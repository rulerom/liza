; ModuleID = '/private/tmp/liza-state-p2-llvm23/staged/module.ll'
source_filename = "/private/tmp/liza-state-p2-llvm23/staged/module.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%variant.5 = type { i32, i64, %struct.JsonError }
%struct.JsonError = type { %variant.1, i64 }
%variant.1 = type { i32, [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8] }
%struct.JsonState = type { %struct.Utf8StreamState, i64, [64 x i8], i32, i1, i32, i1, i32, i32, i32, i32, i64, i64, i32, i64 }
%struct.Utf8StreamState = type { i64, i64, i64, i32, i8, i8, i32, i64 }
%variant.2 = type { i32, i64, %struct.Utf8StreamError }
%struct.Utf8StreamError = type { %variant.0, i64 }
%variant.0 = type { i32, [0 x i8], [0 x i8] }
%variant.3 = type { i32, %struct.Utf8StreamError, [0 x i8] }
%variant.4 = type { i32, %struct.JsonError, [0 x i8] }

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #0

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i32 0, 9) i32 @liza_status(ptr nofree readonly captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v0 = tail call %variant.5 @liza_json.finish(ptr %p0)
  %v1 = extractvalue %variant.5 %v0, 0
  %0 = icmp eq i32 %v1, 0
  %v4 = extractvalue %variant.5 %v0, 2
  %v5 = extractvalue %struct.JsonError %v4, 0
  %v6 = extractvalue %variant.1 %v5, 0
  %switch.offset = add nsw i32 %v6, 1
  %common.ret.op = select i1 %0, i32 0, i32 %switch.offset
  ret i32 %common.ret.op
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @liza_value(ptr nofree readonly captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v0 = tail call %variant.5 @liza_json.finish(ptr %p0)
  %v1 = extractvalue %variant.5 %v0, 0
  %0 = icmp eq i32 %v1, 0
  %v2 = extractvalue %variant.5 %v0, 1
  %v3 = extractvalue %variant.5 %v0, 2
  %v4 = extractvalue %struct.JsonError %v3, 1
  %common.ret.op = select i1 %0, i64 %v2, i64 %v4
  ret i64 %common.ret.op
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define range(i32 0, 2) i32 @liza_pending(ptr nofree readonly captures(none) %p0) local_unnamed_addr #3 {
b0:
  %v0_ptr.i = getelementptr i8, ptr %p0, i64 168
  %v0.i = load i32, ptr %v0_ptr.i, align 4
  %v2.i.not = icmp ne i32 %v0.i, 0
  %spec.select = zext i1 %v2.i.not to i32
  ret i32 %spec.select
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @liza_start(ptr nofree writeonly sret(%struct.JsonState) captures(none) initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %return_storage) local_unnamed_addr #4 {
b0:
  %v16_mem.sroa.75.sroa.0.i = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0.i = alloca i8, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  store i1 false, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  store i1 false, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i = load i8, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i = load i8, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %return_storage, i8 0, i64 28, i1 false)
  %v0_mem.sroa.2.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 28
  store i8 -128, ptr %v0_mem.sroa.2.0.return_storage.sroa_idx, align 4
  %v0_mem.sroa.3.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 29
  store i8 -65, ptr %v0_mem.sroa.3.0.return_storage.sroa_idx, align 1
  %v0_mem.sroa.41.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 32
  store i32 0, ptr %v0_mem.sroa.41.0.return_storage.sroa_idx, align 8
  %0 = getelementptr inbounds nuw i8, ptr %return_storage, i64 40
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %0, i8 0, i64 84, i1 false)
  %v0_mem.sroa.6.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  store i8 %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i, ptr %v0_mem.sroa.6.0.return_storage.sroa_idx, align 4
  %v0_mem.sroa.72.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 128
  store i32 0, ptr %v0_mem.sroa.72.0.return_storage.sroa_idx, align 8
  %v0_mem.sroa.8.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 132
  store i8 %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i, ptr %v0_mem.sroa.8.0.return_storage.sroa_idx, align 4
  %1 = getelementptr inbounds nuw i8, ptr %return_storage, i64 136
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %1, i8 0, i64 36, i1 false)
  %v0_mem.sroa.103.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 176
  store i64 0, ptr %v0_mem.sroa.103.0.return_storage.sroa_idx, align 8
  ret void
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write, target_mem: none)
define i32 @liza_feed(ptr %p0, { ptr, i32 } %p1) local_unnamed_addr #5 {
b0:
  %v1 = tail call i32 @liza_json.feed_mut(ptr %p0, { ptr, i32 } %p1)
  ret i32 %v1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @liza_main() local_unnamed_addr #6 {
b0:
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %struct.Utf8StreamState @liza_utf8_stream.create() local_unnamed_addr #6 {
b0:
  ret %struct.Utf8StreamState { i64 0, i64 0, i64 0, i32 0, i8 -128, i8 -65, i32 0, i64 0 }
}

; Function Attrs: nounwind memory(inaccessiblemem: write)
define %struct.Utf8StreamState @liza_utf8_stream.feed_byte(%struct.Utf8StreamState %p0, i8 %p1) local_unnamed_addr #7 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  %v2.not = icmp eq i32 %v0, 0
  br i1 %v2.not, label %b3, label %common.ret

common.ret:                                       ; preds = %b0, %v145_ok, %b53, %b48, %b34, %b11, %b4
  %common.ret.op = phi %struct.Utf8StreamState [ %v146, %v145_ok ], [ %v11, %b4 ], [ %v28, %b11 ], [ %v96, %b34 ], [ %v111, %b48 ], [ %v134, %b53 ], [ %p0, %b0 ]
  ret %struct.Utf8StreamState %common.ret.op

b3:                                               ; preds = %b0
  %v3 = extractvalue %struct.Utf8StreamState %p0, 0
  %v5 = icmp eq i64 %v3, -1
  br i1 %v5, label %b4, label %b6

b4:                                               ; preds = %b3
  %v8 = insertvalue %struct.Utf8StreamState %p0, i32 2, 6
  %v11 = insertvalue %struct.Utf8StreamState %v8, i64 -1, 7
  br label %common.ret

b6:                                               ; preds = %b3
  %v12 = extractvalue %struct.Utf8StreamState %p0, 3
  %v14 = icmp eq i32 %v12, 0
  br i1 %v14, label %b7, label %b8

b7:                                               ; preds = %b6
  %v17 = insertvalue %struct.Utf8StreamState %p0, i64 %v3, 2
  %v19 = icmp sgt i8 %p1, -1
  br i1 %v19, label %b9, label %b10

b8:                                               ; preds = %b6
  %v100 = extractvalue %struct.Utf8StreamState %p0, 4
  %v101 = icmp ult i8 %p1, %v100
  %v103 = extractvalue %struct.Utf8StreamState %p0, 5
  %v104 = icmp ugt i8 %p1, %v103
  %v105 = select i1 %v101, i1 true, i1 %v104
  br i1 %v105, label %b48, label %v115_ok

b9:                                               ; preds = %b7
  %v20 = extractvalue %struct.Utf8StreamState %p0, 1
  %v22 = icmp eq i64 %v20, -1
  br i1 %v22, label %b11, label %v32_ok

b10:                                              ; preds = %b7
  %v36 = insertvalue %struct.Utf8StreamState %v17, i8 -128, 4
  %v39 = insertvalue %struct.Utf8StreamState %v36, i8 -65, 5
  %0 = add nsw i8 %p1, 62
  %v45 = icmp ult i8 %0, 30
  br i1 %v45, label %b17, label %b18

b11:                                              ; preds = %b9
  %v25 = insertvalue %struct.Utf8StreamState %v17, i32 2, 6
  %v28 = insertvalue %struct.Utf8StreamState %v25, i64 %v3, 7
  br label %common.ret

v32_ok:                                           ; preds = %b9
  %v32 = add nuw i64 %v20, 1
  %v33 = insertvalue %struct.Utf8StreamState %v17, i64 %v32, 1
  br label %b57

b17:                                              ; preds = %b10
  %v48 = insertvalue %struct.Utf8StreamState %v39, i32 1, 3
  br label %b57

b18:                                              ; preds = %b10
  %1 = and i8 %p1, -16
  %v54 = icmp eq i8 %1, -32
  br i1 %v54, label %b22, label %b23

b22:                                              ; preds = %b18
  %v57 = insertvalue %struct.Utf8StreamState %v39, i32 2, 3
  %v59 = icmp eq i8 %p1, -32
  %v62 = insertvalue %struct.Utf8StreamState %v57, i8 -96, 4
  %spec.select = select i1 %v59, %struct.Utf8StreamState %v62, %struct.Utf8StreamState %v57
  %v65 = icmp eq i8 %p1, -19
  %v68 = insertvalue %struct.Utf8StreamState %spec.select, i8 -97, 5
  %spec.select2 = select i1 %v65, %struct.Utf8StreamState %v68, %struct.Utf8StreamState %spec.select
  br label %b57

b23:                                              ; preds = %b18
  %2 = add nsw i8 %p1, 16
  %v75 = icmp ult i8 %2, 5
  br i1 %v75, label %b33, label %b34

b33:                                              ; preds = %b23
  %v78 = insertvalue %struct.Utf8StreamState %v39, i32 3, 3
  %v80 = icmp eq i8 %p1, -16
  %v83 = insertvalue %struct.Utf8StreamState %v78, i8 -112, 4
  %spec.select1 = select i1 %v80, %struct.Utf8StreamState %v83, %struct.Utf8StreamState %v78
  %v86 = icmp eq i8 %p1, -12
  %v89 = insertvalue %struct.Utf8StreamState %spec.select1, i8 -113, 5
  %spec.select3 = select i1 %v86, %struct.Utf8StreamState %v89, %struct.Utf8StreamState %spec.select1
  br label %b57

b34:                                              ; preds = %b23
  %v93 = insertvalue %struct.Utf8StreamState %v39, i32 1, 6
  %v96 = insertvalue %struct.Utf8StreamState %v93, i64 %v3, 7
  br label %common.ret

b48:                                              ; preds = %b8
  %v108 = insertvalue %struct.Utf8StreamState %p0, i32 1, 6
  %v110 = extractvalue %struct.Utf8StreamState %p0, 2
  %v111 = insertvalue %struct.Utf8StreamState %v108, i64 %v110, 7
  br label %common.ret

v115_ok:                                          ; preds = %b8
  %v115 = add i32 %v12, -1
  %v116 = insertvalue %struct.Utf8StreamState %p0, i32 %v115, 3
  %v119 = insertvalue %struct.Utf8StreamState %v116, i8 -128, 4
  %v122 = insertvalue %struct.Utf8StreamState %v119, i8 -65, 5
  %v125 = icmp eq i32 %v115, 0
  br i1 %v125, label %b51, label %b57

b51:                                              ; preds = %v115_ok
  %v126 = extractvalue %struct.Utf8StreamState %p0, 1
  %v128 = icmp eq i64 %v126, -1
  br i1 %v128, label %b53, label %v138_ok

b53:                                              ; preds = %b51
  %v131 = insertvalue %struct.Utf8StreamState %v122, i32 2, 6
  %v134 = insertvalue %struct.Utf8StreamState %v131, i64 %v3, 7
  br label %common.ret

v138_ok:                                          ; preds = %b51
  %v138 = add nuw i64 %v126, 1
  %v139 = insertvalue %struct.Utf8StreamState %v122, i64 %v138, 1
  br label %b57

b57:                                              ; preds = %b33, %b22, %v138_ok, %v115_ok, %v32_ok, %b17
  %v141 = phi %struct.Utf8StreamState [ %v139, %v138_ok ], [ %v33, %v32_ok ], [ %v48, %b17 ], [ %spec.select3, %b33 ], [ %v122, %v115_ok ], [ %spec.select2, %b22 ]
  %v143 = extractvalue %struct.Utf8StreamState %v141, 0
  %v145_pair = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v143, i64 1)
  %v145_overflow = extractvalue { i64, i1 } %v145_pair, 1
  br i1 %v145_overflow, label %v145_trap, label %v145_ok

v145_trap:                                        ; preds = %b57
  tail call void @llvm.trap()
  unreachable

v145_ok:                                          ; preds = %b57
  %v145 = extractvalue { i64, i1 } %v145_pair, 0
  %v146 = insertvalue %struct.Utf8StreamState %v141, i64 %v145, 0
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.2 @liza_utf8_stream.finish(%struct.Utf8StreamState %p0) local_unnamed_addr #6 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  switch i32 %v0, label %b6 [
    i32 1, label %b1
    i32 2, label %b4
  ]

common.ret:                                       ; preds = %b9, %b7, %b4, %b1
  %common.ret.op = phi %variant.2 [ %v6, %b1 ], [ %v13, %b4 ], [ %v20, %b7 ], [ %v22, %b9 ]
  ret %variant.2 %common.ret.op

b1:                                               ; preds = %b0
  %v4 = extractvalue %struct.Utf8StreamState %p0, 7
  %v5 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4, 1
  %v6 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5, 2
  br label %common.ret

b4:                                               ; preds = %b0
  %v11 = extractvalue %struct.Utf8StreamState %p0, 7
  %v12 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11, 1
  %v13 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12, 2
  br label %common.ret

b6:                                               ; preds = %b0
  %v14 = extractvalue %struct.Utf8StreamState %p0, 3
  %v16.not = icmp eq i32 %v14, 0
  br i1 %v16.not, label %b9, label %b7

b7:                                               ; preds = %b6
  %v18 = extractvalue %struct.Utf8StreamState %p0, 2
  %v19 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18, 1
  %v20 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19, 2
  br label %common.ret

b9:                                               ; preds = %b6
  %v21 = extractvalue %struct.Utf8StreamState %p0, 1
  %v22 = insertvalue %variant.2 zeroinitializer, i64 %v21, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.3 @liza_utf8_stream.status(%struct.Utf8StreamState %p0) local_unnamed_addr #6 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  switch i32 %v0, label %common.ret [
    i32 1, label %b1
    i32 2, label %b4
  ]

common.ret:                                       ; preds = %b0, %b4, %b1
  %common.ret.op = phi %variant.3 [ %v6, %b1 ], [ %v13, %b4 ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  ret %variant.3 %common.ret.op

b1:                                               ; preds = %b0
  %v4 = extractvalue %struct.Utf8StreamState %p0, 7
  %v5 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4, 1
  %v6 = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5, 1
  br label %common.ret

b4:                                               ; preds = %b0
  %v11 = extractvalue %struct.Utf8StreamState %p0, 7
  %v12 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11, 1
  %v13 = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @liza_json.create(ptr nofree writeonly sret(%struct.JsonState) captures(none) initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %return_storage) local_unnamed_addr #4 {
b0:
  %v16_mem.sroa.75.sroa.0 = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0 = alloca i8, align 4
  store i1 false, ptr %v16_mem.sroa.75.sroa.0, align 4
  store i1 false, ptr %v16_mem.sroa.77.sroa.0, align 4
  %v16_mem.sroa.5.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 28
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %return_storage, i8 0, i64 28, i1 false)
  store i8 -128, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.6.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 29
  store i8 -65, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx, align 1
  %v16_mem.sroa.71.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 32
  store i32 0, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx, align 8
  %v16_mem.sroa.82.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 40
  %v16_mem.sroa.75.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %v16_mem.sroa.82.0.return_storage.sroa_idx, i8 0, i64 84, i1 false)
  %v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0. = load i8, ptr %v16_mem.sroa.75.sroa.0, align 4
  store i8 %v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0., ptr %v16_mem.sroa.75.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.764.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 128
  store i32 0, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx, align 8
  %v16_mem.sroa.77.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 132
  %v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0. = load i8, ptr %v16_mem.sroa.77.sroa.0, align 4
  store i8 %v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0., ptr %v16_mem.sroa.77.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.785.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 136
  %v16_mem.sroa.857.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 176
  store i64 0, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %v16_mem.sroa.785.0.return_storage.sroa_idx, i8 0, i64 36, i1 false)
  ret void
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define void @liza___liza_json_done(ptr nofree writeonly sret(%struct.JsonState) captures(none) %return_storage, ptr nofree readonly %p0) local_unnamed_addr #2 {
b0:
  %v5_mem.sroa.67.sroa.0 = alloca i8, align 4
  %v22_scratch = alloca [64 x i8], align 1
  %v27_scratch = alloca [64 x i8], align 1
  %v29_mem.sroa.0 = alloca { %struct.Utf8StreamState, i64 }, align 8
  %v29_mem.sroa.131.sroa.4 = alloca [59 x i8], align 1
  %v30_mem.sroa.0 = alloca { %struct.Utf8StreamState, i64 }, align 8
  %v30_mem.sroa.131.sroa.5 = alloca [59 x i8], align 1
  %v14_storage = alloca [64 x i8], align 1
  %v9_storage = alloca [64 x i8], align 1
  %v0_ptr = getelementptr i8, ptr %p0, i64 120
  %v0 = load i32, ptr %v0_ptr, align 4
  %v2 = icmp eq i32 %v0, 0
  %v5_mem.sroa.2.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 56
  %v5_mem.sroa.3.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 57
  %v5_mem.sroa.4.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 58
  %v5_mem.sroa.5.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 59
  %v5_mem.sroa.6.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 60
  %v5_mem.sroa.7.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 61
  %v5_mem.sroa.8.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 62
  %v5_mem.sroa.9.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 63
  %v5_mem.sroa.10.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 64
  %v5_mem.sroa.11.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 65
  %v5_mem.sroa.12.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 66
  %v5_mem.sroa.13.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 67
  %v5_mem.sroa.14.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 68
  %v5_mem.sroa.15.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 69
  %v5_mem.sroa.16.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 70
  %v5_mem.sroa.17.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 71
  %v5_mem.sroa.18.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 72
  %v5_mem.sroa.19.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 73
  %v5_mem.sroa.20.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 74
  %v5_mem.sroa.21.0.p0.sroa_idx = getelementptr i8, ptr %p0, i64 75
  br i1 %v2, label %b1, label %b2

b1:                                               ; preds = %b0
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %v29_mem.sroa.0, ptr noundef nonnull align 1 dereferenceable(56) %p0, i64 56, i1 false)
  %v5_mem.sroa.2.0.copyload = load i8, ptr %v5_mem.sroa.2.0.p0.sroa_idx, align 4
  %v5_mem.sroa.3.0.copyload = load i8, ptr %v5_mem.sroa.3.0.p0.sroa_idx, align 1
  %v5_mem.sroa.4.0.copyload = load i8, ptr %v5_mem.sroa.4.0.p0.sroa_idx, align 2
  %v5_mem.sroa.5.0.copyload = load i8, ptr %v5_mem.sroa.5.0.p0.sroa_idx, align 1
  %v5_mem.sroa.6.0.copyload = load i8, ptr %v5_mem.sroa.6.0.p0.sroa_idx, align 4
  %v5_mem.sroa.7.0.copyload = load i8, ptr %v5_mem.sroa.7.0.p0.sroa_idx, align 1
  %v5_mem.sroa.8.0.copyload = load i8, ptr %v5_mem.sroa.8.0.p0.sroa_idx, align 2
  %v5_mem.sroa.9.0.copyload = load i8, ptr %v5_mem.sroa.9.0.p0.sroa_idx, align 1
  %v5_mem.sroa.10.0.copyload = load i8, ptr %v5_mem.sroa.10.0.p0.sroa_idx, align 4
  %v5_mem.sroa.11.0.copyload = load i8, ptr %v5_mem.sroa.11.0.p0.sroa_idx, align 1
  %v5_mem.sroa.12.0.copyload = load i8, ptr %v5_mem.sroa.12.0.p0.sroa_idx, align 2
  %v5_mem.sroa.13.0.copyload = load i8, ptr %v5_mem.sroa.13.0.p0.sroa_idx, align 1
  %v5_mem.sroa.14.0.copyload = load i8, ptr %v5_mem.sroa.14.0.p0.sroa_idx, align 4
  %v5_mem.sroa.15.0.copyload = load i8, ptr %v5_mem.sroa.15.0.p0.sroa_idx, align 1
  %v5_mem.sroa.16.0.copyload = load i8, ptr %v5_mem.sroa.16.0.p0.sroa_idx, align 2
  %v5_mem.sroa.17.0.copyload = load i8, ptr %v5_mem.sroa.17.0.p0.sroa_idx, align 1
  %v5_mem.sroa.18.0.copyload = load i8, ptr %v5_mem.sroa.18.0.p0.sroa_idx, align 4
  %v5_mem.sroa.19.0.copyload = load i8, ptr %v5_mem.sroa.19.0.p0.sroa_idx, align 1
  %v5_mem.sroa.20.0.copyload = load i8, ptr %v5_mem.sroa.20.0.p0.sroa_idx, align 2
  %v5_mem.sroa.21.0.copyload = load i8, ptr %v5_mem.sroa.21.0.p0.sroa_idx, align 1
  %v5_mem.sroa.22.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 76
  %v5_mem.sroa.22.0.copyload = load i8, ptr %v5_mem.sroa.22.0.p0.sroa_idx, align 4
  %v5_mem.sroa.23.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 77
  %v5_mem.sroa.23.0.copyload = load i8, ptr %v5_mem.sroa.23.0.p0.sroa_idx, align 1
  %v5_mem.sroa.24.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 78
  %v5_mem.sroa.24.0.copyload = load i8, ptr %v5_mem.sroa.24.0.p0.sroa_idx, align 2
  %v5_mem.sroa.25.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 79
  %v5_mem.sroa.25.0.copyload = load i8, ptr %v5_mem.sroa.25.0.p0.sroa_idx, align 1
  %v5_mem.sroa.26.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 80
  %v5_mem.sroa.26.0.copyload = load i8, ptr %v5_mem.sroa.26.0.p0.sroa_idx, align 4
  %v5_mem.sroa.27.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 81
  %v5_mem.sroa.27.0.copyload = load i8, ptr %v5_mem.sroa.27.0.p0.sroa_idx, align 1
  %v5_mem.sroa.28.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 82
  %v5_mem.sroa.28.0.copyload = load i8, ptr %v5_mem.sroa.28.0.p0.sroa_idx, align 2
  %v5_mem.sroa.29.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 83
  %v5_mem.sroa.29.0.copyload = load i8, ptr %v5_mem.sroa.29.0.p0.sroa_idx, align 1
  %v5_mem.sroa.30.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 84
  %v5_mem.sroa.30.0.copyload = load i8, ptr %v5_mem.sroa.30.0.p0.sroa_idx, align 4
  %v5_mem.sroa.31.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 85
  %v5_mem.sroa.31.0.copyload = load i8, ptr %v5_mem.sroa.31.0.p0.sroa_idx, align 1
  %v5_mem.sroa.32.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 86
  %v5_mem.sroa.32.0.copyload = load i8, ptr %v5_mem.sroa.32.0.p0.sroa_idx, align 2
  %v5_mem.sroa.33.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 87
  %v5_mem.sroa.33.0.copyload = load i8, ptr %v5_mem.sroa.33.0.p0.sroa_idx, align 1
  %v5_mem.sroa.34.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 88
  %v5_mem.sroa.34.0.copyload = load i8, ptr %v5_mem.sroa.34.0.p0.sroa_idx, align 4
  %v5_mem.sroa.35.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 89
  %v5_mem.sroa.35.0.copyload = load i8, ptr %v5_mem.sroa.35.0.p0.sroa_idx, align 1
  %v5_mem.sroa.36.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 90
  %v5_mem.sroa.36.0.copyload = load i8, ptr %v5_mem.sroa.36.0.p0.sroa_idx, align 2
  %v5_mem.sroa.37.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 91
  %v5_mem.sroa.37.0.copyload = load i8, ptr %v5_mem.sroa.37.0.p0.sroa_idx, align 1
  %v5_mem.sroa.38.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 92
  %v5_mem.sroa.38.0.copyload = load i8, ptr %v5_mem.sroa.38.0.p0.sroa_idx, align 4
  %v5_mem.sroa.39.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 93
  %v5_mem.sroa.39.0.copyload = load i8, ptr %v5_mem.sroa.39.0.p0.sroa_idx, align 1
  %v5_mem.sroa.40.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 94
  %v5_mem.sroa.40.0.copyload = load i8, ptr %v5_mem.sroa.40.0.p0.sroa_idx, align 2
  %v5_mem.sroa.41.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 95
  %v5_mem.sroa.41.0.copyload = load i8, ptr %v5_mem.sroa.41.0.p0.sroa_idx, align 1
  %v5_mem.sroa.42.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 96
  %v5_mem.sroa.42.0.copyload = load i8, ptr %v5_mem.sroa.42.0.p0.sroa_idx, align 4
  %v5_mem.sroa.43.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 97
  %v5_mem.sroa.43.0.copyload = load i8, ptr %v5_mem.sroa.43.0.p0.sroa_idx, align 1
  %v5_mem.sroa.44.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 98
  %v5_mem.sroa.44.0.copyload = load i8, ptr %v5_mem.sroa.44.0.p0.sroa_idx, align 2
  %v5_mem.sroa.45.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 99
  %v5_mem.sroa.45.0.copyload = load i8, ptr %v5_mem.sroa.45.0.p0.sroa_idx, align 1
  %v5_mem.sroa.46.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 100
  %v5_mem.sroa.46.0.copyload = load i8, ptr %v5_mem.sroa.46.0.p0.sroa_idx, align 4
  %v5_mem.sroa.47.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 101
  %v5_mem.sroa.47.0.copyload = load i8, ptr %v5_mem.sroa.47.0.p0.sroa_idx, align 1
  %v5_mem.sroa.48.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 102
  %v5_mem.sroa.48.0.copyload = load i8, ptr %v5_mem.sroa.48.0.p0.sroa_idx, align 2
  %v5_mem.sroa.49.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 103
  %v5_mem.sroa.49.0.copyload = load i8, ptr %v5_mem.sroa.49.0.p0.sroa_idx, align 1
  %v5_mem.sroa.50.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 104
  %v5_mem.sroa.50.0.copyload = load i8, ptr %v5_mem.sroa.50.0.p0.sroa_idx, align 4
  %v5_mem.sroa.51.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 105
  %v5_mem.sroa.51.0.copyload = load i8, ptr %v5_mem.sroa.51.0.p0.sroa_idx, align 1
  %v5_mem.sroa.52.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 106
  %v5_mem.sroa.52.0.copyload = load i8, ptr %v5_mem.sroa.52.0.p0.sroa_idx, align 2
  %v5_mem.sroa.53.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 107
  %v5_mem.sroa.53.0.copyload = load i8, ptr %v5_mem.sroa.53.0.p0.sroa_idx, align 1
  %v5_mem.sroa.54.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 108
  %v5_mem.sroa.54.0.copyload = load i8, ptr %v5_mem.sroa.54.0.p0.sroa_idx, align 4
  %v5_mem.sroa.55.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 109
  %v5_mem.sroa.55.0.copyload = load i8, ptr %v5_mem.sroa.55.0.p0.sroa_idx, align 1
  %v5_mem.sroa.56.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 110
  %v5_mem.sroa.56.0.copyload = load i8, ptr %v5_mem.sroa.56.0.p0.sroa_idx, align 2
  %v5_mem.sroa.57.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 111
  %v5_mem.sroa.57.0.copyload = load i8, ptr %v5_mem.sroa.57.0.p0.sroa_idx, align 1
  %v5_mem.sroa.58.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 112
  %v5_mem.sroa.58.0.copyload = load i8, ptr %v5_mem.sroa.58.0.p0.sroa_idx, align 4
  %v5_mem.sroa.59.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 113
  %v5_mem.sroa.59.0.copyload = load i8, ptr %v5_mem.sroa.59.0.p0.sroa_idx, align 1
  %v5_mem.sroa.60.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 114
  %v5_mem.sroa.60.0.copyload = load i8, ptr %v5_mem.sroa.60.0.p0.sroa_idx, align 2
  %v5_mem.sroa.61.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 115
  %v5_mem.sroa.61.0.copyload = load i8, ptr %v5_mem.sroa.61.0.p0.sroa_idx, align 1
  %v5_mem.sroa.62.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 116
  %v5_mem.sroa.62.0.copyload = load i8, ptr %v5_mem.sroa.62.0.p0.sroa_idx, align 4
  %v5_mem.sroa.63.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 117
  %v5_mem.sroa.63.0.copyload = load i8, ptr %v5_mem.sroa.63.0.p0.sroa_idx, align 1
  %v5_mem.sroa.64.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 118
  %v5_mem.sroa.64.0.copyload = load i8, ptr %v5_mem.sroa.64.0.p0.sroa_idx, align 2
  %v5_mem.sroa.65.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 119
  %v5_mem.sroa.65.0.copyload = load i8, ptr %v5_mem.sroa.65.0.p0.sroa_idx, align 1
  %v5_mem.sroa.67.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 124
  %0 = load i8, ptr %v5_mem.sroa.67.0.p0.sroa_idx, align 4
  store i8 %0, ptr %v5_mem.sroa.67.sroa.0, align 4
  %v5_mem.sroa.68.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 125
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v29_mem.sroa.131.sroa.4, ptr noundef nonnull align 1 dereferenceable(59) %v5_mem.sroa.68.0.p0.sroa_idx, i64 59, i1 false)
  store i1 true, ptr %v5_mem.sroa.67.sroa.0, align 4
  %v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0. = load i8, ptr %v5_mem.sroa.67.sroa.0, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v8_pair = add i32 %v0, -1
  %v9.unpack = load i8, ptr %v5_mem.sroa.2.0.p0.sroa_idx, align 4
  %v9.unpack258 = load i8, ptr %v5_mem.sroa.3.0.p0.sroa_idx, align 1
  %v9.unpack260 = load i8, ptr %v5_mem.sroa.4.0.p0.sroa_idx, align 2
  %v9.unpack262 = load i8, ptr %v5_mem.sroa.5.0.p0.sroa_idx, align 1
  %v9.unpack264 = load i8, ptr %v5_mem.sroa.6.0.p0.sroa_idx, align 4
  %v9.unpack266 = load i8, ptr %v5_mem.sroa.7.0.p0.sroa_idx, align 1
  %v9.unpack268 = load i8, ptr %v5_mem.sroa.8.0.p0.sroa_idx, align 2
  %v9.unpack270 = load i8, ptr %v5_mem.sroa.9.0.p0.sroa_idx, align 1
  %v9.unpack272 = load i8, ptr %v5_mem.sroa.10.0.p0.sroa_idx, align 4
  %v9.unpack274 = load i8, ptr %v5_mem.sroa.11.0.p0.sroa_idx, align 1
  %v9.unpack276 = load i8, ptr %v5_mem.sroa.12.0.p0.sroa_idx, align 2
  %v9.unpack278 = load i8, ptr %v5_mem.sroa.13.0.p0.sroa_idx, align 1
  %v9.unpack280 = load i8, ptr %v5_mem.sroa.14.0.p0.sroa_idx, align 4
  %v9.unpack282 = load i8, ptr %v5_mem.sroa.15.0.p0.sroa_idx, align 1
  %v9.unpack284 = load i8, ptr %v5_mem.sroa.16.0.p0.sroa_idx, align 2
  %v9.unpack286 = load i8, ptr %v5_mem.sroa.17.0.p0.sroa_idx, align 1
  %v9.unpack288 = load i8, ptr %v5_mem.sroa.18.0.p0.sroa_idx, align 4
  %v9.unpack290 = load i8, ptr %v5_mem.sroa.19.0.p0.sroa_idx, align 1
  %v9.unpack292 = load i8, ptr %v5_mem.sroa.20.0.p0.sroa_idx, align 2
  %v9.unpack294 = load i8, ptr %v5_mem.sroa.21.0.p0.sroa_idx, align 1
  %v9.elt295 = getelementptr i8, ptr %p0, i64 76
  %v9.unpack296 = load i8, ptr %v9.elt295, align 4
  %v9.elt297 = getelementptr i8, ptr %p0, i64 77
  %v9.unpack298 = load i8, ptr %v9.elt297, align 1
  %v9.elt299 = getelementptr i8, ptr %p0, i64 78
  %v9.unpack300 = load i8, ptr %v9.elt299, align 2
  %v9.elt301 = getelementptr i8, ptr %p0, i64 79
  %v9.unpack302 = load i8, ptr %v9.elt301, align 1
  %v9.elt303 = getelementptr i8, ptr %p0, i64 80
  %v9.unpack304 = load i8, ptr %v9.elt303, align 4
  %v9.elt305 = getelementptr i8, ptr %p0, i64 81
  %v9.unpack306 = load i8, ptr %v9.elt305, align 1
  %v9.elt307 = getelementptr i8, ptr %p0, i64 82
  %v9.unpack308 = load i8, ptr %v9.elt307, align 2
  %v9.elt309 = getelementptr i8, ptr %p0, i64 83
  %v9.unpack310 = load i8, ptr %v9.elt309, align 1
  %v9.elt311 = getelementptr i8, ptr %p0, i64 84
  %v9.unpack312 = load i8, ptr %v9.elt311, align 4
  %v9.elt313 = getelementptr i8, ptr %p0, i64 85
  %v9.unpack314 = load i8, ptr %v9.elt313, align 1
  %v9.elt315 = getelementptr i8, ptr %p0, i64 86
  %v9.unpack316 = load i8, ptr %v9.elt315, align 2
  %v9.elt317 = getelementptr i8, ptr %p0, i64 87
  %v9.unpack318 = load i8, ptr %v9.elt317, align 1
  %v9.elt319 = getelementptr i8, ptr %p0, i64 88
  %v9.unpack320 = load i8, ptr %v9.elt319, align 4
  %v9.elt321 = getelementptr i8, ptr %p0, i64 89
  %v9.unpack322 = load i8, ptr %v9.elt321, align 1
  %v9.elt323 = getelementptr i8, ptr %p0, i64 90
  %v9.unpack324 = load i8, ptr %v9.elt323, align 2
  %v9.elt325 = getelementptr i8, ptr %p0, i64 91
  %v9.unpack326 = load i8, ptr %v9.elt325, align 1
  %v9.elt327 = getelementptr i8, ptr %p0, i64 92
  %v9.unpack328 = load i8, ptr %v9.elt327, align 4
  %v9.elt329 = getelementptr i8, ptr %p0, i64 93
  %v9.unpack330 = load i8, ptr %v9.elt329, align 1
  %v9.elt331 = getelementptr i8, ptr %p0, i64 94
  %v9.unpack332 = load i8, ptr %v9.elt331, align 2
  %v9.elt333 = getelementptr i8, ptr %p0, i64 95
  %v9.unpack334 = load i8, ptr %v9.elt333, align 1
  %v9.elt335 = getelementptr i8, ptr %p0, i64 96
  %v9.unpack336 = load i8, ptr %v9.elt335, align 4
  %v9.elt337 = getelementptr i8, ptr %p0, i64 97
  %v9.unpack338 = load i8, ptr %v9.elt337, align 1
  %v9.elt339 = getelementptr i8, ptr %p0, i64 98
  %v9.unpack340 = load i8, ptr %v9.elt339, align 2
  %v9.elt341 = getelementptr i8, ptr %p0, i64 99
  %v9.unpack342 = load i8, ptr %v9.elt341, align 1
  %v9.elt343 = getelementptr i8, ptr %p0, i64 100
  %v9.unpack344 = load i8, ptr %v9.elt343, align 4
  %v9.elt345 = getelementptr i8, ptr %p0, i64 101
  %v9.unpack346 = load i8, ptr %v9.elt345, align 1
  %v9.elt347 = getelementptr i8, ptr %p0, i64 102
  %v9.unpack348 = load i8, ptr %v9.elt347, align 2
  %v9.elt349 = getelementptr i8, ptr %p0, i64 103
  %v9.unpack350 = load i8, ptr %v9.elt349, align 1
  %v9.elt351 = getelementptr i8, ptr %p0, i64 104
  %v9.unpack352 = load i8, ptr %v9.elt351, align 4
  %v9.elt353 = getelementptr i8, ptr %p0, i64 105
  %v9.unpack354 = load i8, ptr %v9.elt353, align 1
  %v9.elt355 = getelementptr i8, ptr %p0, i64 106
  %v9.unpack356 = load i8, ptr %v9.elt355, align 2
  %v9.elt357 = getelementptr i8, ptr %p0, i64 107
  %v9.unpack358 = load i8, ptr %v9.elt357, align 1
  %v9.elt359 = getelementptr i8, ptr %p0, i64 108
  %v9.unpack360 = load i8, ptr %v9.elt359, align 4
  %v9.elt361 = getelementptr i8, ptr %p0, i64 109
  %v9.unpack362 = load i8, ptr %v9.elt361, align 1
  %v9.elt363 = getelementptr i8, ptr %p0, i64 110
  %v9.unpack364 = load i8, ptr %v9.elt363, align 2
  %v9.elt365 = getelementptr i8, ptr %p0, i64 111
  %v9.unpack366 = load i8, ptr %v9.elt365, align 1
  %v9.elt367 = getelementptr i8, ptr %p0, i64 112
  %v9.unpack368 = load i8, ptr %v9.elt367, align 4
  %v9.elt369 = getelementptr i8, ptr %p0, i64 113
  %v9.unpack370 = load i8, ptr %v9.elt369, align 1
  %v9.elt371 = getelementptr i8, ptr %p0, i64 114
  %v9.unpack372 = load i8, ptr %v9.elt371, align 2
  %v9.elt373 = getelementptr i8, ptr %p0, i64 115
  %v9.unpack374 = load i8, ptr %v9.elt373, align 1
  %v9.elt375 = getelementptr i8, ptr %p0, i64 116
  %v9.unpack376 = load i8, ptr %v9.elt375, align 4
  %v9.elt377 = getelementptr i8, ptr %p0, i64 117
  %v9.unpack378 = load i8, ptr %v9.elt377, align 1
  %v9.elt379 = getelementptr i8, ptr %p0, i64 118
  %v9.unpack380 = load i8, ptr %v9.elt379, align 2
  %v9.elt381 = getelementptr i8, ptr %p0, i64 119
  %v9.unpack382 = load i8, ptr %v9.elt381, align 1
  store i8 %v9.unpack, ptr %v9_storage, align 1
  %v9.fca.1.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 1
  store i8 %v9.unpack258, ptr %v9.fca.1.gep, align 1
  %v9.fca.2.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 2
  store i8 %v9.unpack260, ptr %v9.fca.2.gep, align 1
  %v9.fca.3.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 3
  store i8 %v9.unpack262, ptr %v9.fca.3.gep, align 1
  %v9.fca.4.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 4
  store i8 %v9.unpack264, ptr %v9.fca.4.gep, align 1
  %v9.fca.5.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 5
  store i8 %v9.unpack266, ptr %v9.fca.5.gep, align 1
  %v9.fca.6.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 6
  store i8 %v9.unpack268, ptr %v9.fca.6.gep, align 1
  %v9.fca.7.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 7
  store i8 %v9.unpack270, ptr %v9.fca.7.gep, align 1
  %v9.fca.8.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 8
  store i8 %v9.unpack272, ptr %v9.fca.8.gep, align 1
  %v9.fca.9.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 9
  store i8 %v9.unpack274, ptr %v9.fca.9.gep, align 1
  %v9.fca.10.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 10
  store i8 %v9.unpack276, ptr %v9.fca.10.gep, align 1
  %v9.fca.11.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 11
  store i8 %v9.unpack278, ptr %v9.fca.11.gep, align 1
  %v9.fca.12.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 12
  store i8 %v9.unpack280, ptr %v9.fca.12.gep, align 1
  %v9.fca.13.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 13
  store i8 %v9.unpack282, ptr %v9.fca.13.gep, align 1
  %v9.fca.14.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 14
  store i8 %v9.unpack284, ptr %v9.fca.14.gep, align 1
  %v9.fca.15.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 15
  store i8 %v9.unpack286, ptr %v9.fca.15.gep, align 1
  %v9.fca.16.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 16
  store i8 %v9.unpack288, ptr %v9.fca.16.gep, align 1
  %v9.fca.17.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 17
  store i8 %v9.unpack290, ptr %v9.fca.17.gep, align 1
  %v9.fca.18.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 18
  store i8 %v9.unpack292, ptr %v9.fca.18.gep, align 1
  %v9.fca.19.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 19
  store i8 %v9.unpack294, ptr %v9.fca.19.gep, align 1
  %v9.fca.20.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 20
  store i8 %v9.unpack296, ptr %v9.fca.20.gep, align 1
  %v9.fca.21.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 21
  store i8 %v9.unpack298, ptr %v9.fca.21.gep, align 1
  %v9.fca.22.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 22
  store i8 %v9.unpack300, ptr %v9.fca.22.gep, align 1
  %v9.fca.23.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 23
  store i8 %v9.unpack302, ptr %v9.fca.23.gep, align 1
  %v9.fca.24.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 24
  store i8 %v9.unpack304, ptr %v9.fca.24.gep, align 1
  %v9.fca.25.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 25
  store i8 %v9.unpack306, ptr %v9.fca.25.gep, align 1
  %v9.fca.26.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 26
  store i8 %v9.unpack308, ptr %v9.fca.26.gep, align 1
  %v9.fca.27.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 27
  store i8 %v9.unpack310, ptr %v9.fca.27.gep, align 1
  %v9.fca.28.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 28
  store i8 %v9.unpack312, ptr %v9.fca.28.gep, align 1
  %v9.fca.29.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 29
  store i8 %v9.unpack314, ptr %v9.fca.29.gep, align 1
  %v9.fca.30.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 30
  store i8 %v9.unpack316, ptr %v9.fca.30.gep, align 1
  %v9.fca.31.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 31
  store i8 %v9.unpack318, ptr %v9.fca.31.gep, align 1
  %v9.fca.32.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 32
  store i8 %v9.unpack320, ptr %v9.fca.32.gep, align 1
  %v9.fca.33.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 33
  store i8 %v9.unpack322, ptr %v9.fca.33.gep, align 1
  %v9.fca.34.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 34
  store i8 %v9.unpack324, ptr %v9.fca.34.gep, align 1
  %v9.fca.35.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 35
  store i8 %v9.unpack326, ptr %v9.fca.35.gep, align 1
  %v9.fca.36.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 36
  store i8 %v9.unpack328, ptr %v9.fca.36.gep, align 1
  %v9.fca.37.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 37
  store i8 %v9.unpack330, ptr %v9.fca.37.gep, align 1
  %v9.fca.38.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 38
  store i8 %v9.unpack332, ptr %v9.fca.38.gep, align 1
  %v9.fca.39.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 39
  store i8 %v9.unpack334, ptr %v9.fca.39.gep, align 1
  %v9.fca.40.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 40
  store i8 %v9.unpack336, ptr %v9.fca.40.gep, align 1
  %v9.fca.41.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 41
  store i8 %v9.unpack338, ptr %v9.fca.41.gep, align 1
  %v9.fca.42.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 42
  store i8 %v9.unpack340, ptr %v9.fca.42.gep, align 1
  %v9.fca.43.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 43
  store i8 %v9.unpack342, ptr %v9.fca.43.gep, align 1
  %v9.fca.44.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 44
  store i8 %v9.unpack344, ptr %v9.fca.44.gep, align 1
  %v9.fca.45.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 45
  store i8 %v9.unpack346, ptr %v9.fca.45.gep, align 1
  %v9.fca.46.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 46
  store i8 %v9.unpack348, ptr %v9.fca.46.gep, align 1
  %v9.fca.47.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 47
  store i8 %v9.unpack350, ptr %v9.fca.47.gep, align 1
  %v9.fca.48.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 48
  store i8 %v9.unpack352, ptr %v9.fca.48.gep, align 1
  %v9.fca.49.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 49
  store i8 %v9.unpack354, ptr %v9.fca.49.gep, align 1
  %v9.fca.50.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 50
  store i8 %v9.unpack356, ptr %v9.fca.50.gep, align 1
  %v9.fca.51.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 51
  store i8 %v9.unpack358, ptr %v9.fca.51.gep, align 1
  %v9.fca.52.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 52
  store i8 %v9.unpack360, ptr %v9.fca.52.gep, align 1
  %v9.fca.53.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 53
  store i8 %v9.unpack362, ptr %v9.fca.53.gep, align 1
  %v9.fca.54.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 54
  store i8 %v9.unpack364, ptr %v9.fca.54.gep, align 1
  %v9.fca.55.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 55
  store i8 %v9.unpack366, ptr %v9.fca.55.gep, align 1
  %v9.fca.56.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 56
  store i8 %v9.unpack368, ptr %v9.fca.56.gep, align 1
  %v9.fca.57.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 57
  store i8 %v9.unpack370, ptr %v9.fca.57.gep, align 1
  %v9.fca.58.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 58
  store i8 %v9.unpack372, ptr %v9.fca.58.gep, align 1
  %v9.fca.59.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 59
  store i8 %v9.unpack374, ptr %v9.fca.59.gep, align 1
  %v9.fca.60.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 60
  store i8 %v9.unpack376, ptr %v9.fca.60.gep, align 1
  %v9.fca.61.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 61
  store i8 %v9.unpack378, ptr %v9.fca.61.gep, align 1
  %v9.fca.62.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 62
  store i8 %v9.unpack380, ptr %v9.fca.62.gep, align 1
  %v9.fca.63.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 63
  store i8 %v9.unpack382, ptr %v9.fca.63.gep, align 1
  %v10_invalid = icmp ugt i32 %v8_pair, 63
  br i1 %v10_invalid, label %v10_trap, label %v10_ok

v10_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v10_ok:                                           ; preds = %b2
  %v10_offset = zext nneg i32 %v8_pair to i64
  %v10_ptr = getelementptr i8, ptr %v9_storage, i64 %v10_offset
  %v10 = load i8, ptr %v10_ptr, align 1
  %v12 = icmp eq i8 %v10, 1
  br i1 %v12, label %b8_to_b9, label %b3

b3:                                               ; preds = %v10_ok
  store i8 %v9.unpack, ptr %v14_storage, align 1
  %v14.fca.1.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 1
  store i8 %v9.unpack258, ptr %v14.fca.1.gep, align 1
  %v14.fca.2.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 2
  store i8 %v9.unpack260, ptr %v14.fca.2.gep, align 1
  %v14.fca.3.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 3
  store i8 %v9.unpack262, ptr %v14.fca.3.gep, align 1
  %v14.fca.4.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 4
  store i8 %v9.unpack264, ptr %v14.fca.4.gep, align 1
  %v14.fca.5.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 5
  store i8 %v9.unpack266, ptr %v14.fca.5.gep, align 1
  %v14.fca.6.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 6
  store i8 %v9.unpack268, ptr %v14.fca.6.gep, align 1
  %v14.fca.7.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 7
  store i8 %v9.unpack270, ptr %v14.fca.7.gep, align 1
  %v14.fca.8.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 8
  store i8 %v9.unpack272, ptr %v14.fca.8.gep, align 1
  %v14.fca.9.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 9
  store i8 %v9.unpack274, ptr %v14.fca.9.gep, align 1
  %v14.fca.10.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 10
  store i8 %v9.unpack276, ptr %v14.fca.10.gep, align 1
  %v14.fca.11.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 11
  store i8 %v9.unpack278, ptr %v14.fca.11.gep, align 1
  %v14.fca.12.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 12
  store i8 %v9.unpack280, ptr %v14.fca.12.gep, align 1
  %v14.fca.13.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 13
  store i8 %v9.unpack282, ptr %v14.fca.13.gep, align 1
  %v14.fca.14.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 14
  store i8 %v9.unpack284, ptr %v14.fca.14.gep, align 1
  %v14.fca.15.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 15
  store i8 %v9.unpack286, ptr %v14.fca.15.gep, align 1
  %v14.fca.16.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 16
  store i8 %v9.unpack288, ptr %v14.fca.16.gep, align 1
  %v14.fca.17.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 17
  store i8 %v9.unpack290, ptr %v14.fca.17.gep, align 1
  %v14.fca.18.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 18
  store i8 %v9.unpack292, ptr %v14.fca.18.gep, align 1
  %v14.fca.19.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 19
  store i8 %v9.unpack294, ptr %v14.fca.19.gep, align 1
  %v14.fca.20.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 20
  store i8 %v9.unpack296, ptr %v14.fca.20.gep, align 1
  %v14.fca.21.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 21
  store i8 %v9.unpack298, ptr %v14.fca.21.gep, align 1
  %v14.fca.22.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 22
  store i8 %v9.unpack300, ptr %v14.fca.22.gep, align 1
  %v14.fca.23.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 23
  store i8 %v9.unpack302, ptr %v14.fca.23.gep, align 1
  %v14.fca.24.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 24
  store i8 %v9.unpack304, ptr %v14.fca.24.gep, align 1
  %v14.fca.25.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 25
  store i8 %v9.unpack306, ptr %v14.fca.25.gep, align 1
  %v14.fca.26.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 26
  store i8 %v9.unpack308, ptr %v14.fca.26.gep, align 1
  %v14.fca.27.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 27
  store i8 %v9.unpack310, ptr %v14.fca.27.gep, align 1
  %v14.fca.28.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 28
  store i8 %v9.unpack312, ptr %v14.fca.28.gep, align 1
  %v14.fca.29.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 29
  store i8 %v9.unpack314, ptr %v14.fca.29.gep, align 1
  %v14.fca.30.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 30
  store i8 %v9.unpack316, ptr %v14.fca.30.gep, align 1
  %v14.fca.31.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 31
  store i8 %v9.unpack318, ptr %v14.fca.31.gep, align 1
  %v14.fca.32.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 32
  store i8 %v9.unpack320, ptr %v14.fca.32.gep, align 1
  %v14.fca.33.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 33
  store i8 %v9.unpack322, ptr %v14.fca.33.gep, align 1
  %v14.fca.34.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 34
  store i8 %v9.unpack324, ptr %v14.fca.34.gep, align 1
  %v14.fca.35.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 35
  store i8 %v9.unpack326, ptr %v14.fca.35.gep, align 1
  %v14.fca.36.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 36
  store i8 %v9.unpack328, ptr %v14.fca.36.gep, align 1
  %v14.fca.37.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 37
  store i8 %v9.unpack330, ptr %v14.fca.37.gep, align 1
  %v14.fca.38.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 38
  store i8 %v9.unpack332, ptr %v14.fca.38.gep, align 1
  %v14.fca.39.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 39
  store i8 %v9.unpack334, ptr %v14.fca.39.gep, align 1
  %v14.fca.40.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 40
  store i8 %v9.unpack336, ptr %v14.fca.40.gep, align 1
  %v14.fca.41.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 41
  store i8 %v9.unpack338, ptr %v14.fca.41.gep, align 1
  %v14.fca.42.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 42
  store i8 %v9.unpack340, ptr %v14.fca.42.gep, align 1
  %v14.fca.43.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 43
  store i8 %v9.unpack342, ptr %v14.fca.43.gep, align 1
  %v14.fca.44.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 44
  store i8 %v9.unpack344, ptr %v14.fca.44.gep, align 1
  %v14.fca.45.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 45
  store i8 %v9.unpack346, ptr %v14.fca.45.gep, align 1
  %v14.fca.46.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 46
  store i8 %v9.unpack348, ptr %v14.fca.46.gep, align 1
  %v14.fca.47.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 47
  store i8 %v9.unpack350, ptr %v14.fca.47.gep, align 1
  %v14.fca.48.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 48
  store i8 %v9.unpack352, ptr %v14.fca.48.gep, align 1
  %v14.fca.49.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 49
  store i8 %v9.unpack354, ptr %v14.fca.49.gep, align 1
  %v14.fca.50.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 50
  store i8 %v9.unpack356, ptr %v14.fca.50.gep, align 1
  %v14.fca.51.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 51
  store i8 %v9.unpack358, ptr %v14.fca.51.gep, align 1
  %v14.fca.52.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 52
  store i8 %v9.unpack360, ptr %v14.fca.52.gep, align 1
  %v14.fca.53.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 53
  store i8 %v9.unpack362, ptr %v14.fca.53.gep, align 1
  %v14.fca.54.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 54
  store i8 %v9.unpack364, ptr %v14.fca.54.gep, align 1
  %v14.fca.55.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 55
  store i8 %v9.unpack366, ptr %v14.fca.55.gep, align 1
  %v14.fca.56.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 56
  store i8 %v9.unpack368, ptr %v14.fca.56.gep, align 1
  %v14.fca.57.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 57
  store i8 %v9.unpack370, ptr %v14.fca.57.gep, align 1
  %v14.fca.58.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 58
  store i8 %v9.unpack372, ptr %v14.fca.58.gep, align 1
  %v14.fca.59.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 59
  store i8 %v9.unpack374, ptr %v14.fca.59.gep, align 1
  %v14.fca.60.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 60
  store i8 %v9.unpack376, ptr %v14.fca.60.gep, align 1
  %v14.fca.61.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 61
  store i8 %v9.unpack378, ptr %v14.fca.61.gep, align 1
  %v14.fca.62.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 62
  store i8 %v9.unpack380, ptr %v14.fca.62.gep, align 1
  %v14.fca.63.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 63
  store i8 %v9.unpack382, ptr %v14.fca.63.gep, align 1
  %v15_ptr = getelementptr i8, ptr %v14_storage, i64 %v10_offset
  %v15 = load i8, ptr %v15_ptr, align 1
  %v17 = icmp eq i8 %v15, 3
  %spec.select = select i1 %v17, ptr %v22_scratch, ptr %v27_scratch
  %spec.select1351 = select i1 %v17, i8 2, i8 7
  br label %b8_to_b9

b9:                                               ; preds = %b8_to_b9, %b1
  %v29_mem.sroa.0.sink = phi ptr [ %v29_mem.sroa.0, %b8_to_b9 ], [ %p0, %b1 ]
  %v29_mem.sroa.131.sroa.4.sink = phi ptr [ %v29_mem.sroa.131.sroa.4, %b8_to_b9 ], [ %v5_mem.sroa.68.0.p0.sroa_idx, %b1 ]
  %v30_mem.sroa.131.sroa.3.sroa.0.0 = phi i8 [ %1, %b8_to_b9 ], [ %v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0., %b1 ]
  %v30_mem.sroa.9.0 = phi i8 [ %v22.fca.3.load, %b8_to_b9 ], [ %v5_mem.sroa.5.0.copyload, %b1 ]
  %v30_mem.sroa.7.0 = phi i8 [ %v22.fca.2.load, %b8_to_b9 ], [ %v5_mem.sroa.4.0.copyload, %b1 ]
  %v30_mem.sroa.5.0 = phi i8 [ %v22.fca.1.load, %b8_to_b9 ], [ %v5_mem.sroa.3.0.copyload, %b1 ]
  %v30_mem.sroa.3.0 = phi i8 [ %v22.fca.0.load, %b8_to_b9 ], [ %v5_mem.sroa.2.0.copyload, %b1 ]
  %v30_mem.sroa.11.0 = phi i8 [ %v22.fca.4.load, %b8_to_b9 ], [ %v5_mem.sroa.6.0.copyload, %b1 ]
  %v30_mem.sroa.13.0 = phi i8 [ %v22.fca.5.load, %b8_to_b9 ], [ %v5_mem.sroa.7.0.copyload, %b1 ]
  %v30_mem.sroa.15.0 = phi i8 [ %v22.fca.6.load, %b8_to_b9 ], [ %v5_mem.sroa.8.0.copyload, %b1 ]
  %v30_mem.sroa.17.0 = phi i8 [ %v22.fca.7.load, %b8_to_b9 ], [ %v5_mem.sroa.9.0.copyload, %b1 ]
  %v30_mem.sroa.19.0 = phi i8 [ %v22.fca.8.load, %b8_to_b9 ], [ %v5_mem.sroa.10.0.copyload, %b1 ]
  %v30_mem.sroa.21.0 = phi i8 [ %v22.fca.9.load, %b8_to_b9 ], [ %v5_mem.sroa.11.0.copyload, %b1 ]
  %v30_mem.sroa.23.0 = phi i8 [ %v22.fca.10.load, %b8_to_b9 ], [ %v5_mem.sroa.12.0.copyload, %b1 ]
  %v30_mem.sroa.25.0 = phi i8 [ %v22.fca.11.load, %b8_to_b9 ], [ %v5_mem.sroa.13.0.copyload, %b1 ]
  %v30_mem.sroa.27.0 = phi i8 [ %v22.fca.12.load, %b8_to_b9 ], [ %v5_mem.sroa.14.0.copyload, %b1 ]
  %v30_mem.sroa.29.0 = phi i8 [ %v22.fca.13.load, %b8_to_b9 ], [ %v5_mem.sroa.15.0.copyload, %b1 ]
  %v30_mem.sroa.31.0 = phi i8 [ %v22.fca.14.load, %b8_to_b9 ], [ %v5_mem.sroa.16.0.copyload, %b1 ]
  %v30_mem.sroa.33.0 = phi i8 [ %v22.fca.15.load, %b8_to_b9 ], [ %v5_mem.sroa.17.0.copyload, %b1 ]
  %v30_mem.sroa.35.0 = phi i8 [ %v22.fca.16.load, %b8_to_b9 ], [ %v5_mem.sroa.18.0.copyload, %b1 ]
  %v30_mem.sroa.37.0 = phi i8 [ %v22.fca.17.load, %b8_to_b9 ], [ %v5_mem.sroa.19.0.copyload, %b1 ]
  %v30_mem.sroa.39.0 = phi i8 [ %v22.fca.18.load, %b8_to_b9 ], [ %v5_mem.sroa.20.0.copyload, %b1 ]
  %v30_mem.sroa.41.0 = phi i8 [ %v22.fca.19.load, %b8_to_b9 ], [ %v5_mem.sroa.21.0.copyload, %b1 ]
  %v30_mem.sroa.43.0 = phi i8 [ %v22.fca.20.load, %b8_to_b9 ], [ %v5_mem.sroa.22.0.copyload, %b1 ]
  %v30_mem.sroa.45.0 = phi i8 [ %v22.fca.21.load, %b8_to_b9 ], [ %v5_mem.sroa.23.0.copyload, %b1 ]
  %v30_mem.sroa.47.0 = phi i8 [ %v22.fca.22.load, %b8_to_b9 ], [ %v5_mem.sroa.24.0.copyload, %b1 ]
  %v30_mem.sroa.49.0 = phi i8 [ %v22.fca.23.load, %b8_to_b9 ], [ %v5_mem.sroa.25.0.copyload, %b1 ]
  %v30_mem.sroa.51.0 = phi i8 [ %v22.fca.24.load, %b8_to_b9 ], [ %v5_mem.sroa.26.0.copyload, %b1 ]
  %v30_mem.sroa.53.0 = phi i8 [ %v22.fca.25.load, %b8_to_b9 ], [ %v5_mem.sroa.27.0.copyload, %b1 ]
  %v30_mem.sroa.55.0 = phi i8 [ %v22.fca.26.load, %b8_to_b9 ], [ %v5_mem.sroa.28.0.copyload, %b1 ]
  %v30_mem.sroa.57.0 = phi i8 [ %v22.fca.27.load, %b8_to_b9 ], [ %v5_mem.sroa.29.0.copyload, %b1 ]
  %v30_mem.sroa.59.0 = phi i8 [ %v22.fca.28.load, %b8_to_b9 ], [ %v5_mem.sroa.30.0.copyload, %b1 ]
  %v30_mem.sroa.61.0 = phi i8 [ %v22.fca.29.load, %b8_to_b9 ], [ %v5_mem.sroa.31.0.copyload, %b1 ]
  %v30_mem.sroa.63.0 = phi i8 [ %v22.fca.30.load, %b8_to_b9 ], [ %v5_mem.sroa.32.0.copyload, %b1 ]
  %v30_mem.sroa.65.0 = phi i8 [ %v22.fca.31.load, %b8_to_b9 ], [ %v5_mem.sroa.33.0.copyload, %b1 ]
  %v30_mem.sroa.67.0 = phi i8 [ %v22.fca.32.load, %b8_to_b9 ], [ %v5_mem.sroa.34.0.copyload, %b1 ]
  %v30_mem.sroa.69.0 = phi i8 [ %v22.fca.33.load, %b8_to_b9 ], [ %v5_mem.sroa.35.0.copyload, %b1 ]
  %v30_mem.sroa.71.0 = phi i8 [ %v22.fca.34.load, %b8_to_b9 ], [ %v5_mem.sroa.36.0.copyload, %b1 ]
  %v30_mem.sroa.73.0 = phi i8 [ %v22.fca.35.load, %b8_to_b9 ], [ %v5_mem.sroa.37.0.copyload, %b1 ]
  %v30_mem.sroa.75.0 = phi i8 [ %v22.fca.36.load, %b8_to_b9 ], [ %v5_mem.sroa.38.0.copyload, %b1 ]
  %v30_mem.sroa.77.0 = phi i8 [ %v22.fca.37.load, %b8_to_b9 ], [ %v5_mem.sroa.39.0.copyload, %b1 ]
  %v30_mem.sroa.79.0 = phi i8 [ %v22.fca.38.load, %b8_to_b9 ], [ %v5_mem.sroa.40.0.copyload, %b1 ]
  %v30_mem.sroa.81.0 = phi i8 [ %v22.fca.39.load, %b8_to_b9 ], [ %v5_mem.sroa.41.0.copyload, %b1 ]
  %v30_mem.sroa.83.0 = phi i8 [ %v22.fca.40.load, %b8_to_b9 ], [ %v5_mem.sroa.42.0.copyload, %b1 ]
  %v30_mem.sroa.85.0 = phi i8 [ %v22.fca.41.load, %b8_to_b9 ], [ %v5_mem.sroa.43.0.copyload, %b1 ]
  %v30_mem.sroa.87.0 = phi i8 [ %v22.fca.42.load, %b8_to_b9 ], [ %v5_mem.sroa.44.0.copyload, %b1 ]
  %v30_mem.sroa.89.0 = phi i8 [ %v22.fca.43.load, %b8_to_b9 ], [ %v5_mem.sroa.45.0.copyload, %b1 ]
  %v30_mem.sroa.91.0 = phi i8 [ %v22.fca.44.load, %b8_to_b9 ], [ %v5_mem.sroa.46.0.copyload, %b1 ]
  %v30_mem.sroa.93.0 = phi i8 [ %v22.fca.45.load, %b8_to_b9 ], [ %v5_mem.sroa.47.0.copyload, %b1 ]
  %v30_mem.sroa.95.0 = phi i8 [ %v22.fca.46.load, %b8_to_b9 ], [ %v5_mem.sroa.48.0.copyload, %b1 ]
  %v30_mem.sroa.97.0 = phi i8 [ %v22.fca.47.load, %b8_to_b9 ], [ %v5_mem.sroa.49.0.copyload, %b1 ]
  %v30_mem.sroa.99.0 = phi i8 [ %v22.fca.48.load, %b8_to_b9 ], [ %v5_mem.sroa.50.0.copyload, %b1 ]
  %v30_mem.sroa.101.0 = phi i8 [ %v22.fca.49.load, %b8_to_b9 ], [ %v5_mem.sroa.51.0.copyload, %b1 ]
  %v30_mem.sroa.103.0 = phi i8 [ %v22.fca.50.load, %b8_to_b9 ], [ %v5_mem.sroa.52.0.copyload, %b1 ]
  %v30_mem.sroa.105.0 = phi i8 [ %v22.fca.51.load, %b8_to_b9 ], [ %v5_mem.sroa.53.0.copyload, %b1 ]
  %v30_mem.sroa.107.0 = phi i8 [ %v22.fca.52.load, %b8_to_b9 ], [ %v5_mem.sroa.54.0.copyload, %b1 ]
  %v30_mem.sroa.109.0 = phi i8 [ %v22.fca.53.load, %b8_to_b9 ], [ %v5_mem.sroa.55.0.copyload, %b1 ]
  %v30_mem.sroa.111.0 = phi i8 [ %v22.fca.54.load, %b8_to_b9 ], [ %v5_mem.sroa.56.0.copyload, %b1 ]
  %v30_mem.sroa.113.0 = phi i8 [ %v22.fca.55.load, %b8_to_b9 ], [ %v5_mem.sroa.57.0.copyload, %b1 ]
  %v30_mem.sroa.115.0 = phi i8 [ %v22.fca.56.load, %b8_to_b9 ], [ %v5_mem.sroa.58.0.copyload, %b1 ]
  %v30_mem.sroa.117.0 = phi i8 [ %v22.fca.57.load, %b8_to_b9 ], [ %v5_mem.sroa.59.0.copyload, %b1 ]
  %v30_mem.sroa.119.0 = phi i8 [ %v22.fca.58.load, %b8_to_b9 ], [ %v5_mem.sroa.60.0.copyload, %b1 ]
  %v30_mem.sroa.121.0 = phi i8 [ %v22.fca.59.load, %b8_to_b9 ], [ %v5_mem.sroa.61.0.copyload, %b1 ]
  %v30_mem.sroa.123.0 = phi i8 [ %v22.fca.60.load, %b8_to_b9 ], [ %v5_mem.sroa.62.0.copyload, %b1 ]
  %v30_mem.sroa.125.0 = phi i8 [ %v22.fca.61.load, %b8_to_b9 ], [ %v5_mem.sroa.63.0.copyload, %b1 ]
  %v30_mem.sroa.127.0 = phi i8 [ %v22.fca.62.load, %b8_to_b9 ], [ %v5_mem.sroa.64.0.copyload, %b1 ]
  %v30_mem.sroa.129.0 = phi i8 [ %v22.fca.63.load, %b8_to_b9 ], [ %v5_mem.sroa.65.0.copyload, %b1 ]
  %v30_mem.sroa.131.sroa.0.0 = phi i32 [ %v23_mem.sroa.130.sroa.0.0.copyload, %b8_to_b9 ], [ 0, %b1 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %v30_mem.sroa.0, ptr noundef nonnull align 1 dereferenceable(56) %v29_mem.sroa.0.sink, i64 56, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5, ptr noundef nonnull align 1 dereferenceable(59) %v29_mem.sroa.131.sroa.4.sink, i64 59, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %return_storage, ptr noundef nonnull align 8 dereferenceable(56) %v30_mem.sroa.0, i64 56, i1 false)
  %v30_mem.sroa.3.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 56
  store i8 %v30_mem.sroa.3.0, ptr %v30_mem.sroa.3.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.5.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 57
  store i8 %v30_mem.sroa.5.0, ptr %v30_mem.sroa.5.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.7.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 58
  store i8 %v30_mem.sroa.7.0, ptr %v30_mem.sroa.7.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.9.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 59
  store i8 %v30_mem.sroa.9.0, ptr %v30_mem.sroa.9.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.11.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 60
  store i8 %v30_mem.sroa.11.0, ptr %v30_mem.sroa.11.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.13.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 61
  store i8 %v30_mem.sroa.13.0, ptr %v30_mem.sroa.13.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.15.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 62
  store i8 %v30_mem.sroa.15.0, ptr %v30_mem.sroa.15.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.17.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 63
  store i8 %v30_mem.sroa.17.0, ptr %v30_mem.sroa.17.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.19.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 64
  store i8 %v30_mem.sroa.19.0, ptr %v30_mem.sroa.19.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.21.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 65
  store i8 %v30_mem.sroa.21.0, ptr %v30_mem.sroa.21.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.23.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 66
  store i8 %v30_mem.sroa.23.0, ptr %v30_mem.sroa.23.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.25.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 67
  store i8 %v30_mem.sroa.25.0, ptr %v30_mem.sroa.25.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.27.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 68
  store i8 %v30_mem.sroa.27.0, ptr %v30_mem.sroa.27.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.29.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 69
  store i8 %v30_mem.sroa.29.0, ptr %v30_mem.sroa.29.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.31.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 70
  store i8 %v30_mem.sroa.31.0, ptr %v30_mem.sroa.31.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.33.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 71
  store i8 %v30_mem.sroa.33.0, ptr %v30_mem.sroa.33.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.35.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 72
  store i8 %v30_mem.sroa.35.0, ptr %v30_mem.sroa.35.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.37.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 73
  store i8 %v30_mem.sroa.37.0, ptr %v30_mem.sroa.37.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.39.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 74
  store i8 %v30_mem.sroa.39.0, ptr %v30_mem.sroa.39.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.41.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 75
  store i8 %v30_mem.sroa.41.0, ptr %v30_mem.sroa.41.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.43.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 76
  store i8 %v30_mem.sroa.43.0, ptr %v30_mem.sroa.43.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.45.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 77
  store i8 %v30_mem.sroa.45.0, ptr %v30_mem.sroa.45.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.47.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 78
  store i8 %v30_mem.sroa.47.0, ptr %v30_mem.sroa.47.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.49.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 79
  store i8 %v30_mem.sroa.49.0, ptr %v30_mem.sroa.49.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.51.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 80
  store i8 %v30_mem.sroa.51.0, ptr %v30_mem.sroa.51.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.53.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 81
  store i8 %v30_mem.sroa.53.0, ptr %v30_mem.sroa.53.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.55.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 82
  store i8 %v30_mem.sroa.55.0, ptr %v30_mem.sroa.55.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.57.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 83
  store i8 %v30_mem.sroa.57.0, ptr %v30_mem.sroa.57.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.59.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 84
  store i8 %v30_mem.sroa.59.0, ptr %v30_mem.sroa.59.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.61.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 85
  store i8 %v30_mem.sroa.61.0, ptr %v30_mem.sroa.61.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.63.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 86
  store i8 %v30_mem.sroa.63.0, ptr %v30_mem.sroa.63.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.65.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 87
  store i8 %v30_mem.sroa.65.0, ptr %v30_mem.sroa.65.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.67.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 88
  store i8 %v30_mem.sroa.67.0, ptr %v30_mem.sroa.67.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.69.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 89
  store i8 %v30_mem.sroa.69.0, ptr %v30_mem.sroa.69.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.71.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 90
  store i8 %v30_mem.sroa.71.0, ptr %v30_mem.sroa.71.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.73.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 91
  store i8 %v30_mem.sroa.73.0, ptr %v30_mem.sroa.73.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.75.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 92
  store i8 %v30_mem.sroa.75.0, ptr %v30_mem.sroa.75.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.77.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 93
  store i8 %v30_mem.sroa.77.0, ptr %v30_mem.sroa.77.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.79.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 94
  store i8 %v30_mem.sroa.79.0, ptr %v30_mem.sroa.79.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.81.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 95
  store i8 %v30_mem.sroa.81.0, ptr %v30_mem.sroa.81.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.83.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 96
  store i8 %v30_mem.sroa.83.0, ptr %v30_mem.sroa.83.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.85.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 97
  store i8 %v30_mem.sroa.85.0, ptr %v30_mem.sroa.85.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.87.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 98
  store i8 %v30_mem.sroa.87.0, ptr %v30_mem.sroa.87.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.89.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 99
  store i8 %v30_mem.sroa.89.0, ptr %v30_mem.sroa.89.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.91.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 100
  store i8 %v30_mem.sroa.91.0, ptr %v30_mem.sroa.91.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.93.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 101
  store i8 %v30_mem.sroa.93.0, ptr %v30_mem.sroa.93.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.95.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 102
  store i8 %v30_mem.sroa.95.0, ptr %v30_mem.sroa.95.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.97.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 103
  store i8 %v30_mem.sroa.97.0, ptr %v30_mem.sroa.97.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.99.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 104
  store i8 %v30_mem.sroa.99.0, ptr %v30_mem.sroa.99.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.101.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 105
  store i8 %v30_mem.sroa.101.0, ptr %v30_mem.sroa.101.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.103.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 106
  store i8 %v30_mem.sroa.103.0, ptr %v30_mem.sroa.103.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.105.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 107
  store i8 %v30_mem.sroa.105.0, ptr %v30_mem.sroa.105.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.107.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 108
  store i8 %v30_mem.sroa.107.0, ptr %v30_mem.sroa.107.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.109.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 109
  store i8 %v30_mem.sroa.109.0, ptr %v30_mem.sroa.109.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.111.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 110
  store i8 %v30_mem.sroa.111.0, ptr %v30_mem.sroa.111.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.113.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 111
  store i8 %v30_mem.sroa.113.0, ptr %v30_mem.sroa.113.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.115.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 112
  store i8 %v30_mem.sroa.115.0, ptr %v30_mem.sroa.115.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.117.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 113
  store i8 %v30_mem.sroa.117.0, ptr %v30_mem.sroa.117.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.119.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 114
  store i8 %v30_mem.sroa.119.0, ptr %v30_mem.sroa.119.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.121.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 115
  store i8 %v30_mem.sroa.121.0, ptr %v30_mem.sroa.121.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.123.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 116
  store i8 %v30_mem.sroa.123.0, ptr %v30_mem.sroa.123.0.return_storage.sroa_idx, align 4
  %v30_mem.sroa.125.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 117
  store i8 %v30_mem.sroa.125.0, ptr %v30_mem.sroa.125.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.127.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 118
  store i8 %v30_mem.sroa.127.0, ptr %v30_mem.sroa.127.0.return_storage.sroa_idx, align 2
  %v30_mem.sroa.129.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 119
  store i8 %v30_mem.sroa.129.0, ptr %v30_mem.sroa.129.0.return_storage.sroa_idx, align 1
  %v30_mem.sroa.131.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 120
  store i32 %v30_mem.sroa.131.sroa.0.0, ptr %v30_mem.sroa.131.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.131.sroa.3.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  store i8 %v30_mem.sroa.131.sroa.3.sroa.0.0, ptr %v30_mem.sroa.131.sroa.3.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx, align 4
  %v30_mem.sroa.131.sroa.5.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 125
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5, i64 59, i1 false)
  ret void

b8_to_b9:                                         ; preds = %b3, %v10_ok
  %v22_scratch.sink1350 = phi ptr [ %v22_scratch, %v10_ok ], [ %spec.select, %b3 ]
  %.sink = phi i8 [ 2, %v10_ok ], [ %spec.select1351, %b3 ]
  %v19.unpack763 = load i8, ptr %v9.elt381, align 1
  %v19.unpack761 = load i8, ptr %v9.elt379, align 2
  %v19.unpack759 = load i8, ptr %v9.elt377, align 1
  %v19.unpack757 = load i8, ptr %v9.elt375, align 4
  %v19.unpack755 = load i8, ptr %v9.elt373, align 1
  %v19.unpack753 = load i8, ptr %v9.elt371, align 2
  %v19.unpack751 = load i8, ptr %v9.elt369, align 1
  %v19.unpack749 = load i8, ptr %v9.elt367, align 4
  %v19.unpack747 = load i8, ptr %v9.elt365, align 1
  %v19.unpack745 = load i8, ptr %v9.elt363, align 2
  %v19.unpack743 = load i8, ptr %v9.elt361, align 1
  %v19.unpack741 = load i8, ptr %v9.elt359, align 4
  %v19.unpack739 = load i8, ptr %v9.elt357, align 1
  %v19.unpack737 = load i8, ptr %v9.elt355, align 2
  %v19.unpack735 = load i8, ptr %v9.elt353, align 1
  %v19.unpack733 = load i8, ptr %v9.elt351, align 4
  %v19.unpack731 = load i8, ptr %v9.elt349, align 1
  %v19.unpack729 = load i8, ptr %v9.elt347, align 2
  %v19.unpack727 = load i8, ptr %v9.elt345, align 1
  %v19.unpack725 = load i8, ptr %v9.elt343, align 4
  %v19.unpack723 = load i8, ptr %v9.elt341, align 1
  %v19.unpack721 = load i8, ptr %v9.elt339, align 2
  %v19.unpack719 = load i8, ptr %v9.elt337, align 1
  %v19.unpack717 = load i8, ptr %v9.elt335, align 4
  %v19.unpack715 = load i8, ptr %v9.elt333, align 1
  %v19.unpack713 = load i8, ptr %v9.elt331, align 2
  %v19.unpack711 = load i8, ptr %v9.elt329, align 1
  %v19.unpack709 = load i8, ptr %v9.elt327, align 4
  %v19.unpack707 = load i8, ptr %v9.elt325, align 1
  %v19.unpack705 = load i8, ptr %v9.elt323, align 2
  %v19.unpack703 = load i8, ptr %v9.elt321, align 1
  %v19.unpack701 = load i8, ptr %v9.elt319, align 4
  %v19.unpack699 = load i8, ptr %v9.elt317, align 1
  %v19.unpack697 = load i8, ptr %v9.elt315, align 2
  %v19.unpack695 = load i8, ptr %v9.elt313, align 1
  %v19.unpack693 = load i8, ptr %v9.elt311, align 4
  %v19.unpack691 = load i8, ptr %v9.elt309, align 1
  %v19.unpack689 = load i8, ptr %v9.elt307, align 2
  %v19.unpack687 = load i8, ptr %v9.elt305, align 1
  %v19.unpack685 = load i8, ptr %v9.elt303, align 4
  %v19.unpack683 = load i8, ptr %v9.elt301, align 1
  %v19.unpack681 = load i8, ptr %v9.elt299, align 2
  %v19.unpack679 = load i8, ptr %v9.elt297, align 1
  %v19.unpack677 = load i8, ptr %v9.elt295, align 4
  %v19.unpack675 = load i8, ptr %v5_mem.sroa.21.0.p0.sroa_idx, align 1
  %v19.unpack673 = load i8, ptr %v5_mem.sroa.20.0.p0.sroa_idx, align 2
  %v19.unpack671 = load i8, ptr %v5_mem.sroa.19.0.p0.sroa_idx, align 1
  %v19.unpack669 = load i8, ptr %v5_mem.sroa.18.0.p0.sroa_idx, align 4
  %v19.unpack667 = load i8, ptr %v5_mem.sroa.17.0.p0.sroa_idx, align 1
  %v19.unpack665 = load i8, ptr %v5_mem.sroa.16.0.p0.sroa_idx, align 2
  %v19.unpack663 = load i8, ptr %v5_mem.sroa.15.0.p0.sroa_idx, align 1
  %v19.unpack661 = load i8, ptr %v5_mem.sroa.14.0.p0.sroa_idx, align 4
  %v19.unpack659 = load i8, ptr %v5_mem.sroa.13.0.p0.sroa_idx, align 1
  %v19.unpack657 = load i8, ptr %v5_mem.sroa.12.0.p0.sroa_idx, align 2
  %v19.unpack655 = load i8, ptr %v5_mem.sroa.11.0.p0.sroa_idx, align 1
  %v19.unpack653 = load i8, ptr %v5_mem.sroa.10.0.p0.sroa_idx, align 4
  %v19.unpack651 = load i8, ptr %v5_mem.sroa.9.0.p0.sroa_idx, align 1
  %v19.unpack649 = load i8, ptr %v5_mem.sroa.8.0.p0.sroa_idx, align 2
  %v19.unpack647 = load i8, ptr %v5_mem.sroa.7.0.p0.sroa_idx, align 1
  %v19.unpack645 = load i8, ptr %v5_mem.sroa.6.0.p0.sroa_idx, align 4
  %v19.unpack643 = load i8, ptr %v5_mem.sroa.5.0.p0.sroa_idx, align 1
  %v19.unpack641 = load i8, ptr %v5_mem.sroa.4.0.p0.sroa_idx, align 2
  %v19.unpack639 = load i8, ptr %v5_mem.sroa.3.0.p0.sroa_idx, align 1
  %v19.unpack = load i8, ptr %v5_mem.sroa.2.0.p0.sroa_idx, align 4
  store i8 %v19.unpack, ptr %v22_scratch.sink1350, align 1
  %v19.fca.1.gep132 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 1
  store i8 %v19.unpack639, ptr %v19.fca.1.gep132, align 1
  %v19.fca.2.gep134 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 2
  store i8 %v19.unpack641, ptr %v19.fca.2.gep134, align 1
  %v19.fca.3.gep136 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 3
  store i8 %v19.unpack643, ptr %v19.fca.3.gep136, align 1
  %v19.fca.4.gep138 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 4
  store i8 %v19.unpack645, ptr %v19.fca.4.gep138, align 1
  %v19.fca.5.gep140 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 5
  store i8 %v19.unpack647, ptr %v19.fca.5.gep140, align 1
  %v19.fca.6.gep142 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 6
  store i8 %v19.unpack649, ptr %v19.fca.6.gep142, align 1
  %v19.fca.7.gep144 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 7
  store i8 %v19.unpack651, ptr %v19.fca.7.gep144, align 1
  %v19.fca.8.gep146 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 8
  store i8 %v19.unpack653, ptr %v19.fca.8.gep146, align 1
  %v19.fca.9.gep148 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 9
  store i8 %v19.unpack655, ptr %v19.fca.9.gep148, align 1
  %v19.fca.10.gep150 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 10
  store i8 %v19.unpack657, ptr %v19.fca.10.gep150, align 1
  %v19.fca.11.gep152 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 11
  store i8 %v19.unpack659, ptr %v19.fca.11.gep152, align 1
  %v19.fca.12.gep154 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 12
  store i8 %v19.unpack661, ptr %v19.fca.12.gep154, align 1
  %v19.fca.13.gep156 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 13
  store i8 %v19.unpack663, ptr %v19.fca.13.gep156, align 1
  %v19.fca.14.gep158 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 14
  store i8 %v19.unpack665, ptr %v19.fca.14.gep158, align 1
  %v19.fca.15.gep160 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 15
  store i8 %v19.unpack667, ptr %v19.fca.15.gep160, align 1
  %v19.fca.16.gep162 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 16
  store i8 %v19.unpack669, ptr %v19.fca.16.gep162, align 1
  %v19.fca.17.gep164 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 17
  store i8 %v19.unpack671, ptr %v19.fca.17.gep164, align 1
  %v19.fca.18.gep166 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 18
  store i8 %v19.unpack673, ptr %v19.fca.18.gep166, align 1
  %v19.fca.19.gep168 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 19
  store i8 %v19.unpack675, ptr %v19.fca.19.gep168, align 1
  %v19.fca.20.gep170 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 20
  store i8 %v19.unpack677, ptr %v19.fca.20.gep170, align 1
  %v19.fca.21.gep172 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 21
  store i8 %v19.unpack679, ptr %v19.fca.21.gep172, align 1
  %v19.fca.22.gep174 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 22
  store i8 %v19.unpack681, ptr %v19.fca.22.gep174, align 1
  %v19.fca.23.gep176 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 23
  store i8 %v19.unpack683, ptr %v19.fca.23.gep176, align 1
  %v19.fca.24.gep178 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 24
  store i8 %v19.unpack685, ptr %v19.fca.24.gep178, align 1
  %v19.fca.25.gep180 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 25
  store i8 %v19.unpack687, ptr %v19.fca.25.gep180, align 1
  %v19.fca.26.gep182 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 26
  store i8 %v19.unpack689, ptr %v19.fca.26.gep182, align 1
  %v19.fca.27.gep184 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 27
  store i8 %v19.unpack691, ptr %v19.fca.27.gep184, align 1
  %v19.fca.28.gep186 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 28
  store i8 %v19.unpack693, ptr %v19.fca.28.gep186, align 1
  %v19.fca.29.gep188 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 29
  store i8 %v19.unpack695, ptr %v19.fca.29.gep188, align 1
  %v19.fca.30.gep190 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 30
  store i8 %v19.unpack697, ptr %v19.fca.30.gep190, align 1
  %v19.fca.31.gep192 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 31
  store i8 %v19.unpack699, ptr %v19.fca.31.gep192, align 1
  %v19.fca.32.gep194 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 32
  store i8 %v19.unpack701, ptr %v19.fca.32.gep194, align 1
  %v19.fca.33.gep196 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 33
  store i8 %v19.unpack703, ptr %v19.fca.33.gep196, align 1
  %v19.fca.34.gep198 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 34
  store i8 %v19.unpack705, ptr %v19.fca.34.gep198, align 1
  %v19.fca.35.gep200 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 35
  store i8 %v19.unpack707, ptr %v19.fca.35.gep200, align 1
  %v19.fca.36.gep202 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 36
  store i8 %v19.unpack709, ptr %v19.fca.36.gep202, align 1
  %v19.fca.37.gep204 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 37
  store i8 %v19.unpack711, ptr %v19.fca.37.gep204, align 1
  %v19.fca.38.gep206 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 38
  store i8 %v19.unpack713, ptr %v19.fca.38.gep206, align 1
  %v19.fca.39.gep208 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 39
  store i8 %v19.unpack715, ptr %v19.fca.39.gep208, align 1
  %v19.fca.40.gep210 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 40
  store i8 %v19.unpack717, ptr %v19.fca.40.gep210, align 1
  %v19.fca.41.gep212 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 41
  store i8 %v19.unpack719, ptr %v19.fca.41.gep212, align 1
  %v19.fca.42.gep214 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 42
  store i8 %v19.unpack721, ptr %v19.fca.42.gep214, align 1
  %v19.fca.43.gep216 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 43
  store i8 %v19.unpack723, ptr %v19.fca.43.gep216, align 1
  %v19.fca.44.gep218 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 44
  store i8 %v19.unpack725, ptr %v19.fca.44.gep218, align 1
  %v19.fca.45.gep220 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 45
  store i8 %v19.unpack727, ptr %v19.fca.45.gep220, align 1
  %v19.fca.46.gep222 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 46
  store i8 %v19.unpack729, ptr %v19.fca.46.gep222, align 1
  %v19.fca.47.gep224 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 47
  store i8 %v19.unpack731, ptr %v19.fca.47.gep224, align 1
  %v19.fca.48.gep226 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 48
  store i8 %v19.unpack733, ptr %v19.fca.48.gep226, align 1
  %v19.fca.49.gep228 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 49
  store i8 %v19.unpack735, ptr %v19.fca.49.gep228, align 1
  %v19.fca.50.gep230 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 50
  store i8 %v19.unpack737, ptr %v19.fca.50.gep230, align 1
  %v19.fca.51.gep232 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 51
  store i8 %v19.unpack739, ptr %v19.fca.51.gep232, align 1
  %v19.fca.52.gep234 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 52
  store i8 %v19.unpack741, ptr %v19.fca.52.gep234, align 1
  %v19.fca.53.gep236 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 53
  store i8 %v19.unpack743, ptr %v19.fca.53.gep236, align 1
  %v19.fca.54.gep238 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 54
  store i8 %v19.unpack745, ptr %v19.fca.54.gep238, align 1
  %v19.fca.55.gep240 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 55
  store i8 %v19.unpack747, ptr %v19.fca.55.gep240, align 1
  %v19.fca.56.gep242 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 56
  store i8 %v19.unpack749, ptr %v19.fca.56.gep242, align 1
  %v19.fca.57.gep244 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 57
  store i8 %v19.unpack751, ptr %v19.fca.57.gep244, align 1
  %v19.fca.58.gep246 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 58
  store i8 %v19.unpack753, ptr %v19.fca.58.gep246, align 1
  %v19.fca.59.gep248 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 59
  store i8 %v19.unpack755, ptr %v19.fca.59.gep248, align 1
  %v19.fca.60.gep250 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 60
  store i8 %v19.unpack757, ptr %v19.fca.60.gep250, align 1
  %v19.fca.61.gep252 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 61
  store i8 %v19.unpack759, ptr %v19.fca.61.gep252, align 1
  %v19.fca.62.gep254 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 62
  store i8 %v19.unpack761, ptr %v19.fca.62.gep254, align 1
  %v19.fca.63.gep256 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 63
  store i8 %v19.unpack763, ptr %v19.fca.63.gep256, align 1
  %v22_ptr = getelementptr i8, ptr %v22_scratch.sink1350, i64 %v10_offset
  store i8 %.sink, ptr %v22_ptr, align 1
  %v22.fca.0.load = load i8, ptr %v22_scratch.sink1350, align 1
  %v22.fca.1.load = load i8, ptr %v19.fca.1.gep132, align 1
  %v22.fca.2.load = load i8, ptr %v19.fca.2.gep134, align 1
  %v22.fca.3.load = load i8, ptr %v19.fca.3.gep136, align 1
  %v22.fca.4.load = load i8, ptr %v19.fca.4.gep138, align 1
  %v22.fca.5.load = load i8, ptr %v19.fca.5.gep140, align 1
  %v22.fca.6.load = load i8, ptr %v19.fca.6.gep142, align 1
  %v22.fca.7.load = load i8, ptr %v19.fca.7.gep144, align 1
  %v22.fca.8.load = load i8, ptr %v19.fca.8.gep146, align 1
  %v22.fca.9.load = load i8, ptr %v19.fca.9.gep148, align 1
  %v22.fca.10.load = load i8, ptr %v19.fca.10.gep150, align 1
  %v22.fca.11.load = load i8, ptr %v19.fca.11.gep152, align 1
  %v22.fca.12.load = load i8, ptr %v19.fca.12.gep154, align 1
  %v22.fca.13.load = load i8, ptr %v19.fca.13.gep156, align 1
  %v22.fca.14.load = load i8, ptr %v19.fca.14.gep158, align 1
  %v22.fca.15.load = load i8, ptr %v19.fca.15.gep160, align 1
  %v22.fca.16.load = load i8, ptr %v19.fca.16.gep162, align 1
  %v22.fca.17.load = load i8, ptr %v19.fca.17.gep164, align 1
  %v22.fca.18.load = load i8, ptr %v19.fca.18.gep166, align 1
  %v22.fca.19.load = load i8, ptr %v19.fca.19.gep168, align 1
  %v22.fca.20.load = load i8, ptr %v19.fca.20.gep170, align 1
  %v22.fca.21.load = load i8, ptr %v19.fca.21.gep172, align 1
  %v22.fca.22.load = load i8, ptr %v19.fca.22.gep174, align 1
  %v22.fca.23.load = load i8, ptr %v19.fca.23.gep176, align 1
  %v22.fca.24.load = load i8, ptr %v19.fca.24.gep178, align 1
  %v22.fca.25.load = load i8, ptr %v19.fca.25.gep180, align 1
  %v22.fca.26.load = load i8, ptr %v19.fca.26.gep182, align 1
  %v22.fca.27.load = load i8, ptr %v19.fca.27.gep184, align 1
  %v22.fca.28.load = load i8, ptr %v19.fca.28.gep186, align 1
  %v22.fca.29.load = load i8, ptr %v19.fca.29.gep188, align 1
  %v22.fca.30.load = load i8, ptr %v19.fca.30.gep190, align 1
  %v22.fca.31.load = load i8, ptr %v19.fca.31.gep192, align 1
  %v22.fca.32.load = load i8, ptr %v19.fca.32.gep194, align 1
  %v22.fca.33.load = load i8, ptr %v19.fca.33.gep196, align 1
  %v22.fca.34.load = load i8, ptr %v19.fca.34.gep198, align 1
  %v22.fca.35.load = load i8, ptr %v19.fca.35.gep200, align 1
  %v22.fca.36.load = load i8, ptr %v19.fca.36.gep202, align 1
  %v22.fca.37.load = load i8, ptr %v19.fca.37.gep204, align 1
  %v22.fca.38.load = load i8, ptr %v19.fca.38.gep206, align 1
  %v22.fca.39.load = load i8, ptr %v19.fca.39.gep208, align 1
  %v22.fca.40.load = load i8, ptr %v19.fca.40.gep210, align 1
  %v22.fca.41.load = load i8, ptr %v19.fca.41.gep212, align 1
  %v22.fca.42.load = load i8, ptr %v19.fca.42.gep214, align 1
  %v22.fca.43.load = load i8, ptr %v19.fca.43.gep216, align 1
  %v22.fca.44.load = load i8, ptr %v19.fca.44.gep218, align 1
  %v22.fca.45.load = load i8, ptr %v19.fca.45.gep220, align 1
  %v22.fca.46.load = load i8, ptr %v19.fca.46.gep222, align 1
  %v22.fca.47.load = load i8, ptr %v19.fca.47.gep224, align 1
  %v22.fca.48.load = load i8, ptr %v19.fca.48.gep226, align 1
  %v22.fca.49.load = load i8, ptr %v19.fca.49.gep228, align 1
  %v22.fca.50.load = load i8, ptr %v19.fca.50.gep230, align 1
  %v22.fca.51.load = load i8, ptr %v19.fca.51.gep232, align 1
  %v22.fca.52.load = load i8, ptr %v19.fca.52.gep234, align 1
  %v22.fca.53.load = load i8, ptr %v19.fca.53.gep236, align 1
  %v22.fca.54.load = load i8, ptr %v19.fca.54.gep238, align 1
  %v22.fca.55.load = load i8, ptr %v19.fca.55.gep240, align 1
  %v22.fca.56.load = load i8, ptr %v19.fca.56.gep242, align 1
  %v22.fca.57.load = load i8, ptr %v19.fca.57.gep244, align 1
  %v22.fca.58.load = load i8, ptr %v19.fca.58.gep246, align 1
  %v22.fca.59.load = load i8, ptr %v19.fca.59.gep248, align 1
  %v22.fca.60.load = load i8, ptr %v19.fca.60.gep250, align 1
  %v22.fca.61.load = load i8, ptr %v19.fca.61.gep252, align 1
  %v22.fca.62.load = load i8, ptr %v19.fca.62.gep254, align 1
  %v22.fca.63.load = load i8, ptr %v19.fca.63.gep256, align 1
  %v23_mem.sroa.130.sroa.0.0.copyload = load i32, ptr %v0_ptr, align 4
  %v23_mem.sroa.130.sroa.2.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx = getelementptr i8, ptr %p0, i64 124
  %1 = load i8, ptr %v23_mem.sroa.130.sroa.2.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx, align 4
  %v23_mem.sroa.130.sroa.3.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx = getelementptr i8, ptr %p0, i64 125
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %v29_mem.sroa.0, ptr noundef nonnull align 1 dereferenceable(56) %p0, i64 56, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v29_mem.sroa.131.sroa.4, ptr noundef nonnull align 1 dereferenceable(59) %v23_mem.sroa.130.sroa.3.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx, i64 59, i1 false)
  br label %b9
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i1 @liza___liza_json_space(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = icmp ult i8 %p0, 33
  %switch.cast = zext nneg i8 %p0 to i33
  %switch.downshift = lshr i33 -4294957568, %switch.cast
  %switch.masked = trunc i33 %switch.downshift to i1
  %v13 = select i1 %0, i1 %switch.masked, i1 false
  ret i1 %v13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i1 @liza___liza_json_digit(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = add i8 %p0, -48
  %v5 = icmp ult i8 %0, 10
  ret i1 %v5
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define range(i32 0, 17) i32 @liza___liza_json_hex(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = add i8 %p0, -48
  %v5 = icmp ult i8 %0, 10
  br i1 %v5, label %v6_ok, label %b6

v6_ok:                                            ; preds = %b0
  %v6 = zext nneg i8 %p0 to i32
  %v8_pair = add nsw i32 %v6, -48
  br label %common.ret

common.ret:                                       ; preds = %v24_ok, %v15_ok, %v6_ok, %b12
  %common.ret.op = phi i32 [ %v26_pair, %v24_ok ], [ %v8_pair, %v6_ok ], [ %v17_pair, %v15_ok ], [ 16, %b12 ]
  ret i32 %common.ret.op

b6:                                               ; preds = %b0
  %1 = add i8 %p0, -65
  %v14 = icmp ult i8 %1, 6
  br i1 %v14, label %v15_ok, label %b12

v15_ok:                                           ; preds = %b6
  %v15 = zext nneg i8 %p0 to i32
  %v17_pair = add nsw i32 %v15, -55
  br label %common.ret

b12:                                              ; preds = %b6
  %2 = add i8 %p0, -97
  %v23 = icmp ult i8 %2, 6
  br i1 %v23, label %v24_ok, label %common.ret

v24_ok:                                           ; preds = %b12
  %v24 = zext nneg i8 %p0 to i32
  %v26_pair = add nsw i32 %v24, -87
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define %variant.4 @liza_json.status(ptr nofree readonly captures(none) %p0) local_unnamed_addr #3 {
b0:
  %v0_ptr = getelementptr i8, ptr %p0, i64 168
  %v0 = load i32, ptr %v0_ptr, align 4
  %v2 = icmp eq i32 %v0, 0
  br i1 %v2, label %common.ret, label %b3

common.ret:                                       ; preds = %b0, %b3
  %common.ret.op = phi %variant.4 [ %v42, %b3 ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  ret %variant.4 %common.ret.op

b3:                                               ; preds = %b0
  %v7 = icmp eq i32 %v0, 2
  %v9 = select i1 %v7, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12 = icmp eq i32 %v0, 3
  %v14 = select i1 %v12, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9
  %v17 = icmp eq i32 %v0, 4
  %v19 = select i1 %v17, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14
  %v22 = icmp eq i32 %v0, 5
  %v24 = select i1 %v22, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19
  %v27 = icmp eq i32 %v0, 6
  %v29 = select i1 %v27, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24
  %v32 = icmp eq i32 %v0, 7
  %v34 = select i1 %v32, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29
  %v37 = icmp eq i32 %v0, 8
  %v39 = select i1 %v37, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34
  %v40_ptr = getelementptr i8, ptr %p0, i64 176
  %v40 = load i64, ptr %v40_ptr, align 8
  %v41_field0 = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39, 0
  %v41 = insertvalue %struct.JsonError %v41_field0, i64 %v40, 1
  %v42 = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41, 1
  br label %common.ret
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define %variant.5 @liza_json.finish(ptr nofree readonly captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v33_mem = alloca %struct.JsonState, align 8
  %v35_mem.sroa.5.sroa.0 = alloca i8, align 4
  %v0_ptr.i = getelementptr i8, ptr %p0, i64 168
  %v0.i = load i32, ptr %v0_ptr.i, align 4
  %v2.i = icmp eq i32 %v0.i, 0
  %p0.sink.sroa.gep = getelementptr inbounds nuw i8, ptr %p0, i64 160
  %p0.sink.sroa.gep29 = getelementptr inbounds nuw i8, ptr %v33_mem, i64 160
  br i1 %v2.i, label %liza_json.status.exit, label %b3.i

b3.i:                                             ; preds = %b0
  %v7.i = icmp eq i32 %v0.i, 2
  %v9.i = select i1 %v7.i, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12.i = icmp eq i32 %v0.i, 3
  %v14.i = select i1 %v12.i, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9.i
  %v17.i = icmp eq i32 %v0.i, 4
  %v19.i = select i1 %v17.i, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14.i
  %v22.i = icmp eq i32 %v0.i, 5
  %v24.i = select i1 %v22.i, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19.i
  %v27.i = icmp eq i32 %v0.i, 6
  %v29.i = select i1 %v27.i, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24.i
  %v32.i = icmp eq i32 %v0.i, 7
  %v34.i = select i1 %v32.i, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29.i
  %v37.i = icmp eq i32 %v0.i, 8
  %v39.i = select i1 %v37.i, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34.i
  %v40_ptr.i = getelementptr i8, ptr %p0, i64 176
  %v40.i = load i64, ptr %v40_ptr.i, align 8
  %v41_field0.i = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39.i, 0
  %v41.i = insertvalue %struct.JsonError %v41_field0.i, i64 %v40.i, 1
  %v42.i = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41.i, 1
  br label %liza_json.status.exit

liza_json.status.exit:                            ; preds = %b0, %b3.i
  %common.ret.op.i = phi %variant.4 [ %v42.i, %b3.i ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  %v1 = extractvalue %variant.4 %common.ret.op.i, 0
  %0 = icmp eq i32 %v1, 0
  br i1 %0, label %b2, label %b4

common.ret:                                       ; preds = %b38, %b36, %b27, %b7, %b2
  %common.ret.op = phi %variant.5 [ %v3, %b2 ], [ %v12, %b7 ], [ %v52, %b27 ], [ %v68, %b36 ], [ %v70, %b38 ]
  ret %variant.5 %common.ret.op

b2:                                               ; preds = %liza_json.status.exit
  %v2 = extractvalue %variant.4 %common.ret.op.i, 1
  %v3 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v2, 2
  br label %common.ret

b4:                                               ; preds = %liza_json.status.exit
  %v4 = load %struct.Utf8StreamState, ptr %p0, align 8
  %v0.i3 = extractvalue %struct.Utf8StreamState %v4, 6
  switch i32 %v0.i3, label %b6.i [
    i32 1, label %b1.i
    i32 2, label %b4.i
  ]

b1.i:                                             ; preds = %b4
  %v4.i = extractvalue %struct.Utf8StreamState %v4, 7
  %v5.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i, 1
  %v6.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5.i, 2
  br label %liza_utf8_stream.finish.exit

b4.i:                                             ; preds = %b4
  %v11.i = extractvalue %struct.Utf8StreamState %v4, 7
  %v12.i4 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i, 1
  %v13.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12.i4, 2
  br label %liza_utf8_stream.finish.exit

b6.i:                                             ; preds = %b4
  %v14.i6 = extractvalue %struct.Utf8StreamState %v4, 3
  %v16.not.i = icmp eq i32 %v14.i6, 0
  br i1 %v16.not.i, label %b9.i, label %b7.i

b7.i:                                             ; preds = %b6.i
  %v18.i = extractvalue %struct.Utf8StreamState %v4, 2
  %v19.i7 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18.i, 1
  %v20.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19.i7, 2
  br label %liza_utf8_stream.finish.exit

b9.i:                                             ; preds = %b6.i
  %v21.i = extractvalue %struct.Utf8StreamState %v4, 1
  %v22.i8 = insertvalue %variant.2 zeroinitializer, i64 %v21.i, 1
  br label %liza_utf8_stream.finish.exit

liza_utf8_stream.finish.exit:                     ; preds = %b1.i, %b4.i, %b7.i, %b9.i
  %common.ret.op.i5 = phi %variant.2 [ %v6.i, %b1.i ], [ %v13.i, %b4.i ], [ %v20.i, %b7.i ], [ %v22.i8, %b9.i ]
  %v6 = extractvalue %variant.2 %common.ret.op.i5, 0
  %1 = icmp eq i32 %v6, 0
  br i1 %1, label %b6, label %b7

b6:                                               ; preds = %liza_utf8_stream.finish.exit
  %v13_ptr = getelementptr i8, ptr %p0, i64 128
  %v13 = load i32, ptr %v13_ptr, align 8
  switch i32 %v13, label %b19_to_b20 [
    i32 11, label %b18
    i32 12, label %b18
    i32 14, label %b18
    i32 17, label %b18
  ]

b7:                                               ; preds = %liza_utf8_stream.finish.exit
  %v8 = extractvalue %variant.2 %common.ret.op.i5, 2
  %v10 = extractvalue %struct.Utf8StreamError %v8, 1
  %v11 = insertvalue %struct.JsonError { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v10, 1
  %v12 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v11, 2
  br label %common.ret

b18:                                              ; preds = %b6, %b6, %b6, %b6
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(184) %v33_mem, ptr noundef nonnull align 1 dereferenceable(184) %p0, i64 184, i1 false)
  %v33_part = getelementptr inbounds nuw i8, ptr %v33_mem, i64 128
  store i32 0, ptr %v33_part, align 8
  call void @liza___liza_owned___liza_json_done(ptr nonnull sret(%struct.JsonState) %v33_mem, ptr nonnull poison)
  %v35_next.sroa.4.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 48
  %v35_next.sroa.4.0.copyload = load i64, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx, align 8
  %v35_next.sroa.8.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 120
  %v35_next.sroa.8.0.copyload = load i32, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx, align 8
  %v35_next.sroa.10.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 124
  %2 = load i8, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx, align 4
  %v35_next.sroa.14.0.copyload = load i32, ptr %v33_part, align 8
  br label %b20

b20:                                              ; preds = %b19_to_b20, %b18
  %p0.sink.sroa.phi = phi ptr [ %p0.sink.sroa.gep, %b19_to_b20 ], [ %p0.sink.sroa.gep29, %b18 ]
  %storemerge = phi i8 [ %4, %b19_to_b20 ], [ %2, %b18 ]
  %v35_mem.sroa.617.0 = phi i32 [ %v13, %b19_to_b20 ], [ %v35_next.sroa.14.0.copyload, %b18 ]
  %v35_mem.sroa.412.0 = phi i32 [ %v35_next.sroa.8.0.copyload26, %b19_to_b20 ], [ %v35_next.sroa.8.0.copyload, %b18 ]
  %v35_mem.sroa.2.0 = phi i64 [ %v35_next.sroa.4.0.copyload25, %b19_to_b20 ], [ %v35_next.sroa.4.0.copyload, %b18 ]
  %v35_next.sroa.18.0.copyload28 = load i64, ptr %p0.sink.sroa.phi, align 8
  store i8 %storemerge, ptr %v35_mem.sroa.5.sroa.0, align 4
  %3 = add i32 %v35_mem.sroa.617.0, -4
  %or.cond = icmp ult i32 %3, 3
  br i1 %or.cond, label %b27, label %b29

b27:                                              ; preds = %b20
  %v51 = insertvalue %struct.JsonError { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_next.sroa.18.0.copyload28, 1
  %v52 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v51, 2
  br label %common.ret

b29:                                              ; preds = %b20
  %v55 = icmp eq i32 %v35_mem.sroa.617.0, 0
  %v59 = icmp eq i32 %v35_mem.sroa.412.0, 0
  %v60.not2 = select i1 %v55, i1 %v59, i1 false
  %v35_mem.sroa.5.sroa.0.0.v35_mem.sroa.5.sroa.0.0.v35_mem.sroa.5.sroa.0.0.v35_mem.sroa.5.0.v35_mem.sroa.5.0.v35_mem.sroa.5.124.v35_mem.124.v62 = load i1, ptr %v35_mem.sroa.5.sroa.0, align 4
  %or.cond1.not = select i1 %v60.not2, i1 %v35_mem.sroa.5.sroa.0.0.v35_mem.sroa.5.sroa.0.0.v35_mem.sroa.5.sroa.0.0.v35_mem.sroa.5.0.v35_mem.sroa.5.0.v35_mem.sroa.5.124.v35_mem.124.v62, i1 false
  br i1 %or.cond1.not, label %b38, label %b36

b36:                                              ; preds = %b29
  %v67 = insertvalue %struct.JsonError { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.2.0, 1
  %v68 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v67, 2
  br label %common.ret

b38:                                              ; preds = %b29
  %v70 = insertvalue %variant.5 zeroinitializer, i64 %v35_mem.sroa.2.0, 1
  br label %common.ret

b19_to_b20:                                       ; preds = %b6
  %v35_next.sroa.4.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 48
  %v35_next.sroa.4.0.copyload25 = load i64, ptr %v35_next.sroa.4.0.p0.sroa_idx, align 8
  %v35_next.sroa.8.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 120
  %v35_next.sroa.8.0.copyload26 = load i32, ptr %v35_next.sroa.8.0.p0.sroa_idx, align 8
  %v35_next.sroa.10.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 124
  %4 = load i8, ptr %v35_next.sroa.10.0.p0.sroa_idx, align 4
  br label %b20
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define i32 @liza___liza_json_mut_fail(i32 returned %p0, i64 %p1, ptr nofree writeonly captures(none) initializes((168, 172), (176, 184)) %p2) local_unnamed_addr #4 {
b0:
  %v0 = getelementptr i8, ptr %p2, i64 168
  store i32 %p0, ptr %v0, align 4
  %v2 = getelementptr i8, ptr %p2, i64 176
  store i64 %p1, ptr %v2, align 8
  ret i32 %p0
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i32 @liza___liza_json_mut_done(ptr nofree captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v0 = getelementptr i8, ptr %p0, i64 120
  %v1 = load i32, ptr %v0, align 4
  %v3 = icmp eq i32 %v1, 0
  br i1 %v3, label %b1, label %b2

b1:                                               ; preds = %b0
  %v4 = getelementptr i8, ptr %p0, i64 124
  store i1 true, ptr %v4, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v10_pair = add i32 %v1, -1
  %v12_invalid = icmp ugt i32 %v10_pair, 63
  br i1 %v12_invalid, label %v12_trap, label %v12_ok

v12_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v12_ok:                                           ; preds = %b2
  %v11 = getelementptr i8, ptr %p0, i64 56
  %v12_offset = zext nneg i32 %v10_pair to i64
  %v12 = getelementptr i8, ptr %v11, i64 %v12_offset
  %v13 = load i8, ptr %v12, align 1
  switch i8 %v13, label %v28_ok [
    i8 1, label %v24_ok
    i8 3, label %v24_ok
  ]

v24_ok:                                           ; preds = %v12_ok, %v12_ok
  store i8 2, ptr %v12, align 1
  br label %b9

v28_ok:                                           ; preds = %v12_ok
  store i8 7, ptr %v12, align 1
  br label %b9

b9:                                               ; preds = %v24_ok, %v28_ok, %b1
  %v31 = getelementptr i8, ptr %p0, i64 168
  %v32 = load i32, ptr %v31, align 4
  ret i32 %v32
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i32 @liza___liza_json_mut_step(i8 %p0, ptr nofree %p1) local_unnamed_addr #2 {
b0:
  %v0 = getelementptr i8, ptr %p1, i64 128
  %v1 = load i32, ptr %v0, align 4
  switch i32 %v1, label %b132 [
    i32 1, label %b1
    i32 2, label %b16
    i32 4, label %b46
    i32 5, label %b52
    i32 3, label %b61
    i32 6, label %b61
    i32 20, label %b91
  ]

b1:                                               ; preds = %b0
  %v5 = icmp ult i8 %p0, 32
  br i1 %v5, label %b3, label %b5

common.ret:                                       ; preds = %b312, %b304, %b292, %b289, %b286, %v691_ok, %b279, %b271, %b266, %b264, %v613_ok, %b255, %b251, %b246, %v560_ok, %v542_ok, %b217, %b210, %b201, %b189, %b180, %b165, %b157, %b140, %b131, %liza___liza_json_mut_done.exit, %b126, %b89, %b86, %b80, %b75, %b73, %b63, %b56, %b54, %b50, %b48, %b44, %b42, %b39, %b14, %b10, %v24_ok, %b3
  %common.ret.op = phi i32 [ 1, %b3 ], [ %v28, %v24_ok ], [ %v30, %b10 ], [ %v42, %b14 ], [ %v81, %b39 ], [ %v94, %b42 ], [ 3, %b44 ], [ 4, %b48 ], [ %v117, %b50 ], [ 4, %b54 ], [ %v140, %b56 ], [ 3, %b63 ], [ 4, %b73 ], [ %v201, %b75 ], [ %v220, %b80 ], [ 4, %b86 ], [ %v241, %b89 ], [ 1, %b126 ], [ %v32.i, %liza___liza_json_mut_done.exit ], [ %v337, %b131 ], [ 2, %b140 ], [ %v392, %b157 ], [ %v411, %b165 ], [ %v440, %b180 ], [ %v457, %b189 ], [ 2, %b201 ], [ 2, %b210 ], [ %v514, %b217 ], [ %v545, %v542_ok ], [ %v563, %v560_ok ], [ 1, %b246 ], [ %v597, %b251 ], [ 1, %b255 ], [ %v617, %v613_ok ], [ 1, %b264 ], [ %v639, %b266 ], [ 1, %b271 ], [ 7, %b279 ], [ %v694, %v691_ok ], [ %v704, %b286 ], [ %v711, %b289 ], [ %v722, %b292 ], [ %v753, %b304 ], [ 1, %b312 ]
  ret i32 %common.ret.op

b3:                                               ; preds = %b1
  %v7 = getelementptr i8, ptr %p1, i64 48
  %v8 = load i64, ptr %v7, align 8
  %v0.i = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i, align 8
  %v2.i = getelementptr i8, ptr %p1, i64 176
  store i64 %v8, ptr %v2.i, align 8
  br label %common.ret

b5:                                               ; preds = %b1
  switch i8 %p0, label %b14 [
    i8 34, label %b6
    i8 92, label %b12
  ]

b6:                                               ; preds = %b5
  store i32 0, ptr %v0, align 4
  %v17 = getelementptr i8, ptr %p1, i64 132
  %v18 = load i1, ptr %v17, align 4
  br i1 %v18, label %b8, label %b10

b8:                                               ; preds = %b6
  %v19 = getelementptr i8, ptr %p1, i64 56
  %v20 = getelementptr i8, ptr %p1, i64 120
  %v21 = load i32, ptr %v20, align 4
  %v23_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v21, i32 1)
  %v23 = extractvalue { i32, i1 } %v23_pair, 0
  %v23_overflow = extractvalue { i32, i1 } %v23_pair, 1
  br i1 %v23_overflow, label %v23_trap, label %v23_ok

v23_trap:                                         ; preds = %b8
  tail call void @llvm.trap()
  unreachable

v23_ok:                                           ; preds = %b8
  %v24_invalid = icmp ugt i32 %v23, 63
  br i1 %v24_invalid, label %v24_trap, label %v24_ok

v24_trap:                                         ; preds = %v23_ok
  tail call void @llvm.trap()
  unreachable

v24_ok:                                           ; preds = %v23_ok
  %v24_offset = zext nneg i32 %v23 to i64
  %v24 = getelementptr i8, ptr %v19, i64 %v24_offset
  store i8 5, ptr %v24, align 1
  %v27 = getelementptr i8, ptr %p1, i64 168
  %v28 = load i32, ptr %v27, align 4
  br label %common.ret

b10:                                              ; preds = %b6
  %v30 = tail call i32 @liza___liza_json_mut_done(ptr %p1)
  br label %common.ret

b12:                                              ; preds = %b5
  store i32 2, ptr %v0, align 4
  %v37 = getelementptr i8, ptr %p1, i64 152
  %v38 = getelementptr i8, ptr %p1, i64 48
  %v39 = load i64, ptr %v38, align 8
  store i64 %v39, ptr %v37, align 8
  br label %b14

b14:                                              ; preds = %b5, %b12
  %v41 = getelementptr i8, ptr %p1, i64 168
  %v42 = load i32, ptr %v41, align 4
  br label %common.ret

b16:                                              ; preds = %b0
  switch i8 %p0, label %b44 [
    i8 114, label %b39
    i8 110, label %b39
    i8 102, label %b39
    i8 98, label %b39
    i8 92, label %b39
    i8 47, label %b39
    i8 34, label %b39
    i8 116, label %b39
    i8 117, label %b42
  ]

b39:                                              ; preds = %b16, %b16, %b16, %b16, %b16, %b16, %b16, %b16
  store i32 1, ptr %v0, align 4
  %v80 = getelementptr i8, ptr %p1, i64 168
  %v81 = load i32, ptr %v80, align 4
  br label %common.ret

b42:                                              ; preds = %b16
  store i32 3, ptr %v0, align 4
  %v87 = getelementptr i8, ptr %p1, i64 144
  store i32 0, ptr %v87, align 4
  %v90 = getelementptr i8, ptr %p1, i64 148
  store i32 0, ptr %v90, align 4
  %v93 = getelementptr i8, ptr %p1, i64 168
  %v94 = load i32, ptr %v93, align 4
  br label %common.ret

b44:                                              ; preds = %b16
  %v96 = getelementptr i8, ptr %p1, i64 48
  %v97 = load i64, ptr %v96, align 8
  %v0.i12 = getelementptr i8, ptr %p1, i64 168
  store i32 3, ptr %v0.i12, align 8
  %v2.i13 = getelementptr i8, ptr %p1, i64 176
  store i64 %v97, ptr %v2.i13, align 8
  br label %common.ret

b46:                                              ; preds = %b0
  %v106.not = icmp eq i8 %p0, 92
  br i1 %v106.not, label %b50, label %b48

b48:                                              ; preds = %b46
  %v108 = getelementptr i8, ptr %p1, i64 160
  %v109 = load i64, ptr %v108, align 8
  %v0.i14 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i14, align 8
  %v2.i15 = getelementptr i8, ptr %p1, i64 176
  store i64 %v109, ptr %v2.i15, align 8
  br label %common.ret

b50:                                              ; preds = %b46
  store i32 5, ptr %v0, align 4
  %v116 = getelementptr i8, ptr %p1, i64 168
  %v117 = load i32, ptr %v116, align 4
  br label %common.ret

b52:                                              ; preds = %b0
  %v123.not = icmp eq i8 %p0, 117
  br i1 %v123.not, label %b56, label %b54

b54:                                              ; preds = %b52
  %v125 = getelementptr i8, ptr %p1, i64 160
  %v126 = load i64, ptr %v125, align 8
  %v0.i16 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i16, align 8
  %v2.i17 = getelementptr i8, ptr %p1, i64 176
  store i64 %v126, ptr %v2.i17, align 8
  br label %common.ret

b56:                                              ; preds = %b52
  store i32 6, ptr %v0, align 4
  %v133 = getelementptr i8, ptr %p1, i64 144
  store i32 0, ptr %v133, align 4
  %v136 = getelementptr i8, ptr %p1, i64 148
  store i32 0, ptr %v136, align 4
  %v139 = getelementptr i8, ptr %p1, i64 168
  %v140 = load i32, ptr %v139, align 4
  br label %common.ret

b61:                                              ; preds = %b0, %b0
  %0 = add i8 %p0, -48
  %v5.i = icmp ult i8 %0, 10
  br i1 %v5.i, label %v6_ok.i, label %b6.i

v6_ok.i:                                          ; preds = %b61
  %v6.i = zext nneg i8 %p0 to i32
  %v8_pair.i = add nsw i32 %v6.i, -48
  br label %liza___liza_json_hex.exit

b6.i:                                             ; preds = %b61
  %1 = add i8 %p0, -65
  %v14.i = icmp ult i8 %1, 6
  br i1 %v14.i, label %v15_ok.i, label %b12.i

v15_ok.i:                                         ; preds = %b6.i
  %v15.i = zext nneg i8 %p0 to i32
  %v17_pair.i = add nsw i32 %v15.i, -55
  br label %liza___liza_json_hex.exit

b12.i:                                            ; preds = %b6.i
  %2 = add i8 %p0, -97
  %v23.i = icmp ult i8 %2, 6
  br i1 %v23.i, label %v24_ok.i, label %liza___liza_json_hex.exit

v24_ok.i:                                         ; preds = %b12.i
  %v24.i = zext nneg i8 %p0 to i32
  %v26_pair.i = add nsw i32 %v24.i, -87
  br label %liza___liza_json_hex.exit

liza___liza_json_hex.exit:                        ; preds = %v6_ok.i, %v15_ok.i, %b12.i, %v24_ok.i
  %common.ret.op.i = phi i32 [ %v26_pair.i, %v24_ok.i ], [ %v8_pair.i, %v6_ok.i ], [ %v17_pair.i, %v15_ok.i ], [ 16, %b12.i ]
  %v153 = icmp eq i32 %common.ret.op.i, 16
  br i1 %v153, label %b63, label %b65

b63:                                              ; preds = %liza___liza_json_hex.exit
  %v155 = getelementptr i8, ptr %p1, i64 48
  %v156 = load i64, ptr %v155, align 8
  %v0.i18 = getelementptr i8, ptr %p1, i64 168
  store i32 3, ptr %v0.i18, align 8
  %v2.i19 = getelementptr i8, ptr %p1, i64 176
  store i64 %v156, ptr %v2.i19, align 8
  br label %common.ret

b65:                                              ; preds = %liza___liza_json_hex.exit
  %v160 = getelementptr i8, ptr %p1, i64 148
  %v162 = load i32, ptr %v160, align 4
  %v164_overflow = icmp ugt i32 %v162, 268435455
  br i1 %v164_overflow, label %v164_trap, label %v164_ok

v164_trap:                                        ; preds = %b65
  tail call void @llvm.trap()
  unreachable

v164_ok:                                          ; preds = %b65
  %v164 = shl nuw i32 %v162, 4
  %v165_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v164, i32 %common.ret.op.i)
  %v165_overflow = extractvalue { i32, i1 } %v165_pair, 1
  br i1 %v165_overflow, label %v165_trap, label %v165_ok

v165_trap:                                        ; preds = %v164_ok
  tail call void @llvm.trap()
  unreachable

v165_ok:                                          ; preds = %v164_ok
  %v165 = extractvalue { i32, i1 } %v165_pair, 0
  store i32 %v165, ptr %v160, align 4
  %v167 = getelementptr i8, ptr %p1, i64 144
  %v169 = load i32, ptr %v167, align 4
  %v171_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v169, i32 1)
  %v171_overflow = extractvalue { i32, i1 } %v171_pair, 1
  br i1 %v171_overflow, label %v171_trap, label %v171_ok

v171_trap:                                        ; preds = %v165_ok
  tail call void @llvm.trap()
  unreachable

v171_ok:                                          ; preds = %v165_ok
  %v171 = extractvalue { i32, i1 } %v171_pair, 0
  store i32 %v171, ptr %v167, align 4
  %v176 = icmp eq i32 %v171, 4
  br i1 %v176, label %b66, label %b89

b66:                                              ; preds = %v171_ok
  %v180 = icmp eq i32 %v1, 6
  br i1 %v180, label %b68, label %b76

b68:                                              ; preds = %b66
  %3 = add i32 %v165, -57344
  %or.cond = icmp ult i32 %3, -1024
  br i1 %or.cond, label %b73, label %b75

b73:                                              ; preds = %b68
  %v192 = getelementptr i8, ptr %p1, i64 160
  %v193 = load i64, ptr %v192, align 8
  %v0.i20 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i20, align 8
  %v2.i21 = getelementptr i8, ptr %p1, i64 176
  store i64 %v193, ptr %v2.i21, align 8
  br label %common.ret

b75:                                              ; preds = %b68
  store i32 1, ptr %v0, align 4
  %v200 = getelementptr i8, ptr %p1, i64 168
  %v201 = load i32, ptr %v200, align 4
  br label %common.ret

b76:                                              ; preds = %b66
  %4 = and i32 %v165, -1024
  %or.cond8 = icmp eq i32 %4, 55296
  br i1 %or.cond8, label %b80, label %b82

b80:                                              ; preds = %b76
  store i32 4, ptr %v0, align 4
  %v215 = getelementptr i8, ptr %p1, i64 160
  %v216 = getelementptr i8, ptr %p1, i64 152
  %v217 = load i64, ptr %v216, align 8
  store i64 %v217, ptr %v215, align 8
  %v219 = getelementptr i8, ptr %p1, i64 168
  %v220 = load i32, ptr %v219, align 8
  br label %common.ret

b82:                                              ; preds = %b76
  %5 = and i32 %v165, -1024
  %or.cond9 = icmp eq i32 %5, 56320
  br i1 %or.cond9, label %b86, label %b88

b86:                                              ; preds = %b82
  %v232 = getelementptr i8, ptr %p1, i64 152
  %v233 = load i64, ptr %v232, align 8
  %v0.i22 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i22, align 8
  %v2.i23 = getelementptr i8, ptr %p1, i64 176
  store i64 %v233, ptr %v2.i23, align 8
  br label %common.ret

b88:                                              ; preds = %b82
  store i32 1, ptr %v0, align 4
  br label %b89

b89:                                              ; preds = %v171_ok, %b88
  %v240 = getelementptr i8, ptr %p1, i64 168
  %v241 = load i32, ptr %v240, align 4
  br label %common.ret

b91:                                              ; preds = %b0
  %v248 = getelementptr i8, ptr %p1, i64 136
  %v249 = load i32, ptr %v248, align 4
  %v251 = icmp eq i32 %v249, 1
  br i1 %v251, label %b93, label %b104

b93:                                              ; preds = %b91
  %v252 = getelementptr i8, ptr %p1, i64 140
  %v253 = load i32, ptr %v252, align 4
  %v255 = icmp eq i32 %v253, 1
  %. = select i1 %v255, i8 114, i8 0
  %v261 = icmp eq i32 %v253, 2
  %v263 = select i1 %v261, i8 117, i8 %.
  %v267 = icmp eq i32 %v253, 3
  %v269 = select i1 %v267, i8 101, i8 %v263
  br label %b104

b104:                                             ; preds = %b91, %b93
  %v270 = phi i8 [ %v269, %b93 ], [ 0, %b91 ]
  %v274 = icmp eq i32 %v249, 2
  br i1 %v274, label %b105, label %b119

b105:                                             ; preds = %b104
  %v276 = getelementptr i8, ptr %p1, i64 140
  %v277 = load i32, ptr %v276, align 4
  %v279 = icmp eq i32 %v277, 1
  %.v270 = select i1 %v279, i8 97, i8 %v270
  %v285 = icmp eq i32 %v277, 2
  %v287 = select i1 %v285, i8 108, i8 %.v270
  %v291 = icmp eq i32 %v277, 3
  %v293 = select i1 %v291, i8 115, i8 %v287
  %v297 = icmp eq i32 %v277, 4
  %v299 = select i1 %v297, i8 101, i8 %v293
  br label %b119

b119:                                             ; preds = %b104, %b105
  %v300 = phi i8 [ %v299, %b105 ], [ %v270, %b104 ]
  %v301 = phi i32 [ 5, %b105 ], [ 4, %b104 ]
  %v305 = icmp eq i32 %v249, 3
  br i1 %v305, label %b120, label %b125

b120:                                             ; preds = %b119
  %v306 = getelementptr i8, ptr %p1, i64 140
  %v307 = load i32, ptr %v306, align 4
  %v309 = icmp eq i32 %v307, 1
  %.1 = select i1 %v309, i8 117, i8 108
  br label %b125

b125:                                             ; preds = %b119, %b120
  %v313 = phi i8 [ %.1, %b120 ], [ %v300, %b119 ]
  %v314.not = icmp eq i8 %p0, %v313
  br i1 %v314.not, label %b128, label %b126

b126:                                             ; preds = %b125
  %v316 = getelementptr i8, ptr %p1, i64 48
  %v317 = load i64, ptr %v316, align 8
  %v0.i24 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i24, align 8
  %v2.i25 = getelementptr i8, ptr %p1, i64 176
  store i64 %v317, ptr %v2.i25, align 8
  br label %common.ret

b128:                                             ; preds = %b125
  %v321 = getelementptr i8, ptr %p1, i64 140
  %v323 = load i32, ptr %v321, align 4
  %v325_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v323, i32 1)
  %v325_overflow = extractvalue { i32, i1 } %v325_pair, 1
  br i1 %v325_overflow, label %v325_trap, label %v325_ok

v325_trap:                                        ; preds = %b128
  tail call void @llvm.trap()
  unreachable

v325_ok:                                          ; preds = %b128
  %v325 = extractvalue { i32, i1 } %v325_pair, 0
  store i32 %v325, ptr %v321, align 4
  %v329 = icmp eq i32 %v325, %v301
  br i1 %v329, label %b129, label %b131

b129:                                             ; preds = %v325_ok
  store i32 0, ptr %v0, align 4
  %v0.i26 = getelementptr i8, ptr %p1, i64 120
  %v1.i = load i32, ptr %v0.i26, align 4
  %v3.i = icmp eq i32 %v1.i, 0
  br i1 %v3.i, label %b1.i, label %b2.i

b1.i:                                             ; preds = %b129
  %v4.i = getelementptr i8, ptr %p1, i64 124
  store i1 true, ptr %v4.i, align 4
  br label %liza___liza_json_mut_done.exit

b2.i:                                             ; preds = %b129
  %v10_pair.i = add i32 %v1.i, -1
  %v12_invalid.i = icmp ugt i32 %v10_pair.i, 63
  br i1 %v12_invalid.i, label %v12_trap.i, label %v12_ok.i

v12_trap.i:                                       ; preds = %b2.i
  tail call void @llvm.trap()
  unreachable

v12_ok.i:                                         ; preds = %b2.i
  %v11.i = getelementptr i8, ptr %p1, i64 56
  %v12_offset.i = zext nneg i32 %v10_pair.i to i64
  %v12.i = getelementptr i8, ptr %v11.i, i64 %v12_offset.i
  %v13.i = load i8, ptr %v12.i, align 1
  switch i8 %v13.i, label %v28_ok.i [
    i8 1, label %v24_ok.i27
    i8 3, label %v24_ok.i27
  ]

v24_ok.i27:                                       ; preds = %v12_ok.i, %v12_ok.i
  store i8 2, ptr %v12.i, align 1
  br label %liza___liza_json_mut_done.exit

v28_ok.i:                                         ; preds = %v12_ok.i
  store i8 7, ptr %v12.i, align 1
  br label %liza___liza_json_mut_done.exit

liza___liza_json_mut_done.exit:                   ; preds = %b1.i, %v24_ok.i27, %v28_ok.i
  %v31.i = getelementptr i8, ptr %p1, i64 168
  %v32.i = load i32, ptr %v31.i, align 4
  br label %common.ret

b131:                                             ; preds = %v325_ok
  %v336 = getelementptr i8, ptr %p1, i64 168
  %v337 = load i32, ptr %v336, align 4
  br label %common.ret

b132:                                             ; preds = %b0
  %6 = add i32 %v1, -10
  %or.cond10 = icmp ult i32 %6, 8
  br i1 %or.cond10, label %b136, label %b216

b136:                                             ; preds = %b132
  %7 = add i8 %p0, -48
  %v5.i28 = icmp ult i8 %7, 10
  br i1 %v5.i28, label %b138, label %b158

b138:                                             ; preds = %b136
  switch i32 %v1, label %b148 [
    i32 11, label %b140
    i32 10, label %b143
  ]

b140:                                             ; preds = %b138
  %v354 = getelementptr i8, ptr %p1, i64 48
  %v355 = load i64, ptr %v354, align 8
  %v0.i29 = getelementptr i8, ptr %p1, i64 168
  store i32 2, ptr %v0.i29, align 8
  %v2.i30 = getelementptr i8, ptr %p1, i64 176
  store i64 %v355, ptr %v2.i30, align 8
  br label %common.ret

b143:                                             ; preds = %b138
  %v364 = icmp eq i8 %p0, 48
  %.55 = select i1 %v364, i32 11, i32 12
  store i32 %.55, ptr %v0, align 4
  br label %b148

b148:                                             ; preds = %b143, %b138
  %v372 = load i32, ptr %v0, align 4
  %v374 = icmp eq i32 %v372, 13
  br i1 %v374, label %b149, label %b151

b149:                                             ; preds = %b148
  store i32 14, ptr %v0, align 4
  br label %b151

b151:                                             ; preds = %b148, %b149
  %v379 = load i32, ptr %v0, align 4
  %v379.off = add i32 %v379, -15
  %switch = icmp ult i32 %v379.off, 2
  br i1 %switch, label %b155, label %b157

b155:                                             ; preds = %b151
  store i32 17, ptr %v0, align 4
  br label %b157

b157:                                             ; preds = %b151, %b155
  %v391 = getelementptr i8, ptr %p1, i64 168
  %v392 = load i32, ptr %v391, align 4
  br label %common.ret

b158:                                             ; preds = %b136
  %v396 = icmp eq i32 %v1, 11
  br i1 %v396, label %b162, label %b159

b159:                                             ; preds = %b158
  %v401 = icmp eq i32 %v1, 12
  %v405 = icmp eq i8 %p0, 46
  %or.cond6 = select i1 %v401, i1 %v405, i1 false
  br i1 %or.cond6, label %b165, label %b167

b162:                                             ; preds = %b158
  %v405.old = icmp eq i8 %p0, 46
  br i1 %v405.old, label %b165, label %b167

b165:                                             ; preds = %b159, %b162
  store i32 13, ptr %v0, align 4
  %v410 = getelementptr i8, ptr %p1, i64 168
  %v411 = load i32, ptr %v410, align 4
  br label %common.ret

b167:                                             ; preds = %b162, %b159
  switch i32 %v1, label %b203 [
    i32 11, label %b174
    i32 12, label %b174
    i32 14, label %b174
    i32 15, label %b183
    i32 10, label %b201
    i32 13, label %b201
    i32 16, label %b201
  ]

b174:                                             ; preds = %b167, %b167, %b167
  switch i8 %p0, label %b182 [
    i8 101, label %b180
    i8 69, label %b180
  ]

b180:                                             ; preds = %b174, %b174
  store i32 15, ptr %v0, align 4
  %v439 = getelementptr i8, ptr %p1, i64 168
  %v440 = load i32, ptr %v439, align 4
  br label %common.ret

b182:                                             ; preds = %b174
  switch i32 %v1, label %b203 [
    i32 15, label %b183
    i32 10, label %b201
    i32 13, label %b201
    i32 16, label %b201
  ]

b183:                                             ; preds = %b167, %b182
  switch i8 %p0, label %b191 [
    i8 45, label %b189
    i8 43, label %b189
  ]

b189:                                             ; preds = %b183, %b183
  store i32 16, ptr %v0, align 4
  %v456 = getelementptr i8, ptr %p1, i64 168
  %v457 = load i32, ptr %v456, align 4
  br label %common.ret

b191:                                             ; preds = %b183
  switch i32 %v1, label %b203 [
    i32 10, label %b201
    i32 13, label %b201
    i32 15, label %b201
    i32 16, label %b201
  ]

b201:                                             ; preds = %b167, %b167, %b167, %b182, %b182, %b182, %b191, %b191, %b191, %b191
  %v481 = getelementptr i8, ptr %p1, i64 48
  %v482 = load i64, ptr %v481, align 8
  %v0.i31 = getelementptr i8, ptr %p1, i64 168
  store i32 2, ptr %v0.i31, align 8
  %v2.i32 = getelementptr i8, ptr %p1, i64 176
  store i64 %v482, ptr %v2.i32, align 8
  br label %common.ret

b203:                                             ; preds = %b167, %b182, %b191
  switch i8 %p0, label %b210 [
    i8 32, label %b215
    i8 10, label %b215
    i8 9, label %b215
    i8 13, label %b215
    i8 93, label %b215
    i8 44, label %b215
    i8 125, label %b215
  ]

b210:                                             ; preds = %b203
  %v501 = getelementptr i8, ptr %p1, i64 48
  %v502 = load i64, ptr %v501, align 8
  %v0.i34 = getelementptr i8, ptr %p1, i64 168
  store i32 2, ptr %v0.i34, align 8
  %v2.i35 = getelementptr i8, ptr %p1, i64 176
  store i64 %v502, ptr %v2.i35, align 8
  br label %common.ret

b215:                                             ; preds = %b203, %b203, %b203, %b203, %b203, %b203, %b203
  store i32 0, ptr %v0, align 4
  %v510 = tail call i32 @liza___liza_json_mut_done(ptr %p1)
  br label %b216

b216:                                             ; preds = %b132, %b215
  switch i8 %p0, label %b7.i37 [
    i8 32, label %b217
    i8 10, label %b217
    i8 9, label %b217
    i8 13, label %b217
  ]

b7.i37:                                           ; preds = %b216
  %v516 = getelementptr i8, ptr %p1, i64 120
  %v517 = load i32, ptr %v516, align 4
  %v519.not = icmp eq i32 %v517, 0
  br i1 %v519.not, label %b222, label %b220

b217:                                             ; preds = %b216, %b216, %b216, %b216
  %v513 = getelementptr i8, ptr %p1, i64 168
  %v514 = load i32, ptr %v513, align 4
  br label %common.ret

b220:                                             ; preds = %b7.i37
  %v524_pair = add i32 %v517, -1
  %v525_invalid = icmp ugt i32 %v524_pair, 63
  br i1 %v525_invalid, label %v525_trap, label %v525_ok

v525_trap:                                        ; preds = %b220
  tail call void @llvm.trap()
  unreachable

v525_ok:                                          ; preds = %b220
  %v520 = getelementptr i8, ptr %p1, i64 56
  %v525_offset = zext nneg i32 %v524_pair to i64
  %v525 = getelementptr i8, ptr %v520, i64 %v525_offset
  %v526 = load i8, ptr %v525, align 1
  br label %b222

b222:                                             ; preds = %b7.i37, %v525_ok
  %v527 = phi i8 [ %v526, %v525_ok ], [ 0, %b7.i37 ]
  switch i8 %p0, label %b240 [
    i8 93, label %b223
    i8 125, label %b232
  ]

b223:                                             ; preds = %b222
  %8 = add i8 %v527, -1
  %9 = icmp ult i8 %8, 2
  br i1 %9, label %b229, label %b240

b229:                                             ; preds = %b223
  %v542_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v542_overflow = extractvalue { i32, i1 } %v542_pair, 1
  br i1 %v542_overflow, label %v542_trap, label %v542_ok

v542_trap:                                        ; preds = %b229
  tail call void @llvm.trap()
  unreachable

v542_ok:                                          ; preds = %b229
  %v542 = extractvalue { i32, i1 } %v542_pair, 0
  store i32 %v542, ptr %v516, align 4
  %v544 = getelementptr i8, ptr %p1, i64 168
  %v545 = load i32, ptr %v544, align 4
  br label %common.ret

b232:                                             ; preds = %b222
  switch i8 %v527, label %b259 [
    i8 7, label %b238
    i8 4, label %b238
    i8 2, label %b244
    i8 5, label %b253
    i8 8, label %b262.critedge
  ]

b238:                                             ; preds = %b232, %b232
  %v560_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v560_overflow = extractvalue { i32, i1 } %v560_pair, 1
  br i1 %v560_overflow, label %v560_trap, label %v560_ok

v560_trap:                                        ; preds = %b238
  tail call void @llvm.trap()
  unreachable

v560_ok:                                          ; preds = %b238
  %v560 = extractvalue { i32, i1 } %v560_pair, 0
  store i32 %v560, ptr %v516, align 4
  %v562 = getelementptr i8, ptr %p1, i64 168
  %v563 = load i32, ptr %v562, align 4
  br label %common.ret

b240:                                             ; preds = %b223, %b222
  switch i8 %v527, label %b259 [
    i8 7, label %b244
    i8 2, label %b244
    i8 5, label %b253
    i8 4, label %b262.critedge
    i8 8, label %b262.critedge
  ]

b244:                                             ; preds = %b232, %b240, %b240
  %v571.not = icmp eq i8 %p0, 44
  br i1 %v571.not, label %b248, label %b246

b246:                                             ; preds = %b244
  %v573 = getelementptr i8, ptr %p1, i64 48
  %v574 = load i64, ptr %v573, align 8
  %v0.i39 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i39, align 8
  %v2.i40 = getelementptr i8, ptr %p1, i64 176
  store i64 %v574, ptr %v2.i40, align 8
  br label %common.ret

b248:                                             ; preds = %b244
  %v579 = icmp eq i8 %v527, 2
  %v580 = getelementptr i8, ptr %p1, i64 56
  %v584_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v584 = extractvalue { i32, i1 } %v584_pair, 0
  %v584_overflow = extractvalue { i32, i1 } %v584_pair, 1
  br i1 %v579, label %b249, label %b250

b249:                                             ; preds = %b248
  br i1 %v584_overflow, label %v584_trap, label %v584_ok

v584_trap:                                        ; preds = %b249
  tail call void @llvm.trap()
  unreachable

v584_ok:                                          ; preds = %b249
  %v585_invalid = icmp ugt i32 %v584, 63
  br i1 %v585_invalid, label %v585_trap, label %b251

v585_trap:                                        ; preds = %v584_ok
  tail call void @llvm.trap()
  unreachable

b250:                                             ; preds = %b248
  br i1 %v584_overflow, label %v592_trap, label %v592_ok

v592_trap:                                        ; preds = %b250
  tail call void @llvm.trap()
  unreachable

v592_ok:                                          ; preds = %b250
  %v593_invalid = icmp ugt i32 %v584, 63
  br i1 %v593_invalid, label %v593_trap, label %b251

v593_trap:                                        ; preds = %v592_ok
  tail call void @llvm.trap()
  unreachable

b251:                                             ; preds = %v592_ok, %v584_ok
  %.sink52 = phi i8 [ 3, %v584_ok ], [ 8, %v592_ok ]
  %v593_offset = zext nneg i32 %v584 to i64
  %v593 = getelementptr i8, ptr %v580, i64 %v593_offset
  store i8 %.sink52, ptr %v593, align 1
  %v596 = getelementptr i8, ptr %p1, i64 168
  %v597 = load i32, ptr %v596, align 4
  br label %common.ret

b253:                                             ; preds = %b232, %b240
  %v601.not = icmp eq i8 %p0, 58
  br i1 %v601.not, label %b257, label %b255

b255:                                             ; preds = %b253
  %v603 = getelementptr i8, ptr %p1, i64 48
  %v604 = load i64, ptr %v603, align 8
  %v0.i41 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i41, align 8
  %v2.i42 = getelementptr i8, ptr %p1, i64 176
  store i64 %v604, ptr %v2.i42, align 8
  br label %common.ret

b257:                                             ; preds = %b253
  %v608 = getelementptr i8, ptr %p1, i64 56
  %v612_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v612 = extractvalue { i32, i1 } %v612_pair, 0
  %v612_overflow = extractvalue { i32, i1 } %v612_pair, 1
  br i1 %v612_overflow, label %v612_trap, label %v612_ok

v612_trap:                                        ; preds = %b257
  tail call void @llvm.trap()
  unreachable

v612_ok:                                          ; preds = %b257
  %v613_invalid = icmp ugt i32 %v612, 63
  br i1 %v613_invalid, label %v613_trap, label %v613_ok

v613_trap:                                        ; preds = %v612_ok
  tail call void @llvm.trap()
  unreachable

v613_ok:                                          ; preds = %v612_ok
  %v613_offset = zext nneg i32 %v612 to i64
  %v613 = getelementptr i8, ptr %v608, i64 %v613_offset
  store i8 6, ptr %v613, align 1
  %v616 = getelementptr i8, ptr %p1, i64 168
  %v617 = load i32, ptr %v616, align 4
  br label %common.ret

b259:                                             ; preds = %b232, %b240
  br i1 %v519.not, label %b268, label %b273

b262.critedge:                                    ; preds = %b232, %b240, %b240
  %v625.not = icmp eq i8 %p0, 34
  br i1 %v625.not, label %b266, label %b264

b264:                                             ; preds = %b262.critedge
  %v627 = getelementptr i8, ptr %p1, i64 48
  %v628 = load i64, ptr %v627, align 8
  %v0.i43 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i43, align 8
  %v2.i44 = getelementptr i8, ptr %p1, i64 176
  store i64 %v628, ptr %v2.i44, align 8
  br label %common.ret

b266:                                             ; preds = %b262.critedge
  %v632 = getelementptr i8, ptr %p1, i64 132
  store i1 true, ptr %v632, align 4
  store i32 1, ptr %v0, align 4
  %v638 = getelementptr i8, ptr %p1, i64 168
  %v639 = load i32, ptr %v638, align 4
  br label %common.ret

b268:                                             ; preds = %b259
  %v645 = getelementptr i8, ptr %p1, i64 124
  %v646 = load i1, ptr %v645, align 4
  br i1 %v646, label %b271, label %b273

b271:                                             ; preds = %b268
  %v649 = getelementptr i8, ptr %p1, i64 48
  %v650 = load i64, ptr %v649, align 8
  %v0.i45 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i45, align 8
  %v2.i46 = getelementptr i8, ptr %p1, i64 176
  store i64 %v650, ptr %v2.i46, align 8
  br label %common.ret

b273:                                             ; preds = %b268, %b259
  switch i8 %p0, label %b291 [
    i8 123, label %b277
    i8 91, label %b277
    i8 34, label %b286
    i8 45, label %b289
  ]

b277:                                             ; preds = %b273, %b273
  %v663 = icmp eq i32 %v517, 64
  br i1 %v663, label %b279, label %b281

b279:                                             ; preds = %b277
  %v665 = getelementptr i8, ptr %p1, i64 48
  %v666 = load i64, ptr %v665, align 8
  %v0.i47 = getelementptr i8, ptr %p1, i64 168
  store i32 7, ptr %v0.i47, align 8
  %v2.i48 = getelementptr i8, ptr %p1, i64 176
  store i64 %v666, ptr %v2.i48, align 8
  br label %common.ret

b281:                                             ; preds = %b277
  %v671 = tail call i32 @liza___liza_json_mut_done(ptr %p1)
  %v674 = icmp eq i8 %p0, 91
  %v677 = load i32, ptr %v516, align 4
  %v678_invalid = icmp ugt i32 %v677, 63
  br i1 %v674, label %b282, label %b283

b282:                                             ; preds = %b281
  br i1 %v678_invalid, label %v678_trap, label %b284

v678_trap:                                        ; preds = %b282
  tail call void @llvm.trap()
  unreachable

b283:                                             ; preds = %b281
  br i1 %v678_invalid, label %v684_trap, label %b284

v684_trap:                                        ; preds = %b283
  tail call void @llvm.trap()
  unreachable

b284:                                             ; preds = %b283, %b282
  %.sink53 = phi i8 [ 1, %b282 ], [ 4, %b283 ]
  %v681 = getelementptr i8, ptr %p1, i64 56
  %v684_offset = zext nneg i32 %v677 to i64
  %v684 = getelementptr i8, ptr %v681, i64 %v684_offset
  store i8 %.sink53, ptr %v684, align 1
  %v689 = load i32, ptr %v516, align 4
  %v691_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v689, i32 1)
  %v691_overflow = extractvalue { i32, i1 } %v691_pair, 1
  br i1 %v691_overflow, label %v691_trap, label %v691_ok

v691_trap:                                        ; preds = %b284
  tail call void @llvm.trap()
  unreachable

v691_ok:                                          ; preds = %b284
  %v691 = extractvalue { i32, i1 } %v691_pair, 0
  store i32 %v691, ptr %v516, align 4
  %v693 = getelementptr i8, ptr %p1, i64 168
  %v694 = load i32, ptr %v693, align 4
  br label %common.ret

b286:                                             ; preds = %b273
  %v697 = getelementptr i8, ptr %p1, i64 132
  store i1 false, ptr %v697, align 4
  store i32 1, ptr %v0, align 4
  %v703 = getelementptr i8, ptr %p1, i64 168
  %v704 = load i32, ptr %v703, align 4
  br label %common.ret

b289:                                             ; preds = %b273
  store i32 10, ptr %v0, align 4
  %v710 = getelementptr i8, ptr %p1, i64 168
  %v711 = load i32, ptr %v710, align 4
  br label %common.ret

b291:                                             ; preds = %b273
  %10 = add i8 %p0, -48
  %v5.i49 = icmp ult i8 %10, 10
  br i1 %v5.i49, label %b292, label %b297

b292:                                             ; preds = %b291
  %v714 = icmp eq i8 %p0, 48
  %.11 = select i1 %v714, i32 11, i32 12
  store i32 %.11, ptr %v0, align 4
  %v721 = getelementptr i8, ptr %p1, i64 168
  %v722 = load i32, ptr %v721, align 4
  br label %common.ret

b297:                                             ; preds = %b291
  switch i8 %p0, label %b312 [
    i8 116, label %b304
    i8 102, label %b304
    i8 110, label %b304
  ]

b304:                                             ; preds = %b297, %b297, %b297
  store i32 20, ptr %v0, align 4
  %v736 = getelementptr i8, ptr %p1, i64 140
  store i32 1, ptr %v736, align 4
  %v749 = getelementptr i8, ptr %p1, i64 136
  %switch.selectcmp = icmp eq i8 %p0, 102
  %switch.select = select i1 %switch.selectcmp, i32 2, i32 3
  %switch.selectcmp56 = icmp eq i8 %p0, 116
  %switch.select57 = select i1 %switch.selectcmp56, i32 1, i32 %switch.select
  store i32 %switch.select57, ptr %v749, align 4
  %v752 = getelementptr i8, ptr %p1, i64 168
  %v753 = load i32, ptr %v752, align 4
  br label %common.ret

b312:                                             ; preds = %b297
  %v755 = getelementptr i8, ptr %p1, i64 48
  %v756 = load i64, ptr %v755, align 8
  %v0.i50 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i50, align 8
  %v2.i51 = getelementptr i8, ptr %p1, i64 176
  store i64 %v756, ptr %v2.i51, align 8
  br label %common.ret
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write, target_mem: none)
define i32 @liza_json.feed_mut(ptr %p0, { ptr, i32 } %p1) local_unnamed_addr #5 {
b0:
  %v0 = getelementptr i8, ptr %p0, i64 168
  %v1 = load i32, ptr %v0, align 4
  %v3.not = icmp eq i32 %v1, 0
  br i1 %v3.not, label %b4.preheader, label %common.ret

b4.preheader:                                     ; preds = %b0
  %v8 = extractvalue { ptr, i32 } %p1, 1
  %v10_base = extractvalue { ptr, i32 } %p1, 0
  %v42 = getelementptr i8, ptr %p0, i64 48
  %wide.trip.count = zext i32 %v8 to i64
  br label %b4

common.ret:                                       ; preds = %b13, %b0, %b12, %b11, %b6
  %common.ret.op = phi i32 [ %v1, %b0 ], [ %v51, %b6 ], [ 5, %b11 ], [ 8, %b12 ], [ %v37, %b13 ]
  ret i32 %common.ret.op

b4:                                               ; preds = %b4.preheader, %v46_ok
  %indvars.iv = phi i64 [ 0, %b4.preheader ], [ %indvars.iv.next, %v46_ok ]
  %exitcond.not = icmp eq i64 %indvars.iv, %wide.trip.count
  br i1 %exitcond.not, label %b6, label %v10_ok

v10_ok:                                           ; preds = %b4
  %v10_ptr = getelementptr i8, ptr %v10_base, i64 %indvars.iv
  %v10 = load i8, ptr %v10_ptr, align 1
  %v13 = load %struct.Utf8StreamState, ptr %p0, align 8
  %v14 = tail call %struct.Utf8StreamState @liza_utf8_stream.feed_byte(%struct.Utf8StreamState %v13, i8 %v10)
  store %struct.Utf8StreamState %v14, ptr %p0, align 8
  %v0.i = extractvalue %struct.Utf8StreamState %v14, 6
  switch i32 %v0.i, label %liza_utf8_stream.status.exit [
    i32 1, label %b1.i
    i32 2, label %b4.i
  ]

b1.i:                                             ; preds = %v10_ok
  %v4.i = extractvalue %struct.Utf8StreamState %v14, 7
  %v5.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i, 1
  %v6.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5.i, 1
  br label %liza_utf8_stream.status.exit

b4.i:                                             ; preds = %v10_ok
  %v11.i = extractvalue %struct.Utf8StreamState %v14, 7
  %v12.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i, 1
  %v13.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12.i, 1
  br label %liza_utf8_stream.status.exit

liza_utf8_stream.status.exit:                     ; preds = %v10_ok, %b1.i, %b4.i
  %common.ret.op.i = phi %variant.3 [ %v6.i, %b1.i ], [ %v13.i, %b4.i ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %v10_ok ]
  %v19 = extractvalue %variant.3 %common.ret.op.i, 0
  %0 = icmp eq i32 %v19, 1
  br i1 %0, label %b13, label %b9

b6:                                               ; preds = %b4
  %v51 = load i32, ptr %v0, align 4
  br label %common.ret

b9:                                               ; preds = %liza_utf8_stream.status.exit
  %v20 = extractvalue %variant.3 %common.ret.op.i, 1
  %v21 = extractvalue %struct.Utf8StreamError %v20, 0
  %v22 = extractvalue %variant.0 %v21, 0
  %1 = icmp eq i32 %v22, 0
  %v24 = extractvalue %struct.Utf8StreamError %v20, 1
  %v2.i = getelementptr i8, ptr %p0, i64 176
  br i1 %1, label %b11, label %b12

b11:                                              ; preds = %b9
  store i32 5, ptr %v0, align 8
  store i64 %v24, ptr %v2.i, align 8
  br label %common.ret

b12:                                              ; preds = %b9
  store i32 8, ptr %v0, align 8
  store i64 %v24, ptr %v2.i, align 8
  br label %common.ret

b13:                                              ; preds = %liza_utf8_stream.status.exit
  %v34 = tail call i32 @liza___liza_json_mut_step(i8 %v10, ptr nonnull %p0)
  %v37 = load i32, ptr %v0, align 8
  %v39.not = icmp eq i32 %v37, 0
  br i1 %v39.not, label %b16, label %common.ret

b16:                                              ; preds = %b13
  %v44 = load i64, ptr %v42, align 8
  %v46_pair = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v44, i64 1)
  %v46_overflow = extractvalue { i64, i1 } %v46_pair, 1
  br i1 %v46_overflow, label %v46_trap, label %v46_ok

v46_trap:                                         ; preds = %b16
  tail call void @llvm.trap()
  unreachable

v46_ok:                                           ; preds = %b16
  %v46 = extractvalue { i64, i1 } %v46_pair, 0
  store i64 %v46, ptr %v42, align 8
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond15 = icmp eq i64 %indvars.iv.next, 4294967296
  br i1 %exitcond15, label %v49_trap, label %b4

v49_trap:                                         ; preds = %v46_ok
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define void @liza___liza_owned___liza_json_done(ptr nofree sret(%struct.JsonState) %return_storage, ptr nofree readnone captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v22_scratch = alloca [64 x i8], align 1
  %v27_scratch = alloca [64 x i8], align 1
  %v14_storage = alloca [64 x i8], align 1
  %v9_storage = alloca [64 x i8], align 1
  %v0_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 120
  %v0 = load i32, ptr %v0_ptr, align 8
  %v2 = icmp eq i32 %v0, 0
  br i1 %v2, label %b1, label %b2

b1:                                               ; preds = %b0
  %v3_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  store i1 true, ptr %v3_ptr, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v8_pair = add i32 %v0, -1
  %v9_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 56
  %v9.unpack = load i8, ptr %v9_ptr, align 8
  %v9.elt257 = getelementptr inbounds nuw i8, ptr %return_storage, i64 57
  %v9.unpack258 = load i8, ptr %v9.elt257, align 1
  %v9.elt259 = getelementptr inbounds nuw i8, ptr %return_storage, i64 58
  %v9.unpack260 = load i8, ptr %v9.elt259, align 2
  %v9.elt261 = getelementptr inbounds nuw i8, ptr %return_storage, i64 59
  %v9.unpack262 = load i8, ptr %v9.elt261, align 1
  %v9.elt263 = getelementptr inbounds nuw i8, ptr %return_storage, i64 60
  %v9.unpack264 = load i8, ptr %v9.elt263, align 4
  %v9.elt265 = getelementptr inbounds nuw i8, ptr %return_storage, i64 61
  %v9.unpack266 = load i8, ptr %v9.elt265, align 1
  %v9.elt267 = getelementptr inbounds nuw i8, ptr %return_storage, i64 62
  %v9.unpack268 = load i8, ptr %v9.elt267, align 2
  %v9.elt269 = getelementptr inbounds nuw i8, ptr %return_storage, i64 63
  %v9.unpack270 = load i8, ptr %v9.elt269, align 1
  %v9.elt271 = getelementptr inbounds nuw i8, ptr %return_storage, i64 64
  %v9.unpack272 = load i8, ptr %v9.elt271, align 8
  %v9.elt273 = getelementptr inbounds nuw i8, ptr %return_storage, i64 65
  %v9.unpack274 = load i8, ptr %v9.elt273, align 1
  %v9.elt275 = getelementptr inbounds nuw i8, ptr %return_storage, i64 66
  %v9.unpack276 = load i8, ptr %v9.elt275, align 2
  %v9.elt277 = getelementptr inbounds nuw i8, ptr %return_storage, i64 67
  %v9.unpack278 = load i8, ptr %v9.elt277, align 1
  %v9.elt279 = getelementptr inbounds nuw i8, ptr %return_storage, i64 68
  %v9.unpack280 = load i8, ptr %v9.elt279, align 4
  %v9.elt281 = getelementptr inbounds nuw i8, ptr %return_storage, i64 69
  %v9.unpack282 = load i8, ptr %v9.elt281, align 1
  %v9.elt283 = getelementptr inbounds nuw i8, ptr %return_storage, i64 70
  %v9.unpack284 = load i8, ptr %v9.elt283, align 2
  %v9.elt285 = getelementptr inbounds nuw i8, ptr %return_storage, i64 71
  %v9.unpack286 = load i8, ptr %v9.elt285, align 1
  %v9.elt287 = getelementptr inbounds nuw i8, ptr %return_storage, i64 72
  %v9.unpack288 = load i8, ptr %v9.elt287, align 8
  %v9.elt289 = getelementptr inbounds nuw i8, ptr %return_storage, i64 73
  %v9.unpack290 = load i8, ptr %v9.elt289, align 1
  %v9.elt291 = getelementptr inbounds nuw i8, ptr %return_storage, i64 74
  %v9.unpack292 = load i8, ptr %v9.elt291, align 2
  %v9.elt293 = getelementptr inbounds nuw i8, ptr %return_storage, i64 75
  %v9.unpack294 = load i8, ptr %v9.elt293, align 1
  %v9.elt295 = getelementptr inbounds nuw i8, ptr %return_storage, i64 76
  %v9.unpack296 = load i8, ptr %v9.elt295, align 4
  %v9.elt297 = getelementptr inbounds nuw i8, ptr %return_storage, i64 77
  %v9.unpack298 = load i8, ptr %v9.elt297, align 1
  %v9.elt299 = getelementptr inbounds nuw i8, ptr %return_storage, i64 78
  %v9.unpack300 = load i8, ptr %v9.elt299, align 2
  %v9.elt301 = getelementptr inbounds nuw i8, ptr %return_storage, i64 79
  %v9.unpack302 = load i8, ptr %v9.elt301, align 1
  %v9.elt303 = getelementptr inbounds nuw i8, ptr %return_storage, i64 80
  %v9.unpack304 = load i8, ptr %v9.elt303, align 8
  %v9.elt305 = getelementptr inbounds nuw i8, ptr %return_storage, i64 81
  %v9.unpack306 = load i8, ptr %v9.elt305, align 1
  %v9.elt307 = getelementptr inbounds nuw i8, ptr %return_storage, i64 82
  %v9.unpack308 = load i8, ptr %v9.elt307, align 2
  %v9.elt309 = getelementptr inbounds nuw i8, ptr %return_storage, i64 83
  %v9.unpack310 = load i8, ptr %v9.elt309, align 1
  %v9.elt311 = getelementptr inbounds nuw i8, ptr %return_storage, i64 84
  %v9.unpack312 = load i8, ptr %v9.elt311, align 4
  %v9.elt313 = getelementptr inbounds nuw i8, ptr %return_storage, i64 85
  %v9.unpack314 = load i8, ptr %v9.elt313, align 1
  %v9.elt315 = getelementptr inbounds nuw i8, ptr %return_storage, i64 86
  %v9.unpack316 = load i8, ptr %v9.elt315, align 2
  %v9.elt317 = getelementptr inbounds nuw i8, ptr %return_storage, i64 87
  %v9.unpack318 = load i8, ptr %v9.elt317, align 1
  %v9.elt319 = getelementptr inbounds nuw i8, ptr %return_storage, i64 88
  %v9.unpack320 = load i8, ptr %v9.elt319, align 8
  %v9.elt321 = getelementptr inbounds nuw i8, ptr %return_storage, i64 89
  %v9.unpack322 = load i8, ptr %v9.elt321, align 1
  %v9.elt323 = getelementptr inbounds nuw i8, ptr %return_storage, i64 90
  %v9.unpack324 = load i8, ptr %v9.elt323, align 2
  %v9.elt325 = getelementptr inbounds nuw i8, ptr %return_storage, i64 91
  %v9.unpack326 = load i8, ptr %v9.elt325, align 1
  %v9.elt327 = getelementptr inbounds nuw i8, ptr %return_storage, i64 92
  %v9.unpack328 = load i8, ptr %v9.elt327, align 4
  %v9.elt329 = getelementptr inbounds nuw i8, ptr %return_storage, i64 93
  %v9.unpack330 = load i8, ptr %v9.elt329, align 1
  %v9.elt331 = getelementptr inbounds nuw i8, ptr %return_storage, i64 94
  %v9.unpack332 = load i8, ptr %v9.elt331, align 2
  %v9.elt333 = getelementptr inbounds nuw i8, ptr %return_storage, i64 95
  %v9.unpack334 = load i8, ptr %v9.elt333, align 1
  %v9.elt335 = getelementptr inbounds nuw i8, ptr %return_storage, i64 96
  %v9.unpack336 = load i8, ptr %v9.elt335, align 8
  %v9.elt337 = getelementptr inbounds nuw i8, ptr %return_storage, i64 97
  %v9.unpack338 = load i8, ptr %v9.elt337, align 1
  %v9.elt339 = getelementptr inbounds nuw i8, ptr %return_storage, i64 98
  %v9.unpack340 = load i8, ptr %v9.elt339, align 2
  %v9.elt341 = getelementptr inbounds nuw i8, ptr %return_storage, i64 99
  %v9.unpack342 = load i8, ptr %v9.elt341, align 1
  %v9.elt343 = getelementptr inbounds nuw i8, ptr %return_storage, i64 100
  %v9.unpack344 = load i8, ptr %v9.elt343, align 4
  %v9.elt345 = getelementptr inbounds nuw i8, ptr %return_storage, i64 101
  %v9.unpack346 = load i8, ptr %v9.elt345, align 1
  %v9.elt347 = getelementptr inbounds nuw i8, ptr %return_storage, i64 102
  %v9.unpack348 = load i8, ptr %v9.elt347, align 2
  %v9.elt349 = getelementptr inbounds nuw i8, ptr %return_storage, i64 103
  %v9.unpack350 = load i8, ptr %v9.elt349, align 1
  %v9.elt351 = getelementptr inbounds nuw i8, ptr %return_storage, i64 104
  %v9.unpack352 = load i8, ptr %v9.elt351, align 8
  %v9.elt353 = getelementptr inbounds nuw i8, ptr %return_storage, i64 105
  %v9.unpack354 = load i8, ptr %v9.elt353, align 1
  %v9.elt355 = getelementptr inbounds nuw i8, ptr %return_storage, i64 106
  %v9.unpack356 = load i8, ptr %v9.elt355, align 2
  %v9.elt357 = getelementptr inbounds nuw i8, ptr %return_storage, i64 107
  %v9.unpack358 = load i8, ptr %v9.elt357, align 1
  %v9.elt359 = getelementptr inbounds nuw i8, ptr %return_storage, i64 108
  %v9.unpack360 = load i8, ptr %v9.elt359, align 4
  %v9.elt361 = getelementptr inbounds nuw i8, ptr %return_storage, i64 109
  %v9.unpack362 = load i8, ptr %v9.elt361, align 1
  %v9.elt363 = getelementptr inbounds nuw i8, ptr %return_storage, i64 110
  %v9.unpack364 = load i8, ptr %v9.elt363, align 2
  %v9.elt365 = getelementptr inbounds nuw i8, ptr %return_storage, i64 111
  %v9.unpack366 = load i8, ptr %v9.elt365, align 1
  %v9.elt367 = getelementptr inbounds nuw i8, ptr %return_storage, i64 112
  %v9.unpack368 = load i8, ptr %v9.elt367, align 8
  %v9.elt369 = getelementptr inbounds nuw i8, ptr %return_storage, i64 113
  %v9.unpack370 = load i8, ptr %v9.elt369, align 1
  %v9.elt371 = getelementptr inbounds nuw i8, ptr %return_storage, i64 114
  %v9.unpack372 = load i8, ptr %v9.elt371, align 2
  %v9.elt373 = getelementptr inbounds nuw i8, ptr %return_storage, i64 115
  %v9.unpack374 = load i8, ptr %v9.elt373, align 1
  %v9.elt375 = getelementptr inbounds nuw i8, ptr %return_storage, i64 116
  %v9.unpack376 = load i8, ptr %v9.elt375, align 4
  %v9.elt377 = getelementptr inbounds nuw i8, ptr %return_storage, i64 117
  %v9.unpack378 = load i8, ptr %v9.elt377, align 1
  %v9.elt379 = getelementptr inbounds nuw i8, ptr %return_storage, i64 118
  %v9.unpack380 = load i8, ptr %v9.elt379, align 2
  %v9.elt381 = getelementptr inbounds nuw i8, ptr %return_storage, i64 119
  %v9.unpack382 = load i8, ptr %v9.elt381, align 1
  store i8 %v9.unpack, ptr %v9_storage, align 1
  %v9.fca.1.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 1
  store i8 %v9.unpack258, ptr %v9.fca.1.gep, align 1
  %v9.fca.2.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 2
  store i8 %v9.unpack260, ptr %v9.fca.2.gep, align 1
  %v9.fca.3.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 3
  store i8 %v9.unpack262, ptr %v9.fca.3.gep, align 1
  %v9.fca.4.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 4
  store i8 %v9.unpack264, ptr %v9.fca.4.gep, align 1
  %v9.fca.5.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 5
  store i8 %v9.unpack266, ptr %v9.fca.5.gep, align 1
  %v9.fca.6.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 6
  store i8 %v9.unpack268, ptr %v9.fca.6.gep, align 1
  %v9.fca.7.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 7
  store i8 %v9.unpack270, ptr %v9.fca.7.gep, align 1
  %v9.fca.8.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 8
  store i8 %v9.unpack272, ptr %v9.fca.8.gep, align 1
  %v9.fca.9.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 9
  store i8 %v9.unpack274, ptr %v9.fca.9.gep, align 1
  %v9.fca.10.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 10
  store i8 %v9.unpack276, ptr %v9.fca.10.gep, align 1
  %v9.fca.11.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 11
  store i8 %v9.unpack278, ptr %v9.fca.11.gep, align 1
  %v9.fca.12.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 12
  store i8 %v9.unpack280, ptr %v9.fca.12.gep, align 1
  %v9.fca.13.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 13
  store i8 %v9.unpack282, ptr %v9.fca.13.gep, align 1
  %v9.fca.14.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 14
  store i8 %v9.unpack284, ptr %v9.fca.14.gep, align 1
  %v9.fca.15.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 15
  store i8 %v9.unpack286, ptr %v9.fca.15.gep, align 1
  %v9.fca.16.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 16
  store i8 %v9.unpack288, ptr %v9.fca.16.gep, align 1
  %v9.fca.17.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 17
  store i8 %v9.unpack290, ptr %v9.fca.17.gep, align 1
  %v9.fca.18.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 18
  store i8 %v9.unpack292, ptr %v9.fca.18.gep, align 1
  %v9.fca.19.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 19
  store i8 %v9.unpack294, ptr %v9.fca.19.gep, align 1
  %v9.fca.20.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 20
  store i8 %v9.unpack296, ptr %v9.fca.20.gep, align 1
  %v9.fca.21.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 21
  store i8 %v9.unpack298, ptr %v9.fca.21.gep, align 1
  %v9.fca.22.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 22
  store i8 %v9.unpack300, ptr %v9.fca.22.gep, align 1
  %v9.fca.23.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 23
  store i8 %v9.unpack302, ptr %v9.fca.23.gep, align 1
  %v9.fca.24.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 24
  store i8 %v9.unpack304, ptr %v9.fca.24.gep, align 1
  %v9.fca.25.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 25
  store i8 %v9.unpack306, ptr %v9.fca.25.gep, align 1
  %v9.fca.26.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 26
  store i8 %v9.unpack308, ptr %v9.fca.26.gep, align 1
  %v9.fca.27.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 27
  store i8 %v9.unpack310, ptr %v9.fca.27.gep, align 1
  %v9.fca.28.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 28
  store i8 %v9.unpack312, ptr %v9.fca.28.gep, align 1
  %v9.fca.29.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 29
  store i8 %v9.unpack314, ptr %v9.fca.29.gep, align 1
  %v9.fca.30.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 30
  store i8 %v9.unpack316, ptr %v9.fca.30.gep, align 1
  %v9.fca.31.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 31
  store i8 %v9.unpack318, ptr %v9.fca.31.gep, align 1
  %v9.fca.32.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 32
  store i8 %v9.unpack320, ptr %v9.fca.32.gep, align 1
  %v9.fca.33.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 33
  store i8 %v9.unpack322, ptr %v9.fca.33.gep, align 1
  %v9.fca.34.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 34
  store i8 %v9.unpack324, ptr %v9.fca.34.gep, align 1
  %v9.fca.35.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 35
  store i8 %v9.unpack326, ptr %v9.fca.35.gep, align 1
  %v9.fca.36.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 36
  store i8 %v9.unpack328, ptr %v9.fca.36.gep, align 1
  %v9.fca.37.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 37
  store i8 %v9.unpack330, ptr %v9.fca.37.gep, align 1
  %v9.fca.38.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 38
  store i8 %v9.unpack332, ptr %v9.fca.38.gep, align 1
  %v9.fca.39.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 39
  store i8 %v9.unpack334, ptr %v9.fca.39.gep, align 1
  %v9.fca.40.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 40
  store i8 %v9.unpack336, ptr %v9.fca.40.gep, align 1
  %v9.fca.41.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 41
  store i8 %v9.unpack338, ptr %v9.fca.41.gep, align 1
  %v9.fca.42.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 42
  store i8 %v9.unpack340, ptr %v9.fca.42.gep, align 1
  %v9.fca.43.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 43
  store i8 %v9.unpack342, ptr %v9.fca.43.gep, align 1
  %v9.fca.44.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 44
  store i8 %v9.unpack344, ptr %v9.fca.44.gep, align 1
  %v9.fca.45.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 45
  store i8 %v9.unpack346, ptr %v9.fca.45.gep, align 1
  %v9.fca.46.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 46
  store i8 %v9.unpack348, ptr %v9.fca.46.gep, align 1
  %v9.fca.47.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 47
  store i8 %v9.unpack350, ptr %v9.fca.47.gep, align 1
  %v9.fca.48.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 48
  store i8 %v9.unpack352, ptr %v9.fca.48.gep, align 1
  %v9.fca.49.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 49
  store i8 %v9.unpack354, ptr %v9.fca.49.gep, align 1
  %v9.fca.50.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 50
  store i8 %v9.unpack356, ptr %v9.fca.50.gep, align 1
  %v9.fca.51.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 51
  store i8 %v9.unpack358, ptr %v9.fca.51.gep, align 1
  %v9.fca.52.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 52
  store i8 %v9.unpack360, ptr %v9.fca.52.gep, align 1
  %v9.fca.53.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 53
  store i8 %v9.unpack362, ptr %v9.fca.53.gep, align 1
  %v9.fca.54.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 54
  store i8 %v9.unpack364, ptr %v9.fca.54.gep, align 1
  %v9.fca.55.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 55
  store i8 %v9.unpack366, ptr %v9.fca.55.gep, align 1
  %v9.fca.56.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 56
  store i8 %v9.unpack368, ptr %v9.fca.56.gep, align 1
  %v9.fca.57.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 57
  store i8 %v9.unpack370, ptr %v9.fca.57.gep, align 1
  %v9.fca.58.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 58
  store i8 %v9.unpack372, ptr %v9.fca.58.gep, align 1
  %v9.fca.59.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 59
  store i8 %v9.unpack374, ptr %v9.fca.59.gep, align 1
  %v9.fca.60.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 60
  store i8 %v9.unpack376, ptr %v9.fca.60.gep, align 1
  %v9.fca.61.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 61
  store i8 %v9.unpack378, ptr %v9.fca.61.gep, align 1
  %v9.fca.62.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 62
  store i8 %v9.unpack380, ptr %v9.fca.62.gep, align 1
  %v9.fca.63.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 63
  store i8 %v9.unpack382, ptr %v9.fca.63.gep, align 1
  %v10_invalid = icmp ugt i32 %v8_pair, 63
  br i1 %v10_invalid, label %v10_trap, label %v10_ok

v10_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v10_ok:                                           ; preds = %b2
  %v10_offset = zext nneg i32 %v8_pair to i64
  %v10_ptr = getelementptr i8, ptr %v9_storage, i64 %v10_offset
  %v10 = load i8, ptr %v10_ptr, align 1
  %v12 = icmp eq i8 %v10, 1
  br i1 %v12, label %v20_ok, label %b3

b3:                                               ; preds = %v10_ok
  store i8 %v9.unpack, ptr %v14_storage, align 1
  %v14.fca.1.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 1
  store i8 %v9.unpack258, ptr %v14.fca.1.gep, align 1
  %v14.fca.2.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 2
  store i8 %v9.unpack260, ptr %v14.fca.2.gep, align 1
  %v14.fca.3.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 3
  store i8 %v9.unpack262, ptr %v14.fca.3.gep, align 1
  %v14.fca.4.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 4
  store i8 %v9.unpack264, ptr %v14.fca.4.gep, align 1
  %v14.fca.5.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 5
  store i8 %v9.unpack266, ptr %v14.fca.5.gep, align 1
  %v14.fca.6.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 6
  store i8 %v9.unpack268, ptr %v14.fca.6.gep, align 1
  %v14.fca.7.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 7
  store i8 %v9.unpack270, ptr %v14.fca.7.gep, align 1
  %v14.fca.8.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 8
  store i8 %v9.unpack272, ptr %v14.fca.8.gep, align 1
  %v14.fca.9.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 9
  store i8 %v9.unpack274, ptr %v14.fca.9.gep, align 1
  %v14.fca.10.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 10
  store i8 %v9.unpack276, ptr %v14.fca.10.gep, align 1
  %v14.fca.11.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 11
  store i8 %v9.unpack278, ptr %v14.fca.11.gep, align 1
  %v14.fca.12.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 12
  store i8 %v9.unpack280, ptr %v14.fca.12.gep, align 1
  %v14.fca.13.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 13
  store i8 %v9.unpack282, ptr %v14.fca.13.gep, align 1
  %v14.fca.14.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 14
  store i8 %v9.unpack284, ptr %v14.fca.14.gep, align 1
  %v14.fca.15.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 15
  store i8 %v9.unpack286, ptr %v14.fca.15.gep, align 1
  %v14.fca.16.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 16
  store i8 %v9.unpack288, ptr %v14.fca.16.gep, align 1
  %v14.fca.17.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 17
  store i8 %v9.unpack290, ptr %v14.fca.17.gep, align 1
  %v14.fca.18.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 18
  store i8 %v9.unpack292, ptr %v14.fca.18.gep, align 1
  %v14.fca.19.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 19
  store i8 %v9.unpack294, ptr %v14.fca.19.gep, align 1
  %v14.fca.20.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 20
  store i8 %v9.unpack296, ptr %v14.fca.20.gep, align 1
  %v14.fca.21.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 21
  store i8 %v9.unpack298, ptr %v14.fca.21.gep, align 1
  %v14.fca.22.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 22
  store i8 %v9.unpack300, ptr %v14.fca.22.gep, align 1
  %v14.fca.23.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 23
  store i8 %v9.unpack302, ptr %v14.fca.23.gep, align 1
  %v14.fca.24.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 24
  store i8 %v9.unpack304, ptr %v14.fca.24.gep, align 1
  %v14.fca.25.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 25
  store i8 %v9.unpack306, ptr %v14.fca.25.gep, align 1
  %v14.fca.26.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 26
  store i8 %v9.unpack308, ptr %v14.fca.26.gep, align 1
  %v14.fca.27.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 27
  store i8 %v9.unpack310, ptr %v14.fca.27.gep, align 1
  %v14.fca.28.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 28
  store i8 %v9.unpack312, ptr %v14.fca.28.gep, align 1
  %v14.fca.29.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 29
  store i8 %v9.unpack314, ptr %v14.fca.29.gep, align 1
  %v14.fca.30.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 30
  store i8 %v9.unpack316, ptr %v14.fca.30.gep, align 1
  %v14.fca.31.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 31
  store i8 %v9.unpack318, ptr %v14.fca.31.gep, align 1
  %v14.fca.32.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 32
  store i8 %v9.unpack320, ptr %v14.fca.32.gep, align 1
  %v14.fca.33.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 33
  store i8 %v9.unpack322, ptr %v14.fca.33.gep, align 1
  %v14.fca.34.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 34
  store i8 %v9.unpack324, ptr %v14.fca.34.gep, align 1
  %v14.fca.35.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 35
  store i8 %v9.unpack326, ptr %v14.fca.35.gep, align 1
  %v14.fca.36.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 36
  store i8 %v9.unpack328, ptr %v14.fca.36.gep, align 1
  %v14.fca.37.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 37
  store i8 %v9.unpack330, ptr %v14.fca.37.gep, align 1
  %v14.fca.38.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 38
  store i8 %v9.unpack332, ptr %v14.fca.38.gep, align 1
  %v14.fca.39.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 39
  store i8 %v9.unpack334, ptr %v14.fca.39.gep, align 1
  %v14.fca.40.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 40
  store i8 %v9.unpack336, ptr %v14.fca.40.gep, align 1
  %v14.fca.41.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 41
  store i8 %v9.unpack338, ptr %v14.fca.41.gep, align 1
  %v14.fca.42.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 42
  store i8 %v9.unpack340, ptr %v14.fca.42.gep, align 1
  %v14.fca.43.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 43
  store i8 %v9.unpack342, ptr %v14.fca.43.gep, align 1
  %v14.fca.44.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 44
  store i8 %v9.unpack344, ptr %v14.fca.44.gep, align 1
  %v14.fca.45.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 45
  store i8 %v9.unpack346, ptr %v14.fca.45.gep, align 1
  %v14.fca.46.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 46
  store i8 %v9.unpack348, ptr %v14.fca.46.gep, align 1
  %v14.fca.47.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 47
  store i8 %v9.unpack350, ptr %v14.fca.47.gep, align 1
  %v14.fca.48.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 48
  store i8 %v9.unpack352, ptr %v14.fca.48.gep, align 1
  %v14.fca.49.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 49
  store i8 %v9.unpack354, ptr %v14.fca.49.gep, align 1
  %v14.fca.50.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 50
  store i8 %v9.unpack356, ptr %v14.fca.50.gep, align 1
  %v14.fca.51.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 51
  store i8 %v9.unpack358, ptr %v14.fca.51.gep, align 1
  %v14.fca.52.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 52
  store i8 %v9.unpack360, ptr %v14.fca.52.gep, align 1
  %v14.fca.53.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 53
  store i8 %v9.unpack362, ptr %v14.fca.53.gep, align 1
  %v14.fca.54.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 54
  store i8 %v9.unpack364, ptr %v14.fca.54.gep, align 1
  %v14.fca.55.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 55
  store i8 %v9.unpack366, ptr %v14.fca.55.gep, align 1
  %v14.fca.56.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 56
  store i8 %v9.unpack368, ptr %v14.fca.56.gep, align 1
  %v14.fca.57.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 57
  store i8 %v9.unpack370, ptr %v14.fca.57.gep, align 1
  %v14.fca.58.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 58
  store i8 %v9.unpack372, ptr %v14.fca.58.gep, align 1
  %v14.fca.59.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 59
  store i8 %v9.unpack374, ptr %v14.fca.59.gep, align 1
  %v14.fca.60.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 60
  store i8 %v9.unpack376, ptr %v14.fca.60.gep, align 1
  %v14.fca.61.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 61
  store i8 %v9.unpack378, ptr %v14.fca.61.gep, align 1
  %v14.fca.62.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 62
  store i8 %v9.unpack380, ptr %v14.fca.62.gep, align 1
  %v14.fca.63.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 63
  store i8 %v9.unpack382, ptr %v14.fca.63.gep, align 1
  %v15_ptr = getelementptr i8, ptr %v14_storage, i64 %v10_offset
  %v15 = load i8, ptr %v15_ptr, align 1
  %v17 = icmp eq i8 %v15, 3
  br i1 %v17, label %v20_ok, label %v25_ok

v20_ok:                                           ; preds = %b3, %v10_ok
  %v19.unpack889 = load i8, ptr %v9.elt381, align 1
  %v19.unpack887 = load i8, ptr %v9.elt379, align 2
  %v19.unpack885 = load i8, ptr %v9.elt377, align 1
  %v19.unpack883 = load i8, ptr %v9.elt375, align 4
  %v19.unpack881 = load i8, ptr %v9.elt373, align 1
  %v19.unpack879 = load i8, ptr %v9.elt371, align 2
  %v19.unpack877 = load i8, ptr %v9.elt369, align 1
  %v19.unpack875 = load i8, ptr %v9.elt367, align 8
  %v19.unpack873 = load i8, ptr %v9.elt365, align 1
  %v19.unpack871 = load i8, ptr %v9.elt363, align 2
  %v19.unpack869 = load i8, ptr %v9.elt361, align 1
  %v19.unpack867 = load i8, ptr %v9.elt359, align 4
  %v19.unpack865 = load i8, ptr %v9.elt357, align 1
  %v19.unpack863 = load i8, ptr %v9.elt355, align 2
  %v19.unpack861 = load i8, ptr %v9.elt353, align 1
  %v19.unpack859 = load i8, ptr %v9.elt351, align 8
  %v19.unpack857 = load i8, ptr %v9.elt349, align 1
  %v19.unpack855 = load i8, ptr %v9.elt347, align 2
  %v19.unpack853 = load i8, ptr %v9.elt345, align 1
  %v19.unpack851 = load i8, ptr %v9.elt343, align 4
  %v19.unpack849 = load i8, ptr %v9.elt341, align 1
  %v19.unpack847 = load i8, ptr %v9.elt339, align 2
  %v19.unpack845 = load i8, ptr %v9.elt337, align 1
  %v19.unpack843 = load i8, ptr %v9.elt335, align 8
  %v19.unpack841 = load i8, ptr %v9.elt333, align 1
  %v19.unpack839 = load i8, ptr %v9.elt331, align 2
  %v19.unpack837 = load i8, ptr %v9.elt329, align 1
  %v19.unpack835 = load i8, ptr %v9.elt327, align 4
  %v19.unpack833 = load i8, ptr %v9.elt325, align 1
  %v19.unpack831 = load i8, ptr %v9.elt323, align 2
  %v19.unpack829 = load i8, ptr %v9.elt321, align 1
  %v19.unpack827 = load i8, ptr %v9.elt319, align 8
  %v19.unpack825 = load i8, ptr %v9.elt317, align 1
  %v19.unpack823 = load i8, ptr %v9.elt315, align 2
  %v19.unpack821 = load i8, ptr %v9.elt313, align 1
  %v19.unpack819 = load i8, ptr %v9.elt311, align 4
  %v19.unpack817 = load i8, ptr %v9.elt309, align 1
  %v19.unpack815 = load i8, ptr %v9.elt307, align 2
  %v19.unpack813 = load i8, ptr %v9.elt305, align 1
  %v19.unpack811 = load i8, ptr %v9.elt303, align 8
  %v19.unpack809 = load i8, ptr %v9.elt301, align 1
  %v19.unpack807 = load i8, ptr %v9.elt299, align 2
  %v19.unpack805 = load i8, ptr %v9.elt297, align 1
  %v19.unpack803 = load i8, ptr %v9.elt295, align 4
  %v19.unpack801 = load i8, ptr %v9.elt293, align 1
  %v19.unpack799 = load i8, ptr %v9.elt291, align 2
  %v19.unpack797 = load i8, ptr %v9.elt289, align 1
  %v19.unpack795 = load i8, ptr %v9.elt287, align 8
  %v19.unpack793 = load i8, ptr %v9.elt285, align 1
  %v19.unpack791 = load i8, ptr %v9.elt283, align 2
  %v19.unpack789 = load i8, ptr %v9.elt281, align 1
  %v19.unpack787 = load i8, ptr %v9.elt279, align 4
  %v19.unpack785 = load i8, ptr %v9.elt277, align 1
  %v19.unpack783 = load i8, ptr %v9.elt275, align 2
  %v19.unpack781 = load i8, ptr %v9.elt273, align 1
  %v19.unpack779 = load i8, ptr %v9.elt271, align 8
  %v19.unpack777 = load i8, ptr %v9.elt269, align 1
  %v19.unpack775 = load i8, ptr %v9.elt267, align 2
  %v19.unpack773 = load i8, ptr %v9.elt265, align 1
  %v19.unpack771 = load i8, ptr %v9.elt263, align 4
  %v19.unpack769 = load i8, ptr %v9.elt261, align 1
  %v19.unpack767 = load i8, ptr %v9.elt259, align 2
  %v19.unpack765 = load i8, ptr %v9.elt257, align 1
  %v19.unpack = load i8, ptr %v9_ptr, align 8
  store i8 %v19.unpack, ptr %v22_scratch, align 1
  %v19.fca.1.gep132 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 1
  store i8 %v19.unpack765, ptr %v19.fca.1.gep132, align 1
  %v19.fca.2.gep134 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 2
  store i8 %v19.unpack767, ptr %v19.fca.2.gep134, align 1
  %v19.fca.3.gep136 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 3
  store i8 %v19.unpack769, ptr %v19.fca.3.gep136, align 1
  %v19.fca.4.gep138 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 4
  store i8 %v19.unpack771, ptr %v19.fca.4.gep138, align 1
  %v19.fca.5.gep140 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 5
  store i8 %v19.unpack773, ptr %v19.fca.5.gep140, align 1
  %v19.fca.6.gep142 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 6
  store i8 %v19.unpack775, ptr %v19.fca.6.gep142, align 1
  %v19.fca.7.gep144 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 7
  store i8 %v19.unpack777, ptr %v19.fca.7.gep144, align 1
  %v19.fca.8.gep146 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 8
  store i8 %v19.unpack779, ptr %v19.fca.8.gep146, align 1
  %v19.fca.9.gep148 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 9
  store i8 %v19.unpack781, ptr %v19.fca.9.gep148, align 1
  %v19.fca.10.gep150 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 10
  store i8 %v19.unpack783, ptr %v19.fca.10.gep150, align 1
  %v19.fca.11.gep152 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 11
  store i8 %v19.unpack785, ptr %v19.fca.11.gep152, align 1
  %v19.fca.12.gep154 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 12
  store i8 %v19.unpack787, ptr %v19.fca.12.gep154, align 1
  %v19.fca.13.gep156 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 13
  store i8 %v19.unpack789, ptr %v19.fca.13.gep156, align 1
  %v19.fca.14.gep158 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 14
  store i8 %v19.unpack791, ptr %v19.fca.14.gep158, align 1
  %v19.fca.15.gep160 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 15
  store i8 %v19.unpack793, ptr %v19.fca.15.gep160, align 1
  %v19.fca.16.gep162 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 16
  store i8 %v19.unpack795, ptr %v19.fca.16.gep162, align 1
  %v19.fca.17.gep164 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 17
  store i8 %v19.unpack797, ptr %v19.fca.17.gep164, align 1
  %v19.fca.18.gep166 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 18
  store i8 %v19.unpack799, ptr %v19.fca.18.gep166, align 1
  %v19.fca.19.gep168 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 19
  store i8 %v19.unpack801, ptr %v19.fca.19.gep168, align 1
  %v19.fca.20.gep170 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 20
  store i8 %v19.unpack803, ptr %v19.fca.20.gep170, align 1
  %v19.fca.21.gep172 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 21
  store i8 %v19.unpack805, ptr %v19.fca.21.gep172, align 1
  %v19.fca.22.gep174 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 22
  store i8 %v19.unpack807, ptr %v19.fca.22.gep174, align 1
  %v19.fca.23.gep176 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 23
  store i8 %v19.unpack809, ptr %v19.fca.23.gep176, align 1
  %v19.fca.24.gep178 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 24
  store i8 %v19.unpack811, ptr %v19.fca.24.gep178, align 1
  %v19.fca.25.gep180 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 25
  store i8 %v19.unpack813, ptr %v19.fca.25.gep180, align 1
  %v19.fca.26.gep182 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 26
  store i8 %v19.unpack815, ptr %v19.fca.26.gep182, align 1
  %v19.fca.27.gep184 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 27
  store i8 %v19.unpack817, ptr %v19.fca.27.gep184, align 1
  %v19.fca.28.gep186 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 28
  store i8 %v19.unpack819, ptr %v19.fca.28.gep186, align 1
  %v19.fca.29.gep188 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 29
  store i8 %v19.unpack821, ptr %v19.fca.29.gep188, align 1
  %v19.fca.30.gep190 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 30
  store i8 %v19.unpack823, ptr %v19.fca.30.gep190, align 1
  %v19.fca.31.gep192 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 31
  store i8 %v19.unpack825, ptr %v19.fca.31.gep192, align 1
  %v19.fca.32.gep194 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 32
  store i8 %v19.unpack827, ptr %v19.fca.32.gep194, align 1
  %v19.fca.33.gep196 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 33
  store i8 %v19.unpack829, ptr %v19.fca.33.gep196, align 1
  %v19.fca.34.gep198 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 34
  store i8 %v19.unpack831, ptr %v19.fca.34.gep198, align 1
  %v19.fca.35.gep200 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 35
  store i8 %v19.unpack833, ptr %v19.fca.35.gep200, align 1
  %v19.fca.36.gep202 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 36
  store i8 %v19.unpack835, ptr %v19.fca.36.gep202, align 1
  %v19.fca.37.gep204 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 37
  store i8 %v19.unpack837, ptr %v19.fca.37.gep204, align 1
  %v19.fca.38.gep206 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 38
  store i8 %v19.unpack839, ptr %v19.fca.38.gep206, align 1
  %v19.fca.39.gep208 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 39
  store i8 %v19.unpack841, ptr %v19.fca.39.gep208, align 1
  %v19.fca.40.gep210 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 40
  store i8 %v19.unpack843, ptr %v19.fca.40.gep210, align 1
  %v19.fca.41.gep212 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 41
  store i8 %v19.unpack845, ptr %v19.fca.41.gep212, align 1
  %v19.fca.42.gep214 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 42
  store i8 %v19.unpack847, ptr %v19.fca.42.gep214, align 1
  %v19.fca.43.gep216 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 43
  store i8 %v19.unpack849, ptr %v19.fca.43.gep216, align 1
  %v19.fca.44.gep218 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 44
  store i8 %v19.unpack851, ptr %v19.fca.44.gep218, align 1
  %v19.fca.45.gep220 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 45
  store i8 %v19.unpack853, ptr %v19.fca.45.gep220, align 1
  %v19.fca.46.gep222 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 46
  store i8 %v19.unpack855, ptr %v19.fca.46.gep222, align 1
  %v19.fca.47.gep224 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 47
  store i8 %v19.unpack857, ptr %v19.fca.47.gep224, align 1
  %v19.fca.48.gep226 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 48
  store i8 %v19.unpack859, ptr %v19.fca.48.gep226, align 1
  %v19.fca.49.gep228 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 49
  store i8 %v19.unpack861, ptr %v19.fca.49.gep228, align 1
  %v19.fca.50.gep230 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 50
  store i8 %v19.unpack863, ptr %v19.fca.50.gep230, align 1
  %v19.fca.51.gep232 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 51
  store i8 %v19.unpack865, ptr %v19.fca.51.gep232, align 1
  %v19.fca.52.gep234 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 52
  store i8 %v19.unpack867, ptr %v19.fca.52.gep234, align 1
  %v19.fca.53.gep236 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 53
  store i8 %v19.unpack869, ptr %v19.fca.53.gep236, align 1
  %v19.fca.54.gep238 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 54
  store i8 %v19.unpack871, ptr %v19.fca.54.gep238, align 1
  %v19.fca.55.gep240 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 55
  store i8 %v19.unpack873, ptr %v19.fca.55.gep240, align 1
  %v19.fca.56.gep242 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 56
  store i8 %v19.unpack875, ptr %v19.fca.56.gep242, align 1
  %v19.fca.57.gep244 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 57
  store i8 %v19.unpack877, ptr %v19.fca.57.gep244, align 1
  %v19.fca.58.gep246 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 58
  store i8 %v19.unpack879, ptr %v19.fca.58.gep246, align 1
  %v19.fca.59.gep248 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 59
  store i8 %v19.unpack881, ptr %v19.fca.59.gep248, align 1
  %v19.fca.60.gep250 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 60
  store i8 %v19.unpack883, ptr %v19.fca.60.gep250, align 1
  %v19.fca.61.gep252 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 61
  store i8 %v19.unpack885, ptr %v19.fca.61.gep252, align 1
  %v19.fca.62.gep254 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 62
  store i8 %v19.unpack887, ptr %v19.fca.62.gep254, align 1
  %v19.fca.63.gep256 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 63
  store i8 %v19.unpack889, ptr %v19.fca.63.gep256, align 1
  %v22_ptr = getelementptr i8, ptr %v22_scratch, i64 %v10_offset
  store i8 2, ptr %v22_ptr, align 1
  %v22.fca.0.load = load i8, ptr %v22_scratch, align 1
  %v22.fca.1.load = load i8, ptr %v19.fca.1.gep132, align 1
  %v22.fca.2.load = load i8, ptr %v19.fca.2.gep134, align 1
  %v22.fca.3.load = load i8, ptr %v19.fca.3.gep136, align 1
  %v22.fca.4.load = load i8, ptr %v19.fca.4.gep138, align 1
  %v22.fca.5.load = load i8, ptr %v19.fca.5.gep140, align 1
  %v22.fca.6.load = load i8, ptr %v19.fca.6.gep142, align 1
  %v22.fca.7.load = load i8, ptr %v19.fca.7.gep144, align 1
  %v22.fca.8.load = load i8, ptr %v19.fca.8.gep146, align 1
  %v22.fca.9.load = load i8, ptr %v19.fca.9.gep148, align 1
  %v22.fca.10.load = load i8, ptr %v19.fca.10.gep150, align 1
  %v22.fca.11.load = load i8, ptr %v19.fca.11.gep152, align 1
  %v22.fca.12.load = load i8, ptr %v19.fca.12.gep154, align 1
  %v22.fca.13.load = load i8, ptr %v19.fca.13.gep156, align 1
  %v22.fca.14.load = load i8, ptr %v19.fca.14.gep158, align 1
  %v22.fca.15.load = load i8, ptr %v19.fca.15.gep160, align 1
  %v22.fca.16.load = load i8, ptr %v19.fca.16.gep162, align 1
  %v22.fca.17.load = load i8, ptr %v19.fca.17.gep164, align 1
  %v22.fca.18.load = load i8, ptr %v19.fca.18.gep166, align 1
  %v22.fca.19.load = load i8, ptr %v19.fca.19.gep168, align 1
  %v22.fca.20.load = load i8, ptr %v19.fca.20.gep170, align 1
  %v22.fca.21.load = load i8, ptr %v19.fca.21.gep172, align 1
  %v22.fca.22.load = load i8, ptr %v19.fca.22.gep174, align 1
  %v22.fca.23.load = load i8, ptr %v19.fca.23.gep176, align 1
  %v22.fca.24.load = load i8, ptr %v19.fca.24.gep178, align 1
  %v22.fca.25.load = load i8, ptr %v19.fca.25.gep180, align 1
  %v22.fca.26.load = load i8, ptr %v19.fca.26.gep182, align 1
  %v22.fca.27.load = load i8, ptr %v19.fca.27.gep184, align 1
  %v22.fca.28.load = load i8, ptr %v19.fca.28.gep186, align 1
  %v22.fca.29.load = load i8, ptr %v19.fca.29.gep188, align 1
  %v22.fca.30.load = load i8, ptr %v19.fca.30.gep190, align 1
  %v22.fca.31.load = load i8, ptr %v19.fca.31.gep192, align 1
  %v22.fca.32.load = load i8, ptr %v19.fca.32.gep194, align 1
  %v22.fca.33.load = load i8, ptr %v19.fca.33.gep196, align 1
  %v22.fca.34.load = load i8, ptr %v19.fca.34.gep198, align 1
  %v22.fca.35.load = load i8, ptr %v19.fca.35.gep200, align 1
  %v22.fca.36.load = load i8, ptr %v19.fca.36.gep202, align 1
  %v22.fca.37.load = load i8, ptr %v19.fca.37.gep204, align 1
  %v22.fca.38.load = load i8, ptr %v19.fca.38.gep206, align 1
  %v22.fca.39.load = load i8, ptr %v19.fca.39.gep208, align 1
  %v22.fca.40.load = load i8, ptr %v19.fca.40.gep210, align 1
  %v22.fca.41.load = load i8, ptr %v19.fca.41.gep212, align 1
  %v22.fca.42.load = load i8, ptr %v19.fca.42.gep214, align 1
  %v22.fca.43.load = load i8, ptr %v19.fca.43.gep216, align 1
  %v22.fca.44.load = load i8, ptr %v19.fca.44.gep218, align 1
  %v22.fca.45.load = load i8, ptr %v19.fca.45.gep220, align 1
  %v22.fca.46.load = load i8, ptr %v19.fca.46.gep222, align 1
  %v22.fca.47.load = load i8, ptr %v19.fca.47.gep224, align 1
  %v22.fca.48.load = load i8, ptr %v19.fca.48.gep226, align 1
  %v22.fca.49.load = load i8, ptr %v19.fca.49.gep228, align 1
  %v22.fca.50.load = load i8, ptr %v19.fca.50.gep230, align 1
  %v22.fca.51.load = load i8, ptr %v19.fca.51.gep232, align 1
  %v22.fca.52.load = load i8, ptr %v19.fca.52.gep234, align 1
  %v22.fca.53.load = load i8, ptr %v19.fca.53.gep236, align 1
  %v22.fca.54.load = load i8, ptr %v19.fca.54.gep238, align 1
  %v22.fca.55.load = load i8, ptr %v19.fca.55.gep240, align 1
  %v22.fca.56.load = load i8, ptr %v19.fca.56.gep242, align 1
  %v22.fca.57.load = load i8, ptr %v19.fca.57.gep244, align 1
  %v22.fca.58.load = load i8, ptr %v19.fca.58.gep246, align 1
  %v22.fca.59.load = load i8, ptr %v19.fca.59.gep248, align 1
  %v22.fca.60.load = load i8, ptr %v19.fca.60.gep250, align 1
  %v22.fca.61.load = load i8, ptr %v19.fca.61.gep252, align 1
  %v22.fca.62.load = load i8, ptr %v19.fca.62.gep254, align 1
  %v22.fca.63.load = load i8, ptr %v19.fca.63.gep256, align 1
  store i8 %v22.fca.0.load, ptr %v9_ptr, align 8
  store i8 %v22.fca.1.load, ptr %v9.elt257, align 1
  store i8 %v22.fca.2.load, ptr %v9.elt259, align 2
  store i8 %v22.fca.3.load, ptr %v9.elt261, align 1
  store i8 %v22.fca.4.load, ptr %v9.elt263, align 4
  store i8 %v22.fca.5.load, ptr %v9.elt265, align 1
  store i8 %v22.fca.6.load, ptr %v9.elt267, align 2
  store i8 %v22.fca.7.load, ptr %v9.elt269, align 1
  store i8 %v22.fca.8.load, ptr %v9.elt271, align 8
  store i8 %v22.fca.9.load, ptr %v9.elt273, align 1
  store i8 %v22.fca.10.load, ptr %v9.elt275, align 2
  store i8 %v22.fca.11.load, ptr %v9.elt277, align 1
  store i8 %v22.fca.12.load, ptr %v9.elt279, align 4
  store i8 %v22.fca.13.load, ptr %v9.elt281, align 1
  store i8 %v22.fca.14.load, ptr %v9.elt283, align 2
  store i8 %v22.fca.15.load, ptr %v9.elt285, align 1
  store i8 %v22.fca.16.load, ptr %v9.elt287, align 8
  store i8 %v22.fca.17.load, ptr %v9.elt289, align 1
  store i8 %v22.fca.18.load, ptr %v9.elt291, align 2
  store i8 %v22.fca.19.load, ptr %v9.elt293, align 1
  store i8 %v22.fca.20.load, ptr %v9.elt295, align 4
  store i8 %v22.fca.21.load, ptr %v9.elt297, align 1
  store i8 %v22.fca.22.load, ptr %v9.elt299, align 2
  store i8 %v22.fca.23.load, ptr %v9.elt301, align 1
  store i8 %v22.fca.24.load, ptr %v9.elt303, align 8
  store i8 %v22.fca.25.load, ptr %v9.elt305, align 1
  store i8 %v22.fca.26.load, ptr %v9.elt307, align 2
  store i8 %v22.fca.27.load, ptr %v9.elt309, align 1
  store i8 %v22.fca.28.load, ptr %v9.elt311, align 4
  store i8 %v22.fca.29.load, ptr %v9.elt313, align 1
  store i8 %v22.fca.30.load, ptr %v9.elt315, align 2
  store i8 %v22.fca.31.load, ptr %v9.elt317, align 1
  store i8 %v22.fca.32.load, ptr %v9.elt319, align 8
  store i8 %v22.fca.33.load, ptr %v9.elt321, align 1
  store i8 %v22.fca.34.load, ptr %v9.elt323, align 2
  store i8 %v22.fca.35.load, ptr %v9.elt325, align 1
  store i8 %v22.fca.36.load, ptr %v9.elt327, align 4
  store i8 %v22.fca.37.load, ptr %v9.elt329, align 1
  store i8 %v22.fca.38.load, ptr %v9.elt331, align 2
  store i8 %v22.fca.39.load, ptr %v9.elt333, align 1
  store i8 %v22.fca.40.load, ptr %v9.elt335, align 8
  store i8 %v22.fca.41.load, ptr %v9.elt337, align 1
  store i8 %v22.fca.42.load, ptr %v9.elt339, align 2
  store i8 %v22.fca.43.load, ptr %v9.elt341, align 1
  store i8 %v22.fca.44.load, ptr %v9.elt343, align 4
  store i8 %v22.fca.45.load, ptr %v9.elt345, align 1
  store i8 %v22.fca.46.load, ptr %v9.elt347, align 2
  store i8 %v22.fca.47.load, ptr %v9.elt349, align 1
  store i8 %v22.fca.48.load, ptr %v9.elt351, align 8
  store i8 %v22.fca.49.load, ptr %v9.elt353, align 1
  store i8 %v22.fca.50.load, ptr %v9.elt355, align 2
  store i8 %v22.fca.51.load, ptr %v9.elt357, align 1
  store i8 %v22.fca.52.load, ptr %v9.elt359, align 4
  store i8 %v22.fca.53.load, ptr %v9.elt361, align 1
  store i8 %v22.fca.54.load, ptr %v9.elt363, align 2
  store i8 %v22.fca.55.load, ptr %v9.elt365, align 1
  store i8 %v22.fca.56.load, ptr %v9.elt367, align 8
  store i8 %v22.fca.57.load, ptr %v9.elt369, align 1
  store i8 %v22.fca.58.load, ptr %v9.elt371, align 2
  store i8 %v22.fca.59.load, ptr %v9.elt373, align 1
  store i8 %v22.fca.60.load, ptr %v9.elt375, align 4
  store i8 %v22.fca.61.load, ptr %v9.elt377, align 1
  store i8 %v22.fca.62.load, ptr %v9.elt379, align 2
  store i8 %v22.fca.63.load, ptr %v9.elt381, align 1
  br label %b9

v25_ok:                                           ; preds = %b3
  %v24.unpack636 = load i8, ptr %v9.elt381, align 1
  %v24.unpack634 = load i8, ptr %v9.elt379, align 2
  %v24.unpack632 = load i8, ptr %v9.elt377, align 1
  %v24.unpack630 = load i8, ptr %v9.elt375, align 4
  %v24.unpack628 = load i8, ptr %v9.elt373, align 1
  %v24.unpack626 = load i8, ptr %v9.elt371, align 2
  %v24.unpack624 = load i8, ptr %v9.elt369, align 1
  %v24.unpack622 = load i8, ptr %v9.elt367, align 8
  %v24.unpack620 = load i8, ptr %v9.elt365, align 1
  %v24.unpack618 = load i8, ptr %v9.elt363, align 2
  %v24.unpack616 = load i8, ptr %v9.elt361, align 1
  %v24.unpack614 = load i8, ptr %v9.elt359, align 4
  %v24.unpack612 = load i8, ptr %v9.elt357, align 1
  %v24.unpack610 = load i8, ptr %v9.elt355, align 2
  %v24.unpack608 = load i8, ptr %v9.elt353, align 1
  %v24.unpack606 = load i8, ptr %v9.elt351, align 8
  %v24.unpack604 = load i8, ptr %v9.elt349, align 1
  %v24.unpack602 = load i8, ptr %v9.elt347, align 2
  %v24.unpack600 = load i8, ptr %v9.elt345, align 1
  %v24.unpack598 = load i8, ptr %v9.elt343, align 4
  %v24.unpack596 = load i8, ptr %v9.elt341, align 1
  %v24.unpack594 = load i8, ptr %v9.elt339, align 2
  %v24.unpack592 = load i8, ptr %v9.elt337, align 1
  %v24.unpack590 = load i8, ptr %v9.elt335, align 8
  %v24.unpack588 = load i8, ptr %v9.elt333, align 1
  %v24.unpack586 = load i8, ptr %v9.elt331, align 2
  %v24.unpack584 = load i8, ptr %v9.elt329, align 1
  %v24.unpack582 = load i8, ptr %v9.elt327, align 4
  %v24.unpack580 = load i8, ptr %v9.elt325, align 1
  %v24.unpack578 = load i8, ptr %v9.elt323, align 2
  %v24.unpack576 = load i8, ptr %v9.elt321, align 1
  %v24.unpack574 = load i8, ptr %v9.elt319, align 8
  %v24.unpack572 = load i8, ptr %v9.elt317, align 1
  %v24.unpack570 = load i8, ptr %v9.elt315, align 2
  %v24.unpack568 = load i8, ptr %v9.elt313, align 1
  %v24.unpack566 = load i8, ptr %v9.elt311, align 4
  %v24.unpack564 = load i8, ptr %v9.elt309, align 1
  %v24.unpack562 = load i8, ptr %v9.elt307, align 2
  %v24.unpack560 = load i8, ptr %v9.elt305, align 1
  %v24.unpack558 = load i8, ptr %v9.elt303, align 8
  %v24.unpack556 = load i8, ptr %v9.elt301, align 1
  %v24.unpack554 = load i8, ptr %v9.elt299, align 2
  %v24.unpack552 = load i8, ptr %v9.elt297, align 1
  %v24.unpack550 = load i8, ptr %v9.elt295, align 4
  %v24.unpack548 = load i8, ptr %v9.elt293, align 1
  %v24.unpack546 = load i8, ptr %v9.elt291, align 2
  %v24.unpack544 = load i8, ptr %v9.elt289, align 1
  %v24.unpack542 = load i8, ptr %v9.elt287, align 8
  %v24.unpack540 = load i8, ptr %v9.elt285, align 1
  %v24.unpack538 = load i8, ptr %v9.elt283, align 2
  %v24.unpack536 = load i8, ptr %v9.elt281, align 1
  %v24.unpack534 = load i8, ptr %v9.elt279, align 4
  %v24.unpack532 = load i8, ptr %v9.elt277, align 1
  %v24.unpack530 = load i8, ptr %v9.elt275, align 2
  %v24.unpack528 = load i8, ptr %v9.elt273, align 1
  %v24.unpack526 = load i8, ptr %v9.elt271, align 8
  %v24.unpack524 = load i8, ptr %v9.elt269, align 1
  %v24.unpack522 = load i8, ptr %v9.elt267, align 2
  %v24.unpack520 = load i8, ptr %v9.elt265, align 1
  %v24.unpack518 = load i8, ptr %v9.elt263, align 4
  %v24.unpack516 = load i8, ptr %v9.elt261, align 1
  %v24.unpack514 = load i8, ptr %v9.elt259, align 2
  %v24.unpack512 = load i8, ptr %v9.elt257, align 1
  %v24.unpack = load i8, ptr %v9_ptr, align 8
  store i8 %v24.unpack, ptr %v27_scratch, align 1
  %v24.fca.1.gep4 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 1
  store i8 %v24.unpack512, ptr %v24.fca.1.gep4, align 1
  %v24.fca.2.gep6 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 2
  store i8 %v24.unpack514, ptr %v24.fca.2.gep6, align 1
  %v24.fca.3.gep8 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 3
  store i8 %v24.unpack516, ptr %v24.fca.3.gep8, align 1
  %v24.fca.4.gep10 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 4
  store i8 %v24.unpack518, ptr %v24.fca.4.gep10, align 1
  %v24.fca.5.gep12 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 5
  store i8 %v24.unpack520, ptr %v24.fca.5.gep12, align 1
  %v24.fca.6.gep14 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 6
  store i8 %v24.unpack522, ptr %v24.fca.6.gep14, align 1
  %v24.fca.7.gep16 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 7
  store i8 %v24.unpack524, ptr %v24.fca.7.gep16, align 1
  %v24.fca.8.gep18 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 8
  store i8 %v24.unpack526, ptr %v24.fca.8.gep18, align 1
  %v24.fca.9.gep20 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 9
  store i8 %v24.unpack528, ptr %v24.fca.9.gep20, align 1
  %v24.fca.10.gep22 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 10
  store i8 %v24.unpack530, ptr %v24.fca.10.gep22, align 1
  %v24.fca.11.gep24 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 11
  store i8 %v24.unpack532, ptr %v24.fca.11.gep24, align 1
  %v24.fca.12.gep26 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 12
  store i8 %v24.unpack534, ptr %v24.fca.12.gep26, align 1
  %v24.fca.13.gep28 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 13
  store i8 %v24.unpack536, ptr %v24.fca.13.gep28, align 1
  %v24.fca.14.gep30 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 14
  store i8 %v24.unpack538, ptr %v24.fca.14.gep30, align 1
  %v24.fca.15.gep32 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 15
  store i8 %v24.unpack540, ptr %v24.fca.15.gep32, align 1
  %v24.fca.16.gep34 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 16
  store i8 %v24.unpack542, ptr %v24.fca.16.gep34, align 1
  %v24.fca.17.gep36 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 17
  store i8 %v24.unpack544, ptr %v24.fca.17.gep36, align 1
  %v24.fca.18.gep38 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 18
  store i8 %v24.unpack546, ptr %v24.fca.18.gep38, align 1
  %v24.fca.19.gep40 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 19
  store i8 %v24.unpack548, ptr %v24.fca.19.gep40, align 1
  %v24.fca.20.gep42 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 20
  store i8 %v24.unpack550, ptr %v24.fca.20.gep42, align 1
  %v24.fca.21.gep44 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 21
  store i8 %v24.unpack552, ptr %v24.fca.21.gep44, align 1
  %v24.fca.22.gep46 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 22
  store i8 %v24.unpack554, ptr %v24.fca.22.gep46, align 1
  %v24.fca.23.gep48 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 23
  store i8 %v24.unpack556, ptr %v24.fca.23.gep48, align 1
  %v24.fca.24.gep50 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 24
  store i8 %v24.unpack558, ptr %v24.fca.24.gep50, align 1
  %v24.fca.25.gep52 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 25
  store i8 %v24.unpack560, ptr %v24.fca.25.gep52, align 1
  %v24.fca.26.gep54 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 26
  store i8 %v24.unpack562, ptr %v24.fca.26.gep54, align 1
  %v24.fca.27.gep56 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 27
  store i8 %v24.unpack564, ptr %v24.fca.27.gep56, align 1
  %v24.fca.28.gep58 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 28
  store i8 %v24.unpack566, ptr %v24.fca.28.gep58, align 1
  %v24.fca.29.gep60 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 29
  store i8 %v24.unpack568, ptr %v24.fca.29.gep60, align 1
  %v24.fca.30.gep62 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 30
  store i8 %v24.unpack570, ptr %v24.fca.30.gep62, align 1
  %v24.fca.31.gep64 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 31
  store i8 %v24.unpack572, ptr %v24.fca.31.gep64, align 1
  %v24.fca.32.gep66 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 32
  store i8 %v24.unpack574, ptr %v24.fca.32.gep66, align 1
  %v24.fca.33.gep68 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 33
  store i8 %v24.unpack576, ptr %v24.fca.33.gep68, align 1
  %v24.fca.34.gep70 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 34
  store i8 %v24.unpack578, ptr %v24.fca.34.gep70, align 1
  %v24.fca.35.gep72 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 35
  store i8 %v24.unpack580, ptr %v24.fca.35.gep72, align 1
  %v24.fca.36.gep74 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 36
  store i8 %v24.unpack582, ptr %v24.fca.36.gep74, align 1
  %v24.fca.37.gep76 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 37
  store i8 %v24.unpack584, ptr %v24.fca.37.gep76, align 1
  %v24.fca.38.gep78 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 38
  store i8 %v24.unpack586, ptr %v24.fca.38.gep78, align 1
  %v24.fca.39.gep80 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 39
  store i8 %v24.unpack588, ptr %v24.fca.39.gep80, align 1
  %v24.fca.40.gep82 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 40
  store i8 %v24.unpack590, ptr %v24.fca.40.gep82, align 1
  %v24.fca.41.gep84 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 41
  store i8 %v24.unpack592, ptr %v24.fca.41.gep84, align 1
  %v24.fca.42.gep86 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 42
  store i8 %v24.unpack594, ptr %v24.fca.42.gep86, align 1
  %v24.fca.43.gep88 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 43
  store i8 %v24.unpack596, ptr %v24.fca.43.gep88, align 1
  %v24.fca.44.gep90 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 44
  store i8 %v24.unpack598, ptr %v24.fca.44.gep90, align 1
  %v24.fca.45.gep92 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 45
  store i8 %v24.unpack600, ptr %v24.fca.45.gep92, align 1
  %v24.fca.46.gep94 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 46
  store i8 %v24.unpack602, ptr %v24.fca.46.gep94, align 1
  %v24.fca.47.gep96 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 47
  store i8 %v24.unpack604, ptr %v24.fca.47.gep96, align 1
  %v24.fca.48.gep98 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 48
  store i8 %v24.unpack606, ptr %v24.fca.48.gep98, align 1
  %v24.fca.49.gep100 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 49
  store i8 %v24.unpack608, ptr %v24.fca.49.gep100, align 1
  %v24.fca.50.gep102 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 50
  store i8 %v24.unpack610, ptr %v24.fca.50.gep102, align 1
  %v24.fca.51.gep104 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 51
  store i8 %v24.unpack612, ptr %v24.fca.51.gep104, align 1
  %v24.fca.52.gep106 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 52
  store i8 %v24.unpack614, ptr %v24.fca.52.gep106, align 1
  %v24.fca.53.gep108 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 53
  store i8 %v24.unpack616, ptr %v24.fca.53.gep108, align 1
  %v24.fca.54.gep110 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 54
  store i8 %v24.unpack618, ptr %v24.fca.54.gep110, align 1
  %v24.fca.55.gep112 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 55
  store i8 %v24.unpack620, ptr %v24.fca.55.gep112, align 1
  %v24.fca.56.gep114 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 56
  store i8 %v24.unpack622, ptr %v24.fca.56.gep114, align 1
  %v24.fca.57.gep116 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 57
  store i8 %v24.unpack624, ptr %v24.fca.57.gep116, align 1
  %v24.fca.58.gep118 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 58
  store i8 %v24.unpack626, ptr %v24.fca.58.gep118, align 1
  %v24.fca.59.gep120 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 59
  store i8 %v24.unpack628, ptr %v24.fca.59.gep120, align 1
  %v24.fca.60.gep122 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 60
  store i8 %v24.unpack630, ptr %v24.fca.60.gep122, align 1
  %v24.fca.61.gep124 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 61
  store i8 %v24.unpack632, ptr %v24.fca.61.gep124, align 1
  %v24.fca.62.gep126 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 62
  store i8 %v24.unpack634, ptr %v24.fca.62.gep126, align 1
  %v24.fca.63.gep128 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 63
  store i8 %v24.unpack636, ptr %v24.fca.63.gep128, align 1
  %v27_ptr = getelementptr i8, ptr %v27_scratch, i64 %v10_offset
  store i8 7, ptr %v27_ptr, align 1
  %v27.fca.0.load = load i8, ptr %v27_scratch, align 1
  %v27.fca.1.load = load i8, ptr %v24.fca.1.gep4, align 1
  %v27.fca.2.load = load i8, ptr %v24.fca.2.gep6, align 1
  %v27.fca.3.load = load i8, ptr %v24.fca.3.gep8, align 1
  %v27.fca.4.load = load i8, ptr %v24.fca.4.gep10, align 1
  %v27.fca.5.load = load i8, ptr %v24.fca.5.gep12, align 1
  %v27.fca.6.load = load i8, ptr %v24.fca.6.gep14, align 1
  %v27.fca.7.load = load i8, ptr %v24.fca.7.gep16, align 1
  %v27.fca.8.load = load i8, ptr %v24.fca.8.gep18, align 1
  %v27.fca.9.load = load i8, ptr %v24.fca.9.gep20, align 1
  %v27.fca.10.load = load i8, ptr %v24.fca.10.gep22, align 1
  %v27.fca.11.load = load i8, ptr %v24.fca.11.gep24, align 1
  %v27.fca.12.load = load i8, ptr %v24.fca.12.gep26, align 1
  %v27.fca.13.load = load i8, ptr %v24.fca.13.gep28, align 1
  %v27.fca.14.load = load i8, ptr %v24.fca.14.gep30, align 1
  %v27.fca.15.load = load i8, ptr %v24.fca.15.gep32, align 1
  %v27.fca.16.load = load i8, ptr %v24.fca.16.gep34, align 1
  %v27.fca.17.load = load i8, ptr %v24.fca.17.gep36, align 1
  %v27.fca.18.load = load i8, ptr %v24.fca.18.gep38, align 1
  %v27.fca.19.load = load i8, ptr %v24.fca.19.gep40, align 1
  %v27.fca.20.load = load i8, ptr %v24.fca.20.gep42, align 1
  %v27.fca.21.load = load i8, ptr %v24.fca.21.gep44, align 1
  %v27.fca.22.load = load i8, ptr %v24.fca.22.gep46, align 1
  %v27.fca.23.load = load i8, ptr %v24.fca.23.gep48, align 1
  %v27.fca.24.load = load i8, ptr %v24.fca.24.gep50, align 1
  %v27.fca.25.load = load i8, ptr %v24.fca.25.gep52, align 1
  %v27.fca.26.load = load i8, ptr %v24.fca.26.gep54, align 1
  %v27.fca.27.load = load i8, ptr %v24.fca.27.gep56, align 1
  %v27.fca.28.load = load i8, ptr %v24.fca.28.gep58, align 1
  %v27.fca.29.load = load i8, ptr %v24.fca.29.gep60, align 1
  %v27.fca.30.load = load i8, ptr %v24.fca.30.gep62, align 1
  %v27.fca.31.load = load i8, ptr %v24.fca.31.gep64, align 1
  %v27.fca.32.load = load i8, ptr %v24.fca.32.gep66, align 1
  %v27.fca.33.load = load i8, ptr %v24.fca.33.gep68, align 1
  %v27.fca.34.load = load i8, ptr %v24.fca.34.gep70, align 1
  %v27.fca.35.load = load i8, ptr %v24.fca.35.gep72, align 1
  %v27.fca.36.load = load i8, ptr %v24.fca.36.gep74, align 1
  %v27.fca.37.load = load i8, ptr %v24.fca.37.gep76, align 1
  %v27.fca.38.load = load i8, ptr %v24.fca.38.gep78, align 1
  %v27.fca.39.load = load i8, ptr %v24.fca.39.gep80, align 1
  %v27.fca.40.load = load i8, ptr %v24.fca.40.gep82, align 1
  %v27.fca.41.load = load i8, ptr %v24.fca.41.gep84, align 1
  %v27.fca.42.load = load i8, ptr %v24.fca.42.gep86, align 1
  %v27.fca.43.load = load i8, ptr %v24.fca.43.gep88, align 1
  %v27.fca.44.load = load i8, ptr %v24.fca.44.gep90, align 1
  %v27.fca.45.load = load i8, ptr %v24.fca.45.gep92, align 1
  %v27.fca.46.load = load i8, ptr %v24.fca.46.gep94, align 1
  %v27.fca.47.load = load i8, ptr %v24.fca.47.gep96, align 1
  %v27.fca.48.load = load i8, ptr %v24.fca.48.gep98, align 1
  %v27.fca.49.load = load i8, ptr %v24.fca.49.gep100, align 1
  %v27.fca.50.load = load i8, ptr %v24.fca.50.gep102, align 1
  %v27.fca.51.load = load i8, ptr %v24.fca.51.gep104, align 1
  %v27.fca.52.load = load i8, ptr %v24.fca.52.gep106, align 1
  %v27.fca.53.load = load i8, ptr %v24.fca.53.gep108, align 1
  %v27.fca.54.load = load i8, ptr %v24.fca.54.gep110, align 1
  %v27.fca.55.load = load i8, ptr %v24.fca.55.gep112, align 1
  %v27.fca.56.load = load i8, ptr %v24.fca.56.gep114, align 1
  %v27.fca.57.load = load i8, ptr %v24.fca.57.gep116, align 1
  %v27.fca.58.load = load i8, ptr %v24.fca.58.gep118, align 1
  %v27.fca.59.load = load i8, ptr %v24.fca.59.gep120, align 1
  %v27.fca.60.load = load i8, ptr %v24.fca.60.gep122, align 1
  %v27.fca.61.load = load i8, ptr %v24.fca.61.gep124, align 1
  %v27.fca.62.load = load i8, ptr %v24.fca.62.gep126, align 1
  %v27.fca.63.load = load i8, ptr %v24.fca.63.gep128, align 1
  store i8 %v27.fca.0.load, ptr %v9_ptr, align 8
  store i8 %v27.fca.1.load, ptr %v9.elt257, align 1
  store i8 %v27.fca.2.load, ptr %v9.elt259, align 2
  store i8 %v27.fca.3.load, ptr %v9.elt261, align 1
  store i8 %v27.fca.4.load, ptr %v9.elt263, align 4
  store i8 %v27.fca.5.load, ptr %v9.elt265, align 1
  store i8 %v27.fca.6.load, ptr %v9.elt267, align 2
  store i8 %v27.fca.7.load, ptr %v9.elt269, align 1
  store i8 %v27.fca.8.load, ptr %v9.elt271, align 8
  store i8 %v27.fca.9.load, ptr %v9.elt273, align 1
  store i8 %v27.fca.10.load, ptr %v9.elt275, align 2
  store i8 %v27.fca.11.load, ptr %v9.elt277, align 1
  store i8 %v27.fca.12.load, ptr %v9.elt279, align 4
  store i8 %v27.fca.13.load, ptr %v9.elt281, align 1
  store i8 %v27.fca.14.load, ptr %v9.elt283, align 2
  store i8 %v27.fca.15.load, ptr %v9.elt285, align 1
  store i8 %v27.fca.16.load, ptr %v9.elt287, align 8
  store i8 %v27.fca.17.load, ptr %v9.elt289, align 1
  store i8 %v27.fca.18.load, ptr %v9.elt291, align 2
  store i8 %v27.fca.19.load, ptr %v9.elt293, align 1
  store i8 %v27.fca.20.load, ptr %v9.elt295, align 4
  store i8 %v27.fca.21.load, ptr %v9.elt297, align 1
  store i8 %v27.fca.22.load, ptr %v9.elt299, align 2
  store i8 %v27.fca.23.load, ptr %v9.elt301, align 1
  store i8 %v27.fca.24.load, ptr %v9.elt303, align 8
  store i8 %v27.fca.25.load, ptr %v9.elt305, align 1
  store i8 %v27.fca.26.load, ptr %v9.elt307, align 2
  store i8 %v27.fca.27.load, ptr %v9.elt309, align 1
  store i8 %v27.fca.28.load, ptr %v9.elt311, align 4
  store i8 %v27.fca.29.load, ptr %v9.elt313, align 1
  store i8 %v27.fca.30.load, ptr %v9.elt315, align 2
  store i8 %v27.fca.31.load, ptr %v9.elt317, align 1
  store i8 %v27.fca.32.load, ptr %v9.elt319, align 8
  store i8 %v27.fca.33.load, ptr %v9.elt321, align 1
  store i8 %v27.fca.34.load, ptr %v9.elt323, align 2
  store i8 %v27.fca.35.load, ptr %v9.elt325, align 1
  store i8 %v27.fca.36.load, ptr %v9.elt327, align 4
  store i8 %v27.fca.37.load, ptr %v9.elt329, align 1
  store i8 %v27.fca.38.load, ptr %v9.elt331, align 2
  store i8 %v27.fca.39.load, ptr %v9.elt333, align 1
  store i8 %v27.fca.40.load, ptr %v9.elt335, align 8
  store i8 %v27.fca.41.load, ptr %v9.elt337, align 1
  store i8 %v27.fca.42.load, ptr %v9.elt339, align 2
  store i8 %v27.fca.43.load, ptr %v9.elt341, align 1
  store i8 %v27.fca.44.load, ptr %v9.elt343, align 4
  store i8 %v27.fca.45.load, ptr %v9.elt345, align 1
  store i8 %v27.fca.46.load, ptr %v9.elt347, align 2
  store i8 %v27.fca.47.load, ptr %v9.elt349, align 1
  store i8 %v27.fca.48.load, ptr %v9.elt351, align 8
  store i8 %v27.fca.49.load, ptr %v9.elt353, align 1
  store i8 %v27.fca.50.load, ptr %v9.elt355, align 2
  store i8 %v27.fca.51.load, ptr %v9.elt357, align 1
  store i8 %v27.fca.52.load, ptr %v9.elt359, align 4
  store i8 %v27.fca.53.load, ptr %v9.elt361, align 1
  store i8 %v27.fca.54.load, ptr %v9.elt363, align 2
  store i8 %v27.fca.55.load, ptr %v9.elt365, align 1
  store i8 %v27.fca.56.load, ptr %v9.elt367, align 8
  store i8 %v27.fca.57.load, ptr %v9.elt369, align 1
  store i8 %v27.fca.58.load, ptr %v9.elt371, align 2
  store i8 %v27.fca.59.load, ptr %v9.elt373, align 1
  store i8 %v27.fca.60.load, ptr %v9.elt375, align 4
  store i8 %v27.fca.61.load, ptr %v9.elt377, align 1
  store i8 %v27.fca.62.load, ptr %v9.elt379, align 2
  store i8 %v27.fca.63.load, ptr %v9.elt381, align 1
  br label %b9

b9:                                               ; preds = %v25_ok, %v20_ok, %b1
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @example_entry() local_unnamed_addr #6 {
entry:
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @stream_start(ptr nofree writeonly captures(none) initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %out) local_unnamed_addr #4 {
  %v16_mem.sroa.75.sroa.0.i = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0.i = alloca i8, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  store i1 false, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  store i1 false, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %v16_mem.sroa.5.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 28
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %out, i8 0, i64 28, i1 false)
  store i8 -128, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.6.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 29
  store i8 -65, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx.i, align 1
  %v16_mem.sroa.71.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 32
  store i32 0, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx.i, align 8
  %v16_mem.sroa.82.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 40
  %v16_mem.sroa.75.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 124
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %v16_mem.sroa.82.0.return_storage.sroa_idx.i, i8 0, i64 84, i1 false)
  %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i = load i8, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  store i8 %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i, ptr %v16_mem.sroa.75.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.764.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 128
  store i32 0, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx.i, align 8
  %v16_mem.sroa.77.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 132
  %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i = load i8, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  store i8 %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i, ptr %v16_mem.sroa.77.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.785.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 136
  %v16_mem.sroa.857.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 176
  store i64 0, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %v16_mem.sroa.785.0.return_storage.sroa_idx.i, i8 0, i64 36, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  ret void
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write, target_mem: none)
define void @stream_feed(ptr %state, ptr %bytes, i32 %length) local_unnamed_addr #5 {
  %a = insertvalue { ptr, i32 } zeroinitializer, ptr %bytes, 0
  %v = insertvalue { ptr, i32 } %a, i32 %length, 1
  %code = tail call i32 @liza_json.feed_mut(ptr %state, { ptr, i32 } %v)
  ret void
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i32 0, 9) i32 @stream_status(ptr nofree readonly captures(none) %state) local_unnamed_addr #2 {
liza_status.exit:
  %v0.i = tail call %variant.5 @liza_json.finish(ptr readonly %state)
  %v1.i = extractvalue %variant.5 %v0.i, 0
  %0 = icmp eq i32 %v1.i, 0
  %v4.i = extractvalue %variant.5 %v0.i, 2
  %v5.i = extractvalue %struct.JsonError %v4.i, 0
  %v6.i = extractvalue %variant.1 %v5.i, 0
  %switch.offset = add nsw i32 %v6.i, 1
  %common.ret.op.i = select i1 %0, i32 0, i32 %switch.offset
  ret i32 %common.ret.op.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define range(i32 0, 2) i32 @stream_pending(ptr nofree readonly captures(none) %state) local_unnamed_addr #3 {
  %v0_ptr.i.i = getelementptr i8, ptr %state, i64 168
  %v0.i.i = load i32, ptr %v0_ptr.i.i, align 4
  %v2.i.not.i = icmp ne i32 %v0.i.i, 0
  %spec.select.i = zext i1 %v2.i.not.i to i32
  ret i32 %spec.select.i
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @stream_value(ptr nofree readonly captures(none) %state) local_unnamed_addr #2 {
  %v0.i = tail call %variant.5 @liza_json.finish(ptr readonly %state)
  %v1.i = extractvalue %variant.5 %v0.i, 0
  %1 = icmp eq i32 %v1.i, 0
  %v2.i = extractvalue %variant.5 %v0.i, 1
  %v3.i = extractvalue %variant.5 %v0.i, 2
  %v4.i = extractvalue %struct.JsonError %v3.i, 1
  %common.ret.op.i = select i1 %1, i64 %v2.i, i64 %v4.i
  ret i64 %common.ret.op.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i64 @stream_size() local_unnamed_addr #6 {
  ret i64 184
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #8

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #9

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #8

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #8

attributes #0 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind memory(argmem: readwrite, inaccessiblemem: write) }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) }
attributes #5 = { nounwind memory(read, argmem: readwrite, inaccessiblemem: write, target_mem: none) }
attributes #6 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
attributes #7 = { nounwind memory(inaccessiblemem: write) }
attributes #8 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #9 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
