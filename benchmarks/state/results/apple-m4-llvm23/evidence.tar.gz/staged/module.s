	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_status                    ; -- Begin function liza_status
	.p2align	2
_liza_status:                           ; @liza_status
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csinc	w0, wzr, w2, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_liza_value                     ; -- Begin function liza_value
	.p2align	2
_liza_value:                            ; @liza_value
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csel	x0, x1, x3, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_liza_pending                   ; -- Begin function liza_pending
	.p2align	2
_liza_pending:                          ; @liza_pending
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_liza_start                     ; -- Begin function liza_start
	.p2align	2
_liza_start:                            ; @liza_start
; %bb.0:                                ; %b0
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w9, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x8]
	str	wzr, [x8, #24]
	str	xzr, [x8, #16]
	strh	w9, [x8, #28]
	str	wzr, [x8, #32]
	stur	q0, [x8, #40]
	stur	q0, [x8, #56]
	stur	q0, [x8, #72]
	stur	q0, [x8, #88]
	stur	q0, [x8, #104]
	str	wzr, [x8, #120]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	stur	q0, [x8, #136]
	stur	q0, [x8, #152]
	str	wzr, [x8, #168]
	str	xzr, [x8, #176]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_liza_feed                      ; -- Begin function liza_feed
	.p2align	2
_liza_feed:                             ; @liza_feed
; %bb.0:                                ; %b0
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	w0, [x0, #168]
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	cbz	w0, LBB4_2
LBB4_1:                                 ; %liza_json.feed_mut.exit
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB4_2:                                 ; %b4.preheader.i
	mov	x20, x1
	mov	w22, w2
	mov	x23, #4294967296                ; =0x100000000
LBB4_3:                                 ; %b4.i
                                        ; =>This Inner Loop Header: Depth=1
	cbz	x22, LBB4_13
; %bb.4:                                ; %v10_ok.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldp	x1, x2, [x19, #8]
	ldr	x7, [x19, #40]
	ldrb	w21, [x20], #1
	ldr	w6, [x19, #32]
	ldr	w3, [x19, #24]
	ldr	x0, [x19]
	ldrb	w5, [x19, #29]
	ldrb	w4, [x19, #28]
	strb	w21, [sp]
	bl	_liza_utf8_stream.feed_byte
	cmp	w6, #2
	stp	x0, x1, [x19]
	str	x2, [x19, #16]
	str	w3, [x19, #24]
	strb	w4, [x19, #28]
	strb	w5, [x19, #29]
	str	w6, [x19, #32]
	str	x7, [x19, #40]
	b.eq	LBB4_7
; %bb.5:                                ; %v10_ok.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w6, #1
	b.ne	LBB4_8
; %bb.6:                                ; %b1.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, wzr
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB4_9
	b	LBB4_14
LBB4_7:                                 ; %b4.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, wzr
	mov	w8, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB4_9
	b	LBB4_14
LBB4_8:                                 ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, wzr
	mov	x7, xzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB4_14
LBB4_9:                                 ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w0, w21
	mov	x1, x19
	bl	_liza___liza_json_mut_step
	ldr	w0, [x19, #168]
	cbnz	w0, LBB4_1
; %bb.10:                               ; %b16.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	x8, [x19, #48]
	adds	x8, x8, #1
	b.hs	LBB4_12
; %bb.11:                               ; %v46_ok.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	x23, x23, #1
	sub	x22, x22, #1
	str	x8, [x19, #48]
	cbnz	x23, LBB4_3
LBB4_12:                                ; %v46_trap.i
	brk	#0x1
LBB4_13:
	mov	w0, wzr
	b	LBB4_1
LBB4_14:                                ; %b9.i
	cmp	w8, #0
	mov	w8, #8                          ; =0x8
	mov	w9, #5                          ; =0x5
	csel	w0, w9, w8, eq
	str	x7, [x19, #176]
	str	w0, [x19, #168]
	b	LBB4_1
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
; %bb.0:                                ; %b0
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.create        ; -- Begin function liza_utf8_stream.create
	.p2align	2
_liza_utf8_stream.create:               ; @liza_utf8_stream.create
; %bb.0:                                ; %b0
	mov	x0, xzr
	mov	x1, xzr
	mov	x2, xzr
	mov	w3, wzr
	mov	w4, #128                        ; =0x80
	mov	w5, #191                        ; =0xbf
	mov	w6, wzr
	mov	x7, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.feed_byte     ; -- Begin function liza_utf8_stream.feed_byte
	.p2align	2
_liza_utf8_stream.feed_byte:            ; @liza_utf8_stream.feed_byte
; %bb.0:                                ; %b0
	cbz	w6, LBB7_2
LBB7_1:                                 ; %common.ret
	ret
LBB7_2:                                 ; %b3
	cmn	x0, #1
	b.eq	LBB7_6
; %bb.3:                                ; %b6
	ldrb	w8, [sp]
	cbz	w3, LBB7_7
; %bb.4:                                ; %b8
	and	w8, w8, #0xff
	and	w9, w4, #0xff
	cmp	w8, w5, uxtb
	ccmp	w8, w9, #0, ls
	b.hs	LBB7_10
; %bb.5:                                ; %b48
	mov	w6, #1                          ; =0x1
	mov	x7, x2
	ret
LBB7_6:                                 ; %b4
	mov	x7, #-1                         ; =0xffffffffffffffff
	mov	w6, #2                          ; =0x2
	ret
LBB7_7:                                 ; %b7
	tbnz	w8, #7, LBB7_13
; %bb.8:                                ; %b9
	cmn	x1, #1
	b.eq	LBB7_15
; %bb.9:                                ; %v32_ok
	add	x1, x1, #1
	mov	x2, x0
	b	LBB7_23
LBB7_10:                                ; %v115_ok
	subs	w3, w3, #1
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	b.ne	LBB7_23
; %bb.11:                               ; %b51
	cmn	x1, #1
	b.eq	LBB7_19
; %bb.12:                               ; %v138_ok
	add	x1, x1, #1
	b	LBB7_23
LBB7_13:                                ; %b10
	add	w9, w8, #62
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	and	w9, w9, #0xff
	cmp	w9, #30
	b.hs	LBB7_17
; %bb.14:                               ; %b17
	mov	w3, #1                          ; =0x1
	mov	x2, x0
	b	LBB7_23
LBB7_15:                                ; %b11
	mov	w6, #2                          ; =0x2
LBB7_16:                                ; %common.ret
	mov	x2, x0
	mov	x7, x0
	ret
LBB7_17:                                ; %b18
	and	w9, w8, #0xf0
	cmp	w9, #224
	b.ne	LBB7_20
; %bb.18:                               ; %b22
	and	w8, w8, #0xff
	mov	w9, #-96                        ; =0xffffffa0
	mov	w3, #2                          ; =0x2
	cmp	w8, #224
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #237
	mov	w8, #-97                        ; =0xffffff9f
	b	LBB7_22
LBB7_19:                                ; %b53
	mov	w6, #2                          ; =0x2
	mov	x7, x0
	ret
LBB7_20:                                ; %b23
	add	w9, w8, #16
	and	w9, w9, #0xff
	cmp	w9, #4
	b.hi	LBB7_25
; %bb.21:                               ; %b33
	and	w8, w8, #0xff
	mov	w9, #-112                       ; =0xffffff90
	mov	w3, #3                          ; =0x3
	cmp	w8, #240
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #244
	mov	w8, #-113                       ; =0xffffff8f
LBB7_22:                                ; %b57
	csel	w5, w8, w5, eq
LBB7_23:                                ; %b57
	adds	x0, x0, #1
	b.lo	LBB7_1
; %bb.24:                               ; %v145_trap
	brk	#0x1
LBB7_25:                                ; %b34
	mov	w6, #1                          ; =0x1
	b	LBB7_16
                                        ; -- End function
	.globl	_liza_utf8_stream.finish        ; -- Begin function liza_utf8_stream.finish
	.p2align	2
_liza_utf8_stream.finish:               ; @liza_utf8_stream.finish
; %bb.0:                                ; %b0
	cmp	w6, #1
	b.eq	LBB8_3
; %bb.1:                                ; %b0
	cmp	w6, #2
	b.ne	LBB8_4
; %bb.2:                                ; %b4
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_3:                                 ; %b1
	mov	x1, xzr
	b	LBB8_6
LBB8_4:                                 ; %b6
	cbz	w3, LBB8_7
; %bb.5:                                ; %b7
	mov	x1, xzr
	mov	x7, x2
LBB8_6:                                 ; %common.ret
	mov	w2, wzr
	mov	w0, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_7:                                 ; %b9
	mov	w0, wzr
	mov	w2, wzr
	mov	x3, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.status        ; -- Begin function liza_utf8_stream.status
	.p2align	2
_liza_utf8_stream.status:               ; @liza_utf8_stream.status
; %bb.0:                                ; %b0
	cmp	w6, #2
	cset	w8, ne
	cset	w9, eq
	csel	x10, x7, xzr, eq
	cmp	w6, #1
	csel	w0, wzr, w8, eq
	csel	w1, wzr, w9, eq
	csel	x2, x7, x10, eq
	ret
                                        ; -- End function
	.globl	_liza_json.create               ; -- Begin function liza_json.create
	.p2align	2
_liza_json.create:                      ; @liza_json.create
; %bb.0:                                ; %b0
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w9, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8]
	str	wzr, [x8, #24]
	strh	w9, [x8, #28]
	str	wzr, [x8, #32]
	stur	q0, [x8, #40]
	stur	q0, [x8, #56]
	stur	q0, [x8, #72]
	stur	q0, [x8, #88]
	stur	q0, [x8, #104]
	str	wzr, [x8, #120]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	str	xzr, [x8, #176]
	str	wzr, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_liza___liza_json_done          ; -- Begin function liza___liza_json_done
	.p2align	2
_liza___liza_json_done:                 ; @liza___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #624
	ldr	w20, [x0, #120]
	add	x12, sp, #304
	cbz	w20, LBB11_5
; %bb.1:                                ; %b2
	ldrb	w9, [x0, #57]
	ldrb	w10, [x0, #59]
	sub	w21, w20, #1
	ldrb	w11, [x0, #61]
	ldrb	w23, [x0, #56]
	cmp	w21, #64
	stp	w10, w9, [sp, #168]             ; 8-byte Folded Spill
	ldrb	w22, [x0, #58]
	ldrb	w24, [x0, #98]
	strb	w9, [sp, #177]
	ldrb	w9, [x0, #60]
	ldrb	w25, [x0, #99]
	strb	w10, [sp, #179]
	ldrb	w10, [x0, #62]
	ldrb	w26, [x0, #100]
	stp	w11, w9, [sp, #160]             ; 8-byte Folded Spill
	ldrb	w27, [x0, #101]
	ldrb	w28, [x0, #102]
	strb	w9, [sp, #180]
	ldrb	w9, [x0, #63]
	ldrb	w30, [x0, #103]
	strb	w11, [sp, #181]
	ldrb	w11, [x0, #64]
	ldrb	w12, [x0, #107]
	stp	w9, w10, [sp, #152]             ; 8-byte Folded Spill
	ldrb	w13, [x0, #108]
	ldrb	w14, [x0, #109]
	strb	w10, [sp, #182]
	ldrb	w10, [x0, #65]
	ldrb	w15, [x0, #110]
	strb	w9, [sp, #183]
	ldrb	w9, [x0, #66]
	ldrb	w16, [x0, #111]
	stp	w10, w11, [sp, #144]            ; 8-byte Folded Spill
	ldrb	w17, [x0, #112]
	ldrb	w2, [x0, #113]
	strb	w11, [sp, #184]
	ldrb	w11, [x0, #67]
	ldrb	w3, [x0, #114]
	strb	w10, [sp, #185]
	ldrb	w10, [x0, #68]
	ldrb	w4, [x0, #115]
	stp	w11, w9, [sp, #136]             ; 8-byte Folded Spill
	ldrb	w5, [x0, #116]
	ldrb	w6, [x0, #117]
	strb	w9, [sp, #186]
	ldrb	w9, [x0, #69]
	ldrb	w7, [x0, #118]
	strb	w11, [sp, #187]
	ldrb	w11, [x0, #70]
	ldrb	w19, [x0, #119]
	stp	w9, w10, [sp, #128]             ; 8-byte Folded Spill
	strb	w10, [sp, #188]
	ldrb	w10, [x0, #71]
	strb	w9, [sp, #189]
	ldrb	w9, [x0, #72]
	stp	w10, w11, [sp, #120]            ; 8-byte Folded Spill
	strb	w11, [sp, #190]
	ldrb	w11, [x0, #73]
	strb	w10, [sp, #191]
	ldrb	w10, [x0, #74]
	stp	w11, w9, [sp, #112]             ; 8-byte Folded Spill
	strb	w9, [sp, #192]
	ldrb	w9, [x0, #75]
	strb	w11, [sp, #193]
	ldrb	w11, [x0, #76]
	stp	w9, w10, [sp, #104]             ; 8-byte Folded Spill
	strb	w10, [sp, #194]
	ldrb	w10, [x0, #77]
	strb	w9, [sp, #195]
	ldrb	w9, [x0, #78]
	stp	w10, w11, [sp, #96]             ; 8-byte Folded Spill
	strb	w11, [sp, #196]
	ldrb	w11, [x0, #79]
	strb	w10, [sp, #197]
	ldrb	w10, [x0, #80]
	stp	w11, w9, [sp, #88]              ; 8-byte Folded Spill
	strb	w9, [sp, #198]
	ldrb	w9, [x0, #81]
	strb	w11, [sp, #199]
	ldrb	w11, [x0, #82]
	stp	w9, w10, [sp, #80]              ; 8-byte Folded Spill
	strb	w10, [sp, #200]
	ldrb	w10, [x0, #83]
	strb	w9, [sp, #201]
	ldrb	w9, [x0, #84]
	stp	w10, w11, [sp, #72]             ; 8-byte Folded Spill
	strb	w11, [sp, #202]
	ldrb	w11, [x0, #85]
	strb	w10, [sp, #203]
	ldrb	w10, [x0, #87]
	stp	w11, w9, [sp, #64]              ; 8-byte Folded Spill
	strb	w9, [sp, #204]
	ldrb	w9, [x0, #86]
	strb	w10, [sp, #207]
	stp	w10, w9, [sp, #56]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #89]
	strb	w9, [sp, #206]
	ldrb	w9, [x0, #88]
	strb	w10, [sp, #209]
	stp	w10, w9, [sp, #48]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #91]
	strb	w9, [sp, #208]
	ldrb	w9, [x0, #90]
	strb	w10, [sp, #211]
	stp	w10, w9, [sp, #40]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #93]
	strb	w9, [sp, #210]
	ldrb	w9, [x0, #92]
	strb	w10, [sp, #213]
	stp	w10, w9, [sp, #32]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #95]
	strb	w9, [sp, #212]
	ldrb	w9, [x0, #94]
	strb	w10, [sp, #215]
	stp	w10, w9, [sp, #24]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #97]
	strb	w9, [sp, #214]
	ldrb	w9, [x0, #96]
	strb	w11, [sp, #205]
	ldrb	w11, [x0, #106]
	stp	w10, w9, [sp, #16]              ; 8-byte Folded Spill
	strb	w9, [sp, #216]
	ldrb	w9, [x0, #104]
	strb	w10, [sp, #217]
	ldrb	w10, [x0, #105]
	strb	w23, [sp, #176]
	strb	w22, [sp, #178]
	strb	w24, [sp, #218]
	strb	w25, [sp, #219]
	strb	w26, [sp, #220]
	strb	w27, [sp, #221]
	strb	w28, [sp, #222]
	strb	w30, [sp, #223]
	strb	w9, [sp, #224]
	strb	w10, [sp, #225]
	strb	w11, [sp, #226]
	strb	w12, [sp, #227]
	strb	w13, [sp, #228]
	strb	w14, [sp, #229]
	strb	w15, [sp, #230]
	strb	w16, [sp, #231]
	strb	w17, [sp, #232]
	strb	w2, [sp, #233]
	strb	w3, [sp, #234]
	strb	w4, [sp, #235]
	strb	w5, [sp, #236]
	strb	w6, [sp, #237]
	strb	w7, [sp, #238]
	strb	w19, [sp, #239]
	b.hs	LBB11_7
; %bb.2:                                ; %v10_ok
	add	x1, sp, #176
	add	x20, sp, #556
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	mov	w1, #2                          ; =0x2
	b.eq	LBB11_4
; %bb.3:                                ; %b3
	strb	w23, [sp, #240]
	mov	w23, w22
	ldr	w22, [sp, #172]                 ; 4-byte Reload
	strb	w23, [sp, #242]
	strb	w22, [sp, #241]
	ldr	w22, [sp, #168]                 ; 4-byte Reload
	strb	w24, [sp, #282]
	strb	w22, [sp, #243]
	ldr	w22, [sp, #164]                 ; 4-byte Reload
	strb	w25, [sp, #283]
	strb	w22, [sp, #244]
	ldr	w22, [sp, #160]                 ; 4-byte Reload
	strb	w26, [sp, #284]
	strb	w22, [sp, #245]
	ldr	w22, [sp, #156]                 ; 4-byte Reload
	strb	w27, [sp, #285]
	strb	w22, [sp, #246]
	ldr	w22, [sp, #152]                 ; 4-byte Reload
	strb	w28, [sp, #286]
	strb	w22, [sp, #247]
	ldr	w22, [sp, #148]                 ; 4-byte Reload
	strb	w30, [sp, #287]
	strb	w22, [sp, #248]
	ldr	w22, [sp, #144]                 ; 4-byte Reload
	strb	w9, [sp, #288]
	add	x9, sp, #240
	strb	w22, [sp, #249]
	ldr	w22, [sp, #140]                 ; 4-byte Reload
	strb	w10, [sp, #289]
	mov	w10, #7                         ; =0x7
	strb	w22, [sp, #250]
	ldr	w22, [sp, #136]                 ; 4-byte Reload
	strb	w11, [sp, #290]
	strb	w22, [sp, #251]
	ldr	w22, [sp, #132]                 ; 4-byte Reload
	strb	w12, [sp, #291]
	strb	w22, [sp, #252]
	ldr	w22, [sp, #128]                 ; 4-byte Reload
	strb	w13, [sp, #292]
	strb	w22, [sp, #253]
	ldr	w22, [sp, #124]                 ; 4-byte Reload
	strb	w14, [sp, #293]
	strb	w22, [sp, #254]
	ldr	w22, [sp, #120]                 ; 4-byte Reload
	strb	w15, [sp, #294]
	strb	w22, [sp, #255]
	ldr	w22, [sp, #116]                 ; 4-byte Reload
	strb	w16, [sp, #295]
	strb	w22, [sp, #256]
	ldr	w22, [sp, #112]                 ; 4-byte Reload
	strb	w17, [sp, #296]
	strb	w22, [sp, #257]
	ldr	w22, [sp, #108]                 ; 4-byte Reload
	strb	w2, [sp, #297]
	strb	w22, [sp, #258]
	ldr	w22, [sp, #104]                 ; 4-byte Reload
	strb	w3, [sp, #298]
	strb	w22, [sp, #259]
	ldr	w22, [sp, #100]                 ; 4-byte Reload
	strb	w4, [sp, #299]
	strb	w22, [sp, #260]
	ldr	w22, [sp, #96]                  ; 4-byte Reload
	strb	w5, [sp, #300]
	strb	w22, [sp, #261]
	ldr	w22, [sp, #92]                  ; 4-byte Reload
	strb	w6, [sp, #301]
	strb	w22, [sp, #262]
	ldr	w22, [sp, #88]                  ; 4-byte Reload
	strb	w7, [sp, #302]
	strb	w22, [sp, #263]
	ldr	w22, [sp, #84]                  ; 4-byte Reload
	strb	w19, [sp, #303]
	strb	w22, [sp, #264]
	ldr	w22, [sp, #80]                  ; 4-byte Reload
	strb	w22, [sp, #265]
	ldr	w22, [sp, #76]                  ; 4-byte Reload
	strb	w22, [sp, #266]
	ldr	w22, [sp, #72]                  ; 4-byte Reload
	strb	w22, [sp, #267]
	ldr	w22, [sp, #68]                  ; 4-byte Reload
	strb	w22, [sp, #268]
	ldr	w22, [sp, #64]                  ; 4-byte Reload
	strb	w22, [sp, #269]
	ldr	w22, [sp, #60]                  ; 4-byte Reload
	strb	w22, [sp, #270]
	ldr	w22, [sp, #56]                  ; 4-byte Reload
	strb	w22, [sp, #271]
	ldr	w22, [sp, #52]                  ; 4-byte Reload
	strb	w22, [sp, #272]
	ldr	w22, [sp, #48]                  ; 4-byte Reload
	strb	w22, [sp, #273]
	ldr	w22, [sp, #44]                  ; 4-byte Reload
	strb	w22, [sp, #274]
	ldr	w22, [sp, #40]                  ; 4-byte Reload
	strb	w22, [sp, #275]
	ldr	w22, [sp, #36]                  ; 4-byte Reload
	strb	w22, [sp, #276]
	ldr	w22, [sp, #32]                  ; 4-byte Reload
	strb	w22, [sp, #277]
	ldr	w22, [sp, #28]                  ; 4-byte Reload
	strb	w22, [sp, #278]
	ldr	w22, [sp, #24]                  ; 4-byte Reload
	strb	w22, [sp, #279]
	ldr	w22, [sp, #20]                  ; 4-byte Reload
	strb	w22, [sp, #280]
	ldr	w22, [sp, #16]                  ; 4-byte Reload
	strb	w22, [sp, #281]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	add	x9, sp, #492
	csel	x20, x20, x9, eq
	csel	w1, w1, w10, eq
LBB11_4:                                ; %b8_to_b9
	ldur	q0, [x0, #56]
	ldur	q1, [x0, #72]
	add	x12, sp, #304
	ldur	q2, [x0, #88]
	ldur	q3, [x0, #168]
	add	x11, sp, #368
	stp	q0, q1, [x20]
	ldur	q0, [x0, #104]
	ldr	x9, [x0, #48]
	stur	q3, [x12, #107]
	ldur	q4, [x0, #157]
	ldur	q5, [x0, #141]
	stp	q2, q0, [x20, #32]
	ldr	q2, [x0]
	ldur	q6, [x0, #125]
	strb	w1, [x20, x21]
	ldrb	w10, [x0, #124]
	str	q2, [sp, #432]
	ldp	q1, q0, [x0, #16]
	str	x9, [sp, #480]
	ldr	w9, [x0, #120]
	add	x0, sp, #432
	stp	q5, q4, [sp, #384]
	ldp	q2, q3, [x20, #32]
	stp	q1, q0, [sp, #448]
	ldp	q0, q1, [x20]
	str	q6, [sp, #368]
	b	LBB11_6
LBB11_5:                                ; %b1
	ldp	q0, q1, [x0]
	mov	w9, wzr
	ldr	q2, [x0, #32]
	ldr	x10, [x0, #48]
	add	x11, x0, #125
	ldur	q4, [x0, #125]
	ldur	q3, [x0, #104]
	stp	q0, q1, [sp, #432]
	ldur	q0, [x0, #168]
	ldur	q1, [x0, #157]
	str	q2, [sp, #464]
	ldur	q2, [x0, #141]
	str	x10, [sp, #480]
	mov	w10, #1                         ; =0x1
	stur	q0, [x12, #107]
	ldur	q0, [x0, #56]
	stp	q2, q1, [sp, #384]
	ldur	q1, [x0, #72]
	ldur	q2, [x0, #88]
	str	q4, [sp, #368]
	strb	w10, [sp, #620]
LBB11_6:                                ; %b9
	ldp	q4, q5, [x11]
	ldr	q6, [x11, #32]
	str	q6, [sp, #336]
	ldr	q6, [x0]
	stp	q4, q5, [sp, #304]
	ldur	q4, [x11, #43]
	ldr	x11, [x0, #48]
	stur	q4, [x12, #43]
	ldp	q5, q4, [x0, #16]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #304]
	str	x11, [x8, #48]
	stp	q5, q4, [x8, #16]
	stur	q0, [x8, #125]
	ldr	q0, [sp, #336]
	stur	q1, [x8, #141]
	ldur	q1, [x12, #43]
	str	q6, [x8]
	stur	q2, [x8, #88]
	stur	q3, [x8, #104]
	str	w9, [x8, #120]
	strb	w10, [x8, #124]
	stur	q0, [x8, #157]
	stur	q1, [x8, #168]
	add	sp, sp, #624
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB11_7:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_json_space         ; -- Begin function liza___liza_json_space
	.p2align	2
_liza___liza_json_space:                ; @liza___liza_json_space
; %bb.0:                                ; %b0
	mov	x8, #9728                       ; =0x2600
                                        ; kill: def $w0 killed $w0 def $x0
	and	w9, w0, #0xff
	movk	x8, #1, lsl #32
	cmp	w9, #33
	lsr	x8, x8, x0
	cset	w9, lo
	and	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza___liza_json_digit         ; -- Begin function liza___liza_json_digit
	.p2align	2
_liza___liza_json_digit:                ; @liza___liza_json_digit
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w8, w8, #48
	cmp	w8, #10
	cset	w0, lo
	ret
                                        ; -- End function
	.globl	_liza___liza_json_hex           ; -- Begin function liza___liza_json_hex
	.p2align	2
_liza___liza_json_hex:                  ; @liza___liza_json_hex
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w0, w8, #48
	cmp	w0, #9
	b.hi	LBB14_2
; %bb.1:                                ; %common.ret
	ret
LBB14_2:                                ; %b6
	sub	w9, w8, #65
	cmp	w9, #5
	b.hi	LBB14_4
; %bb.3:                                ; %v15_ok
	sub	w0, w8, #55
	ret
LBB14_4:                                ; %b12
	sub	w9, w8, #97
	cmp	w9, #5
	b.hi	LBB14_6
; %bb.5:                                ; %v24_ok
	sub	w0, w8, #87
	ret
LBB14_6:
	mov	w0, #16                         ; =0x10
	ret
                                        ; -- End function
	.globl	_liza_json.status               ; -- Begin function liza_json.status
	.p2align	2
_liza_json.status:                      ; @liza_json.status
; %bb.0:                                ; %b0
	ldr	w9, [x0, #168]
	cbz	w9, LBB15_2
; %bb.1:                                ; %b3
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	mov	x8, x0
	cset	w11, eq
	cmp	w9, #3
	ldr	x2, [x8, #176]
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	mov	w0, wzr
	csel	w1, w9, w10, eq
	ret
LBB15_2:
	mov	w1, wzr
	mov	x2, xzr
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_json.finish               ; -- Begin function liza_json.finish
	.p2align	2
_liza_json.finish:                      ; @liza_json.finish
; %bb.0:                                ; %b0
	ldr	w9, [x0, #168]
	cbz	w9, LBB16_11
; %bb.1:                                ; %b3.i
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	ldr	x3, [x0, #176]
	cset	w11, eq
	cmp	w9, #3
	mov	w8, wzr
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	csel	w2, w9, w10, eq
	cbz	w8, LBB16_12
LBB16_2:                                ; %b4
	ldr	w8, [x0, #32]
	ldr	x3, [x0, #40]
	cmp	w8, #2
	b.eq	LBB16_13
; %bb.3:                                ; %b4
	cmp	w8, #1
	b.eq	LBB16_14
; %bb.4:                                ; %b6.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB16_20
; %bb.5:                                ; %b7.i
	ldr	x3, [x0, #16]
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB16_15
LBB16_6:                                ; %b6
	sub	sp, sp, #224
	ldr	w8, [x0, #128]
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	cmp	w8, #17
	b.hi	LBB16_24
; %bb.7:                                ; %b6
	mov	w9, #22528                      ; =0x5800
	movk	w9, #2, lsl #16
	lsr	w9, w9, w8
	tbz	w9, #0, LBB16_24
; %bb.8:                                ; %b18
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x8, [x0, #176]
	str	q2, [sp, #160]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #64]
	str	x8, [sp, #176]
	mov	x8, sp
	add	x19, x8, #160
	str	wzr, [sp, #128]
	stp	q0, q1, [sp, #64]
	ldp	q2, q0, [x0, #96]
	stp	q2, q0, [sp, #96]
	ldp	q1, q0, [x0]
	stp	q1, q0, [sp]
	ldp	q1, q0, [x0, #32]
                                        ; implicit-def: $x0
	stp	q1, q0, [sp, #32]
	bl	_liza___liza_owned___liza_json_done
	ldr	x3, [sp, #48]
	ldr	w10, [sp, #120]
	ldrb	w9, [sp, #124]
	ldr	w8, [sp, #128]
LBB16_9:                                ; %b20
	sub	w11, w8, #4
	cmp	w11, #2
	b.hi	LBB16_16
; %bb.10:                               ; %b27
	ldr	x3, [x19]
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
	b	LBB16_22
LBB16_11:
	mov	w2, wzr
	mov	x3, xzr
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB16_2
LBB16_12:                               ; %b2
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	ret
LBB16_13:                               ; %b4.i
	mov	w8, #1                          ; =0x1
LBB16_14:                               ; %liza_utf8_stream.finish.exit
	cbz	w8, LBB16_6
LBB16_15:                               ; %b7
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB16_16:                               ; %b29
	cbnz	w8, LBB16_21
; %bb.17:                               ; %b29
	cbnz	w10, LBB16_21
; %bb.18:                               ; %b29
	tbz	w9, #0, LBB16_21
; %bb.19:                               ; %b38
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	b	LBB16_23
LBB16_20:                               ; %b9.i
	mov	x3, xzr
	cbnz	w8, LBB16_15
	b	LBB16_6
LBB16_21:                               ; %b36
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
LBB16_22:
	mov	w0, #1                          ; =0x1
LBB16_23:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
LBB16_24:                               ; %b19_to_b20
	ldr	x3, [x0, #48]
	ldr	w10, [x0, #120]
	add	x19, x0, #160
	ldrb	w9, [x0, #124]
	b	LBB16_9
                                        ; -- End function
	.globl	_liza___liza_json_mut_fail      ; -- Begin function liza___liza_json_mut_fail
	.p2align	2
_liza___liza_json_mut_fail:             ; @liza___liza_json_mut_fail
; %bb.0:                                ; %b0
	str	w0, [x2, #168]
	str	x1, [x2, #176]
	ret
                                        ; -- End function
	.globl	_liza___liza_json_mut_done      ; -- Begin function liza___liza_json_mut_done
	.p2align	2
_liza___liza_json_mut_done:             ; @liza___liza_json_mut_done
; %bb.0:                                ; %b0
	ldr	w8, [x0, #120]
	cbz	w8, LBB18_4
; %bb.1:                                ; %b2
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB18_7
; %bb.2:                                ; %v12_ok
	add	x9, x0, #56
	ldrb	w10, [x9, w8, uxtw]
	orr	w10, w10, #0x2
	cmp	w10, #3
	b.ne	LBB18_5
; %bb.3:                                ; %v24_ok
	mov	w10, #2                         ; =0x2
	b	LBB18_6
LBB18_4:                                ; %b1
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #124]
	ldr	w0, [x0, #168]
	ret
LBB18_5:                                ; %v28_ok
	mov	w10, #7                         ; =0x7
LBB18_6:                                ; %b9
	strb	w10, [x9, w8, uxtw]
	ldr	w0, [x0, #168]
	ret
LBB18_7:                                ; %v12_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_json_mut_step      ; -- Begin function liza___liza_json_mut_step
	.p2align	2
_liza___liza_json_mut_step:             ; @liza___liza_json_mut_step
; %bb.0:                                ; %b0
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	ldr	w8, [x1, #128]
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
                                        ; kill: def $w0 killed $w0 def $x0
	cmp	w8, #3
	b.le	LBB19_7
; %bb.1:                                ; %b0
	cmp	w8, #5
	b.gt	LBB19_10
; %bb.2:                                ; %b0
	cmp	w8, #4
	b.eq	LBB19_30
; %bb.3:                                ; %b0
	cmp	w8, #5
	b.ne	LBB19_25
; %bb.4:                                ; %b52
	and	w8, w0, #0xff
	cmp	w8, #117
	b.ne	LBB19_45
; %bb.5:                                ; %b56
	mov	w8, #6                          ; =0x6
LBB19_6:                                ; %common.ret
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	str	xzr, [x1, #144]
	b	LBB19_162
LBB19_7:                                ; %b0
	cmp	w8, #1
	b.eq	LBB19_18
; %bb.8:                                ; %b0
	cmp	w8, #2
	b.eq	LBB19_34
; %bb.9:                                ; %b0
	cmp	w8, #3
	b.eq	LBB19_16
	b	LBB19_25
LBB19_10:                               ; %b0
	cmp	w8, #6
	b.eq	LBB19_16
; %bb.11:                               ; %b0
	cmp	w8, #20
	b.ne	LBB19_25
; %bb.12:                               ; %b91
	ldr	w8, [x1, #136]
	cmp	w8, #3
	b.eq	LBB19_66
; %bb.13:                               ; %b91
	cmp	w8, #2
	b.eq	LBB19_65
; %bb.14:                               ; %b91
	cmp	w8, #1
	b.ne	LBB19_67
; %bb.15:                               ; %b104.thread
	ldr	w8, [x1, #140]
	mov	w9, #114                        ; =0x72
	mov	w10, #117                       ; =0x75
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	b	LBB19_68
LBB19_16:                               ; %b61
	sub	w9, w0, #48
	and	w9, w9, #0xff
	cmp	w9, #10
	b.hs	LBB19_32
; %bb.17:
	mov	w9, #-48                        ; =0xffffffd0
	b	LBB19_40
LBB19_18:                               ; %b1
	and	w8, w0, #0xff
	cmp	w8, #32
	b.lo	LBB19_160
; %bb.19:                               ; %b5
	cmp	w8, #92
	b.eq	LBB19_75
; %bb.20:                               ; %b5
	cmp	w8, #34
	b.ne	LBB19_95
; %bb.21:                               ; %b6
	ldrb	w8, [x1, #132]
	str	wzr, [x1, #128]
	cbz	w8, LBB19_81
; %bb.22:                               ; %b8
	ldr	w8, [x1, #120]
	subs	w8, w8, #1
	b.lo	LBB19_167
; %bb.23:                               ; %v23_ok
	cmp	w8, #64
	b.hs	LBB19_167
; %bb.24:                               ; %v24_ok
	add	x9, x1, #56
	mov	w10, #5                         ; =0x5
	b	LBB19_94
LBB19_25:                               ; %b132
	sub	w9, w8, #10
	cmp	w9, #7
	b.hi	LBB19_60
; %bb.26:                               ; %b136
	sub	w9, w0, #48
	and	w9, w9, #0xff
	cmp	w9, #9
	b.hi	LBB19_55
; %bb.27:                               ; %b138
	cmp	w8, #10
	b.eq	LBB19_83
; %bb.28:                               ; %b138
	cmp	w8, #13
	b.eq	LBB19_82
; %bb.29:                               ; %b138
	cmp	w8, #11
	b.ne	LBB19_84
	b	LBB19_139
LBB19_30:                               ; %b46
	and	w8, w0, #0xff
	cmp	w8, #92
	b.ne	LBB19_45
; %bb.31:                               ; %b50
	mov	w8, #5                          ; =0x5
	b	LBB19_53
LBB19_32:                               ; %b6.i
	sub	w9, w0, #65
	and	w9, w9, #0xff
	cmp	w9, #6
	b.hs	LBB19_38
; %bb.33:
	mov	w9, #-55                        ; =0xffffffc9
	b	LBB19_40
LBB19_34:                               ; %b16
	and	w8, w0, #0xff
	sub	w9, w8, #98
	cmp	w9, #19
	b.hi	LBB19_50
; %bb.35:                               ; %b16
	mov	w10, #4113                      ; =0x1011
	movk	w10, #5, lsl #16
	lsr	w10, w10, w9
	tbnz	w10, #0, LBB19_52
; %bb.36:                               ; %b16
	cmp	w9, #19
	b.ne	LBB19_50
; %bb.37:                               ; %b42
	mov	w8, #3                          ; =0x3
	b	LBB19_6
LBB19_38:                               ; %b12.i
	sub	w9, w0, #97
	and	w9, w9, #0xff
	cmp	w9, #6
	b.hs	LBB19_54
; %bb.39:
	mov	w9, #-87                        ; =0xffffffa9
LBB19_40:                               ; %b65
	ldr	w10, [x1, #148]
	lsr	w11, w10, #28
	cbnz	w11, LBB19_167
; %bb.41:                               ; %v165_ok
	add	w9, w9, w0, uxtb
	ldr	w11, [x1, #144]
	add	w9, w9, w10, lsl #4
	adds	w10, w11, #1
	str	w9, [x1, #148]
	b.hs	LBB19_167
; %bb.42:                               ; %v171_ok
	cmp	w10, #4
	str	w10, [x1, #144]
	b.ne	LBB19_95
; %bb.43:                               ; %b66
	cmp	w8, #6
	b.ne	LBB19_47
; %bb.44:                               ; %b68
	sub	w8, w9, #14, lsl #12            ; =57344
	cmn	w8, #1025
	b.hi	LBB19_52
LBB19_45:                               ; %b48
	ldr	x8, [x1, #160]
LBB19_46:                               ; %common.ret
	mov	w0, #4                          ; =0x4
	b	LBB19_161
LBB19_47:                               ; %b76
	and	w8, w9, #0xfffffc00
	mov	w9, #56320                      ; =0xdc00
	cmp	w8, w9
	b.eq	LBB19_76
; %bb.48:                               ; %b76
	mov	w9, #55296                      ; =0xd800
	cmp	w8, w9
	b.ne	LBB19_77
; %bb.49:                               ; %b80
	ldr	x9, [x1, #152]
	mov	w8, #4                          ; =0x4
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	str	x9, [x1, #160]
	b	LBB19_162
LBB19_50:                               ; %b16
	sub	w8, w8, #34
	cmp	w8, #58
	b.hi	LBB19_54
; %bb.51:                               ; %b16
	mov	x9, #8193                       ; =0x2001
	movk	x9, #1024, lsl #48
	lsr	x8, x9, x8
	tbz	w8, #0, LBB19_54
LBB19_52:                               ; %b39
	mov	w8, #1                          ; =0x1
LBB19_53:                               ; %common.ret
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	b	LBB19_162
LBB19_54:                               ; %b44
	ldr	x8, [x1, #48]
	mov	w0, #3                          ; =0x3
	b	LBB19_161
LBB19_55:                               ; %b158
	cmp	w8, #11
	b.ne	LBB19_78
; %bb.56:                               ; %b162
	and	w8, w0, #0xff
	cmp	w8, #92
	b.gt	LBB19_104
; %bb.57:                               ; %b162
	sub	w8, w8, #9
	cmp	w8, #60
	b.hi	LBB19_139
; %bb.58:                               ; %b162
	mov	x9, #19                         ; =0x13
	movk	x9, #128, lsl #16
	movk	x9, #8, lsl #32
	lsr	x9, x9, x8
	tbz	w9, #0, LBB19_111
LBB19_59:                               ; %b215
	mov	x19, x0
	mov	x0, x1
	str	wzr, [x1, #128]
	mov	x20, x1
	bl	_liza___liza_json_mut_done
	mov	x0, x19
	mov	x1, x20
LBB19_60:                               ; %b216
	and	w8, w0, #0xff
	cmp	w8, #32
	b.hi	LBB19_62
; %bb.61:                               ; %b216
	mov	w8, w0
	mov	x9, #9728                       ; =0x2600
	and	x8, x8, #0xff
	movk	x9, #1, lsl #32
	lsr	x8, x9, x8
	tbnz	w8, #0, LBB19_95
LBB19_62:                               ; %b7.i37
	ldr	w8, [x1, #120]
	cbz	w8, LBB19_96
; %bb.63:                               ; %b220
	sub	w9, w8, #1
	cmp	w9, #64
	b.hs	LBB19_167
; %bb.64:                               ; %v525_ok
	add	x9, x1, w9, uxtw
	ldrb	w9, [x9, #56]
	b	LBB19_97
LBB19_65:                               ; %b105
	ldr	w8, [x1, #140]
	mov	w9, #97                         ; =0x61
	mov	w10, #108                       ; =0x6c
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w10, #115                       ; =0x73
	csel	w9, w10, w9, eq
	cmp	w8, #4
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	mov	w8, #5                          ; =0x5
	cmp	w9, w0, uxtb
	b.eq	LBB19_69
	b	LBB19_160
LBB19_66:                               ; %b120
	ldr	w8, [x1, #140]
	mov	w9, #117                        ; =0x75
	cmp	w8, #1
	mov	w8, #108                        ; =0x6c
	csel	w9, w9, w8, eq
	b	LBB19_68
LBB19_67:
	mov	w9, wzr
LBB19_68:                               ; %b125
	mov	w8, #4                          ; =0x4
	cmp	w9, w0, uxtb
	b.ne	LBB19_160
LBB19_69:                               ; %b128
	ldr	w9, [x1, #140]
	adds	w9, w9, #1
	b.hs	LBB19_167
; %bb.70:                               ; %v325_ok
	cmp	w9, w8
	str	w9, [x1, #140]
	b.ne	LBB19_95
; %bb.71:                               ; %b129
	ldr	w8, [x1, #120]
	str	wzr, [x1, #128]
	cbz	w8, LBB19_80
; %bb.72:                               ; %b2.i
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB19_167
; %bb.73:                               ; %v12_ok.i
	add	x9, x1, #56
	ldrb	w10, [x9, w8, uxtw]
	orr	w10, w10, #0x2
	cmp	w10, #3
	b.ne	LBB19_93
; %bb.74:                               ; %v24_ok.i27
	mov	w10, #2                         ; =0x2
	b	LBB19_94
LBB19_75:                               ; %b12
	ldr	x9, [x1, #48]
	mov	w8, #2                          ; =0x2
	str	w8, [x1, #128]
	str	x9, [x1, #152]
	b	LBB19_95
LBB19_76:                               ; %b86
	ldr	x8, [x1, #152]
	b	LBB19_46
LBB19_77:                               ; %b88
	mov	w8, #1                          ; =0x1
	str	w8, [x1, #128]
	b	LBB19_95
LBB19_78:                               ; %b159
	and	w9, w0, #0xff
	cmp	w9, #46
	ccmp	w8, #12, #0, eq
	b.ne	LBB19_86
LBB19_79:                               ; %b165
	mov	w8, #13                         ; =0xd
	b	LBB19_53
LBB19_80:                               ; %b1.i
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #124]
	b	LBB19_95
LBB19_81:                               ; %b10
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	mov	x0, x1
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_liza___liza_json_mut_done
LBB19_82:
	mov	w8, #14                         ; =0xe
	str	w8, [x1, #128]
	b	LBB19_95
LBB19_83:                               ; %b148.thread
	and	w8, w0, #0xff
	cmp	w8, #48
	mov	w8, #11                         ; =0xb
	cinc	w8, w8, ne
	str	w8, [x1, #128]
LBB19_84:                               ; %b151
	sub	w8, w8, #15
	cmp	w8, #1
	b.hi	LBB19_95
; %bb.85:
	mov	w8, #17                         ; =0x11
	str	w8, [x1, #128]
	b	LBB19_95
LBB19_86:                               ; %b167
	cmp	w8, #16
	b.hi	LBB19_140
; %bb.87:                               ; %b167
	mov	w9, #22528                      ; =0x5800
	lsr	w9, w9, w8
	tbnz	w9, #0, LBB19_117
; %bb.88:                               ; %b167
	mov	w9, #9216                       ; =0x2400
	movk	w9, #1, lsl #16
	lsr	w9, w9, w8
	tbnz	w9, #0, LBB19_139
; %bb.89:                               ; %b167
	cmp	w8, #15
	b.ne	LBB19_140
; %bb.90:                               ; %b183
	and	w8, w0, #0xff
	cmp	w8, #45
	b.eq	LBB19_92
; %bb.91:                               ; %b183
	cmp	w8, #43
	b.ne	LBB19_139
LBB19_92:                               ; %b189
	mov	w8, #16                         ; =0x10
	b	LBB19_53
LBB19_93:                               ; %v28_ok.i
	mov	w10, #7                         ; =0x7
LBB19_94:                               ; %liza___liza_json_mut_done.exit
	strb	w10, [x9, w8, uxtw]
LBB19_95:                               ; %b131
	ldr	w0, [x1, #168]
	b	LBB19_162
LBB19_96:
	mov	w9, wzr
LBB19_97:                               ; %b222
	and	w10, w0, #0xff
	cmp	w10, #125
	b.eq	LBB19_107
; %bb.98:                               ; %b222
	cmp	w10, #93
	b.ne	LBB19_100
; %bb.99:                               ; %b223
	sub	w10, w9, #1
	cmp	w10, #1
	b.ls	LBB19_126
LBB19_100:                              ; %b240
	cmp	w9, #4
	b.le	LBB19_113
; %bb.101:                              ; %b240
	cmp	w9, #5
	b.eq	LBB19_134
; %bb.102:                              ; %b240
	cmp	w9, #8
	b.eq	LBB19_115
; %bb.103:                              ; %b240
	cmp	w9, #7
	b.eq	LBB19_119
	b	LBB19_128
LBB19_104:                              ; %b162
	cmp	w8, #93
	b.eq	LBB19_59
; %bb.105:                              ; %b162
	cmp	w8, #101
	b.eq	LBB19_118
LBB19_106:                              ; %b203
	cmp	w8, #125
	b.eq	LBB19_59
	b	LBB19_139
LBB19_107:                              ; %b232
	cmp	w9, #4
	b.le	LBB19_124
; %bb.108:                              ; %b232
	cmp	w9, #5
	b.eq	LBB19_160
; %bb.109:                              ; %b232
	cmp	w9, #8
	b.eq	LBB19_160
; %bb.110:                              ; %b232
	cmp	w9, #7
	b.eq	LBB19_126
	b	LBB19_128
LBB19_111:                              ; %b162
	cmp	x8, #37
	b.eq	LBB19_79
; %bb.112:                              ; %b162
	cmp	x8, #60
	b.eq	LBB19_118
	b	LBB19_139
LBB19_113:                              ; %b240
	cmp	w9, #2
	b.eq	LBB19_119
; %bb.114:                              ; %b240
	cmp	w9, #4
	b.ne	LBB19_128
LBB19_115:                              ; %b262.critedge
	and	w8, w0, #0xff
	cmp	w8, #34
	b.ne	LBB19_160
; %bb.116:                              ; %b266
	mov	w8, #1                          ; =0x1
	ldr	w0, [x1, #168]
	strb	w8, [x1, #132]
	str	w8, [x1, #128]
	b	LBB19_162
LBB19_117:                              ; %b174
	orr	w9, w0, #0x20
	and	w9, w9, #0xff
	cmp	w9, #101
	b.ne	LBB19_138
LBB19_118:                              ; %b180
	mov	w8, #15                         ; =0xf
	b	LBB19_53
LBB19_119:                              ; %b244
	and	w10, w0, #0xff
	cmp	w10, #44
	b.ne	LBB19_160
; %bb.120:                              ; %b248
	subs	w8, w8, #1
	cset	w10, lo
	cmp	w9, #2
	b.ne	LBB19_147
; %bb.121:                              ; %b249
	cbnz	w10, LBB19_167
; %bb.122:                              ; %v584_ok
	cmp	w8, #64
	b.hs	LBB19_167
; %bb.123:
	mov	w9, #3                          ; =0x3
	b	LBB19_150
LBB19_124:                              ; %b232
	cmp	w9, #2
	b.eq	LBB19_160
; %bb.125:                              ; %b232
	cmp	w9, #4
	b.ne	LBB19_128
LBB19_126:                              ; %b229
	subs	w8, w8, #1
	b.lo	LBB19_167
; %bb.127:                              ; %v542_ok
	ldr	w0, [x1, #168]
	str	w8, [x1, #120]
	b	LBB19_162
LBB19_128:                              ; %b259
	cbnz	w8, LBB19_130
; %bb.129:                              ; %b268
	ldrb	w9, [x1, #124]
	cbnz	w9, LBB19_160
LBB19_130:                              ; %b273
	and	w9, w0, #0xff
	cmp	w9, #90
	b.gt	LBB19_143
; %bb.131:                              ; %b273
	cmp	w9, #34
	b.eq	LBB19_156
; %bb.132:                              ; %b273
	cmp	w9, #45
	b.ne	LBB19_151
; %bb.133:                              ; %b289
	mov	w8, #10                         ; =0xa
	b	LBB19_53
LBB19_134:                              ; %b253
	and	w9, w0, #0xff
	cmp	w9, #58
	b.ne	LBB19_160
; %bb.135:                              ; %b257
	subs	w8, w8, #1
	b.lo	LBB19_167
; %bb.136:                              ; %v612_ok
	cmp	w8, #64
	b.hs	LBB19_167
; %bb.137:                              ; %v613_ok
	add	x9, x1, #56
	mov	w10, #6                         ; =0x6
	b	LBB19_94
LBB19_138:                              ; %b182
	cmp	w8, #13
	b.ne	LBB19_140
LBB19_139:                              ; %b140
	ldr	x8, [x1, #48]
	mov	w0, #2                          ; =0x2
	b	LBB19_161
LBB19_140:                              ; %b203
	and	w8, w0, #0xff
	cmp	w8, #44
	b.hi	LBB19_142
; %bb.141:                              ; %b203
	mov	x10, #9728                      ; =0x2600
	and	x9, x0, #0xff
	movk	x10, #4097, lsl #32
	lsr	x9, x10, x9
	tbnz	w9, #0, LBB19_59
LBB19_142:                              ; %b203
	cmp	w8, #93
	b.ne	LBB19_106
	b	LBB19_59
LBB19_143:                              ; %b273
	cmp	w9, #123
	b.eq	LBB19_145
; %bb.144:                              ; %b273
	cmp	w9, #91
	b.ne	LBB19_151
LBB19_145:                              ; %b277
	cmp	w8, #64
	b.ne	LBB19_153
; %bb.146:                              ; %b279
	ldr	x8, [x1, #48]
	mov	w0, #7                          ; =0x7
	b	LBB19_161
LBB19_147:                              ; %b250
	cbnz	w10, LBB19_167
; %bb.148:                              ; %v592_ok
	cmp	w8, #64
	b.hs	LBB19_167
; %bb.149:
	mov	w9, #8                          ; =0x8
LBB19_150:                              ; %b251
	add	x10, x1, #56
	strb	w9, [x10, w8, uxtw]
	b	LBB19_95
LBB19_151:                              ; %b291
	sub	w8, w0, #48
	and	w8, w8, #0xff
	cmp	w8, #9
	b.hi	LBB19_157
; %bb.152:                              ; %b292
	and	w8, w0, #0xff
	cmp	w8, #48
	mov	w8, #11                         ; =0xb
	cinc	w8, w8, ne
	b	LBB19_53
LBB19_153:                              ; %b281
	mov	x20, x0
	mov	x0, x1
	mov	x19, x1
	bl	_liza___liza_json_mut_done
	and	w10, w20, #0xff
	ldr	w9, [x19, #120]
	mov	x8, x19
	cmp	w10, #91
	b.ne	LBB19_163
; %bb.154:                              ; %b282
	cmp	w9, #64
	b.hs	LBB19_167
; %bb.155:
	mov	w10, #1                         ; =0x1
	b	LBB19_165
LBB19_156:                              ; %b286
	strb	wzr, [x1, #132]
	b	LBB19_52
LBB19_157:                              ; %b297
	and	w8, w0, #0xff
	sub	w8, w8, #102
	cmp	w8, #14
	b.hi	LBB19_160
; %bb.158:                              ; %b297
	mov	w9, #16641                      ; =0x4101
	lsr	w8, w9, w8
	tbz	w8, #0, LBB19_160
; %bb.159:                              ; %b304
	mov	w8, #20                         ; =0x14
	and	w9, w0, #0xff
	mov	w10, #1                         ; =0x1
	str	w8, [x1, #128]
	cmp	w9, #102
	mov	w8, #2                          ; =0x2
	cinc	w8, w8, ne
	cmp	w9, #116
	ldr	w0, [x1, #168]
	csinc	w8, w8, wzr, ne
	stp	w8, w10, [x1, #136]
	b	LBB19_162
LBB19_160:                              ; %b3
	ldr	x8, [x1, #48]
	mov	w0, #1                          ; =0x1
LBB19_161:                              ; %common.ret
	str	w0, [x1, #168]
	str	x8, [x1, #176]
LBB19_162:                              ; %common.ret
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB19_163:                              ; %b283
	cmp	w9, #64
	b.hs	LBB19_167
; %bb.164:
	mov	w10, #4                         ; =0x4
LBB19_165:                              ; %b284
	add	x9, x8, x9
	strb	w10, [x9, #56]
	ldr	w9, [x8, #120]
	adds	w9, w9, #1
	b.hs	LBB19_167
; %bb.166:                              ; %v691_ok
	ldr	w0, [x8, #168]
	str	w9, [x8, #120]
	b	LBB19_162
LBB19_167:                              ; %v23_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_json.feed_mut             ; -- Begin function liza_json.feed_mut
	.p2align	2
_liza_json.feed_mut:                    ; @liza_json.feed_mut
; %bb.0:                                ; %b0
	sub	sp, sp, #80
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	w0, [x0, #168]
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	cbz	w0, LBB20_2
LBB20_1:                                ; %common.ret
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB20_2:                                ; %b4.preheader
	mov	x20, x1
	mov	w22, w2
	mov	x23, #4294967296                ; =0x100000000
LBB20_3:                                ; %b4
                                        ; =>This Inner Loop Header: Depth=1
	cbz	x22, LBB20_13
; %bb.4:                                ; %v10_ok
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldp	x1, x2, [x19, #8]
	ldr	x7, [x19, #40]
	ldrb	w21, [x20], #1
	ldr	w6, [x19, #32]
	ldr	w3, [x19, #24]
	ldr	x0, [x19]
	ldrb	w5, [x19, #29]
	ldrb	w4, [x19, #28]
	strb	w21, [sp]
	bl	_liza_utf8_stream.feed_byte
	cmp	w6, #2
	stp	x0, x1, [x19]
	str	x2, [x19, #16]
	str	w3, [x19, #24]
	strb	w4, [x19, #28]
	strb	w5, [x19, #29]
	str	w6, [x19, #32]
	str	x7, [x19, #40]
	b.eq	LBB20_7
; %bb.5:                                ; %v10_ok
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w6, #1
	b.ne	LBB20_8
; %bb.6:                                ; %b1.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, wzr
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB20_9
	b	LBB20_14
LBB20_7:                                ; %b4.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, wzr
	mov	w8, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB20_9
	b	LBB20_14
LBB20_8:                                ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, wzr
	mov	x7, xzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB20_14
LBB20_9:                                ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w0, w21
	mov	x1, x19
	bl	_liza___liza_json_mut_step
	ldr	w0, [x19, #168]
	cbnz	w0, LBB20_1
; %bb.10:                               ; %b16
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	x8, [x19, #48]
	adds	x8, x8, #1
	b.hs	LBB20_12
; %bb.11:                               ; %v46_ok
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	x23, x23, #1
	sub	x22, x22, #1
	str	x8, [x19, #48]
	cbnz	x23, LBB20_3
LBB20_12:                               ; %v46_trap
	brk	#0x1
LBB20_13:
	mov	w0, wzr
	b	LBB20_1
LBB20_14:                               ; %b9
	cmp	w8, #0
	mov	w8, #8                          ; =0x8
	mov	w9, #5                          ; =0x5
	csel	w0, w9, w8, eq
	str	x7, [x19, #176]
	str	w0, [x19, #168]
	b	LBB20_1
                                        ; -- End function
	.globl	_liza___liza_owned___liza_json_done ; -- Begin function liza___liza_owned___liza_json_done
	.p2align	2
_liza___liza_owned___liza_json_done:    ; @liza___liza_owned___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #416
	ldr	w21, [x8, #120]
	cbz	w21, LBB21_5
; %bb.1:                                ; %b2
	ldrb	w11, [x8, #56]
	ldrb	w9, [x8, #57]
	sub	w21, w21, #1
	ldrb	w10, [x8, #58]
	ldrb	w2, [x8, #94]
	cmp	w21, #64
	strb	w11, [sp, #160]
	ldrb	w3, [x8, #95]
	ldrb	w4, [x8, #96]
	stp	w11, w10, [sp, #148]            ; 8-byte Folded Spill
	ldrb	w11, [x8, #59]
	ldrb	w5, [x8, #97]
	str	w9, [sp, #156]                  ; 4-byte Spill
	ldrb	w6, [x8, #98]
	ldrb	w7, [x8, #99]
	strb	w9, [sp, #161]
	ldrb	w9, [x8, #60]
	ldrb	w19, [x8, #100]
	strb	w10, [sp, #162]
	ldrb	w10, [x8, #61]
	ldrb	w20, [x8, #101]
	stp	w9, w11, [sp, #140]             ; 8-byte Folded Spill
	ldrb	w22, [x8, #102]
	ldrb	w23, [x8, #103]
	strb	w11, [sp, #163]
	ldrb	w11, [x8, #62]
	ldrb	w24, [x8, #104]
	strb	w9, [sp, #164]
	ldrb	w9, [x8, #63]
	ldrb	w25, [x8, #105]
	stp	w11, w10, [sp, #132]            ; 8-byte Folded Spill
	ldrb	w26, [x8, #106]
	ldrb	w27, [x8, #107]
	strb	w10, [sp, #165]
	ldrb	w10, [x8, #64]
	ldrb	w28, [x8, #108]
	strb	w11, [sp, #166]
	ldrb	w11, [x8, #65]
	ldrb	w30, [x8, #109]
	stp	w10, w9, [sp, #124]             ; 8-byte Folded Spill
	ldrb	w12, [x8, #113]
	ldrb	w13, [x8, #114]
	strb	w9, [sp, #167]
	ldrb	w9, [x8, #66]
	ldrb	w14, [x8, #115]
	strb	w10, [sp, #168]
	ldrb	w10, [x8, #67]
	ldrb	w15, [x8, #116]
	stp	w9, w11, [sp, #116]             ; 8-byte Folded Spill
	ldrb	w16, [x8, #117]
	ldrb	w17, [x8, #118]
	strb	w11, [sp, #169]
	ldrb	w11, [x8, #68]
	ldrb	w0, [x8, #119]
	strb	w9, [sp, #170]
	ldrb	w9, [x8, #69]
	stp	w11, w10, [sp, #108]            ; 8-byte Folded Spill
	strb	w10, [sp, #171]
	ldrb	w10, [x8, #70]
	strb	w11, [sp, #172]
	ldrb	w11, [x8, #71]
	stp	w10, w9, [sp, #100]             ; 8-byte Folded Spill
	strb	w9, [sp, #173]
	ldrb	w9, [x8, #72]
	strb	w10, [sp, #174]
	ldrb	w10, [x8, #73]
	stp	w9, w11, [sp, #92]              ; 8-byte Folded Spill
	strb	w11, [sp, #175]
	ldrb	w11, [x8, #74]
	strb	w9, [sp, #176]
	ldrb	w9, [x8, #75]
	stp	w11, w10, [sp, #84]             ; 8-byte Folded Spill
	strb	w10, [sp, #177]
	ldrb	w10, [x8, #76]
	strb	w11, [sp, #178]
	ldrb	w11, [x8, #77]
	stp	w10, w9, [sp, #76]              ; 8-byte Folded Spill
	strb	w9, [sp, #179]
	ldrb	w9, [x8, #78]
	strb	w10, [sp, #180]
	ldrb	w10, [x8, #79]
	stp	w9, w11, [sp, #68]              ; 8-byte Folded Spill
	strb	w11, [sp, #181]
	ldrb	w11, [x8, #80]
	strb	w9, [sp, #182]
	ldrb	w9, [x8, #81]
	stp	w11, w10, [sp, #60]             ; 8-byte Folded Spill
	strb	w10, [sp, #183]
	ldrb	w10, [x8, #82]
	strb	w11, [sp, #184]
	ldrb	w11, [x8, #83]
	stp	w10, w9, [sp, #52]              ; 8-byte Folded Spill
	strb	w9, [sp, #185]
	ldrb	w9, [x8, #84]
	strb	w10, [sp, #186]
	ldrb	w10, [x8, #85]
	stp	w9, w11, [sp, #44]              ; 8-byte Folded Spill
	strb	w9, [sp, #188]
	ldrb	w9, [x8, #86]
	strb	w10, [sp, #189]
	stp	w9, w10, [sp, #36]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #87]
	strb	w9, [sp, #190]
	ldrb	w9, [x8, #88]
	strb	w10, [sp, #191]
	stp	w9, w10, [sp, #28]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #89]
	strb	w9, [sp, #192]
	ldrb	w9, [x8, #90]
	strb	w10, [sp, #193]
	stp	w9, w10, [sp, #20]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #91]
	strb	w9, [sp, #194]
	ldrb	w9, [x8, #92]
	strb	w10, [sp, #195]
	stp	w9, w10, [sp, #12]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #93]
	strb	w11, [sp, #187]
	ldrb	w11, [x8, #112]
	strb	w9, [sp, #196]
	ldrb	w9, [x8, #110]
	str	w10, [sp, #8]                   ; 4-byte Spill
	strb	w10, [sp, #197]
	ldrb	w10, [x8, #111]
	strb	w2, [sp, #198]
	strb	w3, [sp, #199]
	strb	w4, [sp, #200]
	strb	w5, [sp, #201]
	strb	w6, [sp, #202]
	strb	w7, [sp, #203]
	strb	w19, [sp, #204]
	strb	w20, [sp, #205]
	strb	w22, [sp, #206]
	strb	w23, [sp, #207]
	strb	w24, [sp, #208]
	strb	w25, [sp, #209]
	strb	w26, [sp, #210]
	strb	w27, [sp, #211]
	strb	w28, [sp, #212]
	strb	w30, [sp, #213]
	strb	w9, [sp, #214]
	strb	w10, [sp, #215]
	strb	w11, [sp, #216]
	strb	w12, [sp, #217]
	strb	w13, [sp, #218]
	strb	w14, [sp, #219]
	strb	w15, [sp, #220]
	strb	w16, [sp, #221]
	strb	w17, [sp, #222]
	strb	w0, [sp, #223]
	b.hs	LBB21_9
; %bb.2:                                ; %v10_ok
	add	x1, sp, #160
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	b.eq	LBB21_4
; %bb.3:                                ; %b3
	ldr	w1, [sp, #148]                  ; 4-byte Reload
	strb	w2, [sp, #262]
	strb	w3, [sp, #263]
	strb	w1, [sp, #224]
	ldr	w1, [sp, #156]                  ; 4-byte Reload
	strb	w4, [sp, #264]
	strb	w1, [sp, #225]
	ldr	w1, [sp, #152]                  ; 4-byte Reload
	strb	w5, [sp, #265]
	strb	w1, [sp, #226]
	ldr	w1, [sp, #144]                  ; 4-byte Reload
	strb	w6, [sp, #266]
	strb	w1, [sp, #227]
	ldr	w1, [sp, #140]                  ; 4-byte Reload
	strb	w7, [sp, #267]
	strb	w1, [sp, #228]
	ldr	w1, [sp, #136]                  ; 4-byte Reload
	strb	w19, [sp, #268]
	strb	w1, [sp, #229]
	ldr	w1, [sp, #132]                  ; 4-byte Reload
	strb	w20, [sp, #269]
	strb	w1, [sp, #230]
	ldr	w1, [sp, #128]                  ; 4-byte Reload
	strb	w22, [sp, #270]
	strb	w1, [sp, #231]
	ldr	w1, [sp, #124]                  ; 4-byte Reload
	strb	w23, [sp, #271]
	strb	w1, [sp, #232]
	ldr	w1, [sp, #120]                  ; 4-byte Reload
	strb	w24, [sp, #272]
	strb	w1, [sp, #233]
	ldr	w1, [sp, #116]                  ; 4-byte Reload
	strb	w25, [sp, #273]
	strb	w1, [sp, #234]
	ldr	w1, [sp, #112]                  ; 4-byte Reload
	strb	w26, [sp, #274]
	strb	w1, [sp, #235]
	ldr	w1, [sp, #108]                  ; 4-byte Reload
	strb	w27, [sp, #275]
	strb	w1, [sp, #236]
	ldr	w1, [sp, #104]                  ; 4-byte Reload
	strb	w28, [sp, #276]
	strb	w1, [sp, #237]
	ldr	w1, [sp, #100]                  ; 4-byte Reload
	strb	w30, [sp, #277]
	strb	w1, [sp, #238]
	ldr	w1, [sp, #96]                   ; 4-byte Reload
	strb	w9, [sp, #278]
	add	x9, sp, #224
	strb	w1, [sp, #239]
	ldr	w1, [sp, #92]                   ; 4-byte Reload
	strb	w10, [sp, #279]
	strb	w1, [sp, #240]
	ldr	w1, [sp, #88]                   ; 4-byte Reload
	strb	w11, [sp, #280]
	strb	w1, [sp, #241]
	ldr	w1, [sp, #84]                   ; 4-byte Reload
	strb	w12, [sp, #281]
	strb	w1, [sp, #242]
	ldr	w1, [sp, #80]                   ; 4-byte Reload
	strb	w13, [sp, #282]
	strb	w1, [sp, #243]
	ldr	w1, [sp, #76]                   ; 4-byte Reload
	strb	w14, [sp, #283]
	strb	w1, [sp, #244]
	ldr	w1, [sp, #72]                   ; 4-byte Reload
	strb	w15, [sp, #284]
	strb	w1, [sp, #245]
	ldr	w1, [sp, #68]                   ; 4-byte Reload
	strb	w16, [sp, #285]
	strb	w1, [sp, #246]
	ldr	w1, [sp, #64]                   ; 4-byte Reload
	strb	w17, [sp, #286]
	strb	w1, [sp, #247]
	ldr	w1, [sp, #60]                   ; 4-byte Reload
	strb	w0, [sp, #287]
	strb	w1, [sp, #248]
	ldr	w1, [sp, #56]                   ; 4-byte Reload
	strb	w1, [sp, #249]
	ldr	w1, [sp, #52]                   ; 4-byte Reload
	strb	w1, [sp, #250]
	ldr	w1, [sp, #48]                   ; 4-byte Reload
	strb	w1, [sp, #251]
	ldr	w1, [sp, #44]                   ; 4-byte Reload
	strb	w1, [sp, #252]
	ldr	w1, [sp, #40]                   ; 4-byte Reload
	strb	w1, [sp, #253]
	ldr	w1, [sp, #36]                   ; 4-byte Reload
	strb	w1, [sp, #254]
	ldr	w1, [sp, #32]                   ; 4-byte Reload
	strb	w1, [sp, #255]
	ldr	w1, [sp, #28]                   ; 4-byte Reload
	strb	w1, [sp, #256]
	ldr	w1, [sp, #24]                   ; 4-byte Reload
	strb	w1, [sp, #257]
	ldr	w1, [sp, #20]                   ; 4-byte Reload
	strb	w1, [sp, #258]
	ldr	w1, [sp, #16]                   ; 4-byte Reload
	strb	w1, [sp, #259]
	ldr	w1, [sp, #12]                   ; 4-byte Reload
	strb	w1, [sp, #260]
	ldr	w1, [sp, #8]                    ; 4-byte Reload
	strb	w1, [sp, #261]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	b.ne	LBB21_6
LBB21_4:                                ; %v20_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #352
	ldur	q2, [x8, #88]
	mov	w10, #2                         ; =0x2
	stp	q0, q1, [sp, #352]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #384]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #352]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #384]
	b	LBB21_7
LBB21_5:                                ; %b1
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #124]
	b	LBB21_8
LBB21_6:                                ; %v25_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #288
	ldur	q2, [x8, #88]
	mov	w10, #7                         ; =0x7
	stp	q0, q1, [sp, #288]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #320]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #288]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #320]
LBB21_7:                                ; %b9
	stur	q0, [x8, #88]
	stur	q1, [x8, #104]
LBB21_8:                                ; %b9
	add	sp, sp, #416
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB21_9:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_example_entry                  ; -- Begin function example_entry
	.p2align	2
_example_entry:                         ; @example_entry
; %bb.0:                                ; %entry
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_stream_start                   ; -- Begin function stream_start
	.p2align	2
_stream_start:                          ; @stream_start
; %bb.0:
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w8, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x0, #8]
	str	xzr, [x0]
	str	wzr, [x0, #24]
	strh	w8, [x0, #28]
	str	wzr, [x0, #32]
	stur	q0, [x0, #40]
	stur	q0, [x0, #56]
	stur	q0, [x0, #72]
	stur	q0, [x0, #88]
	stur	q0, [x0, #104]
	str	wzr, [x0, #120]
	strb	wzr, [x0, #124]
	str	wzr, [x0, #128]
	strb	wzr, [x0, #132]
	str	xzr, [x0, #176]
	str	wzr, [x0, #168]
	stur	q0, [x0, #152]
	stur	q0, [x0, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_stream_feed                    ; -- Begin function stream_feed
	.p2align	2
_stream_feed:                           ; @stream_feed
; %bb.0:
	sub	sp, sp, #80
	ldr	w8, [x0, #168]
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	cbz	w8, LBB24_2
LBB24_1:                                ; %liza_json.feed_mut.exit
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB24_2:                                ; %b4.preheader.i
	mov	x19, x0
	mov	x20, x1
	mov	w22, w2
	mov	x23, #4294967296                ; =0x100000000
LBB24_3:                                ; %b4.i
                                        ; =>This Inner Loop Header: Depth=1
	cbz	x22, LBB24_1
; %bb.4:                                ; %v10_ok.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldp	x1, x2, [x19, #8]
	ldr	x7, [x19, #40]
	ldrb	w21, [x20], #1
	ldr	w6, [x19, #32]
	ldr	w3, [x19, #24]
	ldr	x0, [x19]
	ldrb	w5, [x19, #29]
	ldrb	w4, [x19, #28]
	strb	w21, [sp]
	bl	_liza_utf8_stream.feed_byte
	cmp	w6, #2
	stp	x0, x1, [x19]
	str	x2, [x19, #16]
	str	w3, [x19, #24]
	strb	w4, [x19, #28]
	strb	w5, [x19, #29]
	str	w6, [x19, #32]
	str	x7, [x19, #40]
	b.eq	LBB24_7
; %bb.5:                                ; %v10_ok.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w6, #1
	b.ne	LBB24_8
; %bb.6:                                ; %b1.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, wzr
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB24_9
	b	LBB24_13
LBB24_7:                                ; %b4.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, wzr
	mov	w8, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB24_9
	b	LBB24_13
LBB24_8:                                ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, wzr
	mov	x7, xzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB24_13
LBB24_9:                                ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w0, w21
	mov	x1, x19
	bl	_liza___liza_json_mut_step
	ldr	w8, [x19, #168]
	cbnz	w8, LBB24_1
; %bb.10:                               ; %b16.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	x8, [x19, #48]
	adds	x8, x8, #1
	b.hs	LBB24_12
; %bb.11:                               ; %v46_ok.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	x23, x23, #1
	sub	x22, x22, #1
	str	x8, [x19, #48]
	cbnz	x23, LBB24_3
LBB24_12:                               ; %v46_trap.i
	brk	#0x1
LBB24_13:                               ; %b9.i
	cmp	w8, #0
	mov	w8, #8                          ; =0x8
	mov	w9, #5                          ; =0x5
	csel	w8, w9, w8, eq
	str	x7, [x19, #176]
	str	w8, [x19, #168]
	b	LBB24_1
                                        ; -- End function
	.globl	_stream_status                  ; -- Begin function stream_status
	.p2align	2
_stream_status:                         ; @stream_status
; %bb.0:                                ; %liza_status.exit
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csinc	w0, wzr, w2, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_stream_pending                 ; -- Begin function stream_pending
	.p2align	2
_stream_pending:                        ; @stream_pending
; %bb.0:
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_stream_value                   ; -- Begin function stream_value
	.p2align	2
_stream_value:                          ; @stream_value
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csel	x0, x1, x3, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_stream_size                    ; -- Begin function stream_size
	.p2align	2
_stream_size:                           ; @stream_size
; %bb.0:
	mov	w0, #184                        ; =0xb8
	ret
                                        ; -- End function
.subsections_via_symbols
