; ModuleID = '/private/tmp/liza-state-p2-llvm23/cost400/module.ll'
source_filename = "/private/tmp/liza-state-p2-llvm23/cost400/module.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%struct.JsonState = type { %struct.Utf8StreamState, i64, [64 x i8], i32, i1, i32, i1, i32, i32, i32, i32, i64, i64, i32, i64 }
%struct.Utf8StreamState = type { i64, i64, i64, i32, i8, i8, i32, i64 }
%variant.1 = type { i32, [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8] }
%struct.JsonError = type { %variant.1, i64 }
%variant.4 = type { i32, %struct.JsonError, [0 x i8] }
%variant.5 = type { i32, i64, %struct.JsonError }
%struct.Utf8StreamError = type { %variant.0, i64 }
%variant.0 = type { i32, [0 x i8], [0 x i8] }
%variant.2 = type { i32, i64, %struct.Utf8StreamError }
%variant.3 = type { i32, %struct.Utf8StreamError, [0 x i8] }

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #0

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i32 0, 9) i32 @liza_status(ptr nofree   %p0) local_unnamed_addr #2 {
b0:
  %v33_mem.i = alloca %struct.JsonState, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %v33_mem.i)
  %v0_ptr.i.i = getelementptr i8, ptr %p0, i64 168
  %s2sz0_p = getelementptr i32, ptr null, i32 1
  %s2sz0 = ptrtoint ptr %s2sz0_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr.i.i, i64 %s2sz0)
  %v0.i.i = load i32, ptr %v0_ptr.i.i, align 4
  %v2.i.i = icmp eq i32 %v0.i.i, 0
  %p0.sink.sroa.gep = getelementptr inbounds nuw i8, ptr %p0, i64 160
  %p0.sink.sroa.gep4 = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 160
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2.i.i, label %liza_json.status.exit.i, label %b3.i.i

b3.i.i:                                           ; preds = %b0
  %v7.i.i = icmp eq i32 %v0.i.i, 2
  %v9.i.i = select i1 %v7.i.i, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12.i.i = icmp eq i32 %v0.i.i, 3
  %v14.i.i = select i1 %v12.i.i, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9.i.i
  %v17.i.i = icmp eq i32 %v0.i.i, 4
  %v19.i.i = select i1 %v17.i.i, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14.i.i
  %v22.i.i = icmp eq i32 %v0.i.i, 5
  %v24.i.i = select i1 %v22.i.i, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19.i.i
  %v27.i.i = icmp eq i32 %v0.i.i, 6
  %v29.i.i = select i1 %v27.i.i, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24.i.i
  %v32.i.i = icmp eq i32 %v0.i.i, 7
  %v34.i.i = select i1 %v32.i.i, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29.i.i
  %v37.i.i = icmp eq i32 %v0.i.i, 8
  %v39.i.i = select i1 %v37.i.i, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34.i.i
  %v40_ptr.i.i = getelementptr i8, ptr %p0, i64 176
  %s2sz1_p = getelementptr i64, ptr null, i32 1
  %s2sz1 = ptrtoint ptr %s2sz1_p to i64
  call void @s2_record(i32 0, ptr %v40_ptr.i.i, i64 %s2sz1)
  %v40.i.i = load i64, ptr %v40_ptr.i.i, align 8
  %v41_field0.i.i = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39.i.i, 0
  %v41.i.i = insertvalue %struct.JsonError %v41_field0.i.i, i64 %v40.i.i, 1
  %v42.i.i = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41.i.i, 1
  br label %liza_json.status.exit.i

liza_json.status.exit.i:                          ; preds = %b3.i.i, %b0
  %common.ret.op.i.i = phi %variant.4 [ %v42.i.i, %b3.i.i ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  %v1.i = extractvalue %variant.4 %common.ret.op.i.i, 0
  %0 = icmp eq i32 %v1.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %0, label %b2.i, label %b4.i

b2.i:                                             ; preds = %liza_json.status.exit.i
  %v2.i = extractvalue %variant.4 %common.ret.op.i.i, 1
  %v3.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v2.i, 2
  br label %liza_json.finish.exit

b4.i:                                             ; preds = %liza_json.status.exit.i
  %s2sz2_p = getelementptr %struct.Utf8StreamState, ptr null, i32 1
  %s2sz2 = ptrtoint ptr %s2sz2_p to i64
  call void @s2_record(i32 0, ptr %p0, i64 %s2sz2)
  %v4.i = load %struct.Utf8StreamState, ptr %p0, align 8
  %v0.i3.i = extractvalue %struct.Utf8StreamState %v4.i, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0.i3.i, label %b6.i.i [
    i32 1, label %b1.i.i
    i32 2, label %b4.i.i
  ]

b1.i.i:                                           ; preds = %b4.i
  %v4.i.i = extractvalue %struct.Utf8StreamState %v4.i, 7
  %v5.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i.i, 1
  %v6.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5.i.i, 2
  br label %liza_utf8_stream.finish.exit.i

b4.i.i:                                           ; preds = %b4.i
  %v11.i.i = extractvalue %struct.Utf8StreamState %v4.i, 7
  %v12.i4.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i.i, 1
  %v13.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12.i4.i, 2
  br label %liza_utf8_stream.finish.exit.i

b6.i.i:                                           ; preds = %b4.i
  %v14.i6.i = extractvalue %struct.Utf8StreamState %v4.i, 3
  %v16.not.i.i = icmp eq i32 %v14.i6.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v16.not.i.i, label %b9.i.i, label %b7.i.i

b7.i.i:                                           ; preds = %b6.i.i
  %v18.i.i = extractvalue %struct.Utf8StreamState %v4.i, 2
  %v19.i7.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18.i.i, 1
  %v20.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19.i7.i, 2
  br label %liza_utf8_stream.finish.exit.i

b9.i.i:                                           ; preds = %b6.i.i
  %v21.i.i = extractvalue %struct.Utf8StreamState %v4.i, 1
  %v22.i8.i = insertvalue %variant.2 zeroinitializer, i64 %v21.i.i, 1
  br label %liza_utf8_stream.finish.exit.i

liza_utf8_stream.finish.exit.i:                   ; preds = %b9.i.i, %b7.i.i, %b4.i.i, %b1.i.i
  %common.ret.op.i5.i = phi %variant.2 [ %v6.i.i, %b1.i.i ], [ %v13.i.i, %b4.i.i ], [ %v20.i.i, %b7.i.i ], [ %v22.i8.i, %b9.i.i ]
  %v6.i = extractvalue %variant.2 %common.ret.op.i5.i, 0
  %1 = icmp eq i32 %v6.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %1, label %b6.i, label %b7.i

b6.i:                                             ; preds = %liza_utf8_stream.finish.exit.i
  %v13_ptr.i = getelementptr i8, ptr %p0, i64 128
  %s2sz3_p = getelementptr i32, ptr null, i32 1
  %s2sz3 = ptrtoint ptr %s2sz3_p to i64
  call void @s2_record(i32 0, ptr %v13_ptr.i, i64 %s2sz3)
  %v13.i = load i32, ptr %v13_ptr.i, align 8
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v13.i, label %b19_to_b20.i [
    i32 11, label %b18.i
    i32 12, label %b18.i
    i32 14, label %b18.i
    i32 17, label %b18.i
  ]

b7.i:                                             ; preds = %liza_utf8_stream.finish.exit.i
  %v8.i = extractvalue %variant.2 %common.ret.op.i5.i, 2
  %v10.i = extractvalue %struct.Utf8StreamError %v8.i, 1
  %v11.i = insertvalue %struct.JsonError { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v10.i, 1
  %v12.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v11.i, 2
  br label %liza_json.finish.exit

b18.i:                                            ; preds = %b6.i, %b6.i, %b6.i, %b6.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(184) %v33_mem.i, ptr noundef nonnull  align 1 dereferenceable(184) %p0, i64 184, i1 false)
  %v33_part.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 128
  %s2sz4_p = getelementptr i32, ptr null, i32 1
  %s2sz4 = ptrtoint ptr %s2sz4_p to i64
  call void @s2_record(i32 1, ptr %v33_part.i, i64 %s2sz4)
  store i32 0, ptr %v33_part.i, align 8
  call void @liza___liza_owned___liza_json_done(ptr nonnull sret(%struct.JsonState) %v33_mem.i, ptr nonnull poison)
  %v35_next.sroa.4.0.v33_mem.sroa_idx.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 48
  %s2sz5_p = getelementptr i64, ptr null, i32 1
  %s2sz5 = ptrtoint ptr %s2sz5_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i, i64 %s2sz5)
  %v35_next.sroa.4.0.copyload.i = load i64, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i, align 8
  %v35_next.sroa.8.0.v33_mem.sroa_idx.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 120
  %s2sz6_p = getelementptr i32, ptr null, i32 1
  %s2sz6 = ptrtoint ptr %s2sz6_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i, i64 %s2sz6)
  %v35_next.sroa.8.0.copyload.i = load i32, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i, align 8
  %v35_next.sroa.10.0.v33_mem.sroa_idx.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 124
  %s2sz7_p = getelementptr i8, ptr null, i32 1
  %s2sz7 = ptrtoint ptr %s2sz7_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i, i64 %s2sz7)
  %2 = load i8, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i, align 4
  %s2sz8_p = getelementptr i32, ptr null, i32 1
  %s2sz8 = ptrtoint ptr %s2sz8_p to i64
  call void @s2_record(i32 0, ptr %v33_part.i, i64 %s2sz8)
  %v35_next.sroa.14.0.copyload.i = load i32, ptr %v33_part.i, align 8
  %extract.t3 = trunc i8 %2 to i1
  br label %b20.i

b20.i:                                            ; preds = %b19_to_b20.i, %b18.i
  %p0.sink.sroa.phi = phi ptr [ %p0.sink.sroa.gep, %b19_to_b20.i ], [ %p0.sink.sroa.gep4, %b18.i ]
  %.sink.off0 = phi i1 [ %extract.t2, %b19_to_b20.i ], [ %extract.t3, %b18.i ]
  %v35_mem.sroa.617.0.i = phi i32 [ %v13.i, %b19_to_b20.i ], [ %v35_next.sroa.14.0.copyload.i, %b18.i ]
  %v35_mem.sroa.412.0.i = phi i32 [ %v35_next.sroa.8.0.copyload26.i, %b19_to_b20.i ], [ %v35_next.sroa.8.0.copyload.i, %b18.i ]
  %v35_mem.sroa.2.0.i = phi i64 [ %v35_next.sroa.4.0.copyload25.i, %b19_to_b20.i ], [ %v35_next.sroa.4.0.copyload.i, %b18.i ]
  %3 = add i32 %v35_mem.sroa.617.0.i, -4
  %or.cond.i = icmp ult i32 %3, 3
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond.i, label %b27.i, label %b29.i

b27.i:                                            ; preds = %b20.i
  %s2sz9_p = getelementptr i64, ptr null, i32 1
  %s2sz9 = ptrtoint ptr %s2sz9_p to i64
  call void @s2_record(i32 0, ptr %p0.sink.sroa.phi, i64 %s2sz9)
  %v35_next.sroa.18.0.copyload28.i = load i64, ptr %p0.sink.sroa.phi, align 8
  %v51.i = insertvalue %struct.JsonError { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_next.sroa.18.0.copyload28.i, 1
  %v52.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v51.i, 2
  br label %liza_json.finish.exit

b29.i:                                            ; preds = %b20.i
  %v55.i = icmp eq i32 %v35_mem.sroa.617.0.i, 0
  %v59.i = icmp eq i32 %v35_mem.sroa.412.0.i, 0
  %v60.not2.i = select i1 %v55.i, i1 %v59.i, i1 false
  %or.cond1.not.i = select i1 %v60.not2.i, i1 %.sink.off0, i1 false
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond1.not.i, label %b38.i, label %b36.i

b36.i:                                            ; preds = %b29.i
  %v67.i = insertvalue %struct.JsonError { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.2.0.i, 1
  %v68.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v67.i, 2
  br label %liza_json.finish.exit

b38.i:                                            ; preds = %b29.i
  %v70.i = insertvalue %variant.5 zeroinitializer, i64 %v35_mem.sroa.2.0.i, 1
  br label %liza_json.finish.exit

b19_to_b20.i:                                     ; preds = %b6.i
  %v35_next.sroa.4.0.p0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %p0, i64 48
  %s2sz10_p = getelementptr i64, ptr null, i32 1
  %s2sz10 = ptrtoint ptr %s2sz10_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.p0.sroa_idx.i, i64 %s2sz10)
  %v35_next.sroa.4.0.copyload25.i = load i64, ptr %v35_next.sroa.4.0.p0.sroa_idx.i, align 8
  %v35_next.sroa.8.0.p0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %p0, i64 120
  %s2sz11_p = getelementptr i32, ptr null, i32 1
  %s2sz11 = ptrtoint ptr %s2sz11_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.p0.sroa_idx.i, i64 %s2sz11)
  %v35_next.sroa.8.0.copyload26.i = load i32, ptr %v35_next.sroa.8.0.p0.sroa_idx.i, align 8
  %v35_next.sroa.10.0.p0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %p0, i64 124
  %s2sz12_p = getelementptr i8, ptr null, i32 1
  %s2sz12 = ptrtoint ptr %s2sz12_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.p0.sroa_idx.i, i64 %s2sz12)
  %4 = load i8, ptr %v35_next.sroa.10.0.p0.sroa_idx.i, align 4
  %extract.t2 = trunc i8 %4 to i1
  br label %b20.i

liza_json.finish.exit:                            ; preds = %b2.i, %b7.i, %b27.i, %b36.i, %b38.i
  %common.ret.op.i = phi %variant.5 [ %v3.i, %b2.i ], [ %v12.i, %b7.i ], [ %v52.i, %b27.i ], [ %v68.i, %b36.i ], [ %v70.i, %b38.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %v33_mem.i)
  %v1 = extractvalue %variant.5 %common.ret.op.i, 0
  %5 = icmp eq i32 %v1, 0
  %v4 = extractvalue %variant.5 %common.ret.op.i, 2
  %v5 = extractvalue %struct.JsonError %v4, 0
  %v6 = extractvalue %variant.1 %v5, 0
  %switch.offset = add nsw i32 %v6, 1
  %common.ret.op = select i1 %5, i32 0, i32 %switch.offset
  ret i32 %common.ret.op
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @liza_value(ptr nofree   %p0) local_unnamed_addr #2 {
b0:
  %v33_mem.i = alloca %struct.JsonState, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %v33_mem.i)
  %v0_ptr.i.i = getelementptr i8, ptr %p0, i64 168
  %s2sz13_p = getelementptr i32, ptr null, i32 1
  %s2sz13 = ptrtoint ptr %s2sz13_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr.i.i, i64 %s2sz13)
  %v0.i.i = load i32, ptr %v0_ptr.i.i, align 4
  %v2.i.i = icmp eq i32 %v0.i.i, 0
  %p0.sink.sroa.gep = getelementptr inbounds nuw i8, ptr %p0, i64 160
  %p0.sink.sroa.gep4 = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 160
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2.i.i, label %liza_json.status.exit.i, label %b3.i.i

b3.i.i:                                           ; preds = %b0
  %v7.i.i = icmp eq i32 %v0.i.i, 2
  %v9.i.i = select i1 %v7.i.i, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12.i.i = icmp eq i32 %v0.i.i, 3
  %v14.i.i = select i1 %v12.i.i, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9.i.i
  %v17.i.i = icmp eq i32 %v0.i.i, 4
  %v19.i.i = select i1 %v17.i.i, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14.i.i
  %v22.i.i = icmp eq i32 %v0.i.i, 5
  %v24.i.i = select i1 %v22.i.i, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19.i.i
  %v27.i.i = icmp eq i32 %v0.i.i, 6
  %v29.i.i = select i1 %v27.i.i, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24.i.i
  %v32.i.i = icmp eq i32 %v0.i.i, 7
  %v34.i.i = select i1 %v32.i.i, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29.i.i
  %v37.i.i = icmp eq i32 %v0.i.i, 8
  %v39.i.i = select i1 %v37.i.i, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34.i.i
  %v40_ptr.i.i = getelementptr i8, ptr %p0, i64 176
  %s2sz14_p = getelementptr i64, ptr null, i32 1
  %s2sz14 = ptrtoint ptr %s2sz14_p to i64
  call void @s2_record(i32 0, ptr %v40_ptr.i.i, i64 %s2sz14)
  %v40.i.i = load i64, ptr %v40_ptr.i.i, align 8
  %v41_field0.i.i = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39.i.i, 0
  %v41.i.i = insertvalue %struct.JsonError %v41_field0.i.i, i64 %v40.i.i, 1
  %v42.i.i = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41.i.i, 1
  br label %liza_json.status.exit.i

liza_json.status.exit.i:                          ; preds = %b3.i.i, %b0
  %common.ret.op.i.i = phi %variant.4 [ %v42.i.i, %b3.i.i ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  %v1.i = extractvalue %variant.4 %common.ret.op.i.i, 0
  %0 = icmp eq i32 %v1.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %0, label %b2.i, label %b4.i

b2.i:                                             ; preds = %liza_json.status.exit.i
  %v2.i = extractvalue %variant.4 %common.ret.op.i.i, 1
  %v3.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v2.i, 2
  br label %liza_json.finish.exit

b4.i:                                             ; preds = %liza_json.status.exit.i
  %s2sz15_p = getelementptr %struct.Utf8StreamState, ptr null, i32 1
  %s2sz15 = ptrtoint ptr %s2sz15_p to i64
  call void @s2_record(i32 0, ptr %p0, i64 %s2sz15)
  %v4.i = load %struct.Utf8StreamState, ptr %p0, align 8
  %v0.i3.i = extractvalue %struct.Utf8StreamState %v4.i, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0.i3.i, label %b6.i.i [
    i32 1, label %b1.i.i
    i32 2, label %b4.i.i
  ]

b1.i.i:                                           ; preds = %b4.i
  %v4.i.i = extractvalue %struct.Utf8StreamState %v4.i, 7
  %v5.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i.i, 1
  %v6.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5.i.i, 2
  br label %liza_utf8_stream.finish.exit.i

b4.i.i:                                           ; preds = %b4.i
  %v11.i.i = extractvalue %struct.Utf8StreamState %v4.i, 7
  %v12.i4.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i.i, 1
  %v13.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12.i4.i, 2
  br label %liza_utf8_stream.finish.exit.i

b6.i.i:                                           ; preds = %b4.i
  %v14.i6.i = extractvalue %struct.Utf8StreamState %v4.i, 3
  %v16.not.i.i = icmp eq i32 %v14.i6.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v16.not.i.i, label %b9.i.i, label %b7.i.i

b7.i.i:                                           ; preds = %b6.i.i
  %v18.i.i = extractvalue %struct.Utf8StreamState %v4.i, 2
  %v19.i7.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18.i.i, 1
  %v20.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19.i7.i, 2
  br label %liza_utf8_stream.finish.exit.i

b9.i.i:                                           ; preds = %b6.i.i
  %v21.i.i = extractvalue %struct.Utf8StreamState %v4.i, 1
  %v22.i8.i = insertvalue %variant.2 zeroinitializer, i64 %v21.i.i, 1
  br label %liza_utf8_stream.finish.exit.i

liza_utf8_stream.finish.exit.i:                   ; preds = %b9.i.i, %b7.i.i, %b4.i.i, %b1.i.i
  %common.ret.op.i5.i = phi %variant.2 [ %v6.i.i, %b1.i.i ], [ %v13.i.i, %b4.i.i ], [ %v20.i.i, %b7.i.i ], [ %v22.i8.i, %b9.i.i ]
  %v6.i = extractvalue %variant.2 %common.ret.op.i5.i, 0
  %1 = icmp eq i32 %v6.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %1, label %b6.i, label %b7.i

b6.i:                                             ; preds = %liza_utf8_stream.finish.exit.i
  %v13_ptr.i = getelementptr i8, ptr %p0, i64 128
  %s2sz16_p = getelementptr i32, ptr null, i32 1
  %s2sz16 = ptrtoint ptr %s2sz16_p to i64
  call void @s2_record(i32 0, ptr %v13_ptr.i, i64 %s2sz16)
  %v13.i = load i32, ptr %v13_ptr.i, align 8
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v13.i, label %b19_to_b20.i [
    i32 11, label %b18.i
    i32 12, label %b18.i
    i32 14, label %b18.i
    i32 17, label %b18.i
  ]

b7.i:                                             ; preds = %liza_utf8_stream.finish.exit.i
  %v8.i = extractvalue %variant.2 %common.ret.op.i5.i, 2
  %v10.i = extractvalue %struct.Utf8StreamError %v8.i, 1
  %v11.i = insertvalue %struct.JsonError { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v10.i, 1
  %v12.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v11.i, 2
  br label %liza_json.finish.exit

b18.i:                                            ; preds = %b6.i, %b6.i, %b6.i, %b6.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(184) %v33_mem.i, ptr noundef nonnull  align 1 dereferenceable(184) %p0, i64 184, i1 false)
  %v33_part.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 128
  %s2sz17_p = getelementptr i32, ptr null, i32 1
  %s2sz17 = ptrtoint ptr %s2sz17_p to i64
  call void @s2_record(i32 1, ptr %v33_part.i, i64 %s2sz17)
  store i32 0, ptr %v33_part.i, align 8
  call void @liza___liza_owned___liza_json_done(ptr nonnull sret(%struct.JsonState) %v33_mem.i, ptr nonnull poison)
  %v35_next.sroa.4.0.v33_mem.sroa_idx.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 48
  %s2sz18_p = getelementptr i64, ptr null, i32 1
  %s2sz18 = ptrtoint ptr %s2sz18_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i, i64 %s2sz18)
  %v35_next.sroa.4.0.copyload.i = load i64, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i, align 8
  %v35_next.sroa.8.0.v33_mem.sroa_idx.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 120
  %s2sz19_p = getelementptr i32, ptr null, i32 1
  %s2sz19 = ptrtoint ptr %s2sz19_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i, i64 %s2sz19)
  %v35_next.sroa.8.0.copyload.i = load i32, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i, align 8
  %v35_next.sroa.10.0.v33_mem.sroa_idx.i = getelementptr inbounds nuw i8, ptr %v33_mem.i, i64 124
  %s2sz20_p = getelementptr i8, ptr null, i32 1
  %s2sz20 = ptrtoint ptr %s2sz20_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i, i64 %s2sz20)
  %2 = load i8, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i, align 4
  %s2sz21_p = getelementptr i32, ptr null, i32 1
  %s2sz21 = ptrtoint ptr %s2sz21_p to i64
  call void @s2_record(i32 0, ptr %v33_part.i, i64 %s2sz21)
  %v35_next.sroa.14.0.copyload.i = load i32, ptr %v33_part.i, align 8
  %extract.t3 = trunc i8 %2 to i1
  br label %b20.i

b20.i:                                            ; preds = %b19_to_b20.i, %b18.i
  %p0.sink.sroa.phi = phi ptr [ %p0.sink.sroa.gep, %b19_to_b20.i ], [ %p0.sink.sroa.gep4, %b18.i ]
  %.sink.off0 = phi i1 [ %extract.t2, %b19_to_b20.i ], [ %extract.t3, %b18.i ]
  %v35_mem.sroa.617.0.i = phi i32 [ %v13.i, %b19_to_b20.i ], [ %v35_next.sroa.14.0.copyload.i, %b18.i ]
  %v35_mem.sroa.412.0.i = phi i32 [ %v35_next.sroa.8.0.copyload26.i, %b19_to_b20.i ], [ %v35_next.sroa.8.0.copyload.i, %b18.i ]
  %v35_mem.sroa.2.0.i = phi i64 [ %v35_next.sroa.4.0.copyload25.i, %b19_to_b20.i ], [ %v35_next.sroa.4.0.copyload.i, %b18.i ]
  %3 = add i32 %v35_mem.sroa.617.0.i, -4
  %or.cond.i = icmp ult i32 %3, 3
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond.i, label %b27.i, label %b29.i

b27.i:                                            ; preds = %b20.i
  %s2sz22_p = getelementptr i64, ptr null, i32 1
  %s2sz22 = ptrtoint ptr %s2sz22_p to i64
  call void @s2_record(i32 0, ptr %p0.sink.sroa.phi, i64 %s2sz22)
  %v35_next.sroa.18.0.copyload28.i = load i64, ptr %p0.sink.sroa.phi, align 8
  %v51.i = insertvalue %struct.JsonError { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_next.sroa.18.0.copyload28.i, 1
  %v52.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v51.i, 2
  br label %liza_json.finish.exit

b29.i:                                            ; preds = %b20.i
  %v55.i = icmp eq i32 %v35_mem.sroa.617.0.i, 0
  %v59.i = icmp eq i32 %v35_mem.sroa.412.0.i, 0
  %v60.not2.i = select i1 %v55.i, i1 %v59.i, i1 false
  %or.cond1.not.i = select i1 %v60.not2.i, i1 %.sink.off0, i1 false
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond1.not.i, label %b38.i, label %b36.i

b36.i:                                            ; preds = %b29.i
  %v67.i = insertvalue %struct.JsonError { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.2.0.i, 1
  %v68.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v67.i, 2
  br label %liza_json.finish.exit

b38.i:                                            ; preds = %b29.i
  %v70.i = insertvalue %variant.5 zeroinitializer, i64 %v35_mem.sroa.2.0.i, 1
  br label %liza_json.finish.exit

b19_to_b20.i:                                     ; preds = %b6.i
  %v35_next.sroa.4.0.p0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %p0, i64 48
  %s2sz23_p = getelementptr i64, ptr null, i32 1
  %s2sz23 = ptrtoint ptr %s2sz23_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.p0.sroa_idx.i, i64 %s2sz23)
  %v35_next.sroa.4.0.copyload25.i = load i64, ptr %v35_next.sroa.4.0.p0.sroa_idx.i, align 8
  %v35_next.sroa.8.0.p0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %p0, i64 120
  %s2sz24_p = getelementptr i32, ptr null, i32 1
  %s2sz24 = ptrtoint ptr %s2sz24_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.p0.sroa_idx.i, i64 %s2sz24)
  %v35_next.sroa.8.0.copyload26.i = load i32, ptr %v35_next.sroa.8.0.p0.sroa_idx.i, align 8
  %v35_next.sroa.10.0.p0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %p0, i64 124
  %s2sz25_p = getelementptr i8, ptr null, i32 1
  %s2sz25 = ptrtoint ptr %s2sz25_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.p0.sroa_idx.i, i64 %s2sz25)
  %4 = load i8, ptr %v35_next.sroa.10.0.p0.sroa_idx.i, align 4
  %extract.t2 = trunc i8 %4 to i1
  br label %b20.i

liza_json.finish.exit:                            ; preds = %b2.i, %b7.i, %b27.i, %b36.i, %b38.i
  %common.ret.op.i = phi %variant.5 [ %v3.i, %b2.i ], [ %v12.i, %b7.i ], [ %v52.i, %b27.i ], [ %v68.i, %b36.i ], [ %v70.i, %b38.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %v33_mem.i)
  %v1 = extractvalue %variant.5 %common.ret.op.i, 0
  %5 = icmp eq i32 %v1, 0
  %v2 = extractvalue %variant.5 %common.ret.op.i, 1
  %v3 = extractvalue %variant.5 %common.ret.op.i, 2
  %v4 = extractvalue %struct.JsonError %v3, 1
  %common.ret.op = select i1 %5, i64 %v2, i64 %v4
  ret i64 %common.ret.op
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define range(i32 0, 2) i32 @liza_pending(ptr nofree   %p0) local_unnamed_addr #3 {
b0:
  %v0_ptr.i = getelementptr i8, ptr %p0, i64 168
  %s2sz26_p = getelementptr i32, ptr null, i32 1
  %s2sz26 = ptrtoint ptr %s2sz26_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr.i, i64 %s2sz26)
  %v0.i = load i32, ptr %v0_ptr.i, align 4
  %v2.i.not = icmp ne i32 %v0.i, 0
  %spec.select = zext i1 %v2.i.not to i32
  ret i32 %spec.select
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @liza_start(ptr nofree writeonly sret(%struct.JsonState)  initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %return_storage) local_unnamed_addr #4 {
b0:
  %v16_mem.sroa.75.sroa.0.i = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0.i = alloca i8, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  %s2sz27_p = getelementptr i1, ptr null, i32 1
  %s2sz27 = ptrtoint ptr %s2sz27_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.75.sroa.0.i, i64 %s2sz27)
  store i1 false, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  %s2sz28_p = getelementptr i1, ptr null, i32 1
  %s2sz28 = ptrtoint ptr %s2sz28_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.77.sroa.0.i, i64 %s2sz28)
  store i1 false, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %s2sz29_p = getelementptr i8, ptr null, i32 1
  %s2sz29 = ptrtoint ptr %s2sz29_p to i64
  call void @s2_record(i32 0, ptr %v16_mem.sroa.75.sroa.0.i, i64 %s2sz29)
  %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i = load i8, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  %s2sz30_p = getelementptr i8, ptr null, i32 1
  %s2sz30 = ptrtoint ptr %s2sz30_p to i64
  call void @s2_record(i32 0, ptr %v16_mem.sroa.77.sroa.0.i, i64 %s2sz30)
  %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i = load i8, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %return_storage, i8 0, i64 28, i1 false)
  %v0_mem.sroa.2.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 28
  %s2sz31_p = getelementptr i8, ptr null, i32 1
  %s2sz31 = ptrtoint ptr %s2sz31_p to i64
  call void @s2_record(i32 1, ptr %v0_mem.sroa.2.0.return_storage.sroa_idx, i64 %s2sz31)
  store i8 -128, ptr %v0_mem.sroa.2.0.return_storage.sroa_idx, align 4
  %v0_mem.sroa.3.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 29
  %s2sz32_p = getelementptr i8, ptr null, i32 1
  %s2sz32 = ptrtoint ptr %s2sz32_p to i64
  call void @s2_record(i32 1, ptr %v0_mem.sroa.3.0.return_storage.sroa_idx, i64 %s2sz32)
  store i8 -65, ptr %v0_mem.sroa.3.0.return_storage.sroa_idx, align 1
  %v0_mem.sroa.41.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 32
  %s2sz33_p = getelementptr i32, ptr null, i32 1
  %s2sz33 = ptrtoint ptr %s2sz33_p to i64
  call void @s2_record(i32 1, ptr %v0_mem.sroa.41.0.return_storage.sroa_idx, i64 %s2sz33)
  store i32 0, ptr %v0_mem.sroa.41.0.return_storage.sroa_idx, align 8
  %0 = getelementptr inbounds nuw i8, ptr %return_storage, i64 40
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %0, i8 0, i64 84, i1 false)
  %v0_mem.sroa.6.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  %s2sz34_p = getelementptr i8, ptr null, i32 1
  %s2sz34 = ptrtoint ptr %s2sz34_p to i64
  call void @s2_record(i32 1, ptr %v0_mem.sroa.6.0.return_storage.sroa_idx, i64 %s2sz34)
  store i8 %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i, ptr %v0_mem.sroa.6.0.return_storage.sroa_idx, align 4
  %v0_mem.sroa.72.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 128
  %s2sz35_p = getelementptr i32, ptr null, i32 1
  %s2sz35 = ptrtoint ptr %s2sz35_p to i64
  call void @s2_record(i32 1, ptr %v0_mem.sroa.72.0.return_storage.sroa_idx, i64 %s2sz35)
  store i32 0, ptr %v0_mem.sroa.72.0.return_storage.sroa_idx, align 8
  %v0_mem.sroa.8.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 132
  %s2sz36_p = getelementptr i8, ptr null, i32 1
  %s2sz36 = ptrtoint ptr %s2sz36_p to i64
  call void @s2_record(i32 1, ptr %v0_mem.sroa.8.0.return_storage.sroa_idx, i64 %s2sz36)
  store i8 %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i, ptr %v0_mem.sroa.8.0.return_storage.sroa_idx, align 4
  %1 = getelementptr inbounds nuw i8, ptr %return_storage, i64 136
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %1, i8 0, i64 36, i1 false)
  %v0_mem.sroa.103.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 176
  %s2sz37_p = getelementptr i64, ptr null, i32 1
  %s2sz37 = ptrtoint ptr %s2sz37_p to i64
  call void @s2_record(i32 1, ptr %v0_mem.sroa.103.0.return_storage.sroa_idx, i64 %s2sz37)
  store i64 0, ptr %v0_mem.sroa.103.0.return_storage.sroa_idx, align 8
  ret void
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write, target_mem: none)
define i32 @liza_feed(ptr %p0, { ptr, i32 } %p1) local_unnamed_addr #5 {
b0:
  %v1 = tail call i32 @liza_json.feed_mut(ptr %p0, { ptr, i32 } %p1)
  ret i32 %v1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @liza_main() local_unnamed_addr #6 {
b0:
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %struct.Utf8StreamState @liza_utf8_stream.create() local_unnamed_addr #6 {
b0:
  ret %struct.Utf8StreamState { i64 0, i64 0, i64 0, i32 0, i8 -128, i8 -65, i32 0, i64 0 }
}

; Function Attrs: nounwind memory(inaccessiblemem: write)
define %struct.Utf8StreamState @liza_utf8_stream.feed_byte(%struct.Utf8StreamState %p0, i8 %p1) local_unnamed_addr #7 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  %v2.not = icmp eq i32 %v0, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2.not, label %b3, label %common.ret

common.ret:                                       ; preds = %b0, %v145_ok, %b53, %b48, %b34, %b11, %b4
  %common.ret.op = phi %struct.Utf8StreamState [ %v146, %v145_ok ], [ %v11, %b4 ], [ %v28, %b11 ], [ %v96, %b34 ], [ %v111, %b48 ], [ %v134, %b53 ], [ %p0, %b0 ]
  ret %struct.Utf8StreamState %common.ret.op

b3:                                               ; preds = %b0
  %v3 = extractvalue %struct.Utf8StreamState %p0, 0
  %v5 = icmp eq i64 %v3, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v5, label %b4, label %b6

b4:                                               ; preds = %b3
  %v8 = insertvalue %struct.Utf8StreamState %p0, i32 2, 6
  %v11 = insertvalue %struct.Utf8StreamState %v8, i64 -1, 7
  br label %common.ret

b6:                                               ; preds = %b3
  %v12 = extractvalue %struct.Utf8StreamState %p0, 3
  %v14 = icmp eq i32 %v12, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v14, label %b7, label %b8

b7:                                               ; preds = %b6
  %v17 = insertvalue %struct.Utf8StreamState %p0, i64 %v3, 2
  %v19 = icmp sgt i8 %p1, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v19, label %b9, label %b10

b8:                                               ; preds = %b6
  %v100 = extractvalue %struct.Utf8StreamState %p0, 4
  %v101 = icmp ult i8 %p1, %v100
  %v103 = extractvalue %struct.Utf8StreamState %p0, 5
  %v104 = icmp ugt i8 %p1, %v103
  %v105 = select i1 %v101, i1 true, i1 %v104
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v105, label %b48, label %v115_ok

b9:                                               ; preds = %b7
  %v20 = extractvalue %struct.Utf8StreamState %p0, 1
  %v22 = icmp eq i64 %v20, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v22, label %b11, label %v32_ok

b10:                                              ; preds = %b7
  %v36 = insertvalue %struct.Utf8StreamState %v17, i8 -128, 4
  %v39 = insertvalue %struct.Utf8StreamState %v36, i8 -65, 5
  %0 = add nsw i8 %p1, 62
  %v45 = icmp ult i8 %0, 30
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v45, label %b17, label %b18

b11:                                              ; preds = %b9
  %v25 = insertvalue %struct.Utf8StreamState %v17, i32 2, 6
  %v28 = insertvalue %struct.Utf8StreamState %v25, i64 %v3, 7
  br label %common.ret

v32_ok:                                           ; preds = %b9
  %v32 = add nuw i64 %v20, 1
  %v33 = insertvalue %struct.Utf8StreamState %v17, i64 %v32, 1
  br label %b57

b17:                                              ; preds = %b10
  %v48 = insertvalue %struct.Utf8StreamState %v39, i32 1, 3
  br label %b57

b18:                                              ; preds = %b10
  %1 = and i8 %p1, -16
  %v54 = icmp eq i8 %1, -32
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v54, label %b22, label %b23

b22:                                              ; preds = %b18
  %v57 = insertvalue %struct.Utf8StreamState %v39, i32 2, 3
  %v59 = icmp eq i8 %p1, -32
  %v62 = insertvalue %struct.Utf8StreamState %v57, i8 -96, 4
  %spec.select = select i1 %v59, %struct.Utf8StreamState %v62, %struct.Utf8StreamState %v57
  %v65 = icmp eq i8 %p1, -19
  %v68 = insertvalue %struct.Utf8StreamState %spec.select, i8 -97, 5
  %spec.select2 = select i1 %v65, %struct.Utf8StreamState %v68, %struct.Utf8StreamState %spec.select
  br label %b57

b23:                                              ; preds = %b18
  %2 = add nsw i8 %p1, 16
  %v75 = icmp ult i8 %2, 5
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v75, label %b33, label %b34

b33:                                              ; preds = %b23
  %v78 = insertvalue %struct.Utf8StreamState %v39, i32 3, 3
  %v80 = icmp eq i8 %p1, -16
  %v83 = insertvalue %struct.Utf8StreamState %v78, i8 -112, 4
  %spec.select1 = select i1 %v80, %struct.Utf8StreamState %v83, %struct.Utf8StreamState %v78
  %v86 = icmp eq i8 %p1, -12
  %v89 = insertvalue %struct.Utf8StreamState %spec.select1, i8 -113, 5
  %spec.select3 = select i1 %v86, %struct.Utf8StreamState %v89, %struct.Utf8StreamState %spec.select1
  br label %b57

b34:                                              ; preds = %b23
  %v93 = insertvalue %struct.Utf8StreamState %v39, i32 1, 6
  %v96 = insertvalue %struct.Utf8StreamState %v93, i64 %v3, 7
  br label %common.ret

b48:                                              ; preds = %b8
  %v108 = insertvalue %struct.Utf8StreamState %p0, i32 1, 6
  %v110 = extractvalue %struct.Utf8StreamState %p0, 2
  %v111 = insertvalue %struct.Utf8StreamState %v108, i64 %v110, 7
  br label %common.ret

v115_ok:                                          ; preds = %b8
  %v115 = add i32 %v12, -1
  %v116 = insertvalue %struct.Utf8StreamState %p0, i32 %v115, 3
  %v119 = insertvalue %struct.Utf8StreamState %v116, i8 -128, 4
  %v122 = insertvalue %struct.Utf8StreamState %v119, i8 -65, 5
  %v125 = icmp eq i32 %v115, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v125, label %b51, label %b57

b51:                                              ; preds = %v115_ok
  %v126 = extractvalue %struct.Utf8StreamState %p0, 1
  %v128 = icmp eq i64 %v126, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v128, label %b53, label %v138_ok

b53:                                              ; preds = %b51
  %v131 = insertvalue %struct.Utf8StreamState %v122, i32 2, 6
  %v134 = insertvalue %struct.Utf8StreamState %v131, i64 %v3, 7
  br label %common.ret

v138_ok:                                          ; preds = %b51
  %v138 = add nuw i64 %v126, 1
  %v139 = insertvalue %struct.Utf8StreamState %v122, i64 %v138, 1
  br label %b57

b57:                                              ; preds = %b33, %b22, %v138_ok, %v115_ok, %v32_ok, %b17
  %v141 = phi %struct.Utf8StreamState [ %v139, %v138_ok ], [ %v33, %v32_ok ], [ %v48, %b17 ], [ %spec.select3, %b33 ], [ %v122, %v115_ok ], [ %spec.select2, %b22 ]
  %v143 = extractvalue %struct.Utf8StreamState %v141, 0
  call void @s2_record(i32 3, ptr null, i64 0)
  %v145_pair = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v143, i64 1)
  %v145_overflow = extractvalue { i64, i1 } %v145_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v145_overflow, label %v145_trap, label %v145_ok

v145_trap:                                        ; preds = %b57
  tail call void @llvm.trap()
  unreachable

v145_ok:                                          ; preds = %b57
  %v145 = extractvalue { i64, i1 } %v145_pair, 0
  %v146 = insertvalue %struct.Utf8StreamState %v141, i64 %v145, 0
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.2 @liza_utf8_stream.finish(%struct.Utf8StreamState %p0) local_unnamed_addr #6 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0, label %b6 [
    i32 1, label %b1
    i32 2, label %b4
  ]

common.ret:                                       ; preds = %b9, %b7, %b4, %b1
  %common.ret.op = phi %variant.2 [ %v6, %b1 ], [ %v13, %b4 ], [ %v20, %b7 ], [ %v22, %b9 ]
  ret %variant.2 %common.ret.op

b1:                                               ; preds = %b0
  %v4 = extractvalue %struct.Utf8StreamState %p0, 7
  %v5 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4, 1
  %v6 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5, 2
  br label %common.ret

b4:                                               ; preds = %b0
  %v11 = extractvalue %struct.Utf8StreamState %p0, 7
  %v12 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11, 1
  %v13 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12, 2
  br label %common.ret

b6:                                               ; preds = %b0
  %v14 = extractvalue %struct.Utf8StreamState %p0, 3
  %v16.not = icmp eq i32 %v14, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v16.not, label %b9, label %b7

b7:                                               ; preds = %b6
  %v18 = extractvalue %struct.Utf8StreamState %p0, 2
  %v19 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18, 1
  %v20 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19, 2
  br label %common.ret

b9:                                               ; preds = %b6
  %v21 = extractvalue %struct.Utf8StreamState %p0, 1
  %v22 = insertvalue %variant.2 zeroinitializer, i64 %v21, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.3 @liza_utf8_stream.status(%struct.Utf8StreamState %p0) local_unnamed_addr #6 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0, label %common.ret [
    i32 1, label %b1
    i32 2, label %b4
  ]

common.ret:                                       ; preds = %b0, %b4, %b1
  %common.ret.op = phi %variant.3 [ %v6, %b1 ], [ %v13, %b4 ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  ret %variant.3 %common.ret.op

b1:                                               ; preds = %b0
  %v4 = extractvalue %struct.Utf8StreamState %p0, 7
  %v5 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4, 1
  %v6 = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5, 1
  br label %common.ret

b4:                                               ; preds = %b0
  %v11 = extractvalue %struct.Utf8StreamState %p0, 7
  %v12 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11, 1
  %v13 = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @liza_json.create(ptr nofree writeonly sret(%struct.JsonState)  initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %return_storage) local_unnamed_addr #4 {
b0:
  %v16_mem.sroa.75.sroa.0 = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0 = alloca i8, align 4
  %s2sz38_p = getelementptr i1, ptr null, i32 1
  %s2sz38 = ptrtoint ptr %s2sz38_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.75.sroa.0, i64 %s2sz38)
  store i1 false, ptr %v16_mem.sroa.75.sroa.0, align 4
  %s2sz39_p = getelementptr i1, ptr null, i32 1
  %s2sz39 = ptrtoint ptr %s2sz39_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.77.sroa.0, i64 %s2sz39)
  store i1 false, ptr %v16_mem.sroa.77.sroa.0, align 4
  %v16_mem.sroa.5.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 28
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %return_storage, i8 0, i64 28, i1 false)
  %s2sz40_p = getelementptr i8, ptr null, i32 1
  %s2sz40 = ptrtoint ptr %s2sz40_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx, i64 %s2sz40)
  store i8 -128, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.6.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 29
  %s2sz41_p = getelementptr i8, ptr null, i32 1
  %s2sz41 = ptrtoint ptr %s2sz41_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx, i64 %s2sz41)
  store i8 -65, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx, align 1
  %v16_mem.sroa.71.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 32
  %s2sz42_p = getelementptr i32, ptr null, i32 1
  %s2sz42 = ptrtoint ptr %s2sz42_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx, i64 %s2sz42)
  store i32 0, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx, align 8
  %v16_mem.sroa.82.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 40
  %v16_mem.sroa.75.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %v16_mem.sroa.82.0.return_storage.sroa_idx, i8 0, i64 84, i1 false)
  %s2sz43_p = getelementptr i8, ptr null, i32 1
  %s2sz43 = ptrtoint ptr %s2sz43_p to i64
  call void @s2_record(i32 0, ptr %v16_mem.sroa.75.sroa.0, i64 %s2sz43)
  %v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0. = load i8, ptr %v16_mem.sroa.75.sroa.0, align 4
  %s2sz44_p = getelementptr i8, ptr null, i32 1
  %s2sz44 = ptrtoint ptr %s2sz44_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.75.0.return_storage.sroa_idx, i64 %s2sz44)
  store i8 %v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0., ptr %v16_mem.sroa.75.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.764.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 128
  %s2sz45_p = getelementptr i32, ptr null, i32 1
  %s2sz45 = ptrtoint ptr %s2sz45_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx, i64 %s2sz45)
  store i32 0, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx, align 8
  %v16_mem.sroa.77.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 132
  %s2sz46_p = getelementptr i8, ptr null, i32 1
  %s2sz46 = ptrtoint ptr %s2sz46_p to i64
  call void @s2_record(i32 0, ptr %v16_mem.sroa.77.sroa.0, i64 %s2sz46)
  %v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0. = load i8, ptr %v16_mem.sroa.77.sroa.0, align 4
  %s2sz47_p = getelementptr i8, ptr null, i32 1
  %s2sz47 = ptrtoint ptr %s2sz47_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.77.0.return_storage.sroa_idx, i64 %s2sz47)
  store i8 %v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0., ptr %v16_mem.sroa.77.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.785.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 136
  %v16_mem.sroa.857.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 176
  %s2sz48_p = getelementptr i64, ptr null, i32 1
  %s2sz48 = ptrtoint ptr %s2sz48_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx, i64 %s2sz48)
  store i64 0, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %v16_mem.sroa.785.0.return_storage.sroa_idx, i8 0, i64 36, i1 false)
  ret void
}

; Function Attrs: nounwind memory(readwrite, inaccessiblemem: write, target_mem: none)
define void @liza___liza_json_done(ptr nofree writeonly sret(%struct.JsonState)  %return_storage, ptr nofree  %p0) local_unnamed_addr #8 {
b0:
  %v5_mem.sroa.67.sroa.0 = alloca i8, align 4
  %v22_scratch = alloca [64 x i8], align 1
  %v27_scratch = alloca [64 x i8], align 1
  %v29_mem.sroa.0 = alloca { %struct.Utf8StreamState, i64 }, align 8
  %v29_mem.sroa.131.sroa.4 = alloca [59 x i8], align 1
  %v30_mem.sroa.0 = alloca { %struct.Utf8StreamState, i64 }, align 8
  %v30_mem.sroa.131.sroa.5 = alloca [59 x i8], align 1
  %v14_storage = alloca [64 x i8], align 1
  %v9_storage = alloca [64 x i8], align 1
  %v0_ptr = getelementptr i8, ptr %p0, i64 120
  %s2sz49_p = getelementptr i32, ptr null, i32 1
  %s2sz49 = ptrtoint ptr %s2sz49_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr, i64 %s2sz49)
  %v0 = load i32, ptr %v0_ptr, align 4
  %v2 = icmp eq i32 %v0, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2, label %b1, label %b2

b1:                                               ; preds = %b0
  %v5_mem.sroa.2.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 56
  %s2sz50_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz50 = ptrtoint ptr %s2sz50_p to i64
  call void @s2_record(i32 0, ptr %v5_mem.sroa.2.0.p0.sroa_idx, i64 %s2sz50)
  %0 = load <16 x i8>, ptr %v5_mem.sroa.2.0.p0.sroa_idx, align 4
  %v5_mem.sroa.18.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 72
  %s2sz51_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz51 = ptrtoint ptr %s2sz51_p to i64
  call void @s2_record(i32 0, ptr %v5_mem.sroa.18.0.p0.sroa_idx, i64 %s2sz51)
  %1 = load <16 x i8>, ptr %v5_mem.sroa.18.0.p0.sroa_idx, align 4
  %v5_mem.sroa.34.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 88
  %s2sz52_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz52 = ptrtoint ptr %s2sz52_p to i64
  call void @s2_record(i32 0, ptr %v5_mem.sroa.34.0.p0.sroa_idx, i64 %s2sz52)
  %2 = load <16 x i8>, ptr %v5_mem.sroa.34.0.p0.sroa_idx, align 4
  %v5_mem.sroa.50.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 104
  %s2sz53_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz53 = ptrtoint ptr %s2sz53_p to i64
  call void @s2_record(i32 0, ptr %v5_mem.sroa.50.0.p0.sroa_idx, i64 %s2sz53)
  %3 = load <16 x i8>, ptr %v5_mem.sroa.50.0.p0.sroa_idx, align 4
  %v5_mem.sroa.68.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 125
  %s2sz54_p = getelementptr i1, ptr null, i32 1
  %s2sz54 = ptrtoint ptr %s2sz54_p to i64
  call void @s2_record(i32 1, ptr %v5_mem.sroa.67.sroa.0, i64 %s2sz54)
  store i1 true, ptr %v5_mem.sroa.67.sroa.0, align 4
  %s2sz55_p = getelementptr i8, ptr null, i32 1
  %s2sz55 = ptrtoint ptr %s2sz55_p to i64
  call void @s2_record(i32 0, ptr %v5_mem.sroa.67.sroa.0, i64 %s2sz55)
  %v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0. = load i8, ptr %v5_mem.sroa.67.sroa.0, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v8_pair = add i32 %v0, -1
  %v9_ptr = getelementptr i8, ptr %p0, i64 56
  %s2sz56_p = getelementptr i8, ptr null, i32 1
  %s2sz56 = ptrtoint ptr %s2sz56_p to i64
  call void @s2_record(i32 0, ptr %v9_ptr, i64 %s2sz56)
  %v9.unpack = load i8, ptr %v9_ptr, align 4
  %v9.elt257 = getelementptr i8, ptr %p0, i64 57
  %s2sz57_p = getelementptr i8, ptr null, i32 1
  %s2sz57 = ptrtoint ptr %s2sz57_p to i64
  call void @s2_record(i32 0, ptr %v9.elt257, i64 %s2sz57)
  %v9.unpack258 = load i8, ptr %v9.elt257, align 1
  %v9.elt259 = getelementptr i8, ptr %p0, i64 58
  %s2sz58_p = getelementptr i8, ptr null, i32 1
  %s2sz58 = ptrtoint ptr %s2sz58_p to i64
  call void @s2_record(i32 0, ptr %v9.elt259, i64 %s2sz58)
  %v9.unpack260 = load i8, ptr %v9.elt259, align 2
  %v9.elt261 = getelementptr i8, ptr %p0, i64 59
  %s2sz59_p = getelementptr i8, ptr null, i32 1
  %s2sz59 = ptrtoint ptr %s2sz59_p to i64
  call void @s2_record(i32 0, ptr %v9.elt261, i64 %s2sz59)
  %v9.unpack262 = load i8, ptr %v9.elt261, align 1
  %v9.elt263 = getelementptr i8, ptr %p0, i64 60
  %s2sz60_p = getelementptr i8, ptr null, i32 1
  %s2sz60 = ptrtoint ptr %s2sz60_p to i64
  call void @s2_record(i32 0, ptr %v9.elt263, i64 %s2sz60)
  %v9.unpack264 = load i8, ptr %v9.elt263, align 4
  %v9.elt265 = getelementptr i8, ptr %p0, i64 61
  %s2sz61_p = getelementptr i8, ptr null, i32 1
  %s2sz61 = ptrtoint ptr %s2sz61_p to i64
  call void @s2_record(i32 0, ptr %v9.elt265, i64 %s2sz61)
  %v9.unpack266 = load i8, ptr %v9.elt265, align 1
  %v9.elt267 = getelementptr i8, ptr %p0, i64 62
  %s2sz62_p = getelementptr i8, ptr null, i32 1
  %s2sz62 = ptrtoint ptr %s2sz62_p to i64
  call void @s2_record(i32 0, ptr %v9.elt267, i64 %s2sz62)
  %v9.unpack268 = load i8, ptr %v9.elt267, align 2
  %v9.elt269 = getelementptr i8, ptr %p0, i64 63
  %s2sz63_p = getelementptr i8, ptr null, i32 1
  %s2sz63 = ptrtoint ptr %s2sz63_p to i64
  call void @s2_record(i32 0, ptr %v9.elt269, i64 %s2sz63)
  %v9.unpack270 = load i8, ptr %v9.elt269, align 1
  %v9.elt271 = getelementptr i8, ptr %p0, i64 64
  %s2sz64_p = getelementptr i8, ptr null, i32 1
  %s2sz64 = ptrtoint ptr %s2sz64_p to i64
  call void @s2_record(i32 0, ptr %v9.elt271, i64 %s2sz64)
  %v9.unpack272 = load i8, ptr %v9.elt271, align 4
  %v9.elt273 = getelementptr i8, ptr %p0, i64 65
  %s2sz65_p = getelementptr i8, ptr null, i32 1
  %s2sz65 = ptrtoint ptr %s2sz65_p to i64
  call void @s2_record(i32 0, ptr %v9.elt273, i64 %s2sz65)
  %v9.unpack274 = load i8, ptr %v9.elt273, align 1
  %v9.elt275 = getelementptr i8, ptr %p0, i64 66
  %s2sz66_p = getelementptr i8, ptr null, i32 1
  %s2sz66 = ptrtoint ptr %s2sz66_p to i64
  call void @s2_record(i32 0, ptr %v9.elt275, i64 %s2sz66)
  %v9.unpack276 = load i8, ptr %v9.elt275, align 2
  %v9.elt277 = getelementptr i8, ptr %p0, i64 67
  %s2sz67_p = getelementptr i8, ptr null, i32 1
  %s2sz67 = ptrtoint ptr %s2sz67_p to i64
  call void @s2_record(i32 0, ptr %v9.elt277, i64 %s2sz67)
  %v9.unpack278 = load i8, ptr %v9.elt277, align 1
  %v9.elt279 = getelementptr i8, ptr %p0, i64 68
  %s2sz68_p = getelementptr i8, ptr null, i32 1
  %s2sz68 = ptrtoint ptr %s2sz68_p to i64
  call void @s2_record(i32 0, ptr %v9.elt279, i64 %s2sz68)
  %v9.unpack280 = load i8, ptr %v9.elt279, align 4
  %v9.elt281 = getelementptr i8, ptr %p0, i64 69
  %s2sz69_p = getelementptr i8, ptr null, i32 1
  %s2sz69 = ptrtoint ptr %s2sz69_p to i64
  call void @s2_record(i32 0, ptr %v9.elt281, i64 %s2sz69)
  %v9.unpack282 = load i8, ptr %v9.elt281, align 1
  %v9.elt283 = getelementptr i8, ptr %p0, i64 70
  %s2sz70_p = getelementptr i8, ptr null, i32 1
  %s2sz70 = ptrtoint ptr %s2sz70_p to i64
  call void @s2_record(i32 0, ptr %v9.elt283, i64 %s2sz70)
  %v9.unpack284 = load i8, ptr %v9.elt283, align 2
  %v9.elt285 = getelementptr i8, ptr %p0, i64 71
  %s2sz71_p = getelementptr i8, ptr null, i32 1
  %s2sz71 = ptrtoint ptr %s2sz71_p to i64
  call void @s2_record(i32 0, ptr %v9.elt285, i64 %s2sz71)
  %v9.unpack286 = load i8, ptr %v9.elt285, align 1
  %v9.elt287 = getelementptr i8, ptr %p0, i64 72
  %s2sz72_p = getelementptr i8, ptr null, i32 1
  %s2sz72 = ptrtoint ptr %s2sz72_p to i64
  call void @s2_record(i32 0, ptr %v9.elt287, i64 %s2sz72)
  %v9.unpack288 = load i8, ptr %v9.elt287, align 4
  %v9.elt289 = getelementptr i8, ptr %p0, i64 73
  %s2sz73_p = getelementptr i8, ptr null, i32 1
  %s2sz73 = ptrtoint ptr %s2sz73_p to i64
  call void @s2_record(i32 0, ptr %v9.elt289, i64 %s2sz73)
  %v9.unpack290 = load i8, ptr %v9.elt289, align 1
  %v9.elt291 = getelementptr i8, ptr %p0, i64 74
  %s2sz74_p = getelementptr i8, ptr null, i32 1
  %s2sz74 = ptrtoint ptr %s2sz74_p to i64
  call void @s2_record(i32 0, ptr %v9.elt291, i64 %s2sz74)
  %v9.unpack292 = load i8, ptr %v9.elt291, align 2
  %v9.elt293 = getelementptr i8, ptr %p0, i64 75
  %s2sz75_p = getelementptr i8, ptr null, i32 1
  %s2sz75 = ptrtoint ptr %s2sz75_p to i64
  call void @s2_record(i32 0, ptr %v9.elt293, i64 %s2sz75)
  %v9.unpack294 = load i8, ptr %v9.elt293, align 1
  %v9.elt295 = getelementptr i8, ptr %p0, i64 76
  %s2sz76_p = getelementptr i8, ptr null, i32 1
  %s2sz76 = ptrtoint ptr %s2sz76_p to i64
  call void @s2_record(i32 0, ptr %v9.elt295, i64 %s2sz76)
  %v9.unpack296 = load i8, ptr %v9.elt295, align 4
  %v9.elt297 = getelementptr i8, ptr %p0, i64 77
  %s2sz77_p = getelementptr i8, ptr null, i32 1
  %s2sz77 = ptrtoint ptr %s2sz77_p to i64
  call void @s2_record(i32 0, ptr %v9.elt297, i64 %s2sz77)
  %v9.unpack298 = load i8, ptr %v9.elt297, align 1
  %v9.elt299 = getelementptr i8, ptr %p0, i64 78
  %s2sz78_p = getelementptr i8, ptr null, i32 1
  %s2sz78 = ptrtoint ptr %s2sz78_p to i64
  call void @s2_record(i32 0, ptr %v9.elt299, i64 %s2sz78)
  %v9.unpack300 = load i8, ptr %v9.elt299, align 2
  %v9.elt301 = getelementptr i8, ptr %p0, i64 79
  %s2sz79_p = getelementptr i8, ptr null, i32 1
  %s2sz79 = ptrtoint ptr %s2sz79_p to i64
  call void @s2_record(i32 0, ptr %v9.elt301, i64 %s2sz79)
  %v9.unpack302 = load i8, ptr %v9.elt301, align 1
  %v9.elt303 = getelementptr i8, ptr %p0, i64 80
  %s2sz80_p = getelementptr i8, ptr null, i32 1
  %s2sz80 = ptrtoint ptr %s2sz80_p to i64
  call void @s2_record(i32 0, ptr %v9.elt303, i64 %s2sz80)
  %v9.unpack304 = load i8, ptr %v9.elt303, align 4
  %v9.elt305 = getelementptr i8, ptr %p0, i64 81
  %s2sz81_p = getelementptr i8, ptr null, i32 1
  %s2sz81 = ptrtoint ptr %s2sz81_p to i64
  call void @s2_record(i32 0, ptr %v9.elt305, i64 %s2sz81)
  %v9.unpack306 = load i8, ptr %v9.elt305, align 1
  %v9.elt307 = getelementptr i8, ptr %p0, i64 82
  %s2sz82_p = getelementptr i8, ptr null, i32 1
  %s2sz82 = ptrtoint ptr %s2sz82_p to i64
  call void @s2_record(i32 0, ptr %v9.elt307, i64 %s2sz82)
  %v9.unpack308 = load i8, ptr %v9.elt307, align 2
  %v9.elt309 = getelementptr i8, ptr %p0, i64 83
  %s2sz83_p = getelementptr i8, ptr null, i32 1
  %s2sz83 = ptrtoint ptr %s2sz83_p to i64
  call void @s2_record(i32 0, ptr %v9.elt309, i64 %s2sz83)
  %v9.unpack310 = load i8, ptr %v9.elt309, align 1
  %v9.elt311 = getelementptr i8, ptr %p0, i64 84
  %s2sz84_p = getelementptr i8, ptr null, i32 1
  %s2sz84 = ptrtoint ptr %s2sz84_p to i64
  call void @s2_record(i32 0, ptr %v9.elt311, i64 %s2sz84)
  %v9.unpack312 = load i8, ptr %v9.elt311, align 4
  %v9.elt313 = getelementptr i8, ptr %p0, i64 85
  %s2sz85_p = getelementptr i8, ptr null, i32 1
  %s2sz85 = ptrtoint ptr %s2sz85_p to i64
  call void @s2_record(i32 0, ptr %v9.elt313, i64 %s2sz85)
  %v9.unpack314 = load i8, ptr %v9.elt313, align 1
  %v9.elt315 = getelementptr i8, ptr %p0, i64 86
  %s2sz86_p = getelementptr i8, ptr null, i32 1
  %s2sz86 = ptrtoint ptr %s2sz86_p to i64
  call void @s2_record(i32 0, ptr %v9.elt315, i64 %s2sz86)
  %v9.unpack316 = load i8, ptr %v9.elt315, align 2
  %v9.elt317 = getelementptr i8, ptr %p0, i64 87
  %s2sz87_p = getelementptr i8, ptr null, i32 1
  %s2sz87 = ptrtoint ptr %s2sz87_p to i64
  call void @s2_record(i32 0, ptr %v9.elt317, i64 %s2sz87)
  %v9.unpack318 = load i8, ptr %v9.elt317, align 1
  %v9.elt319 = getelementptr i8, ptr %p0, i64 88
  %s2sz88_p = getelementptr i8, ptr null, i32 1
  %s2sz88 = ptrtoint ptr %s2sz88_p to i64
  call void @s2_record(i32 0, ptr %v9.elt319, i64 %s2sz88)
  %v9.unpack320 = load i8, ptr %v9.elt319, align 4
  %v9.elt321 = getelementptr i8, ptr %p0, i64 89
  %s2sz89_p = getelementptr i8, ptr null, i32 1
  %s2sz89 = ptrtoint ptr %s2sz89_p to i64
  call void @s2_record(i32 0, ptr %v9.elt321, i64 %s2sz89)
  %v9.unpack322 = load i8, ptr %v9.elt321, align 1
  %v9.elt323 = getelementptr i8, ptr %p0, i64 90
  %s2sz90_p = getelementptr i8, ptr null, i32 1
  %s2sz90 = ptrtoint ptr %s2sz90_p to i64
  call void @s2_record(i32 0, ptr %v9.elt323, i64 %s2sz90)
  %v9.unpack324 = load i8, ptr %v9.elt323, align 2
  %v9.elt325 = getelementptr i8, ptr %p0, i64 91
  %s2sz91_p = getelementptr i8, ptr null, i32 1
  %s2sz91 = ptrtoint ptr %s2sz91_p to i64
  call void @s2_record(i32 0, ptr %v9.elt325, i64 %s2sz91)
  %v9.unpack326 = load i8, ptr %v9.elt325, align 1
  %v9.elt327 = getelementptr i8, ptr %p0, i64 92
  %s2sz92_p = getelementptr i8, ptr null, i32 1
  %s2sz92 = ptrtoint ptr %s2sz92_p to i64
  call void @s2_record(i32 0, ptr %v9.elt327, i64 %s2sz92)
  %v9.unpack328 = load i8, ptr %v9.elt327, align 4
  %v9.elt329 = getelementptr i8, ptr %p0, i64 93
  %s2sz93_p = getelementptr i8, ptr null, i32 1
  %s2sz93 = ptrtoint ptr %s2sz93_p to i64
  call void @s2_record(i32 0, ptr %v9.elt329, i64 %s2sz93)
  %v9.unpack330 = load i8, ptr %v9.elt329, align 1
  %v9.elt331 = getelementptr i8, ptr %p0, i64 94
  %s2sz94_p = getelementptr i8, ptr null, i32 1
  %s2sz94 = ptrtoint ptr %s2sz94_p to i64
  call void @s2_record(i32 0, ptr %v9.elt331, i64 %s2sz94)
  %v9.unpack332 = load i8, ptr %v9.elt331, align 2
  %v9.elt333 = getelementptr i8, ptr %p0, i64 95
  %s2sz95_p = getelementptr i8, ptr null, i32 1
  %s2sz95 = ptrtoint ptr %s2sz95_p to i64
  call void @s2_record(i32 0, ptr %v9.elt333, i64 %s2sz95)
  %v9.unpack334 = load i8, ptr %v9.elt333, align 1
  %v9.elt335 = getelementptr i8, ptr %p0, i64 96
  %s2sz96_p = getelementptr i8, ptr null, i32 1
  %s2sz96 = ptrtoint ptr %s2sz96_p to i64
  call void @s2_record(i32 0, ptr %v9.elt335, i64 %s2sz96)
  %v9.unpack336 = load i8, ptr %v9.elt335, align 4
  %v9.elt337 = getelementptr i8, ptr %p0, i64 97
  %s2sz97_p = getelementptr i8, ptr null, i32 1
  %s2sz97 = ptrtoint ptr %s2sz97_p to i64
  call void @s2_record(i32 0, ptr %v9.elt337, i64 %s2sz97)
  %v9.unpack338 = load i8, ptr %v9.elt337, align 1
  %v9.elt339 = getelementptr i8, ptr %p0, i64 98
  %s2sz98_p = getelementptr i8, ptr null, i32 1
  %s2sz98 = ptrtoint ptr %s2sz98_p to i64
  call void @s2_record(i32 0, ptr %v9.elt339, i64 %s2sz98)
  %v9.unpack340 = load i8, ptr %v9.elt339, align 2
  %v9.elt341 = getelementptr i8, ptr %p0, i64 99
  %s2sz99_p = getelementptr i8, ptr null, i32 1
  %s2sz99 = ptrtoint ptr %s2sz99_p to i64
  call void @s2_record(i32 0, ptr %v9.elt341, i64 %s2sz99)
  %v9.unpack342 = load i8, ptr %v9.elt341, align 1
  %v9.elt343 = getelementptr i8, ptr %p0, i64 100
  %s2sz100_p = getelementptr i8, ptr null, i32 1
  %s2sz100 = ptrtoint ptr %s2sz100_p to i64
  call void @s2_record(i32 0, ptr %v9.elt343, i64 %s2sz100)
  %v9.unpack344 = load i8, ptr %v9.elt343, align 4
  %v9.elt345 = getelementptr i8, ptr %p0, i64 101
  %s2sz101_p = getelementptr i8, ptr null, i32 1
  %s2sz101 = ptrtoint ptr %s2sz101_p to i64
  call void @s2_record(i32 0, ptr %v9.elt345, i64 %s2sz101)
  %v9.unpack346 = load i8, ptr %v9.elt345, align 1
  %v9.elt347 = getelementptr i8, ptr %p0, i64 102
  %s2sz102_p = getelementptr i8, ptr null, i32 1
  %s2sz102 = ptrtoint ptr %s2sz102_p to i64
  call void @s2_record(i32 0, ptr %v9.elt347, i64 %s2sz102)
  %v9.unpack348 = load i8, ptr %v9.elt347, align 2
  %v9.elt349 = getelementptr i8, ptr %p0, i64 103
  %s2sz103_p = getelementptr i8, ptr null, i32 1
  %s2sz103 = ptrtoint ptr %s2sz103_p to i64
  call void @s2_record(i32 0, ptr %v9.elt349, i64 %s2sz103)
  %v9.unpack350 = load i8, ptr %v9.elt349, align 1
  %v9.elt351 = getelementptr i8, ptr %p0, i64 104
  %s2sz104_p = getelementptr i8, ptr null, i32 1
  %s2sz104 = ptrtoint ptr %s2sz104_p to i64
  call void @s2_record(i32 0, ptr %v9.elt351, i64 %s2sz104)
  %v9.unpack352 = load i8, ptr %v9.elt351, align 4
  %v9.elt353 = getelementptr i8, ptr %p0, i64 105
  %s2sz105_p = getelementptr i8, ptr null, i32 1
  %s2sz105 = ptrtoint ptr %s2sz105_p to i64
  call void @s2_record(i32 0, ptr %v9.elt353, i64 %s2sz105)
  %v9.unpack354 = load i8, ptr %v9.elt353, align 1
  %v9.elt355 = getelementptr i8, ptr %p0, i64 106
  %s2sz106_p = getelementptr i8, ptr null, i32 1
  %s2sz106 = ptrtoint ptr %s2sz106_p to i64
  call void @s2_record(i32 0, ptr %v9.elt355, i64 %s2sz106)
  %v9.unpack356 = load i8, ptr %v9.elt355, align 2
  %v9.elt357 = getelementptr i8, ptr %p0, i64 107
  %s2sz107_p = getelementptr i8, ptr null, i32 1
  %s2sz107 = ptrtoint ptr %s2sz107_p to i64
  call void @s2_record(i32 0, ptr %v9.elt357, i64 %s2sz107)
  %v9.unpack358 = load i8, ptr %v9.elt357, align 1
  %v9.elt359 = getelementptr i8, ptr %p0, i64 108
  %s2sz108_p = getelementptr i8, ptr null, i32 1
  %s2sz108 = ptrtoint ptr %s2sz108_p to i64
  call void @s2_record(i32 0, ptr %v9.elt359, i64 %s2sz108)
  %v9.unpack360 = load i8, ptr %v9.elt359, align 4
  %v9.elt361 = getelementptr i8, ptr %p0, i64 109
  %s2sz109_p = getelementptr i8, ptr null, i32 1
  %s2sz109 = ptrtoint ptr %s2sz109_p to i64
  call void @s2_record(i32 0, ptr %v9.elt361, i64 %s2sz109)
  %v9.unpack362 = load i8, ptr %v9.elt361, align 1
  %v9.elt363 = getelementptr i8, ptr %p0, i64 110
  %s2sz110_p = getelementptr i8, ptr null, i32 1
  %s2sz110 = ptrtoint ptr %s2sz110_p to i64
  call void @s2_record(i32 0, ptr %v9.elt363, i64 %s2sz110)
  %v9.unpack364 = load i8, ptr %v9.elt363, align 2
  %v9.elt365 = getelementptr i8, ptr %p0, i64 111
  %s2sz111_p = getelementptr i8, ptr null, i32 1
  %s2sz111 = ptrtoint ptr %s2sz111_p to i64
  call void @s2_record(i32 0, ptr %v9.elt365, i64 %s2sz111)
  %v9.unpack366 = load i8, ptr %v9.elt365, align 1
  %v9.elt367 = getelementptr i8, ptr %p0, i64 112
  %s2sz112_p = getelementptr i8, ptr null, i32 1
  %s2sz112 = ptrtoint ptr %s2sz112_p to i64
  call void @s2_record(i32 0, ptr %v9.elt367, i64 %s2sz112)
  %v9.unpack368 = load i8, ptr %v9.elt367, align 4
  %v9.elt369 = getelementptr i8, ptr %p0, i64 113
  %s2sz113_p = getelementptr i8, ptr null, i32 1
  %s2sz113 = ptrtoint ptr %s2sz113_p to i64
  call void @s2_record(i32 0, ptr %v9.elt369, i64 %s2sz113)
  %v9.unpack370 = load i8, ptr %v9.elt369, align 1
  %v9.elt371 = getelementptr i8, ptr %p0, i64 114
  %s2sz114_p = getelementptr i8, ptr null, i32 1
  %s2sz114 = ptrtoint ptr %s2sz114_p to i64
  call void @s2_record(i32 0, ptr %v9.elt371, i64 %s2sz114)
  %v9.unpack372 = load i8, ptr %v9.elt371, align 2
  %v9.elt373 = getelementptr i8, ptr %p0, i64 115
  %s2sz115_p = getelementptr i8, ptr null, i32 1
  %s2sz115 = ptrtoint ptr %s2sz115_p to i64
  call void @s2_record(i32 0, ptr %v9.elt373, i64 %s2sz115)
  %v9.unpack374 = load i8, ptr %v9.elt373, align 1
  %v9.elt375 = getelementptr i8, ptr %p0, i64 116
  %s2sz116_p = getelementptr i8, ptr null, i32 1
  %s2sz116 = ptrtoint ptr %s2sz116_p to i64
  call void @s2_record(i32 0, ptr %v9.elt375, i64 %s2sz116)
  %v9.unpack376 = load i8, ptr %v9.elt375, align 4
  %v9.elt377 = getelementptr i8, ptr %p0, i64 117
  %s2sz117_p = getelementptr i8, ptr null, i32 1
  %s2sz117 = ptrtoint ptr %s2sz117_p to i64
  call void @s2_record(i32 0, ptr %v9.elt377, i64 %s2sz117)
  %v9.unpack378 = load i8, ptr %v9.elt377, align 1
  %v9.elt379 = getelementptr i8, ptr %p0, i64 118
  %s2sz118_p = getelementptr i8, ptr null, i32 1
  %s2sz118 = ptrtoint ptr %s2sz118_p to i64
  call void @s2_record(i32 0, ptr %v9.elt379, i64 %s2sz118)
  %v9.unpack380 = load i8, ptr %v9.elt379, align 2
  %v9.elt381 = getelementptr i8, ptr %p0, i64 119
  %s2sz119_p = getelementptr i8, ptr null, i32 1
  %s2sz119 = ptrtoint ptr %s2sz119_p to i64
  call void @s2_record(i32 0, ptr %v9.elt381, i64 %s2sz119)
  %v9.unpack382 = load i8, ptr %v9.elt381, align 1
  %s2sz120_p = getelementptr i8, ptr null, i32 1
  %s2sz120 = ptrtoint ptr %s2sz120_p to i64
  call void @s2_record(i32 1, ptr %v9_storage, i64 %s2sz120)
  store i8 %v9.unpack, ptr %v9_storage, align 1
  %v9.fca.1.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 1
  %s2sz121_p = getelementptr i8, ptr null, i32 1
  %s2sz121 = ptrtoint ptr %s2sz121_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.1.gep, i64 %s2sz121)
  store i8 %v9.unpack258, ptr %v9.fca.1.gep, align 1
  %v9.fca.2.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 2
  %s2sz122_p = getelementptr i8, ptr null, i32 1
  %s2sz122 = ptrtoint ptr %s2sz122_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.2.gep, i64 %s2sz122)
  store i8 %v9.unpack260, ptr %v9.fca.2.gep, align 1
  %v9.fca.3.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 3
  %s2sz123_p = getelementptr i8, ptr null, i32 1
  %s2sz123 = ptrtoint ptr %s2sz123_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.3.gep, i64 %s2sz123)
  store i8 %v9.unpack262, ptr %v9.fca.3.gep, align 1
  %v9.fca.4.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 4
  %s2sz124_p = getelementptr i8, ptr null, i32 1
  %s2sz124 = ptrtoint ptr %s2sz124_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.4.gep, i64 %s2sz124)
  store i8 %v9.unpack264, ptr %v9.fca.4.gep, align 1
  %v9.fca.5.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 5
  %s2sz125_p = getelementptr i8, ptr null, i32 1
  %s2sz125 = ptrtoint ptr %s2sz125_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.5.gep, i64 %s2sz125)
  store i8 %v9.unpack266, ptr %v9.fca.5.gep, align 1
  %v9.fca.6.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 6
  %s2sz126_p = getelementptr i8, ptr null, i32 1
  %s2sz126 = ptrtoint ptr %s2sz126_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.6.gep, i64 %s2sz126)
  store i8 %v9.unpack268, ptr %v9.fca.6.gep, align 1
  %v9.fca.7.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 7
  %s2sz127_p = getelementptr i8, ptr null, i32 1
  %s2sz127 = ptrtoint ptr %s2sz127_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.7.gep, i64 %s2sz127)
  store i8 %v9.unpack270, ptr %v9.fca.7.gep, align 1
  %v9.fca.8.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 8
  %s2sz128_p = getelementptr i8, ptr null, i32 1
  %s2sz128 = ptrtoint ptr %s2sz128_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.8.gep, i64 %s2sz128)
  store i8 %v9.unpack272, ptr %v9.fca.8.gep, align 1
  %v9.fca.9.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 9
  %s2sz129_p = getelementptr i8, ptr null, i32 1
  %s2sz129 = ptrtoint ptr %s2sz129_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.9.gep, i64 %s2sz129)
  store i8 %v9.unpack274, ptr %v9.fca.9.gep, align 1
  %v9.fca.10.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 10
  %s2sz130_p = getelementptr i8, ptr null, i32 1
  %s2sz130 = ptrtoint ptr %s2sz130_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.10.gep, i64 %s2sz130)
  store i8 %v9.unpack276, ptr %v9.fca.10.gep, align 1
  %v9.fca.11.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 11
  %s2sz131_p = getelementptr i8, ptr null, i32 1
  %s2sz131 = ptrtoint ptr %s2sz131_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.11.gep, i64 %s2sz131)
  store i8 %v9.unpack278, ptr %v9.fca.11.gep, align 1
  %v9.fca.12.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 12
  %s2sz132_p = getelementptr i8, ptr null, i32 1
  %s2sz132 = ptrtoint ptr %s2sz132_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.12.gep, i64 %s2sz132)
  store i8 %v9.unpack280, ptr %v9.fca.12.gep, align 1
  %v9.fca.13.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 13
  %s2sz133_p = getelementptr i8, ptr null, i32 1
  %s2sz133 = ptrtoint ptr %s2sz133_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.13.gep, i64 %s2sz133)
  store i8 %v9.unpack282, ptr %v9.fca.13.gep, align 1
  %v9.fca.14.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 14
  %s2sz134_p = getelementptr i8, ptr null, i32 1
  %s2sz134 = ptrtoint ptr %s2sz134_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.14.gep, i64 %s2sz134)
  store i8 %v9.unpack284, ptr %v9.fca.14.gep, align 1
  %v9.fca.15.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 15
  %s2sz135_p = getelementptr i8, ptr null, i32 1
  %s2sz135 = ptrtoint ptr %s2sz135_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.15.gep, i64 %s2sz135)
  store i8 %v9.unpack286, ptr %v9.fca.15.gep, align 1
  %v9.fca.16.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 16
  %s2sz136_p = getelementptr i8, ptr null, i32 1
  %s2sz136 = ptrtoint ptr %s2sz136_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.16.gep, i64 %s2sz136)
  store i8 %v9.unpack288, ptr %v9.fca.16.gep, align 1
  %v9.fca.17.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 17
  %s2sz137_p = getelementptr i8, ptr null, i32 1
  %s2sz137 = ptrtoint ptr %s2sz137_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.17.gep, i64 %s2sz137)
  store i8 %v9.unpack290, ptr %v9.fca.17.gep, align 1
  %v9.fca.18.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 18
  %s2sz138_p = getelementptr i8, ptr null, i32 1
  %s2sz138 = ptrtoint ptr %s2sz138_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.18.gep, i64 %s2sz138)
  store i8 %v9.unpack292, ptr %v9.fca.18.gep, align 1
  %v9.fca.19.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 19
  %s2sz139_p = getelementptr i8, ptr null, i32 1
  %s2sz139 = ptrtoint ptr %s2sz139_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.19.gep, i64 %s2sz139)
  store i8 %v9.unpack294, ptr %v9.fca.19.gep, align 1
  %v9.fca.20.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 20
  %s2sz140_p = getelementptr i8, ptr null, i32 1
  %s2sz140 = ptrtoint ptr %s2sz140_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.20.gep, i64 %s2sz140)
  store i8 %v9.unpack296, ptr %v9.fca.20.gep, align 1
  %v9.fca.21.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 21
  %s2sz141_p = getelementptr i8, ptr null, i32 1
  %s2sz141 = ptrtoint ptr %s2sz141_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.21.gep, i64 %s2sz141)
  store i8 %v9.unpack298, ptr %v9.fca.21.gep, align 1
  %v9.fca.22.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 22
  %s2sz142_p = getelementptr i8, ptr null, i32 1
  %s2sz142 = ptrtoint ptr %s2sz142_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.22.gep, i64 %s2sz142)
  store i8 %v9.unpack300, ptr %v9.fca.22.gep, align 1
  %v9.fca.23.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 23
  %s2sz143_p = getelementptr i8, ptr null, i32 1
  %s2sz143 = ptrtoint ptr %s2sz143_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.23.gep, i64 %s2sz143)
  store i8 %v9.unpack302, ptr %v9.fca.23.gep, align 1
  %v9.fca.24.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 24
  %s2sz144_p = getelementptr i8, ptr null, i32 1
  %s2sz144 = ptrtoint ptr %s2sz144_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.24.gep, i64 %s2sz144)
  store i8 %v9.unpack304, ptr %v9.fca.24.gep, align 1
  %v9.fca.25.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 25
  %s2sz145_p = getelementptr i8, ptr null, i32 1
  %s2sz145 = ptrtoint ptr %s2sz145_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.25.gep, i64 %s2sz145)
  store i8 %v9.unpack306, ptr %v9.fca.25.gep, align 1
  %v9.fca.26.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 26
  %s2sz146_p = getelementptr i8, ptr null, i32 1
  %s2sz146 = ptrtoint ptr %s2sz146_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.26.gep, i64 %s2sz146)
  store i8 %v9.unpack308, ptr %v9.fca.26.gep, align 1
  %v9.fca.27.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 27
  %s2sz147_p = getelementptr i8, ptr null, i32 1
  %s2sz147 = ptrtoint ptr %s2sz147_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.27.gep, i64 %s2sz147)
  store i8 %v9.unpack310, ptr %v9.fca.27.gep, align 1
  %v9.fca.28.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 28
  %s2sz148_p = getelementptr i8, ptr null, i32 1
  %s2sz148 = ptrtoint ptr %s2sz148_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.28.gep, i64 %s2sz148)
  store i8 %v9.unpack312, ptr %v9.fca.28.gep, align 1
  %v9.fca.29.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 29
  %s2sz149_p = getelementptr i8, ptr null, i32 1
  %s2sz149 = ptrtoint ptr %s2sz149_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.29.gep, i64 %s2sz149)
  store i8 %v9.unpack314, ptr %v9.fca.29.gep, align 1
  %v9.fca.30.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 30
  %s2sz150_p = getelementptr i8, ptr null, i32 1
  %s2sz150 = ptrtoint ptr %s2sz150_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.30.gep, i64 %s2sz150)
  store i8 %v9.unpack316, ptr %v9.fca.30.gep, align 1
  %v9.fca.31.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 31
  %s2sz151_p = getelementptr i8, ptr null, i32 1
  %s2sz151 = ptrtoint ptr %s2sz151_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.31.gep, i64 %s2sz151)
  store i8 %v9.unpack318, ptr %v9.fca.31.gep, align 1
  %v9.fca.32.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 32
  %s2sz152_p = getelementptr i8, ptr null, i32 1
  %s2sz152 = ptrtoint ptr %s2sz152_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.32.gep, i64 %s2sz152)
  store i8 %v9.unpack320, ptr %v9.fca.32.gep, align 1
  %v9.fca.33.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 33
  %s2sz153_p = getelementptr i8, ptr null, i32 1
  %s2sz153 = ptrtoint ptr %s2sz153_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.33.gep, i64 %s2sz153)
  store i8 %v9.unpack322, ptr %v9.fca.33.gep, align 1
  %v9.fca.34.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 34
  %s2sz154_p = getelementptr i8, ptr null, i32 1
  %s2sz154 = ptrtoint ptr %s2sz154_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.34.gep, i64 %s2sz154)
  store i8 %v9.unpack324, ptr %v9.fca.34.gep, align 1
  %v9.fca.35.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 35
  %s2sz155_p = getelementptr i8, ptr null, i32 1
  %s2sz155 = ptrtoint ptr %s2sz155_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.35.gep, i64 %s2sz155)
  store i8 %v9.unpack326, ptr %v9.fca.35.gep, align 1
  %v9.fca.36.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 36
  %s2sz156_p = getelementptr i8, ptr null, i32 1
  %s2sz156 = ptrtoint ptr %s2sz156_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.36.gep, i64 %s2sz156)
  store i8 %v9.unpack328, ptr %v9.fca.36.gep, align 1
  %v9.fca.37.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 37
  %s2sz157_p = getelementptr i8, ptr null, i32 1
  %s2sz157 = ptrtoint ptr %s2sz157_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.37.gep, i64 %s2sz157)
  store i8 %v9.unpack330, ptr %v9.fca.37.gep, align 1
  %v9.fca.38.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 38
  %s2sz158_p = getelementptr i8, ptr null, i32 1
  %s2sz158 = ptrtoint ptr %s2sz158_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.38.gep, i64 %s2sz158)
  store i8 %v9.unpack332, ptr %v9.fca.38.gep, align 1
  %v9.fca.39.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 39
  %s2sz159_p = getelementptr i8, ptr null, i32 1
  %s2sz159 = ptrtoint ptr %s2sz159_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.39.gep, i64 %s2sz159)
  store i8 %v9.unpack334, ptr %v9.fca.39.gep, align 1
  %v9.fca.40.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 40
  %s2sz160_p = getelementptr i8, ptr null, i32 1
  %s2sz160 = ptrtoint ptr %s2sz160_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.40.gep, i64 %s2sz160)
  store i8 %v9.unpack336, ptr %v9.fca.40.gep, align 1
  %v9.fca.41.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 41
  %s2sz161_p = getelementptr i8, ptr null, i32 1
  %s2sz161 = ptrtoint ptr %s2sz161_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.41.gep, i64 %s2sz161)
  store i8 %v9.unpack338, ptr %v9.fca.41.gep, align 1
  %v9.fca.42.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 42
  %s2sz162_p = getelementptr i8, ptr null, i32 1
  %s2sz162 = ptrtoint ptr %s2sz162_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.42.gep, i64 %s2sz162)
  store i8 %v9.unpack340, ptr %v9.fca.42.gep, align 1
  %v9.fca.43.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 43
  %s2sz163_p = getelementptr i8, ptr null, i32 1
  %s2sz163 = ptrtoint ptr %s2sz163_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.43.gep, i64 %s2sz163)
  store i8 %v9.unpack342, ptr %v9.fca.43.gep, align 1
  %v9.fca.44.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 44
  %s2sz164_p = getelementptr i8, ptr null, i32 1
  %s2sz164 = ptrtoint ptr %s2sz164_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.44.gep, i64 %s2sz164)
  store i8 %v9.unpack344, ptr %v9.fca.44.gep, align 1
  %v9.fca.45.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 45
  %s2sz165_p = getelementptr i8, ptr null, i32 1
  %s2sz165 = ptrtoint ptr %s2sz165_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.45.gep, i64 %s2sz165)
  store i8 %v9.unpack346, ptr %v9.fca.45.gep, align 1
  %v9.fca.46.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 46
  %s2sz166_p = getelementptr i8, ptr null, i32 1
  %s2sz166 = ptrtoint ptr %s2sz166_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.46.gep, i64 %s2sz166)
  store i8 %v9.unpack348, ptr %v9.fca.46.gep, align 1
  %v9.fca.47.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 47
  %s2sz167_p = getelementptr i8, ptr null, i32 1
  %s2sz167 = ptrtoint ptr %s2sz167_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.47.gep, i64 %s2sz167)
  store i8 %v9.unpack350, ptr %v9.fca.47.gep, align 1
  %v9.fca.48.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 48
  %s2sz168_p = getelementptr i8, ptr null, i32 1
  %s2sz168 = ptrtoint ptr %s2sz168_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.48.gep, i64 %s2sz168)
  store i8 %v9.unpack352, ptr %v9.fca.48.gep, align 1
  %v9.fca.49.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 49
  %s2sz169_p = getelementptr i8, ptr null, i32 1
  %s2sz169 = ptrtoint ptr %s2sz169_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.49.gep, i64 %s2sz169)
  store i8 %v9.unpack354, ptr %v9.fca.49.gep, align 1
  %v9.fca.50.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 50
  %s2sz170_p = getelementptr i8, ptr null, i32 1
  %s2sz170 = ptrtoint ptr %s2sz170_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.50.gep, i64 %s2sz170)
  store i8 %v9.unpack356, ptr %v9.fca.50.gep, align 1
  %v9.fca.51.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 51
  %s2sz171_p = getelementptr i8, ptr null, i32 1
  %s2sz171 = ptrtoint ptr %s2sz171_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.51.gep, i64 %s2sz171)
  store i8 %v9.unpack358, ptr %v9.fca.51.gep, align 1
  %v9.fca.52.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 52
  %s2sz172_p = getelementptr i8, ptr null, i32 1
  %s2sz172 = ptrtoint ptr %s2sz172_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.52.gep, i64 %s2sz172)
  store i8 %v9.unpack360, ptr %v9.fca.52.gep, align 1
  %v9.fca.53.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 53
  %s2sz173_p = getelementptr i8, ptr null, i32 1
  %s2sz173 = ptrtoint ptr %s2sz173_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.53.gep, i64 %s2sz173)
  store i8 %v9.unpack362, ptr %v9.fca.53.gep, align 1
  %v9.fca.54.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 54
  %s2sz174_p = getelementptr i8, ptr null, i32 1
  %s2sz174 = ptrtoint ptr %s2sz174_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.54.gep, i64 %s2sz174)
  store i8 %v9.unpack364, ptr %v9.fca.54.gep, align 1
  %v9.fca.55.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 55
  %s2sz175_p = getelementptr i8, ptr null, i32 1
  %s2sz175 = ptrtoint ptr %s2sz175_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.55.gep, i64 %s2sz175)
  store i8 %v9.unpack366, ptr %v9.fca.55.gep, align 1
  %v9.fca.56.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 56
  %s2sz176_p = getelementptr i8, ptr null, i32 1
  %s2sz176 = ptrtoint ptr %s2sz176_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.56.gep, i64 %s2sz176)
  store i8 %v9.unpack368, ptr %v9.fca.56.gep, align 1
  %v9.fca.57.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 57
  %s2sz177_p = getelementptr i8, ptr null, i32 1
  %s2sz177 = ptrtoint ptr %s2sz177_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.57.gep, i64 %s2sz177)
  store i8 %v9.unpack370, ptr %v9.fca.57.gep, align 1
  %v9.fca.58.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 58
  %s2sz178_p = getelementptr i8, ptr null, i32 1
  %s2sz178 = ptrtoint ptr %s2sz178_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.58.gep, i64 %s2sz178)
  store i8 %v9.unpack372, ptr %v9.fca.58.gep, align 1
  %v9.fca.59.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 59
  %s2sz179_p = getelementptr i8, ptr null, i32 1
  %s2sz179 = ptrtoint ptr %s2sz179_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.59.gep, i64 %s2sz179)
  store i8 %v9.unpack374, ptr %v9.fca.59.gep, align 1
  %v9.fca.60.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 60
  %s2sz180_p = getelementptr i8, ptr null, i32 1
  %s2sz180 = ptrtoint ptr %s2sz180_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.60.gep, i64 %s2sz180)
  store i8 %v9.unpack376, ptr %v9.fca.60.gep, align 1
  %v9.fca.61.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 61
  %s2sz181_p = getelementptr i8, ptr null, i32 1
  %s2sz181 = ptrtoint ptr %s2sz181_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.61.gep, i64 %s2sz181)
  store i8 %v9.unpack378, ptr %v9.fca.61.gep, align 1
  %v9.fca.62.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 62
  %s2sz182_p = getelementptr i8, ptr null, i32 1
  %s2sz182 = ptrtoint ptr %s2sz182_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.62.gep, i64 %s2sz182)
  store i8 %v9.unpack380, ptr %v9.fca.62.gep, align 1
  %v9.fca.63.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 63
  %s2sz183_p = getelementptr i8, ptr null, i32 1
  %s2sz183 = ptrtoint ptr %s2sz183_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.63.gep, i64 %s2sz183)
  store i8 %v9.unpack382, ptr %v9.fca.63.gep, align 1
  %v10_invalid = icmp ugt i32 %v8_pair, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v10_invalid, label %v10_trap, label %v10_ok

v10_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v10_ok:                                           ; preds = %b2
  %v10_offset = zext nneg i32 %v8_pair to i64
  %v10_ptr = getelementptr i8, ptr %v9_storage, i64 %v10_offset
  %s2sz184_p = getelementptr i8, ptr null, i32 1
  %s2sz184 = ptrtoint ptr %s2sz184_p to i64
  call void @s2_record(i32 0, ptr %v10_ptr, i64 %s2sz184)
  %v10 = load i8, ptr %v10_ptr, align 1
  %v12 = icmp eq i8 %v10, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v12, label %b8_to_b9, label %b3

b3:                                               ; preds = %v10_ok
  %s2sz185_p = getelementptr i8, ptr null, i32 1
  %s2sz185 = ptrtoint ptr %s2sz185_p to i64
  call void @s2_record(i32 1, ptr %v14_storage, i64 %s2sz185)
  store i8 %v9.unpack, ptr %v14_storage, align 1
  %v14.fca.1.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 1
  %s2sz186_p = getelementptr i8, ptr null, i32 1
  %s2sz186 = ptrtoint ptr %s2sz186_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.1.gep, i64 %s2sz186)
  store i8 %v9.unpack258, ptr %v14.fca.1.gep, align 1
  %v14.fca.2.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 2
  %s2sz187_p = getelementptr i8, ptr null, i32 1
  %s2sz187 = ptrtoint ptr %s2sz187_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.2.gep, i64 %s2sz187)
  store i8 %v9.unpack260, ptr %v14.fca.2.gep, align 1
  %v14.fca.3.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 3
  %s2sz188_p = getelementptr i8, ptr null, i32 1
  %s2sz188 = ptrtoint ptr %s2sz188_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.3.gep, i64 %s2sz188)
  store i8 %v9.unpack262, ptr %v14.fca.3.gep, align 1
  %v14.fca.4.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 4
  %s2sz189_p = getelementptr i8, ptr null, i32 1
  %s2sz189 = ptrtoint ptr %s2sz189_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.4.gep, i64 %s2sz189)
  store i8 %v9.unpack264, ptr %v14.fca.4.gep, align 1
  %v14.fca.5.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 5
  %s2sz190_p = getelementptr i8, ptr null, i32 1
  %s2sz190 = ptrtoint ptr %s2sz190_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.5.gep, i64 %s2sz190)
  store i8 %v9.unpack266, ptr %v14.fca.5.gep, align 1
  %v14.fca.6.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 6
  %s2sz191_p = getelementptr i8, ptr null, i32 1
  %s2sz191 = ptrtoint ptr %s2sz191_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.6.gep, i64 %s2sz191)
  store i8 %v9.unpack268, ptr %v14.fca.6.gep, align 1
  %v14.fca.7.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 7
  %s2sz192_p = getelementptr i8, ptr null, i32 1
  %s2sz192 = ptrtoint ptr %s2sz192_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.7.gep, i64 %s2sz192)
  store i8 %v9.unpack270, ptr %v14.fca.7.gep, align 1
  %v14.fca.8.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 8
  %s2sz193_p = getelementptr i8, ptr null, i32 1
  %s2sz193 = ptrtoint ptr %s2sz193_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.8.gep, i64 %s2sz193)
  store i8 %v9.unpack272, ptr %v14.fca.8.gep, align 1
  %v14.fca.9.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 9
  %s2sz194_p = getelementptr i8, ptr null, i32 1
  %s2sz194 = ptrtoint ptr %s2sz194_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.9.gep, i64 %s2sz194)
  store i8 %v9.unpack274, ptr %v14.fca.9.gep, align 1
  %v14.fca.10.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 10
  %s2sz195_p = getelementptr i8, ptr null, i32 1
  %s2sz195 = ptrtoint ptr %s2sz195_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.10.gep, i64 %s2sz195)
  store i8 %v9.unpack276, ptr %v14.fca.10.gep, align 1
  %v14.fca.11.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 11
  %s2sz196_p = getelementptr i8, ptr null, i32 1
  %s2sz196 = ptrtoint ptr %s2sz196_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.11.gep, i64 %s2sz196)
  store i8 %v9.unpack278, ptr %v14.fca.11.gep, align 1
  %v14.fca.12.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 12
  %s2sz197_p = getelementptr i8, ptr null, i32 1
  %s2sz197 = ptrtoint ptr %s2sz197_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.12.gep, i64 %s2sz197)
  store i8 %v9.unpack280, ptr %v14.fca.12.gep, align 1
  %v14.fca.13.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 13
  %s2sz198_p = getelementptr i8, ptr null, i32 1
  %s2sz198 = ptrtoint ptr %s2sz198_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.13.gep, i64 %s2sz198)
  store i8 %v9.unpack282, ptr %v14.fca.13.gep, align 1
  %v14.fca.14.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 14
  %s2sz199_p = getelementptr i8, ptr null, i32 1
  %s2sz199 = ptrtoint ptr %s2sz199_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.14.gep, i64 %s2sz199)
  store i8 %v9.unpack284, ptr %v14.fca.14.gep, align 1
  %v14.fca.15.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 15
  %s2sz200_p = getelementptr i8, ptr null, i32 1
  %s2sz200 = ptrtoint ptr %s2sz200_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.15.gep, i64 %s2sz200)
  store i8 %v9.unpack286, ptr %v14.fca.15.gep, align 1
  %v14.fca.16.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 16
  %s2sz201_p = getelementptr i8, ptr null, i32 1
  %s2sz201 = ptrtoint ptr %s2sz201_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.16.gep, i64 %s2sz201)
  store i8 %v9.unpack288, ptr %v14.fca.16.gep, align 1
  %v14.fca.17.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 17
  %s2sz202_p = getelementptr i8, ptr null, i32 1
  %s2sz202 = ptrtoint ptr %s2sz202_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.17.gep, i64 %s2sz202)
  store i8 %v9.unpack290, ptr %v14.fca.17.gep, align 1
  %v14.fca.18.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 18
  %s2sz203_p = getelementptr i8, ptr null, i32 1
  %s2sz203 = ptrtoint ptr %s2sz203_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.18.gep, i64 %s2sz203)
  store i8 %v9.unpack292, ptr %v14.fca.18.gep, align 1
  %v14.fca.19.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 19
  %s2sz204_p = getelementptr i8, ptr null, i32 1
  %s2sz204 = ptrtoint ptr %s2sz204_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.19.gep, i64 %s2sz204)
  store i8 %v9.unpack294, ptr %v14.fca.19.gep, align 1
  %v14.fca.20.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 20
  %s2sz205_p = getelementptr i8, ptr null, i32 1
  %s2sz205 = ptrtoint ptr %s2sz205_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.20.gep, i64 %s2sz205)
  store i8 %v9.unpack296, ptr %v14.fca.20.gep, align 1
  %v14.fca.21.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 21
  %s2sz206_p = getelementptr i8, ptr null, i32 1
  %s2sz206 = ptrtoint ptr %s2sz206_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.21.gep, i64 %s2sz206)
  store i8 %v9.unpack298, ptr %v14.fca.21.gep, align 1
  %v14.fca.22.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 22
  %s2sz207_p = getelementptr i8, ptr null, i32 1
  %s2sz207 = ptrtoint ptr %s2sz207_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.22.gep, i64 %s2sz207)
  store i8 %v9.unpack300, ptr %v14.fca.22.gep, align 1
  %v14.fca.23.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 23
  %s2sz208_p = getelementptr i8, ptr null, i32 1
  %s2sz208 = ptrtoint ptr %s2sz208_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.23.gep, i64 %s2sz208)
  store i8 %v9.unpack302, ptr %v14.fca.23.gep, align 1
  %v14.fca.24.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 24
  %s2sz209_p = getelementptr i8, ptr null, i32 1
  %s2sz209 = ptrtoint ptr %s2sz209_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.24.gep, i64 %s2sz209)
  store i8 %v9.unpack304, ptr %v14.fca.24.gep, align 1
  %v14.fca.25.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 25
  %s2sz210_p = getelementptr i8, ptr null, i32 1
  %s2sz210 = ptrtoint ptr %s2sz210_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.25.gep, i64 %s2sz210)
  store i8 %v9.unpack306, ptr %v14.fca.25.gep, align 1
  %v14.fca.26.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 26
  %s2sz211_p = getelementptr i8, ptr null, i32 1
  %s2sz211 = ptrtoint ptr %s2sz211_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.26.gep, i64 %s2sz211)
  store i8 %v9.unpack308, ptr %v14.fca.26.gep, align 1
  %v14.fca.27.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 27
  %s2sz212_p = getelementptr i8, ptr null, i32 1
  %s2sz212 = ptrtoint ptr %s2sz212_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.27.gep, i64 %s2sz212)
  store i8 %v9.unpack310, ptr %v14.fca.27.gep, align 1
  %v14.fca.28.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 28
  %s2sz213_p = getelementptr i8, ptr null, i32 1
  %s2sz213 = ptrtoint ptr %s2sz213_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.28.gep, i64 %s2sz213)
  store i8 %v9.unpack312, ptr %v14.fca.28.gep, align 1
  %v14.fca.29.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 29
  %s2sz214_p = getelementptr i8, ptr null, i32 1
  %s2sz214 = ptrtoint ptr %s2sz214_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.29.gep, i64 %s2sz214)
  store i8 %v9.unpack314, ptr %v14.fca.29.gep, align 1
  %v14.fca.30.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 30
  %s2sz215_p = getelementptr i8, ptr null, i32 1
  %s2sz215 = ptrtoint ptr %s2sz215_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.30.gep, i64 %s2sz215)
  store i8 %v9.unpack316, ptr %v14.fca.30.gep, align 1
  %v14.fca.31.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 31
  %s2sz216_p = getelementptr i8, ptr null, i32 1
  %s2sz216 = ptrtoint ptr %s2sz216_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.31.gep, i64 %s2sz216)
  store i8 %v9.unpack318, ptr %v14.fca.31.gep, align 1
  %v14.fca.32.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 32
  %s2sz217_p = getelementptr i8, ptr null, i32 1
  %s2sz217 = ptrtoint ptr %s2sz217_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.32.gep, i64 %s2sz217)
  store i8 %v9.unpack320, ptr %v14.fca.32.gep, align 1
  %v14.fca.33.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 33
  %s2sz218_p = getelementptr i8, ptr null, i32 1
  %s2sz218 = ptrtoint ptr %s2sz218_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.33.gep, i64 %s2sz218)
  store i8 %v9.unpack322, ptr %v14.fca.33.gep, align 1
  %v14.fca.34.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 34
  %s2sz219_p = getelementptr i8, ptr null, i32 1
  %s2sz219 = ptrtoint ptr %s2sz219_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.34.gep, i64 %s2sz219)
  store i8 %v9.unpack324, ptr %v14.fca.34.gep, align 1
  %v14.fca.35.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 35
  %s2sz220_p = getelementptr i8, ptr null, i32 1
  %s2sz220 = ptrtoint ptr %s2sz220_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.35.gep, i64 %s2sz220)
  store i8 %v9.unpack326, ptr %v14.fca.35.gep, align 1
  %v14.fca.36.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 36
  %s2sz221_p = getelementptr i8, ptr null, i32 1
  %s2sz221 = ptrtoint ptr %s2sz221_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.36.gep, i64 %s2sz221)
  store i8 %v9.unpack328, ptr %v14.fca.36.gep, align 1
  %v14.fca.37.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 37
  %s2sz222_p = getelementptr i8, ptr null, i32 1
  %s2sz222 = ptrtoint ptr %s2sz222_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.37.gep, i64 %s2sz222)
  store i8 %v9.unpack330, ptr %v14.fca.37.gep, align 1
  %v14.fca.38.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 38
  %s2sz223_p = getelementptr i8, ptr null, i32 1
  %s2sz223 = ptrtoint ptr %s2sz223_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.38.gep, i64 %s2sz223)
  store i8 %v9.unpack332, ptr %v14.fca.38.gep, align 1
  %v14.fca.39.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 39
  %s2sz224_p = getelementptr i8, ptr null, i32 1
  %s2sz224 = ptrtoint ptr %s2sz224_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.39.gep, i64 %s2sz224)
  store i8 %v9.unpack334, ptr %v14.fca.39.gep, align 1
  %v14.fca.40.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 40
  %s2sz225_p = getelementptr i8, ptr null, i32 1
  %s2sz225 = ptrtoint ptr %s2sz225_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.40.gep, i64 %s2sz225)
  store i8 %v9.unpack336, ptr %v14.fca.40.gep, align 1
  %v14.fca.41.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 41
  %s2sz226_p = getelementptr i8, ptr null, i32 1
  %s2sz226 = ptrtoint ptr %s2sz226_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.41.gep, i64 %s2sz226)
  store i8 %v9.unpack338, ptr %v14.fca.41.gep, align 1
  %v14.fca.42.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 42
  %s2sz227_p = getelementptr i8, ptr null, i32 1
  %s2sz227 = ptrtoint ptr %s2sz227_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.42.gep, i64 %s2sz227)
  store i8 %v9.unpack340, ptr %v14.fca.42.gep, align 1
  %v14.fca.43.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 43
  %s2sz228_p = getelementptr i8, ptr null, i32 1
  %s2sz228 = ptrtoint ptr %s2sz228_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.43.gep, i64 %s2sz228)
  store i8 %v9.unpack342, ptr %v14.fca.43.gep, align 1
  %v14.fca.44.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 44
  %s2sz229_p = getelementptr i8, ptr null, i32 1
  %s2sz229 = ptrtoint ptr %s2sz229_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.44.gep, i64 %s2sz229)
  store i8 %v9.unpack344, ptr %v14.fca.44.gep, align 1
  %v14.fca.45.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 45
  %s2sz230_p = getelementptr i8, ptr null, i32 1
  %s2sz230 = ptrtoint ptr %s2sz230_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.45.gep, i64 %s2sz230)
  store i8 %v9.unpack346, ptr %v14.fca.45.gep, align 1
  %v14.fca.46.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 46
  %s2sz231_p = getelementptr i8, ptr null, i32 1
  %s2sz231 = ptrtoint ptr %s2sz231_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.46.gep, i64 %s2sz231)
  store i8 %v9.unpack348, ptr %v14.fca.46.gep, align 1
  %v14.fca.47.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 47
  %s2sz232_p = getelementptr i8, ptr null, i32 1
  %s2sz232 = ptrtoint ptr %s2sz232_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.47.gep, i64 %s2sz232)
  store i8 %v9.unpack350, ptr %v14.fca.47.gep, align 1
  %v14.fca.48.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 48
  %s2sz233_p = getelementptr i8, ptr null, i32 1
  %s2sz233 = ptrtoint ptr %s2sz233_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.48.gep, i64 %s2sz233)
  store i8 %v9.unpack352, ptr %v14.fca.48.gep, align 1
  %v14.fca.49.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 49
  %s2sz234_p = getelementptr i8, ptr null, i32 1
  %s2sz234 = ptrtoint ptr %s2sz234_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.49.gep, i64 %s2sz234)
  store i8 %v9.unpack354, ptr %v14.fca.49.gep, align 1
  %v14.fca.50.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 50
  %s2sz235_p = getelementptr i8, ptr null, i32 1
  %s2sz235 = ptrtoint ptr %s2sz235_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.50.gep, i64 %s2sz235)
  store i8 %v9.unpack356, ptr %v14.fca.50.gep, align 1
  %v14.fca.51.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 51
  %s2sz236_p = getelementptr i8, ptr null, i32 1
  %s2sz236 = ptrtoint ptr %s2sz236_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.51.gep, i64 %s2sz236)
  store i8 %v9.unpack358, ptr %v14.fca.51.gep, align 1
  %v14.fca.52.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 52
  %s2sz237_p = getelementptr i8, ptr null, i32 1
  %s2sz237 = ptrtoint ptr %s2sz237_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.52.gep, i64 %s2sz237)
  store i8 %v9.unpack360, ptr %v14.fca.52.gep, align 1
  %v14.fca.53.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 53
  %s2sz238_p = getelementptr i8, ptr null, i32 1
  %s2sz238 = ptrtoint ptr %s2sz238_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.53.gep, i64 %s2sz238)
  store i8 %v9.unpack362, ptr %v14.fca.53.gep, align 1
  %v14.fca.54.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 54
  %s2sz239_p = getelementptr i8, ptr null, i32 1
  %s2sz239 = ptrtoint ptr %s2sz239_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.54.gep, i64 %s2sz239)
  store i8 %v9.unpack364, ptr %v14.fca.54.gep, align 1
  %v14.fca.55.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 55
  %s2sz240_p = getelementptr i8, ptr null, i32 1
  %s2sz240 = ptrtoint ptr %s2sz240_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.55.gep, i64 %s2sz240)
  store i8 %v9.unpack366, ptr %v14.fca.55.gep, align 1
  %v14.fca.56.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 56
  %s2sz241_p = getelementptr i8, ptr null, i32 1
  %s2sz241 = ptrtoint ptr %s2sz241_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.56.gep, i64 %s2sz241)
  store i8 %v9.unpack368, ptr %v14.fca.56.gep, align 1
  %v14.fca.57.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 57
  %s2sz242_p = getelementptr i8, ptr null, i32 1
  %s2sz242 = ptrtoint ptr %s2sz242_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.57.gep, i64 %s2sz242)
  store i8 %v9.unpack370, ptr %v14.fca.57.gep, align 1
  %v14.fca.58.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 58
  %s2sz243_p = getelementptr i8, ptr null, i32 1
  %s2sz243 = ptrtoint ptr %s2sz243_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.58.gep, i64 %s2sz243)
  store i8 %v9.unpack372, ptr %v14.fca.58.gep, align 1
  %v14.fca.59.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 59
  %s2sz244_p = getelementptr i8, ptr null, i32 1
  %s2sz244 = ptrtoint ptr %s2sz244_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.59.gep, i64 %s2sz244)
  store i8 %v9.unpack374, ptr %v14.fca.59.gep, align 1
  %v14.fca.60.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 60
  %s2sz245_p = getelementptr i8, ptr null, i32 1
  %s2sz245 = ptrtoint ptr %s2sz245_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.60.gep, i64 %s2sz245)
  store i8 %v9.unpack376, ptr %v14.fca.60.gep, align 1
  %v14.fca.61.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 61
  %s2sz246_p = getelementptr i8, ptr null, i32 1
  %s2sz246 = ptrtoint ptr %s2sz246_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.61.gep, i64 %s2sz246)
  store i8 %v9.unpack378, ptr %v14.fca.61.gep, align 1
  %v14.fca.62.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 62
  %s2sz247_p = getelementptr i8, ptr null, i32 1
  %s2sz247 = ptrtoint ptr %s2sz247_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.62.gep, i64 %s2sz247)
  store i8 %v9.unpack380, ptr %v14.fca.62.gep, align 1
  %v14.fca.63.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 63
  %s2sz248_p = getelementptr i8, ptr null, i32 1
  %s2sz248 = ptrtoint ptr %s2sz248_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.63.gep, i64 %s2sz248)
  store i8 %v9.unpack382, ptr %v14.fca.63.gep, align 1
  %v15_ptr = getelementptr i8, ptr %v14_storage, i64 %v10_offset
  %s2sz249_p = getelementptr i8, ptr null, i32 1
  %s2sz249 = ptrtoint ptr %s2sz249_p to i64
  call void @s2_record(i32 0, ptr %v15_ptr, i64 %s2sz249)
  %v15 = load i8, ptr %v15_ptr, align 1
  %v17 = icmp eq i8 %v15, 3
  %spec.select = select i1 %v17, ptr %v22_scratch, ptr %v27_scratch
  %spec.select1351 = select i1 %v17, i8 2, i8 7
  br label %b8_to_b9

b9:                                               ; preds = %b8_to_b9, %b1
  %v29_mem.sroa.0.sink = phi ptr [ %v29_mem.sroa.0, %b8_to_b9 ], [ %p0, %b1 ]
  %v29_mem.sroa.131.sroa.4.sink = phi ptr [ %v29_mem.sroa.131.sroa.4, %b8_to_b9 ], [ %v5_mem.sroa.68.0.p0.sroa_idx, %b1 ]
  %v30_mem.sroa.131.sroa.3.sroa.0.0 = phi i8 [ %16, %b8_to_b9 ], [ %v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0., %b1 ]
  %v30_mem.sroa.131.sroa.0.0 = phi i32 [ %v23_mem.sroa.130.sroa.0.0.copyload, %b8_to_b9 ], [ 0, %b1 ]
  %4 = phi <16 x i8> [ %12, %b8_to_b9 ], [ %0, %b1 ]
  %5 = phi <16 x i8> [ %13, %b8_to_b9 ], [ %1, %b1 ]
  %6 = phi <16 x i8> [ %14, %b8_to_b9 ], [ %2, %b1 ]
  %7 = phi <16 x i8> [ %15, %b8_to_b9 ], [ %3, %b1 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %v30_mem.sroa.0, ptr noundef nonnull align 1 dereferenceable(56) %v29_mem.sroa.0.sink, i64 56, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5, ptr noundef nonnull align 1 dereferenceable(59) %v29_mem.sroa.131.sroa.4.sink, i64 59, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %return_storage, ptr noundef nonnull align 8 dereferenceable(56) %v30_mem.sroa.0, i64 56, i1 false)
  %v30_mem.sroa.3.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 56
  %s2sz250_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz250 = ptrtoint ptr %s2sz250_p to i64
  call void @s2_record(i32 1, ptr %v30_mem.sroa.3.0.return_storage.sroa_idx, i64 %s2sz250)
  store <16 x i8> %4, ptr %v30_mem.sroa.3.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.35.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 72
  %s2sz251_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz251 = ptrtoint ptr %s2sz251_p to i64
  call void @s2_record(i32 1, ptr %v30_mem.sroa.35.0.return_storage.sroa_idx, i64 %s2sz251)
  store <16 x i8> %5, ptr %v30_mem.sroa.35.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.67.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 88
  %s2sz252_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz252 = ptrtoint ptr %s2sz252_p to i64
  call void @s2_record(i32 1, ptr %v30_mem.sroa.67.0.return_storage.sroa_idx, i64 %s2sz252)
  store <16 x i8> %6, ptr %v30_mem.sroa.67.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.99.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 104
  %s2sz253_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz253 = ptrtoint ptr %s2sz253_p to i64
  call void @s2_record(i32 1, ptr %v30_mem.sroa.99.0.return_storage.sroa_idx, i64 %s2sz253)
  store <16 x i8> %7, ptr %v30_mem.sroa.99.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.131.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 120
  %s2sz254_p = getelementptr i32, ptr null, i32 1
  %s2sz254 = ptrtoint ptr %s2sz254_p to i64
  call void @s2_record(i32 1, ptr %v30_mem.sroa.131.0.return_storage.sroa_idx, i64 %s2sz254)
  store i32 %v30_mem.sroa.131.sroa.0.0, ptr %v30_mem.sroa.131.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.131.sroa.3.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  %s2sz255_p = getelementptr i8, ptr null, i32 1
  %s2sz255 = ptrtoint ptr %s2sz255_p to i64
  call void @s2_record(i32 1, ptr %v30_mem.sroa.131.sroa.3.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx, i64 %s2sz255)
  store i8 %v30_mem.sroa.131.sroa.3.sroa.0.0, ptr %v30_mem.sroa.131.sroa.3.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx, align 4
  %v30_mem.sroa.131.sroa.5.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 125
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5, i64 59, i1 false)
  ret void

b8_to_b9:                                         ; preds = %b3, %v10_ok
  %v22_scratch.sink1350 = phi ptr [ %v22_scratch, %v10_ok ], [ %spec.select, %b3 ]
  %.sink = phi i8 [ 2, %v10_ok ], [ %spec.select1351, %b3 ]
  %s2sz256_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz256 = ptrtoint ptr %s2sz256_p to i64
  call void @s2_record(i32 0, ptr %v9_ptr, i64 %s2sz256)
  %8 = load <16 x i8>, ptr %v9_ptr, align 4
  %s2sz257_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz257 = ptrtoint ptr %s2sz257_p to i64
  call void @s2_record(i32 1, ptr %v22_scratch.sink1350, i64 %s2sz257)
  store <16 x i8> %8, ptr %v22_scratch.sink1350, align 1
  %v19.fca.16.gep162 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 16
  %s2sz258_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz258 = ptrtoint ptr %s2sz258_p to i64
  call void @s2_record(i32 0, ptr %v9.elt287, i64 %s2sz258)
  %9 = load <16 x i8>, ptr %v9.elt287, align 4
  %s2sz259_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz259 = ptrtoint ptr %s2sz259_p to i64
  call void @s2_record(i32 1, ptr %v19.fca.16.gep162, i64 %s2sz259)
  store <16 x i8> %9, ptr %v19.fca.16.gep162, align 1
  %v19.fca.32.gep194 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 32
  %s2sz260_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz260 = ptrtoint ptr %s2sz260_p to i64
  call void @s2_record(i32 0, ptr %v9.elt319, i64 %s2sz260)
  %10 = load <16 x i8>, ptr %v9.elt319, align 4
  %s2sz261_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz261 = ptrtoint ptr %s2sz261_p to i64
  call void @s2_record(i32 1, ptr %v19.fca.32.gep194, i64 %s2sz261)
  store <16 x i8> %10, ptr %v19.fca.32.gep194, align 1
  %v19.fca.48.gep226 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 48
  %s2sz262_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz262 = ptrtoint ptr %s2sz262_p to i64
  call void @s2_record(i32 0, ptr %v9.elt351, i64 %s2sz262)
  %11 = load <16 x i8>, ptr %v9.elt351, align 4
  %s2sz263_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz263 = ptrtoint ptr %s2sz263_p to i64
  call void @s2_record(i32 1, ptr %v19.fca.48.gep226, i64 %s2sz263)
  store <16 x i8> %11, ptr %v19.fca.48.gep226, align 1
  %v22_ptr = getelementptr i8, ptr %v22_scratch.sink1350, i64 %v10_offset
  %s2sz264_p = getelementptr i8, ptr null, i32 1
  %s2sz264 = ptrtoint ptr %s2sz264_p to i64
  call void @s2_record(i32 1, ptr %v22_ptr, i64 %s2sz264)
  store i8 %.sink, ptr %v22_ptr, align 1
  %s2sz265_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz265 = ptrtoint ptr %s2sz265_p to i64
  call void @s2_record(i32 0, ptr %v22_scratch.sink1350, i64 %s2sz265)
  %12 = load <16 x i8>, ptr %v22_scratch.sink1350, align 1
  %s2sz266_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz266 = ptrtoint ptr %s2sz266_p to i64
  call void @s2_record(i32 0, ptr %v19.fca.16.gep162, i64 %s2sz266)
  %13 = load <16 x i8>, ptr %v19.fca.16.gep162, align 1
  %s2sz267_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz267 = ptrtoint ptr %s2sz267_p to i64
  call void @s2_record(i32 0, ptr %v19.fca.32.gep194, i64 %s2sz267)
  %14 = load <16 x i8>, ptr %v19.fca.32.gep194, align 1
  %s2sz268_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz268 = ptrtoint ptr %s2sz268_p to i64
  call void @s2_record(i32 0, ptr %v19.fca.48.gep226, i64 %s2sz268)
  %15 = load <16 x i8>, ptr %v19.fca.48.gep226, align 1
  %s2sz269_p = getelementptr i32, ptr null, i32 1
  %s2sz269 = ptrtoint ptr %s2sz269_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr, i64 %s2sz269)
  %v23_mem.sroa.130.sroa.0.0.copyload = load i32, ptr %v0_ptr, align 4
  %v23_mem.sroa.130.sroa.2.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx = getelementptr i8, ptr %p0, i64 124
  %s2sz270_p = getelementptr i8, ptr null, i32 1
  %s2sz270 = ptrtoint ptr %s2sz270_p to i64
  call void @s2_record(i32 0, ptr %v23_mem.sroa.130.sroa.2.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx, i64 %s2sz270)
  %16 = load i8, ptr %v23_mem.sroa.130.sroa.2.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx, align 4
  %v23_mem.sroa.130.sroa.3.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx = getelementptr i8, ptr %p0, i64 125
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %v29_mem.sroa.0, ptr noundef nonnull align 1 dereferenceable(56) %p0, i64 56, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v29_mem.sroa.131.sroa.4, ptr noundef nonnull align 1 dereferenceable(59) %v23_mem.sroa.130.sroa.3.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx, i64 59, i1 false)
  br label %b9
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i1 @liza___liza_json_space(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = icmp ult i8 %p0, 33
  %switch.cast = zext nneg i8 %p0 to i33
  %switch.downshift = lshr i33 -4294957568, %switch.cast
  %switch.masked = trunc i33 %switch.downshift to i1
  %v13 = select i1 %0, i1 %switch.masked, i1 false
  ret i1 %v13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i1 @liza___liza_json_digit(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = add i8 %p0, -48
  %v5 = icmp ult i8 %0, 10
  ret i1 %v5
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define range(i32 0, 17) i32 @liza___liza_json_hex(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = add i8 %p0, -48
  %v5 = icmp ult i8 %0, 10
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v5, label %v6_ok, label %b6

v6_ok:                                            ; preds = %b0
  %v6 = zext nneg i8 %p0 to i32
  %v8_pair = add nsw i32 %v6, -48
  br label %common.ret

common.ret:                                       ; preds = %v24_ok, %v15_ok, %v6_ok, %b12
  %common.ret.op = phi i32 [ %v26_pair, %v24_ok ], [ %v8_pair, %v6_ok ], [ %v17_pair, %v15_ok ], [ 16, %b12 ]
  ret i32 %common.ret.op

b6:                                               ; preds = %b0
  %1 = add i8 %p0, -65
  %v14 = icmp ult i8 %1, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v14, label %v15_ok, label %b12

v15_ok:                                           ; preds = %b6
  %v15 = zext nneg i8 %p0 to i32
  %v17_pair = add nsw i32 %v15, -55
  br label %common.ret

b12:                                              ; preds = %b6
  %2 = add i8 %p0, -97
  %v23 = icmp ult i8 %2, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v23, label %v24_ok, label %common.ret

v24_ok:                                           ; preds = %b12
  %v24 = zext nneg i8 %p0 to i32
  %v26_pair = add nsw i32 %v24, -87
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define %variant.4 @liza_json.status(ptr nofree   %p0) local_unnamed_addr #3 {
b0:
  %v0_ptr = getelementptr i8, ptr %p0, i64 168
  %s2sz271_p = getelementptr i32, ptr null, i32 1
  %s2sz271 = ptrtoint ptr %s2sz271_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr, i64 %s2sz271)
  %v0 = load i32, ptr %v0_ptr, align 4
  %v2 = icmp eq i32 %v0, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2, label %common.ret, label %b3

common.ret:                                       ; preds = %b0, %b3
  %common.ret.op = phi %variant.4 [ %v42, %b3 ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  ret %variant.4 %common.ret.op

b3:                                               ; preds = %b0
  %v7 = icmp eq i32 %v0, 2
  %v9 = select i1 %v7, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12 = icmp eq i32 %v0, 3
  %v14 = select i1 %v12, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9
  %v17 = icmp eq i32 %v0, 4
  %v19 = select i1 %v17, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14
  %v22 = icmp eq i32 %v0, 5
  %v24 = select i1 %v22, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19
  %v27 = icmp eq i32 %v0, 6
  %v29 = select i1 %v27, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24
  %v32 = icmp eq i32 %v0, 7
  %v34 = select i1 %v32, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29
  %v37 = icmp eq i32 %v0, 8
  %v39 = select i1 %v37, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34
  %v40_ptr = getelementptr i8, ptr %p0, i64 176
  %s2sz272_p = getelementptr i64, ptr null, i32 1
  %s2sz272 = ptrtoint ptr %s2sz272_p to i64
  call void @s2_record(i32 0, ptr %v40_ptr, i64 %s2sz272)
  %v40 = load i64, ptr %v40_ptr, align 8
  %v41_field0 = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39, 0
  %v41 = insertvalue %struct.JsonError %v41_field0, i64 %v40, 1
  %v42 = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41, 1
  br label %common.ret
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define %variant.5 @liza_json.finish(ptr nofree   %p0) local_unnamed_addr #2 {
b0:
  %v33_mem = alloca %struct.JsonState, align 8
  %v0_ptr.i = getelementptr i8, ptr %p0, i64 168
  %s2sz273_p = getelementptr i32, ptr null, i32 1
  %s2sz273 = ptrtoint ptr %s2sz273_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr.i, i64 %s2sz273)
  %v0.i = load i32, ptr %v0_ptr.i, align 4
  %v2.i = icmp eq i32 %v0.i, 0
  %p0.sink.sroa.gep = getelementptr inbounds nuw i8, ptr %p0, i64 160
  %p0.sink.sroa.gep33 = getelementptr inbounds nuw i8, ptr %v33_mem, i64 160
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2.i, label %liza_json.status.exit, label %b3.i

b3.i:                                             ; preds = %b0
  %v7.i = icmp eq i32 %v0.i, 2
  %v9.i = select i1 %v7.i, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12.i = icmp eq i32 %v0.i, 3
  %v14.i = select i1 %v12.i, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9.i
  %v17.i = icmp eq i32 %v0.i, 4
  %v19.i = select i1 %v17.i, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14.i
  %v22.i = icmp eq i32 %v0.i, 5
  %v24.i = select i1 %v22.i, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19.i
  %v27.i = icmp eq i32 %v0.i, 6
  %v29.i = select i1 %v27.i, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24.i
  %v32.i = icmp eq i32 %v0.i, 7
  %v34.i = select i1 %v32.i, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29.i
  %v37.i = icmp eq i32 %v0.i, 8
  %v39.i = select i1 %v37.i, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34.i
  %v40_ptr.i = getelementptr i8, ptr %p0, i64 176
  %s2sz274_p = getelementptr i64, ptr null, i32 1
  %s2sz274 = ptrtoint ptr %s2sz274_p to i64
  call void @s2_record(i32 0, ptr %v40_ptr.i, i64 %s2sz274)
  %v40.i = load i64, ptr %v40_ptr.i, align 8
  %v41_field0.i = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39.i, 0
  %v41.i = insertvalue %struct.JsonError %v41_field0.i, i64 %v40.i, 1
  %v42.i = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41.i, 1
  br label %liza_json.status.exit

liza_json.status.exit:                            ; preds = %b0, %b3.i
  %common.ret.op.i = phi %variant.4 [ %v42.i, %b3.i ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  %v1 = extractvalue %variant.4 %common.ret.op.i, 0
  %0 = icmp eq i32 %v1, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %0, label %b2, label %b4

common.ret:                                       ; preds = %b38, %b36, %b27, %b7, %b2
  %common.ret.op = phi %variant.5 [ %v3, %b2 ], [ %v12, %b7 ], [ %v52, %b27 ], [ %v68, %b36 ], [ %v70, %b38 ]
  ret %variant.5 %common.ret.op

b2:                                               ; preds = %liza_json.status.exit
  %v2 = extractvalue %variant.4 %common.ret.op.i, 1
  %v3 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v2, 2
  br label %common.ret

b4:                                               ; preds = %liza_json.status.exit
  %s2sz275_p = getelementptr %struct.Utf8StreamState, ptr null, i32 1
  %s2sz275 = ptrtoint ptr %s2sz275_p to i64
  call void @s2_record(i32 0, ptr %p0, i64 %s2sz275)
  %v4 = load %struct.Utf8StreamState, ptr %p0, align 8
  %v0.i3 = extractvalue %struct.Utf8StreamState %v4, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0.i3, label %b6.i [
    i32 1, label %b1.i
    i32 2, label %b4.i
  ]

b1.i:                                             ; preds = %b4
  %v4.i = extractvalue %struct.Utf8StreamState %v4, 7
  %v5.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i, 1
  %v6.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5.i, 2
  br label %liza_utf8_stream.finish.exit

b4.i:                                             ; preds = %b4
  %v11.i = extractvalue %struct.Utf8StreamState %v4, 7
  %v12.i4 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i, 1
  %v13.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12.i4, 2
  br label %liza_utf8_stream.finish.exit

b6.i:                                             ; preds = %b4
  %v14.i6 = extractvalue %struct.Utf8StreamState %v4, 3
  %v16.not.i = icmp eq i32 %v14.i6, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v16.not.i, label %b9.i, label %b7.i

b7.i:                                             ; preds = %b6.i
  %v18.i = extractvalue %struct.Utf8StreamState %v4, 2
  %v19.i7 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18.i, 1
  %v20.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19.i7, 2
  br label %liza_utf8_stream.finish.exit

b9.i:                                             ; preds = %b6.i
  %v21.i = extractvalue %struct.Utf8StreamState %v4, 1
  %v22.i8 = insertvalue %variant.2 zeroinitializer, i64 %v21.i, 1
  br label %liza_utf8_stream.finish.exit

liza_utf8_stream.finish.exit:                     ; preds = %b1.i, %b4.i, %b7.i, %b9.i
  %common.ret.op.i5 = phi %variant.2 [ %v6.i, %b1.i ], [ %v13.i, %b4.i ], [ %v20.i, %b7.i ], [ %v22.i8, %b9.i ]
  %v6 = extractvalue %variant.2 %common.ret.op.i5, 0
  %1 = icmp eq i32 %v6, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %1, label %b6, label %b7

b6:                                               ; preds = %liza_utf8_stream.finish.exit
  %v13_ptr = getelementptr i8, ptr %p0, i64 128
  %s2sz276_p = getelementptr i32, ptr null, i32 1
  %s2sz276 = ptrtoint ptr %s2sz276_p to i64
  call void @s2_record(i32 0, ptr %v13_ptr, i64 %s2sz276)
  %v13 = load i32, ptr %v13_ptr, align 8
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v13, label %b19_to_b20 [
    i32 11, label %b18
    i32 12, label %b18
    i32 14, label %b18
    i32 17, label %b18
  ]

b7:                                               ; preds = %liza_utf8_stream.finish.exit
  %v8 = extractvalue %variant.2 %common.ret.op.i5, 2
  %v10 = extractvalue %struct.Utf8StreamError %v8, 1
  %v11 = insertvalue %struct.JsonError { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v10, 1
  %v12 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v11, 2
  br label %common.ret

b18:                                              ; preds = %b6, %b6, %b6, %b6
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(184) %v33_mem, ptr noundef nonnull align 1 dereferenceable(184) %p0, i64 184, i1 false)
  %v33_part = getelementptr inbounds nuw i8, ptr %v33_mem, i64 128
  %s2sz277_p = getelementptr i32, ptr null, i32 1
  %s2sz277 = ptrtoint ptr %s2sz277_p to i64
  call void @s2_record(i32 1, ptr %v33_part, i64 %s2sz277)
  store i32 0, ptr %v33_part, align 8
  call void @liza___liza_owned___liza_json_done(ptr nonnull sret(%struct.JsonState) %v33_mem, ptr nonnull poison)
  %v35_next.sroa.4.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 48
  %s2sz278_p = getelementptr i64, ptr null, i32 1
  %s2sz278 = ptrtoint ptr %s2sz278_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx, i64 %s2sz278)
  %v35_next.sroa.4.0.copyload = load i64, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx, align 8
  %v35_next.sroa.8.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 120
  %s2sz279_p = getelementptr i32, ptr null, i32 1
  %s2sz279 = ptrtoint ptr %s2sz279_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx, i64 %s2sz279)
  %v35_next.sroa.8.0.copyload = load i32, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx, align 8
  %v35_next.sroa.10.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 124
  %s2sz280_p = getelementptr i8, ptr null, i32 1
  %s2sz280 = ptrtoint ptr %s2sz280_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx, i64 %s2sz280)
  %2 = load i8, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx, align 4
  %s2sz281_p = getelementptr i32, ptr null, i32 1
  %s2sz281 = ptrtoint ptr %s2sz281_p to i64
  call void @s2_record(i32 0, ptr %v33_part, i64 %s2sz281)
  %v35_next.sroa.14.0.copyload = load i32, ptr %v33_part, align 8
  %extract.t32 = trunc i8 %2 to i1
  br label %b20

b20:                                              ; preds = %b19_to_b20, %b18
  %p0.sink.sroa.phi = phi ptr [ %p0.sink.sroa.gep, %b19_to_b20 ], [ %p0.sink.sroa.gep33, %b18 ]
  %.sink.off0 = phi i1 [ %extract.t, %b19_to_b20 ], [ %extract.t32, %b18 ]
  %v35_mem.sroa.617.0 = phi i32 [ %v13, %b19_to_b20 ], [ %v35_next.sroa.14.0.copyload, %b18 ]
  %v35_mem.sroa.412.0 = phi i32 [ %v35_next.sroa.8.0.copyload26, %b19_to_b20 ], [ %v35_next.sroa.8.0.copyload, %b18 ]
  %v35_mem.sroa.2.0 = phi i64 [ %v35_next.sroa.4.0.copyload25, %b19_to_b20 ], [ %v35_next.sroa.4.0.copyload, %b18 ]
  %3 = add i32 %v35_mem.sroa.617.0, -4
  %or.cond = icmp ult i32 %3, 3
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond, label %b27, label %b29

b27:                                              ; preds = %b20
  %s2sz282_p = getelementptr i64, ptr null, i32 1
  %s2sz282 = ptrtoint ptr %s2sz282_p to i64
  call void @s2_record(i32 0, ptr %p0.sink.sroa.phi, i64 %s2sz282)
  %v35_next.sroa.18.0.copyload28 = load i64, ptr %p0.sink.sroa.phi, align 8
  %v51 = insertvalue %struct.JsonError { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_next.sroa.18.0.copyload28, 1
  %v52 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v51, 2
  br label %common.ret

b29:                                              ; preds = %b20
  %v55 = icmp eq i32 %v35_mem.sroa.617.0, 0
  %v59 = icmp eq i32 %v35_mem.sroa.412.0, 0
  %v60.not2 = select i1 %v55, i1 %v59, i1 false
  %or.cond1.not = select i1 %v60.not2, i1 %.sink.off0, i1 false
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond1.not, label %b38, label %b36

b36:                                              ; preds = %b29
  %v67 = insertvalue %struct.JsonError { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.2.0, 1
  %v68 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v67, 2
  br label %common.ret

b38:                                              ; preds = %b29
  %v70 = insertvalue %variant.5 zeroinitializer, i64 %v35_mem.sroa.2.0, 1
  br label %common.ret

b19_to_b20:                                       ; preds = %b6
  %v35_next.sroa.4.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 48
  %s2sz283_p = getelementptr i64, ptr null, i32 1
  %s2sz283 = ptrtoint ptr %s2sz283_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.p0.sroa_idx, i64 %s2sz283)
  %v35_next.sroa.4.0.copyload25 = load i64, ptr %v35_next.sroa.4.0.p0.sroa_idx, align 8
  %v35_next.sroa.8.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 120
  %s2sz284_p = getelementptr i32, ptr null, i32 1
  %s2sz284 = ptrtoint ptr %s2sz284_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.p0.sroa_idx, i64 %s2sz284)
  %v35_next.sroa.8.0.copyload26 = load i32, ptr %v35_next.sroa.8.0.p0.sroa_idx, align 8
  %v35_next.sroa.10.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 124
  %s2sz285_p = getelementptr i8, ptr null, i32 1
  %s2sz285 = ptrtoint ptr %s2sz285_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.p0.sroa_idx, i64 %s2sz285)
  %4 = load i8, ptr %v35_next.sroa.10.0.p0.sroa_idx, align 4
  %extract.t = trunc i8 %4 to i1
  br label %b20
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define i32 @liza___liza_json_mut_fail(i32 returned %p0, i64 %p1, ptr nofree writeonly  initializes((168, 172), (176, 184)) %p2) local_unnamed_addr #4 {
b0:
  %v0 = getelementptr i8, ptr %p2, i64 168
  %s2sz286_p = getelementptr i32, ptr null, i32 1
  %s2sz286 = ptrtoint ptr %s2sz286_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz286)
  store i32 %p0, ptr %v0, align 4
  %v2 = getelementptr i8, ptr %p2, i64 176
  %s2sz287_p = getelementptr i64, ptr null, i32 1
  %s2sz287 = ptrtoint ptr %s2sz287_p to i64
  call void @s2_record(i32 1, ptr %v2, i64 %s2sz287)
  store i64 %p1, ptr %v2, align 8
  ret i32 %p0
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i32 @liza___liza_json_mut_done(ptr nofree  %p0) local_unnamed_addr #2 {
b0:
  %v0 = getelementptr i8, ptr %p0, i64 120
  %s2sz288_p = getelementptr i32, ptr null, i32 1
  %s2sz288 = ptrtoint ptr %s2sz288_p to i64
  call void @s2_record(i32 0, ptr %v0, i64 %s2sz288)
  %v1 = load i32, ptr %v0, align 4
  %v3 = icmp eq i32 %v1, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v3, label %b1, label %b2

b1:                                               ; preds = %b0
  %v4 = getelementptr i8, ptr %p0, i64 124
  %s2sz289_p = getelementptr i1, ptr null, i32 1
  %s2sz289 = ptrtoint ptr %s2sz289_p to i64
  call void @s2_record(i32 1, ptr %v4, i64 %s2sz289)
  store i1 true, ptr %v4, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v10_pair = add i32 %v1, -1
  %v12_invalid = icmp ugt i32 %v10_pair, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v12_invalid, label %v12_trap, label %v12_ok

v12_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v12_ok:                                           ; preds = %b2
  %v11 = getelementptr i8, ptr %p0, i64 56
  %v12_offset = zext nneg i32 %v10_pair to i64
  %v12 = getelementptr i8, ptr %v11, i64 %v12_offset
  %s2sz290_p = getelementptr i8, ptr null, i32 1
  %s2sz290 = ptrtoint ptr %s2sz290_p to i64
  call void @s2_record(i32 0, ptr %v12, i64 %s2sz290)
  %v13 = load i8, ptr %v12, align 1
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %v13, label %v28_ok [
    i8 1, label %v24_ok
    i8 3, label %v24_ok
  ]

v24_ok:                                           ; preds = %v12_ok, %v12_ok
  %s2sz291_p = getelementptr i8, ptr null, i32 1
  %s2sz291 = ptrtoint ptr %s2sz291_p to i64
  call void @s2_record(i32 1, ptr %v12, i64 %s2sz291)
  store i8 2, ptr %v12, align 1
  br label %b9

v28_ok:                                           ; preds = %v12_ok
  %s2sz292_p = getelementptr i8, ptr null, i32 1
  %s2sz292 = ptrtoint ptr %s2sz292_p to i64
  call void @s2_record(i32 1, ptr %v12, i64 %s2sz292)
  store i8 7, ptr %v12, align 1
  br label %b9

b9:                                               ; preds = %v24_ok, %v28_ok, %b1
  %v31 = getelementptr i8, ptr %p0, i64 168
  %s2sz293_p = getelementptr i32, ptr null, i32 1
  %s2sz293 = ptrtoint ptr %s2sz293_p to i64
  call void @s2_record(i32 0, ptr %v31, i64 %s2sz293)
  %v32 = load i32, ptr %v31, align 4
  ret i32 %v32
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i32 @liza___liza_json_mut_step(i8 %p0, ptr nofree %p1) local_unnamed_addr #2 {
b0:
  %v0 = getelementptr i8, ptr %p1, i64 128
  %s2sz294_p = getelementptr i32, ptr null, i32 1
  %s2sz294 = ptrtoint ptr %s2sz294_p to i64
  call void @s2_record(i32 0, ptr %v0, i64 %s2sz294)
  %v1 = load i32, ptr %v0, align 4
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v1, label %b132 [
    i32 1, label %b1
    i32 2, label %b16
    i32 4, label %b46
    i32 5, label %b52
    i32 3, label %b61
    i32 6, label %b61
    i32 20, label %b91
  ]

b1:                                               ; preds = %b0
  %v5 = icmp ult i8 %p0, 32
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v5, label %b3, label %b5

common.ret:                                       ; preds = %b312, %b304, %b292, %b289, %b286, %v691_ok, %b279, %b271, %b266, %b264, %v613_ok, %b255, %b251, %b246, %v560_ok, %v542_ok, %b217, %b210, %b201, %b189, %b180, %b165, %b157, %b140, %b131, %liza___liza_json_mut_done.exit, %b126, %b89, %b86, %b80, %b75, %b73, %b63, %b56, %b54, %b50, %b48, %b44, %b42, %b39, %b14, %b10, %v24_ok, %b3
  %common.ret.op = phi i32 [ 1, %b3 ], [ %v28, %v24_ok ], [ %v30, %b10 ], [ %v42, %b14 ], [ %v81, %b39 ], [ %v94, %b42 ], [ 3, %b44 ], [ 4, %b48 ], [ %v117, %b50 ], [ 4, %b54 ], [ %v140, %b56 ], [ 3, %b63 ], [ 4, %b73 ], [ %v201, %b75 ], [ %v220, %b80 ], [ 4, %b86 ], [ %v241, %b89 ], [ 1, %b126 ], [ %v32.i, %liza___liza_json_mut_done.exit ], [ %v337, %b131 ], [ 2, %b140 ], [ %v392, %b157 ], [ %v411, %b165 ], [ %v440, %b180 ], [ %v457, %b189 ], [ 2, %b201 ], [ 2, %b210 ], [ %v514, %b217 ], [ %v545, %v542_ok ], [ %v563, %v560_ok ], [ 1, %b246 ], [ %v597, %b251 ], [ 1, %b255 ], [ %v617, %v613_ok ], [ 1, %b264 ], [ %v639, %b266 ], [ 1, %b271 ], [ 7, %b279 ], [ %v694, %v691_ok ], [ %v704, %b286 ], [ %v711, %b289 ], [ %v722, %b292 ], [ %v753, %b304 ], [ 1, %b312 ]
  ret i32 %common.ret.op

b3:                                               ; preds = %b1
  %v7 = getelementptr i8, ptr %p1, i64 48
  %s2sz295_p = getelementptr i64, ptr null, i32 1
  %s2sz295 = ptrtoint ptr %s2sz295_p to i64
  call void @s2_record(i32 0, ptr %v7, i64 %s2sz295)
  %v8 = load i64, ptr %v7, align 8
  %v0.i = getelementptr i8, ptr %p1, i64 168
  %s2sz296_p = getelementptr i32, ptr null, i32 1
  %s2sz296 = ptrtoint ptr %s2sz296_p to i64
  call void @s2_record(i32 1, ptr %v0.i, i64 %s2sz296)
  store i32 1, ptr %v0.i, align 8
  %v2.i = getelementptr i8, ptr %p1, i64 176
  %s2sz297_p = getelementptr i64, ptr null, i32 1
  %s2sz297 = ptrtoint ptr %s2sz297_p to i64
  call void @s2_record(i32 1, ptr %v2.i, i64 %s2sz297)
  store i64 %v8, ptr %v2.i, align 8
  br label %common.ret

b5:                                               ; preds = %b1
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b14 [
    i8 34, label %b6
    i8 92, label %b12
  ]

b6:                                               ; preds = %b5
  %s2sz298_p = getelementptr i32, ptr null, i32 1
  %s2sz298 = ptrtoint ptr %s2sz298_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz298)
  store i32 0, ptr %v0, align 4
  %v17 = getelementptr i8, ptr %p1, i64 132
  %s2sz299_p = getelementptr i1, ptr null, i32 1
  %s2sz299 = ptrtoint ptr %s2sz299_p to i64
  call void @s2_record(i32 0, ptr %v17, i64 %s2sz299)
  %v18 = load i1, ptr %v17, align 4
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v18, label %b8, label %b10

b8:                                               ; preds = %b6
  %v19 = getelementptr i8, ptr %p1, i64 56
  %v20 = getelementptr i8, ptr %p1, i64 120
  %s2sz300_p = getelementptr i32, ptr null, i32 1
  %s2sz300 = ptrtoint ptr %s2sz300_p to i64
  call void @s2_record(i32 0, ptr %v20, i64 %s2sz300)
  %v21 = load i32, ptr %v20, align 4
  call void @s2_record(i32 3, ptr null, i64 0)
  %v23_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v21, i32 1)
  %v23 = extractvalue { i32, i1 } %v23_pair, 0
  %v23_overflow = extractvalue { i32, i1 } %v23_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v23_overflow, label %v23_trap, label %v23_ok

v23_trap:                                         ; preds = %b8
  tail call void @llvm.trap()
  unreachable

v23_ok:                                           ; preds = %b8
  %v24_invalid = icmp ugt i32 %v23, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v24_invalid, label %v24_trap, label %v24_ok

v24_trap:                                         ; preds = %v23_ok
  tail call void @llvm.trap()
  unreachable

v24_ok:                                           ; preds = %v23_ok
  %v24_offset = zext nneg i32 %v23 to i64
  %v24 = getelementptr i8, ptr %v19, i64 %v24_offset
  %s2sz301_p = getelementptr i8, ptr null, i32 1
  %s2sz301 = ptrtoint ptr %s2sz301_p to i64
  call void @s2_record(i32 1, ptr %v24, i64 %s2sz301)
  store i8 5, ptr %v24, align 1
  %v27 = getelementptr i8, ptr %p1, i64 168
  %s2sz302_p = getelementptr i32, ptr null, i32 1
  %s2sz302 = ptrtoint ptr %s2sz302_p to i64
  call void @s2_record(i32 0, ptr %v27, i64 %s2sz302)
  %v28 = load i32, ptr %v27, align 4
  br label %common.ret

b10:                                              ; preds = %b6
  %v30 = tail call i32 @liza___liza_json_mut_done(ptr nonnull %p1)
  br label %common.ret

b12:                                              ; preds = %b5
  %s2sz303_p = getelementptr i32, ptr null, i32 1
  %s2sz303 = ptrtoint ptr %s2sz303_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz303)
  store i32 2, ptr %v0, align 4
  %v37 = getelementptr i8, ptr %p1, i64 152
  %v38 = getelementptr i8, ptr %p1, i64 48
  %s2sz304_p = getelementptr i64, ptr null, i32 1
  %s2sz304 = ptrtoint ptr %s2sz304_p to i64
  call void @s2_record(i32 0, ptr %v38, i64 %s2sz304)
  %v39 = load i64, ptr %v38, align 8
  %s2sz305_p = getelementptr i64, ptr null, i32 1
  %s2sz305 = ptrtoint ptr %s2sz305_p to i64
  call void @s2_record(i32 1, ptr %v37, i64 %s2sz305)
  store i64 %v39, ptr %v37, align 8
  br label %b14

b14:                                              ; preds = %b5, %b12
  %v41 = getelementptr i8, ptr %p1, i64 168
  %s2sz306_p = getelementptr i32, ptr null, i32 1
  %s2sz306 = ptrtoint ptr %s2sz306_p to i64
  call void @s2_record(i32 0, ptr %v41, i64 %s2sz306)
  %v42 = load i32, ptr %v41, align 4
  br label %common.ret

b16:                                              ; preds = %b0
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b44 [
    i8 114, label %b39
    i8 110, label %b39
    i8 102, label %b39
    i8 98, label %b39
    i8 92, label %b39
    i8 47, label %b39
    i8 34, label %b39
    i8 116, label %b39
    i8 117, label %b42
  ]

b39:                                              ; preds = %b16, %b16, %b16, %b16, %b16, %b16, %b16, %b16
  %s2sz307_p = getelementptr i32, ptr null, i32 1
  %s2sz307 = ptrtoint ptr %s2sz307_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz307)
  store i32 1, ptr %v0, align 4
  %v80 = getelementptr i8, ptr %p1, i64 168
  %s2sz308_p = getelementptr i32, ptr null, i32 1
  %s2sz308 = ptrtoint ptr %s2sz308_p to i64
  call void @s2_record(i32 0, ptr %v80, i64 %s2sz308)
  %v81 = load i32, ptr %v80, align 4
  br label %common.ret

b42:                                              ; preds = %b16
  %s2sz309_p = getelementptr i32, ptr null, i32 1
  %s2sz309 = ptrtoint ptr %s2sz309_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz309)
  store i32 3, ptr %v0, align 4
  %v87 = getelementptr i8, ptr %p1, i64 144
  %s2sz310_p = getelementptr <2 x i32>, ptr null, i32 1
  %s2sz310 = ptrtoint ptr %s2sz310_p to i64
  call void @s2_record(i32 1, ptr %v87, i64 %s2sz310)
  store <2 x i32> zeroinitializer, ptr %v87, align 4
  %v93 = getelementptr i8, ptr %p1, i64 168
  %s2sz311_p = getelementptr i32, ptr null, i32 1
  %s2sz311 = ptrtoint ptr %s2sz311_p to i64
  call void @s2_record(i32 0, ptr %v93, i64 %s2sz311)
  %v94 = load i32, ptr %v93, align 4
  br label %common.ret

b44:                                              ; preds = %b16
  %v96 = getelementptr i8, ptr %p1, i64 48
  %s2sz312_p = getelementptr i64, ptr null, i32 1
  %s2sz312 = ptrtoint ptr %s2sz312_p to i64
  call void @s2_record(i32 0, ptr %v96, i64 %s2sz312)
  %v97 = load i64, ptr %v96, align 8
  %v0.i12 = getelementptr i8, ptr %p1, i64 168
  %s2sz313_p = getelementptr i32, ptr null, i32 1
  %s2sz313 = ptrtoint ptr %s2sz313_p to i64
  call void @s2_record(i32 1, ptr %v0.i12, i64 %s2sz313)
  store i32 3, ptr %v0.i12, align 8
  %v2.i13 = getelementptr i8, ptr %p1, i64 176
  %s2sz314_p = getelementptr i64, ptr null, i32 1
  %s2sz314 = ptrtoint ptr %s2sz314_p to i64
  call void @s2_record(i32 1, ptr %v2.i13, i64 %s2sz314)
  store i64 %v97, ptr %v2.i13, align 8
  br label %common.ret

b46:                                              ; preds = %b0
  %v106.not = icmp eq i8 %p0, 92
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v106.not, label %b50, label %b48

b48:                                              ; preds = %b46
  %v108 = getelementptr i8, ptr %p1, i64 160
  %s2sz315_p = getelementptr i64, ptr null, i32 1
  %s2sz315 = ptrtoint ptr %s2sz315_p to i64
  call void @s2_record(i32 0, ptr %v108, i64 %s2sz315)
  %v109 = load i64, ptr %v108, align 8
  %v0.i14 = getelementptr i8, ptr %p1, i64 168
  %s2sz316_p = getelementptr i32, ptr null, i32 1
  %s2sz316 = ptrtoint ptr %s2sz316_p to i64
  call void @s2_record(i32 1, ptr %v0.i14, i64 %s2sz316)
  store i32 4, ptr %v0.i14, align 8
  %v2.i15 = getelementptr i8, ptr %p1, i64 176
  %s2sz317_p = getelementptr i64, ptr null, i32 1
  %s2sz317 = ptrtoint ptr %s2sz317_p to i64
  call void @s2_record(i32 1, ptr %v2.i15, i64 %s2sz317)
  store i64 %v109, ptr %v2.i15, align 8
  br label %common.ret

b50:                                              ; preds = %b46
  %s2sz318_p = getelementptr i32, ptr null, i32 1
  %s2sz318 = ptrtoint ptr %s2sz318_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz318)
  store i32 5, ptr %v0, align 4
  %v116 = getelementptr i8, ptr %p1, i64 168
  %s2sz319_p = getelementptr i32, ptr null, i32 1
  %s2sz319 = ptrtoint ptr %s2sz319_p to i64
  call void @s2_record(i32 0, ptr %v116, i64 %s2sz319)
  %v117 = load i32, ptr %v116, align 4
  br label %common.ret

b52:                                              ; preds = %b0
  %v123.not = icmp eq i8 %p0, 117
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v123.not, label %b56, label %b54

b54:                                              ; preds = %b52
  %v125 = getelementptr i8, ptr %p1, i64 160
  %s2sz320_p = getelementptr i64, ptr null, i32 1
  %s2sz320 = ptrtoint ptr %s2sz320_p to i64
  call void @s2_record(i32 0, ptr %v125, i64 %s2sz320)
  %v126 = load i64, ptr %v125, align 8
  %v0.i16 = getelementptr i8, ptr %p1, i64 168
  %s2sz321_p = getelementptr i32, ptr null, i32 1
  %s2sz321 = ptrtoint ptr %s2sz321_p to i64
  call void @s2_record(i32 1, ptr %v0.i16, i64 %s2sz321)
  store i32 4, ptr %v0.i16, align 8
  %v2.i17 = getelementptr i8, ptr %p1, i64 176
  %s2sz322_p = getelementptr i64, ptr null, i32 1
  %s2sz322 = ptrtoint ptr %s2sz322_p to i64
  call void @s2_record(i32 1, ptr %v2.i17, i64 %s2sz322)
  store i64 %v126, ptr %v2.i17, align 8
  br label %common.ret

b56:                                              ; preds = %b52
  %s2sz323_p = getelementptr i32, ptr null, i32 1
  %s2sz323 = ptrtoint ptr %s2sz323_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz323)
  store i32 6, ptr %v0, align 4
  %v133 = getelementptr i8, ptr %p1, i64 144
  %s2sz324_p = getelementptr <2 x i32>, ptr null, i32 1
  %s2sz324 = ptrtoint ptr %s2sz324_p to i64
  call void @s2_record(i32 1, ptr %v133, i64 %s2sz324)
  store <2 x i32> zeroinitializer, ptr %v133, align 4
  %v139 = getelementptr i8, ptr %p1, i64 168
  %s2sz325_p = getelementptr i32, ptr null, i32 1
  %s2sz325 = ptrtoint ptr %s2sz325_p to i64
  call void @s2_record(i32 0, ptr %v139, i64 %s2sz325)
  %v140 = load i32, ptr %v139, align 4
  br label %common.ret

b61:                                              ; preds = %b0, %b0
  %0 = add i8 %p0, -48
  %v5.i = icmp ult i8 %0, 10
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v5.i, label %b65, label %b6.i

b6.i:                                             ; preds = %b61
  %1 = add i8 %p0, -65
  %v14.i = icmp ult i8 %1, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v14.i, label %b65, label %b12.i

b12.i:                                            ; preds = %b6.i
  %2 = add i8 %p0, -97
  %v23.i = icmp ult i8 %2, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v23.i, label %b65, label %b63

b63:                                              ; preds = %b12.i
  %v155 = getelementptr i8, ptr %p1, i64 48
  %s2sz326_p = getelementptr i64, ptr null, i32 1
  %s2sz326 = ptrtoint ptr %s2sz326_p to i64
  call void @s2_record(i32 0, ptr %v155, i64 %s2sz326)
  %v156 = load i64, ptr %v155, align 8
  %v0.i18 = getelementptr i8, ptr %p1, i64 168
  %s2sz327_p = getelementptr i32, ptr null, i32 1
  %s2sz327 = ptrtoint ptr %s2sz327_p to i64
  call void @s2_record(i32 1, ptr %v0.i18, i64 %s2sz327)
  store i32 3, ptr %v0.i18, align 8
  %v2.i19 = getelementptr i8, ptr %p1, i64 176
  %s2sz328_p = getelementptr i64, ptr null, i32 1
  %s2sz328 = ptrtoint ptr %s2sz328_p to i64
  call void @s2_record(i32 1, ptr %v2.i19, i64 %s2sz328)
  store i64 %v156, ptr %v2.i19, align 8
  br label %common.ret

b65:                                              ; preds = %b12.i, %b6.i, %b61
  %.sink = phi i32 [ -55, %b6.i ], [ -48, %b61 ], [ -87, %b12.i ]
  %v160 = getelementptr i8, ptr %p1, i64 148
  %s2sz329_p = getelementptr i32, ptr null, i32 1
  %s2sz329 = ptrtoint ptr %s2sz329_p to i64
  call void @s2_record(i32 0, ptr %v160, i64 %s2sz329)
  %v162 = load i32, ptr %v160, align 4
  %v164_overflow = icmp ugt i32 %v162, 268435455
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v164_overflow, label %v164_trap, label %v165_ok

v164_trap:                                        ; preds = %b65
  tail call void @llvm.trap()
  unreachable

v165_ok:                                          ; preds = %b65
  %v24.i = zext nneg i8 %p0 to i32
  %v26_pair.i = add nsw i32 %.sink, %v24.i
  %v164 = shl nuw i32 %v162, 4
  %v165_pair69 = add nuw i32 %v164, %v26_pair.i
  %s2sz330_p = getelementptr i32, ptr null, i32 1
  %s2sz330 = ptrtoint ptr %s2sz330_p to i64
  call void @s2_record(i32 1, ptr %v160, i64 %s2sz330)
  store i32 %v165_pair69, ptr %v160, align 4
  %v167 = getelementptr i8, ptr %p1, i64 144
  %s2sz331_p = getelementptr i32, ptr null, i32 1
  %s2sz331 = ptrtoint ptr %s2sz331_p to i64
  call void @s2_record(i32 0, ptr %v167, i64 %s2sz331)
  %v169 = load i32, ptr %v167, align 4
  call void @s2_record(i32 3, ptr null, i64 0)
  %v171_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v169, i32 1)
  %v171_overflow = extractvalue { i32, i1 } %v171_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v171_overflow, label %v171_trap, label %v171_ok

v171_trap:                                        ; preds = %v165_ok
  tail call void @llvm.trap()
  unreachable

v171_ok:                                          ; preds = %v165_ok
  %v171 = extractvalue { i32, i1 } %v171_pair, 0
  %s2sz332_p = getelementptr i32, ptr null, i32 1
  %s2sz332 = ptrtoint ptr %s2sz332_p to i64
  call void @s2_record(i32 1, ptr %v167, i64 %s2sz332)
  store i32 %v171, ptr %v167, align 4
  %v176 = icmp eq i32 %v171, 4
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v176, label %b66, label %b89

b66:                                              ; preds = %v171_ok
  %v180 = icmp eq i32 %v1, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v180, label %b68, label %b76

b68:                                              ; preds = %b66
  %3 = add i32 %v165_pair69, -57344
  %or.cond = icmp ult i32 %3, -1024
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond, label %b73, label %b75

b73:                                              ; preds = %b68
  %v192 = getelementptr i8, ptr %p1, i64 160
  %s2sz333_p = getelementptr i64, ptr null, i32 1
  %s2sz333 = ptrtoint ptr %s2sz333_p to i64
  call void @s2_record(i32 0, ptr %v192, i64 %s2sz333)
  %v193 = load i64, ptr %v192, align 8
  %v0.i20 = getelementptr i8, ptr %p1, i64 168
  %s2sz334_p = getelementptr i32, ptr null, i32 1
  %s2sz334 = ptrtoint ptr %s2sz334_p to i64
  call void @s2_record(i32 1, ptr %v0.i20, i64 %s2sz334)
  store i32 4, ptr %v0.i20, align 8
  %v2.i21 = getelementptr i8, ptr %p1, i64 176
  %s2sz335_p = getelementptr i64, ptr null, i32 1
  %s2sz335 = ptrtoint ptr %s2sz335_p to i64
  call void @s2_record(i32 1, ptr %v2.i21, i64 %s2sz335)
  store i64 %v193, ptr %v2.i21, align 8
  br label %common.ret

b75:                                              ; preds = %b68
  %s2sz336_p = getelementptr i32, ptr null, i32 1
  %s2sz336 = ptrtoint ptr %s2sz336_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz336)
  store i32 1, ptr %v0, align 4
  %v200 = getelementptr i8, ptr %p1, i64 168
  %s2sz337_p = getelementptr i32, ptr null, i32 1
  %s2sz337 = ptrtoint ptr %s2sz337_p to i64
  call void @s2_record(i32 0, ptr %v200, i64 %s2sz337)
  %v201 = load i32, ptr %v200, align 4
  br label %common.ret

b76:                                              ; preds = %b66
  %4 = and i32 %v165_pair69, -1024
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %4, label %b88 [
    i32 55296, label %b80
    i32 56320, label %b86
  ]

b80:                                              ; preds = %b76
  %s2sz338_p = getelementptr i32, ptr null, i32 1
  %s2sz338 = ptrtoint ptr %s2sz338_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz338)
  store i32 4, ptr %v0, align 4
  %v215 = getelementptr i8, ptr %p1, i64 160
  %v216 = getelementptr i8, ptr %p1, i64 152
  %s2sz339_p = getelementptr i64, ptr null, i32 1
  %s2sz339 = ptrtoint ptr %s2sz339_p to i64
  call void @s2_record(i32 0, ptr %v216, i64 %s2sz339)
  %v217 = load i64, ptr %v216, align 8
  %s2sz340_p = getelementptr i64, ptr null, i32 1
  %s2sz340 = ptrtoint ptr %s2sz340_p to i64
  call void @s2_record(i32 1, ptr %v215, i64 %s2sz340)
  store i64 %v217, ptr %v215, align 8
  %v219 = getelementptr i8, ptr %p1, i64 168
  %s2sz341_p = getelementptr i32, ptr null, i32 1
  %s2sz341 = ptrtoint ptr %s2sz341_p to i64
  call void @s2_record(i32 0, ptr %v219, i64 %s2sz341)
  %v220 = load i32, ptr %v219, align 8
  br label %common.ret

b86:                                              ; preds = %b76
  %v232 = getelementptr i8, ptr %p1, i64 152
  %s2sz342_p = getelementptr i64, ptr null, i32 1
  %s2sz342 = ptrtoint ptr %s2sz342_p to i64
  call void @s2_record(i32 0, ptr %v232, i64 %s2sz342)
  %v233 = load i64, ptr %v232, align 8
  %v0.i22 = getelementptr i8, ptr %p1, i64 168
  %s2sz343_p = getelementptr i32, ptr null, i32 1
  %s2sz343 = ptrtoint ptr %s2sz343_p to i64
  call void @s2_record(i32 1, ptr %v0.i22, i64 %s2sz343)
  store i32 4, ptr %v0.i22, align 8
  %v2.i23 = getelementptr i8, ptr %p1, i64 176
  %s2sz344_p = getelementptr i64, ptr null, i32 1
  %s2sz344 = ptrtoint ptr %s2sz344_p to i64
  call void @s2_record(i32 1, ptr %v2.i23, i64 %s2sz344)
  store i64 %v233, ptr %v2.i23, align 8
  br label %common.ret

b88:                                              ; preds = %b76
  %s2sz345_p = getelementptr i32, ptr null, i32 1
  %s2sz345 = ptrtoint ptr %s2sz345_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz345)
  store i32 1, ptr %v0, align 4
  br label %b89

b89:                                              ; preds = %v171_ok, %b88
  %v240 = getelementptr i8, ptr %p1, i64 168
  %s2sz346_p = getelementptr i32, ptr null, i32 1
  %s2sz346 = ptrtoint ptr %s2sz346_p to i64
  call void @s2_record(i32 0, ptr %v240, i64 %s2sz346)
  %v241 = load i32, ptr %v240, align 4
  br label %common.ret

b91:                                              ; preds = %b0
  %v248 = getelementptr i8, ptr %p1, i64 136
  %s2sz347_p = getelementptr i32, ptr null, i32 1
  %s2sz347 = ptrtoint ptr %s2sz347_p to i64
  call void @s2_record(i32 0, ptr %v248, i64 %s2sz347)
  %v249 = load i32, ptr %v248, align 4
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v249, label %b125 [
    i32 1, label %b104.thread
    i32 2, label %b105
    i32 3, label %b120
  ]

b104.thread:                                      ; preds = %b91
  %v252 = getelementptr i8, ptr %p1, i64 140
  %s2sz348_p = getelementptr i32, ptr null, i32 1
  %s2sz348 = ptrtoint ptr %s2sz348_p to i64
  call void @s2_record(i32 0, ptr %v252, i64 %s2sz348)
  %v253 = load i32, ptr %v252, align 4
  %v255 = icmp eq i32 %v253, 1
  %. = select i1 %v255, i8 114, i8 0
  %v261 = icmp eq i32 %v253, 2
  %v263 = select i1 %v261, i8 117, i8 %.
  %v267 = icmp eq i32 %v253, 3
  %v269 = select i1 %v267, i8 101, i8 %v263
  br label %b125

b105:                                             ; preds = %b91
  %v276 = getelementptr i8, ptr %p1, i64 140
  %s2sz349_p = getelementptr i32, ptr null, i32 1
  %s2sz349 = ptrtoint ptr %s2sz349_p to i64
  call void @s2_record(i32 0, ptr %v276, i64 %s2sz349)
  %v277 = load i32, ptr %v276, align 4
  %v279 = icmp eq i32 %v277, 1
  %.v270 = select i1 %v279, i8 97, i8 0
  %v285 = icmp eq i32 %v277, 2
  %v287 = select i1 %v285, i8 108, i8 %.v270
  %v291 = icmp eq i32 %v277, 3
  %v293 = select i1 %v291, i8 115, i8 %v287
  %v297 = icmp eq i32 %v277, 4
  %v299 = select i1 %v297, i8 101, i8 %v293
  br label %b125

b120:                                             ; preds = %b91
  %v306 = getelementptr i8, ptr %p1, i64 140
  %s2sz350_p = getelementptr i32, ptr null, i32 1
  %s2sz350 = ptrtoint ptr %s2sz350_p to i64
  call void @s2_record(i32 0, ptr %v306, i64 %s2sz350)
  %v307 = load i32, ptr %v306, align 4
  %v309 = icmp eq i32 %v307, 1
  %.1 = select i1 %v309, i8 117, i8 108
  br label %b125

b125:                                             ; preds = %b91, %b105, %b104.thread, %b120
  %v30160 = phi i32 [ 4, %b120 ], [ 4, %b91 ], [ 4, %b104.thread ], [ 5, %b105 ]
  %v313 = phi i8 [ %.1, %b120 ], [ 0, %b91 ], [ %v269, %b104.thread ], [ %v299, %b105 ]
  %v314.not = icmp eq i8 %p0, %v313
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v314.not, label %b128, label %b126

b126:                                             ; preds = %b125
  %v316 = getelementptr i8, ptr %p1, i64 48
  %s2sz351_p = getelementptr i64, ptr null, i32 1
  %s2sz351 = ptrtoint ptr %s2sz351_p to i64
  call void @s2_record(i32 0, ptr %v316, i64 %s2sz351)
  %v317 = load i64, ptr %v316, align 8
  %v0.i24 = getelementptr i8, ptr %p1, i64 168
  %s2sz352_p = getelementptr i32, ptr null, i32 1
  %s2sz352 = ptrtoint ptr %s2sz352_p to i64
  call void @s2_record(i32 1, ptr %v0.i24, i64 %s2sz352)
  store i32 1, ptr %v0.i24, align 8
  %v2.i25 = getelementptr i8, ptr %p1, i64 176
  %s2sz353_p = getelementptr i64, ptr null, i32 1
  %s2sz353 = ptrtoint ptr %s2sz353_p to i64
  call void @s2_record(i32 1, ptr %v2.i25, i64 %s2sz353)
  store i64 %v317, ptr %v2.i25, align 8
  br label %common.ret

b128:                                             ; preds = %b125
  %v321 = getelementptr i8, ptr %p1, i64 140
  %s2sz354_p = getelementptr i32, ptr null, i32 1
  %s2sz354 = ptrtoint ptr %s2sz354_p to i64
  call void @s2_record(i32 0, ptr %v321, i64 %s2sz354)
  %v323 = load i32, ptr %v321, align 4
  call void @s2_record(i32 3, ptr null, i64 0)
  %v325_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v323, i32 1)
  %v325_overflow = extractvalue { i32, i1 } %v325_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v325_overflow, label %v325_trap, label %v325_ok

v325_trap:                                        ; preds = %b128
  tail call void @llvm.trap()
  unreachable

v325_ok:                                          ; preds = %b128
  %v325 = extractvalue { i32, i1 } %v325_pair, 0
  %s2sz355_p = getelementptr i32, ptr null, i32 1
  %s2sz355 = ptrtoint ptr %s2sz355_p to i64
  call void @s2_record(i32 1, ptr %v321, i64 %s2sz355)
  store i32 %v325, ptr %v321, align 4
  %v329 = icmp eq i32 %v325, %v30160
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v329, label %b129, label %b131

b129:                                             ; preds = %v325_ok
  %s2sz356_p = getelementptr i32, ptr null, i32 1
  %s2sz356 = ptrtoint ptr %s2sz356_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz356)
  store i32 0, ptr %v0, align 4
  %v0.i26 = getelementptr i8, ptr %p1, i64 120
  %s2sz357_p = getelementptr i32, ptr null, i32 1
  %s2sz357 = ptrtoint ptr %s2sz357_p to i64
  call void @s2_record(i32 0, ptr %v0.i26, i64 %s2sz357)
  %v1.i = load i32, ptr %v0.i26, align 4
  %v3.i = icmp eq i32 %v1.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v3.i, label %b1.i, label %b2.i

b1.i:                                             ; preds = %b129
  %v4.i = getelementptr i8, ptr %p1, i64 124
  %s2sz358_p = getelementptr i1, ptr null, i32 1
  %s2sz358 = ptrtoint ptr %s2sz358_p to i64
  call void @s2_record(i32 1, ptr %v4.i, i64 %s2sz358)
  store i1 true, ptr %v4.i, align 4
  br label %liza___liza_json_mut_done.exit

b2.i:                                             ; preds = %b129
  %v10_pair.i = add i32 %v1.i, -1
  %v12_invalid.i = icmp ugt i32 %v10_pair.i, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v12_invalid.i, label %v12_trap.i, label %v12_ok.i

v12_trap.i:                                       ; preds = %b2.i
  tail call void @llvm.trap()
  unreachable

v12_ok.i:                                         ; preds = %b2.i
  %v11.i = getelementptr i8, ptr %p1, i64 56
  %v12_offset.i = zext nneg i32 %v10_pair.i to i64
  %v12.i = getelementptr i8, ptr %v11.i, i64 %v12_offset.i
  %s2sz359_p = getelementptr i8, ptr null, i32 1
  %s2sz359 = ptrtoint ptr %s2sz359_p to i64
  call void @s2_record(i32 0, ptr %v12.i, i64 %s2sz359)
  %v13.i = load i8, ptr %v12.i, align 1
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %v13.i, label %v28_ok.i [
    i8 1, label %v24_ok.i27
    i8 3, label %v24_ok.i27
  ]

v24_ok.i27:                                       ; preds = %v12_ok.i, %v12_ok.i
  %s2sz360_p = getelementptr i8, ptr null, i32 1
  %s2sz360 = ptrtoint ptr %s2sz360_p to i64
  call void @s2_record(i32 1, ptr %v12.i, i64 %s2sz360)
  store i8 2, ptr %v12.i, align 1
  br label %liza___liza_json_mut_done.exit

v28_ok.i:                                         ; preds = %v12_ok.i
  %s2sz361_p = getelementptr i8, ptr null, i32 1
  %s2sz361 = ptrtoint ptr %s2sz361_p to i64
  call void @s2_record(i32 1, ptr %v12.i, i64 %s2sz361)
  store i8 7, ptr %v12.i, align 1
  br label %liza___liza_json_mut_done.exit

liza___liza_json_mut_done.exit:                   ; preds = %b1.i, %v24_ok.i27, %v28_ok.i
  %v31.i = getelementptr i8, ptr %p1, i64 168
  %s2sz362_p = getelementptr i32, ptr null, i32 1
  %s2sz362 = ptrtoint ptr %s2sz362_p to i64
  call void @s2_record(i32 0, ptr %v31.i, i64 %s2sz362)
  %v32.i = load i32, ptr %v31.i, align 4
  br label %common.ret

b131:                                             ; preds = %v325_ok
  %v336 = getelementptr i8, ptr %p1, i64 168
  %s2sz363_p = getelementptr i32, ptr null, i32 1
  %s2sz363 = ptrtoint ptr %s2sz363_p to i64
  call void @s2_record(i32 0, ptr %v336, i64 %s2sz363)
  %v337 = load i32, ptr %v336, align 4
  br label %common.ret

b132:                                             ; preds = %b0
  %5 = add i32 %v1, -10
  %or.cond10 = icmp ult i32 %5, 8
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond10, label %b136, label %b216

b136:                                             ; preds = %b132
  %6 = add i8 %p0, -48
  %v5.i28 = icmp ult i8 %6, 10
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v5.i28, label %b138, label %b158

b138:                                             ; preds = %b136
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v1, label %b151 [
    i32 11, label %b140
    i32 10, label %b143
    i32 13, label %b157.sink.split
  ]

b140:                                             ; preds = %b138
  %v354 = getelementptr i8, ptr %p1, i64 48
  %s2sz364_p = getelementptr i64, ptr null, i32 1
  %s2sz364 = ptrtoint ptr %s2sz364_p to i64
  call void @s2_record(i32 0, ptr %v354, i64 %s2sz364)
  %v355 = load i64, ptr %v354, align 8
  %v0.i29 = getelementptr i8, ptr %p1, i64 168
  %s2sz365_p = getelementptr i32, ptr null, i32 1
  %s2sz365 = ptrtoint ptr %s2sz365_p to i64
  call void @s2_record(i32 1, ptr %v0.i29, i64 %s2sz365)
  store i32 2, ptr %v0.i29, align 8
  %v2.i30 = getelementptr i8, ptr %p1, i64 176
  %s2sz366_p = getelementptr i64, ptr null, i32 1
  %s2sz366 = ptrtoint ptr %s2sz366_p to i64
  call void @s2_record(i32 1, ptr %v2.i30, i64 %s2sz366)
  store i64 %v355, ptr %v2.i30, align 8
  br label %common.ret

b143:                                             ; preds = %b138
  %v364 = icmp eq i8 %p0, 48
  %.78 = select i1 %v364, i32 11, i32 12
  br label %b157.sink.split

b151:                                             ; preds = %b138
  %v379.off = add nsw i32 %v1, -15
  %switch = icmp ult i32 %v379.off, 2
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %switch, label %b157.sink.split, label %b157

b157.sink.split:                                  ; preds = %b151, %b138, %b143
  %.sink74 = phi i32 [ 14, %b138 ], [ %.78, %b143 ], [ 17, %b151 ]
  %s2sz367_p = getelementptr i32, ptr null, i32 1
  %s2sz367 = ptrtoint ptr %s2sz367_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz367)
  store i32 %.sink74, ptr %v0, align 4
  br label %b157

b157:                                             ; preds = %b157.sink.split, %b151
  %v391 = getelementptr i8, ptr %p1, i64 168
  %s2sz368_p = getelementptr i32, ptr null, i32 1
  %s2sz368 = ptrtoint ptr %s2sz368_p to i64
  call void @s2_record(i32 0, ptr %v391, i64 %s2sz368)
  %v392 = load i32, ptr %v391, align 4
  br label %common.ret

b158:                                             ; preds = %b136
  %v396 = icmp eq i32 %v1, 11
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v396, label %b162, label %b159

b159:                                             ; preds = %b158
  %v401 = icmp eq i32 %v1, 12
  %v405 = icmp eq i8 %p0, 46
  %or.cond6 = select i1 %v401, i1 %v405, i1 false
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond6, label %b165, label %b167

b162:                                             ; preds = %b158
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b210 [
    i8 46, label %b165
    i8 101, label %b180
    i8 69, label %b180
    i8 32, label %b215
    i8 10, label %b215
    i8 9, label %b215
    i8 13, label %b215
    i8 93, label %b215
    i8 44, label %b215
    i8 125, label %b215
  ]

b165:                                             ; preds = %b162, %b159
  %s2sz369_p = getelementptr i32, ptr null, i32 1
  %s2sz369 = ptrtoint ptr %s2sz369_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz369)
  store i32 13, ptr %v0, align 4
  %v410 = getelementptr i8, ptr %p1, i64 168
  %s2sz370_p = getelementptr i32, ptr null, i32 1
  %s2sz370 = ptrtoint ptr %s2sz370_p to i64
  call void @s2_record(i32 0, ptr %v410, i64 %s2sz370)
  %v411 = load i32, ptr %v410, align 4
  br label %common.ret

b167:                                             ; preds = %b159
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v1, label %b203 [
    i32 11, label %b174
    i32 12, label %b174
    i32 14, label %b174
    i32 15, label %b183
    i32 10, label %b201
    i32 13, label %b201
    i32 16, label %b201
  ]

b174:                                             ; preds = %b167, %b167, %b167
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b191 [
    i8 101, label %b180
    i8 69, label %b180
  ]

b180:                                             ; preds = %b162, %b162, %b174, %b174
  %s2sz371_p = getelementptr i32, ptr null, i32 1
  %s2sz371 = ptrtoint ptr %s2sz371_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz371)
  store i32 15, ptr %v0, align 4
  %v439 = getelementptr i8, ptr %p1, i64 168
  %s2sz372_p = getelementptr i32, ptr null, i32 1
  %s2sz372 = ptrtoint ptr %s2sz372_p to i64
  call void @s2_record(i32 0, ptr %v439, i64 %s2sz372)
  %v440 = load i32, ptr %v439, align 4
  br label %common.ret

b183:                                             ; preds = %b167
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b201 [
    i8 45, label %b189
    i8 43, label %b189
  ]

b189:                                             ; preds = %b183, %b183
  %s2sz373_p = getelementptr i32, ptr null, i32 1
  %s2sz373 = ptrtoint ptr %s2sz373_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz373)
  store i32 16, ptr %v0, align 4
  %v456 = getelementptr i8, ptr %p1, i64 168
  %s2sz374_p = getelementptr i32, ptr null, i32 1
  %s2sz374 = ptrtoint ptr %s2sz374_p to i64
  call void @s2_record(i32 0, ptr %v456, i64 %s2sz374)
  %v457 = load i32, ptr %v456, align 4
  br label %common.ret

b191:                                             ; preds = %b174
  %cond = icmp eq i32 %v1, 13
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %cond, label %b201, label %b203

b201:                                             ; preds = %b191, %b167, %b167, %b167, %b183
  %v481 = getelementptr i8, ptr %p1, i64 48
  %s2sz375_p = getelementptr i64, ptr null, i32 1
  %s2sz375 = ptrtoint ptr %s2sz375_p to i64
  call void @s2_record(i32 0, ptr %v481, i64 %s2sz375)
  %v482 = load i64, ptr %v481, align 8
  %v0.i31 = getelementptr i8, ptr %p1, i64 168
  %s2sz376_p = getelementptr i32, ptr null, i32 1
  %s2sz376 = ptrtoint ptr %s2sz376_p to i64
  call void @s2_record(i32 1, ptr %v0.i31, i64 %s2sz376)
  store i32 2, ptr %v0.i31, align 8
  %v2.i32 = getelementptr i8, ptr %p1, i64 176
  %s2sz377_p = getelementptr i64, ptr null, i32 1
  %s2sz377 = ptrtoint ptr %s2sz377_p to i64
  call void @s2_record(i32 1, ptr %v2.i32, i64 %s2sz377)
  store i64 %v482, ptr %v2.i32, align 8
  br label %common.ret

b203:                                             ; preds = %b191, %b167
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b210 [
    i8 32, label %b215
    i8 10, label %b215
    i8 9, label %b215
    i8 13, label %b215
    i8 93, label %b215
    i8 44, label %b215
    i8 125, label %b215
  ]

b210:                                             ; preds = %b162, %b203
  %v501 = getelementptr i8, ptr %p1, i64 48
  %s2sz378_p = getelementptr i64, ptr null, i32 1
  %s2sz378 = ptrtoint ptr %s2sz378_p to i64
  call void @s2_record(i32 0, ptr %v501, i64 %s2sz378)
  %v502 = load i64, ptr %v501, align 8
  %v0.i34 = getelementptr i8, ptr %p1, i64 168
  %s2sz379_p = getelementptr i32, ptr null, i32 1
  %s2sz379 = ptrtoint ptr %s2sz379_p to i64
  call void @s2_record(i32 1, ptr %v0.i34, i64 %s2sz379)
  store i32 2, ptr %v0.i34, align 8
  %v2.i35 = getelementptr i8, ptr %p1, i64 176
  %s2sz380_p = getelementptr i64, ptr null, i32 1
  %s2sz380 = ptrtoint ptr %s2sz380_p to i64
  call void @s2_record(i32 1, ptr %v2.i35, i64 %s2sz380)
  store i64 %v502, ptr %v2.i35, align 8
  br label %common.ret

b215:                                             ; preds = %b162, %b162, %b162, %b162, %b162, %b162, %b162, %b203, %b203, %b203, %b203, %b203, %b203, %b203
  %s2sz381_p = getelementptr i32, ptr null, i32 1
  %s2sz381 = ptrtoint ptr %s2sz381_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz381)
  store i32 0, ptr %v0, align 4
  %v510 = tail call i32 @liza___liza_json_mut_done(ptr nonnull %p1)
  br label %b216

b216:                                             ; preds = %b132, %b215
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b219 [
    i8 32, label %b217
    i8 10, label %b217
    i8 9, label %b217
    i8 13, label %b217
  ]

b217:                                             ; preds = %b216, %b216, %b216, %b216
  %v513 = getelementptr i8, ptr %p1, i64 168
  %s2sz382_p = getelementptr i32, ptr null, i32 1
  %s2sz382 = ptrtoint ptr %s2sz382_p to i64
  call void @s2_record(i32 0, ptr %v513, i64 %s2sz382)
  %v514 = load i32, ptr %v513, align 4
  br label %common.ret

b219:                                             ; preds = %b216
  %v516 = getelementptr i8, ptr %p1, i64 120
  %s2sz383_p = getelementptr i32, ptr null, i32 1
  %s2sz383 = ptrtoint ptr %s2sz383_p to i64
  call void @s2_record(i32 0, ptr %v516, i64 %s2sz383)
  %v517 = load i32, ptr %v516, align 4
  %v519.not = icmp eq i32 %v517, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v519.not, label %b222, label %b220

b220:                                             ; preds = %b219
  %v524_pair = add i32 %v517, -1
  %v525_invalid = icmp ugt i32 %v524_pair, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v525_invalid, label %v525_trap, label %v525_ok

v525_trap:                                        ; preds = %b220
  tail call void @llvm.trap()
  unreachable

v525_ok:                                          ; preds = %b220
  %v520 = getelementptr i8, ptr %p1, i64 56
  %v525_offset = zext nneg i32 %v524_pair to i64
  %v525 = getelementptr i8, ptr %v520, i64 %v525_offset
  %s2sz384_p = getelementptr i8, ptr null, i32 1
  %s2sz384 = ptrtoint ptr %s2sz384_p to i64
  call void @s2_record(i32 0, ptr %v525, i64 %s2sz384)
  %v526 = load i8, ptr %v525, align 1
  br label %b222

b222:                                             ; preds = %b219, %v525_ok
  %v527 = phi i8 [ %v526, %v525_ok ], [ 0, %b219 ]
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b240 [
    i8 93, label %b223
    i8 125, label %b232
  ]

b223:                                             ; preds = %b222
  %7 = add i8 %v527, -1
  %8 = icmp ult i8 %7, 2
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %8, label %b229, label %b240

b229:                                             ; preds = %b223
  call void @s2_record(i32 3, ptr null, i64 0)
  %v542_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v542_overflow = extractvalue { i32, i1 } %v542_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v542_overflow, label %v542_trap, label %v542_ok

v542_trap:                                        ; preds = %b229
  tail call void @llvm.trap()
  unreachable

v542_ok:                                          ; preds = %b229
  %v542 = extractvalue { i32, i1 } %v542_pair, 0
  %s2sz385_p = getelementptr i32, ptr null, i32 1
  %s2sz385 = ptrtoint ptr %s2sz385_p to i64
  call void @s2_record(i32 1, ptr %v516, i64 %s2sz385)
  store i32 %v542, ptr %v516, align 4
  %v544 = getelementptr i8, ptr %p1, i64 168
  %s2sz386_p = getelementptr i32, ptr null, i32 1
  %s2sz386 = ptrtoint ptr %s2sz386_p to i64
  call void @s2_record(i32 0, ptr %v544, i64 %s2sz386)
  %v545 = load i32, ptr %v544, align 4
  br label %common.ret

b232:                                             ; preds = %b222
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %v527, label %b259 [
    i8 7, label %b238
    i8 4, label %b238
    i8 2, label %b246
    i8 5, label %b255
    i8 8, label %b264
  ]

b238:                                             ; preds = %b232, %b232
  call void @s2_record(i32 3, ptr null, i64 0)
  %v560_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v560_overflow = extractvalue { i32, i1 } %v560_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v560_overflow, label %v560_trap, label %v560_ok

v560_trap:                                        ; preds = %b238
  tail call void @llvm.trap()
  unreachable

v560_ok:                                          ; preds = %b238
  %v560 = extractvalue { i32, i1 } %v560_pair, 0
  %s2sz387_p = getelementptr i32, ptr null, i32 1
  %s2sz387 = ptrtoint ptr %s2sz387_p to i64
  call void @s2_record(i32 1, ptr %v516, i64 %s2sz387)
  store i32 %v560, ptr %v516, align 4
  %v562 = getelementptr i8, ptr %p1, i64 168
  %s2sz388_p = getelementptr i32, ptr null, i32 1
  %s2sz388 = ptrtoint ptr %s2sz388_p to i64
  call void @s2_record(i32 0, ptr %v562, i64 %s2sz388)
  %v563 = load i32, ptr %v562, align 4
  br label %common.ret

b240:                                             ; preds = %b223, %b222
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %v527, label %b259 [
    i8 7, label %b244
    i8 2, label %b244
    i8 5, label %b253
    i8 4, label %b262.critedge
    i8 8, label %b262.critedge
  ]

b244:                                             ; preds = %b240, %b240
  %v571.not = icmp eq i8 %p0, 44
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v571.not, label %b248, label %b246

b246:                                             ; preds = %b232, %b244
  %v573 = getelementptr i8, ptr %p1, i64 48
  %s2sz389_p = getelementptr i64, ptr null, i32 1
  %s2sz389 = ptrtoint ptr %s2sz389_p to i64
  call void @s2_record(i32 0, ptr %v573, i64 %s2sz389)
  %v574 = load i64, ptr %v573, align 8
  %v0.i39 = getelementptr i8, ptr %p1, i64 168
  %s2sz390_p = getelementptr i32, ptr null, i32 1
  %s2sz390 = ptrtoint ptr %s2sz390_p to i64
  call void @s2_record(i32 1, ptr %v0.i39, i64 %s2sz390)
  store i32 1, ptr %v0.i39, align 8
  %v2.i40 = getelementptr i8, ptr %p1, i64 176
  %s2sz391_p = getelementptr i64, ptr null, i32 1
  %s2sz391 = ptrtoint ptr %s2sz391_p to i64
  call void @s2_record(i32 1, ptr %v2.i40, i64 %s2sz391)
  store i64 %v574, ptr %v2.i40, align 8
  br label %common.ret

b248:                                             ; preds = %b244
  %v579 = icmp eq i8 %v527, 2
  %v580 = getelementptr i8, ptr %p1, i64 56
  call void @s2_record(i32 3, ptr null, i64 0)
  %v584_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v584 = extractvalue { i32, i1 } %v584_pair, 0
  %v584_overflow = extractvalue { i32, i1 } %v584_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v579, label %b249, label %b250

b249:                                             ; preds = %b248
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v584_overflow, label %v584_trap, label %v584_ok

v584_trap:                                        ; preds = %b249
  tail call void @llvm.trap()
  unreachable

v584_ok:                                          ; preds = %b249
  %v585_invalid = icmp ugt i32 %v584, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v585_invalid, label %v585_trap, label %b251

v585_trap:                                        ; preds = %v584_ok
  tail call void @llvm.trap()
  unreachable

b250:                                             ; preds = %b248
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v584_overflow, label %v592_trap, label %v592_ok

v592_trap:                                        ; preds = %b250
  tail call void @llvm.trap()
  unreachable

v592_ok:                                          ; preds = %b250
  %v593_invalid = icmp ugt i32 %v584, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v593_invalid, label %v593_trap, label %b251

v593_trap:                                        ; preds = %v592_ok
  tail call void @llvm.trap()
  unreachable

b251:                                             ; preds = %v592_ok, %v584_ok
  %.sink75 = phi i8 [ 3, %v584_ok ], [ 8, %v592_ok ]
  %v593_offset = zext nneg i32 %v584 to i64
  %v593 = getelementptr i8, ptr %v580, i64 %v593_offset
  %s2sz392_p = getelementptr i8, ptr null, i32 1
  %s2sz392 = ptrtoint ptr %s2sz392_p to i64
  call void @s2_record(i32 1, ptr %v593, i64 %s2sz392)
  store i8 %.sink75, ptr %v593, align 1
  %v596 = getelementptr i8, ptr %p1, i64 168
  %s2sz393_p = getelementptr i32, ptr null, i32 1
  %s2sz393 = ptrtoint ptr %s2sz393_p to i64
  call void @s2_record(i32 0, ptr %v596, i64 %s2sz393)
  %v597 = load i32, ptr %v596, align 4
  br label %common.ret

b253:                                             ; preds = %b240
  %v601.not = icmp eq i8 %p0, 58
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v601.not, label %b257, label %b255

b255:                                             ; preds = %b232, %b253
  %v603 = getelementptr i8, ptr %p1, i64 48
  %s2sz394_p = getelementptr i64, ptr null, i32 1
  %s2sz394 = ptrtoint ptr %s2sz394_p to i64
  call void @s2_record(i32 0, ptr %v603, i64 %s2sz394)
  %v604 = load i64, ptr %v603, align 8
  %v0.i41 = getelementptr i8, ptr %p1, i64 168
  %s2sz395_p = getelementptr i32, ptr null, i32 1
  %s2sz395 = ptrtoint ptr %s2sz395_p to i64
  call void @s2_record(i32 1, ptr %v0.i41, i64 %s2sz395)
  store i32 1, ptr %v0.i41, align 8
  %v2.i42 = getelementptr i8, ptr %p1, i64 176
  %s2sz396_p = getelementptr i64, ptr null, i32 1
  %s2sz396 = ptrtoint ptr %s2sz396_p to i64
  call void @s2_record(i32 1, ptr %v2.i42, i64 %s2sz396)
  store i64 %v604, ptr %v2.i42, align 8
  br label %common.ret

b257:                                             ; preds = %b253
  %v608 = getelementptr i8, ptr %p1, i64 56
  call void @s2_record(i32 3, ptr null, i64 0)
  %v612_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v612 = extractvalue { i32, i1 } %v612_pair, 0
  %v612_overflow = extractvalue { i32, i1 } %v612_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v612_overflow, label %v612_trap, label %v612_ok

v612_trap:                                        ; preds = %b257
  tail call void @llvm.trap()
  unreachable

v612_ok:                                          ; preds = %b257
  %v613_invalid = icmp ugt i32 %v612, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v613_invalid, label %v613_trap, label %v613_ok

v613_trap:                                        ; preds = %v612_ok
  tail call void @llvm.trap()
  unreachable

v613_ok:                                          ; preds = %v612_ok
  %v613_offset = zext nneg i32 %v612 to i64
  %v613 = getelementptr i8, ptr %v608, i64 %v613_offset
  %s2sz397_p = getelementptr i8, ptr null, i32 1
  %s2sz397 = ptrtoint ptr %s2sz397_p to i64
  call void @s2_record(i32 1, ptr %v613, i64 %s2sz397)
  store i8 6, ptr %v613, align 1
  %v616 = getelementptr i8, ptr %p1, i64 168
  %s2sz398_p = getelementptr i32, ptr null, i32 1
  %s2sz398 = ptrtoint ptr %s2sz398_p to i64
  call void @s2_record(i32 0, ptr %v616, i64 %s2sz398)
  %v617 = load i32, ptr %v616, align 4
  br label %common.ret

b259:                                             ; preds = %b232, %b240
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v519.not, label %b268, label %b273

b262.critedge:                                    ; preds = %b240, %b240
  %v625.not = icmp eq i8 %p0, 34
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v625.not, label %b266, label %b264

b264:                                             ; preds = %b232, %b262.critedge
  %v627 = getelementptr i8, ptr %p1, i64 48
  %s2sz399_p = getelementptr i64, ptr null, i32 1
  %s2sz399 = ptrtoint ptr %s2sz399_p to i64
  call void @s2_record(i32 0, ptr %v627, i64 %s2sz399)
  %v628 = load i64, ptr %v627, align 8
  %v0.i43 = getelementptr i8, ptr %p1, i64 168
  %s2sz400_p = getelementptr i32, ptr null, i32 1
  %s2sz400 = ptrtoint ptr %s2sz400_p to i64
  call void @s2_record(i32 1, ptr %v0.i43, i64 %s2sz400)
  store i32 1, ptr %v0.i43, align 8
  %v2.i44 = getelementptr i8, ptr %p1, i64 176
  %s2sz401_p = getelementptr i64, ptr null, i32 1
  %s2sz401 = ptrtoint ptr %s2sz401_p to i64
  call void @s2_record(i32 1, ptr %v2.i44, i64 %s2sz401)
  store i64 %v628, ptr %v2.i44, align 8
  br label %common.ret

b266:                                             ; preds = %b262.critedge
  %v632 = getelementptr i8, ptr %p1, i64 132
  %s2sz402_p = getelementptr i1, ptr null, i32 1
  %s2sz402 = ptrtoint ptr %s2sz402_p to i64
  call void @s2_record(i32 1, ptr %v632, i64 %s2sz402)
  store i1 true, ptr %v632, align 4
  %s2sz403_p = getelementptr i32, ptr null, i32 1
  %s2sz403 = ptrtoint ptr %s2sz403_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz403)
  store i32 1, ptr %v0, align 4
  %v638 = getelementptr i8, ptr %p1, i64 168
  %s2sz404_p = getelementptr i32, ptr null, i32 1
  %s2sz404 = ptrtoint ptr %s2sz404_p to i64
  call void @s2_record(i32 0, ptr %v638, i64 %s2sz404)
  %v639 = load i32, ptr %v638, align 4
  br label %common.ret

b268:                                             ; preds = %b259
  %v645 = getelementptr i8, ptr %p1, i64 124
  %s2sz405_p = getelementptr i1, ptr null, i32 1
  %s2sz405 = ptrtoint ptr %s2sz405_p to i64
  call void @s2_record(i32 0, ptr %v645, i64 %s2sz405)
  %v646 = load i1, ptr %v645, align 4
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v646, label %b271, label %b273

b271:                                             ; preds = %b268
  %v649 = getelementptr i8, ptr %p1, i64 48
  %s2sz406_p = getelementptr i64, ptr null, i32 1
  %s2sz406 = ptrtoint ptr %s2sz406_p to i64
  call void @s2_record(i32 0, ptr %v649, i64 %s2sz406)
  %v650 = load i64, ptr %v649, align 8
  %v0.i45 = getelementptr i8, ptr %p1, i64 168
  %s2sz407_p = getelementptr i32, ptr null, i32 1
  %s2sz407 = ptrtoint ptr %s2sz407_p to i64
  call void @s2_record(i32 1, ptr %v0.i45, i64 %s2sz407)
  store i32 1, ptr %v0.i45, align 8
  %v2.i46 = getelementptr i8, ptr %p1, i64 176
  %s2sz408_p = getelementptr i64, ptr null, i32 1
  %s2sz408 = ptrtoint ptr %s2sz408_p to i64
  call void @s2_record(i32 1, ptr %v2.i46, i64 %s2sz408)
  store i64 %v650, ptr %v2.i46, align 8
  br label %common.ret

b273:                                             ; preds = %b268, %b259
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b291 [
    i8 123, label %b277
    i8 91, label %b277
    i8 34, label %b286
    i8 45, label %b289
  ]

b277:                                             ; preds = %b273, %b273
  %v663 = icmp eq i32 %v517, 64
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v663, label %b279, label %b281

b279:                                             ; preds = %b277
  %v665 = getelementptr i8, ptr %p1, i64 48
  %s2sz409_p = getelementptr i64, ptr null, i32 1
  %s2sz409 = ptrtoint ptr %s2sz409_p to i64
  call void @s2_record(i32 0, ptr %v665, i64 %s2sz409)
  %v666 = load i64, ptr %v665, align 8
  %v0.i47 = getelementptr i8, ptr %p1, i64 168
  %s2sz410_p = getelementptr i32, ptr null, i32 1
  %s2sz410 = ptrtoint ptr %s2sz410_p to i64
  call void @s2_record(i32 1, ptr %v0.i47, i64 %s2sz410)
  store i32 7, ptr %v0.i47, align 8
  %v2.i48 = getelementptr i8, ptr %p1, i64 176
  %s2sz411_p = getelementptr i64, ptr null, i32 1
  %s2sz411 = ptrtoint ptr %s2sz411_p to i64
  call void @s2_record(i32 1, ptr %v2.i48, i64 %s2sz411)
  store i64 %v666, ptr %v2.i48, align 8
  br label %common.ret

b281:                                             ; preds = %b277
  %v671 = tail call i32 @liza___liza_json_mut_done(ptr nonnull %p1)
  %v674 = icmp eq i8 %p0, 91
  %s2sz412_p = getelementptr i32, ptr null, i32 1
  %s2sz412 = ptrtoint ptr %s2sz412_p to i64
  call void @s2_record(i32 0, ptr %v516, i64 %s2sz412)
  %v677 = load i32, ptr %v516, align 4
  %v678_invalid = icmp ugt i32 %v677, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v674, label %b282, label %b283

b282:                                             ; preds = %b281
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v678_invalid, label %v678_trap, label %b284

v678_trap:                                        ; preds = %b282
  tail call void @llvm.trap()
  unreachable

b283:                                             ; preds = %b281
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v678_invalid, label %v684_trap, label %b284

v684_trap:                                        ; preds = %b283
  tail call void @llvm.trap()
  unreachable

b284:                                             ; preds = %b283, %b282
  %.sink76 = phi i8 [ 1, %b282 ], [ 4, %b283 ]
  %v681 = getelementptr i8, ptr %p1, i64 56
  %v684_offset = zext nneg i32 %v677 to i64
  %v684 = getelementptr i8, ptr %v681, i64 %v684_offset
  %s2sz413_p = getelementptr i8, ptr null, i32 1
  %s2sz413 = ptrtoint ptr %s2sz413_p to i64
  call void @s2_record(i32 1, ptr %v684, i64 %s2sz413)
  store i8 %.sink76, ptr %v684, align 1
  %s2sz414_p = getelementptr i32, ptr null, i32 1
  %s2sz414 = ptrtoint ptr %s2sz414_p to i64
  call void @s2_record(i32 0, ptr %v516, i64 %s2sz414)
  %v689 = load i32, ptr %v516, align 4
  call void @s2_record(i32 3, ptr null, i64 0)
  %v691_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v689, i32 1)
  %v691_overflow = extractvalue { i32, i1 } %v691_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v691_overflow, label %v691_trap, label %v691_ok

v691_trap:                                        ; preds = %b284
  tail call void @llvm.trap()
  unreachable

v691_ok:                                          ; preds = %b284
  %v691 = extractvalue { i32, i1 } %v691_pair, 0
  %s2sz415_p = getelementptr i32, ptr null, i32 1
  %s2sz415 = ptrtoint ptr %s2sz415_p to i64
  call void @s2_record(i32 1, ptr %v516, i64 %s2sz415)
  store i32 %v691, ptr %v516, align 4
  %v693 = getelementptr i8, ptr %p1, i64 168
  %s2sz416_p = getelementptr i32, ptr null, i32 1
  %s2sz416 = ptrtoint ptr %s2sz416_p to i64
  call void @s2_record(i32 0, ptr %v693, i64 %s2sz416)
  %v694 = load i32, ptr %v693, align 4
  br label %common.ret

b286:                                             ; preds = %b273
  %v697 = getelementptr i8, ptr %p1, i64 132
  %s2sz417_p = getelementptr i1, ptr null, i32 1
  %s2sz417 = ptrtoint ptr %s2sz417_p to i64
  call void @s2_record(i32 1, ptr %v697, i64 %s2sz417)
  store i1 false, ptr %v697, align 4
  %s2sz418_p = getelementptr i32, ptr null, i32 1
  %s2sz418 = ptrtoint ptr %s2sz418_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz418)
  store i32 1, ptr %v0, align 4
  %v703 = getelementptr i8, ptr %p1, i64 168
  %s2sz419_p = getelementptr i32, ptr null, i32 1
  %s2sz419 = ptrtoint ptr %s2sz419_p to i64
  call void @s2_record(i32 0, ptr %v703, i64 %s2sz419)
  %v704 = load i32, ptr %v703, align 4
  br label %common.ret

b289:                                             ; preds = %b273
  %s2sz420_p = getelementptr i32, ptr null, i32 1
  %s2sz420 = ptrtoint ptr %s2sz420_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz420)
  store i32 10, ptr %v0, align 4
  %v710 = getelementptr i8, ptr %p1, i64 168
  %s2sz421_p = getelementptr i32, ptr null, i32 1
  %s2sz421 = ptrtoint ptr %s2sz421_p to i64
  call void @s2_record(i32 0, ptr %v710, i64 %s2sz421)
  %v711 = load i32, ptr %v710, align 4
  br label %common.ret

b291:                                             ; preds = %b273
  %9 = add i8 %p0, -48
  %v5.i49 = icmp ult i8 %9, 10
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v5.i49, label %b292, label %b297

b292:                                             ; preds = %b291
  %v714 = icmp eq i8 %p0, 48
  %.11 = select i1 %v714, i32 11, i32 12
  %s2sz422_p = getelementptr i32, ptr null, i32 1
  %s2sz422 = ptrtoint ptr %s2sz422_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz422)
  store i32 %.11, ptr %v0, align 4
  %v721 = getelementptr i8, ptr %p1, i64 168
  %s2sz423_p = getelementptr i32, ptr null, i32 1
  %s2sz423 = ptrtoint ptr %s2sz423_p to i64
  call void @s2_record(i32 0, ptr %v721, i64 %s2sz423)
  %v722 = load i32, ptr %v721, align 4
  br label %common.ret

b297:                                             ; preds = %b291
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i8 %p0, label %b312 [
    i8 116, label %b304
    i8 102, label %b304
    i8 110, label %b304
  ]

b304:                                             ; preds = %b297, %b297, %b297
  %s2sz424_p = getelementptr i32, ptr null, i32 1
  %s2sz424 = ptrtoint ptr %s2sz424_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz424)
  store i32 20, ptr %v0, align 4
  %v736 = getelementptr i8, ptr %p1, i64 140
  %s2sz425_p = getelementptr i32, ptr null, i32 1
  %s2sz425 = ptrtoint ptr %s2sz425_p to i64
  call void @s2_record(i32 1, ptr %v736, i64 %s2sz425)
  store i32 1, ptr %v736, align 4
  %v749 = getelementptr i8, ptr %p1, i64 136
  %switch.selectcmp = icmp eq i8 %p0, 102
  %switch.select = select i1 %switch.selectcmp, i32 2, i32 3
  %switch.selectcmp79 = icmp eq i8 %p0, 116
  %switch.select80 = select i1 %switch.selectcmp79, i32 1, i32 %switch.select
  %s2sz426_p = getelementptr i32, ptr null, i32 1
  %s2sz426 = ptrtoint ptr %s2sz426_p to i64
  call void @s2_record(i32 1, ptr %v749, i64 %s2sz426)
  store i32 %switch.select80, ptr %v749, align 4
  %v752 = getelementptr i8, ptr %p1, i64 168
  %s2sz427_p = getelementptr i32, ptr null, i32 1
  %s2sz427 = ptrtoint ptr %s2sz427_p to i64
  call void @s2_record(i32 0, ptr %v752, i64 %s2sz427)
  %v753 = load i32, ptr %v752, align 4
  br label %common.ret

b312:                                             ; preds = %b297
  %v755 = getelementptr i8, ptr %p1, i64 48
  %s2sz428_p = getelementptr i64, ptr null, i32 1
  %s2sz428 = ptrtoint ptr %s2sz428_p to i64
  call void @s2_record(i32 0, ptr %v755, i64 %s2sz428)
  %v756 = load i64, ptr %v755, align 8
  %v0.i50 = getelementptr i8, ptr %p1, i64 168
  %s2sz429_p = getelementptr i32, ptr null, i32 1
  %s2sz429 = ptrtoint ptr %s2sz429_p to i64
  call void @s2_record(i32 1, ptr %v0.i50, i64 %s2sz429)
  store i32 1, ptr %v0.i50, align 8
  %v2.i51 = getelementptr i8, ptr %p1, i64 176
  %s2sz430_p = getelementptr i64, ptr null, i32 1
  %s2sz430 = ptrtoint ptr %s2sz430_p to i64
  call void @s2_record(i32 1, ptr %v2.i51, i64 %s2sz430)
  store i64 %v756, ptr %v2.i51, align 8
  br label %common.ret
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write, target_mem: none)
define i32 @liza_json.feed_mut(ptr %p0, { ptr, i32 } %p1) local_unnamed_addr #5 {
b0:
  %v0 = getelementptr i8, ptr %p0, i64 168
  %s2sz431_p = getelementptr i32, ptr null, i32 1
  %s2sz431 = ptrtoint ptr %s2sz431_p to i64
  call void @s2_record(i32 0, ptr %v0, i64 %s2sz431)
  %v1 = load i32, ptr %v0, align 4
  %v3.not = icmp eq i32 %v1, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v3.not, label %b4.preheader, label %common.ret

b4.preheader:                                     ; preds = %b0
  %v8 = extractvalue { ptr, i32 } %p1, 1
  %v914.not = icmp eq i32 %v8, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v914.not, label %common.ret, label %v10_ok.lr.ph

v10_ok.lr.ph:                                     ; preds = %b4.preheader
  %v10_base = extractvalue { ptr, i32 } %p1, 0
  %v42 = getelementptr i8, ptr %p0, i64 48
  %wide.trip.count = zext i32 %v8 to i64
  br label %v10_ok

common.ret:                                       ; preds = %v46_ok, %b13, %b9, %b4.preheader, %b0
  %common.ret.op = phi i32 [ %v1, %b0 ], [ 0, %b4.preheader ], [ %., %b9 ], [ 0, %v46_ok ], [ %v37, %b13 ]
  ret i32 %common.ret.op

v10_ok:                                           ; preds = %v10_ok.lr.ph, %v46_ok
  %indvars.iv = phi i64 [ 0, %v10_ok.lr.ph ], [ %indvars.iv.next, %v46_ok ]
  %v10_ptr = getelementptr i8, ptr %v10_base, i64 %indvars.iv
  %s2sz432_p = getelementptr i8, ptr null, i32 1
  %s2sz432 = ptrtoint ptr %s2sz432_p to i64
  call void @s2_record(i32 0, ptr %v10_ptr, i64 %s2sz432)
  %v10 = load i8, ptr %v10_ptr, align 1
  %s2sz433_p = getelementptr %struct.Utf8StreamState, ptr null, i32 1
  %s2sz433 = ptrtoint ptr %s2sz433_p to i64
  call void @s2_record(i32 0, ptr %p0, i64 %s2sz433)
  %v13 = load %struct.Utf8StreamState, ptr %p0, align 8
  %v0.i = extractvalue %struct.Utf8StreamState %v13, 6
  %v2.not.i = icmp eq i32 %v0.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2.not.i, label %b3.i, label %liza_utf8_stream.feed_byte.exit

b3.i:                                             ; preds = %v10_ok
  %v3.i = extractvalue %struct.Utf8StreamState %v13, 0
  %v5.i = icmp eq i64 %v3.i, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v5.i, label %b4.i, label %b6.i

b4.i:                                             ; preds = %b3.i
  %v8.i = insertvalue %struct.Utf8StreamState %v13, i32 2, 6
  %v11.i = insertvalue %struct.Utf8StreamState %v8.i, i64 -1, 7
  br label %liza_utf8_stream.feed_byte.exit

b6.i:                                             ; preds = %b3.i
  %v12.i = extractvalue %struct.Utf8StreamState %v13, 3
  %v14.i = icmp eq i32 %v12.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v14.i, label %b7.i, label %b8.i

b7.i:                                             ; preds = %b6.i
  %v17.i = insertvalue %struct.Utf8StreamState %v13, i64 %v3.i, 2
  %v19.i = icmp sgt i8 %v10, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v19.i, label %b9.i, label %b10.i

b8.i:                                             ; preds = %b6.i
  %v100.i = extractvalue %struct.Utf8StreamState %v13, 4
  %v101.i = icmp ult i8 %v10, %v100.i
  %v103.i = extractvalue %struct.Utf8StreamState %v13, 5
  %v104.i = icmp ugt i8 %v10, %v103.i
  %v105.i = select i1 %v101.i, i1 true, i1 %v104.i
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v105.i, label %b48.i, label %v115_ok.i

b9.i:                                             ; preds = %b7.i
  %v20.i = extractvalue %struct.Utf8StreamState %v13, 1
  %v22.i = icmp eq i64 %v20.i, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v22.i, label %b11.i, label %v32_ok.i

b10.i:                                            ; preds = %b7.i
  %v36.i = insertvalue %struct.Utf8StreamState %v17.i, i8 -128, 4
  %v39.i = insertvalue %struct.Utf8StreamState %v36.i, i8 -65, 5
  %0 = add nsw i8 %v10, 62
  %v45.i = icmp ult i8 %0, 30
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v45.i, label %b17.i, label %b18.i

b11.i:                                            ; preds = %b9.i
  %v25.i = insertvalue %struct.Utf8StreamState %v17.i, i32 2, 6
  %v28.i = insertvalue %struct.Utf8StreamState %v25.i, i64 %v3.i, 7
  br label %liza_utf8_stream.feed_byte.exit

v32_ok.i:                                         ; preds = %b9.i
  %v32.i = add nuw i64 %v20.i, 1
  %v33.i = insertvalue %struct.Utf8StreamState %v17.i, i64 %v32.i, 1
  br label %b57.i

b17.i:                                            ; preds = %b10.i
  %v48.i = insertvalue %struct.Utf8StreamState %v39.i, i32 1, 3
  br label %b57.i

b18.i:                                            ; preds = %b10.i
  %1 = and i8 %v10, -16
  %v54.i = icmp eq i8 %1, -32
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v54.i, label %b22.i, label %b23.i

b22.i:                                            ; preds = %b18.i
  %v57.i = insertvalue %struct.Utf8StreamState %v39.i, i32 2, 3
  %v59.i = icmp eq i8 %v10, -32
  %v62.i = insertvalue %struct.Utf8StreamState %v57.i, i8 -96, 4
  %spec.select.i = select i1 %v59.i, %struct.Utf8StreamState %v62.i, %struct.Utf8StreamState %v57.i
  %v65.i = icmp eq i8 %v10, -19
  %v68.i = insertvalue %struct.Utf8StreamState %spec.select.i, i8 -97, 5
  %spec.select2.i = select i1 %v65.i, %struct.Utf8StreamState %v68.i, %struct.Utf8StreamState %spec.select.i
  br label %b57.i

b23.i:                                            ; preds = %b18.i
  %2 = add nsw i8 %v10, 16
  %v75.i = icmp ult i8 %2, 5
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v75.i, label %b33.i, label %b34.i

b33.i:                                            ; preds = %b23.i
  %v78.i = insertvalue %struct.Utf8StreamState %v39.i, i32 3, 3
  %v80.i = icmp eq i8 %v10, -16
  %v83.i = insertvalue %struct.Utf8StreamState %v78.i, i8 -112, 4
  %spec.select1.i = select i1 %v80.i, %struct.Utf8StreamState %v83.i, %struct.Utf8StreamState %v78.i
  %v86.i = icmp eq i8 %v10, -12
  %v89.i = insertvalue %struct.Utf8StreamState %spec.select1.i, i8 -113, 5
  %spec.select3.i = select i1 %v86.i, %struct.Utf8StreamState %v89.i, %struct.Utf8StreamState %spec.select1.i
  br label %b57.i

b34.i:                                            ; preds = %b23.i
  %v93.i = insertvalue %struct.Utf8StreamState %v39.i, i32 1, 6
  %v96.i = insertvalue %struct.Utf8StreamState %v93.i, i64 %v3.i, 7
  br label %liza_utf8_stream.feed_byte.exit

b48.i:                                            ; preds = %b8.i
  %v108.i = insertvalue %struct.Utf8StreamState %v13, i32 1, 6
  %v110.i = extractvalue %struct.Utf8StreamState %v13, 2
  %v111.i = insertvalue %struct.Utf8StreamState %v108.i, i64 %v110.i, 7
  br label %liza_utf8_stream.feed_byte.exit

v115_ok.i:                                        ; preds = %b8.i
  %v115.i = add i32 %v12.i, -1
  %v116.i = insertvalue %struct.Utf8StreamState %v13, i32 %v115.i, 3
  %v119.i = insertvalue %struct.Utf8StreamState %v116.i, i8 -128, 4
  %v122.i = insertvalue %struct.Utf8StreamState %v119.i, i8 -65, 5
  %v125.i = icmp eq i32 %v115.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v125.i, label %b51.i, label %b57.i

b51.i:                                            ; preds = %v115_ok.i
  %v126.i = extractvalue %struct.Utf8StreamState %v13, 1
  %v128.i = icmp eq i64 %v126.i, -1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v128.i, label %b53.i, label %v138_ok.i

b53.i:                                            ; preds = %b51.i
  %v131.i = insertvalue %struct.Utf8StreamState %v122.i, i32 2, 6
  %v134.i = insertvalue %struct.Utf8StreamState %v131.i, i64 %v3.i, 7
  br label %liza_utf8_stream.feed_byte.exit

v138_ok.i:                                        ; preds = %b51.i
  %v138.i = add nuw i64 %v126.i, 1
  %v139.i = insertvalue %struct.Utf8StreamState %v122.i, i64 %v138.i, 1
  br label %b57.i

b57.i:                                            ; preds = %v138_ok.i, %v115_ok.i, %b33.i, %b22.i, %b17.i, %v32_ok.i
  %v141.i = phi %struct.Utf8StreamState [ %v139.i, %v138_ok.i ], [ %v33.i, %v32_ok.i ], [ %v48.i, %b17.i ], [ %spec.select3.i, %b33.i ], [ %v122.i, %v115_ok.i ], [ %spec.select2.i, %b22.i ]
  %v143.i = extractvalue %struct.Utf8StreamState %v141.i, 0
  call void @s2_record(i32 3, ptr null, i64 0)
  %v145_pair.i = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v143.i, i64 1)
  %v145_overflow.i = extractvalue { i64, i1 } %v145_pair.i, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v145_overflow.i, label %v145_trap.i, label %v145_ok.i

v145_trap.i:                                      ; preds = %b57.i
  tail call void @llvm.trap()
  unreachable

v145_ok.i:                                        ; preds = %b57.i
  %v145.i = extractvalue { i64, i1 } %v145_pair.i, 0
  %v146.i = insertvalue %struct.Utf8StreamState %v141.i, i64 %v145.i, 0
  br label %liza_utf8_stream.feed_byte.exit

liza_utf8_stream.feed_byte.exit:                  ; preds = %v10_ok, %b4.i, %b11.i, %b34.i, %b48.i, %b53.i, %v145_ok.i
  %common.ret.op.i = phi %struct.Utf8StreamState [ %v146.i, %v145_ok.i ], [ %v11.i, %b4.i ], [ %v28.i, %b11.i ], [ %v96.i, %b34.i ], [ %v111.i, %b48.i ], [ %v134.i, %b53.i ], [ %v13, %v10_ok ]
  %s2sz434_p = getelementptr %struct.Utf8StreamState, ptr null, i32 1
  %s2sz434 = ptrtoint ptr %s2sz434_p to i64
  call void @s2_record(i32 1, ptr %p0, i64 %s2sz434)
  store %struct.Utf8StreamState %common.ret.op.i, ptr %p0, align 8
  %v0.i1 = extractvalue %struct.Utf8StreamState %common.ret.op.i, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0.i1, label %liza_utf8_stream.status.exit [
    i32 1, label %b1.i
    i32 2, label %b4.i2
  ]

b1.i:                                             ; preds = %liza_utf8_stream.feed_byte.exit
  %v4.i = extractvalue %struct.Utf8StreamState %common.ret.op.i, 7
  %v5.i6 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i, 1
  %v6.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5.i6, 1
  br label %liza_utf8_stream.status.exit

b4.i2:                                            ; preds = %liza_utf8_stream.feed_byte.exit
  %v11.i3 = extractvalue %struct.Utf8StreamState %common.ret.op.i, 7
  %v12.i4 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i3, 1
  %v13.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12.i4, 1
  br label %liza_utf8_stream.status.exit

liza_utf8_stream.status.exit:                     ; preds = %liza_utf8_stream.feed_byte.exit, %b1.i, %b4.i2
  %common.ret.op.i5 = phi %variant.3 [ %v6.i, %b1.i ], [ %v13.i, %b4.i2 ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %liza_utf8_stream.feed_byte.exit ]
  %v19 = extractvalue %variant.3 %common.ret.op.i5, 0
  %3 = icmp eq i32 %v19, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %3, label %b13, label %b9

b9:                                               ; preds = %liza_utf8_stream.status.exit
  %v20 = extractvalue %variant.3 %common.ret.op.i5, 1
  %v21 = extractvalue %struct.Utf8StreamError %v20, 0
  %v22 = extractvalue %variant.0 %v21, 0
  %4 = icmp eq i32 %v22, 0
  %. = select i1 %4, i32 5, i32 8
  %v29 = extractvalue %struct.Utf8StreamError %v20, 1
  %s2sz435_p = getelementptr i32, ptr null, i32 1
  %s2sz435 = ptrtoint ptr %s2sz435_p to i64
  call void @s2_record(i32 1, ptr %v0, i64 %s2sz435)
  store i32 %., ptr %v0, align 8
  %v2.i9 = getelementptr i8, ptr %p0, i64 176
  %s2sz436_p = getelementptr i64, ptr null, i32 1
  %s2sz436 = ptrtoint ptr %s2sz436_p to i64
  call void @s2_record(i32 1, ptr %v2.i9, i64 %s2sz436)
  store i64 %v29, ptr %v2.i9, align 8
  br label %common.ret

b13:                                              ; preds = %liza_utf8_stream.status.exit
  %v34 = tail call i32 @liza___liza_json_mut_step(i8 %v10, ptr nonnull %p0)
  %s2sz437_p = getelementptr i32, ptr null, i32 1
  %s2sz437 = ptrtoint ptr %s2sz437_p to i64
  call void @s2_record(i32 0, ptr %v0, i64 %s2sz437)
  %v37 = load i32, ptr %v0, align 8
  %v39.not = icmp eq i32 %v37, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v39.not, label %b16, label %common.ret

b16:                                              ; preds = %b13
  %s2sz438_p = getelementptr i64, ptr null, i32 1
  %s2sz438 = ptrtoint ptr %s2sz438_p to i64
  call void @s2_record(i32 0, ptr %v42, i64 %s2sz438)
  %v44 = load i64, ptr %v42, align 8
  call void @s2_record(i32 3, ptr null, i64 0)
  %v46_pair = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v44, i64 1)
  %v46_overflow = extractvalue { i64, i1 } %v46_pair, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v46_overflow, label %v46_trap, label %v46_ok

v46_trap:                                         ; preds = %b16
  tail call void @llvm.trap()
  unreachable

v46_ok:                                           ; preds = %b16
  %v46 = extractvalue { i64, i1 } %v46_pair, 0
  %s2sz439_p = getelementptr i64, ptr null, i32 1
  %s2sz439 = ptrtoint ptr %s2sz439_p to i64
  call void @s2_record(i32 1, ptr %v42, i64 %s2sz439)
  store i64 %v46, ptr %v42, align 8
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %exitcond.not, label %common.ret, label %v10_ok
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define void @liza___liza_owned___liza_json_done(ptr nofree sret(%struct.JsonState) %return_storage, ptr nofree   %p0) local_unnamed_addr #2 {
b0:
  %v22_scratch = alloca [64 x i8], align 16
  %v27_scratch = alloca [64 x i8], align 16
  %v14_storage = alloca [64 x i8], align 1
  %v9_storage = alloca [64 x i8], align 1
  %v0_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 120
  %s2sz440_p = getelementptr i32, ptr null, i32 1
  %s2sz440 = ptrtoint ptr %s2sz440_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr, i64 %s2sz440)
  %v0 = load i32, ptr %v0_ptr, align 8
  %v2 = icmp eq i32 %v0, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2, label %b1, label %b2

b1:                                               ; preds = %b0
  %v3_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  %s2sz441_p = getelementptr i1, ptr null, i32 1
  %s2sz441 = ptrtoint ptr %s2sz441_p to i64
  call void @s2_record(i32 1, ptr %v3_ptr, i64 %s2sz441)
  store i1 true, ptr %v3_ptr, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v8_pair = add i32 %v0, -1
  %v9_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 56
  %s2sz442_p = getelementptr i8, ptr null, i32 1
  %s2sz442 = ptrtoint ptr %s2sz442_p to i64
  call void @s2_record(i32 0, ptr %v9_ptr, i64 %s2sz442)
  %v9.unpack = load i8, ptr %v9_ptr, align 8
  %v9.elt257 = getelementptr inbounds nuw i8, ptr %return_storage, i64 57
  %s2sz443_p = getelementptr i8, ptr null, i32 1
  %s2sz443 = ptrtoint ptr %s2sz443_p to i64
  call void @s2_record(i32 0, ptr %v9.elt257, i64 %s2sz443)
  %v9.unpack258 = load i8, ptr %v9.elt257, align 1
  %v9.elt259 = getelementptr inbounds nuw i8, ptr %return_storage, i64 58
  %s2sz444_p = getelementptr i8, ptr null, i32 1
  %s2sz444 = ptrtoint ptr %s2sz444_p to i64
  call void @s2_record(i32 0, ptr %v9.elt259, i64 %s2sz444)
  %v9.unpack260 = load i8, ptr %v9.elt259, align 2
  %v9.elt261 = getelementptr inbounds nuw i8, ptr %return_storage, i64 59
  %s2sz445_p = getelementptr i8, ptr null, i32 1
  %s2sz445 = ptrtoint ptr %s2sz445_p to i64
  call void @s2_record(i32 0, ptr %v9.elt261, i64 %s2sz445)
  %v9.unpack262 = load i8, ptr %v9.elt261, align 1
  %v9.elt263 = getelementptr inbounds nuw i8, ptr %return_storage, i64 60
  %s2sz446_p = getelementptr i8, ptr null, i32 1
  %s2sz446 = ptrtoint ptr %s2sz446_p to i64
  call void @s2_record(i32 0, ptr %v9.elt263, i64 %s2sz446)
  %v9.unpack264 = load i8, ptr %v9.elt263, align 4
  %v9.elt265 = getelementptr inbounds nuw i8, ptr %return_storage, i64 61
  %s2sz447_p = getelementptr i8, ptr null, i32 1
  %s2sz447 = ptrtoint ptr %s2sz447_p to i64
  call void @s2_record(i32 0, ptr %v9.elt265, i64 %s2sz447)
  %v9.unpack266 = load i8, ptr %v9.elt265, align 1
  %v9.elt267 = getelementptr inbounds nuw i8, ptr %return_storage, i64 62
  %s2sz448_p = getelementptr i8, ptr null, i32 1
  %s2sz448 = ptrtoint ptr %s2sz448_p to i64
  call void @s2_record(i32 0, ptr %v9.elt267, i64 %s2sz448)
  %v9.unpack268 = load i8, ptr %v9.elt267, align 2
  %v9.elt269 = getelementptr inbounds nuw i8, ptr %return_storage, i64 63
  %s2sz449_p = getelementptr i8, ptr null, i32 1
  %s2sz449 = ptrtoint ptr %s2sz449_p to i64
  call void @s2_record(i32 0, ptr %v9.elt269, i64 %s2sz449)
  %v9.unpack270 = load i8, ptr %v9.elt269, align 1
  %v9.elt271 = getelementptr inbounds nuw i8, ptr %return_storage, i64 64
  %s2sz450_p = getelementptr i8, ptr null, i32 1
  %s2sz450 = ptrtoint ptr %s2sz450_p to i64
  call void @s2_record(i32 0, ptr %v9.elt271, i64 %s2sz450)
  %v9.unpack272 = load i8, ptr %v9.elt271, align 8
  %v9.elt273 = getelementptr inbounds nuw i8, ptr %return_storage, i64 65
  %s2sz451_p = getelementptr i8, ptr null, i32 1
  %s2sz451 = ptrtoint ptr %s2sz451_p to i64
  call void @s2_record(i32 0, ptr %v9.elt273, i64 %s2sz451)
  %v9.unpack274 = load i8, ptr %v9.elt273, align 1
  %v9.elt275 = getelementptr inbounds nuw i8, ptr %return_storage, i64 66
  %s2sz452_p = getelementptr i8, ptr null, i32 1
  %s2sz452 = ptrtoint ptr %s2sz452_p to i64
  call void @s2_record(i32 0, ptr %v9.elt275, i64 %s2sz452)
  %v9.unpack276 = load i8, ptr %v9.elt275, align 2
  %v9.elt277 = getelementptr inbounds nuw i8, ptr %return_storage, i64 67
  %s2sz453_p = getelementptr i8, ptr null, i32 1
  %s2sz453 = ptrtoint ptr %s2sz453_p to i64
  call void @s2_record(i32 0, ptr %v9.elt277, i64 %s2sz453)
  %v9.unpack278 = load i8, ptr %v9.elt277, align 1
  %v9.elt279 = getelementptr inbounds nuw i8, ptr %return_storage, i64 68
  %s2sz454_p = getelementptr i8, ptr null, i32 1
  %s2sz454 = ptrtoint ptr %s2sz454_p to i64
  call void @s2_record(i32 0, ptr %v9.elt279, i64 %s2sz454)
  %v9.unpack280 = load i8, ptr %v9.elt279, align 4
  %v9.elt281 = getelementptr inbounds nuw i8, ptr %return_storage, i64 69
  %s2sz455_p = getelementptr i8, ptr null, i32 1
  %s2sz455 = ptrtoint ptr %s2sz455_p to i64
  call void @s2_record(i32 0, ptr %v9.elt281, i64 %s2sz455)
  %v9.unpack282 = load i8, ptr %v9.elt281, align 1
  %v9.elt283 = getelementptr inbounds nuw i8, ptr %return_storage, i64 70
  %s2sz456_p = getelementptr i8, ptr null, i32 1
  %s2sz456 = ptrtoint ptr %s2sz456_p to i64
  call void @s2_record(i32 0, ptr %v9.elt283, i64 %s2sz456)
  %v9.unpack284 = load i8, ptr %v9.elt283, align 2
  %v9.elt285 = getelementptr inbounds nuw i8, ptr %return_storage, i64 71
  %s2sz457_p = getelementptr i8, ptr null, i32 1
  %s2sz457 = ptrtoint ptr %s2sz457_p to i64
  call void @s2_record(i32 0, ptr %v9.elt285, i64 %s2sz457)
  %v9.unpack286 = load i8, ptr %v9.elt285, align 1
  %v9.elt287 = getelementptr inbounds nuw i8, ptr %return_storage, i64 72
  %s2sz458_p = getelementptr i8, ptr null, i32 1
  %s2sz458 = ptrtoint ptr %s2sz458_p to i64
  call void @s2_record(i32 0, ptr %v9.elt287, i64 %s2sz458)
  %v9.unpack288 = load i8, ptr %v9.elt287, align 8
  %v9.elt289 = getelementptr inbounds nuw i8, ptr %return_storage, i64 73
  %s2sz459_p = getelementptr i8, ptr null, i32 1
  %s2sz459 = ptrtoint ptr %s2sz459_p to i64
  call void @s2_record(i32 0, ptr %v9.elt289, i64 %s2sz459)
  %v9.unpack290 = load i8, ptr %v9.elt289, align 1
  %v9.elt291 = getelementptr inbounds nuw i8, ptr %return_storage, i64 74
  %s2sz460_p = getelementptr i8, ptr null, i32 1
  %s2sz460 = ptrtoint ptr %s2sz460_p to i64
  call void @s2_record(i32 0, ptr %v9.elt291, i64 %s2sz460)
  %v9.unpack292 = load i8, ptr %v9.elt291, align 2
  %v9.elt293 = getelementptr inbounds nuw i8, ptr %return_storage, i64 75
  %s2sz461_p = getelementptr i8, ptr null, i32 1
  %s2sz461 = ptrtoint ptr %s2sz461_p to i64
  call void @s2_record(i32 0, ptr %v9.elt293, i64 %s2sz461)
  %v9.unpack294 = load i8, ptr %v9.elt293, align 1
  %v9.elt295 = getelementptr inbounds nuw i8, ptr %return_storage, i64 76
  %s2sz462_p = getelementptr i8, ptr null, i32 1
  %s2sz462 = ptrtoint ptr %s2sz462_p to i64
  call void @s2_record(i32 0, ptr %v9.elt295, i64 %s2sz462)
  %v9.unpack296 = load i8, ptr %v9.elt295, align 4
  %v9.elt297 = getelementptr inbounds nuw i8, ptr %return_storage, i64 77
  %s2sz463_p = getelementptr i8, ptr null, i32 1
  %s2sz463 = ptrtoint ptr %s2sz463_p to i64
  call void @s2_record(i32 0, ptr %v9.elt297, i64 %s2sz463)
  %v9.unpack298 = load i8, ptr %v9.elt297, align 1
  %v9.elt299 = getelementptr inbounds nuw i8, ptr %return_storage, i64 78
  %s2sz464_p = getelementptr i8, ptr null, i32 1
  %s2sz464 = ptrtoint ptr %s2sz464_p to i64
  call void @s2_record(i32 0, ptr %v9.elt299, i64 %s2sz464)
  %v9.unpack300 = load i8, ptr %v9.elt299, align 2
  %v9.elt301 = getelementptr inbounds nuw i8, ptr %return_storage, i64 79
  %s2sz465_p = getelementptr i8, ptr null, i32 1
  %s2sz465 = ptrtoint ptr %s2sz465_p to i64
  call void @s2_record(i32 0, ptr %v9.elt301, i64 %s2sz465)
  %v9.unpack302 = load i8, ptr %v9.elt301, align 1
  %v9.elt303 = getelementptr inbounds nuw i8, ptr %return_storage, i64 80
  %s2sz466_p = getelementptr i8, ptr null, i32 1
  %s2sz466 = ptrtoint ptr %s2sz466_p to i64
  call void @s2_record(i32 0, ptr %v9.elt303, i64 %s2sz466)
  %v9.unpack304 = load i8, ptr %v9.elt303, align 8
  %v9.elt305 = getelementptr inbounds nuw i8, ptr %return_storage, i64 81
  %s2sz467_p = getelementptr i8, ptr null, i32 1
  %s2sz467 = ptrtoint ptr %s2sz467_p to i64
  call void @s2_record(i32 0, ptr %v9.elt305, i64 %s2sz467)
  %v9.unpack306 = load i8, ptr %v9.elt305, align 1
  %v9.elt307 = getelementptr inbounds nuw i8, ptr %return_storage, i64 82
  %s2sz468_p = getelementptr i8, ptr null, i32 1
  %s2sz468 = ptrtoint ptr %s2sz468_p to i64
  call void @s2_record(i32 0, ptr %v9.elt307, i64 %s2sz468)
  %v9.unpack308 = load i8, ptr %v9.elt307, align 2
  %v9.elt309 = getelementptr inbounds nuw i8, ptr %return_storage, i64 83
  %s2sz469_p = getelementptr i8, ptr null, i32 1
  %s2sz469 = ptrtoint ptr %s2sz469_p to i64
  call void @s2_record(i32 0, ptr %v9.elt309, i64 %s2sz469)
  %v9.unpack310 = load i8, ptr %v9.elt309, align 1
  %v9.elt311 = getelementptr inbounds nuw i8, ptr %return_storage, i64 84
  %s2sz470_p = getelementptr i8, ptr null, i32 1
  %s2sz470 = ptrtoint ptr %s2sz470_p to i64
  call void @s2_record(i32 0, ptr %v9.elt311, i64 %s2sz470)
  %v9.unpack312 = load i8, ptr %v9.elt311, align 4
  %v9.elt313 = getelementptr inbounds nuw i8, ptr %return_storage, i64 85
  %s2sz471_p = getelementptr i8, ptr null, i32 1
  %s2sz471 = ptrtoint ptr %s2sz471_p to i64
  call void @s2_record(i32 0, ptr %v9.elt313, i64 %s2sz471)
  %v9.unpack314 = load i8, ptr %v9.elt313, align 1
  %v9.elt315 = getelementptr inbounds nuw i8, ptr %return_storage, i64 86
  %s2sz472_p = getelementptr i8, ptr null, i32 1
  %s2sz472 = ptrtoint ptr %s2sz472_p to i64
  call void @s2_record(i32 0, ptr %v9.elt315, i64 %s2sz472)
  %v9.unpack316 = load i8, ptr %v9.elt315, align 2
  %v9.elt317 = getelementptr inbounds nuw i8, ptr %return_storage, i64 87
  %s2sz473_p = getelementptr i8, ptr null, i32 1
  %s2sz473 = ptrtoint ptr %s2sz473_p to i64
  call void @s2_record(i32 0, ptr %v9.elt317, i64 %s2sz473)
  %v9.unpack318 = load i8, ptr %v9.elt317, align 1
  %v9.elt319 = getelementptr inbounds nuw i8, ptr %return_storage, i64 88
  %s2sz474_p = getelementptr i8, ptr null, i32 1
  %s2sz474 = ptrtoint ptr %s2sz474_p to i64
  call void @s2_record(i32 0, ptr %v9.elt319, i64 %s2sz474)
  %v9.unpack320 = load i8, ptr %v9.elt319, align 8
  %v9.elt321 = getelementptr inbounds nuw i8, ptr %return_storage, i64 89
  %s2sz475_p = getelementptr i8, ptr null, i32 1
  %s2sz475 = ptrtoint ptr %s2sz475_p to i64
  call void @s2_record(i32 0, ptr %v9.elt321, i64 %s2sz475)
  %v9.unpack322 = load i8, ptr %v9.elt321, align 1
  %v9.elt323 = getelementptr inbounds nuw i8, ptr %return_storage, i64 90
  %s2sz476_p = getelementptr i8, ptr null, i32 1
  %s2sz476 = ptrtoint ptr %s2sz476_p to i64
  call void @s2_record(i32 0, ptr %v9.elt323, i64 %s2sz476)
  %v9.unpack324 = load i8, ptr %v9.elt323, align 2
  %v9.elt325 = getelementptr inbounds nuw i8, ptr %return_storage, i64 91
  %s2sz477_p = getelementptr i8, ptr null, i32 1
  %s2sz477 = ptrtoint ptr %s2sz477_p to i64
  call void @s2_record(i32 0, ptr %v9.elt325, i64 %s2sz477)
  %v9.unpack326 = load i8, ptr %v9.elt325, align 1
  %v9.elt327 = getelementptr inbounds nuw i8, ptr %return_storage, i64 92
  %s2sz478_p = getelementptr i8, ptr null, i32 1
  %s2sz478 = ptrtoint ptr %s2sz478_p to i64
  call void @s2_record(i32 0, ptr %v9.elt327, i64 %s2sz478)
  %v9.unpack328 = load i8, ptr %v9.elt327, align 4
  %v9.elt329 = getelementptr inbounds nuw i8, ptr %return_storage, i64 93
  %s2sz479_p = getelementptr i8, ptr null, i32 1
  %s2sz479 = ptrtoint ptr %s2sz479_p to i64
  call void @s2_record(i32 0, ptr %v9.elt329, i64 %s2sz479)
  %v9.unpack330 = load i8, ptr %v9.elt329, align 1
  %v9.elt331 = getelementptr inbounds nuw i8, ptr %return_storage, i64 94
  %s2sz480_p = getelementptr i8, ptr null, i32 1
  %s2sz480 = ptrtoint ptr %s2sz480_p to i64
  call void @s2_record(i32 0, ptr %v9.elt331, i64 %s2sz480)
  %v9.unpack332 = load i8, ptr %v9.elt331, align 2
  %v9.elt333 = getelementptr inbounds nuw i8, ptr %return_storage, i64 95
  %s2sz481_p = getelementptr i8, ptr null, i32 1
  %s2sz481 = ptrtoint ptr %s2sz481_p to i64
  call void @s2_record(i32 0, ptr %v9.elt333, i64 %s2sz481)
  %v9.unpack334 = load i8, ptr %v9.elt333, align 1
  %v9.elt335 = getelementptr inbounds nuw i8, ptr %return_storage, i64 96
  %s2sz482_p = getelementptr i8, ptr null, i32 1
  %s2sz482 = ptrtoint ptr %s2sz482_p to i64
  call void @s2_record(i32 0, ptr %v9.elt335, i64 %s2sz482)
  %v9.unpack336 = load i8, ptr %v9.elt335, align 8
  %v9.elt337 = getelementptr inbounds nuw i8, ptr %return_storage, i64 97
  %s2sz483_p = getelementptr i8, ptr null, i32 1
  %s2sz483 = ptrtoint ptr %s2sz483_p to i64
  call void @s2_record(i32 0, ptr %v9.elt337, i64 %s2sz483)
  %v9.unpack338 = load i8, ptr %v9.elt337, align 1
  %v9.elt339 = getelementptr inbounds nuw i8, ptr %return_storage, i64 98
  %s2sz484_p = getelementptr i8, ptr null, i32 1
  %s2sz484 = ptrtoint ptr %s2sz484_p to i64
  call void @s2_record(i32 0, ptr %v9.elt339, i64 %s2sz484)
  %v9.unpack340 = load i8, ptr %v9.elt339, align 2
  %v9.elt341 = getelementptr inbounds nuw i8, ptr %return_storage, i64 99
  %s2sz485_p = getelementptr i8, ptr null, i32 1
  %s2sz485 = ptrtoint ptr %s2sz485_p to i64
  call void @s2_record(i32 0, ptr %v9.elt341, i64 %s2sz485)
  %v9.unpack342 = load i8, ptr %v9.elt341, align 1
  %v9.elt343 = getelementptr inbounds nuw i8, ptr %return_storage, i64 100
  %s2sz486_p = getelementptr i8, ptr null, i32 1
  %s2sz486 = ptrtoint ptr %s2sz486_p to i64
  call void @s2_record(i32 0, ptr %v9.elt343, i64 %s2sz486)
  %v9.unpack344 = load i8, ptr %v9.elt343, align 4
  %v9.elt345 = getelementptr inbounds nuw i8, ptr %return_storage, i64 101
  %s2sz487_p = getelementptr i8, ptr null, i32 1
  %s2sz487 = ptrtoint ptr %s2sz487_p to i64
  call void @s2_record(i32 0, ptr %v9.elt345, i64 %s2sz487)
  %v9.unpack346 = load i8, ptr %v9.elt345, align 1
  %v9.elt347 = getelementptr inbounds nuw i8, ptr %return_storage, i64 102
  %s2sz488_p = getelementptr i8, ptr null, i32 1
  %s2sz488 = ptrtoint ptr %s2sz488_p to i64
  call void @s2_record(i32 0, ptr %v9.elt347, i64 %s2sz488)
  %v9.unpack348 = load i8, ptr %v9.elt347, align 2
  %v9.elt349 = getelementptr inbounds nuw i8, ptr %return_storage, i64 103
  %s2sz489_p = getelementptr i8, ptr null, i32 1
  %s2sz489 = ptrtoint ptr %s2sz489_p to i64
  call void @s2_record(i32 0, ptr %v9.elt349, i64 %s2sz489)
  %v9.unpack350 = load i8, ptr %v9.elt349, align 1
  %v9.elt351 = getelementptr inbounds nuw i8, ptr %return_storage, i64 104
  %s2sz490_p = getelementptr i8, ptr null, i32 1
  %s2sz490 = ptrtoint ptr %s2sz490_p to i64
  call void @s2_record(i32 0, ptr %v9.elt351, i64 %s2sz490)
  %v9.unpack352 = load i8, ptr %v9.elt351, align 8
  %v9.elt353 = getelementptr inbounds nuw i8, ptr %return_storage, i64 105
  %s2sz491_p = getelementptr i8, ptr null, i32 1
  %s2sz491 = ptrtoint ptr %s2sz491_p to i64
  call void @s2_record(i32 0, ptr %v9.elt353, i64 %s2sz491)
  %v9.unpack354 = load i8, ptr %v9.elt353, align 1
  %v9.elt355 = getelementptr inbounds nuw i8, ptr %return_storage, i64 106
  %s2sz492_p = getelementptr i8, ptr null, i32 1
  %s2sz492 = ptrtoint ptr %s2sz492_p to i64
  call void @s2_record(i32 0, ptr %v9.elt355, i64 %s2sz492)
  %v9.unpack356 = load i8, ptr %v9.elt355, align 2
  %v9.elt357 = getelementptr inbounds nuw i8, ptr %return_storage, i64 107
  %s2sz493_p = getelementptr i8, ptr null, i32 1
  %s2sz493 = ptrtoint ptr %s2sz493_p to i64
  call void @s2_record(i32 0, ptr %v9.elt357, i64 %s2sz493)
  %v9.unpack358 = load i8, ptr %v9.elt357, align 1
  %v9.elt359 = getelementptr inbounds nuw i8, ptr %return_storage, i64 108
  %s2sz494_p = getelementptr i8, ptr null, i32 1
  %s2sz494 = ptrtoint ptr %s2sz494_p to i64
  call void @s2_record(i32 0, ptr %v9.elt359, i64 %s2sz494)
  %v9.unpack360 = load i8, ptr %v9.elt359, align 4
  %v9.elt361 = getelementptr inbounds nuw i8, ptr %return_storage, i64 109
  %s2sz495_p = getelementptr i8, ptr null, i32 1
  %s2sz495 = ptrtoint ptr %s2sz495_p to i64
  call void @s2_record(i32 0, ptr %v9.elt361, i64 %s2sz495)
  %v9.unpack362 = load i8, ptr %v9.elt361, align 1
  %v9.elt363 = getelementptr inbounds nuw i8, ptr %return_storage, i64 110
  %s2sz496_p = getelementptr i8, ptr null, i32 1
  %s2sz496 = ptrtoint ptr %s2sz496_p to i64
  call void @s2_record(i32 0, ptr %v9.elt363, i64 %s2sz496)
  %v9.unpack364 = load i8, ptr %v9.elt363, align 2
  %v9.elt365 = getelementptr inbounds nuw i8, ptr %return_storage, i64 111
  %s2sz497_p = getelementptr i8, ptr null, i32 1
  %s2sz497 = ptrtoint ptr %s2sz497_p to i64
  call void @s2_record(i32 0, ptr %v9.elt365, i64 %s2sz497)
  %v9.unpack366 = load i8, ptr %v9.elt365, align 1
  %v9.elt367 = getelementptr inbounds nuw i8, ptr %return_storage, i64 112
  %s2sz498_p = getelementptr i8, ptr null, i32 1
  %s2sz498 = ptrtoint ptr %s2sz498_p to i64
  call void @s2_record(i32 0, ptr %v9.elt367, i64 %s2sz498)
  %v9.unpack368 = load i8, ptr %v9.elt367, align 8
  %v9.elt369 = getelementptr inbounds nuw i8, ptr %return_storage, i64 113
  %s2sz499_p = getelementptr i8, ptr null, i32 1
  %s2sz499 = ptrtoint ptr %s2sz499_p to i64
  call void @s2_record(i32 0, ptr %v9.elt369, i64 %s2sz499)
  %v9.unpack370 = load i8, ptr %v9.elt369, align 1
  %v9.elt371 = getelementptr inbounds nuw i8, ptr %return_storage, i64 114
  %s2sz500_p = getelementptr i8, ptr null, i32 1
  %s2sz500 = ptrtoint ptr %s2sz500_p to i64
  call void @s2_record(i32 0, ptr %v9.elt371, i64 %s2sz500)
  %v9.unpack372 = load i8, ptr %v9.elt371, align 2
  %v9.elt373 = getelementptr inbounds nuw i8, ptr %return_storage, i64 115
  %s2sz501_p = getelementptr i8, ptr null, i32 1
  %s2sz501 = ptrtoint ptr %s2sz501_p to i64
  call void @s2_record(i32 0, ptr %v9.elt373, i64 %s2sz501)
  %v9.unpack374 = load i8, ptr %v9.elt373, align 1
  %v9.elt375 = getelementptr inbounds nuw i8, ptr %return_storage, i64 116
  %s2sz502_p = getelementptr i8, ptr null, i32 1
  %s2sz502 = ptrtoint ptr %s2sz502_p to i64
  call void @s2_record(i32 0, ptr %v9.elt375, i64 %s2sz502)
  %v9.unpack376 = load i8, ptr %v9.elt375, align 4
  %v9.elt377 = getelementptr inbounds nuw i8, ptr %return_storage, i64 117
  %s2sz503_p = getelementptr i8, ptr null, i32 1
  %s2sz503 = ptrtoint ptr %s2sz503_p to i64
  call void @s2_record(i32 0, ptr %v9.elt377, i64 %s2sz503)
  %v9.unpack378 = load i8, ptr %v9.elt377, align 1
  %v9.elt379 = getelementptr inbounds nuw i8, ptr %return_storage, i64 118
  %s2sz504_p = getelementptr i8, ptr null, i32 1
  %s2sz504 = ptrtoint ptr %s2sz504_p to i64
  call void @s2_record(i32 0, ptr %v9.elt379, i64 %s2sz504)
  %v9.unpack380 = load i8, ptr %v9.elt379, align 2
  %v9.elt381 = getelementptr inbounds nuw i8, ptr %return_storage, i64 119
  %s2sz505_p = getelementptr i8, ptr null, i32 1
  %s2sz505 = ptrtoint ptr %s2sz505_p to i64
  call void @s2_record(i32 0, ptr %v9.elt381, i64 %s2sz505)
  %v9.unpack382 = load i8, ptr %v9.elt381, align 1
  %s2sz506_p = getelementptr i8, ptr null, i32 1
  %s2sz506 = ptrtoint ptr %s2sz506_p to i64
  call void @s2_record(i32 1, ptr %v9_storage, i64 %s2sz506)
  store i8 %v9.unpack, ptr %v9_storage, align 1
  %v9.fca.1.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 1
  %s2sz507_p = getelementptr i8, ptr null, i32 1
  %s2sz507 = ptrtoint ptr %s2sz507_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.1.gep, i64 %s2sz507)
  store i8 %v9.unpack258, ptr %v9.fca.1.gep, align 1
  %v9.fca.2.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 2
  %s2sz508_p = getelementptr i8, ptr null, i32 1
  %s2sz508 = ptrtoint ptr %s2sz508_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.2.gep, i64 %s2sz508)
  store i8 %v9.unpack260, ptr %v9.fca.2.gep, align 1
  %v9.fca.3.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 3
  %s2sz509_p = getelementptr i8, ptr null, i32 1
  %s2sz509 = ptrtoint ptr %s2sz509_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.3.gep, i64 %s2sz509)
  store i8 %v9.unpack262, ptr %v9.fca.3.gep, align 1
  %v9.fca.4.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 4
  %s2sz510_p = getelementptr i8, ptr null, i32 1
  %s2sz510 = ptrtoint ptr %s2sz510_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.4.gep, i64 %s2sz510)
  store i8 %v9.unpack264, ptr %v9.fca.4.gep, align 1
  %v9.fca.5.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 5
  %s2sz511_p = getelementptr i8, ptr null, i32 1
  %s2sz511 = ptrtoint ptr %s2sz511_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.5.gep, i64 %s2sz511)
  store i8 %v9.unpack266, ptr %v9.fca.5.gep, align 1
  %v9.fca.6.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 6
  %s2sz512_p = getelementptr i8, ptr null, i32 1
  %s2sz512 = ptrtoint ptr %s2sz512_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.6.gep, i64 %s2sz512)
  store i8 %v9.unpack268, ptr %v9.fca.6.gep, align 1
  %v9.fca.7.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 7
  %s2sz513_p = getelementptr i8, ptr null, i32 1
  %s2sz513 = ptrtoint ptr %s2sz513_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.7.gep, i64 %s2sz513)
  store i8 %v9.unpack270, ptr %v9.fca.7.gep, align 1
  %v9.fca.8.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 8
  %s2sz514_p = getelementptr i8, ptr null, i32 1
  %s2sz514 = ptrtoint ptr %s2sz514_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.8.gep, i64 %s2sz514)
  store i8 %v9.unpack272, ptr %v9.fca.8.gep, align 1
  %v9.fca.9.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 9
  %s2sz515_p = getelementptr i8, ptr null, i32 1
  %s2sz515 = ptrtoint ptr %s2sz515_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.9.gep, i64 %s2sz515)
  store i8 %v9.unpack274, ptr %v9.fca.9.gep, align 1
  %v9.fca.10.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 10
  %s2sz516_p = getelementptr i8, ptr null, i32 1
  %s2sz516 = ptrtoint ptr %s2sz516_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.10.gep, i64 %s2sz516)
  store i8 %v9.unpack276, ptr %v9.fca.10.gep, align 1
  %v9.fca.11.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 11
  %s2sz517_p = getelementptr i8, ptr null, i32 1
  %s2sz517 = ptrtoint ptr %s2sz517_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.11.gep, i64 %s2sz517)
  store i8 %v9.unpack278, ptr %v9.fca.11.gep, align 1
  %v9.fca.12.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 12
  %s2sz518_p = getelementptr i8, ptr null, i32 1
  %s2sz518 = ptrtoint ptr %s2sz518_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.12.gep, i64 %s2sz518)
  store i8 %v9.unpack280, ptr %v9.fca.12.gep, align 1
  %v9.fca.13.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 13
  %s2sz519_p = getelementptr i8, ptr null, i32 1
  %s2sz519 = ptrtoint ptr %s2sz519_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.13.gep, i64 %s2sz519)
  store i8 %v9.unpack282, ptr %v9.fca.13.gep, align 1
  %v9.fca.14.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 14
  %s2sz520_p = getelementptr i8, ptr null, i32 1
  %s2sz520 = ptrtoint ptr %s2sz520_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.14.gep, i64 %s2sz520)
  store i8 %v9.unpack284, ptr %v9.fca.14.gep, align 1
  %v9.fca.15.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 15
  %s2sz521_p = getelementptr i8, ptr null, i32 1
  %s2sz521 = ptrtoint ptr %s2sz521_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.15.gep, i64 %s2sz521)
  store i8 %v9.unpack286, ptr %v9.fca.15.gep, align 1
  %v9.fca.16.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 16
  %s2sz522_p = getelementptr i8, ptr null, i32 1
  %s2sz522 = ptrtoint ptr %s2sz522_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.16.gep, i64 %s2sz522)
  store i8 %v9.unpack288, ptr %v9.fca.16.gep, align 1
  %v9.fca.17.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 17
  %s2sz523_p = getelementptr i8, ptr null, i32 1
  %s2sz523 = ptrtoint ptr %s2sz523_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.17.gep, i64 %s2sz523)
  store i8 %v9.unpack290, ptr %v9.fca.17.gep, align 1
  %v9.fca.18.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 18
  %s2sz524_p = getelementptr i8, ptr null, i32 1
  %s2sz524 = ptrtoint ptr %s2sz524_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.18.gep, i64 %s2sz524)
  store i8 %v9.unpack292, ptr %v9.fca.18.gep, align 1
  %v9.fca.19.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 19
  %s2sz525_p = getelementptr i8, ptr null, i32 1
  %s2sz525 = ptrtoint ptr %s2sz525_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.19.gep, i64 %s2sz525)
  store i8 %v9.unpack294, ptr %v9.fca.19.gep, align 1
  %v9.fca.20.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 20
  %s2sz526_p = getelementptr i8, ptr null, i32 1
  %s2sz526 = ptrtoint ptr %s2sz526_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.20.gep, i64 %s2sz526)
  store i8 %v9.unpack296, ptr %v9.fca.20.gep, align 1
  %v9.fca.21.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 21
  %s2sz527_p = getelementptr i8, ptr null, i32 1
  %s2sz527 = ptrtoint ptr %s2sz527_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.21.gep, i64 %s2sz527)
  store i8 %v9.unpack298, ptr %v9.fca.21.gep, align 1
  %v9.fca.22.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 22
  %s2sz528_p = getelementptr i8, ptr null, i32 1
  %s2sz528 = ptrtoint ptr %s2sz528_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.22.gep, i64 %s2sz528)
  store i8 %v9.unpack300, ptr %v9.fca.22.gep, align 1
  %v9.fca.23.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 23
  %s2sz529_p = getelementptr i8, ptr null, i32 1
  %s2sz529 = ptrtoint ptr %s2sz529_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.23.gep, i64 %s2sz529)
  store i8 %v9.unpack302, ptr %v9.fca.23.gep, align 1
  %v9.fca.24.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 24
  %s2sz530_p = getelementptr i8, ptr null, i32 1
  %s2sz530 = ptrtoint ptr %s2sz530_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.24.gep, i64 %s2sz530)
  store i8 %v9.unpack304, ptr %v9.fca.24.gep, align 1
  %v9.fca.25.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 25
  %s2sz531_p = getelementptr i8, ptr null, i32 1
  %s2sz531 = ptrtoint ptr %s2sz531_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.25.gep, i64 %s2sz531)
  store i8 %v9.unpack306, ptr %v9.fca.25.gep, align 1
  %v9.fca.26.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 26
  %s2sz532_p = getelementptr i8, ptr null, i32 1
  %s2sz532 = ptrtoint ptr %s2sz532_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.26.gep, i64 %s2sz532)
  store i8 %v9.unpack308, ptr %v9.fca.26.gep, align 1
  %v9.fca.27.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 27
  %s2sz533_p = getelementptr i8, ptr null, i32 1
  %s2sz533 = ptrtoint ptr %s2sz533_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.27.gep, i64 %s2sz533)
  store i8 %v9.unpack310, ptr %v9.fca.27.gep, align 1
  %v9.fca.28.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 28
  %s2sz534_p = getelementptr i8, ptr null, i32 1
  %s2sz534 = ptrtoint ptr %s2sz534_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.28.gep, i64 %s2sz534)
  store i8 %v9.unpack312, ptr %v9.fca.28.gep, align 1
  %v9.fca.29.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 29
  %s2sz535_p = getelementptr i8, ptr null, i32 1
  %s2sz535 = ptrtoint ptr %s2sz535_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.29.gep, i64 %s2sz535)
  store i8 %v9.unpack314, ptr %v9.fca.29.gep, align 1
  %v9.fca.30.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 30
  %s2sz536_p = getelementptr i8, ptr null, i32 1
  %s2sz536 = ptrtoint ptr %s2sz536_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.30.gep, i64 %s2sz536)
  store i8 %v9.unpack316, ptr %v9.fca.30.gep, align 1
  %v9.fca.31.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 31
  %s2sz537_p = getelementptr i8, ptr null, i32 1
  %s2sz537 = ptrtoint ptr %s2sz537_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.31.gep, i64 %s2sz537)
  store i8 %v9.unpack318, ptr %v9.fca.31.gep, align 1
  %v9.fca.32.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 32
  %s2sz538_p = getelementptr i8, ptr null, i32 1
  %s2sz538 = ptrtoint ptr %s2sz538_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.32.gep, i64 %s2sz538)
  store i8 %v9.unpack320, ptr %v9.fca.32.gep, align 1
  %v9.fca.33.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 33
  %s2sz539_p = getelementptr i8, ptr null, i32 1
  %s2sz539 = ptrtoint ptr %s2sz539_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.33.gep, i64 %s2sz539)
  store i8 %v9.unpack322, ptr %v9.fca.33.gep, align 1
  %v9.fca.34.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 34
  %s2sz540_p = getelementptr i8, ptr null, i32 1
  %s2sz540 = ptrtoint ptr %s2sz540_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.34.gep, i64 %s2sz540)
  store i8 %v9.unpack324, ptr %v9.fca.34.gep, align 1
  %v9.fca.35.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 35
  %s2sz541_p = getelementptr i8, ptr null, i32 1
  %s2sz541 = ptrtoint ptr %s2sz541_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.35.gep, i64 %s2sz541)
  store i8 %v9.unpack326, ptr %v9.fca.35.gep, align 1
  %v9.fca.36.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 36
  %s2sz542_p = getelementptr i8, ptr null, i32 1
  %s2sz542 = ptrtoint ptr %s2sz542_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.36.gep, i64 %s2sz542)
  store i8 %v9.unpack328, ptr %v9.fca.36.gep, align 1
  %v9.fca.37.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 37
  %s2sz543_p = getelementptr i8, ptr null, i32 1
  %s2sz543 = ptrtoint ptr %s2sz543_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.37.gep, i64 %s2sz543)
  store i8 %v9.unpack330, ptr %v9.fca.37.gep, align 1
  %v9.fca.38.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 38
  %s2sz544_p = getelementptr i8, ptr null, i32 1
  %s2sz544 = ptrtoint ptr %s2sz544_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.38.gep, i64 %s2sz544)
  store i8 %v9.unpack332, ptr %v9.fca.38.gep, align 1
  %v9.fca.39.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 39
  %s2sz545_p = getelementptr i8, ptr null, i32 1
  %s2sz545 = ptrtoint ptr %s2sz545_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.39.gep, i64 %s2sz545)
  store i8 %v9.unpack334, ptr %v9.fca.39.gep, align 1
  %v9.fca.40.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 40
  %s2sz546_p = getelementptr i8, ptr null, i32 1
  %s2sz546 = ptrtoint ptr %s2sz546_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.40.gep, i64 %s2sz546)
  store i8 %v9.unpack336, ptr %v9.fca.40.gep, align 1
  %v9.fca.41.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 41
  %s2sz547_p = getelementptr i8, ptr null, i32 1
  %s2sz547 = ptrtoint ptr %s2sz547_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.41.gep, i64 %s2sz547)
  store i8 %v9.unpack338, ptr %v9.fca.41.gep, align 1
  %v9.fca.42.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 42
  %s2sz548_p = getelementptr i8, ptr null, i32 1
  %s2sz548 = ptrtoint ptr %s2sz548_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.42.gep, i64 %s2sz548)
  store i8 %v9.unpack340, ptr %v9.fca.42.gep, align 1
  %v9.fca.43.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 43
  %s2sz549_p = getelementptr i8, ptr null, i32 1
  %s2sz549 = ptrtoint ptr %s2sz549_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.43.gep, i64 %s2sz549)
  store i8 %v9.unpack342, ptr %v9.fca.43.gep, align 1
  %v9.fca.44.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 44
  %s2sz550_p = getelementptr i8, ptr null, i32 1
  %s2sz550 = ptrtoint ptr %s2sz550_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.44.gep, i64 %s2sz550)
  store i8 %v9.unpack344, ptr %v9.fca.44.gep, align 1
  %v9.fca.45.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 45
  %s2sz551_p = getelementptr i8, ptr null, i32 1
  %s2sz551 = ptrtoint ptr %s2sz551_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.45.gep, i64 %s2sz551)
  store i8 %v9.unpack346, ptr %v9.fca.45.gep, align 1
  %v9.fca.46.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 46
  %s2sz552_p = getelementptr i8, ptr null, i32 1
  %s2sz552 = ptrtoint ptr %s2sz552_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.46.gep, i64 %s2sz552)
  store i8 %v9.unpack348, ptr %v9.fca.46.gep, align 1
  %v9.fca.47.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 47
  %s2sz553_p = getelementptr i8, ptr null, i32 1
  %s2sz553 = ptrtoint ptr %s2sz553_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.47.gep, i64 %s2sz553)
  store i8 %v9.unpack350, ptr %v9.fca.47.gep, align 1
  %v9.fca.48.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 48
  %s2sz554_p = getelementptr i8, ptr null, i32 1
  %s2sz554 = ptrtoint ptr %s2sz554_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.48.gep, i64 %s2sz554)
  store i8 %v9.unpack352, ptr %v9.fca.48.gep, align 1
  %v9.fca.49.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 49
  %s2sz555_p = getelementptr i8, ptr null, i32 1
  %s2sz555 = ptrtoint ptr %s2sz555_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.49.gep, i64 %s2sz555)
  store i8 %v9.unpack354, ptr %v9.fca.49.gep, align 1
  %v9.fca.50.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 50
  %s2sz556_p = getelementptr i8, ptr null, i32 1
  %s2sz556 = ptrtoint ptr %s2sz556_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.50.gep, i64 %s2sz556)
  store i8 %v9.unpack356, ptr %v9.fca.50.gep, align 1
  %v9.fca.51.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 51
  %s2sz557_p = getelementptr i8, ptr null, i32 1
  %s2sz557 = ptrtoint ptr %s2sz557_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.51.gep, i64 %s2sz557)
  store i8 %v9.unpack358, ptr %v9.fca.51.gep, align 1
  %v9.fca.52.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 52
  %s2sz558_p = getelementptr i8, ptr null, i32 1
  %s2sz558 = ptrtoint ptr %s2sz558_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.52.gep, i64 %s2sz558)
  store i8 %v9.unpack360, ptr %v9.fca.52.gep, align 1
  %v9.fca.53.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 53
  %s2sz559_p = getelementptr i8, ptr null, i32 1
  %s2sz559 = ptrtoint ptr %s2sz559_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.53.gep, i64 %s2sz559)
  store i8 %v9.unpack362, ptr %v9.fca.53.gep, align 1
  %v9.fca.54.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 54
  %s2sz560_p = getelementptr i8, ptr null, i32 1
  %s2sz560 = ptrtoint ptr %s2sz560_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.54.gep, i64 %s2sz560)
  store i8 %v9.unpack364, ptr %v9.fca.54.gep, align 1
  %v9.fca.55.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 55
  %s2sz561_p = getelementptr i8, ptr null, i32 1
  %s2sz561 = ptrtoint ptr %s2sz561_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.55.gep, i64 %s2sz561)
  store i8 %v9.unpack366, ptr %v9.fca.55.gep, align 1
  %v9.fca.56.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 56
  %s2sz562_p = getelementptr i8, ptr null, i32 1
  %s2sz562 = ptrtoint ptr %s2sz562_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.56.gep, i64 %s2sz562)
  store i8 %v9.unpack368, ptr %v9.fca.56.gep, align 1
  %v9.fca.57.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 57
  %s2sz563_p = getelementptr i8, ptr null, i32 1
  %s2sz563 = ptrtoint ptr %s2sz563_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.57.gep, i64 %s2sz563)
  store i8 %v9.unpack370, ptr %v9.fca.57.gep, align 1
  %v9.fca.58.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 58
  %s2sz564_p = getelementptr i8, ptr null, i32 1
  %s2sz564 = ptrtoint ptr %s2sz564_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.58.gep, i64 %s2sz564)
  store i8 %v9.unpack372, ptr %v9.fca.58.gep, align 1
  %v9.fca.59.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 59
  %s2sz565_p = getelementptr i8, ptr null, i32 1
  %s2sz565 = ptrtoint ptr %s2sz565_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.59.gep, i64 %s2sz565)
  store i8 %v9.unpack374, ptr %v9.fca.59.gep, align 1
  %v9.fca.60.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 60
  %s2sz566_p = getelementptr i8, ptr null, i32 1
  %s2sz566 = ptrtoint ptr %s2sz566_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.60.gep, i64 %s2sz566)
  store i8 %v9.unpack376, ptr %v9.fca.60.gep, align 1
  %v9.fca.61.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 61
  %s2sz567_p = getelementptr i8, ptr null, i32 1
  %s2sz567 = ptrtoint ptr %s2sz567_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.61.gep, i64 %s2sz567)
  store i8 %v9.unpack378, ptr %v9.fca.61.gep, align 1
  %v9.fca.62.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 62
  %s2sz568_p = getelementptr i8, ptr null, i32 1
  %s2sz568 = ptrtoint ptr %s2sz568_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.62.gep, i64 %s2sz568)
  store i8 %v9.unpack380, ptr %v9.fca.62.gep, align 1
  %v9.fca.63.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 63
  %s2sz569_p = getelementptr i8, ptr null, i32 1
  %s2sz569 = ptrtoint ptr %s2sz569_p to i64
  call void @s2_record(i32 1, ptr %v9.fca.63.gep, i64 %s2sz569)
  store i8 %v9.unpack382, ptr %v9.fca.63.gep, align 1
  %v10_invalid = icmp ugt i32 %v8_pair, 63
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v10_invalid, label %v10_trap, label %v10_ok

v10_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v10_ok:                                           ; preds = %b2
  %v10_offset = zext nneg i32 %v8_pair to i64
  %v10_ptr = getelementptr i8, ptr %v9_storage, i64 %v10_offset
  %s2sz570_p = getelementptr i8, ptr null, i32 1
  %s2sz570 = ptrtoint ptr %s2sz570_p to i64
  call void @s2_record(i32 0, ptr %v10_ptr, i64 %s2sz570)
  %v10 = load i8, ptr %v10_ptr, align 1
  %v12 = icmp eq i8 %v10, 1
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v12, label %v20_ok, label %b3

b3:                                               ; preds = %v10_ok
  %s2sz571_p = getelementptr i8, ptr null, i32 1
  %s2sz571 = ptrtoint ptr %s2sz571_p to i64
  call void @s2_record(i32 1, ptr %v14_storage, i64 %s2sz571)
  store i8 %v9.unpack, ptr %v14_storage, align 1
  %v14.fca.1.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 1
  %s2sz572_p = getelementptr i8, ptr null, i32 1
  %s2sz572 = ptrtoint ptr %s2sz572_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.1.gep, i64 %s2sz572)
  store i8 %v9.unpack258, ptr %v14.fca.1.gep, align 1
  %v14.fca.2.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 2
  %s2sz573_p = getelementptr i8, ptr null, i32 1
  %s2sz573 = ptrtoint ptr %s2sz573_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.2.gep, i64 %s2sz573)
  store i8 %v9.unpack260, ptr %v14.fca.2.gep, align 1
  %v14.fca.3.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 3
  %s2sz574_p = getelementptr i8, ptr null, i32 1
  %s2sz574 = ptrtoint ptr %s2sz574_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.3.gep, i64 %s2sz574)
  store i8 %v9.unpack262, ptr %v14.fca.3.gep, align 1
  %v14.fca.4.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 4
  %s2sz575_p = getelementptr i8, ptr null, i32 1
  %s2sz575 = ptrtoint ptr %s2sz575_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.4.gep, i64 %s2sz575)
  store i8 %v9.unpack264, ptr %v14.fca.4.gep, align 1
  %v14.fca.5.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 5
  %s2sz576_p = getelementptr i8, ptr null, i32 1
  %s2sz576 = ptrtoint ptr %s2sz576_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.5.gep, i64 %s2sz576)
  store i8 %v9.unpack266, ptr %v14.fca.5.gep, align 1
  %v14.fca.6.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 6
  %s2sz577_p = getelementptr i8, ptr null, i32 1
  %s2sz577 = ptrtoint ptr %s2sz577_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.6.gep, i64 %s2sz577)
  store i8 %v9.unpack268, ptr %v14.fca.6.gep, align 1
  %v14.fca.7.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 7
  %s2sz578_p = getelementptr i8, ptr null, i32 1
  %s2sz578 = ptrtoint ptr %s2sz578_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.7.gep, i64 %s2sz578)
  store i8 %v9.unpack270, ptr %v14.fca.7.gep, align 1
  %v14.fca.8.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 8
  %s2sz579_p = getelementptr i8, ptr null, i32 1
  %s2sz579 = ptrtoint ptr %s2sz579_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.8.gep, i64 %s2sz579)
  store i8 %v9.unpack272, ptr %v14.fca.8.gep, align 1
  %v14.fca.9.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 9
  %s2sz580_p = getelementptr i8, ptr null, i32 1
  %s2sz580 = ptrtoint ptr %s2sz580_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.9.gep, i64 %s2sz580)
  store i8 %v9.unpack274, ptr %v14.fca.9.gep, align 1
  %v14.fca.10.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 10
  %s2sz581_p = getelementptr i8, ptr null, i32 1
  %s2sz581 = ptrtoint ptr %s2sz581_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.10.gep, i64 %s2sz581)
  store i8 %v9.unpack276, ptr %v14.fca.10.gep, align 1
  %v14.fca.11.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 11
  %s2sz582_p = getelementptr i8, ptr null, i32 1
  %s2sz582 = ptrtoint ptr %s2sz582_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.11.gep, i64 %s2sz582)
  store i8 %v9.unpack278, ptr %v14.fca.11.gep, align 1
  %v14.fca.12.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 12
  %s2sz583_p = getelementptr i8, ptr null, i32 1
  %s2sz583 = ptrtoint ptr %s2sz583_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.12.gep, i64 %s2sz583)
  store i8 %v9.unpack280, ptr %v14.fca.12.gep, align 1
  %v14.fca.13.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 13
  %s2sz584_p = getelementptr i8, ptr null, i32 1
  %s2sz584 = ptrtoint ptr %s2sz584_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.13.gep, i64 %s2sz584)
  store i8 %v9.unpack282, ptr %v14.fca.13.gep, align 1
  %v14.fca.14.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 14
  %s2sz585_p = getelementptr i8, ptr null, i32 1
  %s2sz585 = ptrtoint ptr %s2sz585_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.14.gep, i64 %s2sz585)
  store i8 %v9.unpack284, ptr %v14.fca.14.gep, align 1
  %v14.fca.15.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 15
  %s2sz586_p = getelementptr i8, ptr null, i32 1
  %s2sz586 = ptrtoint ptr %s2sz586_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.15.gep, i64 %s2sz586)
  store i8 %v9.unpack286, ptr %v14.fca.15.gep, align 1
  %v14.fca.16.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 16
  %s2sz587_p = getelementptr i8, ptr null, i32 1
  %s2sz587 = ptrtoint ptr %s2sz587_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.16.gep, i64 %s2sz587)
  store i8 %v9.unpack288, ptr %v14.fca.16.gep, align 1
  %v14.fca.17.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 17
  %s2sz588_p = getelementptr i8, ptr null, i32 1
  %s2sz588 = ptrtoint ptr %s2sz588_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.17.gep, i64 %s2sz588)
  store i8 %v9.unpack290, ptr %v14.fca.17.gep, align 1
  %v14.fca.18.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 18
  %s2sz589_p = getelementptr i8, ptr null, i32 1
  %s2sz589 = ptrtoint ptr %s2sz589_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.18.gep, i64 %s2sz589)
  store i8 %v9.unpack292, ptr %v14.fca.18.gep, align 1
  %v14.fca.19.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 19
  %s2sz590_p = getelementptr i8, ptr null, i32 1
  %s2sz590 = ptrtoint ptr %s2sz590_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.19.gep, i64 %s2sz590)
  store i8 %v9.unpack294, ptr %v14.fca.19.gep, align 1
  %v14.fca.20.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 20
  %s2sz591_p = getelementptr i8, ptr null, i32 1
  %s2sz591 = ptrtoint ptr %s2sz591_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.20.gep, i64 %s2sz591)
  store i8 %v9.unpack296, ptr %v14.fca.20.gep, align 1
  %v14.fca.21.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 21
  %s2sz592_p = getelementptr i8, ptr null, i32 1
  %s2sz592 = ptrtoint ptr %s2sz592_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.21.gep, i64 %s2sz592)
  store i8 %v9.unpack298, ptr %v14.fca.21.gep, align 1
  %v14.fca.22.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 22
  %s2sz593_p = getelementptr i8, ptr null, i32 1
  %s2sz593 = ptrtoint ptr %s2sz593_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.22.gep, i64 %s2sz593)
  store i8 %v9.unpack300, ptr %v14.fca.22.gep, align 1
  %v14.fca.23.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 23
  %s2sz594_p = getelementptr i8, ptr null, i32 1
  %s2sz594 = ptrtoint ptr %s2sz594_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.23.gep, i64 %s2sz594)
  store i8 %v9.unpack302, ptr %v14.fca.23.gep, align 1
  %v14.fca.24.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 24
  %s2sz595_p = getelementptr i8, ptr null, i32 1
  %s2sz595 = ptrtoint ptr %s2sz595_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.24.gep, i64 %s2sz595)
  store i8 %v9.unpack304, ptr %v14.fca.24.gep, align 1
  %v14.fca.25.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 25
  %s2sz596_p = getelementptr i8, ptr null, i32 1
  %s2sz596 = ptrtoint ptr %s2sz596_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.25.gep, i64 %s2sz596)
  store i8 %v9.unpack306, ptr %v14.fca.25.gep, align 1
  %v14.fca.26.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 26
  %s2sz597_p = getelementptr i8, ptr null, i32 1
  %s2sz597 = ptrtoint ptr %s2sz597_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.26.gep, i64 %s2sz597)
  store i8 %v9.unpack308, ptr %v14.fca.26.gep, align 1
  %v14.fca.27.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 27
  %s2sz598_p = getelementptr i8, ptr null, i32 1
  %s2sz598 = ptrtoint ptr %s2sz598_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.27.gep, i64 %s2sz598)
  store i8 %v9.unpack310, ptr %v14.fca.27.gep, align 1
  %v14.fca.28.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 28
  %s2sz599_p = getelementptr i8, ptr null, i32 1
  %s2sz599 = ptrtoint ptr %s2sz599_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.28.gep, i64 %s2sz599)
  store i8 %v9.unpack312, ptr %v14.fca.28.gep, align 1
  %v14.fca.29.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 29
  %s2sz600_p = getelementptr i8, ptr null, i32 1
  %s2sz600 = ptrtoint ptr %s2sz600_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.29.gep, i64 %s2sz600)
  store i8 %v9.unpack314, ptr %v14.fca.29.gep, align 1
  %v14.fca.30.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 30
  %s2sz601_p = getelementptr i8, ptr null, i32 1
  %s2sz601 = ptrtoint ptr %s2sz601_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.30.gep, i64 %s2sz601)
  store i8 %v9.unpack316, ptr %v14.fca.30.gep, align 1
  %v14.fca.31.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 31
  %s2sz602_p = getelementptr i8, ptr null, i32 1
  %s2sz602 = ptrtoint ptr %s2sz602_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.31.gep, i64 %s2sz602)
  store i8 %v9.unpack318, ptr %v14.fca.31.gep, align 1
  %v14.fca.32.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 32
  %s2sz603_p = getelementptr i8, ptr null, i32 1
  %s2sz603 = ptrtoint ptr %s2sz603_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.32.gep, i64 %s2sz603)
  store i8 %v9.unpack320, ptr %v14.fca.32.gep, align 1
  %v14.fca.33.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 33
  %s2sz604_p = getelementptr i8, ptr null, i32 1
  %s2sz604 = ptrtoint ptr %s2sz604_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.33.gep, i64 %s2sz604)
  store i8 %v9.unpack322, ptr %v14.fca.33.gep, align 1
  %v14.fca.34.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 34
  %s2sz605_p = getelementptr i8, ptr null, i32 1
  %s2sz605 = ptrtoint ptr %s2sz605_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.34.gep, i64 %s2sz605)
  store i8 %v9.unpack324, ptr %v14.fca.34.gep, align 1
  %v14.fca.35.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 35
  %s2sz606_p = getelementptr i8, ptr null, i32 1
  %s2sz606 = ptrtoint ptr %s2sz606_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.35.gep, i64 %s2sz606)
  store i8 %v9.unpack326, ptr %v14.fca.35.gep, align 1
  %v14.fca.36.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 36
  %s2sz607_p = getelementptr i8, ptr null, i32 1
  %s2sz607 = ptrtoint ptr %s2sz607_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.36.gep, i64 %s2sz607)
  store i8 %v9.unpack328, ptr %v14.fca.36.gep, align 1
  %v14.fca.37.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 37
  %s2sz608_p = getelementptr i8, ptr null, i32 1
  %s2sz608 = ptrtoint ptr %s2sz608_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.37.gep, i64 %s2sz608)
  store i8 %v9.unpack330, ptr %v14.fca.37.gep, align 1
  %v14.fca.38.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 38
  %s2sz609_p = getelementptr i8, ptr null, i32 1
  %s2sz609 = ptrtoint ptr %s2sz609_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.38.gep, i64 %s2sz609)
  store i8 %v9.unpack332, ptr %v14.fca.38.gep, align 1
  %v14.fca.39.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 39
  %s2sz610_p = getelementptr i8, ptr null, i32 1
  %s2sz610 = ptrtoint ptr %s2sz610_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.39.gep, i64 %s2sz610)
  store i8 %v9.unpack334, ptr %v14.fca.39.gep, align 1
  %v14.fca.40.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 40
  %s2sz611_p = getelementptr i8, ptr null, i32 1
  %s2sz611 = ptrtoint ptr %s2sz611_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.40.gep, i64 %s2sz611)
  store i8 %v9.unpack336, ptr %v14.fca.40.gep, align 1
  %v14.fca.41.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 41
  %s2sz612_p = getelementptr i8, ptr null, i32 1
  %s2sz612 = ptrtoint ptr %s2sz612_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.41.gep, i64 %s2sz612)
  store i8 %v9.unpack338, ptr %v14.fca.41.gep, align 1
  %v14.fca.42.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 42
  %s2sz613_p = getelementptr i8, ptr null, i32 1
  %s2sz613 = ptrtoint ptr %s2sz613_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.42.gep, i64 %s2sz613)
  store i8 %v9.unpack340, ptr %v14.fca.42.gep, align 1
  %v14.fca.43.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 43
  %s2sz614_p = getelementptr i8, ptr null, i32 1
  %s2sz614 = ptrtoint ptr %s2sz614_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.43.gep, i64 %s2sz614)
  store i8 %v9.unpack342, ptr %v14.fca.43.gep, align 1
  %v14.fca.44.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 44
  %s2sz615_p = getelementptr i8, ptr null, i32 1
  %s2sz615 = ptrtoint ptr %s2sz615_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.44.gep, i64 %s2sz615)
  store i8 %v9.unpack344, ptr %v14.fca.44.gep, align 1
  %v14.fca.45.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 45
  %s2sz616_p = getelementptr i8, ptr null, i32 1
  %s2sz616 = ptrtoint ptr %s2sz616_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.45.gep, i64 %s2sz616)
  store i8 %v9.unpack346, ptr %v14.fca.45.gep, align 1
  %v14.fca.46.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 46
  %s2sz617_p = getelementptr i8, ptr null, i32 1
  %s2sz617 = ptrtoint ptr %s2sz617_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.46.gep, i64 %s2sz617)
  store i8 %v9.unpack348, ptr %v14.fca.46.gep, align 1
  %v14.fca.47.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 47
  %s2sz618_p = getelementptr i8, ptr null, i32 1
  %s2sz618 = ptrtoint ptr %s2sz618_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.47.gep, i64 %s2sz618)
  store i8 %v9.unpack350, ptr %v14.fca.47.gep, align 1
  %v14.fca.48.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 48
  %s2sz619_p = getelementptr i8, ptr null, i32 1
  %s2sz619 = ptrtoint ptr %s2sz619_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.48.gep, i64 %s2sz619)
  store i8 %v9.unpack352, ptr %v14.fca.48.gep, align 1
  %v14.fca.49.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 49
  %s2sz620_p = getelementptr i8, ptr null, i32 1
  %s2sz620 = ptrtoint ptr %s2sz620_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.49.gep, i64 %s2sz620)
  store i8 %v9.unpack354, ptr %v14.fca.49.gep, align 1
  %v14.fca.50.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 50
  %s2sz621_p = getelementptr i8, ptr null, i32 1
  %s2sz621 = ptrtoint ptr %s2sz621_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.50.gep, i64 %s2sz621)
  store i8 %v9.unpack356, ptr %v14.fca.50.gep, align 1
  %v14.fca.51.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 51
  %s2sz622_p = getelementptr i8, ptr null, i32 1
  %s2sz622 = ptrtoint ptr %s2sz622_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.51.gep, i64 %s2sz622)
  store i8 %v9.unpack358, ptr %v14.fca.51.gep, align 1
  %v14.fca.52.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 52
  %s2sz623_p = getelementptr i8, ptr null, i32 1
  %s2sz623 = ptrtoint ptr %s2sz623_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.52.gep, i64 %s2sz623)
  store i8 %v9.unpack360, ptr %v14.fca.52.gep, align 1
  %v14.fca.53.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 53
  %s2sz624_p = getelementptr i8, ptr null, i32 1
  %s2sz624 = ptrtoint ptr %s2sz624_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.53.gep, i64 %s2sz624)
  store i8 %v9.unpack362, ptr %v14.fca.53.gep, align 1
  %v14.fca.54.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 54
  %s2sz625_p = getelementptr i8, ptr null, i32 1
  %s2sz625 = ptrtoint ptr %s2sz625_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.54.gep, i64 %s2sz625)
  store i8 %v9.unpack364, ptr %v14.fca.54.gep, align 1
  %v14.fca.55.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 55
  %s2sz626_p = getelementptr i8, ptr null, i32 1
  %s2sz626 = ptrtoint ptr %s2sz626_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.55.gep, i64 %s2sz626)
  store i8 %v9.unpack366, ptr %v14.fca.55.gep, align 1
  %v14.fca.56.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 56
  %s2sz627_p = getelementptr i8, ptr null, i32 1
  %s2sz627 = ptrtoint ptr %s2sz627_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.56.gep, i64 %s2sz627)
  store i8 %v9.unpack368, ptr %v14.fca.56.gep, align 1
  %v14.fca.57.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 57
  %s2sz628_p = getelementptr i8, ptr null, i32 1
  %s2sz628 = ptrtoint ptr %s2sz628_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.57.gep, i64 %s2sz628)
  store i8 %v9.unpack370, ptr %v14.fca.57.gep, align 1
  %v14.fca.58.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 58
  %s2sz629_p = getelementptr i8, ptr null, i32 1
  %s2sz629 = ptrtoint ptr %s2sz629_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.58.gep, i64 %s2sz629)
  store i8 %v9.unpack372, ptr %v14.fca.58.gep, align 1
  %v14.fca.59.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 59
  %s2sz630_p = getelementptr i8, ptr null, i32 1
  %s2sz630 = ptrtoint ptr %s2sz630_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.59.gep, i64 %s2sz630)
  store i8 %v9.unpack374, ptr %v14.fca.59.gep, align 1
  %v14.fca.60.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 60
  %s2sz631_p = getelementptr i8, ptr null, i32 1
  %s2sz631 = ptrtoint ptr %s2sz631_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.60.gep, i64 %s2sz631)
  store i8 %v9.unpack376, ptr %v14.fca.60.gep, align 1
  %v14.fca.61.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 61
  %s2sz632_p = getelementptr i8, ptr null, i32 1
  %s2sz632 = ptrtoint ptr %s2sz632_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.61.gep, i64 %s2sz632)
  store i8 %v9.unpack378, ptr %v14.fca.61.gep, align 1
  %v14.fca.62.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 62
  %s2sz633_p = getelementptr i8, ptr null, i32 1
  %s2sz633 = ptrtoint ptr %s2sz633_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.62.gep, i64 %s2sz633)
  store i8 %v9.unpack380, ptr %v14.fca.62.gep, align 1
  %v14.fca.63.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 63
  %s2sz634_p = getelementptr i8, ptr null, i32 1
  %s2sz634 = ptrtoint ptr %s2sz634_p to i64
  call void @s2_record(i32 1, ptr %v14.fca.63.gep, i64 %s2sz634)
  store i8 %v9.unpack382, ptr %v14.fca.63.gep, align 1
  %v15_ptr = getelementptr i8, ptr %v14_storage, i64 %v10_offset
  %s2sz635_p = getelementptr i8, ptr null, i32 1
  %s2sz635 = ptrtoint ptr %s2sz635_p to i64
  call void @s2_record(i32 0, ptr %v15_ptr, i64 %s2sz635)
  %v15 = load i8, ptr %v15_ptr, align 1
  %v17 = icmp eq i8 %v15, 3
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v17, label %v20_ok, label %v25_ok

v20_ok:                                           ; preds = %b3, %v10_ok
  %s2sz636_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz636 = ptrtoint ptr %s2sz636_p to i64
  call void @s2_record(i32 0, ptr %v9_ptr, i64 %s2sz636)
  %0 = load <16 x i8>, ptr %v9_ptr, align 8
  %s2sz637_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz637 = ptrtoint ptr %s2sz637_p to i64
  call void @s2_record(i32 1, ptr %v22_scratch, i64 %s2sz637)
  store <16 x i8> %0, ptr %v22_scratch, align 16
  %v19.fca.16.gep162 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 16
  %s2sz638_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz638 = ptrtoint ptr %s2sz638_p to i64
  call void @s2_record(i32 0, ptr %v9.elt287, i64 %s2sz638)
  %1 = load <16 x i8>, ptr %v9.elt287, align 8
  %s2sz639_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz639 = ptrtoint ptr %s2sz639_p to i64
  call void @s2_record(i32 1, ptr %v19.fca.16.gep162, i64 %s2sz639)
  store <16 x i8> %1, ptr %v19.fca.16.gep162, align 16
  %v19.fca.32.gep194 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 32
  %s2sz640_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz640 = ptrtoint ptr %s2sz640_p to i64
  call void @s2_record(i32 0, ptr %v9.elt319, i64 %s2sz640)
  %2 = load <16 x i8>, ptr %v9.elt319, align 8
  %s2sz641_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz641 = ptrtoint ptr %s2sz641_p to i64
  call void @s2_record(i32 1, ptr %v19.fca.32.gep194, i64 %s2sz641)
  store <16 x i8> %2, ptr %v19.fca.32.gep194, align 16
  %v19.fca.48.gep226 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 48
  %s2sz642_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz642 = ptrtoint ptr %s2sz642_p to i64
  call void @s2_record(i32 0, ptr %v9.elt351, i64 %s2sz642)
  %3 = load <16 x i8>, ptr %v9.elt351, align 8
  %s2sz643_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz643 = ptrtoint ptr %s2sz643_p to i64
  call void @s2_record(i32 1, ptr %v19.fca.48.gep226, i64 %s2sz643)
  store <16 x i8> %3, ptr %v19.fca.48.gep226, align 16
  %v22_ptr = getelementptr i8, ptr %v22_scratch, i64 %v10_offset
  %s2sz644_p = getelementptr i8, ptr null, i32 1
  %s2sz644 = ptrtoint ptr %s2sz644_p to i64
  call void @s2_record(i32 1, ptr %v22_ptr, i64 %s2sz644)
  store i8 2, ptr %v22_ptr, align 1
  %s2sz645_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz645 = ptrtoint ptr %s2sz645_p to i64
  call void @s2_record(i32 0, ptr %v22_scratch, i64 %s2sz645)
  %4 = load <16 x i8>, ptr %v22_scratch, align 16
  %s2sz646_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz646 = ptrtoint ptr %s2sz646_p to i64
  call void @s2_record(i32 1, ptr %v9_ptr, i64 %s2sz646)
  store <16 x i8> %4, ptr %v9_ptr, align 8
  %s2sz647_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz647 = ptrtoint ptr %s2sz647_p to i64
  call void @s2_record(i32 0, ptr %v19.fca.16.gep162, i64 %s2sz647)
  %5 = load <16 x i8>, ptr %v19.fca.16.gep162, align 16
  %s2sz648_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz648 = ptrtoint ptr %s2sz648_p to i64
  call void @s2_record(i32 1, ptr %v9.elt287, i64 %s2sz648)
  store <16 x i8> %5, ptr %v9.elt287, align 8
  %s2sz649_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz649 = ptrtoint ptr %s2sz649_p to i64
  call void @s2_record(i32 0, ptr %v19.fca.32.gep194, i64 %s2sz649)
  %6 = load <16 x i8>, ptr %v19.fca.32.gep194, align 16
  %s2sz650_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz650 = ptrtoint ptr %s2sz650_p to i64
  call void @s2_record(i32 1, ptr %v9.elt319, i64 %s2sz650)
  store <16 x i8> %6, ptr %v9.elt319, align 8
  %s2sz651_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz651 = ptrtoint ptr %s2sz651_p to i64
  call void @s2_record(i32 0, ptr %v19.fca.48.gep226, i64 %s2sz651)
  %7 = load <16 x i8>, ptr %v19.fca.48.gep226, align 16
  %s2sz652_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz652 = ptrtoint ptr %s2sz652_p to i64
  call void @s2_record(i32 1, ptr %v9.elt351, i64 %s2sz652)
  store <16 x i8> %7, ptr %v9.elt351, align 8
  br label %b9

v25_ok:                                           ; preds = %b3
  %s2sz653_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz653 = ptrtoint ptr %s2sz653_p to i64
  call void @s2_record(i32 0, ptr %v9_ptr, i64 %s2sz653)
  %8 = load <16 x i8>, ptr %v9_ptr, align 8
  %s2sz654_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz654 = ptrtoint ptr %s2sz654_p to i64
  call void @s2_record(i32 1, ptr %v27_scratch, i64 %s2sz654)
  store <16 x i8> %8, ptr %v27_scratch, align 16
  %v24.fca.16.gep34 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 16
  %s2sz655_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz655 = ptrtoint ptr %s2sz655_p to i64
  call void @s2_record(i32 0, ptr %v9.elt287, i64 %s2sz655)
  %9 = load <16 x i8>, ptr %v9.elt287, align 8
  %s2sz656_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz656 = ptrtoint ptr %s2sz656_p to i64
  call void @s2_record(i32 1, ptr %v24.fca.16.gep34, i64 %s2sz656)
  store <16 x i8> %9, ptr %v24.fca.16.gep34, align 16
  %v24.fca.32.gep66 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 32
  %s2sz657_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz657 = ptrtoint ptr %s2sz657_p to i64
  call void @s2_record(i32 0, ptr %v9.elt319, i64 %s2sz657)
  %10 = load <16 x i8>, ptr %v9.elt319, align 8
  %s2sz658_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz658 = ptrtoint ptr %s2sz658_p to i64
  call void @s2_record(i32 1, ptr %v24.fca.32.gep66, i64 %s2sz658)
  store <16 x i8> %10, ptr %v24.fca.32.gep66, align 16
  %v24.fca.48.gep98 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 48
  %s2sz659_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz659 = ptrtoint ptr %s2sz659_p to i64
  call void @s2_record(i32 0, ptr %v9.elt351, i64 %s2sz659)
  %11 = load <16 x i8>, ptr %v9.elt351, align 8
  %s2sz660_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz660 = ptrtoint ptr %s2sz660_p to i64
  call void @s2_record(i32 1, ptr %v24.fca.48.gep98, i64 %s2sz660)
  store <16 x i8> %11, ptr %v24.fca.48.gep98, align 16
  %v27_ptr = getelementptr i8, ptr %v27_scratch, i64 %v10_offset
  %s2sz661_p = getelementptr i8, ptr null, i32 1
  %s2sz661 = ptrtoint ptr %s2sz661_p to i64
  call void @s2_record(i32 1, ptr %v27_ptr, i64 %s2sz661)
  store i8 7, ptr %v27_ptr, align 1
  %s2sz662_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz662 = ptrtoint ptr %s2sz662_p to i64
  call void @s2_record(i32 0, ptr %v27_scratch, i64 %s2sz662)
  %12 = load <16 x i8>, ptr %v27_scratch, align 16
  %s2sz663_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz663 = ptrtoint ptr %s2sz663_p to i64
  call void @s2_record(i32 1, ptr %v9_ptr, i64 %s2sz663)
  store <16 x i8> %12, ptr %v9_ptr, align 8
  %s2sz664_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz664 = ptrtoint ptr %s2sz664_p to i64
  call void @s2_record(i32 0, ptr %v24.fca.16.gep34, i64 %s2sz664)
  %13 = load <16 x i8>, ptr %v24.fca.16.gep34, align 16
  %s2sz665_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz665 = ptrtoint ptr %s2sz665_p to i64
  call void @s2_record(i32 1, ptr %v9.elt287, i64 %s2sz665)
  store <16 x i8> %13, ptr %v9.elt287, align 8
  %s2sz666_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz666 = ptrtoint ptr %s2sz666_p to i64
  call void @s2_record(i32 0, ptr %v24.fca.32.gep66, i64 %s2sz666)
  %14 = load <16 x i8>, ptr %v24.fca.32.gep66, align 16
  %s2sz667_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz667 = ptrtoint ptr %s2sz667_p to i64
  call void @s2_record(i32 1, ptr %v9.elt319, i64 %s2sz667)
  store <16 x i8> %14, ptr %v9.elt319, align 8
  %s2sz668_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz668 = ptrtoint ptr %s2sz668_p to i64
  call void @s2_record(i32 0, ptr %v24.fca.48.gep98, i64 %s2sz668)
  %15 = load <16 x i8>, ptr %v24.fca.48.gep98, align 16
  %s2sz669_p = getelementptr <16 x i8>, ptr null, i32 1
  %s2sz669 = ptrtoint ptr %s2sz669_p to i64
  call void @s2_record(i32 1, ptr %v9.elt351, i64 %s2sz669)
  store <16 x i8> %15, ptr %v9.elt351, align 8
  br label %b9

b9:                                               ; preds = %v25_ok, %v20_ok, %b1
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @example_entry() local_unnamed_addr #6 {
entry:
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @stream_start(ptr nofree writeonly  initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %out) local_unnamed_addr #4 {
  %v16_mem.sroa.75.sroa.0.i = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0.i = alloca i8, align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  %s2sz670_p = getelementptr i1, ptr null, i32 1
  %s2sz670 = ptrtoint ptr %s2sz670_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.75.sroa.0.i, i64 %s2sz670)
  store i1 false, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  %s2sz671_p = getelementptr i1, ptr null, i32 1
  %s2sz671 = ptrtoint ptr %s2sz671_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.77.sroa.0.i, i64 %s2sz671)
  store i1 false, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %v16_mem.sroa.5.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 28
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %out, i8 0, i64 28, i1 false)
  %s2sz672_p = getelementptr i8, ptr null, i32 1
  %s2sz672 = ptrtoint ptr %s2sz672_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx.i, i64 %s2sz672)
  store i8 -128, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.6.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 29
  %s2sz673_p = getelementptr i8, ptr null, i32 1
  %s2sz673 = ptrtoint ptr %s2sz673_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx.i, i64 %s2sz673)
  store i8 -65, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx.i, align 1
  %v16_mem.sroa.71.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 32
  %s2sz674_p = getelementptr i32, ptr null, i32 1
  %s2sz674 = ptrtoint ptr %s2sz674_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx.i, i64 %s2sz674)
  store i32 0, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx.i, align 8
  %v16_mem.sroa.82.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 40
  %v16_mem.sroa.75.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 124
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %v16_mem.sroa.82.0.return_storage.sroa_idx.i, i8 0, i64 84, i1 false)
  %s2sz675_p = getelementptr i8, ptr null, i32 1
  %s2sz675 = ptrtoint ptr %s2sz675_p to i64
  call void @s2_record(i32 0, ptr %v16_mem.sroa.75.sroa.0.i, i64 %s2sz675)
  %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i = load i8, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  %s2sz676_p = getelementptr i8, ptr null, i32 1
  %s2sz676 = ptrtoint ptr %s2sz676_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.75.0.return_storage.sroa_idx.i, i64 %s2sz676)
  store i8 %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i, ptr %v16_mem.sroa.75.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.764.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 128
  %s2sz677_p = getelementptr i32, ptr null, i32 1
  %s2sz677 = ptrtoint ptr %s2sz677_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx.i, i64 %s2sz677)
  store i32 0, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx.i, align 8
  %v16_mem.sroa.77.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 132
  %s2sz678_p = getelementptr i8, ptr null, i32 1
  %s2sz678 = ptrtoint ptr %s2sz678_p to i64
  call void @s2_record(i32 0, ptr %v16_mem.sroa.77.sroa.0.i, i64 %s2sz678)
  %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i = load i8, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %s2sz679_p = getelementptr i8, ptr null, i32 1
  %s2sz679 = ptrtoint ptr %s2sz679_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.77.0.return_storage.sroa_idx.i, i64 %s2sz679)
  store i8 %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i, ptr %v16_mem.sroa.77.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.785.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 136
  %v16_mem.sroa.857.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 176
  %s2sz680_p = getelementptr i64, ptr null, i32 1
  %s2sz680 = ptrtoint ptr %s2sz680_p to i64
  call void @s2_record(i32 1, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx.i, i64 %s2sz680)
  store i64 0, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %v16_mem.sroa.785.0.return_storage.sroa_idx.i, i8 0, i64 36, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  ret void
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write, target_mem: none)
define void @stream_feed(ptr %state, ptr %bytes, i32 %length) local_unnamed_addr #5 {
  call void @s2_begin(ptr %state, i64 184)
  %a = insertvalue { ptr, i32 } zeroinitializer, ptr %bytes, 0
  %v = insertvalue { ptr, i32 } %a, i32 %length, 1
  %code = tail call i32 @liza_json.feed_mut(ptr %state, { ptr, i32 } %v)
  call void @s2_end()
  ret void
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i32 0, 9) i32 @stream_status(ptr nofree   %state) local_unnamed_addr #2 {
  %v33_mem.i.i = alloca %struct.JsonState, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %v33_mem.i.i)
  %v0_ptr.i.i.i = getelementptr i8, ptr %state, i64 168
  %s2sz681_p = getelementptr i32, ptr null, i32 1
  %s2sz681 = ptrtoint ptr %s2sz681_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr.i.i.i, i64 %s2sz681)
  %v0.i.i.i = load i32, ptr %v0_ptr.i.i.i, align 4
  %v2.i.i.i = icmp eq i32 %v0.i.i.i, 0
  %state.sink.sroa.gep = getelementptr inbounds nuw i8, ptr %state, i64 160
  %state.sink.sroa.gep4 = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 160
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2.i.i.i, label %liza_json.status.exit.i.i, label %b3.i.i.i

b3.i.i.i:                                         ; preds = %0
  %v7.i.i.i = icmp eq i32 %v0.i.i.i, 2
  %v9.i.i.i = select i1 %v7.i.i.i, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12.i.i.i = icmp eq i32 %v0.i.i.i, 3
  %v14.i.i.i = select i1 %v12.i.i.i, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9.i.i.i
  %v17.i.i.i = icmp eq i32 %v0.i.i.i, 4
  %v19.i.i.i = select i1 %v17.i.i.i, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14.i.i.i
  %v22.i.i.i = icmp eq i32 %v0.i.i.i, 5
  %v24.i.i.i = select i1 %v22.i.i.i, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19.i.i.i
  %v27.i.i.i = icmp eq i32 %v0.i.i.i, 6
  %v29.i.i.i = select i1 %v27.i.i.i, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24.i.i.i
  %v32.i.i.i = icmp eq i32 %v0.i.i.i, 7
  %v34.i.i.i = select i1 %v32.i.i.i, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29.i.i.i
  %v37.i.i.i = icmp eq i32 %v0.i.i.i, 8
  %v39.i.i.i = select i1 %v37.i.i.i, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34.i.i.i
  %v40_ptr.i.i.i = getelementptr i8, ptr %state, i64 176
  %s2sz682_p = getelementptr i64, ptr null, i32 1
  %s2sz682 = ptrtoint ptr %s2sz682_p to i64
  call void @s2_record(i32 0, ptr %v40_ptr.i.i.i, i64 %s2sz682)
  %v40.i.i.i = load i64, ptr %v40_ptr.i.i.i, align 8
  %v41_field0.i.i.i = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39.i.i.i, 0
  %v41.i.i.i = insertvalue %struct.JsonError %v41_field0.i.i.i, i64 %v40.i.i.i, 1
  %v42.i.i.i = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41.i.i.i, 1
  br label %liza_json.status.exit.i.i

liza_json.status.exit.i.i:                        ; preds = %b3.i.i.i, %0
  %common.ret.op.i.i.i = phi %variant.4 [ %v42.i.i.i, %b3.i.i.i ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %0 ]
  %v1.i.i = extractvalue %variant.4 %common.ret.op.i.i.i, 0
  %1 = icmp eq i32 %v1.i.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %1, label %b2.i.i, label %b4.i.i

b2.i.i:                                           ; preds = %liza_json.status.exit.i.i
  %v2.i.i = extractvalue %variant.4 %common.ret.op.i.i.i, 1
  %v3.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v2.i.i, 2
  br label %liza_status.exit

b4.i.i:                                           ; preds = %liza_json.status.exit.i.i
  %s2sz683_p = getelementptr %struct.Utf8StreamState, ptr null, i32 1
  %s2sz683 = ptrtoint ptr %s2sz683_p to i64
  call void @s2_record(i32 0, ptr %state, i64 %s2sz683)
  %v4.i.i = load %struct.Utf8StreamState, ptr %state, align 8
  %v0.i3.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0.i3.i.i, label %b6.i.i.i [
    i32 1, label %b1.i.i.i
    i32 2, label %b4.i.i.i
  ]

b1.i.i.i:                                         ; preds = %b4.i.i
  %v4.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 7
  %v5.i.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i.i.i, 1
  %v6.i.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5.i.i.i, 2
  br label %liza_utf8_stream.finish.exit.i.i

b4.i.i.i:                                         ; preds = %b4.i.i
  %v11.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 7
  %v12.i4.i.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i.i.i, 1
  %v13.i.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12.i4.i.i, 2
  br label %liza_utf8_stream.finish.exit.i.i

b6.i.i.i:                                         ; preds = %b4.i.i
  %v14.i6.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 3
  %v16.not.i.i.i = icmp eq i32 %v14.i6.i.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v16.not.i.i.i, label %b9.i.i.i, label %b7.i.i.i

b7.i.i.i:                                         ; preds = %b6.i.i.i
  %v18.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 2
  %v19.i7.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18.i.i.i, 1
  %v20.i.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19.i7.i.i, 2
  br label %liza_utf8_stream.finish.exit.i.i

b9.i.i.i:                                         ; preds = %b6.i.i.i
  %v21.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 1
  %v22.i8.i.i = insertvalue %variant.2 zeroinitializer, i64 %v21.i.i.i, 1
  br label %liza_utf8_stream.finish.exit.i.i

liza_utf8_stream.finish.exit.i.i:                 ; preds = %b9.i.i.i, %b7.i.i.i, %b4.i.i.i, %b1.i.i.i
  %common.ret.op.i5.i.i = phi %variant.2 [ %v6.i.i.i, %b1.i.i.i ], [ %v13.i.i.i, %b4.i.i.i ], [ %v20.i.i.i, %b7.i.i.i ], [ %v22.i8.i.i, %b9.i.i.i ]
  %v6.i.i = extractvalue %variant.2 %common.ret.op.i5.i.i, 0
  %2 = icmp eq i32 %v6.i.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %2, label %b6.i.i, label %b7.i.i

b6.i.i:                                           ; preds = %liza_utf8_stream.finish.exit.i.i
  %v13_ptr.i.i = getelementptr i8, ptr %state, i64 128
  %s2sz684_p = getelementptr i32, ptr null, i32 1
  %s2sz684 = ptrtoint ptr %s2sz684_p to i64
  call void @s2_record(i32 0, ptr %v13_ptr.i.i, i64 %s2sz684)
  %v13.i.i = load i32, ptr %v13_ptr.i.i, align 8
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v13.i.i, label %b19_to_b20.i.i [
    i32 11, label %b18.i.i
    i32 12, label %b18.i.i
    i32 14, label %b18.i.i
    i32 17, label %b18.i.i
  ]

b7.i.i:                                           ; preds = %liza_utf8_stream.finish.exit.i.i
  %v8.i.i = extractvalue %variant.2 %common.ret.op.i5.i.i, 2
  %v10.i.i = extractvalue %struct.Utf8StreamError %v8.i.i, 1
  %v11.i.i = insertvalue %struct.JsonError { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v10.i.i, 1
  %v12.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v11.i.i, 2
  br label %liza_status.exit

b18.i.i:                                          ; preds = %b6.i.i, %b6.i.i, %b6.i.i, %b6.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(184) %v33_mem.i.i, ptr noundef nonnull  align 1 dereferenceable(184) %state, i64 184, i1 false)
  %v33_part.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 128
  %s2sz685_p = getelementptr i32, ptr null, i32 1
  %s2sz685 = ptrtoint ptr %s2sz685_p to i64
  call void @s2_record(i32 1, ptr %v33_part.i.i, i64 %s2sz685)
  store i32 0, ptr %v33_part.i.i, align 8
  call void @liza___liza_owned___liza_json_done(ptr nonnull sret(%struct.JsonState) %v33_mem.i.i, ptr nonnull poison)
  %v35_next.sroa.4.0.v33_mem.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 48
  %s2sz686_p = getelementptr i64, ptr null, i32 1
  %s2sz686 = ptrtoint ptr %s2sz686_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i.i, i64 %s2sz686)
  %v35_next.sroa.4.0.copyload.i.i = load i64, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i.i, align 8
  %v35_next.sroa.8.0.v33_mem.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 120
  %s2sz687_p = getelementptr i32, ptr null, i32 1
  %s2sz687 = ptrtoint ptr %s2sz687_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i.i, i64 %s2sz687)
  %v35_next.sroa.8.0.copyload.i.i = load i32, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i.i, align 8
  %v35_next.sroa.10.0.v33_mem.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 124
  %s2sz688_p = getelementptr i8, ptr null, i32 1
  %s2sz688 = ptrtoint ptr %s2sz688_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i.i, i64 %s2sz688)
  %3 = load i8, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i.i, align 4
  %s2sz689_p = getelementptr i32, ptr null, i32 1
  %s2sz689 = ptrtoint ptr %s2sz689_p to i64
  call void @s2_record(i32 0, ptr %v33_part.i.i, i64 %s2sz689)
  %v35_next.sroa.14.0.copyload.i.i = load i32, ptr %v33_part.i.i, align 8
  %extract.t3 = trunc i8 %3 to i1
  br label %b20.i.i

b20.i.i:                                          ; preds = %b19_to_b20.i.i, %b18.i.i
  %state.sink.sroa.phi = phi ptr [ %state.sink.sroa.gep, %b19_to_b20.i.i ], [ %state.sink.sroa.gep4, %b18.i.i ]
  %.sink.off0 = phi i1 [ %extract.t2, %b19_to_b20.i.i ], [ %extract.t3, %b18.i.i ]
  %v35_mem.sroa.617.0.i.i = phi i32 [ %v13.i.i, %b19_to_b20.i.i ], [ %v35_next.sroa.14.0.copyload.i.i, %b18.i.i ]
  %v35_mem.sroa.412.0.i.i = phi i32 [ %v35_next.sroa.8.0.copyload26.i.i, %b19_to_b20.i.i ], [ %v35_next.sroa.8.0.copyload.i.i, %b18.i.i ]
  %v35_mem.sroa.2.0.i.i = phi i64 [ %v35_next.sroa.4.0.copyload25.i.i, %b19_to_b20.i.i ], [ %v35_next.sroa.4.0.copyload.i.i, %b18.i.i ]
  %4 = add i32 %v35_mem.sroa.617.0.i.i, -4
  %or.cond.i.i = icmp ult i32 %4, 3
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond.i.i, label %b27.i.i, label %b29.i.i

b27.i.i:                                          ; preds = %b20.i.i
  %s2sz690_p = getelementptr i64, ptr null, i32 1
  %s2sz690 = ptrtoint ptr %s2sz690_p to i64
  call void @s2_record(i32 0, ptr %state.sink.sroa.phi, i64 %s2sz690)
  %v35_next.sroa.18.0.copyload28.i.i = load i64, ptr %state.sink.sroa.phi, align 8
  %v51.i.i = insertvalue %struct.JsonError { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_next.sroa.18.0.copyload28.i.i, 1
  %v52.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v51.i.i, 2
  br label %liza_status.exit

b29.i.i:                                          ; preds = %b20.i.i
  %v55.i.i = icmp eq i32 %v35_mem.sroa.617.0.i.i, 0
  %v59.i.i = icmp eq i32 %v35_mem.sroa.412.0.i.i, 0
  %v60.not2.i.i = select i1 %v55.i.i, i1 %v59.i.i, i1 false
  %or.cond1.not.i.i = select i1 %v60.not2.i.i, i1 %.sink.off0, i1 false
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond1.not.i.i, label %b38.i.i, label %b36.i.i

b36.i.i:                                          ; preds = %b29.i.i
  %v67.i.i = insertvalue %struct.JsonError { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.2.0.i.i, 1
  %v68.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v67.i.i, 2
  br label %liza_status.exit

b38.i.i:                                          ; preds = %b29.i.i
  %v70.i.i = insertvalue %variant.5 zeroinitializer, i64 %v35_mem.sroa.2.0.i.i, 1
  br label %liza_status.exit

b19_to_b20.i.i:                                   ; preds = %b6.i.i
  %v35_next.sroa.4.0.p0.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %state, i64 48
  %s2sz691_p = getelementptr i64, ptr null, i32 1
  %s2sz691 = ptrtoint ptr %s2sz691_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.p0.sroa_idx.i.i, i64 %s2sz691)
  %v35_next.sroa.4.0.copyload25.i.i = load i64, ptr %v35_next.sroa.4.0.p0.sroa_idx.i.i, align 8
  %v35_next.sroa.8.0.p0.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %state, i64 120
  %s2sz692_p = getelementptr i32, ptr null, i32 1
  %s2sz692 = ptrtoint ptr %s2sz692_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.p0.sroa_idx.i.i, i64 %s2sz692)
  %v35_next.sroa.8.0.copyload26.i.i = load i32, ptr %v35_next.sroa.8.0.p0.sroa_idx.i.i, align 8
  %v35_next.sroa.10.0.p0.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %state, i64 124
  %s2sz693_p = getelementptr i8, ptr null, i32 1
  %s2sz693 = ptrtoint ptr %s2sz693_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.p0.sroa_idx.i.i, i64 %s2sz693)
  %5 = load i8, ptr %v35_next.sroa.10.0.p0.sroa_idx.i.i, align 4
  %extract.t2 = trunc i8 %5 to i1
  br label %b20.i.i

liza_status.exit:                                 ; preds = %b2.i.i, %b7.i.i, %b27.i.i, %b36.i.i, %b38.i.i
  %common.ret.op.i.i = phi %variant.5 [ %v3.i.i, %b2.i.i ], [ %v12.i.i, %b7.i.i ], [ %v52.i.i, %b27.i.i ], [ %v68.i.i, %b36.i.i ], [ %v70.i.i, %b38.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %v33_mem.i.i)
  %v1.i = extractvalue %variant.5 %common.ret.op.i.i, 0
  %6 = icmp eq i32 %v1.i, 0
  %v4.i = extractvalue %variant.5 %common.ret.op.i.i, 2
  %v5.i = extractvalue %struct.JsonError %v4.i, 0
  %v6.i = extractvalue %variant.1 %v5.i, 0
  %switch.offset.i = add nsw i32 %v6.i, 1
  %common.ret.op.i = select i1 %6, i32 0, i32 %switch.offset.i
  ret i32 %common.ret.op.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define range(i32 0, 2) i32 @stream_pending(ptr nofree   %state) local_unnamed_addr #3 {
  %v0_ptr.i.i = getelementptr i8, ptr %state, i64 168
  %s2sz694_p = getelementptr i32, ptr null, i32 1
  %s2sz694 = ptrtoint ptr %s2sz694_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr.i.i, i64 %s2sz694)
  %v0.i.i = load i32, ptr %v0_ptr.i.i, align 4
  %v2.i.not.i = icmp ne i32 %v0.i.i, 0
  %spec.select.i = zext i1 %v2.i.not.i to i32
  ret i32 %spec.select.i
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @stream_value(ptr nofree   %state) local_unnamed_addr #2 {
  %v33_mem.i.i = alloca %struct.JsonState, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %v33_mem.i.i)
  %v0_ptr.i.i.i = getelementptr i8, ptr %state, i64 168
  %s2sz695_p = getelementptr i32, ptr null, i32 1
  %s2sz695 = ptrtoint ptr %s2sz695_p to i64
  call void @s2_record(i32 0, ptr %v0_ptr.i.i.i, i64 %s2sz695)
  %v0.i.i.i = load i32, ptr %v0_ptr.i.i.i, align 4
  %v2.i.i.i = icmp eq i32 %v0.i.i.i, 0
  %state.sink.sroa.gep = getelementptr inbounds nuw i8, ptr %state, i64 160
  %state.sink.sroa.gep4 = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 160
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v2.i.i.i, label %liza_json.status.exit.i.i, label %b3.i.i.i

b3.i.i.i:                                         ; preds = %0
  %v7.i.i.i = icmp eq i32 %v0.i.i.i, 2
  %v9.i.i.i = select i1 %v7.i.i.i, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12.i.i.i = icmp eq i32 %v0.i.i.i, 3
  %v14.i.i.i = select i1 %v12.i.i.i, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9.i.i.i
  %v17.i.i.i = icmp eq i32 %v0.i.i.i, 4
  %v19.i.i.i = select i1 %v17.i.i.i, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14.i.i.i
  %v22.i.i.i = icmp eq i32 %v0.i.i.i, 5
  %v24.i.i.i = select i1 %v22.i.i.i, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19.i.i.i
  %v27.i.i.i = icmp eq i32 %v0.i.i.i, 6
  %v29.i.i.i = select i1 %v27.i.i.i, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24.i.i.i
  %v32.i.i.i = icmp eq i32 %v0.i.i.i, 7
  %v34.i.i.i = select i1 %v32.i.i.i, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29.i.i.i
  %v37.i.i.i = icmp eq i32 %v0.i.i.i, 8
  %v39.i.i.i = select i1 %v37.i.i.i, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34.i.i.i
  %v40_ptr.i.i.i = getelementptr i8, ptr %state, i64 176
  %s2sz696_p = getelementptr i64, ptr null, i32 1
  %s2sz696 = ptrtoint ptr %s2sz696_p to i64
  call void @s2_record(i32 0, ptr %v40_ptr.i.i.i, i64 %s2sz696)
  %v40.i.i.i = load i64, ptr %v40_ptr.i.i.i, align 8
  %v41_field0.i.i.i = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39.i.i.i, 0
  %v41.i.i.i = insertvalue %struct.JsonError %v41_field0.i.i.i, i64 %v40.i.i.i, 1
  %v42.i.i.i = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41.i.i.i, 1
  br label %liza_json.status.exit.i.i

liza_json.status.exit.i.i:                        ; preds = %b3.i.i.i, %0
  %common.ret.op.i.i.i = phi %variant.4 [ %v42.i.i.i, %b3.i.i.i ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %0 ]
  %v1.i.i = extractvalue %variant.4 %common.ret.op.i.i.i, 0
  %1 = icmp eq i32 %v1.i.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %1, label %b2.i.i, label %b4.i.i

b2.i.i:                                           ; preds = %liza_json.status.exit.i.i
  %v2.i.i = extractvalue %variant.4 %common.ret.op.i.i.i, 1
  %v3.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v2.i.i, 2
  br label %liza_value.exit

b4.i.i:                                           ; preds = %liza_json.status.exit.i.i
  %s2sz697_p = getelementptr %struct.Utf8StreamState, ptr null, i32 1
  %s2sz697 = ptrtoint ptr %s2sz697_p to i64
  call void @s2_record(i32 0, ptr %state, i64 %s2sz697)
  %v4.i.i = load %struct.Utf8StreamState, ptr %state, align 8
  %v0.i3.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 6
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v0.i3.i.i, label %b6.i.i.i [
    i32 1, label %b1.i.i.i
    i32 2, label %b4.i.i.i
  ]

b1.i.i.i:                                         ; preds = %b4.i.i
  %v4.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 7
  %v5.i.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i.i.i, 1
  %v6.i.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5.i.i.i, 2
  br label %liza_utf8_stream.finish.exit.i.i

b4.i.i.i:                                         ; preds = %b4.i.i
  %v11.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 7
  %v12.i4.i.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i.i.i, 1
  %v13.i.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12.i4.i.i, 2
  br label %liza_utf8_stream.finish.exit.i.i

b6.i.i.i:                                         ; preds = %b4.i.i
  %v14.i6.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 3
  %v16.not.i.i.i = icmp eq i32 %v14.i6.i.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %v16.not.i.i.i, label %b9.i.i.i, label %b7.i.i.i

b7.i.i.i:                                         ; preds = %b6.i.i.i
  %v18.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 2
  %v19.i7.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18.i.i.i, 1
  %v20.i.i.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19.i7.i.i, 2
  br label %liza_utf8_stream.finish.exit.i.i

b9.i.i.i:                                         ; preds = %b6.i.i.i
  %v21.i.i.i = extractvalue %struct.Utf8StreamState %v4.i.i, 1
  %v22.i8.i.i = insertvalue %variant.2 zeroinitializer, i64 %v21.i.i.i, 1
  br label %liza_utf8_stream.finish.exit.i.i

liza_utf8_stream.finish.exit.i.i:                 ; preds = %b9.i.i.i, %b7.i.i.i, %b4.i.i.i, %b1.i.i.i
  %common.ret.op.i5.i.i = phi %variant.2 [ %v6.i.i.i, %b1.i.i.i ], [ %v13.i.i.i, %b4.i.i.i ], [ %v20.i.i.i, %b7.i.i.i ], [ %v22.i8.i.i, %b9.i.i.i ]
  %v6.i.i = extractvalue %variant.2 %common.ret.op.i5.i.i, 0
  %2 = icmp eq i32 %v6.i.i, 0
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %2, label %b6.i.i, label %b7.i.i

b6.i.i:                                           ; preds = %liza_utf8_stream.finish.exit.i.i
  %v13_ptr.i.i = getelementptr i8, ptr %state, i64 128
  %s2sz698_p = getelementptr i32, ptr null, i32 1
  %s2sz698 = ptrtoint ptr %s2sz698_p to i64
  call void @s2_record(i32 0, ptr %v13_ptr.i.i, i64 %s2sz698)
  %v13.i.i = load i32, ptr %v13_ptr.i.i, align 8
  call void @s2_record(i32 2, ptr null, i64 0)
  switch i32 %v13.i.i, label %b19_to_b20.i.i [
    i32 11, label %b18.i.i
    i32 12, label %b18.i.i
    i32 14, label %b18.i.i
    i32 17, label %b18.i.i
  ]

b7.i.i:                                           ; preds = %liza_utf8_stream.finish.exit.i.i
  %v8.i.i = extractvalue %variant.2 %common.ret.op.i5.i.i, 2
  %v10.i.i = extractvalue %struct.Utf8StreamError %v8.i.i, 1
  %v11.i.i = insertvalue %struct.JsonError { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v10.i.i, 1
  %v12.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v11.i.i, 2
  br label %liza_value.exit

b18.i.i:                                          ; preds = %b6.i.i, %b6.i.i, %b6.i.i, %b6.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(184) %v33_mem.i.i, ptr noundef nonnull  align 1 dereferenceable(184) %state, i64 184, i1 false)
  %v33_part.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 128
  %s2sz699_p = getelementptr i32, ptr null, i32 1
  %s2sz699 = ptrtoint ptr %s2sz699_p to i64
  call void @s2_record(i32 1, ptr %v33_part.i.i, i64 %s2sz699)
  store i32 0, ptr %v33_part.i.i, align 8
  call void @liza___liza_owned___liza_json_done(ptr nonnull sret(%struct.JsonState) %v33_mem.i.i, ptr nonnull poison)
  %v35_next.sroa.4.0.v33_mem.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 48
  %s2sz700_p = getelementptr i64, ptr null, i32 1
  %s2sz700 = ptrtoint ptr %s2sz700_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i.i, i64 %s2sz700)
  %v35_next.sroa.4.0.copyload.i.i = load i64, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx.i.i, align 8
  %v35_next.sroa.8.0.v33_mem.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 120
  %s2sz701_p = getelementptr i32, ptr null, i32 1
  %s2sz701 = ptrtoint ptr %s2sz701_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i.i, i64 %s2sz701)
  %v35_next.sroa.8.0.copyload.i.i = load i32, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx.i.i, align 8
  %v35_next.sroa.10.0.v33_mem.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %v33_mem.i.i, i64 124
  %s2sz702_p = getelementptr i8, ptr null, i32 1
  %s2sz702 = ptrtoint ptr %s2sz702_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i.i, i64 %s2sz702)
  %3 = load i8, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx.i.i, align 4
  %s2sz703_p = getelementptr i32, ptr null, i32 1
  %s2sz703 = ptrtoint ptr %s2sz703_p to i64
  call void @s2_record(i32 0, ptr %v33_part.i.i, i64 %s2sz703)
  %v35_next.sroa.14.0.copyload.i.i = load i32, ptr %v33_part.i.i, align 8
  %extract.t3 = trunc i8 %3 to i1
  br label %b20.i.i

b20.i.i:                                          ; preds = %b19_to_b20.i.i, %b18.i.i
  %state.sink.sroa.phi = phi ptr [ %state.sink.sroa.gep, %b19_to_b20.i.i ], [ %state.sink.sroa.gep4, %b18.i.i ]
  %.sink.off0 = phi i1 [ %extract.t2, %b19_to_b20.i.i ], [ %extract.t3, %b18.i.i ]
  %v35_mem.sroa.617.0.i.i = phi i32 [ %v13.i.i, %b19_to_b20.i.i ], [ %v35_next.sroa.14.0.copyload.i.i, %b18.i.i ]
  %v35_mem.sroa.412.0.i.i = phi i32 [ %v35_next.sroa.8.0.copyload26.i.i, %b19_to_b20.i.i ], [ %v35_next.sroa.8.0.copyload.i.i, %b18.i.i ]
  %v35_mem.sroa.2.0.i.i = phi i64 [ %v35_next.sroa.4.0.copyload25.i.i, %b19_to_b20.i.i ], [ %v35_next.sroa.4.0.copyload.i.i, %b18.i.i ]
  %4 = add i32 %v35_mem.sroa.617.0.i.i, -4
  %or.cond.i.i = icmp ult i32 %4, 3
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond.i.i, label %b27.i.i, label %b29.i.i

b27.i.i:                                          ; preds = %b20.i.i
  %s2sz704_p = getelementptr i64, ptr null, i32 1
  %s2sz704 = ptrtoint ptr %s2sz704_p to i64
  call void @s2_record(i32 0, ptr %state.sink.sroa.phi, i64 %s2sz704)
  %v35_next.sroa.18.0.copyload28.i.i = load i64, ptr %state.sink.sroa.phi, align 8
  %v51.i.i = insertvalue %struct.JsonError { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_next.sroa.18.0.copyload28.i.i, 1
  %v52.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v51.i.i, 2
  br label %liza_value.exit

b29.i.i:                                          ; preds = %b20.i.i
  %v55.i.i = icmp eq i32 %v35_mem.sroa.617.0.i.i, 0
  %v59.i.i = icmp eq i32 %v35_mem.sroa.412.0.i.i, 0
  %v60.not2.i.i = select i1 %v55.i.i, i1 %v59.i.i, i1 false
  %or.cond1.not.i.i = select i1 %v60.not2.i.i, i1 %.sink.off0, i1 false
  call void @s2_record(i32 2, ptr null, i64 0)
  br i1 %or.cond1.not.i.i, label %b38.i.i, label %b36.i.i

b36.i.i:                                          ; preds = %b29.i.i
  %v67.i.i = insertvalue %struct.JsonError { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.2.0.i.i, 1
  %v68.i.i = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v67.i.i, 2
  br label %liza_value.exit

b38.i.i:                                          ; preds = %b29.i.i
  %v70.i.i = insertvalue %variant.5 zeroinitializer, i64 %v35_mem.sroa.2.0.i.i, 1
  br label %liza_value.exit

b19_to_b20.i.i:                                   ; preds = %b6.i.i
  %v35_next.sroa.4.0.p0.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %state, i64 48
  %s2sz705_p = getelementptr i64, ptr null, i32 1
  %s2sz705 = ptrtoint ptr %s2sz705_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.4.0.p0.sroa_idx.i.i, i64 %s2sz705)
  %v35_next.sroa.4.0.copyload25.i.i = load i64, ptr %v35_next.sroa.4.0.p0.sroa_idx.i.i, align 8
  %v35_next.sroa.8.0.p0.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %state, i64 120
  %s2sz706_p = getelementptr i32, ptr null, i32 1
  %s2sz706 = ptrtoint ptr %s2sz706_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.8.0.p0.sroa_idx.i.i, i64 %s2sz706)
  %v35_next.sroa.8.0.copyload26.i.i = load i32, ptr %v35_next.sroa.8.0.p0.sroa_idx.i.i, align 8
  %v35_next.sroa.10.0.p0.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %state, i64 124
  %s2sz707_p = getelementptr i8, ptr null, i32 1
  %s2sz707 = ptrtoint ptr %s2sz707_p to i64
  call void @s2_record(i32 0, ptr %v35_next.sroa.10.0.p0.sroa_idx.i.i, i64 %s2sz707)
  %5 = load i8, ptr %v35_next.sroa.10.0.p0.sroa_idx.i.i, align 4
  %extract.t2 = trunc i8 %5 to i1
  br label %b20.i.i

liza_value.exit:                                  ; preds = %b2.i.i, %b7.i.i, %b27.i.i, %b36.i.i, %b38.i.i
  %common.ret.op.i.i = phi %variant.5 [ %v3.i.i, %b2.i.i ], [ %v12.i.i, %b7.i.i ], [ %v52.i.i, %b27.i.i ], [ %v68.i.i, %b36.i.i ], [ %v70.i.i, %b38.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %v33_mem.i.i)
  %v1.i = extractvalue %variant.5 %common.ret.op.i.i, 0
  %6 = icmp eq i32 %v1.i, 0
  %v2.i = extractvalue %variant.5 %common.ret.op.i.i, 1
  %v3.i = extractvalue %variant.5 %common.ret.op.i.i, 2
  %v4.i = extractvalue %struct.JsonError %v3.i, 1
  %common.ret.op.i = select i1 %6, i64 %v2.i, i64 %v4.i
  ret i64 %common.ret.op.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i64 @stream_size() local_unnamed_addr #6 {
  ret i64 184
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr  writeonly , ptr   , i64, i1 immarg) #9

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #9

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #9

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly , i8, i64, i1 immarg) #10

attributes #0 = { cold noreturn nounwind  }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn  }
attributes #2 = { nounwind  }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn  }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn  }
attributes #5 = { nounwind  }
attributes #6 = { mustprogress nofree norecurse nosync nounwind willreturn  }
attributes #7 = { nounwind  }
attributes #8 = { nounwind  }
attributes #9 = { nocallback nofree nosync nounwind willreturn  }
attributes #10 = { nocallback nofree nosync nounwind willreturn  }
declare void @s2_begin(ptr, i64)
declare void @s2_end()
declare void @s2_record(i32, ptr, i64)
