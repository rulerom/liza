#include <stdint.h>
#include <stdio.h>
extern uint64_t replay_changed(void);extern uint64_t liza_increment(uint64_t);
int main(int argc,char**argv){printf("%llu\n",(unsigned long long)(argc>1?liza_increment(UINT64_MAX):replay_changed()));return 0;}
