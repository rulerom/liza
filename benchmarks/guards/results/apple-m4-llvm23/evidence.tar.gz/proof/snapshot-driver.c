#include <stdbool.h>
extern unsigned snapshot_probe(bool);
int main(void){return snapshot_probe(false)|snapshot_probe(true);}