	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_status                    ; -- Begin function liza_status
	.p2align	2
_liza_status:                           ; @liza_status
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csinc	w0, wzr, w2, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_liza_value                     ; -- Begin function liza_value
	.p2align	2
_liza_value:                            ; @liza_value
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csel	x0, x1, x3, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_liza_pending                   ; -- Begin function liza_pending
	.p2align	2
_liza_pending:                          ; @liza_pending
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_liza_start                     ; -- Begin function liza_start
	.p2align	2
_liza_start:                            ; @liza_start
; %bb.0:                                ; %b0
	sub	sp, sp, #144
	movi.2d	v0, #0000000000000000
	str	wzr, [sp, #132]
	mov	w9, #49024                      ; =0xbf80
	strh	w9, [x8, #28]
	stur	wzr, [sp, #44]
	strb	wzr, [sp, #140]
	stur	q0, [sp, #68]
	stur	q0, [sp, #84]
	stur	q0, [sp, #100]
	stur	q0, [sp, #52]
	stur	q0, [sp, #116]
	stur	q0, [sp, #12]
	ldr	x9, [sp, #128]
	stur	q0, [sp, #28]
	ldp	q0, q1, [sp, #80]
	stur	x9, [x8, #116]
	ldur	x9, [sp, #40]
	strb	wzr, [sp, #136]
	stur	q0, [x8, #68]
	ldr	q0, [sp, #112]
	stur	q1, [x8, #84]
	stur	q0, [x8, #100]
	ldp	q0, q1, [sp, #48]
	stp	xzr, xzr, [x8]
	str	wzr, [x8, #24]
	stur	q0, [x8, #36]
	ldur	q0, [sp, #25]
	stur	q1, [x8, #52]
	ldur	q1, [sp, #9]
	str	xzr, [x8, #16]
	str	wzr, [x8, #32]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	stur	x9, [x8, #164]
	stur	q0, [x8, #149]
	stur	q1, [x8, #133]
	str	xzr, [x8, #176]
	add	sp, sp, #144
	ret
                                        ; -- End function
	.globl	_liza_feed                      ; -- Begin function liza_feed
	.p2align	2
_liza_feed:                             ; @liza_feed
; %bb.0:                                ; %b0
	sub	sp, sp, #224
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	mov	x19, x8
	add	x8, sp, #8
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	bl	_liza_json.feed
	ldur	q0, [sp, #136]
	ldur	q1, [sp, #152]
	ldur	q2, [sp, #168]
	ldr	x8, [sp, #184]
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	stp	q0, q1, [x19, #128]
	ldur	q0, [sp, #72]
	ldur	q1, [sp, #88]
	str	q2, [x19, #160]
	ldur	q2, [sp, #104]
	stp	q0, q1, [x19, #64]
	ldur	q0, [sp, #120]
	ldur	q1, [sp, #8]
	str	x8, [x19, #176]
	stp	q2, q0, [x19, #96]
	ldur	q0, [sp, #24]
	ldur	q2, [sp, #40]
	stp	q1, q0, [x19]
	ldur	q0, [sp, #56]
	stp	q2, q0, [x19, #32]
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
; %bb.0:                                ; %b0
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.create        ; -- Begin function liza_utf8_stream.create
	.p2align	2
_liza_utf8_stream.create:               ; @liza_utf8_stream.create
; %bb.0:                                ; %b0
	mov	x0, xzr
	mov	x1, xzr
	mov	x2, xzr
	mov	w3, wzr
	mov	w4, #128                        ; =0x80
	mov	w5, #191                        ; =0xbf
	mov	w6, wzr
	mov	x7, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.feed_byte     ; -- Begin function liza_utf8_stream.feed_byte
	.p2align	2
_liza_utf8_stream.feed_byte:            ; @liza_utf8_stream.feed_byte
; %bb.0:                                ; %b0
	cbz	w6, LBB7_2
LBB7_1:                                 ; %common.ret
	ret
LBB7_2:                                 ; %b3
	cmn	x0, #1
	b.eq	LBB7_9
; %bb.3:                                ; %b6
	ldrb	w8, [sp]
	cbz	w3, LBB7_10
; %bb.4:                                ; %b8
	and	w8, w8, #0xff
	cmp	w8, w4, uxtb
	b.lo	LBB7_13
; %bb.5:                                ; %b8
	cmp	w8, w5, uxtb
	b.hi	LBB7_13
; %bb.6:                                ; %v115_ok
	subs	w3, w3, #1
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	b.ne	LBB7_24
; %bb.7:                                ; %b51
	cmn	x1, #1
	b.eq	LBB7_20
; %bb.8:                                ; %v138_ok
	add	x1, x1, #1
	b	LBB7_24
LBB7_9:                                 ; %b4
	mov	x7, #-1                         ; =0xffffffffffffffff
	mov	w6, #2                          ; =0x2
	ret
LBB7_10:                                ; %b7
	tbnz	w8, #7, LBB7_14
; %bb.11:                               ; %b9
	cmn	x1, #1
	b.eq	LBB7_16
; %bb.12:                               ; %v32_ok
	add	x1, x1, #1
	mov	x2, x0
	b	LBB7_24
LBB7_13:                                ; %b48
	mov	w6, #1                          ; =0x1
	mov	x7, x2
	ret
LBB7_14:                                ; %b10
	add	w9, w8, #62
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	and	w9, w9, #0xff
	cmp	w9, #30
	b.hs	LBB7_18
; %bb.15:                               ; %b17
	mov	w3, #1                          ; =0x1
	mov	x2, x0
	b	LBB7_24
LBB7_16:                                ; %b11
	mov	w6, #2                          ; =0x2
LBB7_17:                                ; %common.ret
	mov	x2, x0
	mov	x7, x0
	ret
LBB7_18:                                ; %b18
	and	w9, w8, #0xf0
	cmp	w9, #224
	b.ne	LBB7_21
; %bb.19:                               ; %b22
	and	w8, w8, #0xff
	mov	w9, #-96                        ; =0xffffffa0
	mov	w3, #2                          ; =0x2
	cmp	w8, #224
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #237
	mov	w8, #-97                        ; =0xffffff9f
	b	LBB7_23
LBB7_20:                                ; %b53
	mov	w6, #2                          ; =0x2
	mov	x7, x0
	ret
LBB7_21:                                ; %b23
	add	w9, w8, #16
	and	w9, w9, #0xff
	cmp	w9, #4
	b.hi	LBB7_26
; %bb.22:                               ; %b33
	and	w8, w8, #0xff
	mov	w9, #-112                       ; =0xffffff90
	mov	w3, #3                          ; =0x3
	cmp	w8, #240
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #244
	mov	w8, #-113                       ; =0xffffff8f
LBB7_23:                                ; %b57
	csel	w5, w8, w5, eq
LBB7_24:                                ; %b57
	adds	x0, x0, #1
	b.lo	LBB7_1
; %bb.25:                               ; %v145_trap
	brk	#0x1
LBB7_26:                                ; %b34
	mov	w6, #1                          ; =0x1
	b	LBB7_17
                                        ; -- End function
	.globl	_liza_utf8_stream.finish        ; -- Begin function liza_utf8_stream.finish
	.p2align	2
_liza_utf8_stream.finish:               ; @liza_utf8_stream.finish
; %bb.0:                                ; %b0
	cmp	w6, #1
	b.eq	LBB8_3
; %bb.1:                                ; %b0
	cmp	w6, #2
	b.ne	LBB8_4
; %bb.2:                                ; %b4
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_3:                                 ; %b1
	mov	x1, xzr
	b	LBB8_6
LBB8_4:                                 ; %b6
	cbz	w3, LBB8_7
; %bb.5:                                ; %b7
	mov	x1, xzr
	mov	x7, x2
LBB8_6:                                 ; %common.ret
	mov	w2, wzr
	mov	w0, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_7:                                 ; %b9
	mov	w0, wzr
	mov	w2, wzr
	mov	x3, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.status        ; -- Begin function liza_utf8_stream.status
	.p2align	2
_liza_utf8_stream.status:               ; @liza_utf8_stream.status
; %bb.0:                                ; %b0
	mov	w8, #1                          ; =0x1
	cmp	w6, #2
	mov	w9, #1                          ; =0x1
	csel	w8, wzr, w8, eq
	csel	w9, w9, wzr, eq
	csel	x10, x7, xzr, eq
	cmp	w6, #1
	csel	w0, wzr, w8, eq
	csel	w1, wzr, w9, eq
	csel	x2, x7, x10, eq
	ret
                                        ; -- End function
	.globl	_liza_json.create               ; -- Begin function liza_json.create
	.p2align	2
_liza_json.create:                      ; @liza_json.create
; %bb.0:                                ; %b0
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w9, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8]
	str	wzr, [x8, #24]
	strh	w9, [x8, #28]
	str	wzr, [x8, #32]
	stur	q0, [x8, #40]
	stur	q0, [x8, #56]
	stur	q0, [x8, #72]
	stur	q0, [x8, #88]
	stur	q0, [x8, #104]
	str	wzr, [x8, #120]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	str	xzr, [x8, #176]
	str	wzr, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_liza___liza_json_fail          ; -- Begin function liza___liza_json_fail
	.p2align	2
_liza___liza_json_fail:                 ; @liza___liza_json_fail
; %bb.0:                                ; %b0
	ldp	q0, q1, [x0]
	ldr	x9, [x0, #160]
	ldp	q2, q3, [x0, #32]
	ldr	w10, [x0, #172]
	ldp	q4, q5, [x0, #64]
	ldp	q6, q7, [x0, #128]
	ldp	q16, q17, [x0, #96]
	str	x9, [x8, #160]
	stp	q0, q1, [x8]
	stp	q2, q3, [x8, #32]
	stp	q4, q5, [x8, #64]
	stp	q16, q17, [x8, #96]
	stp	q6, q7, [x8, #128]
	stp	w1, w10, [x8, #168]
	str	x2, [x8, #176]
	ret
                                        ; -- End function
	.globl	_liza___liza_json_done          ; -- Begin function liza___liza_json_done
	.p2align	2
_liza___liza_json_done:                 ; @liza___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #688
	ldr	w20, [x0, #120]
	add	x13, sp, #304
	cbz	w20, LBB12_5
; %bb.1:                                ; %b2
	ldrb	w9, [x0, #57]
	ldrb	w10, [x0, #59]
	sub	w21, w20, #1
	ldrb	w11, [x0, #61]
	ldrb	w23, [x0, #56]
	cmp	w21, #64
	stp	w10, w9, [sp, #168]             ; 8-byte Folded Spill
	ldrb	w22, [x0, #58]
	ldrb	w24, [x0, #98]
	strb	w9, [sp, #177]
	ldrb	w9, [x0, #60]
	ldrb	w25, [x0, #99]
	strb	w10, [sp, #179]
	ldrb	w10, [x0, #62]
	ldrb	w26, [x0, #100]
	stp	w11, w9, [sp, #160]             ; 8-byte Folded Spill
	ldrb	w27, [x0, #101]
	ldrb	w28, [x0, #102]
	strb	w9, [sp, #180]
	ldrb	w9, [x0, #63]
	ldrb	w30, [x0, #103]
	strb	w11, [sp, #181]
	ldrb	w11, [x0, #64]
	ldrb	w12, [x0, #107]
	stp	w9, w10, [sp, #152]             ; 8-byte Folded Spill
	ldrb	w13, [x0, #108]
	ldrb	w14, [x0, #109]
	strb	w10, [sp, #182]
	ldrb	w10, [x0, #65]
	ldrb	w15, [x0, #110]
	strb	w9, [sp, #183]
	ldrb	w9, [x0, #66]
	ldrb	w16, [x0, #111]
	stp	w10, w11, [sp, #144]            ; 8-byte Folded Spill
	ldrb	w17, [x0, #112]
	ldrb	w2, [x0, #113]
	strb	w11, [sp, #184]
	ldrb	w11, [x0, #67]
	ldrb	w3, [x0, #114]
	strb	w10, [sp, #185]
	ldrb	w10, [x0, #68]
	ldrb	w4, [x0, #115]
	stp	w11, w9, [sp, #136]             ; 8-byte Folded Spill
	ldrb	w5, [x0, #116]
	ldrb	w6, [x0, #117]
	strb	w9, [sp, #186]
	ldrb	w9, [x0, #69]
	ldrb	w7, [x0, #118]
	strb	w11, [sp, #187]
	ldrb	w11, [x0, #70]
	ldrb	w19, [x0, #119]
	stp	w9, w10, [sp, #128]             ; 8-byte Folded Spill
	strb	w10, [sp, #188]
	ldrb	w10, [x0, #71]
	strb	w9, [sp, #189]
	ldrb	w9, [x0, #72]
	stp	w10, w11, [sp, #120]            ; 8-byte Folded Spill
	strb	w11, [sp, #190]
	ldrb	w11, [x0, #73]
	strb	w10, [sp, #191]
	ldrb	w10, [x0, #74]
	stp	w11, w9, [sp, #112]             ; 8-byte Folded Spill
	strb	w9, [sp, #192]
	ldrb	w9, [x0, #75]
	strb	w11, [sp, #193]
	ldrb	w11, [x0, #76]
	stp	w9, w10, [sp, #104]             ; 8-byte Folded Spill
	strb	w10, [sp, #194]
	ldrb	w10, [x0, #77]
	strb	w9, [sp, #195]
	ldrb	w9, [x0, #78]
	stp	w10, w11, [sp, #96]             ; 8-byte Folded Spill
	strb	w11, [sp, #196]
	ldrb	w11, [x0, #79]
	strb	w10, [sp, #197]
	ldrb	w10, [x0, #80]
	stp	w11, w9, [sp, #88]              ; 8-byte Folded Spill
	strb	w9, [sp, #198]
	ldrb	w9, [x0, #81]
	strb	w11, [sp, #199]
	ldrb	w11, [x0, #82]
	stp	w9, w10, [sp, #80]              ; 8-byte Folded Spill
	strb	w10, [sp, #200]
	ldrb	w10, [x0, #83]
	strb	w9, [sp, #201]
	ldrb	w9, [x0, #84]
	stp	w10, w11, [sp, #72]             ; 8-byte Folded Spill
	strb	w11, [sp, #202]
	ldrb	w11, [x0, #85]
	strb	w10, [sp, #203]
	ldrb	w10, [x0, #87]
	stp	w11, w9, [sp, #64]              ; 8-byte Folded Spill
	strb	w9, [sp, #204]
	ldrb	w9, [x0, #86]
	strb	w10, [sp, #207]
	stp	w10, w9, [sp, #56]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #89]
	strb	w9, [sp, #206]
	ldrb	w9, [x0, #88]
	strb	w10, [sp, #209]
	stp	w10, w9, [sp, #48]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #91]
	strb	w9, [sp, #208]
	ldrb	w9, [x0, #90]
	strb	w10, [sp, #211]
	stp	w10, w9, [sp, #40]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #93]
	strb	w9, [sp, #210]
	ldrb	w9, [x0, #92]
	strb	w10, [sp, #213]
	stp	w10, w9, [sp, #32]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #95]
	strb	w9, [sp, #212]
	ldrb	w9, [x0, #94]
	strb	w10, [sp, #215]
	stp	w10, w9, [sp, #24]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #97]
	strb	w9, [sp, #214]
	ldrb	w9, [x0, #96]
	strb	w11, [sp, #205]
	ldrb	w11, [x0, #106]
	stp	w10, w9, [sp, #16]              ; 8-byte Folded Spill
	strb	w9, [sp, #216]
	ldrb	w9, [x0, #104]
	strb	w10, [sp, #217]
	ldrb	w10, [x0, #105]
	strb	w23, [sp, #176]
	strb	w22, [sp, #178]
	strb	w24, [sp, #218]
	strb	w25, [sp, #219]
	strb	w26, [sp, #220]
	strb	w27, [sp, #221]
	strb	w28, [sp, #222]
	strb	w30, [sp, #223]
	strb	w9, [sp, #224]
	strb	w10, [sp, #225]
	strb	w11, [sp, #226]
	strb	w12, [sp, #227]
	strb	w13, [sp, #228]
	strb	w14, [sp, #229]
	strb	w15, [sp, #230]
	strb	w16, [sp, #231]
	strb	w17, [sp, #232]
	strb	w2, [sp, #233]
	strb	w3, [sp, #234]
	strb	w4, [sp, #235]
	strb	w5, [sp, #236]
	strb	w6, [sp, #237]
	strb	w7, [sp, #238]
	strb	w19, [sp, #239]
	b.hs	LBB12_7
; %bb.2:                                ; %v10_ok
	add	x1, sp, #176
	add	x20, sp, #620
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	mov	w1, #2                          ; =0x2
	b.eq	LBB12_4
; %bb.3:                                ; %b3
	strb	w23, [sp, #240]
	mov	w23, w22
	ldr	w22, [sp, #172]                 ; 4-byte Folded Reload
	strb	w23, [sp, #242]
	strb	w22, [sp, #241]
	ldr	w22, [sp, #168]                 ; 4-byte Folded Reload
	strb	w24, [sp, #282]
	strb	w22, [sp, #243]
	ldr	w22, [sp, #164]                 ; 4-byte Folded Reload
	strb	w25, [sp, #283]
	strb	w22, [sp, #244]
	ldr	w22, [sp, #160]                 ; 4-byte Folded Reload
	strb	w26, [sp, #284]
	strb	w22, [sp, #245]
	ldr	w22, [sp, #156]                 ; 4-byte Folded Reload
	strb	w27, [sp, #285]
	strb	w22, [sp, #246]
	ldr	w22, [sp, #152]                 ; 4-byte Folded Reload
	strb	w28, [sp, #286]
	strb	w22, [sp, #247]
	ldr	w22, [sp, #148]                 ; 4-byte Folded Reload
	strb	w30, [sp, #287]
	strb	w22, [sp, #248]
	ldr	w22, [sp, #144]                 ; 4-byte Folded Reload
	strb	w9, [sp, #288]
	add	x9, sp, #240
	strb	w22, [sp, #249]
	ldr	w22, [sp, #140]                 ; 4-byte Folded Reload
	strb	w10, [sp, #289]
	mov	w10, #7                         ; =0x7
	strb	w22, [sp, #250]
	ldr	w22, [sp, #136]                 ; 4-byte Folded Reload
	strb	w11, [sp, #290]
	strb	w22, [sp, #251]
	ldr	w22, [sp, #132]                 ; 4-byte Folded Reload
	strb	w12, [sp, #291]
	strb	w22, [sp, #252]
	ldr	w22, [sp, #128]                 ; 4-byte Folded Reload
	strb	w13, [sp, #292]
	strb	w22, [sp, #253]
	ldr	w22, [sp, #124]                 ; 4-byte Folded Reload
	strb	w14, [sp, #293]
	strb	w22, [sp, #254]
	ldr	w22, [sp, #120]                 ; 4-byte Folded Reload
	strb	w15, [sp, #294]
	strb	w22, [sp, #255]
	ldr	w22, [sp, #116]                 ; 4-byte Folded Reload
	strb	w16, [sp, #295]
	strb	w22, [sp, #256]
	ldr	w22, [sp, #112]                 ; 4-byte Folded Reload
	strb	w17, [sp, #296]
	strb	w22, [sp, #257]
	ldr	w22, [sp, #108]                 ; 4-byte Folded Reload
	strb	w2, [sp, #297]
	strb	w22, [sp, #258]
	ldr	w22, [sp, #104]                 ; 4-byte Folded Reload
	strb	w3, [sp, #298]
	strb	w22, [sp, #259]
	ldr	w22, [sp, #100]                 ; 4-byte Folded Reload
	strb	w4, [sp, #299]
	strb	w22, [sp, #260]
	ldr	w22, [sp, #96]                  ; 4-byte Folded Reload
	strb	w5, [sp, #300]
	strb	w22, [sp, #261]
	ldr	w22, [sp, #92]                  ; 4-byte Folded Reload
	strb	w6, [sp, #301]
	strb	w22, [sp, #262]
	ldr	w22, [sp, #88]                  ; 4-byte Folded Reload
	strb	w7, [sp, #302]
	strb	w22, [sp, #263]
	ldr	w22, [sp, #84]                  ; 4-byte Folded Reload
	strb	w19, [sp, #303]
	strb	w22, [sp, #264]
	ldr	w22, [sp, #80]                  ; 4-byte Folded Reload
	strb	w22, [sp, #265]
	ldr	w22, [sp, #76]                  ; 4-byte Folded Reload
	strb	w22, [sp, #266]
	ldr	w22, [sp, #72]                  ; 4-byte Folded Reload
	strb	w22, [sp, #267]
	ldr	w22, [sp, #68]                  ; 4-byte Folded Reload
	strb	w22, [sp, #268]
	ldr	w22, [sp, #64]                  ; 4-byte Folded Reload
	strb	w22, [sp, #269]
	ldr	w22, [sp, #60]                  ; 4-byte Folded Reload
	strb	w22, [sp, #270]
	ldr	w22, [sp, #56]                  ; 4-byte Folded Reload
	strb	w22, [sp, #271]
	ldr	w22, [sp, #52]                  ; 4-byte Folded Reload
	strb	w22, [sp, #272]
	ldr	w22, [sp, #48]                  ; 4-byte Folded Reload
	strb	w22, [sp, #273]
	ldr	w22, [sp, #44]                  ; 4-byte Folded Reload
	strb	w22, [sp, #274]
	ldr	w22, [sp, #40]                  ; 4-byte Folded Reload
	strb	w22, [sp, #275]
	ldr	w22, [sp, #36]                  ; 4-byte Folded Reload
	strb	w22, [sp, #276]
	ldr	w22, [sp, #32]                  ; 4-byte Folded Reload
	strb	w22, [sp, #277]
	ldr	w22, [sp, #28]                  ; 4-byte Folded Reload
	strb	w22, [sp, #278]
	ldr	w22, [sp, #24]                  ; 4-byte Folded Reload
	strb	w22, [sp, #279]
	ldr	w22, [sp, #20]                  ; 4-byte Folded Reload
	strb	w22, [sp, #280]
	ldr	w22, [sp, #16]                  ; 4-byte Folded Reload
	strb	w22, [sp, #281]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	add	x9, sp, #556
	csel	x20, x20, x9, eq
	csel	w1, w1, w10, eq
LBB12_4:                                ; %b8_to_b9
	ldur	q0, [x0, #56]
	ldur	q1, [x0, #72]
	add	x13, sp, #304
	ldur	q2, [x0, #88]
	ldur	q3, [x0, #168]
	add	x11, sp, #432
	stp	q0, q1, [x20]
	ldur	q0, [x0, #104]
	ldr	x9, [x0, #48]
	stur	q3, [x13, #171]
	ldur	q4, [x0, #157]
	ldur	q5, [x0, #141]
	stp	q2, q0, [x20, #32]
	ldr	q2, [x0]
	ldur	q6, [x0, #125]
	strb	w1, [x20, x21]
	ldrb	w10, [x0, #124]
	str	q2, [sp, #496]
	ldp	q1, q0, [x0, #16]
	str	x9, [sp, #544]
	ldr	w9, [x0, #120]
	add	x0, sp, #496
	stp	q5, q4, [sp, #448]
	ldp	q2, q3, [x20, #32]
	stp	q1, q0, [sp, #512]
	ldp	q0, q1, [x20]
	str	q6, [sp, #432]
	b	LBB12_6
LBB12_5:                                ; %b1
	ldur	q0, [x0, #56]
	ldur	q1, [x0, #72]
	mov	w10, #1                         ; =0x1
	ldur	q2, [x0, #88]
	ldur	q3, [x0, #104]
	mov	w9, wzr
	add	x11, x0, #125
	strb	w10, [sp, #684]
LBB12_6:                                ; %b9
	ldp	q6, q7, [x11]
	ldr	q16, [x0, #32]
	ldp	q4, q5, [x0]
	ldr	x12, [x0, #48]
	str	q16, [sp, #400]
	stp	q6, q7, [sp, #304]
	ldr	q6, [x11, #32]
	stp	q4, q5, [sp, #368]
	str	q6, [sp, #336]
	ldur	q6, [x11, #43]
	stur	q0, [x8, #56]
	stur	q6, [x13, #43]
	ldur	q0, [x13, #43]
	stur	q1, [x8, #72]
	str	x12, [sp, #416]
	stur	q0, [x8, #168]
	ldp	q0, q1, [sp, #320]
	stp	q4, q5, [x8]
	str	q16, [x8, #32]
	stur	q1, [x8, #157]
	ldr	q1, [sp, #304]
	str	x12, [x8, #48]
	stur	q2, [x8, #88]
	stur	q3, [x8, #104]
	str	w9, [x8, #120]
	strb	w10, [x8, #124]
	stur	q0, [x8, #141]
	stur	q1, [x8, #125]
	add	sp, sp, #688
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB12_7:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_json_space         ; -- Begin function liza___liza_json_space
	.p2align	2
_liza___liza_json_space:                ; @liza___liza_json_space
; %bb.0:                                ; %b0
	mov	x8, #9728                       ; =0x2600
                                        ; kill: def $w0 killed $w0 def $x0
	and	w9, w0, #0xff
	movk	x8, #1, lsl #32
	cmp	w9, #33
	lsr	x8, x8, x0
	cset	w9, lo
	and	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza___liza_json_digit         ; -- Begin function liza___liza_json_digit
	.p2align	2
_liza___liza_json_digit:                ; @liza___liza_json_digit
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w8, w8, #48
	cmp	w8, #10
	cset	w0, lo
	ret
                                        ; -- End function
	.globl	_liza___liza_json_hex           ; -- Begin function liza___liza_json_hex
	.p2align	2
_liza___liza_json_hex:                  ; @liza___liza_json_hex
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w0, w8, #48
	cmp	w0, #9
	b.hi	LBB15_2
; %bb.1:                                ; %common.ret
	ret
LBB15_2:                                ; %b6
	sub	w9, w8, #65
	cmp	w9, #5
	b.hi	LBB15_4
; %bb.3:                                ; %v15_ok
	sub	w0, w8, #55
	ret
LBB15_4:                                ; %b12
	sub	w9, w8, #97
	cmp	w9, #5
	b.hi	LBB15_6
; %bb.5:                                ; %v24_ok
	sub	w0, w8, #87
	ret
LBB15_6:
	mov	w0, #16                         ; =0x10
	ret
                                        ; -- End function
	.globl	_liza___liza_json_step          ; -- Begin function liza___liza_json_step
	.p2align	2
_liza___liza_json_step:                 ; @liza___liza_json_step
; %bb.0:                                ; %b0
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	sub	sp, sp, #3648
	ldr	w9, [x0, #128]
	mov	w19, w1
	cmp	w9, #3
	b.le	LBB16_7
; %bb.1:                                ; %b0
	cmp	w9, #5
	b.gt	LBB16_10
; %bb.2:                                ; %b0
	cmp	w9, #4
	b.eq	LBB16_31
; %bb.3:                                ; %b0
	cmp	w9, #5
	b.ne	LBB16_25
; %bb.4:                                ; %b52
	and	w9, w19, #0xff
	cmp	w9, #117
	b.ne	LBB16_33
; %bb.5:                                ; %b56
	ldur	q0, [x0, #152]
	ldur	q1, [x0, #168]
	ldur	x9, [x0, #132]
	ldr	w10, [x0, #140]
	ldp	q2, q3, [x0, #32]
	str	q0, [sp, #2976]
	ldp	q4, q5, [x0, #96]
	str	q1, [sp, #2992]
	ldp	q1, q0, [x0]
	str	x9, [sp, #3008]
	mov	w9, #6                          ; =0x6
	str	w10, [sp, #3016]
	ldr	x10, [sp, #3008]
	ldp	q6, q7, [x0, #64]
	str	w9, [x8, #128]
	ldr	w9, [sp, #3016]
	stp	q1, q0, [x8]
	ldr	q0, [sp, #2992]
	ldr	q1, [sp, #2976]
LBB16_6:                                ; %common.ret
	stp	q2, q3, [x8, #32]
	stp	q6, q7, [x8, #64]
	stp	q4, q5, [x8, #96]
	stur	x10, [x8, #132]
	str	w9, [x8, #140]
	str	wzr, [x8, #148]
	str	wzr, [x8, #144]
	stur	q0, [x8, #168]
	stur	q1, [x8, #152]
	b	LBB16_84
LBB16_7:                                ; %b0
	cmp	w9, #1
	b.eq	LBB16_18
; %bb.8:                                ; %b0
	cmp	w9, #2
	b.eq	LBB16_36
; %bb.9:                                ; %b0
	cmp	w9, #3
	b.eq	LBB16_16
	b	LBB16_25
LBB16_10:                               ; %b0
	cmp	w9, #6
	b.eq	LBB16_16
; %bb.11:                               ; %b0
	cmp	w9, #20
	b.ne	LBB16_25
; %bb.12:                               ; %b91
	ldr	w9, [x0, #136]
	cmp	w9, #3
	b.eq	LBB16_68
; %bb.13:                               ; %b91
	cmp	w9, #2
	b.eq	LBB16_64
; %bb.14:                               ; %b91
	cmp	w9, #1
	b.ne	LBB16_69
; %bb.15:                               ; %b104.thread
	ldr	w9, [x0, #140]
	mov	w10, #114                       ; =0x72
	mov	w11, #117                       ; =0x75
	cmp	w9, #1
	csel	w10, w10, wzr, eq
	cmp	w9, #2
	csel	w10, w11, w10, eq
	cmp	w9, #3
	mov	w9, #101                        ; =0x65
	csel	w10, w9, w10, eq
	b	LBB16_70
LBB16_16:                               ; %b61
	sub	w10, w19, #48
	and	w10, w10, #0xff
	cmp	w10, #10
	b.hs	LBB16_34
; %bb.17:
	mov	w10, #-48                       ; =0xffffffd0
	b	LBB16_42
LBB16_18:                               ; %b1
	and	w9, w19, #0xff
	cmp	w9, #32
	b.lo	LBB16_65
; %bb.19:                               ; %b5
	cmp	w9, #92
	b.eq	LBB16_76
; %bb.20:                               ; %b5
	cmp	w9, #34
	b.ne	LBB16_77
; %bb.21:                               ; %b6
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x9, [x0, #176]
	str	q2, [sp, #3616]
	str	q0, [sp, #3584]
	str	q1, [sp, #3600]
	ldp	q0, q1, [x0, #64]
	ldrb	w10, [sp, #3588]
	str	x9, [sp, #3632]
	str	wzr, [sp, #3584]
	str	q0, [sp, #3520]
	ldp	q2, q0, [x0, #96]
	str	q1, [sp, #3536]
	cmp	w10, #1
	str	q0, [sp, #3568]
	ldp	q1, q0, [x0]
	str	q2, [sp, #3552]
	str	q1, [sp, #3456]
	str	q0, [sp, #3472]
	ldp	q1, q0, [x0, #32]
	str	q1, [sp, #3488]
	str	q0, [sp, #3504]
	b.ne	LBB16_91
; %bb.22:                               ; %b8
	ldr	w9, [sp, #3576]
	subs	w9, w9, #1
	b.lo	LBB16_181
; %bb.23:                               ; %v17_ok
	cmp	w9, #64
	b.hs	LBB16_181
; %bb.24:                               ; %v18_ok
	add	x10, sp, #3456
	mov	w12, #5                         ; =0x5
	ldr	x11, [x0, #48]
	ldur	q0, [x10, #56]
	ldur	q1, [x10, #72]
	ldur	q2, [x10, #88]
	str	q0, [sp, #3392]
	ldur	q0, [x10, #104]
	add	x10, sp, #3392
	str	q1, [sp, #3408]
	str	q0, [sp, #3440]
	ldp	q1, q0, [x0, #16]
	str	q2, [sp, #3424]
	ldr	q2, [x0]
	strb	w12, [x10, w9, uxtw]
	add	x9, sp, #3456
	stp	q1, q0, [x8, #16]
	ldr	q0, [sp, #3392]
	ldr	q1, [sp, #3408]
	str	x11, [x8, #48]
	stur	q0, [x8, #56]
	ldr	q0, [sp, #3424]
	stur	q1, [x8, #72]
	ldr	q1, [sp, #3440]
	stur	q0, [x8, #88]
	ldur	q0, [x9, #120]
	stur	q1, [x8, #104]
	ldur	q1, [x9, #136]
	stur	q0, [x8, #120]
	ldur	q0, [x9, #152]
	stur	q1, [x8, #136]
	ldur	q1, [x9, #168]
	str	q2, [x8]
	stur	q0, [x8, #152]
	stur	q1, [x8, #168]
	b	LBB16_84
LBB16_25:                               ; %b132
	sub	w10, w9, #10
	cmp	w10, #7
	b.hi	LBB16_61
; %bb.26:                               ; %b136
	sub	w10, w19, #48
	and	w10, w10, #0xff
	cmp	w10, #9
	b.hi	LBB16_56
; %bb.27:                               ; %b138
	cmp	w9, #10
	b.eq	LBB16_93
; %bb.28:                               ; %b138
	cmp	w9, #11
	b.eq	LBB16_149
; %bb.29:                               ; %b148
	ldp	q0, q1, [x0, #64]
	cmp	w9, #13
	ldr	w10, [x0, #180]
	str	q0, [sp, #2288]
	ldp	q0, q2, [x0, #96]
	str	q1, [sp, #2304]
	str	w10, [sp, #2208]
	str	q0, [sp, #2320]
	ldp	q1, q0, [x0]
	str	q2, [sp, #2336]
	str	q0, [sp, #2240]
	ldp	q2, q0, [x0, #32]
	str	q1, [sp, #2224]
	ldur	q1, [x0, #148]
	str	q2, [sp, #2256]
	ldur	q2, [x0, #132]
	str	q0, [sp, #2272]
	ldur	q0, [x0, #164]
	str	q1, [sp, #2176]
	str	q0, [sp, #2192]
	str	q2, [sp, #2160]
	b.ne	LBB16_94
; %bb.30:                               ; %b151.thread
	ldp	q0, q1, [x0, #64]
	add	x10, sp, #1968
	ldur	w9, [x0, #180]
	add	x11, sp, #2032
	str	q0, [sp, #2096]
	ldp	q0, q2, [x0, #96]
	str	q1, [sp, #2112]
	str	w9, [sp, #2016]
	mov	w9, #14                         ; =0xe
	str	q0, [sp, #2128]
	ldp	q1, q0, [x0]
	str	q2, [sp, #2144]
	str	q0, [sp, #2048]
	ldp	q2, q0, [x0, #32]
	str	q1, [sp, #2032]
	ldur	q1, [x0, #148]
	str	q2, [sp, #2064]
	ldur	q2, [x0, #132]
	str	q0, [sp, #2080]
	ldur	q0, [x0, #164]
	str	q1, [sp, #1984]
	str	q0, [sp, #2000]
	str	q2, [sp, #1968]
	b	LBB16_104
LBB16_31:                               ; %b46
	and	w9, w19, #0xff
	cmp	w9, #92
	b.ne	LBB16_33
; %bb.32:                               ; %b50
	ldur	q0, [x0, #132]
	ldur	q1, [x0, #148]
	ldur	q2, [x0, #164]
	ldr	w9, [x0, #180]
	ldp	q4, q5, [x0, #96]
	str	q0, [sp, #3024]
	ldp	q6, q7, [x0, #64]
	str	q1, [sp, #3040]
	ldp	q1, q0, [x0]
	str	q2, [sp, #3056]
	ldp	q2, q3, [x0, #32]
	str	w9, [sp, #3072]
	mov	w9, #5                          ; =0x5
	stp	q1, q0, [x8]
	ldr	q0, [sp, #3024]
	ldr	q1, [sp, #3040]
	str	w9, [x8, #128]
	ldr	w9, [sp, #3072]
	stur	q0, [x8, #132]
	ldr	q0, [sp, #3056]
	b	LBB16_54
LBB16_33:                               ; %b48
	ldp	q0, q1, [x0]
	mov	w11, #4                         ; =0x4
	ldp	q2, q3, [x0, #32]
	ldr	x9, [x0, #160]
	ldp	q4, q5, [x0, #64]
	ldr	w10, [x0, #172]
	ldp	q6, q7, [x0, #128]
	ldp	q16, q17, [x0, #96]
	str	x9, [x8, #160]
	stp	q0, q1, [x8]
	stp	q2, q3, [x8, #32]
	stp	q4, q5, [x8, #64]
	stp	q16, q17, [x8, #96]
	stp	q6, q7, [x8, #128]
	stp	w11, w10, [x8, #168]
	b	LBB16_67
LBB16_34:                               ; %b6.i
	sub	w10, w19, #65
	and	w10, w10, #0xff
	cmp	w10, #6
	b.hs	LBB16_40
; %bb.35:
	mov	w10, #-55                       ; =0xffffffc9
	b	LBB16_42
LBB16_36:                               ; %b16
	and	w9, w19, #0xff
	sub	w10, w9, #98
	cmp	w10, #19
	b.hi	LBB16_51
; %bb.37:                               ; %b16
	mov	w11, #1                         ; =0x1
	mov	w12, #4113                      ; =0x1011
	lsl	w11, w11, w10
	movk	w12, #5, lsl #16
	tst	w11, w12
	b.ne	LBB16_53
; %bb.38:                               ; %b16
	cmp	w10, #19
	b.ne	LBB16_51
; %bb.39:                               ; %b42
	ldur	q0, [x0, #152]
	ldur	q1, [x0, #168]
	ldur	x9, [x0, #132]
	ldr	w10, [x0, #140]
	ldp	q2, q3, [x0, #32]
	str	q0, [sp, #3088]
	ldp	q4, q5, [x0, #96]
	str	q1, [sp, #3104]
	ldp	q1, q0, [x0]
	str	x9, [sp, #3120]
	mov	w9, #3                          ; =0x3
	str	w10, [sp, #3128]
	ldr	x10, [sp, #3120]
	ldp	q6, q7, [x0, #64]
	stp	q1, q0, [x8]
	str	w9, [x8, #128]
	ldr	w9, [sp, #3128]
	ldr	q0, [sp, #3104]
	ldr	q1, [sp, #3088]
	b	LBB16_6
LBB16_40:                               ; %b12.i
	sub	w10, w19, #97
	and	w10, w10, #0xff
	cmp	w10, #6
	b.hs	LBB16_55
; %bb.41:
	mov	w10, #-87                       ; =0xffffffa9
LBB16_42:                               ; %b65
	ldr	w12, [x0, #148]
	lsr	w11, w12, #28
	cbnz	w11, LBB16_181
; %bb.43:                               ; %v128_ok
	ldr	w11, [x0, #144]
	adds	w16, w11, #1
	b.hs	LBB16_181
; %bb.44:                               ; %v133_ok
	add	w15, w10, w19, uxtb
	ldp	x11, x13, [x0, #152]
	ldp	w14, w10, [x0, #168]
	ldur	x17, [x0, #132]
	ldur	w1, [x0, #140]
	add	w12, w15, w12, lsl #4
	ldr	x15, [x0, #176]
	cmp	w16, #4
	str	x17, [sp, #2960]
	str	w1, [sp, #2968]
	b.ne	LBB16_81
; %bb.45:                               ; %b66
	cmp	w9, #6
	b.ne	LBB16_48
; %bb.46:                               ; %b68
	sub	w9, w12, #14, lsl #12           ; =57344
	cmn	w9, #1025
	b.hi	LBB16_75
; %bb.47:                               ; %b73
	ldp	q0, q1, [x0, #96]
	mov	w9, #6                          ; =0x6
	ldp	q2, q3, [x0]
	ldr	x14, [sp, #2960]
	ldp	q4, q5, [x0, #32]
	ldp	q6, q7, [x0, #64]
	str	w9, [x8, #128]
	ldr	w9, [sp, #2968]
	stur	x14, [x8, #132]
	mov	w14, #4                         ; =0x4
	stp	q2, q3, [x8]
	stp	q4, q5, [x8, #32]
	stp	q6, q7, [x8, #64]
	stp	q0, q1, [x8, #96]
	stp	w9, w14, [x8, #140]
	str	w12, [x8, #148]
	stp	x11, x13, [x8, #152]
	stp	w14, w10, [x8, #168]
	str	x13, [x8, #176]
	b	LBB16_84
LBB16_48:                               ; %b76
	and	w17, w12, #0xfffffc00
	mov	w1, #56320                      ; =0xdc00
	cmp	w17, w1
	b.eq	LBB16_79
; %bb.49:                               ; %b76
	mov	w9, #55296                      ; =0xd800
	cmp	w17, w9
	b.ne	LBB16_80
; %bb.50:                               ; %b80
	ldur	w13, [x0, #140]
	ldur	x9, [x0, #132]
	ldp	q0, q1, [x0, #96]
	str	w13, [sp, #2936]
	ldp	q2, q3, [x0, #32]
	ldp	q4, q5, [x0, #64]
	mov	w13, #4                         ; =0x4
	ldp	q7, q6, [x0]
	str	x9, [sp, #2928]
	stur	x9, [x8, #132]
	ldr	w9, [sp, #2936]
	stp	q2, q3, [x8, #32]
	stp	q7, q6, [x8]
	stp	q4, q5, [x8, #64]
	stp	q0, q1, [x8, #96]
	str	w13, [x8, #128]
	stp	w9, w13, [x8, #140]
	str	w12, [x8, #148]
	stp	x11, x11, [x8, #152]
	b	LBB16_83
LBB16_51:                               ; %b16
	sub	w9, w9, #34
	cmp	w9, #58
	b.hi	LBB16_55
; %bb.52:                               ; %b16
	mov	w10, #1                         ; =0x1
	lsl	x9, x10, x9
	mov	x10, #8193                      ; =0x2001
	movk	x10, #1024, lsl #48
	tst	x9, x10
	b.eq	LBB16_55
LBB16_53:                               ; %b39
	ldur	q0, [x0, #132]
	ldur	q1, [x0, #148]
	ldur	q2, [x0, #164]
	ldr	w9, [x0, #180]
	ldp	q4, q5, [x0, #96]
	str	q0, [sp, #3136]
	ldp	q6, q7, [x0, #64]
	str	q1, [sp, #3152]
	ldp	q1, q0, [x0]
	str	q2, [sp, #3168]
	ldp	q2, q3, [x0, #32]
	str	w9, [sp, #3184]
	mov	w9, #1                          ; =0x1
	stp	q1, q0, [x8]
	ldr	q0, [sp, #3136]
	ldr	q1, [sp, #3152]
	str	w9, [x8, #128]
	ldr	w9, [sp, #3184]
	stur	q0, [x8, #132]
	ldr	q0, [sp, #3168]
LBB16_54:                               ; %common.ret
	stp	q2, q3, [x8, #32]
	stp	q6, q7, [x8, #64]
	stp	q4, q5, [x8, #96]
	stur	q1, [x8, #148]
	stur	q0, [x8, #164]
	str	w9, [x8, #180]
	b	LBB16_84
LBB16_55:                               ; %b44
	ldp	q0, q1, [x0]
	ldr	x10, [x0, #160]
	ldp	q2, q3, [x0, #32]
	ldr	x9, [x0, #48]
	ldr	w11, [x0, #172]
	ldp	q4, q5, [x0, #64]
	ldp	q6, q16, [x0, #96]
	ldp	q17, q7, [x0, #128]
	str	x10, [x8, #160]
	mov	w10, #3                         ; =0x3
	b	LBB16_66
LBB16_56:                               ; %b158
	cmp	w9, #11
	b.ne	LBB16_85
; %bb.57:                               ; %b162
	and	w9, w19, #0xff
	cmp	w9, #92
	b.gt	LBB16_113
; %bb.58:                               ; %b162
	sub	w9, w9, #9
	cmp	w9, #60
	b.hi	LBB16_149
; %bb.59:                               ; %b162
	mov	w10, #1                         ; =0x1
	mov	x11, #19                        ; =0x13
	lsl	x10, x10, x9
	movk	x11, #128, lsl #16
	movk	x11, #8, lsl #32
	tst	x10, x11
	b.eq	LBB16_120
LBB16_60:                               ; %b215
	ldp	q0, q1, [x0, #128]
	mov	x20, x8
	ldr	q2, [x0, #160]
	ldr	x9, [x0, #176]
	add	x8, sp, #1392
	str	q0, [sp, #1520]
	str	q1, [sp, #1536]
	ldp	q0, q1, [x0, #64]
	str	q2, [sp, #1552]
	str	x9, [sp, #1568]
	str	q0, [sp, #1456]
	ldp	q2, q0, [x0, #96]
	str	q1, [sp, #1472]
	str	wzr, [sp, #1520]
	str	q0, [sp, #1504]
	ldp	q1, q0, [x0]
	str	q2, [sp, #1488]
	str	q0, [sp, #1408]
	ldp	q2, q0, [x0, #32]
	str	q1, [sp, #1392]
	str	q2, [sp, #1424]
	str	q0, [sp, #1440]
	bl	_liza___liza_owned___liza_json_done
	add	x0, sp, #1392
	mov	x8, x20
LBB16_61:                               ; %b216
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x9, [x0, #176]
	str	q2, [sp, #1360]
	str	q0, [sp, #1328]
	str	q1, [sp, #1344]
	ldp	q0, q1, [x0, #64]
	str	x9, [sp, #1376]
	and	w9, w19, #0xff
	cmp	w9, #32
	str	q0, [sp, #1264]
	ldp	q2, q0, [x0, #96]
	str	q1, [sp, #1280]
	str	q0, [sp, #1312]
	ldp	q1, q0, [x0]
	str	q2, [sp, #1296]
	str	q1, [sp, #1200]
	str	q0, [sp, #1216]
	ldp	q1, q0, [x0, #32]
	str	q1, [sp, #1232]
	str	q0, [sp, #1248]
	b.hi	LBB16_88
; %bb.62:                               ; %b216
	mov	w9, w19
	mov	w10, #1                         ; =0x1
	and	x9, x9, #0xff
	lsl	x9, x10, x9
	mov	x10, #9728                      ; =0x2600
	movk	x10, #1, lsl #32
	tst	x9, x10
	b.eq	LBB16_88
; %bb.63:                               ; %b217
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	ldr	q2, [sp, #1360]
	ldr	x9, [sp, #1376]
	stp	q0, q1, [x8, #128]
	ldr	q0, [sp, #1264]
	ldr	q1, [sp, #1280]
	str	q2, [x8, #160]
	ldr	q2, [sp, #1296]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #1312]
	ldr	q1, [sp, #1200]
	str	x9, [x8, #176]
	stp	q2, q0, [x8, #96]
	ldr	q0, [sp, #1216]
	ldr	q2, [sp, #1232]
	stp	q1, q0, [x8]
	ldr	q0, [sp, #1248]
	stp	q2, q0, [x8, #32]
	b	LBB16_84
LBB16_64:                               ; %b105
	ldr	w9, [x0, #140]
	mov	w10, #97                        ; =0x61
	mov	w11, #108                       ; =0x6c
	cmp	w9, #1
	csel	w10, w10, wzr, eq
	cmp	w9, #2
	csel	w10, w11, w10, eq
	cmp	w9, #3
	mov	w11, #115                       ; =0x73
	csel	w10, w11, w10, eq
	cmp	w9, #4
	mov	w9, #101                        ; =0x65
	csel	w10, w9, w10, eq
	mov	w9, #5                          ; =0x5
	cmp	w10, w19, uxtb
	b.eq	LBB16_71
LBB16_65:                               ; %b3
	ldp	q0, q1, [x0]
	ldr	x10, [x0, #160]
	ldp	q2, q3, [x0, #32]
	ldr	x9, [x0, #48]
	ldr	w11, [x0, #172]
	ldp	q4, q5, [x0, #64]
	ldp	q6, q16, [x0, #96]
	ldp	q17, q7, [x0, #128]
	str	x10, [x8, #160]
	mov	w10, #1                         ; =0x1
LBB16_66:                               ; %common.ret
	stp	q2, q3, [x8, #32]
	stp	q4, q5, [x8, #64]
	stp	q6, q16, [x8, #96]
	stp	q17, q7, [x8, #128]
	str	q1, [x8, #16]
	str	q0, [x8]
	stp	w10, w11, [x8, #168]
LBB16_67:                               ; %common.ret
	str	x9, [x8, #176]
	b	LBB16_84
LBB16_68:                               ; %b120
	ldr	w9, [x0, #140]
	mov	w10, #117                       ; =0x75
	cmp	w9, #1
	mov	w9, #108                        ; =0x6c
	csel	w10, w10, w9, eq
	b	LBB16_70
LBB16_69:
	mov	w10, wzr
LBB16_70:                               ; %b125
	mov	w9, #4                          ; =0x4
	cmp	w10, w19, uxtb
	b.ne	LBB16_65
LBB16_71:                               ; %b128
	ldr	w10, [x0, #140]
	adds	w10, w10, #1
	b.hs	LBB16_181
; %bb.72:                               ; %v251_ok
	ldp	q0, q1, [x0, #144]
	cmp	w10, w9
	ldr	x11, [x0, #176]
	str	q0, [sp, #2736]
	str	q1, [sp, #2752]
	str	x11, [sp, #2768]
	b.ne	LBB16_74
; %bb.73:                               ; %b129
	ldp	q0, q1, [x0, #96]
	add	x10, sp, #2413
	ldur	q2, [x0, #124]
	mov	x19, x8
	add	x8, sp, #2544
	str	w9, [sp, #2684]
	str	q0, [sp, #2640]
	str	q1, [sp, #2656]
	ldp	q0, q1, [x0, #32]
	stur	q2, [x10, #255]
	ldur	x10, [x0, #176]
	str	wzr, [sp, #2672]
	str	q0, [sp, #2576]
	ldp	q0, q2, [x0, #64]
	str	q1, [sp, #2592]
	str	x10, [sp, #2720]
	str	q0, [sp, #2608]
	ldp	q0, q1, [x0]
	str	q2, [sp, #2624]
	str	q0, [sp, #2544]
	ldp	q2, q0, [x0, #144]
	str	q1, [sp, #2560]
	str	q2, [sp, #2688]
	str	q0, [sp, #2704]
	bl	_liza___liza_owned___liza_json_done
	ldr	q0, [sp, #2672]
	ldr	q1, [sp, #2688]
	ldr	q2, [sp, #2704]
	ldr	x8, [sp, #2720]
	stp	q0, q1, [x19, #128]
	ldr	q0, [sp, #2608]
	ldr	q1, [sp, #2624]
	str	q2, [x19, #160]
	ldr	q2, [sp, #2640]
	stp	q0, q1, [x19, #64]
	ldr	q0, [sp, #2656]
	ldr	q1, [sp, #2544]
	str	x8, [x19, #176]
	stp	q2, q0, [x19, #96]
	ldr	q0, [sp, #2560]
	ldr	q2, [sp, #2576]
	stp	q1, q0, [x19]
	ldr	q0, [sp, #2592]
	b	LBB16_92
LBB16_74:                               ; %b131
	ldp	q0, q1, [x0]
	ldr	x9, [x0, #128]
	ldp	q2, q3, [x0, #32]
	ldr	w11, [x0, #136]
	ldp	q4, q5, [x0, #96]
	ldp	q6, q7, [x0, #64]
	str	x9, [x8, #128]
	stp	q0, q1, [x8]
	ldr	q0, [sp, #2736]
	ldr	q1, [sp, #2752]
	ldr	x9, [sp, #2768]
	stp	q2, q3, [x8, #32]
	stp	q6, q7, [x8, #64]
	stp	q4, q5, [x8, #96]
	stp	w11, w10, [x8, #136]
	stp	q0, q1, [x8, #144]
	b	LBB16_67
LBB16_75:                               ; %b75
	ldur	x9, [x0, #132]
	ldur	w16, [x0, #140]
	ldp	q1, q0, [x0]
	str	x9, [sp, #2944]
	ldp	q2, q3, [x0, #32]
	str	w16, [sp, #2952]
	mov	w9, #1                          ; =0x1
	ldr	x16, [sp, #2944]
	ldp	q4, q5, [x0, #96]
	ldp	q6, q7, [x0, #64]
	str	w9, [x8, #128]
	ldr	w9, [sp, #2952]
	stur	x16, [x8, #132]
	mov	w16, #4                         ; =0x4
	stp	q1, q0, [x8]
	stp	q2, q3, [x8, #32]
	stp	q6, q7, [x8, #64]
	stp	q4, q5, [x8, #96]
	b	LBB16_82
LBB16_76:                               ; %b12
	ldr	x9, [x0, #48]
	mov	w10, #2                         ; =0x2
	mov	x11, x9
	b	LBB16_78
LBB16_77:                               ; %b13_to_b14
	ldr	x11, [x0, #48]
	ldr	x9, [x0, #152]
	mov	w10, #1                         ; =0x1
LBB16_78:                               ; %b14
	ldp	q0, q1, [x0]
	ldr	q2, [x0, #32]
	ldr	x12, [x0, #120]
	ldr	w13, [x0, #148]
	ldr	x14, [x0, #176]
	str	q2, [sp, #3376]
	ldur	q2, [x0, #72]
	str	q0, [sp, #3344]
	ldur	q0, [x0, #88]
	str	q1, [sp, #3360]
	ldur	q1, [x0, #104]
	str	q0, [sp, #3296]
	ldur	q0, [x0, #56]
	str	q1, [sp, #3312]
	ldur	q1, [x0, #132]
	str	q0, [sp, #3264]
	ldr	q0, [x0, #160]
	str	q1, [sp, #3232]
	ldr	q1, [sp, #3344]
	str	q0, [sp, #3200]
	ldr	q0, [sp, #3360]
	str	q2, [sp, #3280]
	ldr	q2, [sp, #3376]
	stp	q1, q0, [x8]
	ldr	q0, [sp, #3280]
	ldr	q1, [sp, #3296]
	str	q2, [x8, #32]
	ldr	q2, [sp, #3264]
	stur	q0, [x8, #72]
	ldr	q0, [sp, #3312]
	str	x11, [x8, #48]
	mov	w11, w13
	stur	q0, [x8, #104]
	ldr	q0, [sp, #3232]
	str	w10, [x8, #128]
	mov	x10, x14
	stur	q0, [x8, #132]
	ldr	q0, [sp, #3200]
	stur	q1, [x8, #88]
	str	x12, [sp, #3328]
	str	w13, [sp, #3248]
	str	x14, [sp, #3216]
	str	x12, [x8, #120]
	stur	q2, [x8, #56]
	str	w11, [x8, #148]
	str	x9, [x8, #152]
	str	x10, [x8, #176]
	str	q0, [x8, #160]
	b	LBB16_84
LBB16_79:                               ; %b86
	ldp	q0, q1, [x0, #96]
	ldr	x14, [sp, #2960]
	ldp	q2, q3, [x0]
	ldp	q4, q5, [x0, #32]
	ldp	q6, q7, [x0, #64]
	str	w9, [x8, #128]
	ldr	w9, [sp, #2968]
	stur	x14, [x8, #132]
	mov	w14, #4                         ; =0x4
	stp	q2, q3, [x8]
	stp	q4, q5, [x8, #32]
	stp	q6, q7, [x8, #64]
	stp	q0, q1, [x8, #96]
	stp	w9, w14, [x8, #140]
	str	w12, [x8, #148]
	stp	x11, x13, [x8, #152]
	stp	w14, w10, [x8, #168]
	str	x11, [x8, #176]
	b	LBB16_84
LBB16_80:
	mov	w9, #1                          ; =0x1
LBB16_81:                               ; %b89
	ldp	q0, q1, [x0, #64]
	ldur	w17, [x0, #140]
	str	w17, [sp, #2792]
	str	q0, [sp, #2864]
	ldp	q0, q2, [x0, #96]
	str	q1, [sp, #2880]
	str	q0, [sp, #2896]
	ldp	q1, q0, [x0]
	str	q2, [sp, #2912]
	str	q0, [sp, #2816]
	ldp	q2, q0, [x0, #32]
	str	q1, [sp, #2800]
	ldr	q1, [sp, #2880]
	ldur	x0, [x0, #132]
	str	w9, [x8, #128]
	ldr	w9, [sp, #2792]
	str	q0, [sp, #2848]
	ldr	q0, [sp, #2864]
	mov	x17, x0
	str	q2, [sp, #2832]
	ldr	q2, [sp, #2896]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #2912]
	ldr	q1, [sp, #2800]
	str	x0, [sp, #2784]
	stp	q2, q0, [x8, #96]
	ldr	q0, [sp, #2816]
	ldr	q2, [sp, #2832]
	stur	x17, [x8, #132]
	stp	q1, q0, [x8]
	ldr	q0, [sp, #2848]
	stp	q2, q0, [x8, #32]
LBB16_82:                               ; %common.ret
	stp	w9, w16, [x8, #140]
	str	w12, [x8, #148]
	stp	x11, x13, [x8, #152]
LBB16_83:                               ; %common.ret
	stp	w14, w10, [x8, #168]
	str	x15, [x8, #176]
LBB16_84:                               ; %common.ret
	add	sp, sp, #3648
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB16_85:                               ; %b159
	cmp	w9, #12
	b.ne	LBB16_96
; %bb.86:                               ; %b159
	and	w10, w19, #0xff
	cmp	w10, #46
	b.ne	LBB16_96
LBB16_87:                               ; %b165
	ldur	q0, [x0, #132]
	ldur	q1, [x0, #148]
	ldur	q2, [x0, #164]
	ldr	w9, [x0, #180]
	ldp	q4, q5, [x0, #96]
	str	q0, [sp, #1712]
	ldp	q6, q7, [x0, #64]
	str	q1, [sp, #1728]
	ldp	q1, q0, [x0]
	str	q2, [sp, #1744]
	ldp	q2, q3, [x0, #32]
	str	w9, [sp, #1760]
	mov	w9, #13                         ; =0xd
	stp	q1, q0, [x8]
	ldr	q0, [sp, #1712]
	ldr	q1, [sp, #1728]
	str	w9, [x8, #128]
	ldr	w9, [sp, #1760]
	stur	q0, [x8, #132]
	ldr	q0, [sp, #1744]
	b	LBB16_54
LBB16_88:                               ; %b219
	ldr	w10, [sp, #1320]
	add	x20, sp, #1200
	cbz	w10, LBB16_105
; %bb.89:                               ; %b220
	ldur	q0, [x20, #56]
	ldur	q1, [x20, #72]
	sub	w9, w10, #1
	ldur	q2, [x20, #88]
	cmp	w9, #64
	stp	q0, q1, [sp]
	ldur	q0, [x20, #104]
	stp	q2, q0, [sp, #32]
	b.hs	LBB16_181
; %bb.90:                               ; %v411_ok
	mov	x11, sp
	ldrb	w11, [x11, w9, uxtw]
	b	LBB16_106
LBB16_91:                               ; %b10
	mov	x19, x8
	add	x8, sp, #3456
	bl	_liza___liza_owned___liza_json_done
	ldr	q0, [sp, #3584]
	ldr	q1, [sp, #3600]
	ldr	q2, [sp, #3616]
	ldr	x8, [sp, #3632]
	stp	q0, q1, [x19, #128]
	ldr	q0, [sp, #3520]
	ldr	q1, [sp, #3536]
	str	q2, [x19, #160]
	ldr	q2, [sp, #3552]
	stp	q0, q1, [x19, #64]
	ldr	q0, [sp, #3568]
	ldr	q1, [sp, #3456]
	str	x8, [x19, #176]
	stp	q2, q0, [x19, #96]
	ldr	q0, [sp, #3472]
	ldr	q2, [sp, #3488]
	stp	q1, q0, [x19]
	ldr	q0, [sp, #3504]
LBB16_92:                               ; %common.ret
	stp	q2, q0, [x19, #32]
	b	LBB16_84
LBB16_93:                               ; %b143
	ldp	q0, q1, [x0, #64]
	ldr	w9, [x0, #180]
	str	w9, [sp, #2400]
	str	q0, [sp, #2480]
	ldp	q2, q0, [x0, #96]
	str	q1, [sp, #2496]
	ldr	w9, [sp, #2400]
	str	q0, [sp, #2528]
	ldp	q1, q0, [x0]
	str	q2, [sp, #2512]
	str	w9, [sp, #2208]
	and	w9, w19, #0xff
	str	q0, [sp, #2432]
	ldp	q2, q0, [x0, #32]
	str	q1, [sp, #2416]
	ldur	q1, [x0, #164]
	cmp	w9, #48
	mov	w9, #11                         ; =0xb
	str	q0, [sp, #2464]
	ldur	q0, [x0, #148]
	cinc	w9, w9, ne
	str	q2, [sp, #2448]
	ldur	q2, [x0, #132]
	str	q0, [sp, #2368]
	ldr	q0, [sp, #2496]
	str	q1, [sp, #2384]
	ldr	q1, [sp, #2480]
	str	q0, [sp, #2304]
	ldr	q0, [sp, #2528]
	str	q2, [sp, #2352]
	ldr	q2, [sp, #2512]
	str	q0, [sp, #2336]
	ldr	q0, [sp, #2432]
	str	q1, [sp, #2288]
	ldr	q1, [sp, #2416]
	str	q0, [sp, #2240]
	ldr	q0, [sp, #2464]
	str	q2, [sp, #2320]
	ldr	q2, [sp, #2448]
	str	q0, [sp, #2272]
	ldr	q0, [sp, #2384]
	str	q1, [sp, #2224]
	ldr	q1, [sp, #2368]
	str	q0, [sp, #2192]
	ldr	q0, [sp, #2352]
	str	q2, [sp, #2256]
	str	q1, [sp, #2176]
	str	q0, [sp, #2160]
LBB16_94:                               ; %b151
	ldr	q0, [sp, #2288]
	ldr	q1, [sp, #2304]
	ldr	q2, [sp, #2336]
	ldr	w10, [sp, #2208]
	str	q0, [sp, #2096]
	ldr	q0, [sp, #2320]
	str	q1, [sp, #2112]
	ldr	q1, [sp, #2224]
	str	q0, [sp, #2128]
	ldr	q0, [sp, #2240]
	str	q2, [sp, #2144]
	ldr	q2, [sp, #2256]
	str	q0, [sp, #2048]
	ldr	q0, [sp, #2272]
	str	q1, [sp, #2032]
	ldr	q1, [sp, #2176]
	str	q2, [sp, #2064]
	ldr	q2, [sp, #2160]
	str	q0, [sp, #2080]
	ldr	q0, [sp, #2192]
	str	w10, [sp, #2016]
	sub	w10, w9, #15
	cmp	w10, #1
	str	q0, [sp, #2000]
	str	q1, [sp, #1984]
	str	q2, [sp, #1968]
	b.hi	LBB16_103
; %bb.95:                               ; %b155
	mov	w9, #17                         ; =0x11
	add	x10, sp, #2160
	add	x11, sp, #2224
	b	LBB16_104
LBB16_96:                               ; %b167
	cmp	w9, #16
	b.hi	LBB16_150
; %bb.97:                               ; %b167
	mov	w10, #1                         ; =0x1
	mov	w11, #22528                     ; =0x5800
	lsl	w10, w10, w9
	tst	w10, w11
	b.ne	LBB16_127
; %bb.98:                               ; %b167
	mov	w11, #9216                      ; =0x2400
	movk	w11, #1, lsl #16
	tst	w10, w11
	b.ne	LBB16_149
; %bb.99:                               ; %b167
	cmp	w9, #15
	b.ne	LBB16_150
; %bb.100:                              ; %b183
	and	w9, w19, #0xff
	cmp	w9, #45
	b.eq	LBB16_102
; %bb.101:                              ; %b183
	cmp	w9, #43
	b.ne	LBB16_149
LBB16_102:                              ; %b189
	ldur	q0, [x0, #132]
	ldur	q1, [x0, #148]
	ldur	q2, [x0, #164]
	ldr	w9, [x0, #180]
	ldp	q4, q5, [x0, #96]
	str	q0, [sp, #1584]
	ldp	q6, q7, [x0, #64]
	str	q1, [sp, #1600]
	ldp	q1, q0, [x0]
	str	q2, [sp, #1616]
	ldp	q2, q3, [x0, #32]
	str	w9, [sp, #1632]
	mov	w9, #16                         ; =0x10
	stp	q1, q0, [x8]
	ldr	q0, [sp, #1584]
	ldr	q1, [sp, #1600]
	str	w9, [x8, #128]
	ldr	w9, [sp, #1632]
	stur	q0, [x8, #132]
	ldr	q0, [sp, #1616]
	b	LBB16_54
LBB16_103:
	add	x10, sp, #1968
	add	x11, sp, #2032
LBB16_104:                              ; %b157
	ldp	q0, q1, [x11, #64]
	str	w9, [x8, #128]
	str	q0, [sp, #1904]
	ldp	q0, q2, [x11, #96]
	str	q1, [sp, #1920]
	str	q0, [sp, #1936]
	ldp	q1, q0, [x11]
	str	q2, [sp, #1952]
	str	q0, [sp, #1856]
	ldp	q2, q0, [x11, #32]
	str	q1, [sp, #1840]
	ldr	w11, [x10, #48]
	str	q0, [sp, #1888]
	ldp	q1, q0, [x10, #16]
	str	q2, [sp, #1872]
	ldr	q2, [x10]
	str	w11, [sp, #1824]
	str	q0, [sp, #1808]
	ldr	q0, [sp, #1888]
	ldr	w10, [sp, #1824]
	str	q1, [sp, #1792]
	ldr	q1, [sp, #1872]
	str	q2, [sp, #1776]
	ldr	q2, [sp, #1856]
	stp	q1, q0, [x8, #32]
	ldr	q0, [sp, #1840]
	ldr	q1, [sp, #1952]
	str	w10, [x8, #180]
	stp	q0, q2, [x8]
	ldr	q0, [sp, #1936]
	ldr	q2, [sp, #1920]
	stp	q0, q1, [x8, #96]
	ldr	q0, [sp, #1904]
	ldr	q1, [sp, #1792]
	stp	q0, q2, [x8, #64]
	ldr	q0, [sp, #1808]
	ldr	q2, [sp, #1776]
	stur	q1, [x8, #148]
	stur	q0, [x8, #164]
	stur	q2, [x8, #132]
	b	LBB16_84
LBB16_105:
	mov	w11, wzr
LBB16_106:                              ; %b222
	and	w9, w19, #0xff
	cmp	w9, #125
	b.eq	LBB16_116
; %bb.107:                              ; %b222
	cmp	w9, #93
	b.ne	LBB16_109
; %bb.108:                              ; %b223
	sub	w9, w11, #1
	cmp	w9, #1
	b.ls	LBB16_136
LBB16_109:                              ; %b240
	cmp	w11, #4
	add	x9, sp, #1200
	b.le	LBB16_122
; %bb.110:                              ; %b240
	cmp	w11, #5
	b.eq	LBB16_144
; %bb.111:                              ; %b240
	cmp	w11, #8
	b.eq	LBB16_124
; %bb.112:                              ; %b240
	cmp	w11, #7
	b.eq	LBB16_129
	b	LBB16_138
LBB16_113:                              ; %b162
	cmp	w9, #93
	b.eq	LBB16_60
; %bb.114:                              ; %b162
	cmp	w9, #101
	b.eq	LBB16_128
LBB16_115:                              ; %b203
	cmp	w9, #125
	b.eq	LBB16_60
	b	LBB16_149
LBB16_116:                              ; %b232
	cmp	w11, #4
	b.le	LBB16_134
; %bb.117:                              ; %b232
	cmp	w11, #5
	b.eq	LBB16_172
; %bb.118:                              ; %b232
	cmp	w11, #8
	b.eq	LBB16_172
; %bb.119:                              ; %b232
	cmp	w11, #7
	b.eq	LBB16_136
	b	LBB16_138
LBB16_120:                              ; %b162
	cmp	x9, #37
	b.eq	LBB16_87
; %bb.121:                              ; %b162
	cmp	x9, #60
	b.eq	LBB16_128
	b	LBB16_149
LBB16_122:                              ; %b240
	cmp	w11, #2
	b.eq	LBB16_129
; %bb.123:                              ; %b240
	cmp	w11, #4
	b.ne	LBB16_138
LBB16_124:                              ; %b262
	and	w9, w19, #0xff
	cmp	w9, #34
	b.ne	LBB16_172
; %bb.125:                              ; %b266
	ldr	q0, [sp, #1264]
	ldr	q1, [sp, #1280]
	mov	w9, #1                          ; =0x1
	ldr	q2, [sp, #1312]
	strb	w9, [sp, #876]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #1296]
	ldr	q1, [sp, #1200]
	str	w9, [x8, #128]
	stp	q0, q2, [x8, #96]
	ldr	q0, [sp, #1216]
	ldr	q2, [sp, #1232]
	strb	w9, [x8, #132]
LBB16_126:                              ; %common.ret
	stp	q1, q0, [x8]
	ldr	q0, [sp, #1248]
	stp	q2, q0, [x8, #32]
	ldur	q0, [x20, #133]
	stur	q0, [x8, #133]
	ldur	q0, [x20, #149]
	stur	q0, [x8, #149]
	ldur	q0, [x20, #165]
	ldr	w9, [sp, #1380]
	stur	q0, [x8, #165]
	str	w9, [x8, #180]
	b	LBB16_84
LBB16_127:                              ; %b174
	orr	w10, w19, #0x20
	and	w10, w10, #0xff
	cmp	w10, #101
	b.ne	LBB16_148
LBB16_128:                              ; %b180
	ldur	q0, [x0, #132]
	ldur	q1, [x0, #148]
	ldur	q2, [x0, #164]
	ldr	w9, [x0, #180]
	ldp	q4, q5, [x0, #96]
	str	q0, [sp, #1648]
	ldp	q6, q7, [x0, #64]
	str	q1, [sp, #1664]
	ldp	q1, q0, [x0]
	str	q2, [sp, #1680]
	ldp	q2, q3, [x0, #32]
	str	w9, [sp, #1696]
	mov	w9, #15                         ; =0xf
	stp	q1, q0, [x8]
	ldr	q0, [sp, #1648]
	ldr	q1, [sp, #1664]
	str	w9, [x8, #128]
	ldr	w9, [sp, #1696]
	stur	q0, [x8, #132]
	ldr	q0, [sp, #1680]
	b	LBB16_54
LBB16_129:                              ; %b244
	and	w12, w19, #0xff
	cmp	w12, #44
	b.ne	LBB16_172
; %bb.130:                              ; %b248
	ldur	q0, [x20, #56]
	ldur	q1, [x20, #72]
	subs	w12, w10, #1
	ldur	q2, [x20, #88]
	ldur	q3, [x20, #104]
	cset	w10, lo
	cmp	w11, #2
	b.ne	LBB16_153
; %bb.131:                              ; %b249
	cbnz	w10, LBB16_181
; %bb.132:                              ; %v459_ok
	cmp	w12, #64
	b.hs	LBB16_181
; %bb.133:
	mov	w11, #3                         ; =0x3
	add	x10, sp, #1136
	b	LBB16_156
LBB16_134:                              ; %b232
	cmp	w11, #2
	b.eq	LBB16_172
; %bb.135:                              ; %b232
	cmp	w11, #4
	b.ne	LBB16_138
LBB16_136:                              ; %b229
	subs	w9, w10, #1
	b.lo	LBB16_181
; %bb.137:                              ; %v426_ok
	ldr	q0, [sp, #1264]
	ldr	q1, [sp, #1280]
	ldr	q2, [sp, #1296]
	ldr	x10, [sp, #1312]
	str	w9, [x8, #120]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #1200]
	ldr	q1, [sp, #1216]
	str	q2, [x8, #96]
	ldr	q2, [sp, #1232]
	stp	q0, q1, [x8]
	ldr	q0, [sp, #1248]
	ldur	q1, [x20, #168]
	str	x10, [x8, #112]
	stp	q2, q0, [x8, #32]
	ldur	q0, [x20, #156]
	stur	q1, [x8, #168]
	stur	q0, [x8, #156]
	ldur	q0, [x20, #140]
	stur	q0, [x8, #140]
	ldur	q0, [x20, #124]
	stur	q0, [x8, #124]
	b	LBB16_84
LBB16_138:                              ; %b259
	cbnz	w10, LBB16_140
; %bb.139:                              ; %b259
	ldrb	w9, [sp, #1324]
	tbnz	w9, #0, LBB16_172
LBB16_140:                              ; %b273
	and	w9, w19, #0xff
	cmp	w9, #90
	b.gt	LBB16_157
; %bb.141:                              ; %b273
	cmp	w9, #34
	b.eq	LBB16_166
; %bb.142:                              ; %b273
	cmp	w9, #45
	b.ne	LBB16_161
; %bb.143:                              ; %b289
	ldr	q0, [sp, #1264]
	ldr	q1, [sp, #1280]
	mov	w9, #10                         ; =0xa
	ldr	q2, [sp, #1312]
	str	w9, [x8, #128]
	ldr	w9, [sp, #1380]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #1296]
	ldr	q1, [sp, #1200]
	str	w9, [x8, #180]
	stp	q0, q2, [x8, #96]
	ldr	q0, [sp, #1216]
	ldr	q2, [sp, #1232]
	stp	q1, q0, [x8]
	ldr	q0, [sp, #1248]
	ldur	q1, [x20, #164]
	stp	q2, q0, [x8, #32]
	ldur	q0, [x20, #148]
	stur	q1, [x8, #164]
	stur	q0, [x8, #148]
	ldur	q0, [x20, #132]
	stur	q0, [x8, #132]
	b	LBB16_84
LBB16_144:                              ; %b253
	and	w11, w19, #0xff
	cmp	w11, #58
	b.ne	LBB16_172
; %bb.145:                              ; %b257
	subs	w10, w10, #1
	b.lo	LBB16_181
; %bb.146:                              ; %v483_ok
	cmp	w10, #64
	b.hs	LBB16_181
; %bb.147:                              ; %v484_ok
	ldur	q0, [x20, #56]
	ldur	q1, [x20, #72]
	add	x11, sp, #880
	ldur	q2, [x20, #88]
	mov	w12, #6                         ; =0x6
	stp	q0, q1, [sp, #880]
	ldur	q0, [x20, #104]
	ldr	q1, [sp, #1216]
	stp	q2, q0, [sp, #912]
	ldr	q0, [sp, #1200]
	ldr	q2, [sp, #1232]
	strb	w12, [x11, w10, uxtw]
	ldr	x10, [sp, #1248]
	stp	q0, q1, [x8]
	ldp	q0, q1, [sp, #880]
	str	q2, [x8, #32]
	ldur	q2, [x9, #136]
	str	x10, [x8, #48]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #912]
	stur	q2, [x8, #136]
	stur	q0, [x8, #88]
	ldur	q0, [x9, #168]
	stur	q1, [x8, #104]
	ldur	q1, [x9, #152]
	stur	q0, [x8, #168]
	ldur	q0, [x9, #120]
	stur	q1, [x8, #152]
	stur	q0, [x8, #120]
	b	LBB16_84
LBB16_148:                              ; %b191
	cmp	w9, #13
	b.ne	LBB16_150
LBB16_149:                              ; %b140
	ldp	q0, q1, [x0]
	ldr	x10, [x0, #160]
	ldp	q2, q3, [x0, #32]
	ldr	x9, [x0, #48]
	ldr	w11, [x0, #172]
	ldp	q4, q5, [x0, #64]
	ldp	q6, q16, [x0, #96]
	ldp	q17, q7, [x0, #128]
	str	x10, [x8, #160]
	mov	w10, #2                         ; =0x2
	b	LBB16_66
LBB16_150:                              ; %b203
	and	w9, w19, #0xff
	cmp	w9, #44
	b.hi	LBB16_152
; %bb.151:                              ; %b203
	and	x10, x19, #0xff
	mov	w11, #1                         ; =0x1
	lsl	x10, x11, x10
	mov	x11, #9728                      ; =0x2600
	movk	x11, #4097, lsl #32
	tst	x10, x11
	b.ne	LBB16_60
LBB16_152:                              ; %b203
	cmp	w9, #93
	b.ne	LBB16_115
	b	LBB16_60
LBB16_153:                              ; %b250
	cbnz	w10, LBB16_181
; %bb.154:                              ; %v467_ok
	cmp	w12, #64
	b.hs	LBB16_181
; %bb.155:
	mov	w11, #8                         ; =0x8
	add	x10, sp, #1072
LBB16_156:                              ; %b251
	stp	q0, q1, [x10]
	ldr	q0, [sp, #1200]
	ldr	q1, [sp, #1216]
	stp	q2, q3, [x10, #32]
	ldr	q2, [sp, #1232]
	stp	q0, q1, [sp, #1008]
	ldur	q0, [x9, #168]
	ldur	q1, [x9, #152]
	str	q2, [sp, #1040]
	ldur	q2, [x9, #136]
	stp	q1, q0, [sp, #976]
	ldur	q0, [x9, #120]
	ldr	q3, [sp, #1040]
	strb	w11, [x10, w12, uxtw]
	ldr	x11, [sp, #1248]
	stp	q0, q2, [sp, #944]
	ldp	q0, q1, [sp, #1008]
	mov	x9, x11
	str	x11, [sp, #1056]
	str	x9, [x8, #48]
	str	q0, [x8]
	ldp	q2, q0, [x10]
	stp	q1, q3, [x8, #16]
	stur	q0, [x8, #72]
	ldp	q1, q0, [x10, #32]
	stur	q2, [x8, #56]
	stur	q1, [x8, #88]
	ldp	q2, q1, [sp, #976]
	stur	q0, [x8, #104]
	stur	q1, [x8, #168]
	ldp	q1, q0, [sp, #944]
	stur	q2, [x8, #152]
	stur	q0, [x8, #136]
	stur	q1, [x8, #120]
	b	LBB16_84
LBB16_157:                              ; %b273
	cmp	w9, #123
	b.eq	LBB16_159
; %bb.158:                              ; %b273
	cmp	w9, #91
	b.ne	LBB16_161
LBB16_159:                              ; %b277
	cmp	w10, #64
	b.ne	LBB16_163
; %bb.160:                              ; %b279
	mov	w9, #7                          ; =0x7
	b	LBB16_173
LBB16_161:                              ; %b291
	sub	w9, w19, #48
	and	w9, w9, #0xff
	cmp	w9, #9
	b.hi	LBB16_167
; %bb.162:                              ; %b292
	ldr	q0, [sp, #1264]
	ldr	q1, [sp, #1280]
	ldr	q2, [sp, #1296]
	ldr	w9, [sp, #1380]
	stp	q0, q1, [sp, #544]
	ldr	q0, [sp, #1312]
	ldr	q1, [sp, #1200]
	str	w9, [sp, #464]
	and	w9, w19, #0xff
	stp	q2, q0, [sp, #576]
	ldr	q0, [sp, #1216]
	cmp	w9, #48
	ldr	q2, [sp, #1232]
	mov	w9, #11                         ; =0xb
	ldr	w10, [sp, #464]
	stp	q1, q0, [sp, #480]
	ldr	q0, [sp, #1248]
	cinc	w9, w9, ne
	ldur	q1, [x20, #164]
	str	w9, [x8, #128]
	stp	q2, q0, [sp, #512]
	ldur	q0, [x20, #148]
	ldur	q2, [x20, #132]
	str	w10, [x8, #180]
	stp	q0, q1, [sp, #432]
	ldp	q1, q0, [sp, #544]
	str	q2, [sp, #416]
	stp	q1, q0, [x8, #64]
	ldp	q2, q0, [sp, #576]
	stp	q2, q0, [x8, #96]
	ldp	q1, q0, [sp, #480]
	stp	q1, q0, [x8]
	ldp	q1, q0, [sp, #512]
	stp	q1, q0, [x8, #32]
	ldp	q1, q0, [sp, #432]
	stur	q0, [x8, #164]
	ldr	q0, [sp, #416]
	stur	q1, [x8, #148]
	stur	q0, [x8, #132]
	b	LBB16_84
LBB16_163:                              ; %b281
	mov	x21, x8
	add	x8, sp, #1200
	bl	_liza___liza_owned___liza_json_done
	and	w9, w19, #0xff
	ldr	w8, [sp, #1320]
	cmp	w9, #91
	b.ne	LBB16_174
; %bb.164:                              ; %b282
	cmp	w8, #64
	b.hs	LBB16_181
; %bb.165:
	mov	w11, #1                         ; =0x1
	add	x10, sp, #812
	b	LBB16_176
LBB16_166:                              ; %b286
	ldr	q0, [sp, #1264]
	ldr	q1, [sp, #1280]
	mov	w9, #1                          ; =0x1
	ldr	q2, [sp, #1312]
	strb	wzr, [sp, #620]
	stp	q0, q1, [x8, #64]
	ldr	q0, [sp, #1296]
	ldr	q1, [sp, #1200]
	str	w9, [x8, #128]
	stp	q0, q2, [x8, #96]
	ldr	q0, [sp, #1216]
	ldr	q2, [sp, #1232]
	strb	wzr, [x8, #132]
	b	LBB16_126
LBB16_167:                              ; %b297
	and	w9, w19, #0xff
	sub	w9, w9, #102
	cmp	w9, #14
	b.hi	LBB16_172
; %bb.168:                              ; %b297
	mov	w10, #1                         ; =0x1
	lsl	w9, w10, w9
	mov	w10, #16641                     ; =0x4101
	tst	w9, w10
	b.eq	LBB16_172
; %bb.169:                              ; %b304
	mov	x10, x8
	and	w9, w19, #0xff
	ldr	w8, [sp, #1332]
	add	x12, sp, #1200
	cmp	w9, #102
	add	x11, x12, #144
	b.eq	LBB16_177
; %bb.170:                              ; %b304
	cmp	w9, #116
	b.ne	LBB16_178
; %bb.171:
	mov	w9, #1                          ; =0x1
	b	LBB16_180
LBB16_172:                              ; %b246
	mov	w9, #1                          ; =0x1
LBB16_173:                              ; %common.ret
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1344]
	ldr	q2, [sp, #1264]
	ldr	q3, [sp, #1312]
	str	w9, [sp, #1368]
	ldr	q5, [sp, #1248]
	stp	q0, q1, [x8, #128]
	ldr	q0, [sp, #1280]
	ldr	q1, [sp, #1296]
	ldr	q4, [sp, #1360]
	ldr	x9, [sp, #1248]
	stp	q2, q0, [x8, #64]
	ldr	q0, [sp, #1200]
	ldr	q2, [sp, #1232]
	stp	q1, q3, [x8, #96]
	ldr	q1, [sp, #1216]
	stp	q2, q5, [x8, #32]
	stp	q0, q1, [x8]
	str	x9, [sp, #1376]
	str	x9, [x8, #176]
	str	q4, [x8, #160]
	b	LBB16_84
LBB16_174:                              ; %b283
	cmp	w8, #64
	b.hs	LBB16_181
; %bb.175:
	mov	w11, #4                         ; =0x4
	add	x10, sp, #748
LBB16_176:                              ; %v545_ok
	ldur	q0, [x20, #56]
	ldur	q1, [x20, #72]
	add	x13, sp, #624
	ldur	q2, [x20, #88]
	ldr	x12, [sp, #1248]
	stp	q0, q1, [x10]
	ldur	q0, [x20, #104]
	ldr	q1, [sp, #1216]
	str	x12, [sp, #736]
	stp	q2, q0, [x10, #32]
	ldr	q0, [sp, #1200]
	strb	w11, [x10, x8]
	add	x11, sp, #1200
	add	w8, w8, #1
	stp	q0, q1, [sp, #688]
	ldr	q0, [sp, #1232]
	ldur	q1, [x11, #156]
	ldur	q2, [x11, #140]
	str	w8, [x21, #120]
	str	q0, [sp, #720]
	ldur	q0, [x11, #168]
	stur	q0, [x13, #44]
	ldur	q0, [x11, #124]
	mov	x11, x12
	stp	q2, q1, [sp, #640]
	str	q0, [sp, #624]
	ldp	q1, q0, [sp, #704]
	str	x11, [x21, #48]
	stp	q1, q0, [x21, #16]
	ldr	q0, [sp, #688]
	str	q0, [x21]
	ldp	q2, q0, [x10]
	stur	q0, [x21, #72]
	ldp	q1, q0, [x10, #32]
	stur	q2, [x21, #56]
	ldr	q2, [sp, #624]
	stur	q0, [x21, #104]
	ldur	q0, [x13, #44]
	stur	q1, [x21, #88]
	stur	q0, [x21, #168]
	ldp	q0, q1, [sp, #640]
	stur	q2, [x21, #124]
	stur	q1, [x21, #156]
	stur	q0, [x21, #140]
	b	LBB16_84
LBB16_177:
	mov	w9, #2                          ; =0x2
	b	LBB16_179
LBB16_178:                              ; %b309
	mov	w9, #3                          ; =0x3
LBB16_179:                              ; %b310_to_b311
	ldr	q0, [sp, #1264]
	ldr	q1, [sp, #1280]
	ldr	q2, [sp, #1312]
	ldr	x12, [x11, #32]
	stp	q0, q1, [sp, #352]
	ldr	q0, [sp, #1296]
	ldr	q1, [sp, #1200]
	str	x12, [sp, #272]
	add	x12, sp, #288
	stp	q0, q2, [sp, #384]
	ldr	q0, [sp, #1216]
	ldr	q2, [sp, #1232]
	stp	q1, q0, [sp, #288]
	ldr	q0, [sp, #1248]
	stp	q2, q0, [sp, #320]
	ldp	q1, q0, [x11]
	add	x11, sp, #240
	stp	q1, q0, [sp, #240]
LBB16_180:                              ; %b311
	ldp	q0, q1, [x12, #64]
	stp	q0, q1, [sp, #176]
	ldp	q0, q2, [x12, #96]
	stp	q0, q2, [sp, #208]
	ldp	q1, q0, [x12]
	stp	q1, q0, [sp, #112]
	ldp	q2, q0, [x12, #32]
	ldr	x12, [x11, #32]
	stp	q2, q0, [sp, #144]
	ldp	q1, q0, [x11]
	str	x12, [sp, #96]
	mov	w11, #20                        ; =0x14
	stp	w11, w8, [x10, #128]
	ldr	x11, [sp, #96]
	mov	w8, #1                          ; =0x1
	stp	q1, q0, [sp, #64]
	ldp	q0, q2, [sp, #144]
	stp	w9, w8, [x10, #136]
	str	x11, [x10, #176]
	stp	q0, q2, [x10, #32]
	ldp	q0, q1, [sp, #112]
	stp	q0, q1, [x10]
	ldp	q0, q2, [sp, #208]
	stp	q0, q2, [x10, #96]
	ldp	q0, q1, [sp, #176]
	stp	q0, q1, [x10, #64]
	ldp	q1, q0, [sp, #64]
	stp	q1, q0, [x10, #144]
	b	LBB16_84
LBB16_181:                              ; %v17_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_json.feed                 ; -- Begin function liza_json.feed
	.p2align	2
_liza_json.feed:                        ; @liza_json.feed
; %bb.0:                                ; %b0
	sub	sp, sp, #416
	ldr	w10, [x0, #168]
	stp	x20, x19, [sp, #384]            ; 16-byte Folded Spill
	mov	x19, x8
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #336]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #352]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #400]            ; 16-byte Folded Spill
	cbz	w10, LBB17_2
; %bb.1:                                ; %b1
	ldp	q0, q1, [x0]
	ldr	x8, [x0, #176]
	ldp	q2, q3, [x0, #32]
	ldr	q17, [x0, #128]
	ldp	q4, q5, [x0, #64]
	ldp	q6, q7, [x0, #96]
	ldp	q18, q16, [x0, #144]
	str	x8, [x19, #176]
	stp	q1, q2, [x19, #16]
	stp	q3, q4, [x19, #48]
	stp	q5, q6, [x19, #80]
	stp	q7, q17, [x19, #112]
	stp	q18, q16, [x19, #144]
	str	q0, [x19]
	b	LBB17_18
LBB17_2:                                ; %b3_to_b4
	mov	x8, x0
	ldur	q0, [x0, #120]
	add	x22, sp, #192
	ldur	q1, [x8, #136]
	mov	w9, w2
	mov	x20, x1
	ldp	x1, x2, [x8, #8]
	ldr	x0, [x0]
	stp	q0, q1, [x22, #64]
	ldur	q0, [x8, #152]
	ldur	q1, [x8, #168]
	ldp	w6, w27, [x8, #32]
	stp	q0, q1, [x22, #96]
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	ldp	x7, x23, [x8, #40]
	ldr	w3, [x8, #24]
	ldrb	w4, [x8, #28]
	ldrb	w5, [x8, #29]
	ldrh	w26, [x8, #30]
	stp	q0, q1, [x22]
	ldur	q0, [x8, #88]
	ldur	q1, [x8, #104]
	stp	q0, q1, [x22, #32]
	cbz	w9, LBB17_12
; %bb.3:                                ; %v8_ok.lr.ph
	add	x24, sp, #8
	mov	w25, w9
LBB17_4:                                ; %v8_ok
                                        ; =>This Inner Loop Header: Depth=1
	ldrb	w21, [x20], #1
	strb	w21, [sp]
	bl	_liza_utf8_stream.feed_byte
	ldp	q0, q1, [x22, #64]
	cmp	w6, #2
	strh	w26, [sp, #38]
	stp	x0, x1, [sp, #8]
	stur	q0, [x24, #120]
	stur	q1, [x24, #136]
	ldp	q0, q1, [x22, #96]
	str	x2, [sp, #24]
	str	w3, [sp, #32]
	stur	q0, [x24, #152]
	stur	q1, [x24, #168]
	ldp	q0, q1, [x22]
	strb	w4, [sp, #36]
	strb	w5, [sp, #37]
	stur	q0, [x24, #56]
	stur	q1, [x24, #72]
	ldp	q0, q1, [x22, #32]
	stp	w6, w27, [sp, #40]
	stp	x7, x23, [sp, #48]
	stur	q0, [x24, #88]
	stur	q1, [x24, #104]
	b.eq	LBB17_7
; %bb.5:                                ; %v8_ok
                                        ;   in Loop: Header=BB17_4 Depth=1
	cmp	w6, #1
	b.ne	LBB17_8
; %bb.6:                                ; %b1.i
                                        ;   in Loop: Header=BB17_4 Depth=1
	mov	w9, wzr
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB17_9
	b	LBB17_13
LBB17_7:                                ; %b4.i
                                        ;   in Loop: Header=BB17_4 Depth=1
	mov	w9, wzr
	mov	w8, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB17_9
	b	LBB17_13
LBB17_8:                                ;   in Loop: Header=BB17_4 Depth=1
	mov	w8, wzr
	mov	x7, xzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB17_13
LBB17_9:                                ; %b13
                                        ;   in Loop: Header=BB17_4 Depth=1
	add	x8, sp, #8
	mov	w1, w21
	bl	_liza___liza_owned___liza_json_step
	ldr	w8, [sp, #176]
	cbnz	w8, LBB17_15
; %bb.10:                               ; %b16
                                        ;   in Loop: Header=BB17_4 Depth=1
	ldr	x8, [sp, #56]
	adds	x23, x8, #1
	b.hs	LBB17_19
; %bb.11:                               ; %v32_ok
                                        ;   in Loop: Header=BB17_4 Depth=1
	ldur	q0, [x24, #120]
	ldur	q1, [x24, #136]
	subs	x25, x25, #1
	ldp	x0, x1, [sp, #8]
	ldr	x2, [sp, #24]
	stp	q0, q1, [x22, #64]
	ldur	q0, [x24, #152]
	ldur	q1, [x24, #168]
	ldr	w3, [sp, #32]
	ldrb	w4, [sp, #36]
	ldrb	w5, [sp, #37]
	stp	q0, q1, [x22, #96]
	ldur	q0, [x24, #56]
	ldur	q1, [x24, #72]
	ldrh	w26, [sp, #38]
	ldr	x7, [sp, #48]
	stp	q0, q1, [x22]
	ldur	q0, [x24, #88]
	ldur	q1, [x24, #104]
	ldp	w6, w27, [sp, #40]
	stp	q0, q1, [x22, #32]
	b.ne	LBB17_4
LBB17_12:                               ; %b6
	ldp	q0, q1, [x22, #64]
	stp	x0, x1, [x19]
	str	x2, [x19, #16]
	str	w3, [x19, #24]
	stur	q0, [x19, #120]
	stur	q1, [x19, #136]
	ldp	q0, q1, [x22, #96]
	strb	w4, [x19, #28]
	strb	w5, [x19, #29]
	stur	q0, [x19, #152]
	stur	q1, [x19, #168]
	ldp	q0, q1, [x22]
	strh	w26, [x19, #30]
	stp	w6, w27, [x19, #32]
	stur	q0, [x19, #56]
	stur	q1, [x19, #72]
	ldp	q0, q1, [x22, #32]
	stp	x7, x23, [x19, #40]
	stur	q0, [x19, #88]
	stur	q1, [x19, #104]
	b	LBB17_18
LBB17_13:                               ; %b9
	cbz	w8, LBB17_16
; %bb.14:                               ; %b12
	mov	w8, #8                          ; =0x8
	b	LBB17_17
LBB17_15:                               ; %b14
	ldur	q0, [sp, #136]
	ldur	q1, [sp, #152]
	ldur	q2, [sp, #168]
	ldr	x8, [sp, #184]
	stp	q0, q1, [x19, #128]
	ldur	q0, [sp, #72]
	ldur	q1, [sp, #88]
	str	q2, [x19, #160]
	ldur	q2, [sp, #104]
	stp	q0, q1, [x19, #64]
	ldur	q0, [sp, #120]
	ldur	q1, [sp, #8]
	str	x8, [x19, #176]
	stp	q2, q0, [x19, #96]
	ldur	q0, [sp, #24]
	ldur	q2, [sp, #40]
	stp	q1, q0, [x19]
	ldur	q0, [sp, #56]
	stp	q2, q0, [x19, #32]
	b	LBB17_18
LBB17_16:                               ; %b11
	mov	w8, #5                          ; =0x5
LBB17_17:                               ; %common.ret
	ldur	q0, [sp, #136]
	ldur	q1, [sp, #152]
	ldur	q2, [sp, #72]
	str	w8, [sp, #176]
	stp	q0, q1, [x19, #128]
	ldur	q0, [sp, #88]
	ldur	q1, [sp, #104]
	str	x7, [sp, #184]
	stp	q2, q0, [x19, #64]
	ldur	q0, [sp, #120]
	ldur	q2, [sp, #8]
	str	x7, [x19, #176]
	stp	q1, q0, [x19, #96]
	ldur	q0, [sp, #24]
	ldur	q1, [sp, #40]
	stp	q2, q0, [x19]
	ldur	q0, [sp, #56]
	stp	q1, q0, [x19, #32]
	ldur	q0, [sp, #168]
	str	q0, [x19, #160]
LBB17_18:                               ; %common.ret
	ldp	x29, x30, [sp, #400]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #384]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #368]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #352]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #416
	ret
LBB17_19:                               ; %v32_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_json.status               ; -- Begin function liza_json.status
	.p2align	2
_liza_json.status:                      ; @liza_json.status
; %bb.0:                                ; %b0
	ldr	w9, [x0, #168]
	cbz	w9, LBB18_2
; %bb.1:                                ; %b3
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	mov	x8, x0
	cset	w11, eq
	cmp	w9, #3
	ldr	x2, [x8, #176]
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	mov	w0, wzr
	csel	w1, w9, w10, eq
	ret
LBB18_2:
	mov	w1, wzr
	mov	x2, xzr
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_json.finish               ; -- Begin function liza_json.finish
	.p2align	2
_liza_json.finish:                      ; @liza_json.finish
; %bb.0:                                ; %b0
	ldr	w9, [x0, #168]
	cbz	w9, LBB19_6
; %bb.1:                                ; %b3.i
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	ldr	x3, [x0, #176]
	cset	w11, eq
	cmp	w9, #3
	mov	w8, wzr
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	csel	w2, w9, w10, eq
	cbz	w8, LBB19_7
LBB19_2:                                ; %b4
	ldr	w8, [x0, #32]
	ldr	x3, [x0, #40]
	cmp	w8, #2
	b.eq	LBB19_8
; %bb.3:                                ; %b4
	cmp	w8, #1
	b.eq	LBB19_9
; %bb.4:                                ; %b6.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB19_11
; %bb.5:                                ; %b7.i
	ldr	x3, [x0, #16]
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB19_10
	b	LBB19_12
LBB19_6:
	mov	w2, wzr
	mov	x3, xzr
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB19_2
LBB19_7:                                ; %b2
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	ret
LBB19_8:                                ; %b4.i
	mov	w8, #1                          ; =0x1
LBB19_9:                                ; %liza_utf8_stream.finish.exit
	cbz	w8, LBB19_12
LBB19_10:                               ; %b7
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB19_11:                               ; %b9.i
	mov	x3, xzr
	cbnz	w8, LBB19_10
LBB19_12:                               ; %b6
	ldr	w8, [x0, #128]
	cmp	w8, #17
	b.hi	LBB19_22
; %bb.13:                               ; %b6
	mov	w9, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w9, w9, w8
	movk	w10, #2, lsl #16
	tst	w9, w10
	b.eq	LBB19_22
; %bb.14:                               ; %b18
	sub	sp, sp, #208
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x8, [x0, #176]
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	str	q2, [sp, #160]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #64]
	str	x8, [sp, #176]
	mov	x8, sp
	str	wzr, [sp, #128]
	stp	q0, q1, [sp, #64]
	ldp	q2, q0, [x0, #96]
	stp	q2, q0, [sp, #96]
	ldp	q1, q0, [x0]
	stp	q1, q0, [sp]
	ldp	q2, q0, [x0, #32]
	stp	q2, q0, [sp, #32]
	bl	_liza___liza_owned___liza_json_done
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldr	x3, [sp, #48]
	ldr	w10, [sp, #120]
	ldrb	w9, [sp, #124]
	ldr	w8, [sp, #128]
	ldr	x11, [sp, #160]
	add	sp, sp, #208
LBB19_15:                               ; %b20
	sub	w12, w8, #4
	cmp	w12, #2
	b.hi	LBB19_17
; %bb.16:                               ; %b27
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	mov	x3, x11
	ret
LBB19_17:                               ; %b29
	cbnz	w8, LBB19_21
; %bb.18:                               ; %b29
	cbnz	w10, LBB19_21
; %bb.19:                               ; %b29
	tbz	w9, #0, LBB19_21
; %bb.20:                               ; %b38
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ret
LBB19_21:                               ; %b36
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	mov	w0, #1                          ; =0x1
	ret
LBB19_22:                               ; %b19_to_b20
	ldr	x3, [x0, #48]
	ldr	w10, [x0, #120]
	ldrb	w9, [x0, #124]
	ldr	x11, [x0, #160]
	b	LBB19_15
                                        ; -- End function
	.globl	_liza___liza_owned___liza_json_fail ; -- Begin function liza___liza_owned___liza_json_fail
	.p2align	2
_liza___liza_owned___liza_json_fail:    ; @liza___liza_owned___liza_json_fail
; %bb.0:                                ; %b0
	str	w1, [x8, #168]
	str	x2, [x8, #176]
	ret
                                        ; -- End function
	.globl	_liza___liza_owned___liza_json_done ; -- Begin function liza___liza_owned___liza_json_done
	.p2align	2
_liza___liza_owned___liza_json_done:    ; @liza___liza_owned___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #416
	ldr	w21, [x8, #120]
	cbz	w21, LBB21_5
; %bb.1:                                ; %b2
	ldrb	w11, [x8, #56]
	ldrb	w9, [x8, #57]
	sub	w21, w21, #1
	ldrb	w10, [x8, #58]
	ldrb	w2, [x8, #94]
	cmp	w21, #64
	strb	w11, [sp, #160]
	ldrb	w3, [x8, #95]
	ldrb	w4, [x8, #96]
	stp	w11, w10, [sp, #148]            ; 8-byte Folded Spill
	ldrb	w11, [x8, #59]
	ldrb	w5, [x8, #97]
	str	w9, [sp, #156]                  ; 4-byte Folded Spill
	ldrb	w6, [x8, #98]
	ldrb	w7, [x8, #99]
	strb	w9, [sp, #161]
	ldrb	w9, [x8, #60]
	ldrb	w19, [x8, #100]
	strb	w10, [sp, #162]
	ldrb	w10, [x8, #61]
	ldrb	w20, [x8, #101]
	stp	w9, w11, [sp, #140]             ; 8-byte Folded Spill
	ldrb	w22, [x8, #102]
	ldrb	w23, [x8, #103]
	strb	w11, [sp, #163]
	ldrb	w11, [x8, #62]
	ldrb	w24, [x8, #104]
	strb	w9, [sp, #164]
	ldrb	w9, [x8, #63]
	ldrb	w25, [x8, #105]
	stp	w11, w10, [sp, #132]            ; 8-byte Folded Spill
	ldrb	w26, [x8, #106]
	ldrb	w27, [x8, #107]
	strb	w10, [sp, #165]
	ldrb	w10, [x8, #64]
	ldrb	w28, [x8, #108]
	strb	w11, [sp, #166]
	ldrb	w11, [x8, #65]
	ldrb	w30, [x8, #109]
	stp	w10, w9, [sp, #124]             ; 8-byte Folded Spill
	ldrb	w12, [x8, #113]
	ldrb	w13, [x8, #114]
	strb	w9, [sp, #167]
	ldrb	w9, [x8, #66]
	ldrb	w14, [x8, #115]
	strb	w10, [sp, #168]
	ldrb	w10, [x8, #67]
	ldrb	w15, [x8, #116]
	stp	w9, w11, [sp, #116]             ; 8-byte Folded Spill
	ldrb	w16, [x8, #117]
	ldrb	w17, [x8, #118]
	strb	w11, [sp, #169]
	ldrb	w11, [x8, #68]
	ldrb	w0, [x8, #119]
	strb	w9, [sp, #170]
	ldrb	w9, [x8, #69]
	stp	w11, w10, [sp, #108]            ; 8-byte Folded Spill
	strb	w10, [sp, #171]
	ldrb	w10, [x8, #70]
	strb	w11, [sp, #172]
	ldrb	w11, [x8, #71]
	stp	w10, w9, [sp, #100]             ; 8-byte Folded Spill
	strb	w9, [sp, #173]
	ldrb	w9, [x8, #72]
	strb	w10, [sp, #174]
	ldrb	w10, [x8, #73]
	stp	w9, w11, [sp, #92]              ; 8-byte Folded Spill
	strb	w11, [sp, #175]
	ldrb	w11, [x8, #74]
	strb	w9, [sp, #176]
	ldrb	w9, [x8, #75]
	stp	w11, w10, [sp, #84]             ; 8-byte Folded Spill
	strb	w10, [sp, #177]
	ldrb	w10, [x8, #76]
	strb	w11, [sp, #178]
	ldrb	w11, [x8, #77]
	stp	w10, w9, [sp, #76]              ; 8-byte Folded Spill
	strb	w9, [sp, #179]
	ldrb	w9, [x8, #78]
	strb	w10, [sp, #180]
	ldrb	w10, [x8, #79]
	stp	w9, w11, [sp, #68]              ; 8-byte Folded Spill
	strb	w11, [sp, #181]
	ldrb	w11, [x8, #80]
	strb	w9, [sp, #182]
	ldrb	w9, [x8, #81]
	stp	w11, w10, [sp, #60]             ; 8-byte Folded Spill
	strb	w10, [sp, #183]
	ldrb	w10, [x8, #82]
	strb	w11, [sp, #184]
	ldrb	w11, [x8, #83]
	stp	w10, w9, [sp, #52]              ; 8-byte Folded Spill
	strb	w9, [sp, #185]
	ldrb	w9, [x8, #84]
	strb	w10, [sp, #186]
	ldrb	w10, [x8, #85]
	stp	w9, w11, [sp, #44]              ; 8-byte Folded Spill
	strb	w9, [sp, #188]
	ldrb	w9, [x8, #86]
	strb	w10, [sp, #189]
	stp	w9, w10, [sp, #36]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #87]
	strb	w9, [sp, #190]
	ldrb	w9, [x8, #88]
	strb	w10, [sp, #191]
	stp	w9, w10, [sp, #28]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #89]
	strb	w9, [sp, #192]
	ldrb	w9, [x8, #90]
	strb	w10, [sp, #193]
	stp	w9, w10, [sp, #20]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #91]
	strb	w9, [sp, #194]
	ldrb	w9, [x8, #92]
	strb	w10, [sp, #195]
	stp	w9, w10, [sp, #12]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #93]
	strb	w11, [sp, #187]
	ldrb	w11, [x8, #112]
	strb	w9, [sp, #196]
	ldrb	w9, [x8, #110]
	str	w10, [sp, #8]                   ; 4-byte Folded Spill
	strb	w10, [sp, #197]
	ldrb	w10, [x8, #111]
	strb	w2, [sp, #198]
	strb	w3, [sp, #199]
	strb	w4, [sp, #200]
	strb	w5, [sp, #201]
	strb	w6, [sp, #202]
	strb	w7, [sp, #203]
	strb	w19, [sp, #204]
	strb	w20, [sp, #205]
	strb	w22, [sp, #206]
	strb	w23, [sp, #207]
	strb	w24, [sp, #208]
	strb	w25, [sp, #209]
	strb	w26, [sp, #210]
	strb	w27, [sp, #211]
	strb	w28, [sp, #212]
	strb	w30, [sp, #213]
	strb	w9, [sp, #214]
	strb	w10, [sp, #215]
	strb	w11, [sp, #216]
	strb	w12, [sp, #217]
	strb	w13, [sp, #218]
	strb	w14, [sp, #219]
	strb	w15, [sp, #220]
	strb	w16, [sp, #221]
	strb	w17, [sp, #222]
	strb	w0, [sp, #223]
	b.hs	LBB21_9
; %bb.2:                                ; %v10_ok
	add	x1, sp, #160
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	b.eq	LBB21_4
; %bb.3:                                ; %b3
	ldr	w1, [sp, #148]                  ; 4-byte Folded Reload
	strb	w2, [sp, #262]
	strb	w3, [sp, #263]
	strb	w1, [sp, #224]
	ldr	w1, [sp, #156]                  ; 4-byte Folded Reload
	strb	w4, [sp, #264]
	strb	w1, [sp, #225]
	ldr	w1, [sp, #152]                  ; 4-byte Folded Reload
	strb	w5, [sp, #265]
	strb	w1, [sp, #226]
	ldr	w1, [sp, #144]                  ; 4-byte Folded Reload
	strb	w6, [sp, #266]
	strb	w1, [sp, #227]
	ldr	w1, [sp, #140]                  ; 4-byte Folded Reload
	strb	w7, [sp, #267]
	strb	w1, [sp, #228]
	ldr	w1, [sp, #136]                  ; 4-byte Folded Reload
	strb	w19, [sp, #268]
	strb	w1, [sp, #229]
	ldr	w1, [sp, #132]                  ; 4-byte Folded Reload
	strb	w20, [sp, #269]
	strb	w1, [sp, #230]
	ldr	w1, [sp, #128]                  ; 4-byte Folded Reload
	strb	w22, [sp, #270]
	strb	w1, [sp, #231]
	ldr	w1, [sp, #124]                  ; 4-byte Folded Reload
	strb	w23, [sp, #271]
	strb	w1, [sp, #232]
	ldr	w1, [sp, #120]                  ; 4-byte Folded Reload
	strb	w24, [sp, #272]
	strb	w1, [sp, #233]
	ldr	w1, [sp, #116]                  ; 4-byte Folded Reload
	strb	w25, [sp, #273]
	strb	w1, [sp, #234]
	ldr	w1, [sp, #112]                  ; 4-byte Folded Reload
	strb	w26, [sp, #274]
	strb	w1, [sp, #235]
	ldr	w1, [sp, #108]                  ; 4-byte Folded Reload
	strb	w27, [sp, #275]
	strb	w1, [sp, #236]
	ldr	w1, [sp, #104]                  ; 4-byte Folded Reload
	strb	w28, [sp, #276]
	strb	w1, [sp, #237]
	ldr	w1, [sp, #100]                  ; 4-byte Folded Reload
	strb	w30, [sp, #277]
	strb	w1, [sp, #238]
	ldr	w1, [sp, #96]                   ; 4-byte Folded Reload
	strb	w9, [sp, #278]
	add	x9, sp, #224
	strb	w1, [sp, #239]
	ldr	w1, [sp, #92]                   ; 4-byte Folded Reload
	strb	w10, [sp, #279]
	strb	w1, [sp, #240]
	ldr	w1, [sp, #88]                   ; 4-byte Folded Reload
	strb	w11, [sp, #280]
	strb	w1, [sp, #241]
	ldr	w1, [sp, #84]                   ; 4-byte Folded Reload
	strb	w12, [sp, #281]
	strb	w1, [sp, #242]
	ldr	w1, [sp, #80]                   ; 4-byte Folded Reload
	strb	w13, [sp, #282]
	strb	w1, [sp, #243]
	ldr	w1, [sp, #76]                   ; 4-byte Folded Reload
	strb	w14, [sp, #283]
	strb	w1, [sp, #244]
	ldr	w1, [sp, #72]                   ; 4-byte Folded Reload
	strb	w15, [sp, #284]
	strb	w1, [sp, #245]
	ldr	w1, [sp, #68]                   ; 4-byte Folded Reload
	strb	w16, [sp, #285]
	strb	w1, [sp, #246]
	ldr	w1, [sp, #64]                   ; 4-byte Folded Reload
	strb	w17, [sp, #286]
	strb	w1, [sp, #247]
	ldr	w1, [sp, #60]                   ; 4-byte Folded Reload
	strb	w0, [sp, #287]
	strb	w1, [sp, #248]
	ldr	w1, [sp, #56]                   ; 4-byte Folded Reload
	strb	w1, [sp, #249]
	ldr	w1, [sp, #52]                   ; 4-byte Folded Reload
	strb	w1, [sp, #250]
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	strb	w1, [sp, #251]
	ldr	w1, [sp, #44]                   ; 4-byte Folded Reload
	strb	w1, [sp, #252]
	ldr	w1, [sp, #40]                   ; 4-byte Folded Reload
	strb	w1, [sp, #253]
	ldr	w1, [sp, #36]                   ; 4-byte Folded Reload
	strb	w1, [sp, #254]
	ldr	w1, [sp, #32]                   ; 4-byte Folded Reload
	strb	w1, [sp, #255]
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	strb	w1, [sp, #256]
	ldr	w1, [sp, #24]                   ; 4-byte Folded Reload
	strb	w1, [sp, #257]
	ldr	w1, [sp, #20]                   ; 4-byte Folded Reload
	strb	w1, [sp, #258]
	ldr	w1, [sp, #16]                   ; 4-byte Folded Reload
	strb	w1, [sp, #259]
	ldr	w1, [sp, #12]                   ; 4-byte Folded Reload
	strb	w1, [sp, #260]
	ldr	w1, [sp, #8]                    ; 4-byte Folded Reload
	strb	w1, [sp, #261]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	b.ne	LBB21_6
LBB21_4:                                ; %v20_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #352
	ldur	q2, [x8, #88]
	mov	w10, #2                         ; =0x2
	stp	q0, q1, [sp, #352]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #384]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #352]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #384]
	b	LBB21_7
LBB21_5:                                ; %b1
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #124]
	b	LBB21_8
LBB21_6:                                ; %v25_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #288
	ldur	q2, [x8, #88]
	mov	w10, #7                         ; =0x7
	stp	q0, q1, [sp, #288]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #320]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #288]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #320]
LBB21_7:                                ; %b9
	stur	q0, [x8, #88]
	stur	q1, [x8, #104]
LBB21_8:                                ; %b9
	add	sp, sp, #416
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB21_9:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_owned___liza_json_step ; -- Begin function liza___liza_owned___liza_json_step
	.p2align	2
_liza___liza_owned___liza_json_step:    ; @liza___liza_owned___liza_json_step
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #624
	ldr	w9, [x8, #128]
	mov	w19, w1
	cmp	w9, #3
	b.le	LBB22_7
; %bb.1:                                ; %b0
	cmp	w9, #5
	b.gt	LBB22_10
; %bb.2:                                ; %b0
	cmp	w9, #4
	b.eq	LBB22_32
; %bb.3:                                ; %b0
	cmp	w9, #5
	b.ne	LBB22_25
; %bb.4:                                ; %b52
	and	w9, w19, #0xff
	cmp	w9, #117
	b.ne	LBB22_47
; %bb.5:                                ; %b56
	mov	w9, #6                          ; =0x6
LBB22_6:                                ; %common.ret
	str	w9, [x8, #128]
	str	xzr, [x8, #144]
	b	LBB22_149
LBB22_7:                                ; %b0
	cmp	w9, #1
	b.eq	LBB22_17
; %bb.8:                                ; %b0
	cmp	w9, #2
	b.eq	LBB22_36
; %bb.9:                                ; %b0
	cmp	w9, #3
	b.eq	LBB22_15
	b	LBB22_25
LBB22_10:                               ; %b0
	cmp	w9, #6
	b.eq	LBB22_15
; %bb.11:                               ; %b0
	cmp	w9, #20
	b.ne	LBB22_25
; %bb.12:                               ; %b91
	ldp	w10, w9, [x8, #136]
	cmp	w10, #2
	b.eq	LBB22_56
; %bb.13:                               ; %b91
	cmp	w10, #1
	b.ne	LBB22_57
; %bb.14:                               ; %b104.thread
	cmp	w9, #1
	mov	w11, #114                       ; =0x72
	mov	w12, #117                       ; =0x75
	csel	w11, w11, wzr, eq
	cmp	w9, #2
	csel	w11, w12, w11, eq
	cmp	w9, #3
	mov	w12, #101                       ; =0x65
	csel	w12, w12, w11, eq
	b	LBB22_58
LBB22_15:                               ; %b61
	sub	w10, w19, #48
	and	w10, w10, #0xff
	cmp	w10, #10
	b.hs	LBB22_34
; %bb.16:
	mov	w10, #-48                       ; =0xffffffd0
	b	LBB22_42
LBB22_17:                               ; %b1
	and	w9, w19, #0xff
	cmp	w9, #32
	b.lo	LBB22_147
; %bb.18:                               ; %b5
	cmp	w9, #92
	b.eq	LBB22_67
; %bb.19:                               ; %b5
	cmp	w9, #34
	b.ne	LBB22_149
; %bb.20:                               ; %b6
	ldrb	w9, [x8, #132]
	str	wzr, [x8, #128]
	cmp	w9, #1
	b.ne	LBB22_63
; %bb.21:                               ; %b8
	ldr	w9, [x8, #120]
	subs	w9, w9, #1
	b.lo	LBB22_156
; %bb.22:                               ; %v17_ok
	cmp	w9, #64
	b.hs	LBB22_156
; %bb.23:                               ; %v18_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x10, sp, #560
	ldur	q2, [x8, #88]
	mov	w11, #5                         ; =0x5
	stp	q0, q1, [sp, #560]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #592]
	strb	w11, [x10, w9, uxtw]
	ldp	q0, q1, [sp, #560]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #592]
LBB22_24:                               ; %common.ret
	stur	q0, [x8, #88]
	stur	q1, [x8, #104]
	b	LBB22_149
LBB22_25:                               ; %b132
	sub	w10, w9, #10
	cmp	w10, #7
	b.hi	LBB22_84
; %bb.26:                               ; %b136
	sub	w10, w19, #48
	and	w10, w10, #0xff
	cmp	w10, #9
	b.hi	LBB22_64
; %bb.27:                               ; %b138
	cmp	w9, #10
	b.eq	LBB22_135
; %bb.28:                               ; %b138
	cmp	w9, #13
	b.eq	LBB22_73
; %bb.29:                               ; %b138
	cmp	w9, #11
	b.eq	LBB22_72
; %bb.30:                               ; %b151
	sub	w9, w9, #15
	cmp	w9, #1
	b.hi	LBB22_149
; %bb.31:                               ; %b155
	mov	w9, #17                         ; =0x11
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_32:                               ; %b46
	and	w9, w19, #0xff
	cmp	w9, #92
	b.ne	LBB22_47
; %bb.33:                               ; %b50
	mov	w9, #5                          ; =0x5
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_34:                               ; %b6.i
	sub	w10, w19, #65
	and	w10, w10, #0xff
	cmp	w10, #6
	b.hs	LBB22_40
; %bb.35:
	mov	w10, #-55                       ; =0xffffffc9
	b	LBB22_42
LBB22_36:                               ; %b16
	and	w9, w19, #0xff
	sub	w10, w9, #98
	cmp	w10, #19
	b.hi	LBB22_52
; %bb.37:                               ; %b16
	mov	w11, #1                         ; =0x1
	mov	w12, #4113                      ; =0x1011
	lsl	w11, w11, w10
	movk	w12, #5, lsl #16
	tst	w11, w12
	b.ne	LBB22_54
; %bb.38:                               ; %b16
	cmp	w10, #19
	b.ne	LBB22_52
; %bb.39:                               ; %b42
	mov	w9, #3                          ; =0x3
	b	LBB22_6
LBB22_40:                               ; %b12.i
	sub	w10, w19, #97
	and	w10, w10, #0xff
	cmp	w10, #6
	b.hs	LBB22_55
; %bb.41:
	mov	w10, #-87                       ; =0xffffffa9
LBB22_42:                               ; %b65
	ldr	w11, [x8, #148]
	lsr	w12, w11, #28
	cbnz	w12, LBB22_156
; %bb.43:                               ; %v128_ok
	add	w10, w10, w19, uxtb
	ldr	w12, [x8, #144]
	add	w10, w10, w11, lsl #4
	adds	w11, w12, #1
	str	w10, [x8, #148]
	b.hs	LBB22_156
; %bb.44:                               ; %v133_ok
	cmp	w11, #4
	str	w11, [x8, #144]
	b.ne	LBB22_149
; %bb.45:                               ; %b66
	cmp	w9, #6
	b.ne	LBB22_49
; %bb.46:                               ; %b68
	sub	w9, w10, #14, lsl #12           ; =57344
	cmn	w9, #1025
	b.hi	LBB22_54
LBB22_47:                               ; %b48
	ldr	x9, [x8, #160]
LBB22_48:                               ; %common.ret
	mov	w10, #4                         ; =0x4
	b	LBB22_148
LBB22_49:                               ; %b76
	and	w9, w10, #0xfffffc00
	mov	w10, #56320                     ; =0xdc00
	cmp	w9, w10
	b.eq	LBB22_68
; %bb.50:                               ; %b76
	mov	w10, #55296                     ; =0xd800
	cmp	w9, w10
	b.ne	LBB22_54
; %bb.51:                               ; %b80
	ldr	x10, [x8, #152]
	mov	w9, #4                          ; =0x4
	str	w9, [x8, #128]
	str	x10, [x8, #160]
	b	LBB22_149
LBB22_52:                               ; %b16
	sub	w9, w9, #34
	cmp	w9, #58
	b.hi	LBB22_55
; %bb.53:                               ; %b16
	mov	w10, #1                         ; =0x1
	lsl	x9, x10, x9
	mov	x10, #8193                      ; =0x2001
	movk	x10, #1024, lsl #48
	tst	x9, x10
	b.eq	LBB22_55
LBB22_54:                               ; %b39
	mov	w9, #1                          ; =0x1
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_55:                               ; %b44
	ldr	x9, [x8, #48]
	mov	w10, #3                         ; =0x3
	b	LBB22_148
LBB22_56:                               ; %b105
	cmp	w9, #1
	mov	w11, #97                        ; =0x61
	mov	w12, #108                       ; =0x6c
	csel	w11, w11, wzr, eq
	cmp	w9, #2
	csel	w11, w12, w11, eq
	cmp	w9, #3
	mov	w12, #115                       ; =0x73
	csel	w11, w12, w11, eq
	cmp	w9, #4
	mov	w12, #101                       ; =0x65
	csel	w12, w12, w11, eq
	mov	w11, #5                         ; =0x5
	b	LBB22_59
LBB22_57:
	mov	w12, wzr
LBB22_58:                               ; %b119
	mov	w11, #4                         ; =0x4
LBB22_59:                               ; %b119
	cmp	w9, #1
	mov	w13, #108                       ; =0x6c
	mov	w14, #117                       ; =0x75
	csel	w13, w14, w13, eq
	cmp	w10, #3
	csel	w10, w13, w12, eq
	cmp	w10, w19, uxtb
	b.ne	LBB22_147
; %bb.60:                               ; %b128
	adds	w9, w9, #1
	b.hs	LBB22_156
; %bb.61:                               ; %v251_ok
	cmp	w9, w11
	str	w9, [x8, #140]
	b.ne	LBB22_149
; %bb.62:                               ; %b129
	str	wzr, [x8, #128]
LBB22_63:                               ; %b10
	add	sp, sp, #624
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	b	_liza___liza_owned___liza_json_done
LBB22_64:                               ; %b158
	sub	w10, w9, #11
	cmp	w10, #1
	b.hi	LBB22_69
; %bb.65:                               ; %b158
	and	w10, w19, #0xff
	cmp	w10, #46
	b.ne	LBB22_69
; %bb.66:                               ; %b165
	mov	w9, #13                         ; =0xd
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_67:                               ; %b12
	ldr	x10, [x8, #48]
	mov	w9, #2                          ; =0x2
	str	w9, [x8, #128]
	str	x10, [x8, #152]
	b	LBB22_149
LBB22_68:                               ; %b86
	ldr	x9, [x8, #152]
	b	LBB22_48
LBB22_69:                               ; %b167
	cmp	w9, #16
	b.hi	LBB22_81
; %bb.70:                               ; %b167
	mov	w10, #1                         ; =0x1
	mov	w11, #22528                     ; =0x5800
	lsl	w10, w10, w9
	tst	w10, w11
	b.ne	LBB22_74
; %bb.71:                               ; %b167
	mov	w11, #9216                      ; =0x2400
	movk	w11, #1, lsl #16
	tst	w10, w11
	b.eq	LBB22_76
LBB22_72:                               ; %b140
	ldr	x9, [x8, #48]
	mov	w10, #2                         ; =0x2
	b	LBB22_148
LBB22_73:                               ; %b149
	mov	w9, #14                         ; =0xe
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_74:                               ; %b174
	orr	w10, w19, #0x20
	and	w10, w10, #0xff
	cmp	w10, #101
	b.ne	LBB22_80
; %bb.75:                               ; %b180
	mov	w9, #15                         ; =0xf
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_76:                               ; %b167
	cmp	w9, #15
	b.ne	LBB22_81
; %bb.77:                               ; %b183
	and	w9, w19, #0xff
	cmp	w9, #45
	b.eq	LBB22_79
; %bb.78:                               ; %b183
	cmp	w9, #43
	b.ne	LBB22_72
LBB22_79:                               ; %b189
	mov	w9, #16                         ; =0x10
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_80:                               ; %b191
	cmp	w9, #13
	b.eq	LBB22_72
LBB22_81:                               ; %b203
	and	w9, w19, #0xff
	cmp	w9, #44
	b.hi	LBB22_121
; %bb.82:                               ; %b203
	and	x10, x19, #0xff
	mov	w11, #1                         ; =0x1
	lsl	x10, x11, x10
	mov	x11, #9728                      ; =0x2600
	movk	x11, #4097, lsl #32
	tst	x10, x11
	b.eq	LBB22_121
LBB22_83:                               ; %b215
	str	wzr, [x8, #128]
	mov	x20, x8
	bl	_liza___liza_owned___liza_json_done
	mov	x8, x20
LBB22_84:                               ; %b216
	and	w9, w19, #0xff
	cmp	w9, #32
	b.hi	LBB22_86
; %bb.85:                               ; %b216
	mov	w9, w19
	mov	w10, #1                         ; =0x1
	and	x9, x9, #0xff
	lsl	x9, x10, x9
	mov	x10, #9728                      ; =0x2600
	movk	x10, #1, lsl #32
	tst	x9, x10
	b.ne	LBB22_149
LBB22_86:                               ; %b219
	ldr	w9, [x8, #120]
	cbz	w9, LBB22_89
; %bb.87:                               ; %b220
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	sub	w10, w9, #1
	ldur	q2, [x8, #88]
	cmp	w10, #64
	stp	q0, q1, [sp, #176]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #208]
	b.hs	LBB22_156
; %bb.88:                               ; %v411_ok
	add	x11, sp, #176
	ldrb	w10, [x11, w10, uxtw]
	b	LBB22_90
LBB22_89:
	mov	w10, wzr
LBB22_90:                               ; %b222
	and	w11, w19, #0xff
	cmp	w11, #125
	b.eq	LBB22_98
; %bb.91:                               ; %b222
	cmp	w11, #93
	b.ne	LBB22_94
; %bb.92:                               ; %b223
	sub	w11, w10, #1
	cmp	w11, #1
	b.hi	LBB22_94
; %bb.93:                               ; %b229
	subs	w9, w9, #1
	b.hs	LBB22_114
	b	LBB22_156
LBB22_94:                               ; %b240
	cmp	w10, #4
	b.le	LBB22_102
; %bb.95:                               ; %b240
	cmp	w10, #5
	b.eq	LBB22_123
; %bb.96:                               ; %b240
	cmp	w10, #8
	b.eq	LBB22_104
; %bb.97:                               ; %b240
	cmp	w10, #7
	b.eq	LBB22_106
	b	LBB22_115
LBB22_98:                               ; %b232
	cmp	w10, #4
	b.le	LBB22_111
; %bb.99:                               ; %b232
	cmp	w10, #5
	b.eq	LBB22_147
; %bb.100:                              ; %b232
	cmp	w10, #8
	b.eq	LBB22_147
; %bb.101:                              ; %b232
	cmp	w10, #7
	b.eq	LBB22_113
	b	LBB22_115
LBB22_102:                              ; %b240
	cmp	w10, #2
	b.eq	LBB22_106
; %bb.103:                              ; %b240
	cmp	w10, #4
	b.ne	LBB22_115
LBB22_104:                              ; %b262
	and	w9, w19, #0xff
	cmp	w9, #34
	b.ne	LBB22_147
; %bb.105:                              ; %b266
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #132]
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_106:                              ; %b244
	and	w11, w19, #0xff
	cmp	w11, #44
	b.ne	LBB22_147
; %bb.107:                              ; %b248
	ldrb	w11, [x8, #61]
	ldrb	w3, [x8, #103]
	subs	w9, w9, #1
	ldrb	w26, [x8, #56]
	ldrb	w22, [x8, #57]
	cset	w2, lo
	str	w11, [sp, #20]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #62]
	cmp	w10, #2
	str	w3, [sp, #24]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #104]
	ldrb	w20, [x8, #58]
	str	w11, [sp, #28]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #63]
	ldrb	w7, [x8, #59]
	str	w3, [sp, #32]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #105]
	ldrb	w5, [x8, #60]
	str	w11, [sp, #36]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #64]
	ldrb	w16, [x8, #83]
	str	w3, [sp, #40]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #106]
	ldrb	w1, [x8, #84]
	str	w11, [sp, #44]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #65]
	ldrb	w0, [x8, #85]
	str	w3, [sp, #48]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #107]
	ldrb	w17, [x8, #86]
	str	w11, [sp, #52]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #66]
	ldrb	w15, [x8, #87]
	str	w3, [sp, #56]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #108]
	ldrb	w14, [x8, #88]
	str	w11, [sp, #60]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #67]
	ldrb	w13, [x8, #89]
	str	w3, [sp, #64]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #109]
	ldrb	w12, [x8, #90]
	str	w11, [sp, #68]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #68]
	ldrb	w30, [x8, #92]
	str	w3, [sp, #72]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #110]
	ldrb	w10, [x8, #93]
	str	w11, [sp, #76]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #69]
	ldrb	w28, [x8, #94]
	str	w3, [sp, #80]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #111]
	ldrb	w27, [x8, #95]
	str	w11, [sp, #84]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #70]
	ldrb	w25, [x8, #96]
	str	w3, [sp, #88]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #112]
	ldrb	w24, [x8, #97]
	str	w11, [sp, #92]                  ; 4-byte Folded Spill
	ldrb	w11, [x8, #71]
	ldrb	w23, [x8, #98]
	str	w3, [sp, #96]                   ; 4-byte Folded Spill
	ldrb	w3, [x8, #113]
	ldrb	w21, [x8, #99]
	str	w11, [sp, #100]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #72]
	ldrb	w19, [x8, #100]
	str	w3, [sp, #104]                  ; 4-byte Folded Spill
	ldrb	w3, [x8, #114]
	ldrb	w6, [x8, #101]
	str	w11, [sp, #108]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #73]
	ldrb	w4, [x8, #102]
	str	w3, [sp, #112]                  ; 4-byte Folded Spill
	ldrb	w3, [x8, #115]
	str	w11, [sp, #116]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #74]
	str	w3, [sp, #120]                  ; 4-byte Folded Spill
	ldrb	w3, [x8, #116]
	str	w11, [sp, #124]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #75]
	str	w3, [sp, #128]                  ; 4-byte Folded Spill
	ldrb	w3, [x8, #117]
	str	w11, [sp, #132]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #76]
	str	w3, [sp, #136]                  ; 4-byte Folded Spill
	ldrb	w3, [x8, #118]
	str	w11, [sp, #140]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #77]
	str	w3, [sp, #144]                  ; 4-byte Folded Spill
	ldrb	w3, [x8, #119]
	str	w11, [sp, #148]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #78]
	str	w3, [sp, #152]                  ; 4-byte Folded Spill
	str	w11, [sp, #156]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #79]
	str	w11, [sp, #160]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #80]
	str	w11, [sp, #164]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #81]
	str	w11, [sp, #168]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #82]
	str	w11, [sp, #172]                 ; 4-byte Folded Spill
	ldrb	w11, [x8, #91]
	b.ne	LBB22_127
; %bb.108:                              ; %b249
	cbnz	w2, LBB22_156
; %bb.109:                              ; %v459_ok
	cmp	w9, #64
	b.hs	LBB22_156
; %bb.110:                              ; %v460_ok
	ldr	w2, [sp, #20]                   ; 4-byte Folded Reload
	strb	w10, [sp, #533]
	ldr	w10, [sp, #24]                  ; 4-byte Folded Reload
	strb	w26, [sp, #496]
	add	x26, sp, #496
	strb	w2, [sp, #501]
	ldr	w2, [sp, #28]                   ; 4-byte Folded Reload
	strb	w10, [sp, #543]
	ldr	w10, [sp, #32]                  ; 4-byte Folded Reload
	strb	w2, [sp, #502]
	ldr	w2, [sp, #36]                   ; 4-byte Folded Reload
	strb	w10, [sp, #544]
	ldr	w10, [sp, #40]                  ; 4-byte Folded Reload
	strb	w2, [sp, #503]
	ldr	w2, [sp, #44]                   ; 4-byte Folded Reload
	strb	w10, [sp, #545]
	ldr	w10, [sp, #48]                  ; 4-byte Folded Reload
	strb	w2, [sp, #504]
	ldr	w2, [sp, #52]                   ; 4-byte Folded Reload
	strb	w10, [sp, #546]
	ldr	w10, [sp, #56]                  ; 4-byte Folded Reload
	strb	w2, [sp, #505]
	ldr	w2, [sp, #60]                   ; 4-byte Folded Reload
	strb	w10, [sp, #547]
	ldr	w10, [sp, #64]                  ; 4-byte Folded Reload
	strb	w2, [sp, #506]
	ldr	w2, [sp, #68]                   ; 4-byte Folded Reload
	strb	w10, [sp, #548]
	ldr	w10, [sp, #72]                  ; 4-byte Folded Reload
	strb	w2, [sp, #507]
	ldr	w2, [sp, #76]                   ; 4-byte Folded Reload
	strb	w10, [sp, #549]
	ldr	w10, [sp, #80]                  ; 4-byte Folded Reload
	strb	w2, [sp, #508]
	ldr	w2, [sp, #84]                   ; 4-byte Folded Reload
	strb	w10, [sp, #550]
	ldr	w10, [sp, #88]                  ; 4-byte Folded Reload
	strb	w2, [sp, #509]
	ldr	w2, [sp, #92]                   ; 4-byte Folded Reload
	strb	w10, [sp, #551]
	ldr	w10, [sp, #96]                  ; 4-byte Folded Reload
	strb	w2, [sp, #510]
	ldr	w2, [sp, #100]                  ; 4-byte Folded Reload
	strb	w10, [sp, #552]
	ldr	w10, [sp, #104]                 ; 4-byte Folded Reload
	strb	w2, [sp, #511]
	ldr	w2, [sp, #108]                  ; 4-byte Folded Reload
	strb	w10, [sp, #553]
	ldr	w10, [sp, #112]                 ; 4-byte Folded Reload
	strb	w2, [sp, #512]
	ldr	w2, [sp, #116]                  ; 4-byte Folded Reload
	strb	w10, [sp, #554]
	ldr	w10, [sp, #120]                 ; 4-byte Folded Reload
	strb	w2, [sp, #513]
	ldr	w2, [sp, #124]                  ; 4-byte Folded Reload
	strb	w10, [sp, #555]
	ldr	w10, [sp, #128]                 ; 4-byte Folded Reload
	strb	w2, [sp, #514]
	ldr	w2, [sp, #132]                  ; 4-byte Folded Reload
	strb	w10, [sp, #556]
	ldr	w10, [sp, #136]                 ; 4-byte Folded Reload
	strb	w2, [sp, #515]
	ldr	w2, [sp, #140]                  ; 4-byte Folded Reload
	strb	w10, [sp, #557]
	ldr	w10, [sp, #144]                 ; 4-byte Folded Reload
	strb	w2, [sp, #516]
	ldr	w2, [sp, #148]                  ; 4-byte Folded Reload
	strb	w10, [sp, #558]
	ldr	w10, [sp, #152]                 ; 4-byte Folded Reload
	strb	w2, [sp, #517]
	ldp	w3, w2, [sp, #156]              ; 8-byte Folded Reload
	strb	w22, [sp, #497]
	strb	w20, [sp, #498]
	strb	w3, [sp, #518]
	strb	w2, [sp, #519]
	ldp	w3, w2, [sp, #164]              ; 8-byte Folded Reload
	strb	w7, [sp, #499]
	strb	w5, [sp, #500]
	strb	w2, [sp, #521]
	ldr	w2, [sp, #172]                  ; 4-byte Folded Reload
	strb	w3, [sp, #520]
	strb	w2, [sp, #522]
	strb	w16, [sp, #523]
	strb	w1, [sp, #524]
	strb	w0, [sp, #525]
	strb	w17, [sp, #526]
	strb	w15, [sp, #527]
	strb	w14, [sp, #528]
	strb	w13, [sp, #529]
	strb	w12, [sp, #530]
	strb	w11, [sp, #531]
	strb	w30, [sp, #532]
	strb	w28, [sp, #534]
	strb	w27, [sp, #535]
	strb	w25, [sp, #536]
	strb	w24, [sp, #537]
	strb	w23, [sp, #538]
	strb	w21, [sp, #539]
	strb	w19, [sp, #540]
	strb	w6, [sp, #541]
	strb	w4, [sp, #542]
	strb	w10, [sp, #559]
	mov	w10, #3                         ; =0x3
	strb	w10, [x26, w9, uxtw]
	ldp	q0, q1, [sp, #496]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #528]
	b	LBB22_24
LBB22_111:                              ; %b232
	cmp	w10, #2
	b.eq	LBB22_147
; %bb.112:                              ; %b232
	cmp	w10, #4
	b.ne	LBB22_115
LBB22_113:                              ; %b238
	subs	w9, w9, #1
	b.lo	LBB22_156
LBB22_114:                              ; %v426_ok
	str	w9, [x8, #120]
	b	LBB22_149
LBB22_115:                              ; %b259
	cbnz	w9, LBB22_117
; %bb.116:                              ; %b259
	ldrb	w10, [x8, #124]
	tbnz	w10, #0, LBB22_147
LBB22_117:                              ; %b273
	and	w10, w19, #0xff
	cmp	w10, #90
	b.gt	LBB22_130
; %bb.118:                              ; %b273
	cmp	w10, #34
	b.eq	LBB22_141
; %bb.119:                              ; %b273
	cmp	w10, #45
	b.ne	LBB22_134
; %bb.120:                              ; %b289
	mov	w9, #10                         ; =0xa
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_121:                              ; %b203
	cmp	w9, #93
	b.eq	LBB22_83
; %bb.122:                              ; %b203
	cmp	w9, #125
	b.ne	LBB22_72
	b	LBB22_83
LBB22_123:                              ; %b253
	and	w10, w19, #0xff
	cmp	w10, #58
	b.ne	LBB22_147
; %bb.124:                              ; %b257
	subs	w9, w9, #1
	b.lo	LBB22_156
; %bb.125:                              ; %v483_ok
	cmp	w9, #64
	b.hs	LBB22_156
; %bb.126:                              ; %v484_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x10, sp, #368
	ldur	q2, [x8, #88]
	mov	w11, #6                         ; =0x6
	stp	q0, q1, [sp, #368]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #400]
	strb	w11, [x10, w9, uxtw]
	ldp	q0, q1, [sp, #368]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #400]
	b	LBB22_24
LBB22_127:                              ; %b250
	cbnz	w2, LBB22_156
; %bb.128:                              ; %v467_ok
	cmp	w9, #64
	b.hs	LBB22_156
; %bb.129:                              ; %v468_ok
	ldr	w2, [sp, #20]                   ; 4-byte Folded Reload
	strb	w10, [sp, #469]
	ldr	w10, [sp, #24]                  ; 4-byte Folded Reload
	strb	w26, [sp, #432]
	add	x26, sp, #432
	strb	w2, [sp, #437]
	ldr	w2, [sp, #28]                   ; 4-byte Folded Reload
	strb	w10, [sp, #479]
	ldr	w10, [sp, #32]                  ; 4-byte Folded Reload
	strb	w2, [sp, #438]
	ldr	w2, [sp, #36]                   ; 4-byte Folded Reload
	strb	w10, [sp, #480]
	ldr	w10, [sp, #40]                  ; 4-byte Folded Reload
	strb	w2, [sp, #439]
	ldr	w2, [sp, #44]                   ; 4-byte Folded Reload
	strb	w10, [sp, #481]
	ldr	w10, [sp, #48]                  ; 4-byte Folded Reload
	strb	w2, [sp, #440]
	ldr	w2, [sp, #52]                   ; 4-byte Folded Reload
	strb	w10, [sp, #482]
	ldr	w10, [sp, #56]                  ; 4-byte Folded Reload
	strb	w2, [sp, #441]
	ldr	w2, [sp, #60]                   ; 4-byte Folded Reload
	strb	w10, [sp, #483]
	ldr	w10, [sp, #64]                  ; 4-byte Folded Reload
	strb	w2, [sp, #442]
	ldr	w2, [sp, #68]                   ; 4-byte Folded Reload
	strb	w10, [sp, #484]
	ldr	w10, [sp, #72]                  ; 4-byte Folded Reload
	strb	w2, [sp, #443]
	ldr	w2, [sp, #76]                   ; 4-byte Folded Reload
	strb	w10, [sp, #485]
	ldr	w10, [sp, #80]                  ; 4-byte Folded Reload
	strb	w2, [sp, #444]
	ldr	w2, [sp, #84]                   ; 4-byte Folded Reload
	strb	w10, [sp, #486]
	ldr	w10, [sp, #88]                  ; 4-byte Folded Reload
	strb	w2, [sp, #445]
	ldr	w2, [sp, #92]                   ; 4-byte Folded Reload
	strb	w10, [sp, #487]
	ldr	w10, [sp, #96]                  ; 4-byte Folded Reload
	strb	w2, [sp, #446]
	ldr	w2, [sp, #100]                  ; 4-byte Folded Reload
	strb	w10, [sp, #488]
	ldr	w10, [sp, #104]                 ; 4-byte Folded Reload
	strb	w2, [sp, #447]
	ldr	w2, [sp, #108]                  ; 4-byte Folded Reload
	strb	w10, [sp, #489]
	ldr	w10, [sp, #112]                 ; 4-byte Folded Reload
	strb	w2, [sp, #448]
	ldr	w2, [sp, #116]                  ; 4-byte Folded Reload
	strb	w10, [sp, #490]
	ldr	w10, [sp, #120]                 ; 4-byte Folded Reload
	strb	w2, [sp, #449]
	ldr	w2, [sp, #124]                  ; 4-byte Folded Reload
	strb	w10, [sp, #491]
	ldr	w10, [sp, #128]                 ; 4-byte Folded Reload
	strb	w2, [sp, #450]
	ldr	w2, [sp, #132]                  ; 4-byte Folded Reload
	strb	w10, [sp, #492]
	ldr	w10, [sp, #136]                 ; 4-byte Folded Reload
	strb	w2, [sp, #451]
	ldr	w2, [sp, #140]                  ; 4-byte Folded Reload
	strb	w10, [sp, #493]
	ldr	w10, [sp, #144]                 ; 4-byte Folded Reload
	strb	w2, [sp, #452]
	ldr	w2, [sp, #148]                  ; 4-byte Folded Reload
	strb	w10, [sp, #494]
	ldr	w10, [sp, #152]                 ; 4-byte Folded Reload
	strb	w2, [sp, #453]
	ldp	w3, w2, [sp, #156]              ; 8-byte Folded Reload
	strb	w22, [sp, #433]
	strb	w20, [sp, #434]
	strb	w3, [sp, #454]
	strb	w2, [sp, #455]
	ldp	w3, w2, [sp, #164]              ; 8-byte Folded Reload
	strb	w7, [sp, #435]
	strb	w5, [sp, #436]
	strb	w2, [sp, #457]
	ldr	w2, [sp, #172]                  ; 4-byte Folded Reload
	strb	w3, [sp, #456]
	strb	w2, [sp, #458]
	strb	w16, [sp, #459]
	strb	w1, [sp, #460]
	strb	w0, [sp, #461]
	strb	w17, [sp, #462]
	strb	w15, [sp, #463]
	strb	w14, [sp, #464]
	strb	w13, [sp, #465]
	strb	w12, [sp, #466]
	strb	w11, [sp, #467]
	strb	w30, [sp, #468]
	strb	w28, [sp, #470]
	strb	w27, [sp, #471]
	strb	w25, [sp, #472]
	strb	w24, [sp, #473]
	strb	w23, [sp, #474]
	strb	w21, [sp, #475]
	strb	w19, [sp, #476]
	strb	w6, [sp, #477]
	strb	w4, [sp, #478]
	strb	w10, [sp, #495]
	mov	w10, #8                         ; =0x8
	strb	w10, [x26, w9, uxtw]
	ldp	q0, q1, [sp, #432]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #464]
	b	LBB22_24
LBB22_130:                              ; %b273
	cmp	w10, #123
	b.eq	LBB22_132
; %bb.131:                              ; %b273
	cmp	w10, #91
	b.ne	LBB22_134
LBB22_132:                              ; %b277
	cmp	w9, #64
	b.ne	LBB22_138
; %bb.133:                              ; %b279
	ldr	x9, [x8, #48]
	mov	w10, #7                         ; =0x7
	b	LBB22_148
LBB22_134:                              ; %b291
	sub	w9, w19, #48
	and	w9, w9, #0xff
	cmp	w9, #9
	b.hi	LBB22_142
LBB22_135:                              ; %b143
	and	w9, w19, #0xff
	cmp	w9, #48
	b.ne	LBB22_137
; %bb.136:                              ; %b145
	mov	w9, #11                         ; =0xb
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_137:                              ; %b146
	mov	w9, #12                         ; =0xc
	str	w9, [x8, #128]
	b	LBB22_149
LBB22_138:                              ; %b281
	mov	x20, x8
	bl	_liza___liza_owned___liza_json_done
	and	w9, w19, #0xff
	ldr	w8, [x20, #120]
	cmp	w9, #91
	b.ne	LBB22_150
; %bb.139:                              ; %b282
	cmp	w8, #64
	b.hs	LBB22_156
; %bb.140:
	mov	w10, #1                         ; =0x1
	add	x9, sp, #304
	b	LBB22_152
LBB22_141:                              ; %b286
	strb	wzr, [x8, #132]
	b	LBB22_54
LBB22_142:                              ; %b297
	and	w9, w19, #0xff
	sub	w9, w9, #102
	cmp	w9, #14
	b.hi	LBB22_147
; %bb.143:                              ; %b297
	mov	w10, #1                         ; =0x1
	mov	w11, #16641                     ; =0x4101
	lsl	w9, w10, w9
	tst	w9, w11
	b.eq	LBB22_147
; %bb.144:                              ; %b304
	mov	w9, #20                         ; =0x14
	and	w11, w19, #0xff
	str	w10, [x8, #140]
	str	w9, [x8, #128]
	cmp	w11, #102
	mov	x9, x8
	b.eq	LBB22_154
; %bb.145:                              ; %b304
	cmp	w11, #116
	b.ne	LBB22_155
; %bb.146:                              ; %b306
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #136]
	b	LBB22_149
LBB22_147:                              ; %b3
	ldr	x9, [x8, #48]
	mov	w10, #1                         ; =0x1
LBB22_148:                              ; %common.ret
	str	w10, [x8, #168]
	str	x9, [x8, #176]
LBB22_149:                              ; %common.ret
	add	sp, sp, #624
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB22_150:                              ; %b283
	cmp	w8, #64
	b.hs	LBB22_156
; %bb.151:
	mov	w10, #4                         ; =0x4
	add	x9, sp, #240
LBB22_152:                              ; %b284
	ldur	q0, [x20, #56]
	ldur	q1, [x20, #72]
	ldur	q2, [x20, #88]
	stp	q0, q1, [x9]
	ldur	q0, [x20, #104]
	stp	q2, q0, [x9, #32]
	strb	w10, [x9, x8]
	ldr	w8, [x20, #120]
	ldp	q0, q1, [x9]
	adds	w8, w8, #1
	stur	q0, [x20, #56]
	stur	q1, [x20, #72]
	ldp	q0, q1, [x9, #32]
	stur	q0, [x20, #88]
	stur	q1, [x20, #104]
	b.hs	LBB22_156
; %bb.153:                              ; %v545_ok
	str	w8, [x20, #120]
	b	LBB22_149
LBB22_154:                              ; %b308
	mov	w8, #2                          ; =0x2
	str	w8, [x9, #136]
	b	LBB22_149
LBB22_155:                              ; %b309
	mov	w8, #3                          ; =0x3
	str	w8, [x9, #136]
	b	LBB22_149
LBB22_156:                              ; %v17_trap
	brk	#0x1
                                        ; -- End function
	.globl	_example_entry                  ; -- Begin function example_entry
	.p2align	2
_example_entry:                         ; @example_entry
; %bb.0:                                ; %entry
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_stream_start                   ; -- Begin function stream_start
	.p2align	2
_stream_start:                          ; @stream_start
; %bb.0:
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w8, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x0, #8]
	str	xzr, [x0]
	str	wzr, [x0, #24]
	strh	w8, [x0, #28]
	str	wzr, [x0, #32]
	stur	q0, [x0, #40]
	stur	q0, [x0, #56]
	stur	q0, [x0, #72]
	stur	q0, [x0, #88]
	stur	q0, [x0, #104]
	str	wzr, [x0, #120]
	strb	wzr, [x0, #124]
	str	wzr, [x0, #128]
	strb	wzr, [x0, #132]
	str	xzr, [x0, #176]
	str	wzr, [x0, #168]
	stur	q0, [x0, #152]
	stur	q0, [x0, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_stream_feed                    ; -- Begin function stream_feed
	.p2align	2
_stream_feed:                           ; @stream_feed
; %bb.0:
	sub	sp, sp, #224
	add	x8, sp, #8
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	mov	x19, x0
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	bl	_liza_json.feed
	ldur	w8, [sp, #115]
	ldur	w10, [sp, #103]
	ldur	x9, [sp, #107]
	ldur	q0, [sp, #8]
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	stur	w8, [x19, #107]
	ldur	x8, [sp, #95]
	stur	w10, [x19, #95]
	ldur	x10, [sp, #83]
	stur	x8, [x19, #87]
	ldur	w8, [sp, #79]
	stur	x9, [x19, #99]
	ldur	w9, [sp, #91]
	stur	x10, [x19, #75]
	ldur	w10, [sp, #67]
	stur	w8, [x19, #71]
	ldurh	w8, [sp, #65]
	stur	w9, [x19, #83]
	ldur	x9, [sp, #71]
	stur	w10, [x19, #59]
	sturh	w8, [x19, #57]
	ldp	x10, x8, [sp, #48]
	stur	x9, [x19, #63]
	ldrb	w9, [sp, #64]
	str	q0, [x19]
	stp	x10, x8, [x19, #40]
	ldrh	w8, [sp, #36]
	ldr	w10, [sp, #32]
	strb	w9, [x19, #56]
	ldr	w9, [sp, #40]
	strh	w8, [x19, #28]
	ldr	x8, [sp, #184]
	str	w9, [x19, #32]
	ldr	x9, [sp, #24]
	str	w10, [x19, #24]
	str	x8, [x19, #176]
	ldp	x10, x8, [sp, #160]
	str	x9, [x19, #16]
	ldr	w9, [sp, #176]
	str	w9, [x19, #168]
	ldr	w9, [sp, #156]
	stp	x10, x8, [x19, #152]
	ldur	x8, [sp, #148]
	ldr	w10, [sp, #144]
	str	w9, [x19, #148]
	ldrb	w9, [sp, #140]
	stur	x8, [x19, #140]
	ldr	w8, [sp, #136]
	str	w10, [x19, #136]
	ldrb	w10, [sp, #132]
	strb	w9, [x19, #132]
	ldr	w9, [sp, #128]
	str	w8, [x19, #128]
	ldr	x8, [sp, #120]
	strb	w10, [x19, #124]
	ldrb	w10, [sp, #119]
	str	w9, [x19, #120]
	str	x8, [x19, #112]
	strb	w10, [x19, #111]
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
                                        ; -- End function
	.globl	_stream_status                  ; -- Begin function stream_status
	.p2align	2
_stream_status:                         ; @stream_status
; %bb.0:                                ; %liza_status.exit
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csinc	w0, wzr, w2, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_stream_pending                 ; -- Begin function stream_pending
	.p2align	2
_stream_pending:                        ; @stream_pending
; %bb.0:
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_stream_value                   ; -- Begin function stream_value
	.p2align	2
_stream_value:                          ; @stream_value
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_liza_json.finish
	cmp	w0, #0
	csel	x0, x1, x3, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_stream_size                    ; -- Begin function stream_size
	.p2align	2
_stream_size:                           ; @stream_size
; %bb.0:
	mov	w0, #184                        ; =0xb8
	ret
                                        ; -- End function
.subsections_via_symbols
