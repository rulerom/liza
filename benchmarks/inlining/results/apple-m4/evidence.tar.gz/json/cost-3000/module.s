	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_status                    ; -- Begin function liza_status
	.p2align	2
_liza_status:                           ; @liza_status
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cbz	w8, LBB0_8
; %bb.1:                                ; %b3.i.i
	cmp	w8, #2
	mov	w11, #2                         ; =0x2
	mov	w9, wzr
	cset	w10, eq
	cmp	w8, #3
	csel	w10, w11, w10, eq
	cmp	w8, #4
	mov	w11, #3                         ; =0x3
	csel	w10, w11, w10, eq
	cmp	w8, #5
	mov	w11, #4                         ; =0x4
	csel	w10, w11, w10, eq
	cmp	w8, #6
	mov	w11, #5                         ; =0x5
	csel	w10, w11, w10, eq
	cmp	w8, #7
	mov	w11, #6                         ; =0x6
	csel	w10, w11, w10, eq
	cmp	w8, #8
	mov	w8, #7                          ; =0x7
	csel	w8, w8, w10, eq
	cbz	w9, LBB0_9
LBB0_2:                                 ; %b4.i
	ldr	w8, [x0, #32]
	cmp	w8, #2
	b.eq	LBB0_5
; %bb.3:                                ; %b4.i
	cmp	w8, #1
	b.eq	LBB0_6
; %bb.4:                                ; %b6.i.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB0_6
LBB0_5:                                 ; %b7.i.i
	mov	w8, #1                          ; =0x1
LBB0_6:                                 ; %liza_utf8_stream.finish.exit.i
	cbz	w8, LBB0_10
; %bb.7:                                ; %b7.i
	mov	w8, #4                          ; =0x4
	mov	w9, #1                          ; =0x1
	b	LBB0_22
LBB0_8:
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB0_2
LBB0_9:                                 ; %b2.i
	mov	w9, #1                          ; =0x1
	b	LBB0_22
LBB0_10:                                ; %b6.i
	ldr	w8, [x0, #128]
	cmp	w8, #17
	b.hi	LBB0_16
; %bb.11:                               ; %b6.i
	mov	w9, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w9, w9, w8
	movk	w10, #2, lsl #16
	tst	w9, w10
	b.eq	LBB0_16
; %bb.12:                               ; %b18.i
	ldr	w8, [x0, #120]
	cbz	w8, LBB0_15
; %bb.13:                               ; %b2.i.i
	sub	w8, w8, #65
	cmn	w8, #65
	b.ls	LBB0_23
LBB0_14:                                ; %b36.i
	mov	w8, #5                          ; =0x5
	mov	w9, #1                          ; =0x1
	b	LBB0_22
LBB0_15:                                ; %b1.i21.i
	sub	sp, sp, #16
	mov	w9, wzr
	mov	w10, #1                         ; =0x1
	strb	w10, [sp, #12]
	add	sp, sp, #16
	cbz	w8, LBB0_19
	b	LBB0_14
LBB0_16:                                ; %b20.i
	sub	w9, w8, #4
	cmp	w9, #2
	b.hi	LBB0_18
; %bb.17:                               ; %b27.i
	mov	w8, #3                          ; =0x3
	mov	w9, #1                          ; =0x1
	b	LBB0_22
LBB0_18:
	ldr	w9, [x0, #120]
	ldrb	w10, [x0, #124]
	cbnz	w8, LBB0_14
LBB0_19:                                ; %b29.i
	cbnz	w9, LBB0_14
; %bb.20:                               ; %b29.i
	tbz	w10, #0, LBB0_14
; %bb.21:                               ; %b38.i
	mov	w9, wzr
	mov	w8, wzr
LBB0_22:                                ; %liza_json.finish.exit
	cmp	w9, #0
	csinc	w0, wzr, w8, eq
	ret
LBB0_23:                                ; %v10_trap.i.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza_value                     ; -- Begin function liza_value
	.p2align	2
_liza_value:                            ; @liza_value
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cbz	w8, LBB1_2
; %bb.1:                                ; %b3.i.i
	ldr	x8, [x0, #176]
	mov	w9, wzr
	cbnz	w9, LBB1_3
	b	LBB1_22
LBB1_2:
	mov	x8, xzr
	mov	w9, #1                          ; =0x1
	cbz	w9, LBB1_22
LBB1_3:                                 ; %b4.i
	ldr	w9, [x0, #32]
	ldr	x8, [x0, #40]
	cmp	w9, #2
	b.eq	LBB1_7
; %bb.4:                                ; %b4.i
	cmp	w9, #1
	b.eq	LBB1_8
; %bb.5:                                ; %b6.i.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB1_14
; %bb.6:                                ; %b7.i.i
	ldr	x8, [x0, #16]
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB1_22
	b	LBB1_9
LBB1_7:                                 ; %b4.i.i
	mov	w9, #1                          ; =0x1
LBB1_8:                                 ; %liza_utf8_stream.finish.exit.i
	cbnz	w9, LBB1_22
LBB1_9:                                 ; %b6.i
	ldr	w9, [x0, #128]
	cmp	w9, #17
	b.hi	LBB1_16
; %bb.10:                               ; %b6.i
	mov	w8, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w8, w8, w9
	movk	w10, #2, lsl #16
	tst	w8, w10
	b.eq	LBB1_16
; %bb.11:                               ; %b18.i
	ldr	w9, [x0, #120]
	ldr	x8, [x0, #48]
	cbz	w9, LBB1_15
; %bb.12:                               ; %b2.i.i
	sub	w9, w9, #65
	cmn	w9, #65
	b.hi	LBB1_22
; %bb.13:                               ; %v10_trap.i.i
	brk	#0x1
LBB1_14:                                ; %b9.i.i
	mov	w9, wzr
	mov	x8, xzr
	cbnz	w9, LBB1_22
	b	LBB1_9
LBB1_15:                                ; %b1.i21.i
	sub	sp, sp, #16
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	strb	w11, [sp, #12]
	add	sp, sp, #16
	cbz	w9, LBB1_19
	b	LBB1_22
LBB1_16:                                ; %b20.i
	sub	w8, w9, #4
	cmp	w8, #2
	b.hi	LBB1_18
; %bb.17:                               ; %b27.i
	ldr	x8, [x0, #160]
	b	LBB1_22
LBB1_18:
	ldr	x8, [x0, #48]
	ldr	w10, [x0, #120]
	ldrb	w11, [x0, #124]
	cbnz	w9, LBB1_22
LBB1_19:                                ; %b29.i
	cbnz	w10, LBB1_22
; %bb.20:                               ; %b29.i
	tbz	w11, #0, LBB1_22
; %bb.21:                               ; %b38.i
	mov	w10, wzr
	mov	x9, x8
	mov	x8, xzr
	b	LBB1_23
LBB1_22:                                ; %b2.i
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
LBB1_23:                                ; %liza_json.finish.exit
	cmp	w10, #0
	csel	x0, x9, x8, eq
	ret
                                        ; -- End function
	.globl	_liza_pending                   ; -- Begin function liza_pending
	.p2align	2
_liza_pending:                          ; @liza_pending
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_liza_start                     ; -- Begin function liza_start
	.p2align	2
_liza_start:                            ; @liza_start
; %bb.0:                                ; %b0
	sub	sp, sp, #144
	movi.2d	v0, #0000000000000000
	str	wzr, [sp, #132]
	mov	w9, #49024                      ; =0xbf80
	strh	w9, [x8, #28]
	stur	wzr, [sp, #44]
	strb	wzr, [sp, #140]
	stur	q0, [sp, #68]
	stur	q0, [sp, #84]
	stur	q0, [sp, #100]
	stur	q0, [sp, #52]
	stur	q0, [sp, #116]
	stur	q0, [sp, #12]
	ldr	x9, [sp, #128]
	stur	q0, [sp, #28]
	ldp	q0, q1, [sp, #80]
	stur	x9, [x8, #116]
	ldur	x9, [sp, #40]
	strb	wzr, [sp, #136]
	stur	q0, [x8, #68]
	ldr	q0, [sp, #112]
	stur	q1, [x8, #84]
	stur	q0, [x8, #100]
	ldp	q0, q1, [sp, #48]
	stp	xzr, xzr, [x8]
	str	wzr, [x8, #24]
	stur	q0, [x8, #36]
	ldur	q0, [sp, #25]
	stur	q1, [x8, #52]
	ldur	q1, [sp, #9]
	str	xzr, [x8, #16]
	str	wzr, [x8, #32]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	stur	x9, [x8, #164]
	stur	q0, [x8, #149]
	stur	q1, [x8, #133]
	str	xzr, [x8, #176]
	add	sp, sp, #144
	ret
                                        ; -- End function
	.globl	_liza_feed                      ; -- Begin function liza_feed
	.p2align	2
_liza_feed:                             ; @liza_feed
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	ldr	w8, [x0, #168]
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	cbnz	w8, LBB4_201
; %bb.1:                                ; %b4.preheader.i
	cbz	w2, LBB4_193
; %bb.2:                                ; %v10_ok.lr.ph.i
	mov	x5, #8193                       ; =0x2001
	mov	w22, #4113                      ; =0x1011
	add	x20, x0, #56
	mov	w21, w2
	mov	w16, #-96                       ; =0xffffffa0
	mov	w17, #-97                       ; =0xffffff9f
	mov	w2, #-112                       ; =0xffffff90
	mov	w3, #-113                       ; =0xffffff8f
	mov	w26, #2                         ; =0x2
	mov	w27, #5                         ; =0x5
	mov	w28, #1                         ; =0x1
	mov	w4, #7                          ; =0x7
	movk	x5, #1024, lsl #48
	movk	w22, #5, lsl #16
	mov	w6, #3                          ; =0x3
	mov	w7, #55296                      ; =0xd800
	mov	w19, #4                         ; =0x4
	mov	w25, #56320                     ; =0xdc00
	mov	w30, #11                        ; =0xb
	mov	w24, #6                         ; =0x6
LBB4_3:                                 ; %v10_ok.i
                                        ; =>This Inner Loop Header: Depth=1
	ldp	x10, x15, [x0, #8]
	ldr	x9, [x0, #40]
	ldrb	w23, [x1], #1
	ldr	w8, [x0, #32]
	ldrb	w11, [x0, #29]
	ldrb	w13, [x0, #28]
	ldr	w14, [x0, #24]
	ldr	x12, [x0]
	cbz	w8, LBB4_7
LBB4_4:                                 ; %liza_utf8_stream.feed_byte.exit.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #2
	stp	x12, x10, [x0]
	str	x15, [x0, #16]
	str	w14, [x0, #24]
	strb	w13, [x0, #28]
	strb	w11, [x0, #29]
	str	w8, [x0, #32]
	str	x9, [x0, #40]
	b.eq	LBB4_14
; %bb.5:                                ; %liza_utf8_stream.feed_byte.exit.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #1
	b.ne	LBB4_15
; %bb.6:                                ; %b1.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w10, wzr
	mov	w8, wzr
	cmp	w10, #1
	b.eq	LBB4_16
	b	LBB4_194
LBB4_7:                                 ; %b3.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmn	x12, #1
	b.eq	LBB4_34
; %bb.8:                                ; %b6.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cbz	w14, LBB4_57
; %bb.9:                                ; %b8.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, w13, uxtb
	b.lo	LBB4_60
; %bb.10:                               ; %b8.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, w11, uxtb
	b.hi	LBB4_60
; %bb.11:                               ; %v115_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	subs	w14, w14, #1
	mov	w11, #191                       ; =0xbf
	mov	w13, #128                       ; =0x80
	b.ne	LBB4_108
; %bb.12:                               ; %b51.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmn	x10, #1
	b.eq	LBB4_104
; %bb.13:                               ; %v138_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	add	x10, x10, #1
	b	LBB4_108
LBB4_14:                                ; %b4.i3.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w10, wzr
	mov	w8, #1                          ; =0x1
	cmp	w10, #1
	b.eq	LBB4_16
	b	LBB4_194
LBB4_15:                                ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, wzr
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
	cmp	w10, #1
	b.ne	LBB4_194
LBB4_16:                                ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #128]
	cmp	w8, #3
	b.le	LBB4_23
; %bb.17:                               ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #5
	b.gt	LBB4_26
; %bb.18:                               ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #4
	b.eq	LBB4_49
; %bb.19:                               ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #5
	b.ne	LBB4_42
; %bb.20:                               ; %b52.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #117
	b.ne	LBB4_195
; %bb.21:                               ; %b56.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	str	w24, [x0, #128]
LBB4_22:                                ; %liza___liza_json_mut_step.exit.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	str	xzr, [x0, #144]
	b	LBB4_134
LBB4_23:                                ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #1
	b.eq	LBB4_35
; %bb.24:                               ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #2
	b.eq	LBB4_53
; %bb.25:                               ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #3
	b.eq	LBB4_32
	b	LBB4_42
LBB4_26:                                ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #6
	b.eq	LBB4_32
; %bb.27:                               ; %b13.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #20
	b.ne	LBB4_42
; %bb.28:                               ; %b91.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #136]
	cmp	w8, #3
	b.eq	LBB4_83
; %bb.29:                               ; %b91.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #2
	b.eq	LBB4_82
; %bb.30:                               ; %b91.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #1
	b.ne	LBB4_84
; %bb.31:                               ; %b104.thread.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #114                        ; =0x72
	mov	w10, #117                       ; =0x75
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	b	LBB4_85
LBB4_32:                                ; %b61.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w9, w23, #48
	cmp	w9, #10
	b.hs	LBB4_51
; %bb.33:                               ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, #-48                        ; =0xffffffd0
	b	LBB4_63
LBB4_34:                                ; %b4.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	x9, #-1                         ; =0xffffffffffffffff
	mov	w8, #2                          ; =0x2
	b	LBB4_4
LBB4_35:                                ; %b1.i22.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #31
	b.ls	LBB4_196
; %bb.36:                               ; %b5.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #92
	b.eq	LBB4_73
; %bb.37:                               ; %b5.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #34
	b.ne	LBB4_134
; %bb.38:                               ; %b6.i25.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldrb	w9, [x0, #132]
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cmp	w9, #1
	b.ne	LBB4_96
; %bb.39:                               ; %b8.i28.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB4_203
; %bb.40:                               ; %v23_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.41:                               ; %v24_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w27, [x20, w8, uxtw]
	b	LBB4_134
LBB4_42:                                ; %b132.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w9, w8, #10
	cmp	w9, #7
	b.hi	LBB4_132
; %bb.43:                               ; %b136.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w9, w23, #48
	cmp	w9, #9
	b.hi	LBB4_76
; %bb.44:                               ; %b138.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #10
	b.eq	LBB4_185
; %bb.45:                               ; %b138.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #13
	b.eq	LBB4_105
; %bb.46:                               ; %b138.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #11
	b.eq	LBB4_199
; %bb.47:                               ; %b151.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w8, #15
	cmp	w8, #1
	b.hi	LBB4_134
; %bb.48:                               ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #17                         ; =0x11
	str	w8, [x0, #128]
	b	LBB4_134
LBB4_49:                                ; %b46.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #92
	b.ne	LBB4_195
; %bb.50:                               ; %b50.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	str	w27, [x0, #128]
	b	LBB4_134
LBB4_51:                                ; %b6.i.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w9, w23, #65
	cmp	w9, #6
	b.hs	LBB4_61
; %bb.52:                               ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, #-55                        ; =0xffffffc9
	b	LBB4_63
LBB4_53:                                ; %b16.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w23, #98
	cmp	w8, #19
	b.hi	LBB4_70
; %bb.54:                               ; %b16.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	lsl	w9, w28, w8
	tst	w9, w22
	b.ne	LBB4_72
; %bb.55:                               ; %b16.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #19
	b.ne	LBB4_70
; %bb.56:                               ; %b42.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	str	w6, [x0, #128]
	b	LBB4_22
LBB4_57:                                ; %b7.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	tbnz	w23, #7, LBB4_74
; %bb.58:                               ; %b9.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmn	x10, #1
	b.eq	LBB4_94
; %bb.59:                               ; %v32_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	add	x10, x10, #1
	mov	x15, x12
	b	LBB4_108
LBB4_60:                                ; %b48.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #1                          ; =0x1
	mov	x9, x15
	b	LBB4_4
LBB4_61:                                ; %b12.i.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w9, w23, #97
	cmp	w9, #6
	b.hs	LBB4_197
; %bb.62:                               ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, #-87                        ; =0xffffffa9
LBB4_63:                                ; %b65.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w10, [x0, #148]
	lsr	w11, w10, #28
	cbnz	w11, LBB4_203
; %bb.64:                               ; %v165_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	add	w9, w9, w23
	ldr	w11, [x0, #144]
	add	w9, w9, w10, lsl #4
	adds	w10, w11, #1
	str	w9, [x0, #148]
	b.hs	LBB4_203
; %bb.65:                               ; %v171_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w10, #4
	str	w10, [x0, #144]
	b.ne	LBB4_134
; %bb.66:                               ; %b66.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #6
	b.ne	LBB4_68
; %bb.67:                               ; %b68.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w9, #14, lsl #12            ; =57344
	cmn	w8, #1025
	b.hi	LBB4_72
	b	LBB4_195
LBB4_68:                                ; %b76.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	and	w8, w9, #0xfffffc00
	cmp	w8, w7
	b.eq	LBB4_93
; %bb.69:                               ; %b76.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, w25
	b.ne	LBB4_72
	b	LBB4_198
LBB4_70:                                ; %b16.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w23, #34
	cmp	w8, #58
	b.hi	LBB4_197
; %bb.71:                               ; %b16.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	lsl	x8, x28, x8
	tst	x8, x5
	b.eq	LBB4_197
LBB4_72:                                ; %b39.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	str	w28, [x0, #128]
	b	LBB4_134
LBB4_73:                                ; %b12.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	x8, [x0, #48]
	str	w26, [x0, #128]
	str	x8, [x0, #152]
	b	LBB4_134
LBB4_74:                                ; %b10.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	add	w11, w23, #62
	mov	w13, #128                       ; =0x80
	and	w11, w11, #0xff
	cmp	w11, #30
	mov	w11, #191                       ; =0xbf
	b.hs	LBB4_98
; %bb.75:                               ; %b17.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w14, #1                         ; =0x1
	mov	x15, x12
	b	LBB4_108
LBB4_76:                                ; %b158.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #11
	b.ne	LBB4_101
; %bb.77:                               ; %b162.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #92
	b.gt	LBB4_113
; %bb.78:                               ; %b162.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w23, #9
	cmp	w8, #60
	b.hi	LBB4_199
; %bb.79:                               ; %b162.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	x10, #19                        ; =0x13
	lsl	x9, x28, x8
	movk	x10, #128, lsl #16
	movk	x10, #8, lsl #32
	tst	x9, x10
	b.ne	LBB4_126
; %bb.80:                               ; %b162.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	x8, #37
	b.eq	LBB4_103
; %bb.81:                               ; %b162.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	x8, #60
	b.eq	LBB4_115
	b	LBB4_199
LBB4_82:                                ; %b105.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #97                         ; =0x61
	mov	w10, #108                       ; =0x6c
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w10, #115                       ; =0x73
	csel	w9, w10, w9, eq
	cmp	w8, #4
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	mov	w8, #5                          ; =0x5
	b	LBB4_86
LBB4_83:                                ; %b120.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #117                        ; =0x75
	cmp	w8, #1
	mov	w8, #108                        ; =0x6c
	csel	w9, w9, w8, eq
	b	LBB4_85
LBB4_84:                                ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, wzr
LBB4_85:                                ; %b125.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #4                          ; =0x4
LBB4_86:                                ; %b125.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, w9
	b.ne	LBB4_196
; %bb.87:                               ; %b128.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w9, [x0, #140]
	adds	w9, w9, #1
	b.hs	LBB4_203
; %bb.88:                               ; %v325_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, w8
	str	w9, [x0, #140]
	b.ne	LBB4_134
; %bb.89:                               ; %b129.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cbz	w8, LBB4_97
LBB4_90:                                ; %b2.i.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.91:                               ; %v12_ok.i.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldrb	w9, [x20, w8, uxtw]
	orr	w9, w9, #0x2
	cmp	w9, #3
	b.ne	LBB4_100
; %bb.92:                               ; %v24_ok.i56.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w26, [x20, w8, uxtw]
	b	LBB4_134
LBB4_93:                                ; %b80.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	x8, [x0, #152]
	str	w19, [x0, #128]
	str	x8, [x0, #160]
	b	LBB4_134
LBB4_94:                                ; %b11.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #2                          ; =0x2
LBB4_95:                                ; %liza_utf8_stream.feed_byte.exit.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	x15, x12
	mov	x9, x12
	b	LBB4_4
LBB4_96:                                ; %b10.i27.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cbnz	w8, LBB4_90
LBB4_97:                                ; %b1.i62.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w28, [x0, #124]
	b	LBB4_134
LBB4_98:                                ; %b18.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	and	w15, w23, #0xf0
	cmp	w15, #224
	b.ne	LBB4_106
; %bb.99:                               ; %b22.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #224
	mov	w14, #2                         ; =0x2
	mov	x15, x12
	csel	w13, w16, w13, eq
	cmp	w23, #237
	csel	w11, w17, w11, eq
	b	LBB4_108
LBB4_100:                               ; %v28_ok.i60.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w4, [x20, w8, uxtw]
	b	LBB4_134
LBB4_101:                               ; %b159.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #12
	b.ne	LBB4_109
; %bb.102:                              ; %b159.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #46
	b.ne	LBB4_109
LBB4_103:                               ; %b165.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #13                         ; =0xd
	str	w8, [x0, #128]
	b	LBB4_134
LBB4_104:                               ; %b53.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #2                          ; =0x2
	mov	x9, x12
	b	LBB4_4
LBB4_105:                               ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #14                         ; =0xe
	str	w8, [x0, #128]
	b	LBB4_134
LBB4_106:                               ; %b23.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	add	w15, w23, #16
	and	w15, w15, #0xff
	cmp	w15, #4
	b.hi	LBB4_116
; %bb.107:                              ; %b33.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #240
	mov	w14, #3                         ; =0x3
	mov	x15, x12
	csel	w13, w2, w13, eq
	cmp	w23, #244
	csel	w11, w3, w11, eq
LBB4_108:                               ; %b57.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	adds	x12, x12, #1
	b.lo	LBB4_4
	b	LBB4_203
LBB4_109:                               ; %b167.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #16
	b.hi	LBB4_122
; %bb.110:                              ; %b167.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	lsl	w9, w28, w8
	mov	w10, #22528                     ; =0x5800
	tst	w9, w10
	b.eq	LBB4_117
; %bb.111:                              ; %b174.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	orr	w9, w23, #0x20
	cmp	w9, #101
	b.eq	LBB4_115
; %bb.112:                              ; %b191.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #13
	b.ne	LBB4_122
	b	LBB4_199
LBB4_113:                               ; %b162.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #93
	b.eq	LBB4_126
; %bb.114:                              ; %b162.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #101
	b.ne	LBB4_125
LBB4_115:                               ; %b180.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #15                         ; =0xf
	str	w8, [x0, #128]
	b	LBB4_134
LBB4_116:                               ; %b34.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB4_95
LBB4_117:                               ; %b167.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #15
	b.ne	LBB4_121
; %bb.118:                              ; %b183.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #45
	b.eq	LBB4_120
; %bb.119:                              ; %b183.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #43
	b.ne	LBB4_199
LBB4_120:                               ; %b189.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x0, #128]
	b	LBB4_134
LBB4_121:                               ; %b167.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #9216                       ; =0x2400
	movk	w8, #1, lsl #16
	tst	w9, w8
	b.ne	LBB4_199
LBB4_122:                               ; %b203.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #44
	b.hi	LBB4_124
; %bb.123:                              ; %b203.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	lsl	x8, x28, x23
	mov	x9, #9728                       ; =0x2600
	movk	x9, #4097, lsl #32
	tst	x8, x9
	b.ne	LBB4_126
LBB4_124:                               ; %b203.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #93
	b.eq	LBB4_126
LBB4_125:                               ; %b203.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #125
	b.ne	LBB4_199
LBB4_126:                               ; %b215.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cbz	w8, LBB4_130
; %bb.127:                              ; %b2.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.128:                              ; %v12_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldrb	w9, [x20, w8, uxtw]
	orr	w9, w9, #0x2
	cmp	w9, #3
	b.ne	LBB4_131
; %bb.129:                              ; %v24_ok.i40.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w26, [x20, w8, uxtw]
	b	LBB4_132
LBB4_130:                               ; %b1.i43.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w28, [x0, #124]
	b	LBB4_132
LBB4_131:                               ; %v28_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w4, [x20, w8, uxtw]
LBB4_132:                               ; %b216.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #32
	b.hi	LBB4_137
; %bb.133:                              ; %b216.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	lsl	x8, x28, x23
	mov	x9, #9728                       ; =0x2600
	movk	x9, #1, lsl #32
	tst	x8, x9
	b.eq	LBB4_137
LBB4_134:                               ; %liza___liza_json_mut_step.exit.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #168]
	cbnz	w8, LBB4_201
; %bb.135:                              ; %b16.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	x8, [x0, #48]
	adds	x8, x8, #1
	b.hs	LBB4_203
; %bb.136:                              ; %v46_ok.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	subs	x21, x21, #1
	str	x8, [x0, #48]
	b.ne	LBB4_3
	b	LBB4_193
LBB4_137:                               ; %b219.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldr	w8, [x0, #120]
	cbz	w8, LBB4_140
; %bb.138:                              ; %b220.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w9, w8, #1
	cmp	w9, #64
	b.hs	LBB4_203
; %bb.139:                              ; %v525_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldrb	w9, [x20, w9, uxtw]
	b	LBB4_141
LBB4_140:                               ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, wzr
LBB4_141:                               ; %b222.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #125
	b.eq	LBB4_148
; %bb.142:                              ; %b222.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #93
	b.ne	LBB4_144
; %bb.143:                              ; %b223.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w10, w9, #1
	cmp	w10, #1
	b.ls	LBB4_162
LBB4_144:                               ; %b240.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #4
	b.le	LBB4_152
; %bb.145:                              ; %b240.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #5
	b.eq	LBB4_164
; %bb.146:                              ; %b240.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #8
	b.eq	LBB4_154
; %bb.147:                              ; %b240.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #7
	b.eq	LBB4_156
	b	LBB4_172
LBB4_148:                               ; %b232.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #4
	b.le	LBB4_161
; %bb.149:                              ; %b232.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #7
	b.eq	LBB4_162
; %bb.150:                              ; %b232.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #5
	b.eq	LBB4_196
; %bb.151:                              ; %b232.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #8
	b.ne	LBB4_172
	b	LBB4_196
LBB4_152:                               ; %b240.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #2
	b.eq	LBB4_156
; %bb.153:                              ; %b240.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #4
	b.ne	LBB4_172
LBB4_154:                               ; %b262.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #34
	b.ne	LBB4_196
; %bb.155:                              ; %b266.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w28, [x0, #132]
	str	w28, [x0, #128]
	b	LBB4_134
LBB4_156:                               ; %b244.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #44
	b.ne	LBB4_196
; %bb.157:                              ; %b248.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	subs	w8, w8, #1
	cset	w10, lo
	cmp	w9, #2
	b.ne	LBB4_168
; %bb.158:                              ; %b249.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cbnz	w10, LBB4_203
; %bb.159:                              ; %v584_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.160:                              ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, #3                          ; =0x3
	strb	w9, [x20, w8, uxtw]
	b	LBB4_134
LBB4_161:                               ; %b232.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	b.ne	LBB4_171
LBB4_162:                               ; %b229.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB4_203
LBB4_163:                               ; %v542_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	str	w8, [x0, #120]
	b	LBB4_134
LBB4_164:                               ; %b253.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #58
	b.ne	LBB4_196
; %bb.165:                              ; %b257.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB4_203
; %bb.166:                              ; %v612_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.167:                              ; %v613_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w24, [x20, w8, uxtw]
	b	LBB4_134
LBB4_168:                               ; %b250.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cbnz	w10, LBB4_203
; %bb.169:                              ; %v592_ok.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.170:                              ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, #8                          ; =0x8
	strb	w9, [x20, w8, uxtw]
	b	LBB4_134
LBB4_171:                               ; %b232.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w9, #2
	b.eq	LBB4_196
LBB4_172:                               ; %b259.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cbnz	w8, LBB4_174
; %bb.173:                              ; %b268.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	ldrb	w9, [x0, #124]
	cmp	w9, #1
	b.eq	LBB4_196
LBB4_174:                               ; %b273.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #90
	b.gt	LBB4_178
; %bb.175:                              ; %b273.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #34
	b.eq	LBB4_186
; %bb.176:                              ; %b273.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #45
	b.ne	LBB4_184
; %bb.177:                              ; %b289.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	w8, #10                         ; =0xa
	str	w8, [x0, #128]
	b	LBB4_134
LBB4_178:                               ; %b273.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #123
	b.eq	LBB4_180
; %bb.179:                              ; %b273.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #91
	b.ne	LBB4_184
LBB4_180:                               ; %b277.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #64
	b.eq	LBB4_202
; %bb.181:                              ; %b281.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	mov	x25, x1
	mov	x19, x0
	bl	_liza___liza_json_mut_done
	ldr	w8, [x19, #120]
	mov	x0, x19
	cmp	w23, #91
	b.ne	LBB4_187
; %bb.182:                              ; %b282.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.183:                              ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, #1                          ; =0x1
	b	LBB4_189
LBB4_184:                               ; %b291.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w23, #48
	cmp	w8, #9
	b.hi	LBB4_190
LBB4_185:                               ; %b143.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #48
	cinc	w8, w30, ne
	str	w8, [x0, #128]
	b	LBB4_134
LBB4_186:                               ; %b286.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	wzr, [x0, #132]
	str	w28, [x0, #128]
	b	LBB4_134
LBB4_187:                               ; %b283.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w8, #64
	b.hs	LBB4_203
; %bb.188:                              ;   in Loop: Header=BB4_3 Depth=1
	mov	w9, #4                          ; =0x4
LBB4_189:                               ; %b284.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	strb	w9, [x20, x8]
	mov	x5, #8193                       ; =0x2001
	mov	x1, x25
	ldr	w8, [x0, #120]
	mov	w16, #-96                       ; =0xffffffa0
	mov	w17, #-97                       ; =0xffffff9f
	mov	w2, #-112                       ; =0xffffff90
	mov	w3, #-113                       ; =0xffffff8f
	mov	w4, #7                          ; =0x7
	movk	x5, #1024, lsl #48
	mov	w6, #3                          ; =0x3
	mov	w7, #55296                      ; =0xd800
	mov	w19, #4                         ; =0x4
	mov	w25, #56320                     ; =0xdc00
	mov	w30, #11                        ; =0xb
	adds	w8, w8, #1
	b.lo	LBB4_163
	b	LBB4_203
LBB4_190:                               ; %b297.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	sub	w8, w23, #102
	cmp	w8, #14
	b.hi	LBB4_196
; %bb.191:                              ; %b297.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	lsl	w8, w28, w8
	mov	w9, #16641                      ; =0x4101
	tst	w8, w9
	b.eq	LBB4_196
; %bb.192:                              ; %b304.i.i
                                        ;   in Loop: Header=BB4_3 Depth=1
	cmp	w23, #102
	mov	w8, #20                         ; =0x14
	str	w8, [x0, #128]
	cinc	w8, w26, ne
	cmp	w23, #116
	csinc	w8, w8, wzr, ne
	stp	w8, w28, [x0, #136]
	b	LBB4_134
LBB4_193:
	mov	w8, wzr
	b	LBB4_201
LBB4_194:                               ; %b9.i
	cmp	w8, #0
	mov	w8, #8                          ; =0x8
	mov	w10, #5                         ; =0x5
	csel	w8, w10, w8, eq
	b	LBB4_200
LBB4_195:                               ; %b48.i16.i
	ldr	x9, [x0, #160]
	mov	w8, #4                          ; =0x4
	b	LBB4_200
LBB4_196:                               ; %b3.i32.i
	ldr	x9, [x0, #48]
	mov	w8, #1                          ; =0x1
	b	LBB4_200
LBB4_197:                               ; %b44.i.i
	ldr	x9, [x0, #48]
	mov	w8, #3                          ; =0x3
	b	LBB4_200
LBB4_198:                               ; %b86.i.i
	ldr	x9, [x0, #152]
	mov	w8, #4                          ; =0x4
	b	LBB4_200
LBB4_199:                               ; %b140.i.i
	ldr	x9, [x0, #48]
	mov	w8, #2                          ; =0x2
LBB4_200:                               ; %common.ret.sink.split.i
	str	w8, [x0, #168]
	str	x9, [x0, #176]
LBB4_201:                               ; %liza_json.feed_mut.exit
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	mov	w0, w8
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB4_202:                               ; %b279.i.i
	ldr	x9, [x0, #48]
	mov	w8, #7                          ; =0x7
	b	LBB4_200
LBB4_203:                               ; %v145_trap.i.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
; %bb.0:                                ; %b0
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.create        ; -- Begin function liza_utf8_stream.create
	.p2align	2
_liza_utf8_stream.create:               ; @liza_utf8_stream.create
; %bb.0:                                ; %b0
	mov	x0, xzr
	mov	x1, xzr
	mov	x2, xzr
	mov	w3, wzr
	mov	w4, #128                        ; =0x80
	mov	w5, #191                        ; =0xbf
	mov	w6, wzr
	mov	x7, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.feed_byte     ; -- Begin function liza_utf8_stream.feed_byte
	.p2align	2
_liza_utf8_stream.feed_byte:            ; @liza_utf8_stream.feed_byte
; %bb.0:                                ; %b0
	cbz	w6, LBB7_2
LBB7_1:                                 ; %common.ret
	ret
LBB7_2:                                 ; %b3
	cmn	x0, #1
	b.eq	LBB7_9
; %bb.3:                                ; %b6
	ldrb	w8, [sp]
	cbz	w3, LBB7_10
; %bb.4:                                ; %b8
	and	w8, w8, #0xff
	cmp	w8, w4, uxtb
	b.lo	LBB7_13
; %bb.5:                                ; %b8
	cmp	w8, w5, uxtb
	b.hi	LBB7_13
; %bb.6:                                ; %v115_ok
	subs	w3, w3, #1
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	b.ne	LBB7_24
; %bb.7:                                ; %b51
	cmn	x1, #1
	b.eq	LBB7_20
; %bb.8:                                ; %v138_ok
	add	x1, x1, #1
	b	LBB7_24
LBB7_9:                                 ; %b4
	mov	x7, #-1                         ; =0xffffffffffffffff
	mov	w6, #2                          ; =0x2
	ret
LBB7_10:                                ; %b7
	tbnz	w8, #7, LBB7_14
; %bb.11:                               ; %b9
	cmn	x1, #1
	b.eq	LBB7_16
; %bb.12:                               ; %v32_ok
	add	x1, x1, #1
	mov	x2, x0
	b	LBB7_24
LBB7_13:                                ; %b48
	mov	w6, #1                          ; =0x1
	mov	x7, x2
	ret
LBB7_14:                                ; %b10
	add	w9, w8, #62
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	and	w9, w9, #0xff
	cmp	w9, #30
	b.hs	LBB7_18
; %bb.15:                               ; %b17
	mov	w3, #1                          ; =0x1
	mov	x2, x0
	b	LBB7_24
LBB7_16:                                ; %b11
	mov	w6, #2                          ; =0x2
LBB7_17:                                ; %common.ret
	mov	x2, x0
	mov	x7, x0
	ret
LBB7_18:                                ; %b18
	and	w9, w8, #0xf0
	cmp	w9, #224
	b.ne	LBB7_21
; %bb.19:                               ; %b22
	and	w8, w8, #0xff
	mov	w9, #-96                        ; =0xffffffa0
	mov	w3, #2                          ; =0x2
	cmp	w8, #224
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #237
	mov	w8, #-97                        ; =0xffffff9f
	b	LBB7_23
LBB7_20:                                ; %b53
	mov	w6, #2                          ; =0x2
	mov	x7, x0
	ret
LBB7_21:                                ; %b23
	add	w9, w8, #16
	and	w9, w9, #0xff
	cmp	w9, #4
	b.hi	LBB7_26
; %bb.22:                               ; %b33
	and	w8, w8, #0xff
	mov	w9, #-112                       ; =0xffffff90
	mov	w3, #3                          ; =0x3
	cmp	w8, #240
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #244
	mov	w8, #-113                       ; =0xffffff8f
LBB7_23:                                ; %b57
	csel	w5, w8, w5, eq
LBB7_24:                                ; %b57
	adds	x0, x0, #1
	b.lo	LBB7_1
; %bb.25:                               ; %v145_trap
	brk	#0x1
LBB7_26:                                ; %b34
	mov	w6, #1                          ; =0x1
	b	LBB7_17
                                        ; -- End function
	.globl	_liza_utf8_stream.finish        ; -- Begin function liza_utf8_stream.finish
	.p2align	2
_liza_utf8_stream.finish:               ; @liza_utf8_stream.finish
; %bb.0:                                ; %b0
	cmp	w6, #1
	b.eq	LBB8_3
; %bb.1:                                ; %b0
	cmp	w6, #2
	b.ne	LBB8_4
; %bb.2:                                ; %b4
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_3:                                 ; %b1
	mov	x1, xzr
	b	LBB8_6
LBB8_4:                                 ; %b6
	cbz	w3, LBB8_7
; %bb.5:                                ; %b7
	mov	x1, xzr
	mov	x7, x2
LBB8_6:                                 ; %common.ret
	mov	w2, wzr
	mov	w0, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_7:                                 ; %b9
	mov	w0, wzr
	mov	w2, wzr
	mov	x3, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.status        ; -- Begin function liza_utf8_stream.status
	.p2align	2
_liza_utf8_stream.status:               ; @liza_utf8_stream.status
; %bb.0:                                ; %b0
	mov	w8, #1                          ; =0x1
	cmp	w6, #2
	mov	w9, #1                          ; =0x1
	csel	w8, wzr, w8, eq
	csel	w9, w9, wzr, eq
	csel	x10, x7, xzr, eq
	cmp	w6, #1
	csel	w0, wzr, w8, eq
	csel	w1, wzr, w9, eq
	csel	x2, x7, x10, eq
	ret
                                        ; -- End function
	.globl	_liza_json.create               ; -- Begin function liza_json.create
	.p2align	2
_liza_json.create:                      ; @liza_json.create
; %bb.0:                                ; %b0
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w9, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8]
	str	wzr, [x8, #24]
	strh	w9, [x8, #28]
	str	wzr, [x8, #32]
	stur	q0, [x8, #40]
	stur	q0, [x8, #56]
	stur	q0, [x8, #72]
	stur	q0, [x8, #88]
	stur	q0, [x8, #104]
	str	wzr, [x8, #120]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	str	xzr, [x8, #176]
	str	wzr, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_liza___liza_json_done          ; -- Begin function liza___liza_json_done
	.p2align	2
_liza___liza_json_done:                 ; @liza___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #688
	ldr	w20, [x0, #120]
	add	x13, sp, #304
	cbz	w20, LBB11_5
; %bb.1:                                ; %b2
	ldrb	w9, [x0, #57]
	ldrb	w10, [x0, #59]
	sub	w21, w20, #1
	ldrb	w11, [x0, #61]
	ldrb	w23, [x0, #56]
	cmp	w21, #64
	stp	w10, w9, [sp, #168]             ; 8-byte Folded Spill
	ldrb	w22, [x0, #58]
	ldrb	w24, [x0, #98]
	strb	w9, [sp, #177]
	ldrb	w9, [x0, #60]
	ldrb	w25, [x0, #99]
	strb	w10, [sp, #179]
	ldrb	w10, [x0, #62]
	ldrb	w26, [x0, #100]
	stp	w11, w9, [sp, #160]             ; 8-byte Folded Spill
	ldrb	w27, [x0, #101]
	ldrb	w28, [x0, #102]
	strb	w9, [sp, #180]
	ldrb	w9, [x0, #63]
	ldrb	w30, [x0, #103]
	strb	w11, [sp, #181]
	ldrb	w11, [x0, #64]
	ldrb	w12, [x0, #107]
	stp	w9, w10, [sp, #152]             ; 8-byte Folded Spill
	ldrb	w13, [x0, #108]
	ldrb	w14, [x0, #109]
	strb	w10, [sp, #182]
	ldrb	w10, [x0, #65]
	ldrb	w15, [x0, #110]
	strb	w9, [sp, #183]
	ldrb	w9, [x0, #66]
	ldrb	w16, [x0, #111]
	stp	w10, w11, [sp, #144]            ; 8-byte Folded Spill
	ldrb	w17, [x0, #112]
	ldrb	w2, [x0, #113]
	strb	w11, [sp, #184]
	ldrb	w11, [x0, #67]
	ldrb	w3, [x0, #114]
	strb	w10, [sp, #185]
	ldrb	w10, [x0, #68]
	ldrb	w4, [x0, #115]
	stp	w11, w9, [sp, #136]             ; 8-byte Folded Spill
	ldrb	w5, [x0, #116]
	ldrb	w6, [x0, #117]
	strb	w9, [sp, #186]
	ldrb	w9, [x0, #69]
	ldrb	w7, [x0, #118]
	strb	w11, [sp, #187]
	ldrb	w11, [x0, #70]
	ldrb	w19, [x0, #119]
	stp	w9, w10, [sp, #128]             ; 8-byte Folded Spill
	strb	w10, [sp, #188]
	ldrb	w10, [x0, #71]
	strb	w9, [sp, #189]
	ldrb	w9, [x0, #72]
	stp	w10, w11, [sp, #120]            ; 8-byte Folded Spill
	strb	w11, [sp, #190]
	ldrb	w11, [x0, #73]
	strb	w10, [sp, #191]
	ldrb	w10, [x0, #74]
	stp	w11, w9, [sp, #112]             ; 8-byte Folded Spill
	strb	w9, [sp, #192]
	ldrb	w9, [x0, #75]
	strb	w11, [sp, #193]
	ldrb	w11, [x0, #76]
	stp	w9, w10, [sp, #104]             ; 8-byte Folded Spill
	strb	w10, [sp, #194]
	ldrb	w10, [x0, #77]
	strb	w9, [sp, #195]
	ldrb	w9, [x0, #78]
	stp	w10, w11, [sp, #96]             ; 8-byte Folded Spill
	strb	w11, [sp, #196]
	ldrb	w11, [x0, #79]
	strb	w10, [sp, #197]
	ldrb	w10, [x0, #80]
	stp	w11, w9, [sp, #88]              ; 8-byte Folded Spill
	strb	w9, [sp, #198]
	ldrb	w9, [x0, #81]
	strb	w11, [sp, #199]
	ldrb	w11, [x0, #82]
	stp	w9, w10, [sp, #80]              ; 8-byte Folded Spill
	strb	w10, [sp, #200]
	ldrb	w10, [x0, #83]
	strb	w9, [sp, #201]
	ldrb	w9, [x0, #84]
	stp	w10, w11, [sp, #72]             ; 8-byte Folded Spill
	strb	w11, [sp, #202]
	ldrb	w11, [x0, #85]
	strb	w10, [sp, #203]
	ldrb	w10, [x0, #87]
	stp	w11, w9, [sp, #64]              ; 8-byte Folded Spill
	strb	w9, [sp, #204]
	ldrb	w9, [x0, #86]
	strb	w10, [sp, #207]
	stp	w10, w9, [sp, #56]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #89]
	strb	w9, [sp, #206]
	ldrb	w9, [x0, #88]
	strb	w10, [sp, #209]
	stp	w10, w9, [sp, #48]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #91]
	strb	w9, [sp, #208]
	ldrb	w9, [x0, #90]
	strb	w10, [sp, #211]
	stp	w10, w9, [sp, #40]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #93]
	strb	w9, [sp, #210]
	ldrb	w9, [x0, #92]
	strb	w10, [sp, #213]
	stp	w10, w9, [sp, #32]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #95]
	strb	w9, [sp, #212]
	ldrb	w9, [x0, #94]
	strb	w10, [sp, #215]
	stp	w10, w9, [sp, #24]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #97]
	strb	w9, [sp, #214]
	ldrb	w9, [x0, #96]
	strb	w11, [sp, #205]
	ldrb	w11, [x0, #106]
	stp	w10, w9, [sp, #16]              ; 8-byte Folded Spill
	strb	w9, [sp, #216]
	ldrb	w9, [x0, #104]
	strb	w10, [sp, #217]
	ldrb	w10, [x0, #105]
	strb	w23, [sp, #176]
	strb	w22, [sp, #178]
	strb	w24, [sp, #218]
	strb	w25, [sp, #219]
	strb	w26, [sp, #220]
	strb	w27, [sp, #221]
	strb	w28, [sp, #222]
	strb	w30, [sp, #223]
	strb	w9, [sp, #224]
	strb	w10, [sp, #225]
	strb	w11, [sp, #226]
	strb	w12, [sp, #227]
	strb	w13, [sp, #228]
	strb	w14, [sp, #229]
	strb	w15, [sp, #230]
	strb	w16, [sp, #231]
	strb	w17, [sp, #232]
	strb	w2, [sp, #233]
	strb	w3, [sp, #234]
	strb	w4, [sp, #235]
	strb	w5, [sp, #236]
	strb	w6, [sp, #237]
	strb	w7, [sp, #238]
	strb	w19, [sp, #239]
	b.hs	LBB11_7
; %bb.2:                                ; %v10_ok
	add	x1, sp, #176
	add	x20, sp, #620
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	mov	w1, #2                          ; =0x2
	b.eq	LBB11_4
; %bb.3:                                ; %b3
	strb	w23, [sp, #240]
	mov	w23, w22
	ldr	w22, [sp, #172]                 ; 4-byte Folded Reload
	strb	w23, [sp, #242]
	strb	w22, [sp, #241]
	ldr	w22, [sp, #168]                 ; 4-byte Folded Reload
	strb	w24, [sp, #282]
	strb	w22, [sp, #243]
	ldr	w22, [sp, #164]                 ; 4-byte Folded Reload
	strb	w25, [sp, #283]
	strb	w22, [sp, #244]
	ldr	w22, [sp, #160]                 ; 4-byte Folded Reload
	strb	w26, [sp, #284]
	strb	w22, [sp, #245]
	ldr	w22, [sp, #156]                 ; 4-byte Folded Reload
	strb	w27, [sp, #285]
	strb	w22, [sp, #246]
	ldr	w22, [sp, #152]                 ; 4-byte Folded Reload
	strb	w28, [sp, #286]
	strb	w22, [sp, #247]
	ldr	w22, [sp, #148]                 ; 4-byte Folded Reload
	strb	w30, [sp, #287]
	strb	w22, [sp, #248]
	ldr	w22, [sp, #144]                 ; 4-byte Folded Reload
	strb	w9, [sp, #288]
	add	x9, sp, #240
	strb	w22, [sp, #249]
	ldr	w22, [sp, #140]                 ; 4-byte Folded Reload
	strb	w10, [sp, #289]
	mov	w10, #7                         ; =0x7
	strb	w22, [sp, #250]
	ldr	w22, [sp, #136]                 ; 4-byte Folded Reload
	strb	w11, [sp, #290]
	strb	w22, [sp, #251]
	ldr	w22, [sp, #132]                 ; 4-byte Folded Reload
	strb	w12, [sp, #291]
	strb	w22, [sp, #252]
	ldr	w22, [sp, #128]                 ; 4-byte Folded Reload
	strb	w13, [sp, #292]
	strb	w22, [sp, #253]
	ldr	w22, [sp, #124]                 ; 4-byte Folded Reload
	strb	w14, [sp, #293]
	strb	w22, [sp, #254]
	ldr	w22, [sp, #120]                 ; 4-byte Folded Reload
	strb	w15, [sp, #294]
	strb	w22, [sp, #255]
	ldr	w22, [sp, #116]                 ; 4-byte Folded Reload
	strb	w16, [sp, #295]
	strb	w22, [sp, #256]
	ldr	w22, [sp, #112]                 ; 4-byte Folded Reload
	strb	w17, [sp, #296]
	strb	w22, [sp, #257]
	ldr	w22, [sp, #108]                 ; 4-byte Folded Reload
	strb	w2, [sp, #297]
	strb	w22, [sp, #258]
	ldr	w22, [sp, #104]                 ; 4-byte Folded Reload
	strb	w3, [sp, #298]
	strb	w22, [sp, #259]
	ldr	w22, [sp, #100]                 ; 4-byte Folded Reload
	strb	w4, [sp, #299]
	strb	w22, [sp, #260]
	ldr	w22, [sp, #96]                  ; 4-byte Folded Reload
	strb	w5, [sp, #300]
	strb	w22, [sp, #261]
	ldr	w22, [sp, #92]                  ; 4-byte Folded Reload
	strb	w6, [sp, #301]
	strb	w22, [sp, #262]
	ldr	w22, [sp, #88]                  ; 4-byte Folded Reload
	strb	w7, [sp, #302]
	strb	w22, [sp, #263]
	ldr	w22, [sp, #84]                  ; 4-byte Folded Reload
	strb	w19, [sp, #303]
	strb	w22, [sp, #264]
	ldr	w22, [sp, #80]                  ; 4-byte Folded Reload
	strb	w22, [sp, #265]
	ldr	w22, [sp, #76]                  ; 4-byte Folded Reload
	strb	w22, [sp, #266]
	ldr	w22, [sp, #72]                  ; 4-byte Folded Reload
	strb	w22, [sp, #267]
	ldr	w22, [sp, #68]                  ; 4-byte Folded Reload
	strb	w22, [sp, #268]
	ldr	w22, [sp, #64]                  ; 4-byte Folded Reload
	strb	w22, [sp, #269]
	ldr	w22, [sp, #60]                  ; 4-byte Folded Reload
	strb	w22, [sp, #270]
	ldr	w22, [sp, #56]                  ; 4-byte Folded Reload
	strb	w22, [sp, #271]
	ldr	w22, [sp, #52]                  ; 4-byte Folded Reload
	strb	w22, [sp, #272]
	ldr	w22, [sp, #48]                  ; 4-byte Folded Reload
	strb	w22, [sp, #273]
	ldr	w22, [sp, #44]                  ; 4-byte Folded Reload
	strb	w22, [sp, #274]
	ldr	w22, [sp, #40]                  ; 4-byte Folded Reload
	strb	w22, [sp, #275]
	ldr	w22, [sp, #36]                  ; 4-byte Folded Reload
	strb	w22, [sp, #276]
	ldr	w22, [sp, #32]                  ; 4-byte Folded Reload
	strb	w22, [sp, #277]
	ldr	w22, [sp, #28]                  ; 4-byte Folded Reload
	strb	w22, [sp, #278]
	ldr	w22, [sp, #24]                  ; 4-byte Folded Reload
	strb	w22, [sp, #279]
	ldr	w22, [sp, #20]                  ; 4-byte Folded Reload
	strb	w22, [sp, #280]
	ldr	w22, [sp, #16]                  ; 4-byte Folded Reload
	strb	w22, [sp, #281]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	add	x9, sp, #556
	csel	x20, x20, x9, eq
	csel	w1, w1, w10, eq
LBB11_4:                                ; %b8_to_b9
	ldur	q0, [x0, #56]
	ldur	q1, [x0, #72]
	add	x13, sp, #304
	ldur	q2, [x0, #88]
	ldur	q3, [x0, #168]
	add	x11, sp, #432
	stp	q0, q1, [x20]
	ldur	q0, [x0, #104]
	ldr	x9, [x0, #48]
	stur	q3, [x13, #171]
	ldur	q4, [x0, #157]
	ldur	q5, [x0, #141]
	stp	q2, q0, [x20, #32]
	ldr	q2, [x0]
	ldur	q6, [x0, #125]
	strb	w1, [x20, x21]
	ldrb	w10, [x0, #124]
	str	q2, [sp, #496]
	ldp	q1, q0, [x0, #16]
	str	x9, [sp, #544]
	ldr	w9, [x0, #120]
	add	x0, sp, #496
	stp	q5, q4, [sp, #448]
	ldp	q2, q3, [x20, #32]
	stp	q1, q0, [sp, #512]
	ldp	q0, q1, [x20]
	str	q6, [sp, #432]
	b	LBB11_6
LBB11_5:                                ; %b1
	ldur	q0, [x0, #56]
	ldur	q1, [x0, #72]
	mov	w10, #1                         ; =0x1
	ldur	q2, [x0, #88]
	ldur	q3, [x0, #104]
	mov	w9, wzr
	add	x11, x0, #125
	strb	w10, [sp, #684]
LBB11_6:                                ; %b9
	ldp	q6, q7, [x11]
	ldr	q16, [x0, #32]
	ldp	q4, q5, [x0]
	ldr	x12, [x0, #48]
	str	q16, [sp, #400]
	stp	q6, q7, [sp, #304]
	ldr	q6, [x11, #32]
	stp	q4, q5, [sp, #368]
	str	q6, [sp, #336]
	ldur	q6, [x11, #43]
	stur	q0, [x8, #56]
	stur	q6, [x13, #43]
	ldur	q0, [x13, #43]
	stur	q1, [x8, #72]
	str	x12, [sp, #416]
	stur	q0, [x8, #168]
	ldp	q0, q1, [sp, #320]
	stp	q4, q5, [x8]
	str	q16, [x8, #32]
	stur	q1, [x8, #157]
	ldr	q1, [sp, #304]
	str	x12, [x8, #48]
	stur	q2, [x8, #88]
	stur	q3, [x8, #104]
	str	w9, [x8, #120]
	strb	w10, [x8, #124]
	stur	q0, [x8, #141]
	stur	q1, [x8, #125]
	add	sp, sp, #688
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB11_7:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_json_space         ; -- Begin function liza___liza_json_space
	.p2align	2
_liza___liza_json_space:                ; @liza___liza_json_space
; %bb.0:                                ; %b0
	mov	x8, #9728                       ; =0x2600
                                        ; kill: def $w0 killed $w0 def $x0
	and	w9, w0, #0xff
	movk	x8, #1, lsl #32
	cmp	w9, #33
	lsr	x8, x8, x0
	cset	w9, lo
	and	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza___liza_json_digit         ; -- Begin function liza___liza_json_digit
	.p2align	2
_liza___liza_json_digit:                ; @liza___liza_json_digit
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w8, w8, #48
	cmp	w8, #10
	cset	w0, lo
	ret
                                        ; -- End function
	.globl	_liza___liza_json_hex           ; -- Begin function liza___liza_json_hex
	.p2align	2
_liza___liza_json_hex:                  ; @liza___liza_json_hex
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w0, w8, #48
	cmp	w0, #9
	b.hi	LBB14_2
; %bb.1:                                ; %common.ret
	ret
LBB14_2:                                ; %b6
	sub	w9, w8, #65
	cmp	w9, #5
	b.hi	LBB14_4
; %bb.3:                                ; %v15_ok
	sub	w0, w8, #55
	ret
LBB14_4:                                ; %b12
	sub	w9, w8, #97
	cmp	w9, #5
	b.hi	LBB14_6
; %bb.5:                                ; %v24_ok
	sub	w0, w8, #87
	ret
LBB14_6:
	mov	w0, #16                         ; =0x10
	ret
                                        ; -- End function
	.globl	_liza_json.status               ; -- Begin function liza_json.status
	.p2align	2
_liza_json.status:                      ; @liza_json.status
; %bb.0:                                ; %b0
	ldr	w9, [x0, #168]
	cbz	w9, LBB15_2
; %bb.1:                                ; %b3
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	mov	x8, x0
	cset	w11, eq
	cmp	w9, #3
	ldr	x2, [x8, #176]
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	mov	w0, wzr
	csel	w1, w9, w10, eq
	ret
LBB15_2:
	mov	w1, wzr
	mov	x2, xzr
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_json.finish               ; -- Begin function liza_json.finish
	.p2align	2
_liza_json.finish:                      ; @liza_json.finish
; %bb.0:                                ; %b0
	sub	sp, sp, #16
	ldr	w9, [x0, #168]
	cbz	w9, LBB16_6
; %bb.1:                                ; %b3.i
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	ldr	x3, [x0, #176]
	cset	w11, eq
	cmp	w9, #3
	mov	w8, wzr
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	csel	w2, w9, w10, eq
	cbz	w8, LBB16_7
LBB16_2:                                ; %b4
	ldr	w8, [x0, #32]
	ldr	x3, [x0, #40]
	cmp	w8, #2
	b.eq	LBB16_8
; %bb.3:                                ; %b4
	cmp	w8, #1
	b.eq	LBB16_9
; %bb.4:                                ; %b6.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB16_11
; %bb.5:                                ; %b7.i
	ldr	x3, [x0, #16]
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB16_10
	b	LBB16_12
LBB16_6:
	mov	w2, wzr
	mov	x3, xzr
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB16_2
LBB16_7:                                ; %b2
	mov	x1, xzr
	b	LBB16_26
LBB16_8:                                ; %b4.i
	mov	w8, #1                          ; =0x1
LBB16_9:                                ; %liza_utf8_stream.finish.exit
	cbz	w8, LBB16_12
LBB16_10:                               ; %b7
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	b	LBB16_26
LBB16_11:                               ; %b9.i
	mov	x3, xzr
	cbnz	w8, LBB16_10
LBB16_12:                               ; %b6
	ldr	w9, [x0, #128]
	cmp	w9, #17
	b.hi	LBB16_22
; %bb.13:                               ; %b6
	mov	w8, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w8, w8, w9
	movk	w10, #2, lsl #16
	tst	w8, w10
	b.eq	LBB16_22
; %bb.14:                               ; %b18
	ldr	w8, [x0, #120]
	ldrb	w9, [x0, #124]
	ldr	x3, [x0, #48]
	strb	w9, [sp, #12]
	cbz	w8, LBB16_17
; %bb.15:                               ; %b2.i
	sub	w9, w8, #65
	cmn	w9, #65
	b.hi	LBB16_18
; %bb.16:                               ; %v10_trap.i
	brk	#0x1
LBB16_17:                               ; %b1.i21
	mov	w9, #1                          ; =0x1
	strb	w9, [sp, #12]
LBB16_18:                               ; %b20.thread
	ldrb	w10, [sp, #12]
	mov	w9, wzr
	cbnz	w9, LBB16_25
LBB16_19:                               ; %b29
	cbnz	w8, LBB16_25
; %bb.20:                               ; %b29
	tbz	w10, #0, LBB16_25
; %bb.21:                               ; %b38
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	add	sp, sp, #16
	ret
LBB16_22:                               ; %b20
	sub	w8, w9, #4
	cmp	w8, #2
	b.hi	LBB16_24
; %bb.23:                               ; %b27
	ldr	x3, [x0, #160]
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
	b	LBB16_26
LBB16_24:
	ldr	x3, [x0, #48]
	ldr	w8, [x0, #120]
	ldrb	w10, [x0, #124]
	cbz	w9, LBB16_19
LBB16_25:                               ; %b36
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
LBB16_26:                               ; %common.ret
	mov	w0, #1                          ; =0x1
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_liza___liza_json_mut_fail      ; -- Begin function liza___liza_json_mut_fail
	.p2align	2
_liza___liza_json_mut_fail:             ; @liza___liza_json_mut_fail
; %bb.0:                                ; %b0
	str	w0, [x2, #168]
	str	x1, [x2, #176]
	ret
                                        ; -- End function
	.globl	_liza___liza_json_mut_done      ; -- Begin function liza___liza_json_mut_done
	.p2align	2
_liza___liza_json_mut_done:             ; @liza___liza_json_mut_done
; %bb.0:                                ; %b0
	ldr	w8, [x0, #120]
	cbz	w8, LBB18_4
; %bb.1:                                ; %b2
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB18_7
; %bb.2:                                ; %v12_ok
	add	x9, x0, #56
	ldrb	w10, [x9, w8, uxtw]
	orr	w10, w10, #0x2
	cmp	w10, #3
	b.ne	LBB18_5
; %bb.3:                                ; %v24_ok
	mov	w10, #2                         ; =0x2
	b	LBB18_6
LBB18_4:                                ; %b1
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #124]
	ldr	w0, [x0, #168]
	ret
LBB18_5:                                ; %v28_ok
	mov	w10, #7                         ; =0x7
LBB18_6:                                ; %b9
	strb	w10, [x9, w8, uxtw]
	ldr	w0, [x0, #168]
	ret
LBB18_7:                                ; %v12_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_json_mut_step      ; -- Begin function liza___liza_json_mut_step
	.p2align	2
_liza___liza_json_mut_step:             ; @liza___liza_json_mut_step
; %bb.0:                                ; %b0
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	ldr	w8, [x1, #128]
	mov	w19, w0
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	cmp	w8, #3
	b.le	LBB19_7
; %bb.1:                                ; %b0
	cmp	w8, #5
	b.gt	LBB19_10
; %bb.2:                                ; %b0
	cmp	w8, #4
	b.eq	LBB19_32
; %bb.3:                                ; %b0
	cmp	w8, #5
	b.ne	LBB19_25
; %bb.4:                                ; %b52
	and	w8, w19, #0xff
	cmp	w8, #117
	b.ne	LBB19_47
; %bb.5:                                ; %b56
	mov	w8, #6                          ; =0x6
LBB19_6:                                ; %common.ret
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	str	xzr, [x1, #144]
	b	LBB19_163
LBB19_7:                                ; %b0
	cmp	w8, #1
	b.eq	LBB19_18
; %bb.8:                                ; %b0
	cmp	w8, #2
	b.eq	LBB19_36
; %bb.9:                                ; %b0
	cmp	w8, #3
	b.eq	LBB19_16
	b	LBB19_25
LBB19_10:                               ; %b0
	cmp	w8, #6
	b.eq	LBB19_16
; %bb.11:                               ; %b0
	cmp	w8, #20
	b.ne	LBB19_25
; %bb.12:                               ; %b91
	ldr	w8, [x1, #136]
	cmp	w8, #3
	b.eq	LBB19_68
; %bb.13:                               ; %b91
	cmp	w8, #2
	b.eq	LBB19_67
; %bb.14:                               ; %b91
	cmp	w8, #1
	b.ne	LBB19_69
; %bb.15:                               ; %b104.thread
	ldr	w8, [x1, #140]
	mov	w9, #114                        ; =0x72
	mov	w10, #117                       ; =0x75
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	b	LBB19_70
LBB19_16:                               ; %b61
	sub	w9, w19, #48
	and	w9, w9, #0xff
	cmp	w9, #10
	b.hs	LBB19_34
; %bb.17:
	mov	w9, #-48                        ; =0xffffffd0
	b	LBB19_42
LBB19_18:                               ; %b1
	and	w8, w19, #0xff
	cmp	w8, #32
	b.lo	LBB19_161
; %bb.19:                               ; %b5
	cmp	w8, #92
	b.eq	LBB19_77
; %bb.20:                               ; %b5
	cmp	w8, #34
	b.ne	LBB19_96
; %bb.21:                               ; %b6
	ldrb	w8, [x1, #132]
	str	wzr, [x1, #128]
	cmp	w8, #1
	b.ne	LBB19_84
; %bb.22:                               ; %b8
	ldr	w8, [x1, #120]
	subs	w8, w8, #1
	b.lo	LBB19_168
; %bb.23:                               ; %v23_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.24:                               ; %v24_ok
	add	x9, x1, #56
	mov	w10, #5                         ; =0x5
	b	LBB19_95
LBB19_25:                               ; %b132
	sub	w9, w8, #10
	cmp	w9, #7
	b.hi	LBB19_62
; %bb.26:                               ; %b136
	sub	w9, w19, #48
	and	w9, w9, #0xff
	cmp	w9, #9
	b.hi	LBB19_57
; %bb.27:                               ; %b138
	cmp	w8, #10
	b.eq	LBB19_93
; %bb.28:                               ; %b138
	cmp	w8, #13
	b.eq	LBB19_85
; %bb.29:                               ; %b138
	cmp	w8, #11
	b.eq	LBB19_140
; %bb.30:                               ; %b151
	sub	w8, w8, #15
	cmp	w8, #1
	b.hi	LBB19_96
; %bb.31:
	mov	w8, #17                         ; =0x11
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_32:                               ; %b46
	and	w8, w19, #0xff
	cmp	w8, #92
	b.ne	LBB19_47
; %bb.33:                               ; %b50
	mov	w8, #5                          ; =0x5
	b	LBB19_55
LBB19_34:                               ; %b6.i
	sub	w9, w19, #65
	and	w9, w9, #0xff
	cmp	w9, #6
	b.hs	LBB19_40
; %bb.35:
	mov	w9, #-55                        ; =0xffffffc9
	b	LBB19_42
LBB19_36:                               ; %b16
	and	w8, w19, #0xff
	sub	w9, w8, #98
	cmp	w9, #19
	b.hi	LBB19_52
; %bb.37:                               ; %b16
	mov	w10, #1                         ; =0x1
	mov	w11, #4113                      ; =0x1011
	lsl	w10, w10, w9
	movk	w11, #5, lsl #16
	tst	w10, w11
	b.ne	LBB19_54
; %bb.38:                               ; %b16
	cmp	w9, #19
	b.ne	LBB19_52
; %bb.39:                               ; %b42
	mov	w8, #3                          ; =0x3
	b	LBB19_6
LBB19_40:                               ; %b12.i
	sub	w9, w19, #97
	and	w9, w9, #0xff
	cmp	w9, #6
	b.hs	LBB19_56
; %bb.41:
	mov	w9, #-87                        ; =0xffffffa9
LBB19_42:                               ; %b65
	ldr	w10, [x1, #148]
	lsr	w11, w10, #28
	cbnz	w11, LBB19_168
; %bb.43:                               ; %v165_ok
	add	w9, w9, w19, uxtb
	ldr	w11, [x1, #144]
	add	w9, w9, w10, lsl #4
	adds	w10, w11, #1
	str	w9, [x1, #148]
	b.hs	LBB19_168
; %bb.44:                               ; %v171_ok
	cmp	w10, #4
	str	w10, [x1, #144]
	b.ne	LBB19_96
; %bb.45:                               ; %b66
	cmp	w8, #6
	b.ne	LBB19_49
; %bb.46:                               ; %b68
	sub	w8, w9, #14, lsl #12            ; =57344
	cmn	w8, #1025
	b.hi	LBB19_54
LBB19_47:                               ; %b48
	ldr	x8, [x1, #160]
LBB19_48:                               ; %common.ret
	mov	w0, #4                          ; =0x4
	b	LBB19_162
LBB19_49:                               ; %b76
	and	w8, w9, #0xfffffc00
	mov	w9, #56320                      ; =0xdc00
	cmp	w8, w9
	b.eq	LBB19_78
; %bb.50:                               ; %b76
	mov	w9, #55296                      ; =0xd800
	cmp	w8, w9
	b.ne	LBB19_79
; %bb.51:                               ; %b80
	ldr	x9, [x1, #152]
	mov	w8, #4                          ; =0x4
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	str	x9, [x1, #160]
	b	LBB19_163
LBB19_52:                               ; %b16
	sub	w8, w8, #34
	cmp	w8, #58
	b.hi	LBB19_56
; %bb.53:                               ; %b16
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	mov	x9, #8193                       ; =0x2001
	movk	x9, #1024, lsl #48
	tst	x8, x9
	b.eq	LBB19_56
LBB19_54:                               ; %b39
	mov	w8, #1                          ; =0x1
LBB19_55:                               ; %common.ret
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	b	LBB19_163
LBB19_56:                               ; %b44
	ldr	x8, [x1, #48]
	mov	w0, #3                          ; =0x3
	b	LBB19_162
LBB19_57:                               ; %b158
	cmp	w8, #11
	b.ne	LBB19_80
; %bb.58:                               ; %b162
	and	w8, w19, #0xff
	cmp	w8, #92
	b.gt	LBB19_105
; %bb.59:                               ; %b162
	sub	w8, w8, #9
	cmp	w8, #60
	b.hi	LBB19_140
; %bb.60:                               ; %b162
	mov	w9, #1                          ; =0x1
	mov	x10, #19                        ; =0x13
	lsl	x9, x9, x8
	movk	x10, #128, lsl #16
	movk	x10, #8, lsl #32
	tst	x9, x10
	b.eq	LBB19_112
LBB19_61:                               ; %b215
	mov	x0, x1
	str	wzr, [x1, #128]
	mov	x20, x1
	bl	_liza___liza_json_mut_done
	mov	x1, x20
LBB19_62:                               ; %b216
	and	w8, w19, #0xff
	cmp	w8, #32
	b.hi	LBB19_64
; %bb.63:                               ; %b216
	mov	w8, w19
	mov	w9, #1                          ; =0x1
	and	x8, x8, #0xff
	lsl	x8, x9, x8
	mov	x9, #9728                       ; =0x2600
	movk	x9, #1, lsl #32
	tst	x8, x9
	b.ne	LBB19_96
LBB19_64:                               ; %b219
	ldr	w8, [x1, #120]
	cbz	w8, LBB19_97
; %bb.65:                               ; %b220
	sub	w9, w8, #1
	cmp	w9, #64
	b.hs	LBB19_168
; %bb.66:                               ; %v525_ok
	add	x9, x1, w9, uxtw
	ldrb	w9, [x9, #56]
	b	LBB19_98
LBB19_67:                               ; %b105
	ldr	w8, [x1, #140]
	mov	w9, #97                         ; =0x61
	mov	w10, #108                       ; =0x6c
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w10, #115                       ; =0x73
	csel	w9, w10, w9, eq
	cmp	w8, #4
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	mov	w8, #5                          ; =0x5
	cmp	w9, w19, uxtb
	b.eq	LBB19_71
	b	LBB19_161
LBB19_68:                               ; %b120
	ldr	w8, [x1, #140]
	mov	w9, #117                        ; =0x75
	cmp	w8, #1
	mov	w8, #108                        ; =0x6c
	csel	w9, w9, w8, eq
	b	LBB19_70
LBB19_69:
	mov	w9, wzr
LBB19_70:                               ; %b125
	mov	w8, #4                          ; =0x4
	cmp	w9, w19, uxtb
	b.ne	LBB19_161
LBB19_71:                               ; %b128
	ldr	w9, [x1, #140]
	adds	w9, w9, #1
	b.hs	LBB19_168
; %bb.72:                               ; %v325_ok
	cmp	w9, w8
	str	w9, [x1, #140]
	b.ne	LBB19_96
; %bb.73:                               ; %b129
	ldr	w8, [x1, #120]
	str	wzr, [x1, #128]
	cbz	w8, LBB19_83
; %bb.74:                               ; %b2.i
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.75:                               ; %v12_ok.i
	add	x9, x1, #56
	ldrb	w10, [x9, w8, uxtw]
	orr	w10, w10, #0x2
	cmp	w10, #3
	b.ne	LBB19_94
; %bb.76:                               ; %v24_ok.i28
	mov	w10, #2                         ; =0x2
	b	LBB19_95
LBB19_77:                               ; %b12
	ldr	x9, [x1, #48]
	mov	w8, #2                          ; =0x2
	str	w8, [x1, #128]
	str	x9, [x1, #152]
	b	LBB19_96
LBB19_78:                               ; %b86
	ldr	x8, [x1, #152]
	b	LBB19_48
LBB19_79:                               ; %b88
	mov	w8, #1                          ; =0x1
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_80:                               ; %b159
	cmp	w8, #12
	b.ne	LBB19_86
; %bb.81:                               ; %b159
	and	w9, w19, #0xff
	cmp	w9, #46
	b.ne	LBB19_86
LBB19_82:                               ; %b165
	mov	w8, #13                         ; =0xd
	b	LBB19_55
LBB19_83:                               ; %b1.i
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #124]
	b	LBB19_96
LBB19_84:                               ; %b10
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	mov	x0, x1
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_liza___liza_json_mut_done
LBB19_85:
	mov	w8, #14                         ; =0xe
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_86:                               ; %b167
	cmp	w8, #16
	b.hi	LBB19_141
; %bb.87:                               ; %b167
	mov	w9, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w9, w9, w8
	tst	w9, w10
	b.ne	LBB19_118
; %bb.88:                               ; %b167
	mov	w10, #9216                      ; =0x2400
	movk	w10, #1, lsl #16
	tst	w9, w10
	b.ne	LBB19_140
; %bb.89:                               ; %b167
	cmp	w8, #15
	b.ne	LBB19_141
; %bb.90:                               ; %b183
	and	w8, w19, #0xff
	cmp	w8, #45
	b.eq	LBB19_92
; %bb.91:                               ; %b183
	cmp	w8, #43
	b.ne	LBB19_140
LBB19_92:                               ; %b189
	mov	w8, #16                         ; =0x10
	b	LBB19_55
LBB19_93:                               ; %b143
	and	w8, w19, #0xff
	cmp	w8, #48
	mov	w8, #11                         ; =0xb
	cinc	w8, w8, ne
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_94:                               ; %v28_ok.i
	mov	w10, #7                         ; =0x7
LBB19_95:                               ; %liza___liza_json_mut_done.exit
	strb	w10, [x9, w8, uxtw]
LBB19_96:                               ; %b131
	ldr	w0, [x1, #168]
	b	LBB19_163
LBB19_97:
	mov	w9, wzr
LBB19_98:                               ; %b222
	and	w10, w19, #0xff
	cmp	w10, #125
	b.eq	LBB19_108
; %bb.99:                               ; %b222
	cmp	w10, #93
	b.ne	LBB19_101
; %bb.100:                              ; %b223
	sub	w10, w9, #1
	cmp	w10, #1
	b.ls	LBB19_127
LBB19_101:                              ; %b240
	cmp	w9, #4
	b.le	LBB19_114
; %bb.102:                              ; %b240
	cmp	w9, #5
	b.eq	LBB19_135
; %bb.103:                              ; %b240
	cmp	w9, #8
	b.eq	LBB19_116
; %bb.104:                              ; %b240
	cmp	w9, #7
	b.eq	LBB19_120
	b	LBB19_129
LBB19_105:                              ; %b162
	cmp	w8, #93
	b.eq	LBB19_61
; %bb.106:                              ; %b162
	cmp	w8, #101
	b.eq	LBB19_119
LBB19_107:                              ; %b203
	cmp	w8, #125
	b.eq	LBB19_61
	b	LBB19_140
LBB19_108:                              ; %b232
	cmp	w9, #4
	b.le	LBB19_125
; %bb.109:                              ; %b232
	cmp	w9, #5
	b.eq	LBB19_161
; %bb.110:                              ; %b232
	cmp	w9, #8
	b.eq	LBB19_161
; %bb.111:                              ; %b232
	cmp	w9, #7
	b.eq	LBB19_127
	b	LBB19_129
LBB19_112:                              ; %b162
	cmp	x8, #37
	b.eq	LBB19_82
; %bb.113:                              ; %b162
	cmp	x8, #60
	b.eq	LBB19_119
	b	LBB19_140
LBB19_114:                              ; %b240
	cmp	w9, #2
	b.eq	LBB19_120
; %bb.115:                              ; %b240
	cmp	w9, #4
	b.ne	LBB19_129
LBB19_116:                              ; %b262
	and	w8, w19, #0xff
	cmp	w8, #34
	b.ne	LBB19_161
; %bb.117:                              ; %b266
	mov	w8, #1                          ; =0x1
	ldr	w0, [x1, #168]
	strb	w8, [x1, #132]
	str	w8, [x1, #128]
	b	LBB19_163
LBB19_118:                              ; %b174
	orr	w9, w19, #0x20
	and	w9, w9, #0xff
	cmp	w9, #101
	b.ne	LBB19_139
LBB19_119:                              ; %b180
	mov	w8, #15                         ; =0xf
	b	LBB19_55
LBB19_120:                              ; %b244
	and	w10, w19, #0xff
	cmp	w10, #44
	b.ne	LBB19_161
; %bb.121:                              ; %b248
	subs	w8, w8, #1
	cset	w10, lo
	cmp	w9, #2
	b.ne	LBB19_148
; %bb.122:                              ; %b249
	cbnz	w10, LBB19_168
; %bb.123:                              ; %v584_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.124:
	mov	w9, #3                          ; =0x3
	b	LBB19_151
LBB19_125:                              ; %b232
	cmp	w9, #2
	b.eq	LBB19_161
; %bb.126:                              ; %b232
	cmp	w9, #4
	b.ne	LBB19_129
LBB19_127:                              ; %b229
	subs	w8, w8, #1
	b.lo	LBB19_168
; %bb.128:                              ; %v542_ok
	ldr	w0, [x1, #168]
	str	w8, [x1, #120]
	b	LBB19_163
LBB19_129:                              ; %b259
	cbnz	w8, LBB19_131
; %bb.130:                              ; %b268
	ldrb	w9, [x1, #124]
	cmp	w9, #1
	b.eq	LBB19_161
LBB19_131:                              ; %b273
	and	w9, w19, #0xff
	cmp	w9, #90
	b.gt	LBB19_144
; %bb.132:                              ; %b273
	cmp	w9, #34
	b.eq	LBB19_157
; %bb.133:                              ; %b273
	cmp	w9, #45
	b.ne	LBB19_152
; %bb.134:                              ; %b289
	mov	w8, #10                         ; =0xa
	b	LBB19_55
LBB19_135:                              ; %b253
	and	w9, w19, #0xff
	cmp	w9, #58
	b.ne	LBB19_161
; %bb.136:                              ; %b257
	subs	w8, w8, #1
	b.lo	LBB19_168
; %bb.137:                              ; %v612_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.138:                              ; %v613_ok
	add	x9, x1, #56
	mov	w10, #6                         ; =0x6
	b	LBB19_95
LBB19_139:                              ; %b191
	cmp	w8, #13
	b.ne	LBB19_141
LBB19_140:                              ; %b140
	ldr	x8, [x1, #48]
	mov	w0, #2                          ; =0x2
	b	LBB19_162
LBB19_141:                              ; %b203
	and	w8, w19, #0xff
	cmp	w8, #44
	b.hi	LBB19_143
; %bb.142:                              ; %b203
	and	x9, x19, #0xff
	mov	w10, #1                         ; =0x1
	lsl	x9, x10, x9
	mov	x10, #9728                      ; =0x2600
	movk	x10, #4097, lsl #32
	tst	x9, x10
	b.ne	LBB19_61
LBB19_143:                              ; %b203
	cmp	w8, #93
	b.ne	LBB19_107
	b	LBB19_61
LBB19_144:                              ; %b273
	cmp	w9, #123
	b.eq	LBB19_146
; %bb.145:                              ; %b273
	cmp	w9, #91
	b.ne	LBB19_152
LBB19_146:                              ; %b277
	cmp	w8, #64
	b.ne	LBB19_154
; %bb.147:                              ; %b279
	ldr	x8, [x1, #48]
	mov	w0, #7                          ; =0x7
	b	LBB19_162
LBB19_148:                              ; %b250
	cbnz	w10, LBB19_168
; %bb.149:                              ; %v592_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.150:
	mov	w9, #8                          ; =0x8
LBB19_151:                              ; %b251
	add	x10, x1, #56
	strb	w9, [x10, w8, uxtw]
	b	LBB19_96
LBB19_152:                              ; %b291
	sub	w8, w19, #48
	and	w8, w8, #0xff
	cmp	w8, #9
	b.hi	LBB19_158
; %bb.153:                              ; %b292
	and	w8, w19, #0xff
	cmp	w8, #48
	mov	w8, #11                         ; =0xb
	cinc	w8, w8, ne
	b	LBB19_55
LBB19_154:                              ; %b281
	mov	x0, x1
	mov	x20, x1
	bl	_liza___liza_json_mut_done
	and	w10, w19, #0xff
	ldr	w9, [x20, #120]
	mov	x8, x20
	cmp	w10, #91
	b.ne	LBB19_164
; %bb.155:                              ; %b282
	cmp	w9, #64
	b.hs	LBB19_168
; %bb.156:
	mov	w10, #1                         ; =0x1
	b	LBB19_166
LBB19_157:                              ; %b286
	strb	wzr, [x1, #132]
	b	LBB19_54
LBB19_158:                              ; %b297
	and	w8, w19, #0xff
	sub	w9, w8, #102
	cmp	w9, #14
	b.hi	LBB19_161
; %bb.159:                              ; %b297
	mov	w8, #1                          ; =0x1
	mov	w10, #16641                     ; =0x4101
	lsl	w9, w8, w9
	tst	w9, w10
	b.eq	LBB19_161
; %bb.160:                              ; %b304
	and	w9, w19, #0xff
	mov	w10, #20                        ; =0x14
	mov	w11, #2                         ; =0x2
	cmp	w9, #102
	str	w10, [x1, #128]
	ldr	w0, [x1, #168]
	cinc	w10, w11, ne
	cmp	w9, #116
	csinc	w9, w10, wzr, ne
	stp	w9, w8, [x1, #136]
	b	LBB19_163
LBB19_161:                              ; %b3
	ldr	x8, [x1, #48]
	mov	w0, #1                          ; =0x1
LBB19_162:                              ; %common.ret
	str	w0, [x1, #168]
	str	x8, [x1, #176]
LBB19_163:                              ; %common.ret
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB19_164:                              ; %b283
	cmp	w9, #64
	b.hs	LBB19_168
; %bb.165:
	mov	w10, #4                         ; =0x4
LBB19_166:                              ; %b284
	add	x9, x8, x9
	strb	w10, [x9, #56]
	ldr	w9, [x8, #120]
	adds	w9, w9, #1
	b.hs	LBB19_168
; %bb.167:                              ; %v691_ok
	ldr	w0, [x8, #168]
	str	w9, [x8, #120]
	b	LBB19_163
LBB19_168:                              ; %v23_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_json.feed_mut             ; -- Begin function liza_json.feed_mut
	.p2align	2
_liza_json.feed_mut:                    ; @liza_json.feed_mut
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	ldr	w8, [x0, #168]
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	cbnz	w8, LBB20_201
; %bb.1:                                ; %b4.preheader
	cbz	w2, LBB20_193
; %bb.2:                                ; %v10_ok.lr.ph
	mov	x5, #8193                       ; =0x2001
	mov	w22, #4113                      ; =0x1011
	add	x20, x0, #56
	mov	w21, w2
	mov	w16, #-96                       ; =0xffffffa0
	mov	w17, #-97                       ; =0xffffff9f
	mov	w2, #-112                       ; =0xffffff90
	mov	w3, #-113                       ; =0xffffff8f
	mov	w26, #2                         ; =0x2
	mov	w27, #5                         ; =0x5
	mov	w28, #1                         ; =0x1
	mov	w4, #7                          ; =0x7
	movk	x5, #1024, lsl #48
	movk	w22, #5, lsl #16
	mov	w6, #3                          ; =0x3
	mov	w7, #55296                      ; =0xd800
	mov	w19, #4                         ; =0x4
	mov	w25, #56320                     ; =0xdc00
	mov	w30, #11                        ; =0xb
	mov	w24, #6                         ; =0x6
LBB20_3:                                ; %v10_ok
                                        ; =>This Inner Loop Header: Depth=1
	ldp	x10, x15, [x0, #8]
	ldr	x9, [x0, #40]
	ldrb	w23, [x1], #1
	ldr	w8, [x0, #32]
	ldrb	w11, [x0, #29]
	ldrb	w13, [x0, #28]
	ldr	w14, [x0, #24]
	ldr	x12, [x0]
	cbz	w8, LBB20_7
LBB20_4:                                ; %liza_utf8_stream.feed_byte.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #2
	stp	x12, x10, [x0]
	str	x15, [x0, #16]
	str	w14, [x0, #24]
	strb	w13, [x0, #28]
	strb	w11, [x0, #29]
	str	w8, [x0, #32]
	str	x9, [x0, #40]
	b.eq	LBB20_14
; %bb.5:                                ; %liza_utf8_stream.feed_byte.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #1
	b.ne	LBB20_15
; %bb.6:                                ; %b1.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w10, wzr
	mov	w8, wzr
	cmp	w10, #1
	b.eq	LBB20_16
	b	LBB20_194
LBB20_7:                                ; %b3.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmn	x12, #1
	b.eq	LBB20_34
; %bb.8:                                ; %b6.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cbz	w14, LBB20_57
; %bb.9:                                ; %b8.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, w13, uxtb
	b.lo	LBB20_60
; %bb.10:                               ; %b8.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, w11, uxtb
	b.hi	LBB20_60
; %bb.11:                               ; %v115_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	w14, w14, #1
	mov	w11, #191                       ; =0xbf
	mov	w13, #128                       ; =0x80
	b.ne	LBB20_108
; %bb.12:                               ; %b51.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmn	x10, #1
	b.eq	LBB20_104
; %bb.13:                               ; %v138_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	x10, x10, #1
	b	LBB20_108
LBB20_14:                               ; %b4.i3
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w10, wzr
	mov	w8, #1                          ; =0x1
	cmp	w10, #1
	b.eq	LBB20_16
	b	LBB20_194
LBB20_15:                               ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, wzr
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
	cmp	w10, #1
	b.ne	LBB20_194
LBB20_16:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #128]
	cmp	w8, #3
	b.le	LBB20_23
; %bb.17:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #5
	b.gt	LBB20_26
; %bb.18:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #4
	b.eq	LBB20_49
; %bb.19:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #5
	b.ne	LBB20_42
; %bb.20:                               ; %b52.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #117
	b.ne	LBB20_195
; %bb.21:                               ; %b56.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	str	w24, [x0, #128]
LBB20_22:                               ; %liza___liza_json_mut_step.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	str	xzr, [x0, #144]
	b	LBB20_134
LBB20_23:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #1
	b.eq	LBB20_35
; %bb.24:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #2
	b.eq	LBB20_53
; %bb.25:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #3
	b.eq	LBB20_32
	b	LBB20_42
LBB20_26:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #6
	b.eq	LBB20_32
; %bb.27:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #20
	b.ne	LBB20_42
; %bb.28:                               ; %b91.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #136]
	cmp	w8, #3
	b.eq	LBB20_83
; %bb.29:                               ; %b91.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #2
	b.eq	LBB20_82
; %bb.30:                               ; %b91.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #1
	b.ne	LBB20_84
; %bb.31:                               ; %b104.thread.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #114                        ; =0x72
	mov	w10, #117                       ; =0x75
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	b	LBB20_85
LBB20_32:                               ; %b61.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w9, w23, #48
	cmp	w9, #10
	b.hs	LBB20_51
; %bb.33:                               ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, #-48                        ; =0xffffffd0
	b	LBB20_63
LBB20_34:                               ; %b4.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x9, #-1                         ; =0xffffffffffffffff
	mov	w8, #2                          ; =0x2
	b	LBB20_4
LBB20_35:                               ; %b1.i22
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #31
	b.ls	LBB20_196
; %bb.36:                               ; %b5.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #92
	b.eq	LBB20_73
; %bb.37:                               ; %b5.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #34
	b.ne	LBB20_134
; %bb.38:                               ; %b6.i25
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldrb	w9, [x0, #132]
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cmp	w9, #1
	b.ne	LBB20_96
; %bb.39:                               ; %b8.i28
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB20_203
; %bb.40:                               ; %v23_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.41:                               ; %v24_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w27, [x20, w8, uxtw]
	b	LBB20_134
LBB20_42:                               ; %b132.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w9, w8, #10
	cmp	w9, #7
	b.hi	LBB20_132
; %bb.43:                               ; %b136.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w9, w23, #48
	cmp	w9, #9
	b.hi	LBB20_76
; %bb.44:                               ; %b138.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #10
	b.eq	LBB20_185
; %bb.45:                               ; %b138.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #13
	b.eq	LBB20_105
; %bb.46:                               ; %b138.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #11
	b.eq	LBB20_199
; %bb.47:                               ; %b151.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w8, #15
	cmp	w8, #1
	b.hi	LBB20_134
; %bb.48:                               ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #17                         ; =0x11
	str	w8, [x0, #128]
	b	LBB20_134
LBB20_49:                               ; %b46.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #92
	b.ne	LBB20_195
; %bb.50:                               ; %b50.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	str	w27, [x0, #128]
	b	LBB20_134
LBB20_51:                               ; %b6.i.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w9, w23, #65
	cmp	w9, #6
	b.hs	LBB20_61
; %bb.52:                               ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, #-55                        ; =0xffffffc9
	b	LBB20_63
LBB20_53:                               ; %b16.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w23, #98
	cmp	w8, #19
	b.hi	LBB20_70
; %bb.54:                               ; %b16.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	lsl	w9, w28, w8
	tst	w9, w22
	b.ne	LBB20_72
; %bb.55:                               ; %b16.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #19
	b.ne	LBB20_70
; %bb.56:                               ; %b42.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	str	w6, [x0, #128]
	b	LBB20_22
LBB20_57:                               ; %b7.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	tbnz	w23, #7, LBB20_74
; %bb.58:                               ; %b9.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmn	x10, #1
	b.eq	LBB20_94
; %bb.59:                               ; %v32_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	x10, x10, #1
	mov	x15, x12
	b	LBB20_108
LBB20_60:                               ; %b48.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #1                          ; =0x1
	mov	x9, x15
	b	LBB20_4
LBB20_61:                               ; %b12.i.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w9, w23, #97
	cmp	w9, #6
	b.hs	LBB20_197
; %bb.62:                               ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, #-87                        ; =0xffffffa9
LBB20_63:                               ; %b65.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w10, [x0, #148]
	lsr	w11, w10, #28
	cbnz	w11, LBB20_203
; %bb.64:                               ; %v165_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	w9, w9, w23
	ldr	w11, [x0, #144]
	add	w9, w9, w10, lsl #4
	adds	w10, w11, #1
	str	w9, [x0, #148]
	b.hs	LBB20_203
; %bb.65:                               ; %v171_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w10, #4
	str	w10, [x0, #144]
	b.ne	LBB20_134
; %bb.66:                               ; %b66.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #6
	b.ne	LBB20_68
; %bb.67:                               ; %b68.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w9, #14, lsl #12            ; =57344
	cmn	w8, #1025
	b.hi	LBB20_72
	b	LBB20_195
LBB20_68:                               ; %b76.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	and	w8, w9, #0xfffffc00
	cmp	w8, w7
	b.eq	LBB20_93
; %bb.69:                               ; %b76.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, w25
	b.ne	LBB20_72
	b	LBB20_198
LBB20_70:                               ; %b16.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w23, #34
	cmp	w8, #58
	b.hi	LBB20_197
; %bb.71:                               ; %b16.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	lsl	x8, x28, x8
	tst	x8, x5
	b.eq	LBB20_197
LBB20_72:                               ; %b39.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	str	w28, [x0, #128]
	b	LBB20_134
LBB20_73:                               ; %b12.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	x8, [x0, #48]
	str	w26, [x0, #128]
	str	x8, [x0, #152]
	b	LBB20_134
LBB20_74:                               ; %b10.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	w11, w23, #62
	mov	w13, #128                       ; =0x80
	and	w11, w11, #0xff
	cmp	w11, #30
	mov	w11, #191                       ; =0xbf
	b.hs	LBB20_98
; %bb.75:                               ; %b17.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w14, #1                         ; =0x1
	mov	x15, x12
	b	LBB20_108
LBB20_76:                               ; %b158.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #11
	b.ne	LBB20_101
; %bb.77:                               ; %b162.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #92
	b.gt	LBB20_113
; %bb.78:                               ; %b162.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w23, #9
	cmp	w8, #60
	b.hi	LBB20_199
; %bb.79:                               ; %b162.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x10, #19                        ; =0x13
	lsl	x9, x28, x8
	movk	x10, #128, lsl #16
	movk	x10, #8, lsl #32
	tst	x9, x10
	b.ne	LBB20_126
; %bb.80:                               ; %b162.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	x8, #37
	b.eq	LBB20_103
; %bb.81:                               ; %b162.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	x8, #60
	b.eq	LBB20_115
	b	LBB20_199
LBB20_82:                               ; %b105.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #97                         ; =0x61
	mov	w10, #108                       ; =0x6c
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w10, #115                       ; =0x73
	csel	w9, w10, w9, eq
	cmp	w8, #4
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	mov	w8, #5                          ; =0x5
	b	LBB20_86
LBB20_83:                               ; %b120.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #117                        ; =0x75
	cmp	w8, #1
	mov	w8, #108                        ; =0x6c
	csel	w9, w9, w8, eq
	b	LBB20_85
LBB20_84:                               ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, wzr
LBB20_85:                               ; %b125.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #4                          ; =0x4
LBB20_86:                               ; %b125.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, w9
	b.ne	LBB20_196
; %bb.87:                               ; %b128.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w9, [x0, #140]
	adds	w9, w9, #1
	b.hs	LBB20_203
; %bb.88:                               ; %v325_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, w8
	str	w9, [x0, #140]
	b.ne	LBB20_134
; %bb.89:                               ; %b129.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cbz	w8, LBB20_97
LBB20_90:                               ; %b2.i.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.91:                               ; %v12_ok.i.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldrb	w9, [x20, w8, uxtw]
	orr	w9, w9, #0x2
	cmp	w9, #3
	b.ne	LBB20_100
; %bb.92:                               ; %v24_ok.i56
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w26, [x20, w8, uxtw]
	b	LBB20_134
LBB20_93:                               ; %b80.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	x8, [x0, #152]
	str	w19, [x0, #128]
	str	x8, [x0, #160]
	b	LBB20_134
LBB20_94:                               ; %b11.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #2                          ; =0x2
LBB20_95:                               ; %liza_utf8_stream.feed_byte.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x15, x12
	mov	x9, x12
	b	LBB20_4
LBB20_96:                               ; %b10.i27
                                        ;   in Loop: Header=BB20_3 Depth=1
	cbnz	w8, LBB20_90
LBB20_97:                               ; %b1.i62
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w28, [x0, #124]
	b	LBB20_134
LBB20_98:                               ; %b18.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	and	w15, w23, #0xf0
	cmp	w15, #224
	b.ne	LBB20_106
; %bb.99:                               ; %b22.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #224
	mov	w14, #2                         ; =0x2
	mov	x15, x12
	csel	w13, w16, w13, eq
	cmp	w23, #237
	csel	w11, w17, w11, eq
	b	LBB20_108
LBB20_100:                              ; %v28_ok.i60
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w4, [x20, w8, uxtw]
	b	LBB20_134
LBB20_101:                              ; %b159.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #12
	b.ne	LBB20_109
; %bb.102:                              ; %b159.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #46
	b.ne	LBB20_109
LBB20_103:                              ; %b165.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #13                         ; =0xd
	str	w8, [x0, #128]
	b	LBB20_134
LBB20_104:                              ; %b53.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #2                          ; =0x2
	mov	x9, x12
	b	LBB20_4
LBB20_105:                              ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #14                         ; =0xe
	str	w8, [x0, #128]
	b	LBB20_134
LBB20_106:                              ; %b23.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	w15, w23, #16
	and	w15, w15, #0xff
	cmp	w15, #4
	b.hi	LBB20_116
; %bb.107:                              ; %b33.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #240
	mov	w14, #3                         ; =0x3
	mov	x15, x12
	csel	w13, w2, w13, eq
	cmp	w23, #244
	csel	w11, w3, w11, eq
LBB20_108:                              ; %b57.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	adds	x12, x12, #1
	b.lo	LBB20_4
	b	LBB20_203
LBB20_109:                              ; %b167.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #16
	b.hi	LBB20_122
; %bb.110:                              ; %b167.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	lsl	w9, w28, w8
	mov	w10, #22528                     ; =0x5800
	tst	w9, w10
	b.eq	LBB20_117
; %bb.111:                              ; %b174.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	orr	w9, w23, #0x20
	cmp	w9, #101
	b.eq	LBB20_115
; %bb.112:                              ; %b191.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #13
	b.ne	LBB20_122
	b	LBB20_199
LBB20_113:                              ; %b162.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #93
	b.eq	LBB20_126
; %bb.114:                              ; %b162.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #101
	b.ne	LBB20_125
LBB20_115:                              ; %b180.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #15                         ; =0xf
	str	w8, [x0, #128]
	b	LBB20_134
LBB20_116:                              ; %b34.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB20_95
LBB20_117:                              ; %b167.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #15
	b.ne	LBB20_121
; %bb.118:                              ; %b183.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #45
	b.eq	LBB20_120
; %bb.119:                              ; %b183.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #43
	b.ne	LBB20_199
LBB20_120:                              ; %b189.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x0, #128]
	b	LBB20_134
LBB20_121:                              ; %b167.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #9216                       ; =0x2400
	movk	w8, #1, lsl #16
	tst	w9, w8
	b.ne	LBB20_199
LBB20_122:                              ; %b203.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #44
	b.hi	LBB20_124
; %bb.123:                              ; %b203.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	lsl	x8, x28, x23
	mov	x9, #9728                       ; =0x2600
	movk	x9, #4097, lsl #32
	tst	x8, x9
	b.ne	LBB20_126
LBB20_124:                              ; %b203.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #93
	b.eq	LBB20_126
LBB20_125:                              ; %b203.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #125
	b.ne	LBB20_199
LBB20_126:                              ; %b215.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cbz	w8, LBB20_130
; %bb.127:                              ; %b2.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.128:                              ; %v12_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldrb	w9, [x20, w8, uxtw]
	orr	w9, w9, #0x2
	cmp	w9, #3
	b.ne	LBB20_131
; %bb.129:                              ; %v24_ok.i40
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w26, [x20, w8, uxtw]
	b	LBB20_132
LBB20_130:                              ; %b1.i43
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w28, [x0, #124]
	b	LBB20_132
LBB20_131:                              ; %v28_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w4, [x20, w8, uxtw]
LBB20_132:                              ; %b216.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #32
	b.hi	LBB20_137
; %bb.133:                              ; %b216.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	lsl	x8, x28, x23
	mov	x9, #9728                       ; =0x2600
	movk	x9, #1, lsl #32
	tst	x8, x9
	b.eq	LBB20_137
LBB20_134:                              ; %liza___liza_json_mut_step.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #168]
	cbnz	w8, LBB20_201
; %bb.135:                              ; %b16
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	x8, [x0, #48]
	adds	x8, x8, #1
	b.hs	LBB20_203
; %bb.136:                              ; %v46_ok
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	x21, x21, #1
	str	x8, [x0, #48]
	b.ne	LBB20_3
	b	LBB20_193
LBB20_137:                              ; %b219.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	w8, [x0, #120]
	cbz	w8, LBB20_140
; %bb.138:                              ; %b220.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w9, w8, #1
	cmp	w9, #64
	b.hs	LBB20_203
; %bb.139:                              ; %v525_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldrb	w9, [x20, w9, uxtw]
	b	LBB20_141
LBB20_140:                              ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, wzr
LBB20_141:                              ; %b222.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #125
	b.eq	LBB20_148
; %bb.142:                              ; %b222.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #93
	b.ne	LBB20_144
; %bb.143:                              ; %b223.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w10, w9, #1
	cmp	w10, #1
	b.ls	LBB20_162
LBB20_144:                              ; %b240.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #4
	b.le	LBB20_152
; %bb.145:                              ; %b240.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #5
	b.eq	LBB20_164
; %bb.146:                              ; %b240.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #8
	b.eq	LBB20_154
; %bb.147:                              ; %b240.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #7
	b.eq	LBB20_156
	b	LBB20_172
LBB20_148:                              ; %b232.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #4
	b.le	LBB20_161
; %bb.149:                              ; %b232.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #7
	b.eq	LBB20_162
; %bb.150:                              ; %b232.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #5
	b.eq	LBB20_196
; %bb.151:                              ; %b232.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #8
	b.ne	LBB20_172
	b	LBB20_196
LBB20_152:                              ; %b240.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #2
	b.eq	LBB20_156
; %bb.153:                              ; %b240.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #4
	b.ne	LBB20_172
LBB20_154:                              ; %b262.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #34
	b.ne	LBB20_196
; %bb.155:                              ; %b266.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w28, [x0, #132]
	str	w28, [x0, #128]
	b	LBB20_134
LBB20_156:                              ; %b244.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #44
	b.ne	LBB20_196
; %bb.157:                              ; %b248.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	w8, w8, #1
	cset	w10, lo
	cmp	w9, #2
	b.ne	LBB20_168
; %bb.158:                              ; %b249.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cbnz	w10, LBB20_203
; %bb.159:                              ; %v584_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.160:                              ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, #3                          ; =0x3
	strb	w9, [x20, w8, uxtw]
	b	LBB20_134
LBB20_161:                              ; %b232.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	b.ne	LBB20_171
LBB20_162:                              ; %b229.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB20_203
LBB20_163:                              ; %v542_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	str	w8, [x0, #120]
	b	LBB20_134
LBB20_164:                              ; %b253.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #58
	b.ne	LBB20_196
; %bb.165:                              ; %b257.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB20_203
; %bb.166:                              ; %v612_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.167:                              ; %v613_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w24, [x20, w8, uxtw]
	b	LBB20_134
LBB20_168:                              ; %b250.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cbnz	w10, LBB20_203
; %bb.169:                              ; %v592_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.170:                              ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, #8                          ; =0x8
	strb	w9, [x20, w8, uxtw]
	b	LBB20_134
LBB20_171:                              ; %b232.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w9, #2
	b.eq	LBB20_196
LBB20_172:                              ; %b259.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cbnz	w8, LBB20_174
; %bb.173:                              ; %b268.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldrb	w9, [x0, #124]
	cmp	w9, #1
	b.eq	LBB20_196
LBB20_174:                              ; %b273.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #90
	b.gt	LBB20_178
; %bb.175:                              ; %b273.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #34
	b.eq	LBB20_186
; %bb.176:                              ; %b273.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #45
	b.ne	LBB20_184
; %bb.177:                              ; %b289.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #10                         ; =0xa
	str	w8, [x0, #128]
	b	LBB20_134
LBB20_178:                              ; %b273.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #123
	b.eq	LBB20_180
; %bb.179:                              ; %b273.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #91
	b.ne	LBB20_184
LBB20_180:                              ; %b277.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #64
	b.eq	LBB20_202
; %bb.181:                              ; %b281.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x25, x1
	mov	x19, x0
	bl	_liza___liza_json_mut_done
	ldr	w8, [x19, #120]
	mov	x0, x19
	cmp	w23, #91
	b.ne	LBB20_187
; %bb.182:                              ; %b282.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.183:                              ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, #1                          ; =0x1
	b	LBB20_189
LBB20_184:                              ; %b291.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w23, #48
	cmp	w8, #9
	b.hi	LBB20_190
LBB20_185:                              ; %b143.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #48
	cinc	w8, w30, ne
	str	w8, [x0, #128]
	b	LBB20_134
LBB20_186:                              ; %b286.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	wzr, [x0, #132]
	str	w28, [x0, #128]
	b	LBB20_134
LBB20_187:                              ; %b283.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #64
	b.hs	LBB20_203
; %bb.188:                              ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, #4                          ; =0x4
LBB20_189:                              ; %b284.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	strb	w9, [x20, x8]
	mov	x5, #8193                       ; =0x2001
	mov	x1, x25
	ldr	w8, [x0, #120]
	mov	w16, #-96                       ; =0xffffffa0
	mov	w17, #-97                       ; =0xffffff9f
	mov	w2, #-112                       ; =0xffffff90
	mov	w3, #-113                       ; =0xffffff8f
	mov	w4, #7                          ; =0x7
	movk	x5, #1024, lsl #48
	mov	w6, #3                          ; =0x3
	mov	w7, #55296                      ; =0xd800
	mov	w19, #4                         ; =0x4
	mov	w25, #56320                     ; =0xdc00
	mov	w30, #11                        ; =0xb
	adds	w8, w8, #1
	b.lo	LBB20_163
	b	LBB20_203
LBB20_190:                              ; %b297.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	sub	w8, w23, #102
	cmp	w8, #14
	b.hi	LBB20_196
; %bb.191:                              ; %b297.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	lsl	w8, w28, w8
	mov	w9, #16641                      ; =0x4101
	tst	w8, w9
	b.eq	LBB20_196
; %bb.192:                              ; %b304.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w23, #102
	mov	w8, #20                         ; =0x14
	str	w8, [x0, #128]
	cinc	w8, w26, ne
	cmp	w23, #116
	csinc	w8, w8, wzr, ne
	stp	w8, w28, [x0, #136]
	b	LBB20_134
LBB20_193:
	mov	w8, wzr
	b	LBB20_201
LBB20_194:                              ; %b9
	cmp	w8, #0
	mov	w8, #8                          ; =0x8
	mov	w10, #5                         ; =0x5
	csel	w8, w10, w8, eq
	b	LBB20_200
LBB20_195:                              ; %b48.i16
	ldr	x9, [x0, #160]
	mov	w8, #4                          ; =0x4
	b	LBB20_200
LBB20_196:                              ; %b3.i32
	ldr	x9, [x0, #48]
	mov	w8, #1                          ; =0x1
	b	LBB20_200
LBB20_197:                              ; %b44.i
	ldr	x9, [x0, #48]
	mov	w8, #3                          ; =0x3
	b	LBB20_200
LBB20_198:                              ; %b86.i
	ldr	x9, [x0, #152]
	mov	w8, #4                          ; =0x4
	b	LBB20_200
LBB20_199:                              ; %b140.i
	ldr	x9, [x0, #48]
	mov	w8, #2                          ; =0x2
LBB20_200:                              ; %common.ret.sink.split
	str	w8, [x0, #168]
	str	x9, [x0, #176]
LBB20_201:                              ; %common.ret
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	mov	w0, w8
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB20_202:                              ; %b279.i
	ldr	x9, [x0, #48]
	mov	w8, #7                          ; =0x7
	b	LBB20_200
LBB20_203:                              ; %v145_trap.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_owned___liza_json_done ; -- Begin function liza___liza_owned___liza_json_done
	.p2align	2
_liza___liza_owned___liza_json_done:    ; @liza___liza_owned___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #416
	ldr	w21, [x8, #120]
	cbz	w21, LBB21_5
; %bb.1:                                ; %b2
	ldrb	w11, [x8, #56]
	ldrb	w9, [x8, #57]
	sub	w21, w21, #1
	ldrb	w10, [x8, #58]
	ldrb	w2, [x8, #94]
	cmp	w21, #64
	strb	w11, [sp, #160]
	ldrb	w3, [x8, #95]
	ldrb	w4, [x8, #96]
	stp	w11, w10, [sp, #148]            ; 8-byte Folded Spill
	ldrb	w11, [x8, #59]
	ldrb	w5, [x8, #97]
	str	w9, [sp, #156]                  ; 4-byte Folded Spill
	ldrb	w6, [x8, #98]
	ldrb	w7, [x8, #99]
	strb	w9, [sp, #161]
	ldrb	w9, [x8, #60]
	ldrb	w19, [x8, #100]
	strb	w10, [sp, #162]
	ldrb	w10, [x8, #61]
	ldrb	w20, [x8, #101]
	stp	w9, w11, [sp, #140]             ; 8-byte Folded Spill
	ldrb	w22, [x8, #102]
	ldrb	w23, [x8, #103]
	strb	w11, [sp, #163]
	ldrb	w11, [x8, #62]
	ldrb	w24, [x8, #104]
	strb	w9, [sp, #164]
	ldrb	w9, [x8, #63]
	ldrb	w25, [x8, #105]
	stp	w11, w10, [sp, #132]            ; 8-byte Folded Spill
	ldrb	w26, [x8, #106]
	ldrb	w27, [x8, #107]
	strb	w10, [sp, #165]
	ldrb	w10, [x8, #64]
	ldrb	w28, [x8, #108]
	strb	w11, [sp, #166]
	ldrb	w11, [x8, #65]
	ldrb	w30, [x8, #109]
	stp	w10, w9, [sp, #124]             ; 8-byte Folded Spill
	ldrb	w12, [x8, #113]
	ldrb	w13, [x8, #114]
	strb	w9, [sp, #167]
	ldrb	w9, [x8, #66]
	ldrb	w14, [x8, #115]
	strb	w10, [sp, #168]
	ldrb	w10, [x8, #67]
	ldrb	w15, [x8, #116]
	stp	w9, w11, [sp, #116]             ; 8-byte Folded Spill
	ldrb	w16, [x8, #117]
	ldrb	w17, [x8, #118]
	strb	w11, [sp, #169]
	ldrb	w11, [x8, #68]
	ldrb	w0, [x8, #119]
	strb	w9, [sp, #170]
	ldrb	w9, [x8, #69]
	stp	w11, w10, [sp, #108]            ; 8-byte Folded Spill
	strb	w10, [sp, #171]
	ldrb	w10, [x8, #70]
	strb	w11, [sp, #172]
	ldrb	w11, [x8, #71]
	stp	w10, w9, [sp, #100]             ; 8-byte Folded Spill
	strb	w9, [sp, #173]
	ldrb	w9, [x8, #72]
	strb	w10, [sp, #174]
	ldrb	w10, [x8, #73]
	stp	w9, w11, [sp, #92]              ; 8-byte Folded Spill
	strb	w11, [sp, #175]
	ldrb	w11, [x8, #74]
	strb	w9, [sp, #176]
	ldrb	w9, [x8, #75]
	stp	w11, w10, [sp, #84]             ; 8-byte Folded Spill
	strb	w10, [sp, #177]
	ldrb	w10, [x8, #76]
	strb	w11, [sp, #178]
	ldrb	w11, [x8, #77]
	stp	w10, w9, [sp, #76]              ; 8-byte Folded Spill
	strb	w9, [sp, #179]
	ldrb	w9, [x8, #78]
	strb	w10, [sp, #180]
	ldrb	w10, [x8, #79]
	stp	w9, w11, [sp, #68]              ; 8-byte Folded Spill
	strb	w11, [sp, #181]
	ldrb	w11, [x8, #80]
	strb	w9, [sp, #182]
	ldrb	w9, [x8, #81]
	stp	w11, w10, [sp, #60]             ; 8-byte Folded Spill
	strb	w10, [sp, #183]
	ldrb	w10, [x8, #82]
	strb	w11, [sp, #184]
	ldrb	w11, [x8, #83]
	stp	w10, w9, [sp, #52]              ; 8-byte Folded Spill
	strb	w9, [sp, #185]
	ldrb	w9, [x8, #84]
	strb	w10, [sp, #186]
	ldrb	w10, [x8, #85]
	stp	w9, w11, [sp, #44]              ; 8-byte Folded Spill
	strb	w9, [sp, #188]
	ldrb	w9, [x8, #86]
	strb	w10, [sp, #189]
	stp	w9, w10, [sp, #36]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #87]
	strb	w9, [sp, #190]
	ldrb	w9, [x8, #88]
	strb	w10, [sp, #191]
	stp	w9, w10, [sp, #28]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #89]
	strb	w9, [sp, #192]
	ldrb	w9, [x8, #90]
	strb	w10, [sp, #193]
	stp	w9, w10, [sp, #20]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #91]
	strb	w9, [sp, #194]
	ldrb	w9, [x8, #92]
	strb	w10, [sp, #195]
	stp	w9, w10, [sp, #12]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #93]
	strb	w11, [sp, #187]
	ldrb	w11, [x8, #112]
	strb	w9, [sp, #196]
	ldrb	w9, [x8, #110]
	str	w10, [sp, #8]                   ; 4-byte Folded Spill
	strb	w10, [sp, #197]
	ldrb	w10, [x8, #111]
	strb	w2, [sp, #198]
	strb	w3, [sp, #199]
	strb	w4, [sp, #200]
	strb	w5, [sp, #201]
	strb	w6, [sp, #202]
	strb	w7, [sp, #203]
	strb	w19, [sp, #204]
	strb	w20, [sp, #205]
	strb	w22, [sp, #206]
	strb	w23, [sp, #207]
	strb	w24, [sp, #208]
	strb	w25, [sp, #209]
	strb	w26, [sp, #210]
	strb	w27, [sp, #211]
	strb	w28, [sp, #212]
	strb	w30, [sp, #213]
	strb	w9, [sp, #214]
	strb	w10, [sp, #215]
	strb	w11, [sp, #216]
	strb	w12, [sp, #217]
	strb	w13, [sp, #218]
	strb	w14, [sp, #219]
	strb	w15, [sp, #220]
	strb	w16, [sp, #221]
	strb	w17, [sp, #222]
	strb	w0, [sp, #223]
	b.hs	LBB21_9
; %bb.2:                                ; %v10_ok
	add	x1, sp, #160
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	b.eq	LBB21_4
; %bb.3:                                ; %b3
	ldr	w1, [sp, #148]                  ; 4-byte Folded Reload
	strb	w2, [sp, #262]
	strb	w3, [sp, #263]
	strb	w1, [sp, #224]
	ldr	w1, [sp, #156]                  ; 4-byte Folded Reload
	strb	w4, [sp, #264]
	strb	w1, [sp, #225]
	ldr	w1, [sp, #152]                  ; 4-byte Folded Reload
	strb	w5, [sp, #265]
	strb	w1, [sp, #226]
	ldr	w1, [sp, #144]                  ; 4-byte Folded Reload
	strb	w6, [sp, #266]
	strb	w1, [sp, #227]
	ldr	w1, [sp, #140]                  ; 4-byte Folded Reload
	strb	w7, [sp, #267]
	strb	w1, [sp, #228]
	ldr	w1, [sp, #136]                  ; 4-byte Folded Reload
	strb	w19, [sp, #268]
	strb	w1, [sp, #229]
	ldr	w1, [sp, #132]                  ; 4-byte Folded Reload
	strb	w20, [sp, #269]
	strb	w1, [sp, #230]
	ldr	w1, [sp, #128]                  ; 4-byte Folded Reload
	strb	w22, [sp, #270]
	strb	w1, [sp, #231]
	ldr	w1, [sp, #124]                  ; 4-byte Folded Reload
	strb	w23, [sp, #271]
	strb	w1, [sp, #232]
	ldr	w1, [sp, #120]                  ; 4-byte Folded Reload
	strb	w24, [sp, #272]
	strb	w1, [sp, #233]
	ldr	w1, [sp, #116]                  ; 4-byte Folded Reload
	strb	w25, [sp, #273]
	strb	w1, [sp, #234]
	ldr	w1, [sp, #112]                  ; 4-byte Folded Reload
	strb	w26, [sp, #274]
	strb	w1, [sp, #235]
	ldr	w1, [sp, #108]                  ; 4-byte Folded Reload
	strb	w27, [sp, #275]
	strb	w1, [sp, #236]
	ldr	w1, [sp, #104]                  ; 4-byte Folded Reload
	strb	w28, [sp, #276]
	strb	w1, [sp, #237]
	ldr	w1, [sp, #100]                  ; 4-byte Folded Reload
	strb	w30, [sp, #277]
	strb	w1, [sp, #238]
	ldr	w1, [sp, #96]                   ; 4-byte Folded Reload
	strb	w9, [sp, #278]
	add	x9, sp, #224
	strb	w1, [sp, #239]
	ldr	w1, [sp, #92]                   ; 4-byte Folded Reload
	strb	w10, [sp, #279]
	strb	w1, [sp, #240]
	ldr	w1, [sp, #88]                   ; 4-byte Folded Reload
	strb	w11, [sp, #280]
	strb	w1, [sp, #241]
	ldr	w1, [sp, #84]                   ; 4-byte Folded Reload
	strb	w12, [sp, #281]
	strb	w1, [sp, #242]
	ldr	w1, [sp, #80]                   ; 4-byte Folded Reload
	strb	w13, [sp, #282]
	strb	w1, [sp, #243]
	ldr	w1, [sp, #76]                   ; 4-byte Folded Reload
	strb	w14, [sp, #283]
	strb	w1, [sp, #244]
	ldr	w1, [sp, #72]                   ; 4-byte Folded Reload
	strb	w15, [sp, #284]
	strb	w1, [sp, #245]
	ldr	w1, [sp, #68]                   ; 4-byte Folded Reload
	strb	w16, [sp, #285]
	strb	w1, [sp, #246]
	ldr	w1, [sp, #64]                   ; 4-byte Folded Reload
	strb	w17, [sp, #286]
	strb	w1, [sp, #247]
	ldr	w1, [sp, #60]                   ; 4-byte Folded Reload
	strb	w0, [sp, #287]
	strb	w1, [sp, #248]
	ldr	w1, [sp, #56]                   ; 4-byte Folded Reload
	strb	w1, [sp, #249]
	ldr	w1, [sp, #52]                   ; 4-byte Folded Reload
	strb	w1, [sp, #250]
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	strb	w1, [sp, #251]
	ldr	w1, [sp, #44]                   ; 4-byte Folded Reload
	strb	w1, [sp, #252]
	ldr	w1, [sp, #40]                   ; 4-byte Folded Reload
	strb	w1, [sp, #253]
	ldr	w1, [sp, #36]                   ; 4-byte Folded Reload
	strb	w1, [sp, #254]
	ldr	w1, [sp, #32]                   ; 4-byte Folded Reload
	strb	w1, [sp, #255]
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	strb	w1, [sp, #256]
	ldr	w1, [sp, #24]                   ; 4-byte Folded Reload
	strb	w1, [sp, #257]
	ldr	w1, [sp, #20]                   ; 4-byte Folded Reload
	strb	w1, [sp, #258]
	ldr	w1, [sp, #16]                   ; 4-byte Folded Reload
	strb	w1, [sp, #259]
	ldr	w1, [sp, #12]                   ; 4-byte Folded Reload
	strb	w1, [sp, #260]
	ldr	w1, [sp, #8]                    ; 4-byte Folded Reload
	strb	w1, [sp, #261]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	b.ne	LBB21_6
LBB21_4:                                ; %v20_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #352
	ldur	q2, [x8, #88]
	mov	w10, #2                         ; =0x2
	stp	q0, q1, [sp, #352]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #384]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #352]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #384]
	b	LBB21_7
LBB21_5:                                ; %b1
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #124]
	b	LBB21_8
LBB21_6:                                ; %v25_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #288
	ldur	q2, [x8, #88]
	mov	w10, #7                         ; =0x7
	stp	q0, q1, [sp, #288]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #320]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #288]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #320]
LBB21_7:                                ; %b9
	stur	q0, [x8, #88]
	stur	q1, [x8, #104]
LBB21_8:                                ; %b9
	add	sp, sp, #416
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB21_9:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_example_entry                  ; -- Begin function example_entry
	.p2align	2
_example_entry:                         ; @example_entry
; %bb.0:                                ; %entry
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_stream_start                   ; -- Begin function stream_start
	.p2align	2
_stream_start:                          ; @stream_start
; %bb.0:
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w8, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x0, #8]
	str	xzr, [x0]
	str	wzr, [x0, #24]
	strh	w8, [x0, #28]
	str	wzr, [x0, #32]
	stur	q0, [x0, #40]
	stur	q0, [x0, #56]
	stur	q0, [x0, #72]
	stur	q0, [x0, #88]
	stur	q0, [x0, #104]
	str	wzr, [x0, #120]
	strb	wzr, [x0, #124]
	str	wzr, [x0, #128]
	strb	wzr, [x0, #132]
	str	xzr, [x0, #176]
	str	wzr, [x0, #168]
	stur	q0, [x0, #152]
	stur	q0, [x0, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_stream_feed                    ; -- Begin function stream_feed
	.p2align	2
_stream_feed:                           ; @stream_feed
; %bb.0:
	sub	sp, sp, #112
	ldr	w8, [x0, #168]
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	cbnz	w8, LBB24_200
; %bb.1:
	cbz	w2, LBB24_200
; %bb.2:                                ; %v10_ok.lr.ph.i
	mov	x5, #8193                       ; =0x2001
	mov	w22, #4113                      ; =0x1011
	mov	x25, #9728                      ; =0x2600
	add	x20, x0, #56
	mov	w21, w2
	mov	w16, #-96                       ; =0xffffffa0
	mov	w17, #-97                       ; =0xffffff9f
	mov	w2, #-112                       ; =0xffffff90
	mov	w3, #-113                       ; =0xffffff8f
	mov	w26, #2                         ; =0x2
	mov	w27, #5                         ; =0x5
	mov	w28, #1                         ; =0x1
	mov	w4, #7                          ; =0x7
	movk	x5, #1024, lsl #48
	movk	w22, #5, lsl #16
	mov	w6, #3                          ; =0x3
	mov	w7, #55296                      ; =0xd800
	mov	w19, #4                         ; =0x4
	mov	w30, #56320                     ; =0xdc00
	mov	w24, #6                         ; =0x6
	movk	x25, #1, lsl #32
LBB24_3:                                ; %v10_ok.i
                                        ; =>This Inner Loop Header: Depth=1
	ldp	x10, x15, [x0, #8]
	ldr	x8, [x0, #40]
	ldrb	w23, [x1], #1
	ldr	w9, [x0, #32]
	ldrb	w11, [x0, #29]
	ldrb	w13, [x0, #28]
	ldr	w14, [x0, #24]
	ldr	x12, [x0]
	cbz	w9, LBB24_7
LBB24_4:                                ; %liza_utf8_stream.feed_byte.exit.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #2
	stp	x12, x10, [x0]
	str	x15, [x0, #16]
	str	w14, [x0, #24]
	strb	w13, [x0, #28]
	strb	w11, [x0, #29]
	str	w9, [x0, #32]
	str	x8, [x0, #40]
	b.eq	LBB24_13
; %bb.5:                                ; %liza_utf8_stream.feed_byte.exit.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #1
	b.ne	LBB24_14
; %bb.6:                                ; %b1.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w10, wzr
	mov	w9, wzr
	cmp	w10, #1
	b.eq	LBB24_15
	b	LBB24_193
LBB24_7:                                ; %b3.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmn	x12, #1
	b.eq	LBB24_33
; %bb.8:                                ; %b6.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cbz	w14, LBB24_56
; %bb.9:                                ; %b8.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, w13, uxtb
	b.lo	LBB24_59
; %bb.10:                               ; %b8.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, w11, uxtb
	b.hi	LBB24_59
; %bb.11:                               ; %v115_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	subs	w14, w14, #1
	mov	w11, #191                       ; =0xbf
	mov	w13, #128                       ; =0x80
	b.eq	LBB24_94
; %bb.12:                               ; %b57.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	adds	x12, x12, #1
	b.lo	LBB24_4
	b	LBB24_203
LBB24_13:                               ; %b4.i3.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w10, wzr
	mov	w9, #1                          ; =0x1
	cmp	w10, #1
	b.eq	LBB24_15
	b	LBB24_193
LBB24_14:                               ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, wzr
	mov	x8, xzr
	mov	w10, #1                         ; =0x1
	cmp	w10, #1
	b.ne	LBB24_193
LBB24_15:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #128]
	cmp	w8, #3
	b.le	LBB24_22
; %bb.16:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #5
	b.gt	LBB24_25
; %bb.17:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #4
	b.eq	LBB24_48
; %bb.18:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #5
	b.ne	LBB24_41
; %bb.19:                               ; %b52.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #117
	b.ne	LBB24_194
; %bb.20:                               ; %b56.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	str	w24, [x0, #128]
LBB24_21:                               ; %liza___liza_json_mut_step.exit.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	str	xzr, [x0, #144]
	b	LBB24_135
LBB24_22:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #1
	b.eq	LBB24_34
; %bb.23:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #2
	b.eq	LBB24_52
; %bb.24:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #3
	b.eq	LBB24_31
	b	LBB24_41
LBB24_25:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #6
	b.eq	LBB24_31
; %bb.26:                               ; %b13.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #20
	b.ne	LBB24_41
; %bb.27:                               ; %b91.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #136]
	cmp	w8, #3
	b.eq	LBB24_83
; %bb.28:                               ; %b91.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #2
	b.eq	LBB24_82
; %bb.29:                               ; %b91.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #1
	b.ne	LBB24_84
; %bb.30:                               ; %b104.thread.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #114                        ; =0x72
	mov	w10, #117                       ; =0x75
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	b	LBB24_85
LBB24_31:                               ; %b61.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w9, w23, #48
	cmp	w9, #10
	b.hs	LBB24_50
; %bb.32:                               ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #-48                        ; =0xffffffd0
	b	LBB24_62
LBB24_33:                               ; %b4.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	x8, #-1                         ; =0xffffffffffffffff
	mov	w9, #2                          ; =0x2
	b	LBB24_4
LBB24_34:                               ; %b1.i22.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #31
	b.ls	LBB24_195
; %bb.35:                               ; %b5.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #92
	b.eq	LBB24_72
; %bb.36:                               ; %b5.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #34
	b.ne	LBB24_135
; %bb.37:                               ; %b6.i25.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldrb	w9, [x0, #132]
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cmp	w9, #1
	b.ne	LBB24_98
; %bb.38:                               ; %b8.i28.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB24_203
; %bb.39:                               ; %v23_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.40:                               ; %v24_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w27, [x20, w8, uxtw]
	b	LBB24_135
LBB24_41:                               ; %b132.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w9, w8, #10
	cmp	w9, #7
	b.hi	LBB24_133
; %bb.42:                               ; %b136.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w9, w23, #48
	cmp	w9, #9
	b.hi	LBB24_76
; %bb.43:                               ; %b138.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #10
	b.eq	LBB24_185
; %bb.44:                               ; %b138.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #13
	b.eq	LBB24_107
; %bb.45:                               ; %b138.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #11
	b.eq	LBB24_198
; %bb.46:                               ; %b151.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w8, #15
	cmp	w8, #1
	b.hi	LBB24_135
; %bb.47:                               ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #17                         ; =0x11
	str	w8, [x0, #128]
	b	LBB24_135
LBB24_48:                               ; %b46.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #92
	b.ne	LBB24_194
; %bb.49:                               ; %b50.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	str	w27, [x0, #128]
	b	LBB24_135
LBB24_50:                               ; %b6.i.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w9, w23, #65
	cmp	w9, #6
	b.hs	LBB24_60
; %bb.51:                               ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #-55                        ; =0xffffffc9
	b	LBB24_62
LBB24_52:                               ; %b16.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w23, #98
	cmp	w8, #19
	b.hi	LBB24_69
; %bb.53:                               ; %b16.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	lsl	w9, w28, w8
	tst	w9, w22
	b.ne	LBB24_71
; %bb.54:                               ; %b16.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #19
	b.ne	LBB24_69
; %bb.55:                               ; %b42.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	str	w6, [x0, #128]
	b	LBB24_21
LBB24_56:                               ; %b7.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	tbnz	w23, #7, LBB24_73
; %bb.57:                               ; %b9.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmn	x10, #1
	b.eq	LBB24_96
; %bb.58:                               ; %v32_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	add	x10, x10, #1
	b	LBB24_75
LBB24_59:                               ; %b48.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #1                          ; =0x1
	mov	x8, x15
	b	LBB24_4
LBB24_60:                               ; %b12.i.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w9, w23, #97
	cmp	w9, #6
	b.hs	LBB24_196
; %bb.61:                               ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #-87                        ; =0xffffffa9
LBB24_62:                               ; %b65.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w10, [x0, #148]
	lsr	w11, w10, #28
	cbnz	w11, LBB24_203
; %bb.63:                               ; %v165_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	add	w9, w9, w23
	ldr	w11, [x0, #144]
	add	w9, w9, w10, lsl #4
	adds	w10, w11, #1
	str	w9, [x0, #148]
	b.hs	LBB24_203
; %bb.64:                               ; %v171_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w10, #4
	str	w10, [x0, #144]
	b.ne	LBB24_135
; %bb.65:                               ; %b66.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #6
	b.ne	LBB24_67
; %bb.66:                               ; %b68.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w9, #14, lsl #12            ; =57344
	cmn	w8, #1025
	b.hi	LBB24_71
	b	LBB24_194
LBB24_67:                               ; %b76.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	and	w8, w9, #0xfffffc00
	cmp	w8, w7
	b.eq	LBB24_93
; %bb.68:                               ; %b76.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, w30
	b.ne	LBB24_71
	b	LBB24_197
LBB24_69:                               ; %b16.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w23, #34
	cmp	w8, #58
	b.hi	LBB24_196
; %bb.70:                               ; %b16.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	lsl	x8, x28, x8
	tst	x8, x5
	b.eq	LBB24_196
LBB24_71:                               ; %b39.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	str	w28, [x0, #128]
	b	LBB24_135
LBB24_72:                               ; %b12.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	x8, [x0, #48]
	str	w26, [x0, #128]
	str	x8, [x0, #152]
	b	LBB24_135
LBB24_73:                               ; %b10.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	add	w11, w23, #62
	mov	w13, #128                       ; =0x80
	and	w11, w11, #0xff
	cmp	w11, #30
	mov	w11, #191                       ; =0xbf
	b.hs	LBB24_100
; %bb.74:                               ; %b17.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w14, #1                         ; =0x1
LBB24_75:                               ; %v32_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	x15, x12
	adds	x12, x12, #1
	b.lo	LBB24_4
	b	LBB24_203
LBB24_76:                               ; %b158.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #11
	b.ne	LBB24_103
; %bb.77:                               ; %b162.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #92
	b.gt	LBB24_114
; %bb.78:                               ; %b162.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w23, #9
	cmp	w8, #60
	b.hi	LBB24_198
; %bb.79:                               ; %b162.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	x10, #19                        ; =0x13
	lsl	x9, x28, x8
	movk	x10, #128, lsl #16
	movk	x10, #8, lsl #32
	tst	x9, x10
	b.ne	LBB24_127
; %bb.80:                               ; %b162.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	x8, #37
	b.eq	LBB24_105
; %bb.81:                               ; %b162.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	x8, #60
	b.eq	LBB24_116
	b	LBB24_198
LBB24_82:                               ; %b105.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #97                         ; =0x61
	mov	w10, #108                       ; =0x6c
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w10, #115                       ; =0x73
	csel	w9, w10, w9, eq
	cmp	w8, #4
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	mov	w8, #5                          ; =0x5
	b	LBB24_86
LBB24_83:                               ; %b120.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #140]
	mov	w9, #117                        ; =0x75
	cmp	w8, #1
	mov	w8, #108                        ; =0x6c
	csel	w9, w9, w8, eq
	b	LBB24_85
LBB24_84:                               ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, wzr
LBB24_85:                               ; %b125.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #4                          ; =0x4
LBB24_86:                               ; %b125.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, w9
	b.ne	LBB24_195
; %bb.87:                               ; %b128.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w9, [x0, #140]
	adds	w9, w9, #1
	b.hs	LBB24_203
; %bb.88:                               ; %v325_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, w8
	str	w9, [x0, #140]
	b.ne	LBB24_135
; %bb.89:                               ; %b129.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cbz	w8, LBB24_99
LBB24_90:                               ; %b2.i.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.91:                               ; %v12_ok.i.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldrb	w9, [x20, w8, uxtw]
	orr	w9, w9, #0x2
	cmp	w9, #3
	b.ne	LBB24_102
; %bb.92:                               ; %v24_ok.i56.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w26, [x20, w8, uxtw]
	b	LBB24_135
LBB24_93:                               ; %b80.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	x8, [x0, #152]
	str	w19, [x0, #128]
	str	x8, [x0, #160]
	b	LBB24_135
LBB24_94:                               ; %b51.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmn	x10, #1
	b.eq	LBB24_106
; %bb.95:                               ; %v138_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	add	x10, x10, #1
	adds	x12, x12, #1
	b.lo	LBB24_4
	b	LBB24_203
LBB24_96:                               ; %b11.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #2                          ; =0x2
LBB24_97:                               ; %liza_utf8_stream.feed_byte.exit.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	x15, x12
	mov	x8, x12
	b	LBB24_4
LBB24_98:                               ; %b10.i27.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cbnz	w8, LBB24_90
LBB24_99:                               ; %b1.i62.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w28, [x0, #124]
	b	LBB24_135
LBB24_100:                              ; %b18.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	and	w15, w23, #0xf0
	cmp	w15, #224
	b.ne	LBB24_108
; %bb.101:                              ; %b22.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #224
	mov	w14, #2                         ; =0x2
	mov	x15, x12
	csel	w13, w16, w13, eq
	cmp	w23, #237
	csel	w11, w17, w11, eq
	adds	x12, x12, #1
	b.lo	LBB24_4
	b	LBB24_203
LBB24_102:                              ; %v28_ok.i60.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w4, [x20, w8, uxtw]
	b	LBB24_135
LBB24_103:                              ; %b159.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #12
	b.ne	LBB24_110
; %bb.104:                              ; %b159.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #46
	b.ne	LBB24_110
LBB24_105:                              ; %b165.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #13                         ; =0xd
	str	w8, [x0, #128]
	b	LBB24_135
LBB24_106:                              ; %b53.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #2                          ; =0x2
	mov	x8, x12
	b	LBB24_4
LBB24_107:                              ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #14                         ; =0xe
	str	w8, [x0, #128]
	b	LBB24_135
LBB24_108:                              ; %b23.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	add	w15, w23, #16
	and	w15, w15, #0xff
	cmp	w15, #4
	b.hi	LBB24_117
; %bb.109:                              ; %b33.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #240
	mov	w14, #3                         ; =0x3
	mov	x15, x12
	csel	w13, w2, w13, eq
	cmp	w23, #244
	csel	w11, w3, w11, eq
	adds	x12, x12, #1
	b.lo	LBB24_4
	b	LBB24_203
LBB24_110:                              ; %b167.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #16
	b.hi	LBB24_123
; %bb.111:                              ; %b167.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	lsl	w9, w28, w8
	mov	w10, #22528                     ; =0x5800
	tst	w9, w10
	b.eq	LBB24_118
; %bb.112:                              ; %b174.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	orr	w9, w23, #0x20
	cmp	w9, #101
	b.eq	LBB24_116
; %bb.113:                              ; %b191.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #13
	b.ne	LBB24_123
	b	LBB24_198
LBB24_114:                              ; %b162.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #93
	b.eq	LBB24_127
; %bb.115:                              ; %b162.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #101
	b.ne	LBB24_126
LBB24_116:                              ; %b180.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #15                         ; =0xf
	str	w8, [x0, #128]
	b	LBB24_135
LBB24_117:                              ; %b34.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #1                          ; =0x1
	b	LBB24_97
LBB24_118:                              ; %b167.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #15
	b.ne	LBB24_122
; %bb.119:                              ; %b183.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #45
	b.eq	LBB24_121
; %bb.120:                              ; %b183.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #43
	b.ne	LBB24_198
LBB24_121:                              ; %b189.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x0, #128]
	b	LBB24_135
LBB24_122:                              ; %b167.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #9216                       ; =0x2400
	movk	w8, #1, lsl #16
	tst	w9, w8
	b.ne	LBB24_198
LBB24_123:                              ; %b203.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #44
	b.hi	LBB24_125
; %bb.124:                              ; %b203.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	lsl	x8, x28, x23
	mov	x9, #9728                       ; =0x2600
	movk	x9, #4097, lsl #32
	tst	x8, x9
	b.ne	LBB24_127
LBB24_125:                              ; %b203.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #93
	b.eq	LBB24_127
LBB24_126:                              ; %b203.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #125
	b.ne	LBB24_198
LBB24_127:                              ; %b215.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #120]
	str	wzr, [x0, #128]
	cbz	w8, LBB24_131
; %bb.128:                              ; %b2.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.129:                              ; %v12_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldrb	w9, [x20, w8, uxtw]
	orr	w9, w9, #0x2
	cmp	w9, #3
	b.ne	LBB24_132
; %bb.130:                              ; %v24_ok.i40.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w26, [x20, w8, uxtw]
	b	LBB24_133
LBB24_131:                              ; %b1.i43.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w28, [x0, #124]
	b	LBB24_133
LBB24_132:                              ; %v28_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w4, [x20, w8, uxtw]
LBB24_133:                              ; %b216.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #32
	b.hi	LBB24_138
; %bb.134:                              ; %b216.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	lsl	x8, x28, x23
	tst	x8, x25
	b.eq	LBB24_138
LBB24_135:                              ; %liza___liza_json_mut_step.exit.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #168]
	cbnz	w8, LBB24_200
; %bb.136:                              ; %b16.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	x8, [x0, #48]
	adds	x8, x8, #1
	b.hs	LBB24_203
; %bb.137:                              ; %v46_ok.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	subs	x21, x21, #1
	str	x8, [x0, #48]
	b.ne	LBB24_3
	b	LBB24_200
LBB24_138:                              ; %b219.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldr	w8, [x0, #120]
	cbz	w8, LBB24_147
; %bb.139:                              ; %b220.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w9, w8, #1
	cmp	w9, #64
	b.hs	LBB24_203
; %bb.140:                              ; %v525_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldrb	w9, [x20, w9, uxtw]
	cmp	w23, #125
	b.eq	LBB24_148
LBB24_141:                              ; %b222.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #93
	b.ne	LBB24_143
; %bb.142:                              ; %b223.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w10, w9, #1
	cmp	w10, #1
	b.ls	LBB24_162
LBB24_143:                              ; %b240.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #4
	b.le	LBB24_152
; %bb.144:                              ; %b240.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #5
	b.eq	LBB24_164
; %bb.145:                              ; %b240.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #8
	b.eq	LBB24_154
; %bb.146:                              ; %b240.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #7
	b.eq	LBB24_156
	b	LBB24_172
LBB24_147:                              ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, wzr
	cmp	w23, #125
	b.ne	LBB24_141
LBB24_148:                              ; %b232.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #4
	b.le	LBB24_161
; %bb.149:                              ; %b232.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #7
	b.eq	LBB24_162
; %bb.150:                              ; %b232.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #5
	b.eq	LBB24_195
; %bb.151:                              ; %b232.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #8
	b.ne	LBB24_172
	b	LBB24_195
LBB24_152:                              ; %b240.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #2
	b.eq	LBB24_156
; %bb.153:                              ; %b240.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #4
	b.ne	LBB24_172
LBB24_154:                              ; %b262.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #34
	b.ne	LBB24_195
; %bb.155:                              ; %b266.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w28, [x0, #132]
	str	w28, [x0, #128]
	b	LBB24_135
LBB24_156:                              ; %b244.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #44
	b.ne	LBB24_195
; %bb.157:                              ; %b248.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	subs	w8, w8, #1
	cset	w10, lo
	cmp	w9, #2
	b.ne	LBB24_168
; %bb.158:                              ; %b249.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cbnz	w10, LBB24_203
; %bb.159:                              ; %v584_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.160:                              ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #3                          ; =0x3
	strb	w9, [x20, w8, uxtw]
	b	LBB24_135
LBB24_161:                              ; %b232.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	b.ne	LBB24_171
LBB24_162:                              ; %b229.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB24_203
LBB24_163:                              ; %v542_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	str	w8, [x0, #120]
	b	LBB24_135
LBB24_164:                              ; %b253.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #58
	b.ne	LBB24_195
; %bb.165:                              ; %b257.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	subs	w8, w8, #1
	b.lo	LBB24_203
; %bb.166:                              ; %v612_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.167:                              ; %v613_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w24, [x20, w8, uxtw]
	b	LBB24_135
LBB24_168:                              ; %b250.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cbnz	w10, LBB24_203
; %bb.169:                              ; %v592_ok.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.170:                              ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #8                          ; =0x8
	strb	w9, [x20, w8, uxtw]
	b	LBB24_135
LBB24_171:                              ; %b232.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w9, #2
	b.eq	LBB24_195
LBB24_172:                              ; %b259.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cbnz	w8, LBB24_174
; %bb.173:                              ; %b268.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	ldrb	w9, [x0, #124]
	cmp	w9, #1
	b.eq	LBB24_202
LBB24_174:                              ; %b273.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #90
	b.gt	LBB24_178
; %bb.175:                              ; %b273.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #34
	b.eq	LBB24_186
; %bb.176:                              ; %b273.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #45
	b.ne	LBB24_184
; %bb.177:                              ; %b289.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	mov	w8, #10                         ; =0xa
	str	w8, [x0, #128]
	b	LBB24_135
LBB24_178:                              ; %b273.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #123
	b.eq	LBB24_180
; %bb.179:                              ; %b273.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #91
	b.ne	LBB24_184
LBB24_180:                              ; %b277.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #64
	b.eq	LBB24_201
; %bb.181:                              ; %b281.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	str	x1, [sp, #8]                    ; 8-byte Folded Spill
	mov	x19, x0
	bl	_liza___liza_json_mut_done
	ldr	w8, [x19, #120]
	mov	x0, x19
	cmp	w23, #91
	b.ne	LBB24_187
; %bb.182:                              ; %b282.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.183:                              ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #1                          ; =0x1
	b	LBB24_189
LBB24_184:                              ; %b291.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w23, #48
	cmp	w8, #9
	b.hi	LBB24_190
LBB24_185:                              ; %b143.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #48
	mov	w8, #11                         ; =0xb
	cinc	w8, w8, ne
	str	w8, [x0, #128]
	b	LBB24_135
LBB24_186:                              ; %b286.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	wzr, [x0, #132]
	str	w28, [x0, #128]
	b	LBB24_135
LBB24_187:                              ; %b283.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w8, #64
	b.hs	LBB24_203
; %bb.188:                              ;   in Loop: Header=BB24_3 Depth=1
	mov	w9, #4                          ; =0x4
LBB24_189:                              ; %b284.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	strb	w9, [x20, x8]
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	mov	x5, #8193                       ; =0x2001
	ldr	w8, [x0, #120]
	mov	w16, #-96                       ; =0xffffffa0
	mov	w17, #-97                       ; =0xffffff9f
	mov	w2, #-112                       ; =0xffffff90
	mov	w3, #-113                       ; =0xffffff8f
	mov	w4, #7                          ; =0x7
	movk	x5, #1024, lsl #48
	mov	w6, #3                          ; =0x3
	mov	w7, #55296                      ; =0xd800
	mov	w19, #4                         ; =0x4
	mov	w30, #56320                     ; =0xdc00
	adds	w8, w8, #1
	b.lo	LBB24_163
	b	LBB24_203
LBB24_190:                              ; %b297.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	sub	w8, w23, #102
	cmp	w8, #14
	b.hi	LBB24_195
; %bb.191:                              ; %b297.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	lsl	w8, w28, w8
	mov	w9, #16641                      ; =0x4101
	tst	w8, w9
	b.eq	LBB24_195
; %bb.192:                              ; %b304.i.i
                                        ;   in Loop: Header=BB24_3 Depth=1
	cmp	w23, #102
	mov	w8, #20                         ; =0x14
	str	w8, [x0, #128]
	cinc	w8, w26, ne
	cmp	w23, #116
	csinc	w8, w8, wzr, ne
	stp	w8, w28, [x0, #136]
	b	LBB24_135
LBB24_193:                              ; %b9.i
	cmp	w9, #0
	mov	w9, #8                          ; =0x8
	mov	w10, #5                         ; =0x5
	csel	w9, w10, w9, eq
	b	LBB24_199
LBB24_194:                              ; %b48.i16.i
	ldr	x8, [x0, #160]
	mov	w9, #4                          ; =0x4
	b	LBB24_199
LBB24_195:                              ; %b3.i32.i
	ldr	x8, [x0, #48]
	mov	w9, #1                          ; =0x1
	b	LBB24_199
LBB24_196:                              ; %b44.i.i
	ldr	x8, [x0, #48]
	mov	w9, #3                          ; =0x3
	b	LBB24_199
LBB24_197:                              ; %b86.i.i
	ldr	x8, [x0, #152]
	mov	w9, #4                          ; =0x4
	b	LBB24_199
LBB24_198:                              ; %b140.i.i
	ldr	x8, [x0, #48]
	mov	w9, #2                          ; =0x2
LBB24_199:                              ; %common.ret.sink.split.i
	str	w9, [x0, #168]
	str	x8, [x0, #176]
LBB24_200:                              ; %liza_json.feed_mut.exit
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB24_201:                              ; %b279.i.i
	ldr	x8, [x0, #48]
	mov	w9, #7                          ; =0x7
	b	LBB24_199
LBB24_202:                              ; %b271.i.i
	ldr	x8, [x0, #48]
	b	LBB24_199
LBB24_203:                              ; %v145_trap.i.i
	brk	#0x1
                                        ; -- End function
	.globl	_stream_status                  ; -- Begin function stream_status
	.p2align	2
_stream_status:                         ; @stream_status
; %bb.0:
	ldr	w8, [x0, #168]
	cbz	w8, LBB25_8
; %bb.1:                                ; %b3.i.i.i
	cmp	w8, #2
	mov	w11, #2                         ; =0x2
	mov	w9, wzr
	cset	w10, eq
	cmp	w8, #3
	csel	w10, w11, w10, eq
	cmp	w8, #4
	mov	w11, #3                         ; =0x3
	csel	w10, w11, w10, eq
	cmp	w8, #5
	mov	w11, #4                         ; =0x4
	csel	w10, w11, w10, eq
	cmp	w8, #6
	mov	w11, #5                         ; =0x5
	csel	w10, w11, w10, eq
	cmp	w8, #7
	mov	w11, #6                         ; =0x6
	csel	w10, w11, w10, eq
	cmp	w8, #8
	mov	w8, #7                          ; =0x7
	csel	w8, w8, w10, eq
	cbz	w9, LBB25_9
LBB25_2:                                ; %b4.i.i
	ldr	w8, [x0, #32]
	cmp	w8, #2
	b.eq	LBB25_5
; %bb.3:                                ; %b4.i.i
	cmp	w8, #1
	b.eq	LBB25_6
; %bb.4:                                ; %b6.i.i.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB25_6
LBB25_5:                                ; %b7.i.i.i
	mov	w8, #1                          ; =0x1
LBB25_6:                                ; %liza_utf8_stream.finish.exit.i.i
	cbz	w8, LBB25_10
; %bb.7:                                ; %b7.i.i
	mov	w8, #4                          ; =0x4
	mov	w9, #1                          ; =0x1
	b	LBB25_22
LBB25_8:
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB25_2
LBB25_9:                                ; %b2.i.i
	mov	w9, #1                          ; =0x1
	b	LBB25_22
LBB25_10:                               ; %b6.i.i
	ldr	w8, [x0, #128]
	cmp	w8, #17
	b.hi	LBB25_16
; %bb.11:                               ; %b6.i.i
	mov	w9, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w9, w9, w8
	movk	w10, #2, lsl #16
	tst	w9, w10
	b.eq	LBB25_16
; %bb.12:                               ; %b18.i.i
	ldr	w8, [x0, #120]
	cbz	w8, LBB25_15
; %bb.13:                               ; %b2.i.i.i
	sub	w8, w8, #65
	cmn	w8, #65
	b.ls	LBB25_23
LBB25_14:                               ; %b36.i.i
	mov	w8, #5                          ; =0x5
	mov	w9, #1                          ; =0x1
	b	LBB25_22
LBB25_15:                               ; %b1.i21.i.i
	sub	sp, sp, #16
	mov	w9, wzr
	mov	w10, #1                         ; =0x1
	strb	w10, [sp, #12]
	add	sp, sp, #16
	cbz	w8, LBB25_19
	b	LBB25_14
LBB25_16:                               ; %b20.i.i
	sub	w9, w8, #4
	cmp	w9, #2
	b.hi	LBB25_18
; %bb.17:                               ; %b27.i.i
	mov	w8, #3                          ; =0x3
	mov	w9, #1                          ; =0x1
	b	LBB25_22
LBB25_18:
	ldr	w9, [x0, #120]
	ldrb	w10, [x0, #124]
	cbnz	w8, LBB25_14
LBB25_19:                               ; %b29.i.i
	cbnz	w9, LBB25_14
; %bb.20:                               ; %b29.i.i
	tbz	w10, #0, LBB25_14
; %bb.21:                               ; %b38.i.i
	mov	w9, wzr
	mov	w8, wzr
LBB25_22:                               ; %liza_json.finish.exit.i
	cmp	w9, #0
	csinc	w0, wzr, w8, eq
	ret
LBB25_23:                               ; %v10_trap.i.i.i
	brk	#0x1
                                        ; -- End function
	.globl	_stream_pending                 ; -- Begin function stream_pending
	.p2align	2
_stream_pending:                        ; @stream_pending
; %bb.0:
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_stream_value                   ; -- Begin function stream_value
	.p2align	2
_stream_value:                          ; @stream_value
; %bb.0:
	ldr	w8, [x0, #168]
	cbz	w8, LBB27_2
; %bb.1:                                ; %b3.i.i.i
	ldr	x8, [x0, #176]
	mov	w9, wzr
	cbnz	w9, LBB27_3
	b	LBB27_22
LBB27_2:
	mov	x8, xzr
	mov	w9, #1                          ; =0x1
	cbz	w9, LBB27_22
LBB27_3:                                ; %b4.i.i
	ldr	w9, [x0, #32]
	ldr	x8, [x0, #40]
	cmp	w9, #2
	b.eq	LBB27_7
; %bb.4:                                ; %b4.i.i
	cmp	w9, #1
	b.eq	LBB27_8
; %bb.5:                                ; %b6.i.i.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB27_14
; %bb.6:                                ; %b7.i.i.i
	ldr	x8, [x0, #16]
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB27_22
	b	LBB27_9
LBB27_7:                                ; %b4.i.i.i
	mov	w9, #1                          ; =0x1
LBB27_8:                                ; %liza_utf8_stream.finish.exit.i.i
	cbnz	w9, LBB27_22
LBB27_9:                                ; %b6.i.i
	ldr	w9, [x0, #128]
	cmp	w9, #17
	b.hi	LBB27_16
; %bb.10:                               ; %b6.i.i
	mov	w8, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w8, w8, w9
	movk	w10, #2, lsl #16
	tst	w8, w10
	b.eq	LBB27_16
; %bb.11:                               ; %b18.i.i
	ldr	w9, [x0, #120]
	ldr	x8, [x0, #48]
	cbz	w9, LBB27_15
; %bb.12:                               ; %b2.i.i.i
	sub	w9, w9, #65
	cmn	w9, #65
	b.hi	LBB27_22
; %bb.13:                               ; %v10_trap.i.i.i
	brk	#0x1
LBB27_14:                               ; %b9.i.i.i
	mov	w9, wzr
	mov	x8, xzr
	cbnz	w9, LBB27_22
	b	LBB27_9
LBB27_15:                               ; %b1.i21.i.i
	sub	sp, sp, #16
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	strb	w11, [sp, #12]
	add	sp, sp, #16
	cbz	w9, LBB27_19
	b	LBB27_22
LBB27_16:                               ; %b20.i.i
	sub	w8, w9, #4
	cmp	w8, #2
	b.hi	LBB27_18
; %bb.17:                               ; %b27.i.i
	ldr	x8, [x0, #160]
	b	LBB27_22
LBB27_18:
	ldr	x8, [x0, #48]
	ldr	w10, [x0, #120]
	ldrb	w11, [x0, #124]
	cbnz	w9, LBB27_22
LBB27_19:                               ; %b29.i.i
	cbnz	w10, LBB27_22
; %bb.20:                               ; %b29.i.i
	tbz	w11, #0, LBB27_22
; %bb.21:                               ; %b38.i.i
	mov	w10, wzr
	mov	x9, x8
	mov	x8, xzr
	b	LBB27_23
LBB27_22:                               ; %b2.i.i
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
LBB27_23:                               ; %liza_value.exit
	cmp	w10, #0
	csel	x0, x9, x8, eq
	ret
                                        ; -- End function
	.globl	_stream_size                    ; -- Begin function stream_size
	.p2align	2
_stream_size:                           ; @stream_size
; %bb.0:
	mov	w0, #184                        ; =0xb8
	ret
                                        ; -- End function
.subsections_via_symbols
