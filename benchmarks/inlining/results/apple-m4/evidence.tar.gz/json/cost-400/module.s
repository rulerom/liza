	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_status                    ; -- Begin function liza_status
	.p2align	2
_liza_status:                           ; @liza_status
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cbz	w8, LBB0_2
; %bb.1:                                ; %b3.i.i
	cmp	w8, #2
	mov	w11, #2                         ; =0x2
	mov	w9, wzr
	cset	w10, eq
	cmp	w8, #3
	csel	w10, w11, w10, eq
	cmp	w8, #4
	mov	w11, #3                         ; =0x3
	csel	w10, w11, w10, eq
	cmp	w8, #5
	mov	w11, #4                         ; =0x4
	csel	w10, w11, w10, eq
	cmp	w8, #6
	mov	w11, #5                         ; =0x5
	csel	w10, w11, w10, eq
	cmp	w8, #7
	mov	w11, #6                         ; =0x6
	csel	w10, w11, w10, eq
	cmp	w8, #8
	mov	w8, #7                          ; =0x7
	csel	w8, w8, w10, eq
	cbnz	w9, LBB0_3
	b	LBB0_19
LBB0_2:
	mov	w9, #1                          ; =0x1
	cbz	w9, LBB0_19
LBB0_3:                                 ; %b4.i
	ldr	w8, [x0, #32]
	cmp	w8, #2
	b.eq	LBB0_6
; %bb.4:                                ; %b4.i
	cmp	w8, #1
	b.eq	LBB0_7
; %bb.5:                                ; %b6.i.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB0_7
LBB0_6:                                 ; %b7.i.i
	mov	w8, #1                          ; =0x1
LBB0_7:                                 ; %liza_utf8_stream.finish.exit.i
	cbz	w8, LBB0_9
; %bb.8:                                ; %b7.i
	mov	w8, #4                          ; =0x4
	b	LBB0_19
LBB0_9:                                 ; %b6.i
	ldr	w8, [x0, #128]
	cmp	w8, #17
	b.hi	LBB0_21
; %bb.10:                               ; %b6.i
	mov	w9, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w9, w9, w8
	movk	w10, #2, lsl #16
	tst	w9, w10
	b.eq	LBB0_21
; %bb.11:                               ; %b18.i
	sub	sp, sp, #208
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x8, [x0, #176]
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	str	q2, [sp, #160]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #64]
	str	x8, [sp, #176]
	mov	x8, sp
	str	wzr, [sp, #128]
	stp	q0, q1, [sp, #64]
	ldp	q2, q0, [x0, #96]
	stp	q2, q0, [sp, #96]
	ldp	q1, q0, [x0]
	stp	q1, q0, [sp]
	ldp	q2, q0, [x0, #32]
	stp	q2, q0, [sp, #32]
	bl	_liza___liza_owned___liza_json_done
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldr	w10, [sp, #120]
	ldrb	w9, [sp, #124]
	ldr	w8, [sp, #128]
	add	sp, sp, #208
LBB0_12:                                ; %b20.i
	sub	w11, w8, #4
	cmp	w11, #2
	b.hi	LBB0_14
; %bb.13:                               ; %b27.i
	mov	w8, #3                          ; =0x3
	b	LBB0_19
LBB0_14:                                ; %b29.i
	cbnz	w8, LBB0_18
; %bb.15:                               ; %b29.i
	cbnz	w10, LBB0_18
; %bb.16:                               ; %b29.i
	tbz	w9, #0, LBB0_18
; %bb.17:                               ; %b38.i
	mov	w9, wzr
	mov	w8, wzr
	b	LBB0_20
LBB0_18:                                ; %b36.i
	mov	w8, #5                          ; =0x5
LBB0_19:                                ; %liza_json.finish.exit
	mov	w9, #1                          ; =0x1
LBB0_20:                                ; %liza_json.finish.exit
	cmp	w9, #0
	csinc	w0, wzr, w8, eq
	ret
LBB0_21:                                ; %b19_to_b20.i
	ldr	w10, [x0, #120]
	ldrb	w9, [x0, #124]
	b	LBB0_12
                                        ; -- End function
	.globl	_liza_value                     ; -- Begin function liza_value
	.p2align	2
_liza_value:                            ; @liza_value
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cbz	w8, LBB1_2
; %bb.1:                                ; %b3.i.i
	ldr	x8, [x0, #176]
	mov	w9, wzr
	cbnz	w9, LBB1_3
	b	LBB1_9
LBB1_2:
	mov	x8, xzr
	mov	w9, #1                          ; =0x1
	cbz	w9, LBB1_9
LBB1_3:                                 ; %b4.i
	ldr	w9, [x0, #32]
	ldr	x8, [x0, #40]
	cmp	w9, #2
	b.eq	LBB1_7
; %bb.4:                                ; %b4.i
	cmp	w9, #1
	b.eq	LBB1_8
; %bb.5:                                ; %b6.i.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB1_11
; %bb.6:                                ; %b7.i.i
	ldr	x8, [x0, #16]
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB1_9
	b	LBB1_12
LBB1_7:                                 ; %b4.i.i
	mov	w9, #1                          ; =0x1
LBB1_8:                                 ; %liza_utf8_stream.finish.exit.i
	cbz	w9, LBB1_12
LBB1_9:                                 ; %b2.i
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
LBB1_10:                                ; %liza_json.finish.exit
	cmp	w10, #0
	csel	x0, x9, x8, eq
	ret
LBB1_11:                                ; %b9.i.i
	mov	w9, wzr
	mov	x8, xzr
	cbnz	w9, LBB1_9
LBB1_12:                                ; %b6.i
	ldr	w9, [x0, #128]
	cmp	w9, #17
	b.hi	LBB1_21
; %bb.13:                               ; %b6.i
	mov	w8, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w8, w8, w9
	movk	w10, #2, lsl #16
	tst	w8, w10
	b.eq	LBB1_21
; %bb.14:                               ; %b18.i
	sub	sp, sp, #208
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x8, [x0, #176]
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	str	q2, [sp, #160]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #64]
	str	x8, [sp, #176]
	mov	x8, sp
	str	wzr, [sp, #128]
	stp	q0, q1, [sp, #64]
	ldp	q2, q0, [x0, #96]
	stp	q2, q0, [sp, #96]
	ldp	q1, q0, [x0]
	stp	q1, q0, [sp]
	ldp	q2, q0, [x0, #32]
	stp	q2, q0, [sp, #32]
	bl	_liza___liza_owned___liza_json_done
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldr	x8, [sp, #48]
	ldr	w11, [sp, #120]
	ldrb	w10, [sp, #124]
	ldr	w9, [sp, #128]
	ldr	x12, [sp, #160]
	add	sp, sp, #208
LBB1_15:                                ; %b20.i
	sub	w13, w9, #4
	cmp	w13, #2
	b.hi	LBB1_17
; %bb.16:                               ; %b27.i
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
	mov	x8, x12
	b	LBB1_10
LBB1_17:                                ; %b29.i
	cbnz	w9, LBB1_9
; %bb.18:                               ; %b29.i
	cbnz	w11, LBB1_9
; %bb.19:                               ; %b29.i
	tbz	w10, #0, LBB1_9
; %bb.20:                               ; %b38.i
	mov	w10, wzr
	mov	x9, x8
	mov	x8, xzr
	b	LBB1_10
LBB1_21:                                ; %b19_to_b20.i
	ldr	x8, [x0, #48]
	ldr	w11, [x0, #120]
	ldrb	w10, [x0, #124]
	ldr	x12, [x0, #160]
	b	LBB1_15
                                        ; -- End function
	.globl	_liza_pending                   ; -- Begin function liza_pending
	.p2align	2
_liza_pending:                          ; @liza_pending
; %bb.0:                                ; %b0
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_liza_start                     ; -- Begin function liza_start
	.p2align	2
_liza_start:                            ; @liza_start
; %bb.0:                                ; %b0
	sub	sp, sp, #144
	movi.2d	v0, #0000000000000000
	str	wzr, [sp, #132]
	mov	w9, #49024                      ; =0xbf80
	strh	w9, [x8, #28]
	stur	wzr, [sp, #44]
	strb	wzr, [sp, #140]
	stur	q0, [sp, #68]
	stur	q0, [sp, #84]
	stur	q0, [sp, #100]
	stur	q0, [sp, #52]
	stur	q0, [sp, #116]
	stur	q0, [sp, #12]
	ldr	x9, [sp, #128]
	stur	q0, [sp, #28]
	ldp	q0, q1, [sp, #80]
	stur	x9, [x8, #116]
	ldur	x9, [sp, #40]
	strb	wzr, [sp, #136]
	stur	q0, [x8, #68]
	ldr	q0, [sp, #112]
	stur	q1, [x8, #84]
	stur	q0, [x8, #100]
	ldp	q0, q1, [sp, #48]
	stp	xzr, xzr, [x8]
	str	wzr, [x8, #24]
	stur	q0, [x8, #36]
	ldur	q0, [sp, #25]
	stur	q1, [x8, #52]
	ldur	q1, [sp, #9]
	str	xzr, [x8, #16]
	str	wzr, [x8, #32]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	stur	x9, [x8, #164]
	stur	q0, [x8, #149]
	stur	q1, [x8, #133]
	str	xzr, [x8, #176]
	add	sp, sp, #144
	ret
                                        ; -- End function
	.globl	_liza_feed                      ; -- Begin function liza_feed
	.p2align	2
_liza_feed:                             ; @liza_feed
; %bb.0:                                ; %b0
	b	_liza_json.feed_mut
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
; %bb.0:                                ; %b0
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.create        ; -- Begin function liza_utf8_stream.create
	.p2align	2
_liza_utf8_stream.create:               ; @liza_utf8_stream.create
; %bb.0:                                ; %b0
	mov	x0, xzr
	mov	x1, xzr
	mov	x2, xzr
	mov	w3, wzr
	mov	w4, #128                        ; =0x80
	mov	w5, #191                        ; =0xbf
	mov	w6, wzr
	mov	x7, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.feed_byte     ; -- Begin function liza_utf8_stream.feed_byte
	.p2align	2
_liza_utf8_stream.feed_byte:            ; @liza_utf8_stream.feed_byte
; %bb.0:                                ; %b0
	cbz	w6, LBB7_2
LBB7_1:                                 ; %common.ret
	ret
LBB7_2:                                 ; %b3
	cmn	x0, #1
	b.eq	LBB7_9
; %bb.3:                                ; %b6
	ldrb	w8, [sp]
	cbz	w3, LBB7_10
; %bb.4:                                ; %b8
	and	w8, w8, #0xff
	cmp	w8, w4, uxtb
	b.lo	LBB7_13
; %bb.5:                                ; %b8
	cmp	w8, w5, uxtb
	b.hi	LBB7_13
; %bb.6:                                ; %v115_ok
	subs	w3, w3, #1
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	b.ne	LBB7_24
; %bb.7:                                ; %b51
	cmn	x1, #1
	b.eq	LBB7_20
; %bb.8:                                ; %v138_ok
	add	x1, x1, #1
	b	LBB7_24
LBB7_9:                                 ; %b4
	mov	x7, #-1                         ; =0xffffffffffffffff
	mov	w6, #2                          ; =0x2
	ret
LBB7_10:                                ; %b7
	tbnz	w8, #7, LBB7_14
; %bb.11:                               ; %b9
	cmn	x1, #1
	b.eq	LBB7_16
; %bb.12:                               ; %v32_ok
	add	x1, x1, #1
	mov	x2, x0
	b	LBB7_24
LBB7_13:                                ; %b48
	mov	w6, #1                          ; =0x1
	mov	x7, x2
	ret
LBB7_14:                                ; %b10
	add	w9, w8, #62
	mov	w5, #191                        ; =0xbf
	mov	w4, #128                        ; =0x80
	and	w9, w9, #0xff
	cmp	w9, #30
	b.hs	LBB7_18
; %bb.15:                               ; %b17
	mov	w3, #1                          ; =0x1
	mov	x2, x0
	b	LBB7_24
LBB7_16:                                ; %b11
	mov	w6, #2                          ; =0x2
LBB7_17:                                ; %common.ret
	mov	x2, x0
	mov	x7, x0
	ret
LBB7_18:                                ; %b18
	and	w9, w8, #0xf0
	cmp	w9, #224
	b.ne	LBB7_21
; %bb.19:                               ; %b22
	and	w8, w8, #0xff
	mov	w9, #-96                        ; =0xffffffa0
	mov	w3, #2                          ; =0x2
	cmp	w8, #224
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #237
	mov	w8, #-97                        ; =0xffffff9f
	b	LBB7_23
LBB7_20:                                ; %b53
	mov	w6, #2                          ; =0x2
	mov	x7, x0
	ret
LBB7_21:                                ; %b23
	add	w9, w8, #16
	and	w9, w9, #0xff
	cmp	w9, #4
	b.hi	LBB7_26
; %bb.22:                               ; %b33
	and	w8, w8, #0xff
	mov	w9, #-112                       ; =0xffffff90
	mov	w3, #3                          ; =0x3
	cmp	w8, #240
	mov	x2, x0
	csel	w4, w9, w4, eq
	cmp	w8, #244
	mov	w8, #-113                       ; =0xffffff8f
LBB7_23:                                ; %b57
	csel	w5, w8, w5, eq
LBB7_24:                                ; %b57
	adds	x0, x0, #1
	b.lo	LBB7_1
; %bb.25:                               ; %v145_trap
	brk	#0x1
LBB7_26:                                ; %b34
	mov	w6, #1                          ; =0x1
	b	LBB7_17
                                        ; -- End function
	.globl	_liza_utf8_stream.finish        ; -- Begin function liza_utf8_stream.finish
	.p2align	2
_liza_utf8_stream.finish:               ; @liza_utf8_stream.finish
; %bb.0:                                ; %b0
	cmp	w6, #1
	b.eq	LBB8_3
; %bb.1:                                ; %b0
	cmp	w6, #2
	b.ne	LBB8_4
; %bb.2:                                ; %b4
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_3:                                 ; %b1
	mov	x1, xzr
	b	LBB8_6
LBB8_4:                                 ; %b6
	cbz	w3, LBB8_7
; %bb.5:                                ; %b7
	mov	x1, xzr
	mov	x7, x2
LBB8_6:                                 ; %common.ret
	mov	w2, wzr
	mov	w0, #1                          ; =0x1
	mov	x3, x7
	ret
LBB8_7:                                 ; %b9
	mov	w0, wzr
	mov	w2, wzr
	mov	x3, xzr
	ret
                                        ; -- End function
	.globl	_liza_utf8_stream.status        ; -- Begin function liza_utf8_stream.status
	.p2align	2
_liza_utf8_stream.status:               ; @liza_utf8_stream.status
; %bb.0:                                ; %b0
	mov	w8, #1                          ; =0x1
	cmp	w6, #2
	mov	w9, #1                          ; =0x1
	csel	w8, wzr, w8, eq
	csel	w9, w9, wzr, eq
	csel	x10, x7, xzr, eq
	cmp	w6, #1
	csel	w0, wzr, w8, eq
	csel	w1, wzr, w9, eq
	csel	x2, x7, x10, eq
	ret
                                        ; -- End function
	.globl	_liza_json.create               ; -- Begin function liza_json.create
	.p2align	2
_liza_json.create:                      ; @liza_json.create
; %bb.0:                                ; %b0
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w9, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8]
	str	wzr, [x8, #24]
	strh	w9, [x8, #28]
	str	wzr, [x8, #32]
	stur	q0, [x8, #40]
	stur	q0, [x8, #56]
	stur	q0, [x8, #72]
	stur	q0, [x8, #88]
	stur	q0, [x8, #104]
	str	wzr, [x8, #120]
	strb	wzr, [x8, #124]
	str	wzr, [x8, #128]
	strb	wzr, [x8, #132]
	str	xzr, [x8, #176]
	str	wzr, [x8, #168]
	stur	q0, [x8, #152]
	stur	q0, [x8, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_liza___liza_json_done          ; -- Begin function liza___liza_json_done
	.p2align	2
_liza___liza_json_done:                 ; @liza___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #688
	ldr	w20, [x0, #120]
	add	x13, sp, #304
	cbz	w20, LBB11_5
; %bb.1:                                ; %b2
	ldrb	w9, [x0, #57]
	ldrb	w10, [x0, #59]
	sub	w21, w20, #1
	ldrb	w11, [x0, #61]
	ldrb	w23, [x0, #56]
	cmp	w21, #64
	stp	w10, w9, [sp, #168]             ; 8-byte Folded Spill
	ldrb	w22, [x0, #58]
	ldrb	w24, [x0, #98]
	strb	w9, [sp, #177]
	ldrb	w9, [x0, #60]
	ldrb	w25, [x0, #99]
	strb	w10, [sp, #179]
	ldrb	w10, [x0, #62]
	ldrb	w26, [x0, #100]
	stp	w11, w9, [sp, #160]             ; 8-byte Folded Spill
	ldrb	w27, [x0, #101]
	ldrb	w28, [x0, #102]
	strb	w9, [sp, #180]
	ldrb	w9, [x0, #63]
	ldrb	w30, [x0, #103]
	strb	w11, [sp, #181]
	ldrb	w11, [x0, #64]
	ldrb	w12, [x0, #107]
	stp	w9, w10, [sp, #152]             ; 8-byte Folded Spill
	ldrb	w13, [x0, #108]
	ldrb	w14, [x0, #109]
	strb	w10, [sp, #182]
	ldrb	w10, [x0, #65]
	ldrb	w15, [x0, #110]
	strb	w9, [sp, #183]
	ldrb	w9, [x0, #66]
	ldrb	w16, [x0, #111]
	stp	w10, w11, [sp, #144]            ; 8-byte Folded Spill
	ldrb	w17, [x0, #112]
	ldrb	w2, [x0, #113]
	strb	w11, [sp, #184]
	ldrb	w11, [x0, #67]
	ldrb	w3, [x0, #114]
	strb	w10, [sp, #185]
	ldrb	w10, [x0, #68]
	ldrb	w4, [x0, #115]
	stp	w11, w9, [sp, #136]             ; 8-byte Folded Spill
	ldrb	w5, [x0, #116]
	ldrb	w6, [x0, #117]
	strb	w9, [sp, #186]
	ldrb	w9, [x0, #69]
	ldrb	w7, [x0, #118]
	strb	w11, [sp, #187]
	ldrb	w11, [x0, #70]
	ldrb	w19, [x0, #119]
	stp	w9, w10, [sp, #128]             ; 8-byte Folded Spill
	strb	w10, [sp, #188]
	ldrb	w10, [x0, #71]
	strb	w9, [sp, #189]
	ldrb	w9, [x0, #72]
	stp	w10, w11, [sp, #120]            ; 8-byte Folded Spill
	strb	w11, [sp, #190]
	ldrb	w11, [x0, #73]
	strb	w10, [sp, #191]
	ldrb	w10, [x0, #74]
	stp	w11, w9, [sp, #112]             ; 8-byte Folded Spill
	strb	w9, [sp, #192]
	ldrb	w9, [x0, #75]
	strb	w11, [sp, #193]
	ldrb	w11, [x0, #76]
	stp	w9, w10, [sp, #104]             ; 8-byte Folded Spill
	strb	w10, [sp, #194]
	ldrb	w10, [x0, #77]
	strb	w9, [sp, #195]
	ldrb	w9, [x0, #78]
	stp	w10, w11, [sp, #96]             ; 8-byte Folded Spill
	strb	w11, [sp, #196]
	ldrb	w11, [x0, #79]
	strb	w10, [sp, #197]
	ldrb	w10, [x0, #80]
	stp	w11, w9, [sp, #88]              ; 8-byte Folded Spill
	strb	w9, [sp, #198]
	ldrb	w9, [x0, #81]
	strb	w11, [sp, #199]
	ldrb	w11, [x0, #82]
	stp	w9, w10, [sp, #80]              ; 8-byte Folded Spill
	strb	w10, [sp, #200]
	ldrb	w10, [x0, #83]
	strb	w9, [sp, #201]
	ldrb	w9, [x0, #84]
	stp	w10, w11, [sp, #72]             ; 8-byte Folded Spill
	strb	w11, [sp, #202]
	ldrb	w11, [x0, #85]
	strb	w10, [sp, #203]
	ldrb	w10, [x0, #87]
	stp	w11, w9, [sp, #64]              ; 8-byte Folded Spill
	strb	w9, [sp, #204]
	ldrb	w9, [x0, #86]
	strb	w10, [sp, #207]
	stp	w10, w9, [sp, #56]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #89]
	strb	w9, [sp, #206]
	ldrb	w9, [x0, #88]
	strb	w10, [sp, #209]
	stp	w10, w9, [sp, #48]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #91]
	strb	w9, [sp, #208]
	ldrb	w9, [x0, #90]
	strb	w10, [sp, #211]
	stp	w10, w9, [sp, #40]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #93]
	strb	w9, [sp, #210]
	ldrb	w9, [x0, #92]
	strb	w10, [sp, #213]
	stp	w10, w9, [sp, #32]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #95]
	strb	w9, [sp, #212]
	ldrb	w9, [x0, #94]
	strb	w10, [sp, #215]
	stp	w10, w9, [sp, #24]              ; 8-byte Folded Spill
	ldrb	w10, [x0, #97]
	strb	w9, [sp, #214]
	ldrb	w9, [x0, #96]
	strb	w11, [sp, #205]
	ldrb	w11, [x0, #106]
	stp	w10, w9, [sp, #16]              ; 8-byte Folded Spill
	strb	w9, [sp, #216]
	ldrb	w9, [x0, #104]
	strb	w10, [sp, #217]
	ldrb	w10, [x0, #105]
	strb	w23, [sp, #176]
	strb	w22, [sp, #178]
	strb	w24, [sp, #218]
	strb	w25, [sp, #219]
	strb	w26, [sp, #220]
	strb	w27, [sp, #221]
	strb	w28, [sp, #222]
	strb	w30, [sp, #223]
	strb	w9, [sp, #224]
	strb	w10, [sp, #225]
	strb	w11, [sp, #226]
	strb	w12, [sp, #227]
	strb	w13, [sp, #228]
	strb	w14, [sp, #229]
	strb	w15, [sp, #230]
	strb	w16, [sp, #231]
	strb	w17, [sp, #232]
	strb	w2, [sp, #233]
	strb	w3, [sp, #234]
	strb	w4, [sp, #235]
	strb	w5, [sp, #236]
	strb	w6, [sp, #237]
	strb	w7, [sp, #238]
	strb	w19, [sp, #239]
	b.hs	LBB11_7
; %bb.2:                                ; %v10_ok
	add	x1, sp, #176
	add	x20, sp, #620
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	mov	w1, #2                          ; =0x2
	b.eq	LBB11_4
; %bb.3:                                ; %b3
	strb	w23, [sp, #240]
	mov	w23, w22
	ldr	w22, [sp, #172]                 ; 4-byte Folded Reload
	strb	w23, [sp, #242]
	strb	w22, [sp, #241]
	ldr	w22, [sp, #168]                 ; 4-byte Folded Reload
	strb	w24, [sp, #282]
	strb	w22, [sp, #243]
	ldr	w22, [sp, #164]                 ; 4-byte Folded Reload
	strb	w25, [sp, #283]
	strb	w22, [sp, #244]
	ldr	w22, [sp, #160]                 ; 4-byte Folded Reload
	strb	w26, [sp, #284]
	strb	w22, [sp, #245]
	ldr	w22, [sp, #156]                 ; 4-byte Folded Reload
	strb	w27, [sp, #285]
	strb	w22, [sp, #246]
	ldr	w22, [sp, #152]                 ; 4-byte Folded Reload
	strb	w28, [sp, #286]
	strb	w22, [sp, #247]
	ldr	w22, [sp, #148]                 ; 4-byte Folded Reload
	strb	w30, [sp, #287]
	strb	w22, [sp, #248]
	ldr	w22, [sp, #144]                 ; 4-byte Folded Reload
	strb	w9, [sp, #288]
	add	x9, sp, #240
	strb	w22, [sp, #249]
	ldr	w22, [sp, #140]                 ; 4-byte Folded Reload
	strb	w10, [sp, #289]
	mov	w10, #7                         ; =0x7
	strb	w22, [sp, #250]
	ldr	w22, [sp, #136]                 ; 4-byte Folded Reload
	strb	w11, [sp, #290]
	strb	w22, [sp, #251]
	ldr	w22, [sp, #132]                 ; 4-byte Folded Reload
	strb	w12, [sp, #291]
	strb	w22, [sp, #252]
	ldr	w22, [sp, #128]                 ; 4-byte Folded Reload
	strb	w13, [sp, #292]
	strb	w22, [sp, #253]
	ldr	w22, [sp, #124]                 ; 4-byte Folded Reload
	strb	w14, [sp, #293]
	strb	w22, [sp, #254]
	ldr	w22, [sp, #120]                 ; 4-byte Folded Reload
	strb	w15, [sp, #294]
	strb	w22, [sp, #255]
	ldr	w22, [sp, #116]                 ; 4-byte Folded Reload
	strb	w16, [sp, #295]
	strb	w22, [sp, #256]
	ldr	w22, [sp, #112]                 ; 4-byte Folded Reload
	strb	w17, [sp, #296]
	strb	w22, [sp, #257]
	ldr	w22, [sp, #108]                 ; 4-byte Folded Reload
	strb	w2, [sp, #297]
	strb	w22, [sp, #258]
	ldr	w22, [sp, #104]                 ; 4-byte Folded Reload
	strb	w3, [sp, #298]
	strb	w22, [sp, #259]
	ldr	w22, [sp, #100]                 ; 4-byte Folded Reload
	strb	w4, [sp, #299]
	strb	w22, [sp, #260]
	ldr	w22, [sp, #96]                  ; 4-byte Folded Reload
	strb	w5, [sp, #300]
	strb	w22, [sp, #261]
	ldr	w22, [sp, #92]                  ; 4-byte Folded Reload
	strb	w6, [sp, #301]
	strb	w22, [sp, #262]
	ldr	w22, [sp, #88]                  ; 4-byte Folded Reload
	strb	w7, [sp, #302]
	strb	w22, [sp, #263]
	ldr	w22, [sp, #84]                  ; 4-byte Folded Reload
	strb	w19, [sp, #303]
	strb	w22, [sp, #264]
	ldr	w22, [sp, #80]                  ; 4-byte Folded Reload
	strb	w22, [sp, #265]
	ldr	w22, [sp, #76]                  ; 4-byte Folded Reload
	strb	w22, [sp, #266]
	ldr	w22, [sp, #72]                  ; 4-byte Folded Reload
	strb	w22, [sp, #267]
	ldr	w22, [sp, #68]                  ; 4-byte Folded Reload
	strb	w22, [sp, #268]
	ldr	w22, [sp, #64]                  ; 4-byte Folded Reload
	strb	w22, [sp, #269]
	ldr	w22, [sp, #60]                  ; 4-byte Folded Reload
	strb	w22, [sp, #270]
	ldr	w22, [sp, #56]                  ; 4-byte Folded Reload
	strb	w22, [sp, #271]
	ldr	w22, [sp, #52]                  ; 4-byte Folded Reload
	strb	w22, [sp, #272]
	ldr	w22, [sp, #48]                  ; 4-byte Folded Reload
	strb	w22, [sp, #273]
	ldr	w22, [sp, #44]                  ; 4-byte Folded Reload
	strb	w22, [sp, #274]
	ldr	w22, [sp, #40]                  ; 4-byte Folded Reload
	strb	w22, [sp, #275]
	ldr	w22, [sp, #36]                  ; 4-byte Folded Reload
	strb	w22, [sp, #276]
	ldr	w22, [sp, #32]                  ; 4-byte Folded Reload
	strb	w22, [sp, #277]
	ldr	w22, [sp, #28]                  ; 4-byte Folded Reload
	strb	w22, [sp, #278]
	ldr	w22, [sp, #24]                  ; 4-byte Folded Reload
	strb	w22, [sp, #279]
	ldr	w22, [sp, #20]                  ; 4-byte Folded Reload
	strb	w22, [sp, #280]
	ldr	w22, [sp, #16]                  ; 4-byte Folded Reload
	strb	w22, [sp, #281]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	add	x9, sp, #556
	csel	x20, x20, x9, eq
	csel	w1, w1, w10, eq
LBB11_4:                                ; %b8_to_b9
	ldur	q0, [x0, #56]
	ldur	q1, [x0, #72]
	add	x13, sp, #304
	ldur	q2, [x0, #88]
	ldur	q3, [x0, #168]
	add	x11, sp, #432
	stp	q0, q1, [x20]
	ldur	q0, [x0, #104]
	ldr	x9, [x0, #48]
	stur	q3, [x13, #171]
	ldur	q4, [x0, #157]
	ldur	q5, [x0, #141]
	stp	q2, q0, [x20, #32]
	ldr	q2, [x0]
	ldur	q6, [x0, #125]
	strb	w1, [x20, x21]
	ldrb	w10, [x0, #124]
	str	q2, [sp, #496]
	ldp	q1, q0, [x0, #16]
	str	x9, [sp, #544]
	ldr	w9, [x0, #120]
	add	x0, sp, #496
	stp	q5, q4, [sp, #448]
	ldp	q2, q3, [x20, #32]
	stp	q1, q0, [sp, #512]
	ldp	q0, q1, [x20]
	str	q6, [sp, #432]
	b	LBB11_6
LBB11_5:                                ; %b1
	ldur	q0, [x0, #56]
	ldur	q1, [x0, #72]
	mov	w10, #1                         ; =0x1
	ldur	q2, [x0, #88]
	ldur	q3, [x0, #104]
	mov	w9, wzr
	add	x11, x0, #125
	strb	w10, [sp, #684]
LBB11_6:                                ; %b9
	ldp	q6, q7, [x11]
	ldr	q16, [x0, #32]
	ldp	q4, q5, [x0]
	ldr	x12, [x0, #48]
	str	q16, [sp, #400]
	stp	q6, q7, [sp, #304]
	ldr	q6, [x11, #32]
	stp	q4, q5, [sp, #368]
	str	q6, [sp, #336]
	ldur	q6, [x11, #43]
	stur	q0, [x8, #56]
	stur	q6, [x13, #43]
	ldur	q0, [x13, #43]
	stur	q1, [x8, #72]
	str	x12, [sp, #416]
	stur	q0, [x8, #168]
	ldp	q0, q1, [sp, #320]
	stp	q4, q5, [x8]
	str	q16, [x8, #32]
	stur	q1, [x8, #157]
	ldr	q1, [sp, #304]
	str	x12, [x8, #48]
	stur	q2, [x8, #88]
	stur	q3, [x8, #104]
	str	w9, [x8, #120]
	strb	w10, [x8, #124]
	stur	q0, [x8, #141]
	stur	q1, [x8, #125]
	add	sp, sp, #688
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB11_7:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_json_space         ; -- Begin function liza___liza_json_space
	.p2align	2
_liza___liza_json_space:                ; @liza___liza_json_space
; %bb.0:                                ; %b0
	mov	x8, #9728                       ; =0x2600
                                        ; kill: def $w0 killed $w0 def $x0
	and	w9, w0, #0xff
	movk	x8, #1, lsl #32
	cmp	w9, #33
	lsr	x8, x8, x0
	cset	w9, lo
	and	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza___liza_json_digit         ; -- Begin function liza___liza_json_digit
	.p2align	2
_liza___liza_json_digit:                ; @liza___liza_json_digit
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w8, w8, #48
	cmp	w8, #10
	cset	w0, lo
	ret
                                        ; -- End function
	.globl	_liza___liza_json_hex           ; -- Begin function liza___liza_json_hex
	.p2align	2
_liza___liza_json_hex:                  ; @liza___liza_json_hex
; %bb.0:                                ; %b0
	and	w8, w0, #0xff
	sub	w0, w8, #48
	cmp	w0, #9
	b.hi	LBB14_2
; %bb.1:                                ; %common.ret
	ret
LBB14_2:                                ; %b6
	sub	w9, w8, #65
	cmp	w9, #5
	b.hi	LBB14_4
; %bb.3:                                ; %v15_ok
	sub	w0, w8, #55
	ret
LBB14_4:                                ; %b12
	sub	w9, w8, #97
	cmp	w9, #5
	b.hi	LBB14_6
; %bb.5:                                ; %v24_ok
	sub	w0, w8, #87
	ret
LBB14_6:
	mov	w0, #16                         ; =0x10
	ret
                                        ; -- End function
	.globl	_liza_json.status               ; -- Begin function liza_json.status
	.p2align	2
_liza_json.status:                      ; @liza_json.status
; %bb.0:                                ; %b0
	ldr	w9, [x0, #168]
	cbz	w9, LBB15_2
; %bb.1:                                ; %b3
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	mov	x8, x0
	cset	w11, eq
	cmp	w9, #3
	ldr	x2, [x8, #176]
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	mov	w0, wzr
	csel	w1, w9, w10, eq
	ret
LBB15_2:
	mov	w1, wzr
	mov	x2, xzr
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_json.finish               ; -- Begin function liza_json.finish
	.p2align	2
_liza_json.finish:                      ; @liza_json.finish
; %bb.0:                                ; %b0
	ldr	w9, [x0, #168]
	cbz	w9, LBB16_6
; %bb.1:                                ; %b3.i
	cmp	w9, #2
	mov	w10, #2                         ; =0x2
	ldr	x3, [x0, #176]
	cset	w11, eq
	cmp	w9, #3
	mov	w8, wzr
	csel	w10, w10, w11, eq
	mov	w11, #3                         ; =0x3
	cmp	w9, #4
	csel	w10, w11, w10, eq
	mov	w11, #4                         ; =0x4
	cmp	w9, #5
	csel	w10, w11, w10, eq
	mov	w11, #5                         ; =0x5
	cmp	w9, #6
	csel	w10, w11, w10, eq
	mov	w11, #6                         ; =0x6
	cmp	w9, #7
	csel	w10, w11, w10, eq
	cmp	w9, #8
	mov	w9, #7                          ; =0x7
	csel	w2, w9, w10, eq
	cbz	w8, LBB16_7
LBB16_2:                                ; %b4
	ldr	w8, [x0, #32]
	ldr	x3, [x0, #40]
	cmp	w8, #2
	b.eq	LBB16_8
; %bb.3:                                ; %b4
	cmp	w8, #1
	b.eq	LBB16_9
; %bb.4:                                ; %b6.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB16_11
; %bb.5:                                ; %b7.i
	ldr	x3, [x0, #16]
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB16_10
	b	LBB16_12
LBB16_6:
	mov	w2, wzr
	mov	x3, xzr
	mov	w8, #1                          ; =0x1
	cbnz	w8, LBB16_2
LBB16_7:                                ; %b2
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	ret
LBB16_8:                                ; %b4.i
	mov	w8, #1                          ; =0x1
LBB16_9:                                ; %liza_utf8_stream.finish.exit
	cbz	w8, LBB16_12
LBB16_10:                               ; %b7
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB16_11:                               ; %b9.i
	mov	x3, xzr
	cbnz	w8, LBB16_10
LBB16_12:                               ; %b6
	ldr	w8, [x0, #128]
	cmp	w8, #17
	b.hi	LBB16_22
; %bb.13:                               ; %b6
	mov	w9, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w9, w9, w8
	movk	w10, #2, lsl #16
	tst	w9, w10
	b.eq	LBB16_22
; %bb.14:                               ; %b18
	sub	sp, sp, #208
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x8, [x0, #176]
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	str	q2, [sp, #160]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #64]
	str	x8, [sp, #176]
	mov	x8, sp
	str	wzr, [sp, #128]
	stp	q0, q1, [sp, #64]
	ldp	q2, q0, [x0, #96]
	stp	q2, q0, [sp, #96]
	ldp	q1, q0, [x0]
	stp	q1, q0, [sp]
	ldp	q2, q0, [x0, #32]
	stp	q2, q0, [sp, #32]
	bl	_liza___liza_owned___liza_json_done
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldr	x3, [sp, #48]
	ldr	w10, [sp, #120]
	ldrb	w9, [sp, #124]
	ldr	w8, [sp, #128]
	ldr	x11, [sp, #160]
	add	sp, sp, #208
LBB16_15:                               ; %b20
	sub	w12, w8, #4
	cmp	w12, #2
	b.hi	LBB16_17
; %bb.16:                               ; %b27
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	mov	x3, x11
	ret
LBB16_17:                               ; %b29
	cbnz	w8, LBB16_21
; %bb.18:                               ; %b29
	cbnz	w10, LBB16_21
; %bb.19:                               ; %b29
	tbz	w9, #0, LBB16_21
; %bb.20:                               ; %b38
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ret
LBB16_21:                               ; %b36
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	mov	w0, #1                          ; =0x1
	ret
LBB16_22:                               ; %b19_to_b20
	ldr	x3, [x0, #48]
	ldr	w10, [x0, #120]
	ldrb	w9, [x0, #124]
	ldr	x11, [x0, #160]
	b	LBB16_15
                                        ; -- End function
	.globl	_liza___liza_json_mut_fail      ; -- Begin function liza___liza_json_mut_fail
	.p2align	2
_liza___liza_json_mut_fail:             ; @liza___liza_json_mut_fail
; %bb.0:                                ; %b0
	str	w0, [x2, #168]
	str	x1, [x2, #176]
	ret
                                        ; -- End function
	.globl	_liza___liza_json_mut_done      ; -- Begin function liza___liza_json_mut_done
	.p2align	2
_liza___liza_json_mut_done:             ; @liza___liza_json_mut_done
; %bb.0:                                ; %b0
	ldr	w8, [x0, #120]
	cbz	w8, LBB18_4
; %bb.1:                                ; %b2
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB18_7
; %bb.2:                                ; %v12_ok
	add	x9, x0, #56
	ldrb	w10, [x9, w8, uxtw]
	orr	w10, w10, #0x2
	cmp	w10, #3
	b.ne	LBB18_5
; %bb.3:                                ; %v24_ok
	mov	w10, #2                         ; =0x2
	b	LBB18_6
LBB18_4:                                ; %b1
	mov	w8, #1                          ; =0x1
	strb	w8, [x0, #124]
	ldr	w0, [x0, #168]
	ret
LBB18_5:                                ; %v28_ok
	mov	w10, #7                         ; =0x7
LBB18_6:                                ; %b9
	strb	w10, [x9, w8, uxtw]
	ldr	w0, [x0, #168]
	ret
LBB18_7:                                ; %v12_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_json_mut_step      ; -- Begin function liza___liza_json_mut_step
	.p2align	2
_liza___liza_json_mut_step:             ; @liza___liza_json_mut_step
; %bb.0:                                ; %b0
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	ldr	w8, [x1, #128]
	mov	w19, w0
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	cmp	w8, #3
	b.le	LBB19_7
; %bb.1:                                ; %b0
	cmp	w8, #5
	b.gt	LBB19_10
; %bb.2:                                ; %b0
	cmp	w8, #4
	b.eq	LBB19_32
; %bb.3:                                ; %b0
	cmp	w8, #5
	b.ne	LBB19_25
; %bb.4:                                ; %b52
	and	w8, w19, #0xff
	cmp	w8, #117
	b.ne	LBB19_47
; %bb.5:                                ; %b56
	mov	w8, #6                          ; =0x6
LBB19_6:                                ; %common.ret
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	str	xzr, [x1, #144]
	b	LBB19_163
LBB19_7:                                ; %b0
	cmp	w8, #1
	b.eq	LBB19_18
; %bb.8:                                ; %b0
	cmp	w8, #2
	b.eq	LBB19_36
; %bb.9:                                ; %b0
	cmp	w8, #3
	b.eq	LBB19_16
	b	LBB19_25
LBB19_10:                               ; %b0
	cmp	w8, #6
	b.eq	LBB19_16
; %bb.11:                               ; %b0
	cmp	w8, #20
	b.ne	LBB19_25
; %bb.12:                               ; %b91
	ldr	w8, [x1, #136]
	cmp	w8, #3
	b.eq	LBB19_68
; %bb.13:                               ; %b91
	cmp	w8, #2
	b.eq	LBB19_67
; %bb.14:                               ; %b91
	cmp	w8, #1
	b.ne	LBB19_69
; %bb.15:                               ; %b104.thread
	ldr	w8, [x1, #140]
	mov	w9, #114                        ; =0x72
	mov	w10, #117                       ; =0x75
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	b	LBB19_70
LBB19_16:                               ; %b61
	sub	w9, w19, #48
	and	w9, w9, #0xff
	cmp	w9, #10
	b.hs	LBB19_34
; %bb.17:
	mov	w9, #-48                        ; =0xffffffd0
	b	LBB19_42
LBB19_18:                               ; %b1
	and	w8, w19, #0xff
	cmp	w8, #32
	b.lo	LBB19_161
; %bb.19:                               ; %b5
	cmp	w8, #92
	b.eq	LBB19_77
; %bb.20:                               ; %b5
	cmp	w8, #34
	b.ne	LBB19_96
; %bb.21:                               ; %b6
	ldrb	w8, [x1, #132]
	str	wzr, [x1, #128]
	cmp	w8, #1
	b.ne	LBB19_84
; %bb.22:                               ; %b8
	ldr	w8, [x1, #120]
	subs	w8, w8, #1
	b.lo	LBB19_168
; %bb.23:                               ; %v23_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.24:                               ; %v24_ok
	add	x9, x1, #56
	mov	w10, #5                         ; =0x5
	b	LBB19_95
LBB19_25:                               ; %b132
	sub	w9, w8, #10
	cmp	w9, #7
	b.hi	LBB19_62
; %bb.26:                               ; %b136
	sub	w9, w19, #48
	and	w9, w9, #0xff
	cmp	w9, #9
	b.hi	LBB19_57
; %bb.27:                               ; %b138
	cmp	w8, #10
	b.eq	LBB19_93
; %bb.28:                               ; %b138
	cmp	w8, #13
	b.eq	LBB19_85
; %bb.29:                               ; %b138
	cmp	w8, #11
	b.eq	LBB19_140
; %bb.30:                               ; %b151
	sub	w8, w8, #15
	cmp	w8, #1
	b.hi	LBB19_96
; %bb.31:
	mov	w8, #17                         ; =0x11
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_32:                               ; %b46
	and	w8, w19, #0xff
	cmp	w8, #92
	b.ne	LBB19_47
; %bb.33:                               ; %b50
	mov	w8, #5                          ; =0x5
	b	LBB19_55
LBB19_34:                               ; %b6.i
	sub	w9, w19, #65
	and	w9, w9, #0xff
	cmp	w9, #6
	b.hs	LBB19_40
; %bb.35:
	mov	w9, #-55                        ; =0xffffffc9
	b	LBB19_42
LBB19_36:                               ; %b16
	and	w8, w19, #0xff
	sub	w9, w8, #98
	cmp	w9, #19
	b.hi	LBB19_52
; %bb.37:                               ; %b16
	mov	w10, #1                         ; =0x1
	mov	w11, #4113                      ; =0x1011
	lsl	w10, w10, w9
	movk	w11, #5, lsl #16
	tst	w10, w11
	b.ne	LBB19_54
; %bb.38:                               ; %b16
	cmp	w9, #19
	b.ne	LBB19_52
; %bb.39:                               ; %b42
	mov	w8, #3                          ; =0x3
	b	LBB19_6
LBB19_40:                               ; %b12.i
	sub	w9, w19, #97
	and	w9, w9, #0xff
	cmp	w9, #6
	b.hs	LBB19_56
; %bb.41:
	mov	w9, #-87                        ; =0xffffffa9
LBB19_42:                               ; %b65
	ldr	w10, [x1, #148]
	lsr	w11, w10, #28
	cbnz	w11, LBB19_168
; %bb.43:                               ; %v165_ok
	add	w9, w9, w19, uxtb
	ldr	w11, [x1, #144]
	add	w9, w9, w10, lsl #4
	adds	w10, w11, #1
	str	w9, [x1, #148]
	b.hs	LBB19_168
; %bb.44:                               ; %v171_ok
	cmp	w10, #4
	str	w10, [x1, #144]
	b.ne	LBB19_96
; %bb.45:                               ; %b66
	cmp	w8, #6
	b.ne	LBB19_49
; %bb.46:                               ; %b68
	sub	w8, w9, #14, lsl #12            ; =57344
	cmn	w8, #1025
	b.hi	LBB19_54
LBB19_47:                               ; %b48
	ldr	x8, [x1, #160]
LBB19_48:                               ; %common.ret
	mov	w0, #4                          ; =0x4
	b	LBB19_162
LBB19_49:                               ; %b76
	and	w8, w9, #0xfffffc00
	mov	w9, #56320                      ; =0xdc00
	cmp	w8, w9
	b.eq	LBB19_78
; %bb.50:                               ; %b76
	mov	w9, #55296                      ; =0xd800
	cmp	w8, w9
	b.ne	LBB19_79
; %bb.51:                               ; %b80
	ldr	x9, [x1, #152]
	mov	w8, #4                          ; =0x4
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	str	x9, [x1, #160]
	b	LBB19_163
LBB19_52:                               ; %b16
	sub	w8, w8, #34
	cmp	w8, #58
	b.hi	LBB19_56
; %bb.53:                               ; %b16
	mov	w9, #1                          ; =0x1
	lsl	x8, x9, x8
	mov	x9, #8193                       ; =0x2001
	movk	x9, #1024, lsl #48
	tst	x8, x9
	b.eq	LBB19_56
LBB19_54:                               ; %b39
	mov	w8, #1                          ; =0x1
LBB19_55:                               ; %common.ret
	ldr	w0, [x1, #168]
	str	w8, [x1, #128]
	b	LBB19_163
LBB19_56:                               ; %b44
	ldr	x8, [x1, #48]
	mov	w0, #3                          ; =0x3
	b	LBB19_162
LBB19_57:                               ; %b158
	cmp	w8, #11
	b.ne	LBB19_80
; %bb.58:                               ; %b162
	and	w8, w19, #0xff
	cmp	w8, #92
	b.gt	LBB19_105
; %bb.59:                               ; %b162
	sub	w8, w8, #9
	cmp	w8, #60
	b.hi	LBB19_140
; %bb.60:                               ; %b162
	mov	w9, #1                          ; =0x1
	mov	x10, #19                        ; =0x13
	lsl	x9, x9, x8
	movk	x10, #128, lsl #16
	movk	x10, #8, lsl #32
	tst	x9, x10
	b.eq	LBB19_112
LBB19_61:                               ; %b215
	mov	x0, x1
	str	wzr, [x1, #128]
	mov	x20, x1
	bl	_liza___liza_json_mut_done
	mov	x1, x20
LBB19_62:                               ; %b216
	and	w8, w19, #0xff
	cmp	w8, #32
	b.hi	LBB19_64
; %bb.63:                               ; %b216
	mov	w8, w19
	mov	w9, #1                          ; =0x1
	and	x8, x8, #0xff
	lsl	x8, x9, x8
	mov	x9, #9728                       ; =0x2600
	movk	x9, #1, lsl #32
	tst	x8, x9
	b.ne	LBB19_96
LBB19_64:                               ; %b219
	ldr	w8, [x1, #120]
	cbz	w8, LBB19_97
; %bb.65:                               ; %b220
	sub	w9, w8, #1
	cmp	w9, #64
	b.hs	LBB19_168
; %bb.66:                               ; %v525_ok
	add	x9, x1, w9, uxtw
	ldrb	w9, [x9, #56]
	b	LBB19_98
LBB19_67:                               ; %b105
	ldr	w8, [x1, #140]
	mov	w9, #97                         ; =0x61
	mov	w10, #108                       ; =0x6c
	cmp	w8, #1
	csel	w9, w9, wzr, eq
	cmp	w8, #2
	csel	w9, w10, w9, eq
	cmp	w8, #3
	mov	w10, #115                       ; =0x73
	csel	w9, w10, w9, eq
	cmp	w8, #4
	mov	w8, #101                        ; =0x65
	csel	w9, w8, w9, eq
	mov	w8, #5                          ; =0x5
	cmp	w9, w19, uxtb
	b.eq	LBB19_71
	b	LBB19_161
LBB19_68:                               ; %b120
	ldr	w8, [x1, #140]
	mov	w9, #117                        ; =0x75
	cmp	w8, #1
	mov	w8, #108                        ; =0x6c
	csel	w9, w9, w8, eq
	b	LBB19_70
LBB19_69:
	mov	w9, wzr
LBB19_70:                               ; %b125
	mov	w8, #4                          ; =0x4
	cmp	w9, w19, uxtb
	b.ne	LBB19_161
LBB19_71:                               ; %b128
	ldr	w9, [x1, #140]
	adds	w9, w9, #1
	b.hs	LBB19_168
; %bb.72:                               ; %v325_ok
	cmp	w9, w8
	str	w9, [x1, #140]
	b.ne	LBB19_96
; %bb.73:                               ; %b129
	ldr	w8, [x1, #120]
	str	wzr, [x1, #128]
	cbz	w8, LBB19_83
; %bb.74:                               ; %b2.i
	sub	w8, w8, #1
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.75:                               ; %v12_ok.i
	add	x9, x1, #56
	ldrb	w10, [x9, w8, uxtw]
	orr	w10, w10, #0x2
	cmp	w10, #3
	b.ne	LBB19_94
; %bb.76:                               ; %v24_ok.i28
	mov	w10, #2                         ; =0x2
	b	LBB19_95
LBB19_77:                               ; %b12
	ldr	x9, [x1, #48]
	mov	w8, #2                          ; =0x2
	str	w8, [x1, #128]
	str	x9, [x1, #152]
	b	LBB19_96
LBB19_78:                               ; %b86
	ldr	x8, [x1, #152]
	b	LBB19_48
LBB19_79:                               ; %b88
	mov	w8, #1                          ; =0x1
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_80:                               ; %b159
	cmp	w8, #12
	b.ne	LBB19_86
; %bb.81:                               ; %b159
	and	w9, w19, #0xff
	cmp	w9, #46
	b.ne	LBB19_86
LBB19_82:                               ; %b165
	mov	w8, #13                         ; =0xd
	b	LBB19_55
LBB19_83:                               ; %b1.i
	mov	w8, #1                          ; =0x1
	strb	w8, [x1, #124]
	b	LBB19_96
LBB19_84:                               ; %b10
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	mov	x0, x1
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_liza___liza_json_mut_done
LBB19_85:
	mov	w8, #14                         ; =0xe
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_86:                               ; %b167
	cmp	w8, #16
	b.hi	LBB19_141
; %bb.87:                               ; %b167
	mov	w9, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w9, w9, w8
	tst	w9, w10
	b.ne	LBB19_118
; %bb.88:                               ; %b167
	mov	w10, #9216                      ; =0x2400
	movk	w10, #1, lsl #16
	tst	w9, w10
	b.ne	LBB19_140
; %bb.89:                               ; %b167
	cmp	w8, #15
	b.ne	LBB19_141
; %bb.90:                               ; %b183
	and	w8, w19, #0xff
	cmp	w8, #45
	b.eq	LBB19_92
; %bb.91:                               ; %b183
	cmp	w8, #43
	b.ne	LBB19_140
LBB19_92:                               ; %b189
	mov	w8, #16                         ; =0x10
	b	LBB19_55
LBB19_93:                               ; %b143
	and	w8, w19, #0xff
	cmp	w8, #48
	mov	w8, #11                         ; =0xb
	cinc	w8, w8, ne
	str	w8, [x1, #128]
	b	LBB19_96
LBB19_94:                               ; %v28_ok.i
	mov	w10, #7                         ; =0x7
LBB19_95:                               ; %liza___liza_json_mut_done.exit
	strb	w10, [x9, w8, uxtw]
LBB19_96:                               ; %b131
	ldr	w0, [x1, #168]
	b	LBB19_163
LBB19_97:
	mov	w9, wzr
LBB19_98:                               ; %b222
	and	w10, w19, #0xff
	cmp	w10, #125
	b.eq	LBB19_108
; %bb.99:                               ; %b222
	cmp	w10, #93
	b.ne	LBB19_101
; %bb.100:                              ; %b223
	sub	w10, w9, #1
	cmp	w10, #1
	b.ls	LBB19_127
LBB19_101:                              ; %b240
	cmp	w9, #4
	b.le	LBB19_114
; %bb.102:                              ; %b240
	cmp	w9, #5
	b.eq	LBB19_135
; %bb.103:                              ; %b240
	cmp	w9, #8
	b.eq	LBB19_116
; %bb.104:                              ; %b240
	cmp	w9, #7
	b.eq	LBB19_120
	b	LBB19_129
LBB19_105:                              ; %b162
	cmp	w8, #93
	b.eq	LBB19_61
; %bb.106:                              ; %b162
	cmp	w8, #101
	b.eq	LBB19_119
LBB19_107:                              ; %b203
	cmp	w8, #125
	b.eq	LBB19_61
	b	LBB19_140
LBB19_108:                              ; %b232
	cmp	w9, #4
	b.le	LBB19_125
; %bb.109:                              ; %b232
	cmp	w9, #5
	b.eq	LBB19_161
; %bb.110:                              ; %b232
	cmp	w9, #8
	b.eq	LBB19_161
; %bb.111:                              ; %b232
	cmp	w9, #7
	b.eq	LBB19_127
	b	LBB19_129
LBB19_112:                              ; %b162
	cmp	x8, #37
	b.eq	LBB19_82
; %bb.113:                              ; %b162
	cmp	x8, #60
	b.eq	LBB19_119
	b	LBB19_140
LBB19_114:                              ; %b240
	cmp	w9, #2
	b.eq	LBB19_120
; %bb.115:                              ; %b240
	cmp	w9, #4
	b.ne	LBB19_129
LBB19_116:                              ; %b262
	and	w8, w19, #0xff
	cmp	w8, #34
	b.ne	LBB19_161
; %bb.117:                              ; %b266
	mov	w8, #1                          ; =0x1
	ldr	w0, [x1, #168]
	strb	w8, [x1, #132]
	str	w8, [x1, #128]
	b	LBB19_163
LBB19_118:                              ; %b174
	orr	w9, w19, #0x20
	and	w9, w9, #0xff
	cmp	w9, #101
	b.ne	LBB19_139
LBB19_119:                              ; %b180
	mov	w8, #15                         ; =0xf
	b	LBB19_55
LBB19_120:                              ; %b244
	and	w10, w19, #0xff
	cmp	w10, #44
	b.ne	LBB19_161
; %bb.121:                              ; %b248
	subs	w8, w8, #1
	cset	w10, lo
	cmp	w9, #2
	b.ne	LBB19_148
; %bb.122:                              ; %b249
	cbnz	w10, LBB19_168
; %bb.123:                              ; %v584_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.124:
	mov	w9, #3                          ; =0x3
	b	LBB19_151
LBB19_125:                              ; %b232
	cmp	w9, #2
	b.eq	LBB19_161
; %bb.126:                              ; %b232
	cmp	w9, #4
	b.ne	LBB19_129
LBB19_127:                              ; %b229
	subs	w8, w8, #1
	b.lo	LBB19_168
; %bb.128:                              ; %v542_ok
	ldr	w0, [x1, #168]
	str	w8, [x1, #120]
	b	LBB19_163
LBB19_129:                              ; %b259
	cbnz	w8, LBB19_131
; %bb.130:                              ; %b268
	ldrb	w9, [x1, #124]
	cmp	w9, #1
	b.eq	LBB19_161
LBB19_131:                              ; %b273
	and	w9, w19, #0xff
	cmp	w9, #90
	b.gt	LBB19_144
; %bb.132:                              ; %b273
	cmp	w9, #34
	b.eq	LBB19_157
; %bb.133:                              ; %b273
	cmp	w9, #45
	b.ne	LBB19_152
; %bb.134:                              ; %b289
	mov	w8, #10                         ; =0xa
	b	LBB19_55
LBB19_135:                              ; %b253
	and	w9, w19, #0xff
	cmp	w9, #58
	b.ne	LBB19_161
; %bb.136:                              ; %b257
	subs	w8, w8, #1
	b.lo	LBB19_168
; %bb.137:                              ; %v612_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.138:                              ; %v613_ok
	add	x9, x1, #56
	mov	w10, #6                         ; =0x6
	b	LBB19_95
LBB19_139:                              ; %b191
	cmp	w8, #13
	b.ne	LBB19_141
LBB19_140:                              ; %b140
	ldr	x8, [x1, #48]
	mov	w0, #2                          ; =0x2
	b	LBB19_162
LBB19_141:                              ; %b203
	and	w8, w19, #0xff
	cmp	w8, #44
	b.hi	LBB19_143
; %bb.142:                              ; %b203
	and	x9, x19, #0xff
	mov	w10, #1                         ; =0x1
	lsl	x9, x10, x9
	mov	x10, #9728                      ; =0x2600
	movk	x10, #4097, lsl #32
	tst	x9, x10
	b.ne	LBB19_61
LBB19_143:                              ; %b203
	cmp	w8, #93
	b.ne	LBB19_107
	b	LBB19_61
LBB19_144:                              ; %b273
	cmp	w9, #123
	b.eq	LBB19_146
; %bb.145:                              ; %b273
	cmp	w9, #91
	b.ne	LBB19_152
LBB19_146:                              ; %b277
	cmp	w8, #64
	b.ne	LBB19_154
; %bb.147:                              ; %b279
	ldr	x8, [x1, #48]
	mov	w0, #7                          ; =0x7
	b	LBB19_162
LBB19_148:                              ; %b250
	cbnz	w10, LBB19_168
; %bb.149:                              ; %v592_ok
	cmp	w8, #64
	b.hs	LBB19_168
; %bb.150:
	mov	w9, #8                          ; =0x8
LBB19_151:                              ; %b251
	add	x10, x1, #56
	strb	w9, [x10, w8, uxtw]
	b	LBB19_96
LBB19_152:                              ; %b291
	sub	w8, w19, #48
	and	w8, w8, #0xff
	cmp	w8, #9
	b.hi	LBB19_158
; %bb.153:                              ; %b292
	and	w8, w19, #0xff
	cmp	w8, #48
	mov	w8, #11                         ; =0xb
	cinc	w8, w8, ne
	b	LBB19_55
LBB19_154:                              ; %b281
	mov	x0, x1
	mov	x20, x1
	bl	_liza___liza_json_mut_done
	and	w10, w19, #0xff
	ldr	w9, [x20, #120]
	mov	x8, x20
	cmp	w10, #91
	b.ne	LBB19_164
; %bb.155:                              ; %b282
	cmp	w9, #64
	b.hs	LBB19_168
; %bb.156:
	mov	w10, #1                         ; =0x1
	b	LBB19_166
LBB19_157:                              ; %b286
	strb	wzr, [x1, #132]
	b	LBB19_54
LBB19_158:                              ; %b297
	and	w8, w19, #0xff
	sub	w9, w8, #102
	cmp	w9, #14
	b.hi	LBB19_161
; %bb.159:                              ; %b297
	mov	w8, #1                          ; =0x1
	mov	w10, #16641                     ; =0x4101
	lsl	w9, w8, w9
	tst	w9, w10
	b.eq	LBB19_161
; %bb.160:                              ; %b304
	and	w9, w19, #0xff
	mov	w10, #20                        ; =0x14
	mov	w11, #2                         ; =0x2
	cmp	w9, #102
	str	w10, [x1, #128]
	ldr	w0, [x1, #168]
	cinc	w10, w11, ne
	cmp	w9, #116
	csinc	w9, w10, wzr, ne
	stp	w9, w8, [x1, #136]
	b	LBB19_163
LBB19_161:                              ; %b3
	ldr	x8, [x1, #48]
	mov	w0, #1                          ; =0x1
LBB19_162:                              ; %common.ret
	str	w0, [x1, #168]
	str	x8, [x1, #176]
LBB19_163:                              ; %common.ret
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB19_164:                              ; %b283
	cmp	w9, #64
	b.hs	LBB19_168
; %bb.165:
	mov	w10, #4                         ; =0x4
LBB19_166:                              ; %b284
	add	x9, x8, x9
	strb	w10, [x9, #56]
	ldr	w9, [x8, #120]
	adds	w9, w9, #1
	b.hs	LBB19_168
; %bb.167:                              ; %v691_ok
	ldr	w0, [x8, #168]
	str	w9, [x8, #120]
	b	LBB19_163
LBB19_168:                              ; %v23_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_json.feed_mut             ; -- Begin function liza_json.feed_mut
	.p2align	2
_liza_json.feed_mut:                    ; @liza_json.feed_mut
; %bb.0:                                ; %b0
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	w0, [x0, #168]
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	cbnz	w0, LBB20_38
; %bb.1:                                ; %b4.preheader
	cbz	w2, LBB20_36
; %bb.2:                                ; %v10_ok.lr.ph
	mov	x20, x1
	mov	w21, w2
	mov	w22, #-96                       ; =0xffffffa0
	mov	w23, #-97                       ; =0xffffff9f
	mov	w24, #-112                      ; =0xffffff90
	mov	w25, #-113                      ; =0xffffff8f
LBB20_3:                                ; %v10_ok
                                        ; =>This Inner Loop Header: Depth=1
	ldp	x9, x15, [x19, #8]
	ldr	x13, [x19, #40]
	ldrb	w0, [x20], #1
	ldr	w8, [x19, #32]
	ldrb	w10, [x19, #29]
	ldrb	w12, [x19, #28]
	ldr	w14, [x19, #24]
	ldr	x11, [x19]
	cbz	w8, LBB20_7
LBB20_4:                                ; %liza_utf8_stream.feed_byte.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #2
	stp	x11, x9, [x19]
	str	x15, [x19, #16]
	str	w14, [x19, #24]
	strb	w12, [x19, #28]
	strb	w10, [x19, #29]
	str	w8, [x19, #32]
	str	x13, [x19, #40]
	b.eq	LBB20_13
; %bb.5:                                ; %liza_utf8_stream.feed_byte.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w8, #1
	b.ne	LBB20_14
; %bb.6:                                ; %b1.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, wzr
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB20_15
	b	LBB20_37
LBB20_7:                                ; %b3.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmn	x11, #1
	b.eq	LBB20_18
; %bb.8:                                ; %b6.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cbz	w14, LBB20_19
; %bb.9:                                ; %b8.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w0, w12, uxtb
	b.lo	LBB20_22
; %bb.10:                               ; %b8.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w0, w10, uxtb
	b.hi	LBB20_22
; %bb.11:                               ; %v115_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	w14, w14, #1
	mov	w10, #191                       ; =0xbf
	mov	w12, #128                       ; =0x80
	b.eq	LBB20_26
; %bb.12:                               ; %b57.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	adds	x11, x11, #1
	b.lo	LBB20_4
	b	LBB20_39
LBB20_13:                               ; %b4.i3
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w9, wzr
	mov	w8, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB20_15
	b	LBB20_37
LBB20_14:                               ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, wzr
	mov	x13, xzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB20_37
LBB20_15:                               ; %b13
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x1, x19
	bl	_liza___liza_json_mut_step
	ldr	w0, [x19, #168]
	cbnz	w0, LBB20_38
; %bb.16:                               ; %b16
                                        ;   in Loop: Header=BB20_3 Depth=1
	ldr	x8, [x19, #48]
	adds	x8, x8, #1
	b.hs	LBB20_39
; %bb.17:                               ; %v46_ok
                                        ;   in Loop: Header=BB20_3 Depth=1
	subs	x21, x21, #1
	str	x8, [x19, #48]
	b.ne	LBB20_3
	b	LBB20_36
LBB20_18:                               ; %b4.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x13, #-1                        ; =0xffffffffffffffff
	mov	w8, #2                          ; =0x2
	b	LBB20_4
LBB20_19:                               ; %b7.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	tbnz	w0, #7, LBB20_23
; %bb.20:                               ; %b9.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmn	x9, #1
	b.eq	LBB20_28
; %bb.21:                               ; %v32_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	x9, x9, #1
	b	LBB20_25
LBB20_22:                               ; %b48.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #1                          ; =0x1
	mov	x13, x15
	b	LBB20_4
LBB20_23:                               ; %b10.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	w10, w0, #62
	mov	w12, #128                       ; =0x80
	and	w10, w10, #0xff
	cmp	w10, #30
	mov	w10, #191                       ; =0xbf
	b.hs	LBB20_30
; %bb.24:                               ; %b17.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w14, #1                         ; =0x1
LBB20_25:                               ; %v32_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x15, x11
	adds	x11, x11, #1
	b.lo	LBB20_4
	b	LBB20_39
LBB20_26:                               ; %b51.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmn	x9, #1
	b.eq	LBB20_32
; %bb.27:                               ; %v138_ok.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	x9, x9, #1
	adds	x11, x11, #1
	b.lo	LBB20_4
	b	LBB20_39
LBB20_28:                               ; %b11.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #2                          ; =0x2
LBB20_29:                               ; %liza_utf8_stream.feed_byte.exit
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	x15, x11
	mov	x13, x11
	b	LBB20_4
LBB20_30:                               ; %b18.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	and	w15, w0, #0xf0
	cmp	w15, #224
	b.ne	LBB20_33
; %bb.31:                               ; %b22.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w0, #224
	mov	w14, #2                         ; =0x2
	mov	x15, x11
	csel	w12, w22, w12, eq
	cmp	w0, #237
	csel	w10, w23, w10, eq
	adds	x11, x11, #1
	b.lo	LBB20_4
	b	LBB20_39
LBB20_32:                               ; %b53.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #2                          ; =0x2
	mov	x13, x11
	b	LBB20_4
LBB20_33:                               ; %b23.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	add	w15, w0, #16
	and	w15, w15, #0xff
	cmp	w15, #4
	b.hi	LBB20_35
; %bb.34:                               ; %b33.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	cmp	w0, #240
	mov	w14, #3                         ; =0x3
	mov	x15, x11
	csel	w12, w24, w12, eq
	cmp	w0, #244
	csel	w10, w25, w10, eq
	adds	x11, x11, #1
	b.lo	LBB20_4
	b	LBB20_39
LBB20_35:                               ; %b34.i
                                        ;   in Loop: Header=BB20_3 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB20_29
LBB20_36:
	mov	w0, wzr
	b	LBB20_38
LBB20_37:                               ; %b9
	cmp	w8, #0
	mov	w8, #8                          ; =0x8
	mov	w9, #5                          ; =0x5
	csel	w0, w9, w8, eq
	str	x13, [x19, #176]
	str	w0, [x19, #168]
LBB20_38:                               ; %common.ret
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB20_39:                               ; %v145_trap.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza___liza_owned___liza_json_done ; -- Begin function liza___liza_owned___liza_json_done
	.p2align	2
_liza___liza_owned___liza_json_done:    ; @liza___liza_owned___liza_json_done
; %bb.0:                                ; %b0
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #416
	ldr	w21, [x8, #120]
	cbz	w21, LBB21_5
; %bb.1:                                ; %b2
	ldrb	w11, [x8, #56]
	ldrb	w9, [x8, #57]
	sub	w21, w21, #1
	ldrb	w10, [x8, #58]
	ldrb	w2, [x8, #94]
	cmp	w21, #64
	strb	w11, [sp, #160]
	ldrb	w3, [x8, #95]
	ldrb	w4, [x8, #96]
	stp	w11, w10, [sp, #148]            ; 8-byte Folded Spill
	ldrb	w11, [x8, #59]
	ldrb	w5, [x8, #97]
	str	w9, [sp, #156]                  ; 4-byte Folded Spill
	ldrb	w6, [x8, #98]
	ldrb	w7, [x8, #99]
	strb	w9, [sp, #161]
	ldrb	w9, [x8, #60]
	ldrb	w19, [x8, #100]
	strb	w10, [sp, #162]
	ldrb	w10, [x8, #61]
	ldrb	w20, [x8, #101]
	stp	w9, w11, [sp, #140]             ; 8-byte Folded Spill
	ldrb	w22, [x8, #102]
	ldrb	w23, [x8, #103]
	strb	w11, [sp, #163]
	ldrb	w11, [x8, #62]
	ldrb	w24, [x8, #104]
	strb	w9, [sp, #164]
	ldrb	w9, [x8, #63]
	ldrb	w25, [x8, #105]
	stp	w11, w10, [sp, #132]            ; 8-byte Folded Spill
	ldrb	w26, [x8, #106]
	ldrb	w27, [x8, #107]
	strb	w10, [sp, #165]
	ldrb	w10, [x8, #64]
	ldrb	w28, [x8, #108]
	strb	w11, [sp, #166]
	ldrb	w11, [x8, #65]
	ldrb	w30, [x8, #109]
	stp	w10, w9, [sp, #124]             ; 8-byte Folded Spill
	ldrb	w12, [x8, #113]
	ldrb	w13, [x8, #114]
	strb	w9, [sp, #167]
	ldrb	w9, [x8, #66]
	ldrb	w14, [x8, #115]
	strb	w10, [sp, #168]
	ldrb	w10, [x8, #67]
	ldrb	w15, [x8, #116]
	stp	w9, w11, [sp, #116]             ; 8-byte Folded Spill
	ldrb	w16, [x8, #117]
	ldrb	w17, [x8, #118]
	strb	w11, [sp, #169]
	ldrb	w11, [x8, #68]
	ldrb	w0, [x8, #119]
	strb	w9, [sp, #170]
	ldrb	w9, [x8, #69]
	stp	w11, w10, [sp, #108]            ; 8-byte Folded Spill
	strb	w10, [sp, #171]
	ldrb	w10, [x8, #70]
	strb	w11, [sp, #172]
	ldrb	w11, [x8, #71]
	stp	w10, w9, [sp, #100]             ; 8-byte Folded Spill
	strb	w9, [sp, #173]
	ldrb	w9, [x8, #72]
	strb	w10, [sp, #174]
	ldrb	w10, [x8, #73]
	stp	w9, w11, [sp, #92]              ; 8-byte Folded Spill
	strb	w11, [sp, #175]
	ldrb	w11, [x8, #74]
	strb	w9, [sp, #176]
	ldrb	w9, [x8, #75]
	stp	w11, w10, [sp, #84]             ; 8-byte Folded Spill
	strb	w10, [sp, #177]
	ldrb	w10, [x8, #76]
	strb	w11, [sp, #178]
	ldrb	w11, [x8, #77]
	stp	w10, w9, [sp, #76]              ; 8-byte Folded Spill
	strb	w9, [sp, #179]
	ldrb	w9, [x8, #78]
	strb	w10, [sp, #180]
	ldrb	w10, [x8, #79]
	stp	w9, w11, [sp, #68]              ; 8-byte Folded Spill
	strb	w11, [sp, #181]
	ldrb	w11, [x8, #80]
	strb	w9, [sp, #182]
	ldrb	w9, [x8, #81]
	stp	w11, w10, [sp, #60]             ; 8-byte Folded Spill
	strb	w10, [sp, #183]
	ldrb	w10, [x8, #82]
	strb	w11, [sp, #184]
	ldrb	w11, [x8, #83]
	stp	w10, w9, [sp, #52]              ; 8-byte Folded Spill
	strb	w9, [sp, #185]
	ldrb	w9, [x8, #84]
	strb	w10, [sp, #186]
	ldrb	w10, [x8, #85]
	stp	w9, w11, [sp, #44]              ; 8-byte Folded Spill
	strb	w9, [sp, #188]
	ldrb	w9, [x8, #86]
	strb	w10, [sp, #189]
	stp	w9, w10, [sp, #36]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #87]
	strb	w9, [sp, #190]
	ldrb	w9, [x8, #88]
	strb	w10, [sp, #191]
	stp	w9, w10, [sp, #28]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #89]
	strb	w9, [sp, #192]
	ldrb	w9, [x8, #90]
	strb	w10, [sp, #193]
	stp	w9, w10, [sp, #20]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #91]
	strb	w9, [sp, #194]
	ldrb	w9, [x8, #92]
	strb	w10, [sp, #195]
	stp	w9, w10, [sp, #12]              ; 8-byte Folded Spill
	ldrb	w10, [x8, #93]
	strb	w11, [sp, #187]
	ldrb	w11, [x8, #112]
	strb	w9, [sp, #196]
	ldrb	w9, [x8, #110]
	str	w10, [sp, #8]                   ; 4-byte Folded Spill
	strb	w10, [sp, #197]
	ldrb	w10, [x8, #111]
	strb	w2, [sp, #198]
	strb	w3, [sp, #199]
	strb	w4, [sp, #200]
	strb	w5, [sp, #201]
	strb	w6, [sp, #202]
	strb	w7, [sp, #203]
	strb	w19, [sp, #204]
	strb	w20, [sp, #205]
	strb	w22, [sp, #206]
	strb	w23, [sp, #207]
	strb	w24, [sp, #208]
	strb	w25, [sp, #209]
	strb	w26, [sp, #210]
	strb	w27, [sp, #211]
	strb	w28, [sp, #212]
	strb	w30, [sp, #213]
	strb	w9, [sp, #214]
	strb	w10, [sp, #215]
	strb	w11, [sp, #216]
	strb	w12, [sp, #217]
	strb	w13, [sp, #218]
	strb	w14, [sp, #219]
	strb	w15, [sp, #220]
	strb	w16, [sp, #221]
	strb	w17, [sp, #222]
	strb	w0, [sp, #223]
	b.hs	LBB21_9
; %bb.2:                                ; %v10_ok
	add	x1, sp, #160
	ldrb	w1, [x1, x21]
	cmp	w1, #1
	b.eq	LBB21_4
; %bb.3:                                ; %b3
	ldr	w1, [sp, #148]                  ; 4-byte Folded Reload
	strb	w2, [sp, #262]
	strb	w3, [sp, #263]
	strb	w1, [sp, #224]
	ldr	w1, [sp, #156]                  ; 4-byte Folded Reload
	strb	w4, [sp, #264]
	strb	w1, [sp, #225]
	ldr	w1, [sp, #152]                  ; 4-byte Folded Reload
	strb	w5, [sp, #265]
	strb	w1, [sp, #226]
	ldr	w1, [sp, #144]                  ; 4-byte Folded Reload
	strb	w6, [sp, #266]
	strb	w1, [sp, #227]
	ldr	w1, [sp, #140]                  ; 4-byte Folded Reload
	strb	w7, [sp, #267]
	strb	w1, [sp, #228]
	ldr	w1, [sp, #136]                  ; 4-byte Folded Reload
	strb	w19, [sp, #268]
	strb	w1, [sp, #229]
	ldr	w1, [sp, #132]                  ; 4-byte Folded Reload
	strb	w20, [sp, #269]
	strb	w1, [sp, #230]
	ldr	w1, [sp, #128]                  ; 4-byte Folded Reload
	strb	w22, [sp, #270]
	strb	w1, [sp, #231]
	ldr	w1, [sp, #124]                  ; 4-byte Folded Reload
	strb	w23, [sp, #271]
	strb	w1, [sp, #232]
	ldr	w1, [sp, #120]                  ; 4-byte Folded Reload
	strb	w24, [sp, #272]
	strb	w1, [sp, #233]
	ldr	w1, [sp, #116]                  ; 4-byte Folded Reload
	strb	w25, [sp, #273]
	strb	w1, [sp, #234]
	ldr	w1, [sp, #112]                  ; 4-byte Folded Reload
	strb	w26, [sp, #274]
	strb	w1, [sp, #235]
	ldr	w1, [sp, #108]                  ; 4-byte Folded Reload
	strb	w27, [sp, #275]
	strb	w1, [sp, #236]
	ldr	w1, [sp, #104]                  ; 4-byte Folded Reload
	strb	w28, [sp, #276]
	strb	w1, [sp, #237]
	ldr	w1, [sp, #100]                  ; 4-byte Folded Reload
	strb	w30, [sp, #277]
	strb	w1, [sp, #238]
	ldr	w1, [sp, #96]                   ; 4-byte Folded Reload
	strb	w9, [sp, #278]
	add	x9, sp, #224
	strb	w1, [sp, #239]
	ldr	w1, [sp, #92]                   ; 4-byte Folded Reload
	strb	w10, [sp, #279]
	strb	w1, [sp, #240]
	ldr	w1, [sp, #88]                   ; 4-byte Folded Reload
	strb	w11, [sp, #280]
	strb	w1, [sp, #241]
	ldr	w1, [sp, #84]                   ; 4-byte Folded Reload
	strb	w12, [sp, #281]
	strb	w1, [sp, #242]
	ldr	w1, [sp, #80]                   ; 4-byte Folded Reload
	strb	w13, [sp, #282]
	strb	w1, [sp, #243]
	ldr	w1, [sp, #76]                   ; 4-byte Folded Reload
	strb	w14, [sp, #283]
	strb	w1, [sp, #244]
	ldr	w1, [sp, #72]                   ; 4-byte Folded Reload
	strb	w15, [sp, #284]
	strb	w1, [sp, #245]
	ldr	w1, [sp, #68]                   ; 4-byte Folded Reload
	strb	w16, [sp, #285]
	strb	w1, [sp, #246]
	ldr	w1, [sp, #64]                   ; 4-byte Folded Reload
	strb	w17, [sp, #286]
	strb	w1, [sp, #247]
	ldr	w1, [sp, #60]                   ; 4-byte Folded Reload
	strb	w0, [sp, #287]
	strb	w1, [sp, #248]
	ldr	w1, [sp, #56]                   ; 4-byte Folded Reload
	strb	w1, [sp, #249]
	ldr	w1, [sp, #52]                   ; 4-byte Folded Reload
	strb	w1, [sp, #250]
	ldr	w1, [sp, #48]                   ; 4-byte Folded Reload
	strb	w1, [sp, #251]
	ldr	w1, [sp, #44]                   ; 4-byte Folded Reload
	strb	w1, [sp, #252]
	ldr	w1, [sp, #40]                   ; 4-byte Folded Reload
	strb	w1, [sp, #253]
	ldr	w1, [sp, #36]                   ; 4-byte Folded Reload
	strb	w1, [sp, #254]
	ldr	w1, [sp, #32]                   ; 4-byte Folded Reload
	strb	w1, [sp, #255]
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	strb	w1, [sp, #256]
	ldr	w1, [sp, #24]                   ; 4-byte Folded Reload
	strb	w1, [sp, #257]
	ldr	w1, [sp, #20]                   ; 4-byte Folded Reload
	strb	w1, [sp, #258]
	ldr	w1, [sp, #16]                   ; 4-byte Folded Reload
	strb	w1, [sp, #259]
	ldr	w1, [sp, #12]                   ; 4-byte Folded Reload
	strb	w1, [sp, #260]
	ldr	w1, [sp, #8]                    ; 4-byte Folded Reload
	strb	w1, [sp, #261]
	ldrb	w9, [x9, x21]
	cmp	w9, #3
	b.ne	LBB21_6
LBB21_4:                                ; %v20_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #352
	ldur	q2, [x8, #88]
	mov	w10, #2                         ; =0x2
	stp	q0, q1, [sp, #352]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #384]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #352]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #384]
	b	LBB21_7
LBB21_5:                                ; %b1
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #124]
	b	LBB21_8
LBB21_6:                                ; %v25_ok
	ldur	q0, [x8, #56]
	ldur	q1, [x8, #72]
	add	x9, sp, #288
	ldur	q2, [x8, #88]
	mov	w10, #7                         ; =0x7
	stp	q0, q1, [sp, #288]
	ldur	q0, [x8, #104]
	stp	q2, q0, [sp, #320]
	strb	w10, [x9, x21]
	ldp	q0, q1, [sp, #288]
	stur	q0, [x8, #56]
	stur	q1, [x8, #72]
	ldp	q0, q1, [sp, #320]
LBB21_7:                                ; %b9
	stur	q0, [x8, #88]
	stur	q1, [x8, #104]
LBB21_8:                                ; %b9
	add	sp, sp, #416
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB21_9:                                ; %v10_trap
	brk	#0x1
                                        ; -- End function
	.globl	_example_entry                  ; -- Begin function example_entry
	.p2align	2
_example_entry:                         ; @example_entry
; %bb.0:                                ; %entry
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_stream_start                   ; -- Begin function stream_start
	.p2align	2
_stream_start:                          ; @stream_start
; %bb.0:
	sub	sp, sp, #16
	movi.2d	v0, #0000000000000000
	mov	w8, #49024                      ; =0xbf80
	strb	wzr, [sp, #12]
	strb	wzr, [sp, #8]
	stp	xzr, xzr, [x0, #8]
	str	xzr, [x0]
	str	wzr, [x0, #24]
	strh	w8, [x0, #28]
	str	wzr, [x0, #32]
	stur	q0, [x0, #40]
	stur	q0, [x0, #56]
	stur	q0, [x0, #72]
	stur	q0, [x0, #88]
	stur	q0, [x0, #104]
	str	wzr, [x0, #120]
	strb	wzr, [x0, #124]
	str	wzr, [x0, #128]
	strb	wzr, [x0, #132]
	str	xzr, [x0, #176]
	str	wzr, [x0, #168]
	stur	q0, [x0, #152]
	stur	q0, [x0, #136]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_stream_feed                    ; -- Begin function stream_feed
	.p2align	2
_stream_feed:                           ; @stream_feed
; %bb.0:
	b	_liza_json.feed_mut
                                        ; -- End function
	.globl	_stream_status                  ; -- Begin function stream_status
	.p2align	2
_stream_status:                         ; @stream_status
; %bb.0:
	b	_liza_status
                                        ; -- End function
	.globl	_stream_pending                 ; -- Begin function stream_pending
	.p2align	2
_stream_pending:                        ; @stream_pending
; %bb.0:
	ldr	w8, [x0, #168]
	cmp	w8, #0
	cset	w0, ne
	ret
                                        ; -- End function
	.globl	_stream_value                   ; -- Begin function stream_value
	.p2align	2
_stream_value:                          ; @stream_value
; %bb.0:
	ldr	w8, [x0, #168]
	cbz	w8, LBB27_2
; %bb.1:                                ; %b3.i.i.i
	ldr	x8, [x0, #176]
	mov	w9, wzr
	cbnz	w9, LBB27_3
	b	LBB27_9
LBB27_2:
	mov	x8, xzr
	mov	w9, #1                          ; =0x1
	cbz	w9, LBB27_9
LBB27_3:                                ; %b4.i.i
	ldr	w9, [x0, #32]
	ldr	x8, [x0, #40]
	cmp	w9, #2
	b.eq	LBB27_7
; %bb.4:                                ; %b4.i.i
	cmp	w9, #1
	b.eq	LBB27_8
; %bb.5:                                ; %b6.i.i.i
	ldr	w8, [x0, #24]
	cbz	w8, LBB27_11
; %bb.6:                                ; %b7.i.i.i
	ldr	x8, [x0, #16]
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB27_9
	b	LBB27_12
LBB27_7:                                ; %b4.i.i.i
	mov	w9, #1                          ; =0x1
LBB27_8:                                ; %liza_utf8_stream.finish.exit.i.i
	cbz	w9, LBB27_12
LBB27_9:                                ; %b2.i.i
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
LBB27_10:                               ; %liza_value.exit
	cmp	w10, #0
	csel	x0, x9, x8, eq
	ret
LBB27_11:                               ; %b9.i.i.i
	mov	w9, wzr
	mov	x8, xzr
	cbnz	w9, LBB27_9
LBB27_12:                               ; %b6.i.i
	ldr	w9, [x0, #128]
	cmp	w9, #17
	b.hi	LBB27_21
; %bb.13:                               ; %b6.i.i
	mov	w8, #1                          ; =0x1
	mov	w10, #22528                     ; =0x5800
	lsl	w8, w8, w9
	movk	w10, #2, lsl #16
	tst	w8, w10
	b.eq	LBB27_21
; %bb.14:                               ; %b18.i.i
	sub	sp, sp, #208
	ldp	q0, q1, [x0, #128]
	ldr	q2, [x0, #160]
	ldr	x8, [x0, #176]
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	str	q2, [sp, #160]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #64]
	str	x8, [sp, #176]
	mov	x8, sp
	str	wzr, [sp, #128]
	stp	q0, q1, [sp, #64]
	ldp	q2, q0, [x0, #96]
	stp	q2, q0, [sp, #96]
	ldp	q1, q0, [x0]
	stp	q1, q0, [sp]
	ldp	q2, q0, [x0, #32]
	stp	q2, q0, [sp, #32]
	bl	_liza___liza_owned___liza_json_done
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldr	x8, [sp, #48]
	ldr	w11, [sp, #120]
	ldrb	w10, [sp, #124]
	ldr	w9, [sp, #128]
	ldr	x12, [sp, #160]
	add	sp, sp, #208
LBB27_15:                               ; %b20.i.i
	sub	w13, w9, #4
	cmp	w13, #2
	b.hi	LBB27_17
; %bb.16:                               ; %b27.i.i
	mov	x9, xzr
	mov	w10, #1                         ; =0x1
	mov	x8, x12
	b	LBB27_10
LBB27_17:                               ; %b29.i.i
	cbnz	w9, LBB27_9
; %bb.18:                               ; %b29.i.i
	cbnz	w11, LBB27_9
; %bb.19:                               ; %b29.i.i
	tbz	w10, #0, LBB27_9
; %bb.20:                               ; %b38.i.i
	mov	w10, wzr
	mov	x9, x8
	mov	x8, xzr
	b	LBB27_10
LBB27_21:                               ; %b19_to_b20.i.i
	ldr	x8, [x0, #48]
	ldr	w11, [x0, #120]
	ldrb	w10, [x0, #124]
	ldr	x12, [x0, #160]
	b	LBB27_15
                                        ; -- End function
	.globl	_stream_size                    ; -- Begin function stream_size
	.p2align	2
_stream_size:                           ; @stream_size
; %bb.0:
	mov	w0, #184                        ; =0xb8
	ret
                                        ; -- End function
.subsections_via_symbols
