; ModuleID = '/private/tmp/liza-inlining-p1-final/rtp/excessive/module.ll'
source_filename = "/private/tmp/liza-inlining-p1-final/rtp/excessive/module.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%variant.1 = type { i32, %struct.rtp_result.RtpHeader, %variant.0 }
%struct.rtp_result.RtpHeader = type { i8, i1, i8, i16, i32, i32, i32, i32 }
%variant.0 = type { i32, [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8] }

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32) #1

; Function Attrs: nounwind memory(read, inaccessiblemem: write)
define i16 @liza_rtp_result.be16({ ptr, i32 } %p0, i32 %p1) local_unnamed_addr #2 {
b0:
  %v0_length = extractvalue { ptr, i32 } %p0, 1
  %v0_invalid.not = icmp ult i32 %p1, %v0_length
  br i1 %v0_invalid.not, label %v3_ok, label %v0_trap

v0_trap:                                          ; preds = %b0
  tail call void @llvm.trap()
  unreachable

v3_ok:                                            ; preds = %b0
  %v5_pair1 = add nuw i32 %p1, 1
  %v6_invalid.not = icmp ult i32 %v5_pair1, %v0_length
  br i1 %v6_invalid.not, label %v7_ok, label %v6_trap

v6_trap:                                          ; preds = %v3_ok
  tail call void @llvm.trap()
  unreachable

v7_ok:                                            ; preds = %v3_ok
  %v0_base = extractvalue { ptr, i32 } %p0, 0
  %v0_offset = zext i32 %p1 to i64
  %v0_ptr = getelementptr i8, ptr %v0_base, i64 %v0_offset
  %v0 = load i8, ptr %v0_ptr, align 1
  %v6_offset = zext i32 %v5_pair1 to i64
  %v6_ptr = getelementptr i8, ptr %v0_base, i64 %v6_offset
  %v6 = load i8, ptr %v6_ptr, align 1
  %v1 = zext i8 %v0 to i16
  %v3 = shl nuw i16 %v1, 8
  %v7 = zext i8 %v6 to i16
  %v8 = or disjoint i16 %v3, %v7
  ret i16 %v8
}

; Function Attrs: nounwind memory(read, inaccessiblemem: write)
define i32 @liza_rtp_result.be32({ ptr, i32 } %p0, i32 %p1) local_unnamed_addr #2 {
b0:
  %v0_length.i = extractvalue { ptr, i32 } %p0, 1
  %v0_invalid.not.i = icmp ult i32 %p1, %v0_length.i
  br i1 %v0_invalid.not.i, label %v3_ok.i, label %v0_trap.i

v0_trap.i:                                        ; preds = %b0
  tail call void @llvm.trap()
  unreachable

v3_ok.i:                                          ; preds = %b0
  %v5_pair1.i = add nuw i32 %p1, 1
  %v6_invalid.not.i = icmp ult i32 %v5_pair1.i, %v0_length.i
  br i1 %v6_invalid.not.i, label %liza_rtp_result.be16.exit, label %v6_trap.i

v6_trap.i:                                        ; preds = %v3_ok.i
  tail call void @llvm.trap()
  unreachable

liza_rtp_result.be16.exit:                        ; preds = %v3_ok.i
  %v0_base.i = extractvalue { ptr, i32 } %p0, 0
  %v0_offset.i = zext i32 %p1 to i64
  %v0_ptr.i = getelementptr i8, ptr %v0_base.i, i64 %v0_offset.i
  %v0.i = load i8, ptr %v0_ptr.i, align 1
  %v6_offset.i = zext i32 %v5_pair1.i to i64
  %v6_ptr.i = getelementptr i8, ptr %v0_base.i, i64 %v6_offset.i
  %v6.i = load i8, ptr %v6_ptr.i, align 1
  %v5_pair20 = add nuw i32 %p1, 2
  %v0_invalid.not.i2 = icmp ult i32 %v5_pair20, %v0_length.i
  br i1 %v0_invalid.not.i2, label %v3_ok.i4, label %v0_trap.i3

v0_trap.i3:                                       ; preds = %liza_rtp_result.be16.exit
  tail call void @llvm.trap()
  unreachable

v3_ok.i4:                                         ; preds = %liza_rtp_result.be16.exit
  %v5_pair1.i5 = add nuw i32 %p1, 3
  %v6_invalid.not.i6 = icmp ult i32 %v5_pair1.i5, %v0_length.i
  br i1 %v6_invalid.not.i6, label %liza_rtp_result.be16.exit19, label %v6_trap.i7

v6_trap.i7:                                       ; preds = %v3_ok.i4
  tail call void @llvm.trap()
  unreachable

liza_rtp_result.be16.exit19:                      ; preds = %v3_ok.i4
  %v1.i = zext i8 %v0.i to i32
  %v7.i = zext i8 %v6.i to i32
  %v0_offset.i9 = zext i32 %v5_pair20 to i64
  %v0_ptr.i10 = getelementptr i8, ptr %v0_base.i, i64 %v0_offset.i9
  %v0.i11 = load i8, ptr %v0_ptr.i10, align 1
  %v6_offset.i12 = zext i32 %v5_pair1.i5 to i64
  %v6_ptr.i13 = getelementptr i8, ptr %v0_base.i, i64 %v6_offset.i12
  %v6.i14 = load i8, ptr %v6_ptr.i13, align 1
  %v1.i15 = zext i8 %v0.i11 to i32
  %v3.i16 = shl nuw nsw i32 %v1.i15, 8
  %v7.i17 = zext i8 %v6.i14 to i32
  %0 = shl nuw i32 %v1.i, 24
  %1 = shl nuw nsw i32 %v7.i, 16
  %v8.i18 = or disjoint i32 %1, %0
  %v3 = or disjoint i32 %v8.i18, %v7.i17
  %v8 = or disjoint i32 %v3, %v3.i16
  ret i32 %v8
}

; Function Attrs: nounwind memory(read, inaccessiblemem: write)
define %variant.1 @liza_rtp_result.parse_rtp({ ptr, i32 } %p0) local_unnamed_addr #2 {
b0:
  %v0 = extractvalue { ptr, i32 } %p0, 1
  %v2 = icmp ult i32 %v0, 12
  br i1 %v2, label %common.ret, label %b3

common.ret:                                       ; preds = %b23, %b19, %liza_rtp_result.be16.exit, %v33_ok, %v20_ok, %b3, %b0, %v88_ok
  %common.ret.op = phi %variant.1 [ %v98, %v88_ok ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 zeroinitializer }, %b0 ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %b3 ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %v20_ok ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %v33_ok ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %liza_rtp_result.be16.exit ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %b19 ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %b23 ]
  ret %variant.1 %common.ret.op

b3:                                               ; preds = %b0
  %v6_base = extractvalue { ptr, i32 } %p0, 0
  %v6 = load i8, ptr %v6_base, align 1
  %v10.not = icmp slt i8 %v6, -64
  br i1 %v10.not, label %v20_ok, label %common.ret

v20_ok:                                           ; preds = %b3
  %v18 = shl i8 %v6, 2
  %0 = and i8 %v18, 60
  %narrow = add nuw nsw i8 %0, 12
  %v21_pair = zext nneg i8 %narrow to i32
  %v23 = icmp ult i32 %v0, %v21_pair
  br i1 %v23, label %common.ret, label %v27_ok

v27_ok:                                           ; preds = %v20_ok
  %v29 = and i8 %v6, 16
  %v31.not = icmp eq i8 %v29, 0
  br i1 %v31.not, label %b18, label %b10

b10:                                              ; preds = %v27_ok
  %v33_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v0, i32 %v21_pair)
  %v33 = extractvalue { i32, i1 } %v33_pair, 0
  %v33_overflow = extractvalue { i32, i1 } %v33_pair, 1
  br i1 %v33_overflow, label %v33_trap, label %v33_ok

v33_trap:                                         ; preds = %b10
  tail call void @llvm.trap()
  unreachable

v33_ok:                                           ; preds = %b10
  %v35 = icmp ult i32 %v33, 4
  br i1 %v35, label %common.ret, label %v40_ok

v40_ok:                                           ; preds = %v33_ok
  %v40_pair = or disjoint i32 %v21_pair, 2
  %v0_invalid.not.i = icmp ult i32 %v40_pair, %v0
  br i1 %v0_invalid.not.i, label %v3_ok.i, label %v0_trap.i

v0_trap.i:                                        ; preds = %v40_ok
  tail call void @llvm.trap()
  unreachable

v3_ok.i:                                          ; preds = %v40_ok
  %v5_pair1.i = or disjoint i32 %v21_pair, 3
  %v6_invalid.not.i = icmp ult i32 %v5_pair1.i, %v0
  br i1 %v6_invalid.not.i, label %liza_rtp_result.be16.exit, label %v6_trap.i

v6_trap.i:                                        ; preds = %v3_ok.i
  tail call void @llvm.trap()
  unreachable

liza_rtp_result.be16.exit:                        ; preds = %v3_ok.i
  %v0_offset.i = zext nneg i32 %v40_pair to i64
  %v0_ptr.i = getelementptr i8, ptr %v6_base, i64 %v0_offset.i
  %v0.i = load i8, ptr %v0_ptr.i, align 1
  %v6_offset.i = zext nneg i32 %v5_pair1.i to i64
  %v6_ptr.i = getelementptr i8, ptr %v6_base, i64 %v6_offset.i
  %v6.i = load i8, ptr %v6_ptr.i, align 1
  %v1.i = zext i8 %v0.i to i32
  %v7.i = zext i8 %v6.i to i32
  %1 = shl nuw nsw i32 %v1.i, 10
  %2 = shl nuw nsw i32 %v7.i, 2
  %v43_pair = or disjoint i32 %2, %1
  %v47 = add i32 %v33, -4
  %v48 = icmp ugt i32 %v43_pair, %v47
  br i1 %v48, label %common.ret, label %v52_ok

v52_ok:                                           ; preds = %liza_rtp_result.be16.exit
  %v52_pair = add nuw nsw i32 %v21_pair, 4
  %v53_pair = add nuw nsw i32 %v52_pair, %v43_pair
  br label %b18

b18:                                              ; preds = %v52_ok, %v27_ok
  %v54 = phi i32 [ %v21_pair, %v27_ok ], [ %v53_pair, %v52_ok ]
  %v56_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v0, i32 %v54)
  %v56 = extractvalue { i32, i1 } %v56_pair, 0
  %v56_overflow = extractvalue { i32, i1 } %v56_pair, 1
  br i1 %v56_overflow, label %v56_trap, label %v58_ok

v56_trap:                                         ; preds = %b18
  tail call void @llvm.trap()
  unreachable

v58_ok:                                           ; preds = %b18
  %v60 = and i8 %v6, 32
  %v62.not = icmp eq i8 %v60, 0
  br i1 %v62.not, label %v88_ok, label %b19

b19:                                              ; preds = %v58_ok
  %v64 = icmp eq i32 %v56, 0
  br i1 %v64, label %common.ret, label %b23

b23:                                              ; preds = %b19
  %v69 = add i32 %v0, -1
  %v70_offset = zext i32 %v69 to i64
  %v70_ptr = getelementptr i8, ptr %v6_base, i64 %v70_offset
  %v70 = load i8, ptr %v70_ptr, align 1
  %v71 = zext i8 %v70 to i32
  %v73 = icmp eq i8 %v70, 0
  %v75 = icmp ult i32 %v56, %v71
  %v76 = select i1 %v73, i1 true, i1 %v75
  br i1 %v76, label %common.ret, label %b29

b29:                                              ; preds = %b23
  %v79_pair = sub nuw i32 %v56, %v71
  br label %v88_ok

v88_ok:                                           ; preds = %b29, %v58_ok
  %v80 = phi i32 [ %v56, %v58_ok ], [ %v79_pair, %b29 ]
  %v82_ptr = getelementptr i8, ptr %v6_base, i64 1
  %v82 = load i8, ptr %v82_ptr, align 1
  %v86 = icmp slt i8 %v82, 0
  %v90 = and i8 %v82, 127
  %v0_ptr.i8 = getelementptr i8, ptr %v6_base, i64 2
  %v0.i9 = load i8, ptr %v0_ptr.i8, align 1
  %v6_ptr.i10 = getelementptr i8, ptr %v6_base, i64 3
  %v6.i11 = load i8, ptr %v6_ptr.i10, align 1
  %v1.i12 = zext i8 %v0.i9 to i16
  %v3.i13 = shl nuw i16 %v1.i12, 8
  %v7.i14 = zext i8 %v6.i11 to i16
  %v8.i15 = or disjoint i16 %v3.i13, %v7.i14
  %v0_ptr.i.i = getelementptr i8, ptr %v6_base, i64 4
  %v0.i.i = load i8, ptr %v0_ptr.i.i, align 1
  %v6_ptr.i.i = getelementptr i8, ptr %v6_base, i64 5
  %v6.i.i = load i8, ptr %v6_ptr.i.i, align 1
  %v1.i.i = zext i8 %v0.i.i to i32
  %v7.i.i = zext i8 %v6.i.i to i32
  %v0_ptr.i10.i = getelementptr i8, ptr %v6_base, i64 6
  %v0.i11.i = load i8, ptr %v0_ptr.i10.i, align 1
  %v6_ptr.i13.i = getelementptr i8, ptr %v6_base, i64 7
  %v6.i14.i = load i8, ptr %v6_ptr.i13.i, align 1
  %v1.i15.i = zext i8 %v0.i11.i to i32
  %v3.i16.i = shl nuw nsw i32 %v1.i15.i, 8
  %v7.i17.i = zext i8 %v6.i14.i to i32
  %3 = shl nuw i32 %v1.i.i, 24
  %4 = shl nuw nsw i32 %v7.i.i, 16
  %v8.i18.i = or disjoint i32 %4, %3
  %v3.i17 = or disjoint i32 %v8.i18.i, %v7.i17.i
  %v8.i18 = or disjoint i32 %v3.i17, %v3.i16.i
  %v0_ptr.i.i27 = getelementptr i8, ptr %v6_base, i64 8
  %v0.i.i28 = load i8, ptr %v0_ptr.i.i27, align 1
  %v6_ptr.i.i29 = getelementptr i8, ptr %v6_base, i64 9
  %v6.i.i30 = load i8, ptr %v6_ptr.i.i29, align 1
  %v1.i.i36 = zext i8 %v0.i.i28 to i32
  %v7.i.i37 = zext i8 %v6.i.i30 to i32
  %v0_ptr.i10.i38 = getelementptr i8, ptr %v6_base, i64 10
  %v0.i11.i39 = load i8, ptr %v0_ptr.i10.i38, align 1
  %v6_ptr.i13.i40 = getelementptr i8, ptr %v6_base, i64 11
  %v6.i14.i41 = load i8, ptr %v6_ptr.i13.i40, align 1
  %v1.i15.i42 = zext i8 %v0.i11.i39 to i32
  %v3.i16.i43 = shl nuw nsw i32 %v1.i15.i42, 8
  %v7.i17.i44 = zext i8 %v6.i14.i41 to i32
  %5 = shl nuw i32 %v1.i.i36, 24
  %6 = shl nuw nsw i32 %v7.i.i37, 16
  %v8.i18.i45 = or disjoint i32 %6, %5
  %v3.i46 = or disjoint i32 %v8.i18.i45, %v7.i17.i44
  %v8.i47 = or disjoint i32 %v3.i46, %v3.i16.i43
  %v97_field1 = insertvalue %struct.rtp_result.RtpHeader { i8 2, i1 false, i8 0, i16 0, i32 0, i32 0, i32 0, i32 0 }, i1 %v86, 1
  %v97_field2 = insertvalue %struct.rtp_result.RtpHeader %v97_field1, i8 %v90, 2
  %v97_field3 = insertvalue %struct.rtp_result.RtpHeader %v97_field2, i16 %v8.i15, 3
  %v97_field4 = insertvalue %struct.rtp_result.RtpHeader %v97_field3, i32 %v8.i18, 4
  %v97_field5 = insertvalue %struct.rtp_result.RtpHeader %v97_field4, i32 %v8.i47, 5
  %v97_field6 = insertvalue %struct.rtp_result.RtpHeader %v97_field5, i32 %v54, 6
  %v97 = insertvalue %struct.rtp_result.RtpHeader %v97_field6, i32 %v80, 7
  %v98 = insertvalue %variant.1 zeroinitializer, %struct.rtp_result.RtpHeader %v97, 1
  br label %common.ret
}

; Function Attrs: nounwind memory(read, inaccessiblemem: write)
define i32 @liza_rtp_result.rtp_inspect({ ptr, i32 } %p0, i32 %p1) local_unnamed_addr #2 {
b0:
  %v0.i = extractvalue { ptr, i32 } %p0, 1
  %v2.i = icmp ult i32 %v0.i, 12
  br i1 %v2.i, label %liza_rtp_result.parse_rtp.exit, label %b3.i

b3.i:                                             ; preds = %b0
  %v6_base.i = extractvalue { ptr, i32 } %p0, 0
  %v6.i = load i8, ptr %v6_base.i, align 1
  %v10.not.i = icmp slt i8 %v6.i, -64
  br i1 %v10.not.i, label %v20_ok.i, label %liza_rtp_result.parse_rtp.exit

v20_ok.i:                                         ; preds = %b3.i
  %v18.i = shl i8 %v6.i, 2
  %0 = and i8 %v18.i, 60
  %narrow.i = add nuw nsw i8 %0, 12
  %v21_pair.i = zext nneg i8 %narrow.i to i32
  %v23.i = icmp ult i32 %v0.i, %v21_pair.i
  br i1 %v23.i, label %liza_rtp_result.parse_rtp.exit, label %v27_ok.i

v27_ok.i:                                         ; preds = %v20_ok.i
  %v29.i = and i8 %v6.i, 16
  %v31.not.i = icmp eq i8 %v29.i, 0
  br i1 %v31.not.i, label %b18.i, label %b10.i

b10.i:                                            ; preds = %v27_ok.i
  %v33_pair.i = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v0.i, i32 %v21_pair.i)
  %v33.i = extractvalue { i32, i1 } %v33_pair.i, 0
  %v33_overflow.i = extractvalue { i32, i1 } %v33_pair.i, 1
  br i1 %v33_overflow.i, label %v33_trap.i, label %v33_ok.i

v33_trap.i:                                       ; preds = %b10.i
  tail call void @llvm.trap()
  unreachable

v33_ok.i:                                         ; preds = %b10.i
  %v35.i = icmp ult i32 %v33.i, 4
  br i1 %v35.i, label %liza_rtp_result.parse_rtp.exit, label %v40_ok.i

v40_ok.i:                                         ; preds = %v33_ok.i
  %v40_pair.i = or disjoint i32 %v21_pair.i, 2
  %v0_invalid.not.i.i = icmp ult i32 %v40_pair.i, %v0.i
  br i1 %v0_invalid.not.i.i, label %v3_ok.i.i, label %v0_trap.i.i

v0_trap.i.i:                                      ; preds = %v40_ok.i
  tail call void @llvm.trap()
  unreachable

v3_ok.i.i:                                        ; preds = %v40_ok.i
  %v5_pair1.i.i = or disjoint i32 %v21_pair.i, 3
  %v6_invalid.not.i.i = icmp ult i32 %v5_pair1.i.i, %v0.i
  br i1 %v6_invalid.not.i.i, label %liza_rtp_result.be16.exit.i, label %v6_trap.i.i

v6_trap.i.i:                                      ; preds = %v3_ok.i.i
  tail call void @llvm.trap()
  unreachable

liza_rtp_result.be16.exit.i:                      ; preds = %v3_ok.i.i
  %v0_offset.i.i = zext nneg i32 %v40_pair.i to i64
  %v0_ptr.i.i = getelementptr i8, ptr %v6_base.i, i64 %v0_offset.i.i
  %v0.i.i = load i8, ptr %v0_ptr.i.i, align 1
  %v6_offset.i.i = zext nneg i32 %v5_pair1.i.i to i64
  %v6_ptr.i.i = getelementptr i8, ptr %v6_base.i, i64 %v6_offset.i.i
  %v6.i.i = load i8, ptr %v6_ptr.i.i, align 1
  %v1.i.i = zext i8 %v0.i.i to i32
  %v7.i.i = zext i8 %v6.i.i to i32
  %1 = shl nuw nsw i32 %v1.i.i, 10
  %2 = shl nuw nsw i32 %v7.i.i, 2
  %v43_pair.i = or disjoint i32 %2, %1
  %v47.i = add i32 %v33.i, -4
  %v48.i = icmp ugt i32 %v43_pair.i, %v47.i
  br i1 %v48.i, label %liza_rtp_result.parse_rtp.exit, label %v52_ok.i

v52_ok.i:                                         ; preds = %liza_rtp_result.be16.exit.i
  %v52_pair.i = add nuw nsw i32 %v21_pair.i, 4
  %v53_pair.i = add nuw nsw i32 %v52_pair.i, %v43_pair.i
  br label %b18.i

b18.i:                                            ; preds = %v52_ok.i, %v27_ok.i
  %v54.i = phi i32 [ %v21_pair.i, %v27_ok.i ], [ %v53_pair.i, %v52_ok.i ]
  %v56_pair.i = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v0.i, i32 %v54.i)
  %v56.i = extractvalue { i32, i1 } %v56_pair.i, 0
  %v56_overflow.i = extractvalue { i32, i1 } %v56_pair.i, 1
  br i1 %v56_overflow.i, label %v56_trap.i, label %v58_ok.i

v56_trap.i:                                       ; preds = %b18.i
  tail call void @llvm.trap()
  unreachable

v58_ok.i:                                         ; preds = %b18.i
  %v60.i = and i8 %v6.i, 32
  %v62.not.i = icmp eq i8 %v60.i, 0
  br i1 %v62.not.i, label %v88_ok.i, label %b19.i

b19.i:                                            ; preds = %v58_ok.i
  %v64.i = icmp eq i32 %v56.i, 0
  br i1 %v64.i, label %liza_rtp_result.parse_rtp.exit, label %b23.i

b23.i:                                            ; preds = %b19.i
  %v69.i = add i32 %v0.i, -1
  %v70_offset.i = zext i32 %v69.i to i64
  %v70_ptr.i = getelementptr i8, ptr %v6_base.i, i64 %v70_offset.i
  %v70.i = load i8, ptr %v70_ptr.i, align 1
  %v71.i = zext i8 %v70.i to i32
  %v73.i = icmp eq i8 %v70.i, 0
  %v75.i = icmp ult i32 %v56.i, %v71.i
  %v76.i = select i1 %v73.i, i1 true, i1 %v75.i
  br i1 %v76.i, label %liza_rtp_result.parse_rtp.exit, label %b29.i

b29.i:                                            ; preds = %b23.i
  %v79_pair.i = sub nuw i32 %v56.i, %v71.i
  br label %v88_ok.i

v88_ok.i:                                         ; preds = %b29.i, %v58_ok.i
  %v80.i = phi i32 [ %v56.i, %v58_ok.i ], [ %v79_pair.i, %b29.i ]
  %v82_ptr.i = getelementptr i8, ptr %v6_base.i, i64 1
  %v82.i = load i8, ptr %v82_ptr.i, align 1
  %v86.i = icmp slt i8 %v82.i, 0
  %v90.i = and i8 %v82.i, 127
  %v0_ptr.i8.i = getelementptr i8, ptr %v6_base.i, i64 2
  %v0.i9.i = load i8, ptr %v0_ptr.i8.i, align 1
  %v6_ptr.i10.i = getelementptr i8, ptr %v6_base.i, i64 3
  %v6.i11.i = load i8, ptr %v6_ptr.i10.i, align 1
  %v1.i12.i = zext i8 %v0.i9.i to i16
  %v3.i13.i = shl nuw i16 %v1.i12.i, 8
  %v7.i14.i = zext i8 %v6.i11.i to i16
  %v8.i15.i = or disjoint i16 %v3.i13.i, %v7.i14.i
  %v0_ptr.i.i.i = getelementptr i8, ptr %v6_base.i, i64 4
  %v0.i.i.i = load i8, ptr %v0_ptr.i.i.i, align 1
  %v6_ptr.i.i.i = getelementptr i8, ptr %v6_base.i, i64 5
  %v6.i.i.i = load i8, ptr %v6_ptr.i.i.i, align 1
  %v1.i.i.i = zext i8 %v0.i.i.i to i32
  %v7.i.i.i = zext i8 %v6.i.i.i to i32
  %v0_ptr.i10.i.i = getelementptr i8, ptr %v6_base.i, i64 6
  %v0.i11.i.i = load i8, ptr %v0_ptr.i10.i.i, align 1
  %v6_ptr.i13.i.i = getelementptr i8, ptr %v6_base.i, i64 7
  %v6.i14.i.i = load i8, ptr %v6_ptr.i13.i.i, align 1
  %v1.i15.i.i = zext i8 %v0.i11.i.i to i32
  %v3.i16.i.i = shl nuw nsw i32 %v1.i15.i.i, 8
  %v7.i17.i.i = zext i8 %v6.i14.i.i to i32
  %3 = shl nuw i32 %v1.i.i.i, 24
  %4 = shl nuw nsw i32 %v7.i.i.i, 16
  %v8.i18.i.i = or disjoint i32 %4, %3
  %v3.i17.i = or disjoint i32 %v8.i18.i.i, %v7.i17.i.i
  %v8.i18.i = or disjoint i32 %v3.i17.i, %v3.i16.i.i
  %v0_ptr.i.i27.i = getelementptr i8, ptr %v6_base.i, i64 8
  %v0.i.i28.i = load i8, ptr %v0_ptr.i.i27.i, align 1
  %v6_ptr.i.i29.i = getelementptr i8, ptr %v6_base.i, i64 9
  %v6.i.i30.i = load i8, ptr %v6_ptr.i.i29.i, align 1
  %v1.i.i36.i = zext i8 %v0.i.i28.i to i32
  %v7.i.i37.i = zext i8 %v6.i.i30.i to i32
  %v0_ptr.i10.i38.i = getelementptr i8, ptr %v6_base.i, i64 10
  %v0.i11.i39.i = load i8, ptr %v0_ptr.i10.i38.i, align 1
  %v6_ptr.i13.i40.i = getelementptr i8, ptr %v6_base.i, i64 11
  %v6.i14.i41.i = load i8, ptr %v6_ptr.i13.i40.i, align 1
  %v1.i15.i42.i = zext i8 %v0.i11.i39.i to i32
  %v3.i16.i43.i = shl nuw nsw i32 %v1.i15.i42.i, 8
  %v7.i17.i44.i = zext i8 %v6.i14.i41.i to i32
  %5 = shl nuw i32 %v1.i.i36.i, 24
  %6 = shl nuw nsw i32 %v7.i.i37.i, 16
  %v8.i18.i45.i = or disjoint i32 %6, %5
  %v3.i46.i = or disjoint i32 %v8.i18.i45.i, %v7.i17.i44.i
  %v8.i47.i = or disjoint i32 %v3.i46.i, %v3.i16.i43.i
  %v97_field1.i = insertvalue %struct.rtp_result.RtpHeader { i8 2, i1 false, i8 0, i16 0, i32 0, i32 0, i32 0, i32 0 }, i1 %v86.i, 1
  %v97_field2.i = insertvalue %struct.rtp_result.RtpHeader %v97_field1.i, i8 %v90.i, 2
  %v97_field3.i = insertvalue %struct.rtp_result.RtpHeader %v97_field2.i, i16 %v8.i15.i, 3
  %v97_field4.i = insertvalue %struct.rtp_result.RtpHeader %v97_field3.i, i32 %v8.i18.i, 4
  %v97_field5.i = insertvalue %struct.rtp_result.RtpHeader %v97_field4.i, i32 %v8.i47.i, 5
  %v97_field6.i = insertvalue %struct.rtp_result.RtpHeader %v97_field5.i, i32 %v54.i, 6
  %v97.i = insertvalue %struct.rtp_result.RtpHeader %v97_field6.i, i32 %v80.i, 7
  %v98.i = insertvalue %variant.1 zeroinitializer, %struct.rtp_result.RtpHeader %v97.i, 1
  br label %liza_rtp_result.parse_rtp.exit

liza_rtp_result.parse_rtp.exit:                   ; preds = %b0, %b3.i, %v20_ok.i, %v33_ok.i, %liza_rtp_result.be16.exit.i, %b19.i, %b23.i, %v88_ok.i
  %common.ret.op.i = phi %variant.1 [ %v98.i, %v88_ok.i ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 zeroinitializer }, %b0 ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %b3.i ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %v20_ok.i ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %v33_ok.i ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %liza_rtp_result.be16.exit.i ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %b19.i ], [ { i32 1, %struct.rtp_result.RtpHeader zeroinitializer, %variant.0 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer } }, %b23.i ]
  %v1 = extractvalue %variant.1 %common.ret.op.i, 0
  %switch = icmp eq i32 %v1, 0
  br i1 %switch, label %b2, label %b27

b2:                                               ; preds = %liza_rtp_result.parse_rtp.exit
  %v2 = extractvalue %variant.1 %common.ret.op.i, 1
  switch i32 %p1, label %b26 [
    i32 0, label %v6_ok
    i32 1, label %b6
    i32 2, label %v15_ok
    i32 3, label %v19_ok
    i32 4, label %b18
    i32 5, label %b21
    i32 6, label %b24
  ]

common.ret:                                       ; preds = %b27, %b6, %b26, %b24, %b21, %b18, %v19_ok, %v15_ok, %v6_ok
  %common.ret.op = phi i32 [ %v6, %v6_ok ], [ %v15, %v15_ok ], [ %v19, %v19_ok ], [ %v22, %b18 ], [ %v25, %b21 ], [ %v28, %b24 ], [ %v29, %b26 ], [ %spec.select, %b6 ], [ %switch.offset, %b27 ]
  ret i32 %common.ret.op

v6_ok:                                            ; preds = %b2
  %v5 = extractvalue %struct.rtp_result.RtpHeader %v2, 0
  %v6 = zext i8 %v5 to i32
  br label %common.ret

b6:                                               ; preds = %b2
  %v9 = extractvalue %struct.rtp_result.RtpHeader %v2, 1
  %spec.select = zext i1 %v9 to i32
  br label %common.ret

v15_ok:                                           ; preds = %b2
  %v14 = extractvalue %struct.rtp_result.RtpHeader %v2, 2
  %v15 = zext i8 %v14 to i32
  br label %common.ret

v19_ok:                                           ; preds = %b2
  %v18 = extractvalue %struct.rtp_result.RtpHeader %v2, 3
  %v19 = zext i16 %v18 to i32
  br label %common.ret

b18:                                              ; preds = %b2
  %v22 = extractvalue %struct.rtp_result.RtpHeader %v2, 4
  br label %common.ret

b21:                                              ; preds = %b2
  %v25 = extractvalue %struct.rtp_result.RtpHeader %v2, 5
  br label %common.ret

b24:                                              ; preds = %b2
  %v28 = extractvalue %struct.rtp_result.RtpHeader %v2, 6
  br label %common.ret

b26:                                              ; preds = %b2
  %v29 = extractvalue %struct.rtp_result.RtpHeader %v2, 7
  br label %common.ret

b27:                                              ; preds = %liza_rtp_result.parse_rtp.exit
  %v30 = extractvalue %variant.1 %common.ret.op.i, 2
  %v31 = extractvalue %variant.0 %v30, 0
  %switch.offset = add nsw i32 %v31, -2147483647
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef range(i32 0, 2) i32 @liza_main() local_unnamed_addr #3 {
b18.i.i:
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef range(i32 0, 2) i32 @main() local_unnamed_addr #3 {
entry:
  ret i32 0
}

attributes #0 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind memory(read, inaccessiblemem: write) }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
