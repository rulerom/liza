	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_rtp_result.be16           ; -- Begin function liza_rtp_result.be16
	.p2align	2
_liza_rtp_result.be16:                  ; @liza_rtp_result.be16
; %bb.0:                                ; %b0
	cmp	w2, w1
	b.hs	LBB0_3
; %bb.1:                                ; %v3_ok
	mov	w8, w2
	add	x8, x8, #1
	cmp	w8, w1
	b.hs	LBB0_3
; %bb.2:                                ; %v7_ok
	ldrb	w8, [x0, x8]
	ldrb	w9, [x0, w2, uxtw]
	orr	w0, w8, w9, lsl #8
	ret
LBB0_3:                                 ; %v0_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_rtp_result.be32           ; -- Begin function liza_rtp_result.be32
	.p2align	2
_liza_rtp_result.be32:                  ; @liza_rtp_result.be32
; %bb.0:                                ; %b0
	cmp	w2, w1
	b.hs	LBB1_5
; %bb.1:                                ; %v3_ok.i
	mov	w9, w2
	add	x10, x9, #1
	cmp	w10, w1
	b.hs	LBB1_5
; %bb.2:                                ; %liza_rtp_result.be16.exit
	add	x8, x9, #2
	cmp	w8, w1
	b.hs	LBB1_5
; %bb.3:                                ; %v3_ok.i4
	add	x11, x9, #3
	cmp	w11, w1
	b.hs	LBB1_5
; %bb.4:                                ; %liza_rtp_result.be16.exit19
	ldrb	w9, [x0, x9]
	ldrb	w10, [x0, x10]
	ldrb	w11, [x0, x11]
	ldrb	w8, [x0, x8]
	lsl	w9, w9, #24
	orr	w9, w9, w10, lsl #16
	orr	w9, w9, w11
	orr	w0, w9, w8, lsl #8
	ret
LBB1_5:                                 ; %v0_trap.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza_rtp_result.parse_rtp      ; -- Begin function liza_rtp_result.parse_rtp
	.p2align	2
_liza_rtp_result.parse_rtp:             ; @liza_rtp_result.parse_rtp
; %bb.0:                                ; %b0
	cmp	w1, #11
	b.hi	LBB2_3
; %bb.1:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w14, wzr
LBB2_2:                                 ; %common.ret
	mov	w17, #1                         ; =0x1
	b	LBB2_7
LBB2_3:                                 ; %b3
	ldrsb	w9, [x0]
	cmn	w9, #65
	b.gt	LBB2_6
; %bb.4:                                ; %v20_ok
	and	x10, x9, #0xff
	ubfiz	x11, x10, #2, #4
	add	x2, x11, #12
	cmp	w1, w2
	b.hs	LBB2_8
; %bb.5:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w14, #2                         ; =0x2
	b	LBB2_2
LBB2_6:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w17, #1                         ; =0x1
	mov	w14, #1                         ; =0x1
LBB2_7:                                 ; %common.ret
	strb	w9, [x8, #4]
	and	w9, w11, #0x1
	str	w17, [x8]
	strb	w12, [x8, #6]
	strb	w9, [x8, #5]
	strh	w13, [x8, #8]
	stp	w15, w16, [x8, #12]
	stp	w1, w10, [x8, #20]
	str	w14, [x8, #28]
	ret
LBB2_8:                                 ; %v27_ok
	tbnz	w10, #4, LBB2_16
; %bb.9:                                ; %b18
	subs	w10, w1, w2
	b.lo	LBB2_23
LBB2_10:                                ; %v58_ok
	and	w9, w9, #0xff
	tbz	w9, #5, LBB2_15
; %bb.11:                               ; %b19
	mov	w9, wzr
	cbz	w10, LBB2_24
; %bb.12:                               ; %b23
	sub	w11, w1, #1
	mov	w14, #4                         ; =0x4
	mov	w17, #1                         ; =0x1
	ldrb	w11, [x0, w11, uxtw]
	cbz	w11, LBB2_25
; %bb.13:                               ; %b23
	subs	w3, w10, w11
	mov	w11, w9
	mov	w12, w9
	mov	w13, w9
	mov	w15, w9
	mov	w16, w9
	mov	w1, w9
	mov	w10, w9
	b.lo	LBB2_7
; %bb.14:                               ; %b29
	mov	w10, w3
LBB2_15:                                ; %v88_ok
	ldrb	w9, [x0, #1]
	mov	w17, wzr
	mov	w14, wzr
	ldp	w13, w16, [x0, #4]
	sxtb	w11, w9
	ldrh	w0, [x0, #2]
	and	w12, w9, #0x7f
	mov	w9, #2                          ; =0x2
	mov	w1, w2
	cmp	w11, #0
	rev	w15, w13
	rev	w16, w16
	cset	w11, lt
	rev16	w13, w0
	b	LBB2_7
LBB2_16:                                ; %b10
	subs	w10, w1, w2
	b.lo	LBB2_23
; %bb.17:                               ; %v33_ok
	subs	w10, w10, #4
	b.lo	LBB2_21
; %bb.18:                               ; %v40_ok
	orr	x11, x2, #0x2
	cmp	w11, w1
	b.hs	LBB2_23
; %bb.19:                               ; %v3_ok.i
	mov	w12, w2
	orr	x12, x12, #0x3
	cmp	w12, w1
	b.hs	LBB2_23
; %bb.20:                               ; %liza_rtp_result.be16.exit
	ldrb	w11, [x0, x11]
	ldrb	w12, [x0, x12]
	lsl	w11, w11, #10
	orr	w11, w11, w12, lsl #2
	cmp	w11, w10
	b.ls	LBB2_22
LBB2_21:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w14, #3                         ; =0x3
	b	LBB2_2
LBB2_22:                                ; %v52_ok
	add	w10, w2, w11
	add	w2, w10, #4
	subs	w10, w1, w2
	b.hs	LBB2_10
LBB2_23:                                ; %v33_trap
	brk	#0x1
LBB2_24:
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w14, #4                         ; =0x4
	b	LBB2_2
LBB2_25:
	mov	w11, w9
	mov	w12, w9
	mov	w13, w9
	mov	w15, w9
	mov	w16, w9
	mov	w1, w9
	mov	w10, w9
	b	LBB2_7
                                        ; -- End function
	.globl	_liza_rtp_result.rtp_inspect    ; -- Begin function liza_rtp_result.rtp_inspect
	.p2align	2
_liza_rtp_result.rtp_inspect:           ; @liza_rtp_result.rtp_inspect
; %bb.0:                                ; %b0
	cmp	w1, #12
	b.hs	LBB3_2
; %bb.1:
	mov	w8, wzr
	mov	w9, wzr
	mov	w10, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w1, wzr
	mov	w0, wzr
	mov	w14, wzr
	mov	w15, #1                         ; =0x1
	b	LBB3_6
LBB3_2:                                 ; %b3.i
	ldrsb	w8, [x0]
	cmn	w8, #65
	b.gt	LBB3_5
; %bb.3:                                ; %v20_ok.i
	and	x9, x8, #0xff
	ubfiz	x10, x9, #2, #4
	add	x16, x10, #12
	cmp	w1, w16
	b.hs	LBB3_18
; %bb.4:
	mov	w8, wzr
	mov	w9, wzr
	mov	w10, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w1, wzr
	mov	w0, wzr
	mov	w14, #2                         ; =0x2
	mov	w15, #1                         ; =0x1
	b	LBB3_6
LBB3_5:
	mov	w8, wzr
	mov	w9, wzr
	mov	w10, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w1, wzr
	mov	w0, wzr
	mov	w15, #1                         ; =0x1
	mov	w14, #1                         ; =0x1
LBB3_6:                                 ; %liza_rtp_result.parse_rtp.exit
	cbz	w15, LBB3_9
; %bb.7:                                ; %b27
	mov	w8, #-2147483647                ; =0x80000001
	add	w0, w14, w8
LBB3_8:                                 ; %common.ret
	ret
LBB3_9:                                 ; %b2
	cmp	w2, #2
	b.le	LBB3_14
; %bb.10:                               ; %b2
	cmp	w2, #4
	b.gt	LBB3_26
; %bb.11:                               ; %b2
	cmp	w2, #3
	b.eq	LBB3_36
; %bb.12:                               ; %b2
	cmp	w2, #4
	b.ne	LBB3_8
; %bb.13:                               ; %b18
	mov	w0, w12
	ret
LBB3_14:                                ; %b2
	cbz	w2, LBB3_35
; %bb.15:                               ; %b2
	cmp	w2, #1
	b.eq	LBB3_38
; %bb.16:                               ; %b2
	cmp	w2, #2
	b.ne	LBB3_8
; %bb.17:                               ; %v15_ok
	and	w0, w10, #0xff
	ret
LBB3_18:                                ; %v27_ok.i
	tbnz	w9, #4, LBB3_29
; %bb.19:
	mov	x17, x0
	subs	w0, w1, w16
	b.lo	LBB3_40
LBB3_20:                                ; %v58_ok.i
	and	w8, w8, #0xff
	tbz	w8, #5, LBB3_25
; %bb.21:                               ; %b19.i
	mov	w8, wzr
	cbz	w0, LBB3_41
; %bb.22:                               ; %b23.i
	sub	w9, w1, #1
	mov	w14, #4                         ; =0x4
	mov	w15, #1                         ; =0x1
	ldrb	w9, [x17, w9, uxtw]
	cbz	w9, LBB3_42
; %bb.23:                               ; %b23.i
	subs	w3, w0, w9
	mov	w9, w8
	mov	w10, w8
	mov	w11, w8
	mov	w12, w8
	mov	w13, w8
	mov	w1, w8
	mov	w0, w8
	b.lo	LBB3_6
; %bb.24:                               ; %b29.i
	mov	w0, w3
LBB3_25:                                ; %v88_ok.i
	ldrb	w8, [x17, #1]
	mov	w15, wzr
	mov	w14, wzr
	ldp	w11, w13, [x17, #4]
	sxtb	w9, w8
	ldrh	w17, [x17, #2]
	and	w10, w8, #0x7f
	mov	w8, #2                          ; =0x2
	mov	w1, w16
	cmp	w9, #0
	rev	w12, w11
	rev	w13, w13
	cset	w9, lt
	rev16	w11, w17
	b	LBB3_6
LBB3_26:                                ; %b2
	cmp	w2, #5
	b.eq	LBB3_37
; %bb.27:                               ; %b2
	cmp	w2, #6
	b.ne	LBB3_8
; %bb.28:                               ; %b24
	mov	w0, w1
	ret
LBB3_29:                                ; %b10.i
	subs	w9, w1, w16
	b.lo	LBB3_40
; %bb.30:                               ; %v33_ok.i
	subs	w9, w9, #4
	b.lo	LBB3_34
; %bb.31:                               ; %v40_ok.i
	orr	x10, x16, #0x2
	cmp	w10, w1
	b.hs	LBB3_40
; %bb.32:                               ; %v3_ok.i.i
	mov	w11, w16
	orr	x11, x11, #0x3
	cmp	w11, w1
	b.hs	LBB3_40
; %bb.33:                               ; %liza_rtp_result.be16.exit.i
	ldrb	w10, [x0, x10]
	ldrb	w11, [x0, x11]
	lsl	w10, w10, #10
	orr	w10, w10, w11, lsl #2
	cmp	w10, w9
	b.ls	LBB3_39
LBB3_34:
	mov	w8, wzr
	mov	w9, wzr
	mov	w10, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w1, wzr
	mov	w0, wzr
	mov	w14, #3                         ; =0x3
	mov	w15, #1                         ; =0x1
	b	LBB3_6
LBB3_35:                                ; %v6_ok
	and	w0, w8, #0xff
	ret
LBB3_36:                                ; %v19_ok
	and	w0, w11, #0xffff
	ret
LBB3_37:                                ; %b21
	mov	w0, w13
	ret
LBB3_38:                                ; %b6
	and	w0, w9, #0x1
	ret
LBB3_39:                                ; %v52_ok.i
	add	w9, w16, w10
	mov	x17, x0
	add	w16, w9, #4
	subs	w0, w1, w16
	b.hs	LBB3_20
LBB3_40:                                ; %v33_trap.i
	brk	#0x1
LBB3_41:
	mov	w9, wzr
	mov	w10, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w1, wzr
	mov	w14, #4                         ; =0x4
	mov	w15, #1                         ; =0x1
	b	LBB3_6
LBB3_42:
	mov	w9, w8
	mov	w10, w8
	mov	w11, w8
	mov	w12, w8
	mov	w13, w8
	mov	w1, w8
	mov	w0, w8
	b	LBB3_6
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
; %bb.0:                                ; %b18.i.i
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
; %bb.0:                                ; %entry
	mov	w0, wzr
	ret
                                        ; -- End function
.subsections_via_symbols
