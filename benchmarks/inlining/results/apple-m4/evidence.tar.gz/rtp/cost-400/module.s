	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_rtp_result.be16           ; -- Begin function liza_rtp_result.be16
	.p2align	2
_liza_rtp_result.be16:                  ; @liza_rtp_result.be16
; %bb.0:                                ; %b0
	cmp	w2, w1
	b.hs	LBB0_3
; %bb.1:                                ; %v3_ok
	mov	w8, w2
	add	x8, x8, #1
	cmp	w8, w1
	b.hs	LBB0_3
; %bb.2:                                ; %v7_ok
	ldrb	w8, [x0, x8]
	ldrb	w9, [x0, w2, uxtw]
	orr	w0, w8, w9, lsl #8
	ret
LBB0_3:                                 ; %v0_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_rtp_result.be32           ; -- Begin function liza_rtp_result.be32
	.p2align	2
_liza_rtp_result.be32:                  ; @liza_rtp_result.be32
; %bb.0:                                ; %b0
	cmp	w2, w1
	b.hs	LBB1_5
; %bb.1:                                ; %v3_ok.i
	mov	w9, w2
	add	x10, x9, #1
	cmp	w10, w1
	b.hs	LBB1_5
; %bb.2:                                ; %liza_rtp_result.be16.exit
	add	x8, x9, #2
	cmp	w8, w1
	b.hs	LBB1_5
; %bb.3:                                ; %v3_ok.i4
	add	x11, x9, #3
	cmp	w11, w1
	b.hs	LBB1_5
; %bb.4:                                ; %liza_rtp_result.be16.exit19
	ldrb	w9, [x0, x9]
	ldrb	w10, [x0, x10]
	ldrb	w11, [x0, x11]
	ldrb	w8, [x0, x8]
	lsl	w9, w9, #24
	orr	w9, w9, w10, lsl #16
	orr	w9, w9, w11
	orr	w0, w9, w8, lsl #8
	ret
LBB1_5:                                 ; %v0_trap.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza_rtp_result.parse_rtp      ; -- Begin function liza_rtp_result.parse_rtp
	.p2align	2
_liza_rtp_result.parse_rtp:             ; @liza_rtp_result.parse_rtp
; %bb.0:                                ; %b0
	cmp	w1, #11
	b.hi	LBB2_3
; %bb.1:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w14, wzr
LBB2_2:                                 ; %common.ret
	mov	w17, #1                         ; =0x1
	b	LBB2_7
LBB2_3:                                 ; %b3
	ldrsb	w9, [x0]
	cmn	w9, #65
	b.gt	LBB2_6
; %bb.4:                                ; %v20_ok
	and	x10, x9, #0xff
	ubfiz	x11, x10, #2, #4
	add	x2, x11, #12
	cmp	w1, w2
	b.hs	LBB2_8
; %bb.5:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w14, #2                         ; =0x2
	b	LBB2_2
LBB2_6:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w17, #1                         ; =0x1
	mov	w14, #1                         ; =0x1
LBB2_7:                                 ; %common.ret
	strb	w9, [x8, #4]
	and	w9, w11, #0x1
	str	w17, [x8]
	strb	w12, [x8, #6]
	strb	w9, [x8, #5]
	strh	w13, [x8, #8]
	stp	w15, w16, [x8, #12]
	stp	w1, w10, [x8, #20]
	str	w14, [x8, #28]
	ret
LBB2_8:                                 ; %v27_ok
	tbnz	w10, #4, LBB2_16
; %bb.9:                                ; %b18
	subs	w10, w1, w2
	b.lo	LBB2_23
LBB2_10:                                ; %v58_ok
	and	w9, w9, #0xff
	tbz	w9, #5, LBB2_15
; %bb.11:                               ; %b19
	mov	w9, wzr
	cbz	w10, LBB2_24
; %bb.12:                               ; %b23
	sub	w11, w1, #1
	mov	w14, #4                         ; =0x4
	mov	w17, #1                         ; =0x1
	ldrb	w11, [x0, w11, uxtw]
	cbz	w11, LBB2_25
; %bb.13:                               ; %b23
	subs	w3, w10, w11
	mov	w11, w9
	mov	w12, w9
	mov	w13, w9
	mov	w15, w9
	mov	w16, w9
	mov	w1, w9
	mov	w10, w9
	b.lo	LBB2_7
; %bb.14:                               ; %b29
	mov	w10, w3
LBB2_15:                                ; %v88_ok
	ldrb	w9, [x0, #1]
	mov	w17, wzr
	mov	w14, wzr
	ldp	w13, w16, [x0, #4]
	sxtb	w11, w9
	ldrh	w0, [x0, #2]
	and	w12, w9, #0x7f
	mov	w9, #2                          ; =0x2
	mov	w1, w2
	cmp	w11, #0
	rev	w15, w13
	rev	w16, w16
	cset	w11, lt
	rev16	w13, w0
	b	LBB2_7
LBB2_16:                                ; %b10
	subs	w10, w1, w2
	b.lo	LBB2_23
; %bb.17:                               ; %v33_ok
	subs	w10, w10, #4
	b.lo	LBB2_21
; %bb.18:                               ; %v40_ok
	orr	x11, x2, #0x2
	cmp	w11, w1
	b.hs	LBB2_23
; %bb.19:                               ; %v3_ok.i
	mov	w12, w2
	orr	x12, x12, #0x3
	cmp	w12, w1
	b.hs	LBB2_23
; %bb.20:                               ; %liza_rtp_result.be16.exit
	ldrb	w11, [x0, x11]
	ldrb	w12, [x0, x12]
	lsl	w11, w11, #10
	orr	w11, w11, w12, lsl #2
	cmp	w11, w10
	b.ls	LBB2_22
LBB2_21:
	mov	w9, wzr
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w10, wzr
	mov	w14, #3                         ; =0x3
	b	LBB2_2
LBB2_22:                                ; %v52_ok
	add	w10, w2, w11
	add	w2, w10, #4
	subs	w10, w1, w2
	b.hs	LBB2_10
LBB2_23:                                ; %v33_trap
	brk	#0x1
LBB2_24:
	mov	w11, wzr
	mov	w12, wzr
	mov	w13, wzr
	mov	w15, wzr
	mov	w16, wzr
	mov	w1, wzr
	mov	w14, #4                         ; =0x4
	b	LBB2_2
LBB2_25:
	mov	w11, w9
	mov	w12, w9
	mov	w13, w9
	mov	w15, w9
	mov	w16, w9
	mov	w1, w9
	mov	w10, w9
	b	LBB2_7
                                        ; -- End function
	.globl	_liza_rtp_result.rtp_inspect    ; -- Begin function liza_rtp_result.rtp_inspect
	.p2align	2
_liza_rtp_result.rtp_inspect:           ; @liza_rtp_result.rtp_inspect
; %bb.0:                                ; %b0
	sub	sp, sp, #64
	mov	x8, sp
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	mov	w19, w2
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	bl	_liza_rtp_result.parse_rtp
	ldr	w8, [sp]
	cbz	w8, LBB3_3
; %bb.1:                                ; %b27
	ldr	w8, [sp, #28]
	mov	w9, #-2147483647                ; =0x80000001
	add	w0, w8, w9
LBB3_2:                                 ; %common.ret
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB3_3:                                 ; %b2
	ldr	w0, [sp, #24]
	cmp	w19, #2
	b.le	LBB3_8
; %bb.4:                                ; %b2
	cmp	w19, #4
	b.gt	LBB3_12
; %bb.5:                                ; %b2
	cmp	w19, #3
	b.eq	LBB3_16
; %bb.6:                                ; %b2
	cmp	w19, #4
	b.ne	LBB3_2
; %bb.7:                                ; %b18
	ldr	w0, [sp, #12]
	b	LBB3_2
LBB3_8:                                 ; %b2
	cbz	w19, LBB3_15
; %bb.9:                                ; %b2
	cmp	w19, #1
	b.eq	LBB3_18
; %bb.10:                               ; %b2
	cmp	w19, #2
	b.ne	LBB3_2
; %bb.11:                               ; %v15_ok
	ldrb	w8, [sp, #6]
	and	w0, w8, #0xff
	b	LBB3_2
LBB3_12:                                ; %b2
	cmp	w19, #5
	b.eq	LBB3_17
; %bb.13:                               ; %b2
	cmp	w19, #6
	b.ne	LBB3_2
; %bb.14:                               ; %b24
	ldr	w0, [sp, #20]
	b	LBB3_2
LBB3_15:                                ; %v6_ok
	ldrb	w8, [sp, #4]
	and	w0, w8, #0xff
	b	LBB3_2
LBB3_16:                                ; %v19_ok
	ldrh	w8, [sp, #8]
	and	w0, w8, #0xffff
	b	LBB3_2
LBB3_17:                                ; %b21
	ldr	w0, [sp, #16]
	b	LBB3_2
LBB3_18:                                ; %b6
	ldrb	w8, [sp, #5]
	and	w0, w8, #0x1
	b	LBB3_2
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
; %bb.0:                                ; %b18.i
	mov	w0, wzr
	ret
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
; %bb.0:                                ; %entry
	mov	w0, wzr
	ret
                                        ; -- End function
.subsections_via_symbols
