; ModuleID = '/private/tmp/liza-inlining-p1-final/growth/default/module.ll'
source_filename = "/private/tmp/liza-inlining-p1-final/growth/default/module.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_mix(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = and i32 %p0, 1
  %v3.not = icmp eq i32 %v1, 0
  %v8.v = select i1 %v3.not, i32 45678, i32 12345
  %v8 = xor i32 %v8.v, %p0
  %v10 = and i32 %v8, 2
  %v12.not = icmp eq i32 %v10, 0
  %v17.v = select i1 %v12.not, i32 46669, i32 13342
  %v17 = xor i32 %v17.v, %v8
  %v19 = and i32 %v17, 4
  %v21.not = icmp eq i32 %v19, 0
  %v26.v = select i1 %v21.not, i32 47660, i32 14339
  %v26 = xor i32 %v26.v, %v17
  %v28 = and i32 %v26, 8
  %v30.not = icmp eq i32 %v28, 0
  %v35.v = select i1 %v30.not, i32 48651, i32 15336
  %v37 = and i32 %v17, 16
  %v39.not = icmp eq i32 %v37, 0
  %v44.v = select i1 %v39.not, i32 49642, i32 16333
  %0 = xor i32 %v44.v, %v35.v
  %v44 = xor i32 %0, %v26
  %v46 = and i32 %v44, 32
  %v48.not = icmp eq i32 %v46, 0
  %v53.v = select i1 %v48.not, i32 50633, i32 17330
  %v53 = xor i32 %v53.v, %v44
  %v55 = and i32 %v53, 64
  %v57.not = icmp eq i32 %v55, 0
  %v62.v = select i1 %v57.not, i32 51624, i32 18327
  %v62 = xor i32 %v62.v, %v53
  %v64 = and i32 %v62, 128
  %v66.not = icmp eq i32 %v64, 0
  %v71.v = select i1 %v66.not, i32 52615, i32 19324
  %v71 = xor i32 %v71.v, %v62
  %v73 = and i32 %v71, 256
  %v75.not = icmp eq i32 %v73, 0
  %v80.v = select i1 %v75.not, i32 53606, i32 20321
  %v80 = xor i32 %v80.v, %v71
  %v82 = and i32 %v80, 512
  %v84.not = icmp eq i32 %v82, 0
  %v89.v = select i1 %v84.not, i32 54597, i32 21318
  %v89 = xor i32 %v89.v, %v80
  %v91 = and i32 %v89, 1024
  %v93.not = icmp eq i32 %v91, 0
  %v98.v = select i1 %v93.not, i32 55588, i32 22315
  %v98 = xor i32 %v98.v, %v89
  %v100 = and i32 %v98, 2048
  %v102.not = icmp eq i32 %v100, 0
  %v107.v = select i1 %v102.not, i32 56579, i32 23312
  %v107 = xor i32 %v107.v, %v98
  %v109 = and i32 %v107, 4096
  %v111.not = icmp eq i32 %v109, 0
  %v116.v = select i1 %v111.not, i32 57570, i32 24309
  %v116 = xor i32 %v116.v, %v107
  %v118 = and i32 %v116, 8192
  %v120.not = icmp eq i32 %v118, 0
  %v125.v = select i1 %v120.not, i32 58561, i32 25306
  %v125 = xor i32 %v125.v, %v116
  %v127 = and i32 %v125, 16384
  %v129.not = icmp eq i32 %v127, 0
  %v134.v = select i1 %v129.not, i32 59552, i32 26303
  %v134 = xor i32 %v134.v, %v125
  %v136 = and i32 %v134, 32768
  %v138.not = icmp eq i32 %v136, 0
  %v143.v = select i1 %v138.not, i32 60543, i32 27300
  %v143 = xor i32 %v143.v, %v134
  %v145 = and i32 %v143, 1
  %v147.not = icmp eq i32 %v145, 0
  %v152.v = select i1 %v147.not, i32 61534, i32 28297
  %v152 = xor i32 %v152.v, %v143
  %v154 = and i32 %v152, 2
  %v156.not = icmp eq i32 %v154, 0
  %v161.v = select i1 %v156.not, i32 62525, i32 29294
  %v161 = xor i32 %v161.v, %v152
  %v163 = and i32 %v161, 4
  %v165.not = icmp eq i32 %v163, 0
  %v170.v = select i1 %v165.not, i32 63516, i32 30291
  %v170 = xor i32 %v170.v, %v161
  %v172 = and i32 %v170, 8
  %v174.not = icmp eq i32 %v172, 0
  %v179.v = select i1 %v174.not, i32 64507, i32 31288
  %v179 = xor i32 %v179.v, %v170
  %v181 = and i32 %v179, 16
  %v183.not = icmp eq i32 %v181, 0
  %v188.v = select i1 %v183.not, i32 65498, i32 32285
  %v190 = and i32 %v179, 32
  %v192.not = icmp eq i32 %v190, 0
  %v197.v = select i1 %v192.not, i32 66489, i32 33282
  %1 = xor i32 %v197.v, %v188.v
  %v197 = xor i32 %1, %v179
  %v199 = and i32 %v197, 64
  %v201.not = icmp eq i32 %v199, 0
  %v206.v = select i1 %v201.not, i32 67480, i32 34279
  %v206 = xor i32 %v206.v, %v197
  %v208 = and i32 %v206, 128
  %v210.not = icmp eq i32 %v208, 0
  %v215.v = select i1 %v210.not, i32 68471, i32 35276
  %v215 = xor i32 %v215.v, %v206
  %v217 = and i32 %v215, 256
  %v219.not = icmp eq i32 %v217, 0
  %v224.v = select i1 %v219.not, i32 69462, i32 36273
  %v224 = xor i32 %v224.v, %v215
  %v226 = and i32 %v224, 512
  %v228.not = icmp eq i32 %v226, 0
  %v233.v = select i1 %v228.not, i32 70453, i32 37270
  %v235 = and i32 %v224, 1024
  %v237.not = icmp eq i32 %v235, 0
  %v242.v = select i1 %v237.not, i32 71444, i32 38267
  %v244 = and i32 %v224, 2048
  %v246.not = icmp eq i32 %v244, 0
  %v251.v = select i1 %v246.not, i32 72435, i32 39264
  %2 = xor i32 %v242.v, %v233.v
  %3 = xor i32 %2, %v251.v
  %v251 = xor i32 %3, %v224
  %v253 = and i32 %v251, 4096
  %v255.not = icmp eq i32 %v253, 0
  %v260.v = select i1 %v255.not, i32 73426, i32 40261
  %v262 = and i32 %v197, 8192
  %v264.not = icmp eq i32 %v262, 0
  %v269.v = select i1 %v264.not, i32 74417, i32 41258
  %v271 = and i32 %v197, 16384
  %v273.not = icmp eq i32 %v271, 0
  %v278.v = select i1 %v273.not, i32 75408, i32 42255
  %4 = xor i32 %v278.v, %v269.v
  %5 = xor i32 %4, %v260.v
  %v278 = xor i32 %5, %v251
  %v280 = and i32 %v278, 32768
  %v282.not = icmp eq i32 %v280, 0
  %v287.v = select i1 %v282.not, i32 76399, i32 43252
  %v287 = xor i32 %v287.v, %v278
  %v289 = and i32 %v287, 1
  %v291.not = icmp eq i32 %v289, 0
  %v296.v = select i1 %v291.not, i32 77390, i32 44249
  %v296 = xor i32 %v296.v, %v287
  %v298 = and i32 %v296, 2
  %v300.not = icmp eq i32 %v298, 0
  %v305.v = select i1 %v300.not, i32 78381, i32 45246
  %v305 = xor i32 %v305.v, %v296
  %v307 = and i32 %v305, 4
  %v309.not = icmp eq i32 %v307, 0
  %v314.v = select i1 %v309.not, i32 79372, i32 46243
  %v314 = xor i32 %v314.v, %v305
  %v316 = and i32 %v314, 8
  %v318.not = icmp eq i32 %v316, 0
  %v323.v = select i1 %v318.not, i32 80363, i32 47240
  %v325 = and i32 %v305, 16
  %v327.not = icmp eq i32 %v325, 0
  %v332.v = select i1 %v327.not, i32 81354, i32 48237
  %6 = xor i32 %v332.v, %v323.v
  %v332 = xor i32 %6, %v314
  %v334 = and i32 %v332, 32
  %v336.not = icmp eq i32 %v334, 0
  %v341.v = select i1 %v336.not, i32 82345, i32 49234
  %v341 = xor i32 %v341.v, %v332
  %v343 = and i32 %v341, 64
  %v345.not = icmp eq i32 %v343, 0
  %v350.v = select i1 %v345.not, i32 83336, i32 50231
  %v350 = xor i32 %v350.v, %v341
  %v352 = and i32 %v350, 128
  %v354.not = icmp eq i32 %v352, 0
  %v359.v = select i1 %v354.not, i32 84327, i32 51228
  %v359 = xor i32 %v359.v, %v350
  %v361 = and i32 %v359, 256
  %v363.not = icmp eq i32 %v361, 0
  %v368.v = select i1 %v363.not, i32 85318, i32 52225
  %v370 = and i32 %v314, 512
  %v372.not = icmp eq i32 %v370, 0
  %v377.v = select i1 %v372.not, i32 86309, i32 53222
  %7 = xor i32 %v377.v, %v368.v
  %v377 = xor i32 %7, %v359
  %v379 = and i32 %v377, 1024
  %v381.not = icmp eq i32 %v379, 0
  %v386.v = select i1 %v381.not, i32 87300, i32 54219
  %v388 = and i32 %v377, 2048
  %v390.not = icmp eq i32 %v388, 0
  %v395.v = select i1 %v390.not, i32 88291, i32 55216
  %v397 = and i32 %v377, 4096
  %v399.not = icmp eq i32 %v397, 0
  %v404.v = select i1 %v399.not, i32 89282, i32 56213
  %v406 = and i32 %v314, 8192
  %v408.not = icmp eq i32 %v406, 0
  %v413.v = select i1 %v408.not, i32 90273, i32 57210
  %v415 = and i32 %v359, 16384
  %v417.not = icmp eq i32 %v415, 0
  %v422.v = select i1 %v417.not, i32 91264, i32 58207
  %8 = xor i32 %v422.v, %v413.v
  %9 = xor i32 %8, %v395.v
  %10 = xor i32 %9, %v386.v
  %11 = xor i32 %10, %v404.v
  %v422 = xor i32 %11, %v377
  %v424 = and i32 %v422, 32768
  %v426.not = icmp eq i32 %v424, 0
  %v431.v = select i1 %v426.not, i32 92255, i32 59204
  %v431 = xor i32 %v431.v, %v422
  %v433 = and i32 %v431, 1
  %v435.not = icmp eq i32 %v433, 0
  %v440.v = select i1 %v435.not, i32 93246, i32 60201
  %v440 = xor i32 %v440.v, %v431
  %v442 = and i32 %v440, 2
  %v444.not = icmp eq i32 %v442, 0
  %v449.v = select i1 %v444.not, i32 94237, i32 61198
  %v449 = xor i32 %v449.v, %v440
  %v451 = and i32 %v449, 4
  %v453.not = icmp eq i32 %v451, 0
  %v458.v = select i1 %v453.not, i32 95228, i32 62195
  %v458 = xor i32 %v458.v, %v449
  %v460 = and i32 %v458, 8
  %v462.not = icmp eq i32 %v460, 0
  %v467.v = select i1 %v462.not, i32 96219, i32 63192
  %v467 = xor i32 %v467.v, %v458
  %v469 = and i32 %v467, 16
  %v471.not = icmp eq i32 %v469, 0
  %v476.v = select i1 %v471.not, i32 97210, i32 64189
  %v476 = xor i32 %v476.v, %v467
  %v478 = and i32 %v476, 32
  %v480.not = icmp eq i32 %v478, 0
  %v485.v = select i1 %v480.not, i32 98201, i32 65186
  %v487 = and i32 %v467, 64
  %v489.not = icmp eq i32 %v487, 0
  %v494.v = select i1 %v489.not, i32 99192, i32 66183
  %12 = xor i32 %v494.v, %v485.v
  %v494 = xor i32 %12, %v476
  %v496 = and i32 %v494, 128
  %v498.not = icmp eq i32 %v496, 0
  %v503.v = select i1 %v498.not, i32 100183, i32 67180
  %v503 = xor i32 %v503.v, %v494
  %v505 = and i32 %v503, 256
  %v507.not = icmp eq i32 %v505, 0
  %v512.v = select i1 %v507.not, i32 101174, i32 68177
  %v512 = xor i32 %v512.v, %v503
  %v514 = and i32 %v512, 512
  %v516.not = icmp eq i32 %v514, 0
  %v521.v = select i1 %v516.not, i32 102165, i32 69174
  %v521 = xor i32 %v521.v, %v512
  %v523 = and i32 %v521, 1024
  %v525.not = icmp eq i32 %v523, 0
  %v530.v = select i1 %v525.not, i32 103156, i32 70171
  %v532 = and i32 %v521, 2048
  %v534.not = icmp eq i32 %v532, 0
  %v539.v = select i1 %v534.not, i32 104147, i32 71168
  %v541 = and i32 %v494, 4096
  %v543.not = icmp eq i32 %v541, 0
  %v548.v = select i1 %v543.not, i32 105138, i32 72165
  %v550 = and i32 %v494, 8192
  %v552.not = icmp eq i32 %v550, 0
  %v557.v = select i1 %v552.not, i32 106129, i32 73162
  %v559 = and i32 %v494, 16384
  %v561.not = icmp eq i32 %v559, 0
  %v566.v = select i1 %v561.not, i32 107120, i32 74159
  %13 = xor i32 %v557.v, %v548.v
  %14 = xor i32 %13, %v566.v
  %15 = xor i32 %14, %v539.v
  %16 = xor i32 %15, %v530.v
  %v566 = xor i32 %16, %v521
  %v568 = and i32 %v566, 32768
  %v570.not = icmp eq i32 %v568, 0
  %v575.v = select i1 %v570.not, i32 108111, i32 75156
  %v575 = xor i32 %v575.v, %v566
  ret i32 %v575
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_0(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 1
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_1(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 2
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_2(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 3
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_3(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 4
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_4(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 5
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_5(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 6
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_6(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 7
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_7(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 8
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_8(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 9
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_9(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 10
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_10(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 11
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_11(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 12
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_12(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 13
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_13(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 14
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_14(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 15
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_15(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 16
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_16(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 17
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_17(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 18
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_18(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 19
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_19(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 20
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_20(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 21
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_21(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 22
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_22(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 23
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_23(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 24
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_24(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 25
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_25(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 26
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_26(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 27
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_27(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 28
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_28(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 29
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_29(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 30
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_30(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 31
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_31(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 32
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_32(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 33
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_33(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 34
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_34(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 35
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_35(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 36
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_36(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 37
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_37(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 38
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_38(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 39
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_39(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 40
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_40(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 41
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_41(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 42
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_42(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 43
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_43(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 44
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_44(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 45
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_45(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 46
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_46(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 47
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i32 @liza_caller_47(i32 %p0) local_unnamed_addr #0 {
b0:
  %v1 = xor i32 %p0, 48
  %v2 = tail call i32 @liza_mix(i32 %v1)
  ret i32 %v2
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @liza_main() local_unnamed_addr #0 {
b0:
  ret i32 114219
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @main() local_unnamed_addr #0 {
entry:
  ret i32 114219
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
