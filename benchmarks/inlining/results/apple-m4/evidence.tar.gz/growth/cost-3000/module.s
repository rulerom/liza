	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_mix                       ; -- Begin function liza_mix
	.p2align	2
_liza_mix:                              ; @liza_mix
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w11, w10
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w12, w13
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_0                  ; -- Begin function liza_caller_0
	.p2align	2
_liza_caller_0:                         ; @liza_caller_0
; %bb.0:                                ; %b0
	mov	w8, #45678                      ; =0xb26e
	mov	w9, #12345                      ; =0x3039
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #28297                     ; =0x6e89
	eor	w8, w9, w8
	mov	w9, #61534                      ; =0xf05e
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w12, w13, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w12, w13, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w8, w8, w9
	eor	w0, w8, #0x1
	ret
                                        ; -- End function
	.globl	_liza_caller_1                  ; -- Begin function liza_caller_1
	.p2align	2
_liza_caller_1:                         ; @liza_caller_1
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #46669                      ; =0xb64d
	mov	w10, #13342                     ; =0x341e
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #29294                     ; =0x726e
	eor	w8, w9, w8
	mov	w9, #62525                      ; =0xf43d
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w12, w13, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #61198                     ; =0xef0e
	eor	w11, w12, w11
	mov	w12, #28701                     ; =0x701d
	movk	w12, #1, lsl #16
	tst	w11, #0x2
	csel	w13, w13, w12, eq
	add	w14, w12, #991
	eor	w11, w13, w11
	mov	w13, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w13, w14, w13, eq
	add	w14, w12, #1982
	eor	w11, w13, w11
	mov	w13, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w13, w14, w13, eq
	add	w14, w12, #2973
	add	w12, w12, #3964
	eor	w11, w13, w11
	mov	w13, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w13, w14, w13, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w13, w13, w11
	tst	w13, #0x20
	csel	w12, w12, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w13
	add	w13, w15, #991
	eor	w11, w11, w12
	add	w12, w8, #997
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w8, w8, w9
	eor	w0, w8, #0x2
	ret
                                        ; -- End function
	.globl	_liza_caller_2                  ; -- Begin function liza_caller_2
	.p2align	2
_liza_caller_2:                         ; @liza_caller_2
; %bb.0:                                ; %b0
	eor	w8, w0, #0x3
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	tst	w8, #0x1
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x2
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_3                  ; -- Begin function liza_caller_3
	.p2align	2
_liza_caller_3:                         ; @liza_caller_3
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #14339                     ; =0x3803
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #47660                      ; =0xba2c
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #30291                     ; =0x7653
	eor	w8, w9, w8
	mov	w9, #63516                      ; =0xf81c
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	movk	w13, #1, lsl #16
	mov	w11, #46243                     ; =0xb4a3
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w11, w13, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w12, w14, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w8, w8, w9
	eor	w0, w8, #0x4
	ret
                                        ; -- End function
	.globl	_liza_caller_4                  ; -- Begin function liza_caller_4
	.p2align	2
_liza_caller_4:                         ; @liza_caller_4
; %bb.0:                                ; %b0
	mov	w8, #5                          ; =0x5
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_5                  ; -- Begin function liza_caller_5
	.p2align	2
_liza_caller_5:                         ; @liza_caller_5
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w8, #0x6
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x2
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_6                  ; -- Begin function liza_caller_6
	.p2align	2
_liza_caller_6:                         ; @liza_caller_6
; %bb.0:                                ; %b0
	eor	w8, w0, #0x7
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	tst	w8, #0x1
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x2
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_7                  ; -- Begin function liza_caller_7
	.p2align	2
_liza_caller_7:                         ; @liza_caller_7
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #15336                     ; =0x3be8
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #48651                     ; =0xbe0b
	eor	w9, w8, w9
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w8, w9
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w8, w9
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w8, w9
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w8, w9
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w8, w9
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w8, w9
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w8, w9
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w8, w9
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w8, w9
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w8, w9
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w8, w9
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w8, w9
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w8, w9
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #31288                     ; =0x7a38
	eor	w8, w8, w9
	mov	w9, #64507                      ; =0xfbfb
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w8, w9
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w11, w9
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w9, w10
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w12, w10, w12
	movk	w9, #1, lsl #16
	mov	w10, #38267                     ; =0x957b
	tst	w12, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w12, #0x400
	add	w17, w9, #3964
	csel	w10, w15, w10, eq
	tst	w12, #0x800
	mov	w15, #41258                     ; =0xa12a
	csel	w14, w16, w14, eq
	eor	w10, w13, w10
	mov	w13, #40261                     ; =0x9d45
	eor	w14, w10, w14
	mov	w10, #9620                      ; =0x2594
	add	w16, w9, #2973
	eor	w12, w12, w14
	movk	w10, #1, lsl #16
	mov	w14, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w13, w16, w13, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w15, w17, w15, eq
	tst	w11, #0x4000
	csel	w11, w16, w14, eq
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w13
	add	w13, w10, #1243
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w11, w12
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w11, w12
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w11, w12
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w12, w11
	tst	w11, #0x8
	csel	w14, w14, w16, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	eor	w12, w11, w12
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w12, w14
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w12, w13
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w12, w13
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	eor	w13, w12, w13
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w13, w11
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w11, w12
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w11, w12
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w11, w12
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w11, w12
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w12, w14, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w11, w12
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w11, w12
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w13
	add	w13, w15, #991
	eor	w11, w12, w11
	add	w12, w8, #997
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w11, w12
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w12, w13
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w12, w13
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	eor	w8, w12, w8
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w8, w8, w9
	eor	w0, w8, #0x8
	ret
                                        ; -- End function
	.globl	_liza_caller_8                  ; -- Begin function liza_caller_8
	.p2align	2
_liza_caller_8:                         ; @liza_caller_8
; %bb.0:                                ; %b0
	mov	w8, #9                          ; =0x9
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_9                  ; -- Begin function liza_caller_9
	.p2align	2
_liza_caller_9:                         ; @liza_caller_9
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #10                        ; =0xa
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_10                 ; -- Begin function liza_caller_10
	.p2align	2
_liza_caller_10:                        ; @liza_caller_10
; %bb.0:                                ; %b0
	mov	w8, #11                         ; =0xb
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_11                 ; -- Begin function liza_caller_11
	.p2align	2
_liza_caller_11:                        ; @liza_caller_11
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #47660                     ; =0xba2c
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #14339                     ; =0x3803
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	eor	w9, w8, #0xc
	tst	w9, #0x4
	csel	w10, w11, w10, eq
	mov	w11, #15336                     ; =0x3be8
	eor	w9, w10, w9
	mov	w10, #48651                     ; =0xbe0b
	tst	w9, #0x8
	csel	w10, w10, w11, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_12                 ; -- Begin function liza_caller_12
	.p2align	2
_liza_caller_12:                        ; @liza_caller_12
; %bb.0:                                ; %b0
	mov	w8, #13                         ; =0xd
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_13                 ; -- Begin function liza_caller_13
	.p2align	2
_liza_caller_13:                        ; @liza_caller_13
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w8, #0xe
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x2
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_14                 ; -- Begin function liza_caller_14
	.p2align	2
_liza_caller_14:                        ; @liza_caller_14
; %bb.0:                                ; %b0
	eor	w8, w0, #0xf
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	tst	w8, #0x1
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x2
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_15                 ; -- Begin function liza_caller_15
	.p2align	2
_liza_caller_15:                        ; @liza_caller_15
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w13, #16333                     ; =0x3fcd
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #32285                     ; =0x7e1d
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #65498                     ; =0xffda
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w15, w17, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w12, w14, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w8, w8, w9
	eor	w0, w8, #0x10
	ret
                                        ; -- End function
	.globl	_liza_caller_16                 ; -- Begin function liza_caller_16
	.p2align	2
_liza_caller_16:                        ; @liza_caller_16
; %bb.0:                                ; %b0
	mov	w8, #17                         ; =0x11
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_17                 ; -- Begin function liza_caller_17
	.p2align	2
_liza_caller_17:                        ; @liza_caller_17
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #18                        ; =0x12
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_18                 ; -- Begin function liza_caller_18
	.p2align	2
_liza_caller_18:                        ; @liza_caller_18
; %bb.0:                                ; %b0
	mov	w8, #19                         ; =0x13
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_19                 ; -- Begin function liza_caller_19
	.p2align	2
_liza_caller_19:                        ; @liza_caller_19
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #20                        ; =0x14
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	eor	w8, w8, w11
	mov	w11, #48651                     ; =0xbe0b
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w13, #49642                     ; =0xc1ea
	eor	w8, w8, w9
	mov	w9, #14339                      ; =0x3803
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x4
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_20                 ; -- Begin function liza_caller_20
	.p2align	2
_liza_caller_20:                        ; @liza_caller_20
; %bb.0:                                ; %b0
	mov	w8, #21                         ; =0x15
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_21                 ; -- Begin function liza_caller_21
	.p2align	2
_liza_caller_21:                        ; @liza_caller_21
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #22                        ; =0x16
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_22                 ; -- Begin function liza_caller_22
	.p2align	2
_liza_caller_22:                        ; @liza_caller_22
; %bb.0:                                ; %b0
	mov	w8, #23                         ; =0x17
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_23                 ; -- Begin function liza_caller_23
	.p2align	2
_liza_caller_23:                        ; @liza_caller_23
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	eor	w8, w8, #0x18
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_24                 ; -- Begin function liza_caller_24
	.p2align	2
_liza_caller_24:                        ; @liza_caller_24
; %bb.0:                                ; %b0
	mov	w8, #25                         ; =0x19
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_25                 ; -- Begin function liza_caller_25
	.p2align	2
_liza_caller_25:                        ; @liza_caller_25
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #26                        ; =0x1a
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_26                 ; -- Begin function liza_caller_26
	.p2align	2
_liza_caller_26:                        ; @liza_caller_26
; %bb.0:                                ; %b0
	mov	w8, #27                         ; =0x1b
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_27                 ; -- Begin function liza_caller_27
	.p2align	2
_liza_caller_27:                        ; @liza_caller_27
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w8, w9
	mov	w9, #14339                      ; =0x3803
	eor	w8, w8, #0x1c
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_28                 ; -- Begin function liza_caller_28
	.p2align	2
_liza_caller_28:                        ; @liza_caller_28
; %bb.0:                                ; %b0
	mov	w8, #29                         ; =0x1d
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_29                 ; -- Begin function liza_caller_29
	.p2align	2
_liza_caller_29:                        ; @liza_caller_29
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w8, #0x1e
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x2
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_30                 ; -- Begin function liza_caller_30
	.p2align	2
_liza_caller_30:                        ; @liza_caller_30
; %bb.0:                                ; %b0
	eor	w8, w0, #0x1f
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	tst	w8, #0x1
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	mov	w14, #39264                     ; =0x9960
	tst	w8, #0x2
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_31                 ; -- Begin function liza_caller_31
	.p2align	2
_liza_caller_31:                        ; @liza_caller_31
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #50633                      ; =0xc5c9
	eor	w8, w8, w10
	mov	w10, #17330                     ; =0x43b2
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w12, w13, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48205                     ; =0xbc4d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #2014
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_32                 ; -- Begin function liza_caller_32
	.p2align	2
_liza_caller_32:                        ; @liza_caller_32
; %bb.0:                                ; %b0
	mov	w8, #33                         ; =0x21
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_33                 ; -- Begin function liza_caller_33
	.p2align	2
_liza_caller_33:                        ; @liza_caller_33
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #34                        ; =0x22
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_34                 ; -- Begin function liza_caller_34
	.p2align	2
_liza_caller_34:                        ; @liza_caller_34
; %bb.0:                                ; %b0
	mov	w8, #35                         ; =0x23
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_35                 ; -- Begin function liza_caller_35
	.p2align	2
_liza_caller_35:                        ; @liza_caller_35
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #47660                     ; =0xba2c
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #36                        ; =0x24
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	eor	w9, w8, w10
	mov	w10, #14339                     ; =0x3803
	tst	w9, #0x4
	csel	w10, w11, w10, eq
	mov	w11, #15336                     ; =0x3be8
	eor	w9, w10, w9
	mov	w10, #48651                     ; =0xbe0b
	tst	w9, #0x8
	csel	w10, w10, w11, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_36                 ; -- Begin function liza_caller_36
	.p2align	2
_liza_caller_36:                        ; @liza_caller_36
; %bb.0:                                ; %b0
	mov	w8, #37                         ; =0x25
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_37                 ; -- Begin function liza_caller_37
	.p2align	2
_liza_caller_37:                        ; @liza_caller_37
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #38                        ; =0x26
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_38                 ; -- Begin function liza_caller_38
	.p2align	2
_liza_caller_38:                        ; @liza_caller_38
; %bb.0:                                ; %b0
	mov	w8, #39                         ; =0x27
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_39                 ; -- Begin function liza_caller_39
	.p2align	2
_liza_caller_39:                        ; @liza_caller_39
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #40                        ; =0x28
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #14339                     ; =0x3803
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #47660                      ; =0xba2c
	tst	w8, #0x4
	eor	w11, w8, w11
	csel	w9, w9, w10, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w11, w9
	mov	w11, #48651                     ; =0xbe0b
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_40                 ; -- Begin function liza_caller_40
	.p2align	2
_liza_caller_40:                        ; @liza_caller_40
; %bb.0:                                ; %b0
	mov	w8, #41                         ; =0x29
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_41                 ; -- Begin function liza_caller_41
	.p2align	2
_liza_caller_41:                        ; @liza_caller_41
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #42                        ; =0x2a
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_42                 ; -- Begin function liza_caller_42
	.p2align	2
_liza_caller_42:                        ; @liza_caller_42
; %bb.0:                                ; %b0
	mov	w8, #43                         ; =0x2b
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_43                 ; -- Begin function liza_caller_43
	.p2align	2
_liza_caller_43:                        ; @liza_caller_43
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #47660                     ; =0xba2c
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #44                        ; =0x2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	eor	w9, w8, w10
	mov	w10, #14339                     ; =0x3803
	tst	w9, #0x4
	csel	w10, w11, w10, eq
	mov	w11, #15336                     ; =0x3be8
	eor	w9, w10, w9
	mov	w10, #48651                     ; =0xbe0b
	tst	w9, #0x8
	csel	w10, w10, w11, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_44                 ; -- Begin function liza_caller_44
	.p2align	2
_liza_caller_44:                        ; @liza_caller_44
; %bb.0:                                ; %b0
	mov	w8, #45                         ; =0x2d
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_45                 ; -- Begin function liza_caller_45
	.p2align	2
_liza_caller_45:                        ; @liza_caller_45
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	mov	w10, #46                        ; =0x2e
	tst	w0, #0x1
	eor	w10, w0, w10
	mov	w11, #48651                     ; =0xbe0b
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w12, #16333                     ; =0x3fcd
	eor	w8, w10, w8
	mov	w10, #46669                     ; =0xb64d
	mov	w13, #49642                     ; =0xc1ea
	tst	w8, #0x2
	mov	w14, #39264                     ; =0x9960
	mov	w0, #56213                      ; =0xdb95
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_46                 ; -- Begin function liza_caller_46
	.p2align	2
_liza_caller_46:                        ; @liza_caller_46
; %bb.0:                                ; %b0
	mov	w8, #47                         ; =0x2f
	mov	w9, #12345                      ; =0x3039
	mov	w10, #45678                     ; =0xb26e
	eor	w8, w0, w8
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x1
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #46669                     ; =0xb64d
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #13342                      ; =0x341e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_caller_47                 ; -- Begin function liza_caller_47
	.p2align	2
_liza_caller_47:                        ; @liza_caller_47
; %bb.0:                                ; %b0
	mov	w8, #12345                      ; =0x3039
	mov	w9, #45678                      ; =0xb26e
	tst	w0, #0x1
	csel	w8, w9, w8, eq
	mov	w9, #13342                      ; =0x341e
	mov	w10, #46669                     ; =0xb64d
	eor	w8, w8, w0
	mov	w11, #48651                     ; =0xbe0b
	mov	w12, #16333                     ; =0x3fcd
	tst	w8, #0x2
	mov	w13, #49642                     ; =0xc1ea
	mov	w14, #39264                     ; =0x9960
	csel	w9, w10, w9, eq
	mov	w10, #47660                     ; =0xba2c
	mov	w0, #56213                      ; =0xdb95
	eor	w8, w9, w8
	mov	w9, #14339                      ; =0x3803
	tst	w8, #0x4
	eor	w8, w8, #0x30
	csel	w9, w10, w9, eq
	mov	w10, #15336                     ; =0x3be8
	eor	w9, w9, w8
	tst	w9, #0x8
	csel	w10, w11, w10, eq
	tst	w8, #0x10
	mov	w11, #65498                     ; =0xffda
	csel	w8, w13, w12, eq
	mov	w12, #33282                     ; =0x8202
	eor	w8, w8, w9
	mov	w9, #17330                      ; =0x43b2
	eor	w8, w8, w10
	mov	w10, #50633                     ; =0xc5c9
	tst	w8, #0x20
	csel	w9, w10, w9, eq
	mov	w10, #51624                     ; =0xc9a8
	eor	w8, w9, w8
	mov	w9, #18327                      ; =0x4797
	tst	w8, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #52615                     ; =0xcd87
	eor	w8, w9, w8
	mov	w9, #19324                      ; =0x4b7c
	tst	w8, #0x80
	csel	w9, w10, w9, eq
	mov	w10, #53606                     ; =0xd166
	eor	w8, w9, w8
	mov	w9, #20321                      ; =0x4f61
	tst	w8, #0x100
	csel	w9, w10, w9, eq
	mov	w10, #54597                     ; =0xd545
	eor	w8, w9, w8
	mov	w9, #21318                      ; =0x5346
	tst	w8, #0x200
	csel	w9, w10, w9, eq
	mov	w10, #55588                     ; =0xd924
	eor	w8, w9, w8
	mov	w9, #22315                      ; =0x572b
	tst	w8, #0x400
	csel	w9, w10, w9, eq
	mov	w10, #56579                     ; =0xdd03
	eor	w8, w9, w8
	mov	w9, #23312                      ; =0x5b10
	tst	w8, #0x800
	csel	w9, w10, w9, eq
	mov	w10, #57570                     ; =0xe0e2
	eor	w8, w9, w8
	mov	w9, #24309                      ; =0x5ef5
	tst	w8, #0x1000
	csel	w9, w10, w9, eq
	mov	w10, #58561                     ; =0xe4c1
	eor	w8, w9, w8
	mov	w9, #25306                      ; =0x62da
	tst	w8, #0x2000
	csel	w9, w10, w9, eq
	mov	w10, #59552                     ; =0xe8a0
	eor	w8, w9, w8
	mov	w9, #26303                      ; =0x66bf
	tst	w8, #0x4000
	csel	w9, w10, w9, eq
	mov	w10, #60543                     ; =0xec7f
	eor	w8, w9, w8
	mov	w9, #27300                      ; =0x6aa4
	tst	w8, #0x8000
	csel	w9, w10, w9, eq
	mov	w10, #61534                     ; =0xf05e
	eor	w8, w9, w8
	mov	w9, #28297                      ; =0x6e89
	tst	w8, #0x1
	csel	w9, w10, w9, eq
	mov	w10, #62525                     ; =0xf43d
	eor	w8, w9, w8
	mov	w9, #29294                      ; =0x726e
	tst	w8, #0x2
	csel	w9, w10, w9, eq
	mov	w10, #63516                     ; =0xf81c
	eor	w8, w9, w8
	mov	w9, #30291                      ; =0x7653
	tst	w8, #0x4
	csel	w9, w10, w9, eq
	mov	w10, #64507                     ; =0xfbfb
	eor	w8, w9, w8
	mov	w9, #31288                      ; =0x7a38
	tst	w8, #0x8
	csel	w9, w10, w9, eq
	mov	w10, #32285                     ; =0x7e1d
	eor	w9, w9, w8
	mov	w8, #647                        ; =0x287
	movk	w8, #1, lsl #16
	tst	w9, #0x10
	add	w13, w8, #306
	csel	w10, w11, w10, eq
	tst	w9, #0x20
	csel	w11, w13, w12, eq
	add	w12, w8, #2288
	mov	w13, #37270                     ; =0x9196
	eor	w10, w10, w11
	eor	w11, w10, w9
	mov	w9, #34279                      ; =0x85e7
	add	w10, w8, #1297
	tst	w11, #0x40
	csel	w9, w10, w9, eq
	mov	w10, #35276                     ; =0x89cc
	eor	w9, w9, w11
	tst	w9, #0x80
	csel	w10, w12, w10, eq
	add	w12, w8, #3279
	eor	w10, w10, w9
	mov	w9, #36273                      ; =0x8db1
	tst	w10, #0x100
	csel	w12, w12, w9, eq
	mov	w9, #4917                       ; =0x1335
	eor	w10, w12, w10
	movk	w9, #1, lsl #16
	mov	w12, #38267                     ; =0x957b
	tst	w10, #0x200
	add	w15, w9, #991
	add	w16, w9, #1982
	csel	w13, w9, w13, eq
	tst	w10, #0x400
	add	w17, w9, #3964
	csel	w12, w15, w12, eq
	tst	w10, #0x800
	mov	w15, #40261                     ; =0x9d45
	csel	w14, w16, w14, eq
	eor	w12, w13, w12
	add	w16, w9, #2973
	eor	w13, w14, w10
	mov	w10, #9620                      ; =0x2594
	mov	w14, #41258                     ; =0xa12a
	eor	w12, w12, w13
	movk	w10, #1, lsl #16
	mov	w13, #42255                     ; =0xa50f
	tst	w12, #0x1000
	csel	w15, w16, w15, eq
	tst	w11, #0x2000
	add	w16, w10, #252
	csel	w14, w17, w14, eq
	tst	w11, #0x4000
	csel	w11, w16, w13, eq
	add	w13, w10, #1243
	eor	w11, w11, w14
	mov	w14, #47240                     ; =0xb888
	eor	w11, w11, w12
	mov	w12, #43252                     ; =0xa8f4
	eor	w11, w11, w15
	mov	w15, #48237                     ; =0xbc6d
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w10, #2234
	eor	w11, w12, w11
	mov	w12, #44249                     ; =0xacd9
	tst	w11, #0x1
	csel	w12, w13, w12, eq
	add	w13, w10, #3225
	eor	w11, w12, w11
	mov	w12, #45246                     ; =0xb0be
	tst	w11, #0x2
	csel	w12, w13, w12, eq
	mov	w13, #13836                     ; =0x360c
	eor	w12, w12, w11
	mov	w11, #46243                     ; =0xb4a3
	movk	w13, #1, lsl #16
	tst	w12, #0x4
	add	w16, w13, #991
	add	w17, w13, #1982
	csel	w11, w13, w11, eq
	eor	w11, w11, w12
	tst	w11, #0x8
	csel	w14, w16, w14, eq
	tst	w12, #0x10
	csel	w12, w17, w15, eq
	add	w15, w13, #2973
	add	w13, w13, #3964
	eor	w12, w12, w11
	eor	w12, w12, w14
	mov	w14, #49234                     ; =0xc052
	tst	w12, #0x20
	csel	w14, w15, w14, eq
	mov	w15, #52225                     ; =0xcc01
	eor	w12, w14, w12
	mov	w14, #50231                     ; =0xc437
	tst	w12, #0x40
	csel	w13, w13, w14, eq
	mov	w14, #18791                     ; =0x4967
	eor	w12, w13, w12
	mov	w13, #51228                     ; =0xc81c
	movk	w14, #1, lsl #16
	tst	w12, #0x80
	add	w16, w14, #991
	add	w17, w14, #1982
	csel	w13, w14, w13, eq
	eor	w12, w13, w12
	mov	w13, #53222                     ; =0xcfe6
	tst	w12, #0x100
	csel	w15, w16, w15, eq
	tst	w11, #0x200
	add	w16, w14, #2973
	csel	w13, w17, w13, eq
	mov	w17, #55216                     ; =0xd7b0
	add	w14, w14, #3964
	eor	w13, w13, w12
	eor	w13, w13, w15
	mov	w15, #54219                     ; =0xd3cb
	tst	w13, #0x400
	csel	w15, w16, w15, eq
	mov	w16, #23746                     ; =0x5cc2
	tst	w13, #0x800
	movk	w16, #1, lsl #16
	csel	w14, w14, w17, eq
	tst	w13, #0x1000
	mov	w17, #57210                     ; =0xdf7a
	csel	w0, w16, w0, eq
	tst	w11, #0x2000
	add	w11, w16, #991
	csel	w11, w11, w17, eq
	mov	w17, #58207                     ; =0xe35f
	tst	w12, #0x4000
	add	w12, w16, #1982
	csel	w12, w12, w17, eq
	eor	w11, w12, w11
	eor	w12, w15, w0
	mov	w15, #33656                     ; =0x8378
	eor	w11, w11, w14
	movk	w15, #1, lsl #16
	eor	w11, w11, w12
	mov	w12, #59204                     ; =0xe744
	eor	w11, w11, w13
	add	w13, w16, #2973
	tst	w11, #0x8000
	csel	w12, w13, w12, eq
	add	w13, w16, #3964
	mov	w16, #38611                     ; =0x96d3
	eor	w11, w12, w11
	mov	w12, #60201                     ; =0xeb29
	movk	w16, #1, lsl #16
	tst	w11, #0x1
	add	w17, w16, #991
	add	w0, w16, #1982
	csel	w12, w13, w12, eq
	mov	w13, #28701                     ; =0x701d
	eor	w11, w12, w11
	mov	w12, #61198                     ; =0xef0e
	movk	w13, #1, lsl #16
	tst	w11, #0x2
	add	w14, w13, #991
	csel	w12, w13, w12, eq
	eor	w11, w12, w11
	mov	w12, #62195                     ; =0xf2f3
	tst	w11, #0x4
	csel	w12, w14, w12, eq
	add	w14, w13, #1982
	eor	w11, w12, w11
	mov	w12, #63192                     ; =0xf6d8
	tst	w11, #0x8
	csel	w12, w14, w12, eq
	add	w14, w13, #2973
	add	w13, w13, #3964
	eor	w11, w12, w11
	mov	w12, #64189                     ; =0xfabd
	tst	w11, #0x10
	csel	w12, w14, w12, eq
	mov	w14, #65186                     ; =0xfea2
	eor	w12, w12, w11
	tst	w12, #0x20
	csel	w13, w13, w14, eq
	tst	w11, #0x40
	add	w14, w15, #1982
	csel	w11, w15, w8, eq
	eor	w11, w11, w12
	add	w12, w8, #997
	eor	w11, w11, w13
	add	w13, w15, #991
	tst	w11, #0x80
	csel	w12, w13, w12, eq
	add	w13, w8, #1994
	eor	w12, w12, w11
	tst	w12, #0x100
	csel	w13, w14, w13, eq
	add	w14, w15, #2973
	eor	w12, w13, w12
	add	w13, w8, #2991
	add	w8, w8, #3988
	tst	w12, #0x200
	csel	w13, w14, w13, eq
	add	w14, w15, #3964
	add	w15, w9, #1712
	eor	w12, w13, w12
	add	w13, w9, #715
	tst	w12, #0x400
	csel	w8, w14, w8, eq
	tst	w12, #0x800
	add	w14, w9, #2709
	csel	w13, w16, w13, eq
	tst	w11, #0x1000
	add	w9, w9, #3706
	csel	w15, w17, w15, eq
	tst	w11, #0x2000
	add	w17, w16, #2973
	csel	w14, w0, w14, eq
	tst	w11, #0x4000
	eor	w8, w8, w12
	csel	w9, w17, w9, eq
	eor	w11, w14, w15
	eor	w9, w11, w9
	eor	w9, w9, w13
	eor	w8, w9, w8
	add	w9, w16, #3964
	tst	w8, #0x8000
	csel	w9, w9, w10, eq
	eor	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
; %bb.0:                                ; %b0
	mov	w0, #48683                      ; =0xbe2b
	movk	w0, #1, lsl #16
	ret
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
; %bb.0:                                ; %entry
	mov	w0, #48683                      ; =0xbe2b
	movk	w0, #1, lsl #16
	ret
                                        ; -- End function
.subsections_via_symbols
