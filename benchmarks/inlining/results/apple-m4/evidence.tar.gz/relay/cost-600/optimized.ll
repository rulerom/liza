; ModuleID = '/private/tmp/liza-inlining-p1-final/relay/cost-600/module.ll'
source_filename = "/private/tmp/liza-inlining-p1-final/relay/cost-600/module.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%struct.relay.direction.Direction = type { i32, i32, i1, i1 }
%variant.6 = type { i32, %struct.relay.direction.Direction, %variant.2 }
%variant.2 = type { i32, [0 x i8] }
%struct.liza_proxy.Pair = type { %variant.0, %variant.0, i1, %struct.relay.direction.Direction, %struct.relay.direction.Direction }
%variant.0 = type { i32, [3 x i64], [0 x i8] }
%variant.5 = type { i32, [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8] }
%variant.9 = type { i32, i32, %variant.5 }
%variant.7 = type { i32, i64, %struct.IoFailure }
%struct.IoFailure = type { %variant.1, i64 }
%variant.1 = type { i32, [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8] }
%variant.11 = type { i32, [3 x i64], %variant.5 }
%variant.12 = type { i32, i1, %variant.5 }
%variant.10 = type { i32, ptr, %variant.5 }
%variant.8 = type { i32, i32, [0 x i8] }

@text.liza_proxy.exchange.v21 = private constant [1 x i8] c"\0A"
@text.main.v9 = private constant [41 x i8] c"Usage: liza-proxy [--once | --ephemeral]\0A"
@text.main.v17 = private constant [6 x i8] c"--once"
@text.main.v21 = private constant [11 x i8] c"--ephemeral"
@text.main.v25 = private constant [41 x i8] c"Usage: liza-proxy [--once | --ephemeral]\0A"
@text.main.v28 = private constant [6 x i8] c"--once"
@text.main.v37 = private constant [31 x i8] c"Cannot create loopback reactor\0A"

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #0

declare ptr @liza_rt_region_create(i64, ptr) local_unnamed_addr

declare ptr @liza_rt_region_alloc(ptr, i64, i64, i32, ptr) local_unnamed_addr

declare void @liza_rt_region_close(ptr) local_unnamed_addr

declare i64 @liza_rt_write_text(ptr, i32) local_unnamed_addr

declare i64 @liza_rt_print_u64(i64) local_unnamed_addr

declare i64 @liza_rt_err_text(ptr, i32) local_unnamed_addr

define i64 @liza___liza_write_text({ ptr, i32 } %value) local_unnamed_addr {
  %data = extractvalue { ptr, i32 } %value, 0
  %length = extractvalue { ptr, i32 } %value, 1
  %result = tail call i64 @liza_rt_write_text(ptr %data, i32 %length)
  ret i64 %result
}

define i64 @liza___liza_print_u64(i64 %value) local_unnamed_addr {
  %result = tail call i64 @liza_rt_print_u64(i64 %value)
  ret i64 %result
}

define i64 @liza___liza_err_text({ ptr, i32 } %value) local_unnamed_addr {
  %data = extractvalue { ptr, i32 } %value, 0
  %length = extractvalue { ptr, i32 } %value, 1
  %result = tail call i64 @liza_rt_err_text(ptr %data, i32 %length)
  ret i64 %result
}

declare i32 @liza_rt_cli_count() local_unnamed_addr

declare i32 @liza_rt_cli_equals(i32, ptr, i32) local_unnamed_addr

declare i32 @liza_rt_reactor_connect(ptr, i16, ptr) local_unnamed_addr

declare i64 @liza_rt_reactor_finish_connect(ptr, i64, i64, i64) local_unnamed_addr

declare i64 @liza_rt_reactor_shutdown_write(ptr, i64, i64, i64) local_unnamed_addr

declare i32 @liza_rt_reactor_create(i16, i32, ptr) local_unnamed_addr

declare i32 @liza_rt_reactor_accept(ptr, ptr) local_unnamed_addr

declare i64 @liza_rt_reactor_port(ptr) local_unnamed_addr

declare i64 @liza_rt_reactor_poll(ptr, i32) local_unnamed_addr

declare i64 @liza_rt_reactor_interest(ptr, i64, i64, i64, i32) local_unnamed_addr

declare i64 @liza_rt_reactor_ready(ptr, i64, i64, i64) local_unnamed_addr

declare i64 @liza_rt_reactor_disconnect(ptr, i64, i64, i64) local_unnamed_addr

declare i32 @liza_rt_reactor_close(ptr) local_unnamed_addr

declare i64 @liza_rt_reactor_write(ptr, i64, i64, i64, ptr, i32, i32, i32) local_unnamed_addr

declare i64 @liza_rt_reactor_read(ptr, i64, i64, i64, ptr, i32, i32, i32) local_unnamed_addr

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %struct.relay.direction.Direction @liza_relay.direction.empty() local_unnamed_addr #2 {
b0:
  ret %struct.relay.direction.Direction zeroinitializer
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i1 @liza_relay.direction.valid(%struct.relay.direction.Direction %p0) local_unnamed_addr #2 {
b0:
  %v0 = extractvalue %struct.relay.direction.Direction %p0, 0
  %v1 = extractvalue %struct.relay.direction.Direction %p0, 1
  %v2 = icmp ule i32 %v0, %v1
  %v6 = icmp ult i32 %v1, 2049
  %v7 = and i1 %v2, %v6
  br i1 %v7, label %b4, label %b12

b4:                                               ; preds = %b0
  %v9 = extractvalue %struct.relay.direction.Direction %p0, 3
  br i1 %v9, label %b6, label %b12

b6:                                               ; preds = %b4
  %v12 = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16 = icmp eq i32 %v0, %v1
  %v17 = and i1 %v12, %v16
  br label %b12

b12:                                              ; preds = %b6, %b4, %b0
  %v19 = phi i1 [ false, %b0 ], [ %v17, %b6 ], [ true, %b4 ]
  ret i1 %v19
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define range(i32 0, 2049) i32 @liza_relay.direction.readable(%struct.relay.direction.Direction %p0) local_unnamed_addr #2 {
b0:
  %v0.i = extractvalue %struct.relay.direction.Direction %p0, 0
  %v1.i = extractvalue %struct.relay.direction.Direction %p0, 1
  %v2.i = icmp ule i32 %v0.i, %v1.i
  %v6.i = icmp ult i32 %v1.i, 2049
  %v7.i = and i1 %v2.i, %v6.i
  br i1 %v7.i, label %b4.i, label %common.ret

b4.i:                                             ; preds = %b0
  %v9.i = extractvalue %struct.relay.direction.Direction %p0, 3
  %v9.i.not = xor i1 %v9.i, true
  %v12.i = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16.i = icmp eq i32 %v0.i, %v1.i
  %v17.i = and i1 %v12.i, %v16.i
  %or.cond = select i1 %v9.i.not, i1 true, i1 %v17.i
  br i1 %or.cond, label %b1, label %common.ret

b1:                                               ; preds = %b4.i
  %v8_pair4 = sub nuw nsw i32 2048, %v1.i
  %spec.select = select i1 %v12.i, i32 0, i32 %v8_pair4
  br label %common.ret

common.ret:                                       ; preds = %b1, %b4.i, %b0
  %common.ret.op = phi i32 [ 0, %b0 ], [ 0, %b4.i ], [ %spec.select, %b1 ]
  ret i32 %common.ret.op
}

; Function Attrs: nounwind memory(inaccessiblemem: write)
define i32 @liza_relay.direction.queued(%struct.relay.direction.Direction %p0) local_unnamed_addr #3 {
b0:
  %v0.i = extractvalue %struct.relay.direction.Direction %p0, 0
  %v1.i = extractvalue %struct.relay.direction.Direction %p0, 1
  %v2.i = icmp ule i32 %v0.i, %v1.i
  %v6.i = icmp ult i32 %v1.i, 2049
  %v7.i = and i1 %v2.i, %v6.i
  br i1 %v7.i, label %b4.i, label %common.ret

b4.i:                                             ; preds = %b0
  %v9.i = extractvalue %struct.relay.direction.Direction %p0, 3
  %v9.i.not = xor i1 %v9.i, true
  %v12.i = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16.i = icmp eq i32 %v0.i, %v1.i
  %v17.i = and i1 %v12.i, %v16.i
  %or.cond = select i1 %v9.i.not, i1 true, i1 %v17.i
  br i1 %or.cond, label %b3, label %common.ret

common.ret:                                       ; preds = %b4.i, %b0, %b3
  %common.ret.op = phi i32 [ %v5, %b3 ], [ 0, %b0 ], [ 0, %b4.i ]
  ret i32 %common.ret.op

b3:                                               ; preds = %b4.i
  %v5_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v1.i, i32 %v0.i)
  %v5 = extractvalue { i32, i1 } %v5_pair, 0
  %v5_overflow = extractvalue { i32, i1 } %v5_pair, 1
  br i1 %v5_overflow, label %v5_trap, label %common.ret

v5_trap:                                          ; preds = %b3
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.6 @liza_relay.direction.read(%struct.relay.direction.Direction %p0, i32 %p1) local_unnamed_addr #2 {
b0:
  %v0.i = extractvalue %struct.relay.direction.Direction %p0, 0
  %v1.i = extractvalue %struct.relay.direction.Direction %p0, 1
  %v2.i = icmp ule i32 %v0.i, %v1.i
  %v6.i = icmp ult i32 %v1.i, 2049
  %v7.i = and i1 %v2.i, %v6.i
  br i1 %v7.i, label %b4.i, label %common.ret

b4.i:                                             ; preds = %b0
  %v9.i = extractvalue %struct.relay.direction.Direction %p0, 3
  %v9.i.not = xor i1 %v9.i, true
  %v12.i = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16.i = icmp eq i32 %v0.i, %v1.i
  %v17.i = and i1 %v12.i, %v16.i
  %or.cond = select i1 %v9.i.not, i1 true, i1 %v17.i
  br i1 %or.cond, label %b1, label %common.ret

b1:                                               ; preds = %b4.i
  %v8 = icmp eq i32 %v1.i, 2048
  %0 = or i1 %v9.i, %v8
  %or.cond25 = or i1 %0, %v12.i
  %v8_pair4.i15 = sub nuw nsw i32 2048, %v1.i
  %v12 = icmp ugt i32 %p1, %v8_pair4.i15
  %or.cond26 = select i1 %or.cond25, i1 true, i1 %v12
  br i1 %or.cond26, label %common.ret, label %b12

common.ret:                                       ; preds = %b4.i, %b0, %b1, %v26_ok, %b13
  %common.ret.op = phi %variant.6 [ %v23, %b13 ], [ %v30, %v26_ok ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b1 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b0 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b4.i ]
  ret %variant.6 %common.ret.op

b12:                                              ; preds = %b1
  %v17 = icmp eq i32 %p1, 0
  br i1 %v17, label %b13, label %v26_ok

b13:                                              ; preds = %b12
  %v22_field0 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i, 0
  %v22_field1 = insertvalue %struct.relay.direction.Direction %v22_field0, i32 %v1.i, 1
  %v22_field2 = insertvalue %struct.relay.direction.Direction %v22_field1, i1 true, 2
  %v22 = insertvalue %struct.relay.direction.Direction %v22_field2, i1 false, 3
  %v23 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v22, 1
  br label %common.ret

v26_ok:                                           ; preds = %b12
  %v26_pair23 = add nuw nsw i32 %v1.i, %p1
  %v29_field0 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i, 0
  %v29_field1 = insertvalue %struct.relay.direction.Direction %v29_field0, i32 %v26_pair23, 1
  %v29_field2 = insertvalue %struct.relay.direction.Direction %v29_field1, i1 false, 2
  %v29 = insertvalue %struct.relay.direction.Direction %v29_field2, i1 false, 3
  %v30 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v29, 1
  br label %common.ret
}

; Function Attrs: nounwind memory(inaccessiblemem: write)
define %variant.6 @liza_relay.direction.write(%struct.relay.direction.Direction %p0, i32 %p1) local_unnamed_addr #3 {
b0:
  %v0.i = extractvalue %struct.relay.direction.Direction %p0, 0
  %v1.i = extractvalue %struct.relay.direction.Direction %p0, 1
  %v2.i = icmp ule i32 %v0.i, %v1.i
  %v6.i = icmp ult i32 %v1.i, 2049
  %v7.i = and i1 %v2.i, %v6.i
  br i1 %v7.i, label %b4.i, label %common.ret

b4.i:                                             ; preds = %b0
  %v9.i = extractvalue %struct.relay.direction.Direction %p0, 3
  br i1 %v9.i, label %b6.i, label %liza_relay.direction.valid.exit

b6.i:                                             ; preds = %b4.i
  %v12.i = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16.i = icmp eq i32 %v0.i, %v1.i
  %v17.i = and i1 %v12.i, %v16.i
  br label %liza_relay.direction.valid.exit

liza_relay.direction.valid.exit:                  ; preds = %b4.i, %b6.i
  %v19.i = phi i1 [ %v17.i, %b6.i ], [ true, %b4.i ]
  %v4 = icmp ne i32 %p1, 0
  %or.cond.not = select i1 %v19.i, i1 %v4, i1 false
  br i1 %or.cond.not, label %b4.i.i, label %common.ret

b4.i.i:                                           ; preds = %liza_relay.direction.valid.exit
  %v9.i.not.i = xor i1 %v9.i, true
  %v12.i.i = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16.i.i = icmp eq i32 %v0.i, %v1.i
  %v17.i.i = and i1 %v12.i.i, %v16.i.i
  %or.cond.i = select i1 %v9.i.not.i, i1 true, i1 %v17.i.i
  br i1 %or.cond.i, label %b3.i, label %common.ret

b3.i:                                             ; preds = %b4.i.i
  %v5_pair.i = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v1.i, i32 %v0.i)
  %v5_overflow.i = extractvalue { i32, i1 } %v5_pair.i, 1
  br i1 %v5_overflow.i, label %v5_trap.i, label %liza_relay.direction.queued.exit

v5_trap.i:                                        ; preds = %b3.i
  tail call void @llvm.trap()
  unreachable

liza_relay.direction.queued.exit:                 ; preds = %b3.i
  %v5.i = extractvalue { i32, i1 } %v5_pair.i, 0
  %v8 = icmp ugt i32 %p1, %v5.i
  br i1 %v8, label %common.ret, label %b9

common.ret:                                       ; preds = %b4.i.i, %b0, %liza_relay.direction.queued.exit, %liza_relay.direction.valid.exit, %b12, %b10
  %common.ret.op = phi %variant.6 [ %v21, %b10 ], [ %v26, %b12 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %liza_relay.direction.valid.exit ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %liza_relay.direction.queued.exit ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b0 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b4.i.i ]
  ret %variant.6 %common.ret.op

b9:                                               ; preds = %liza_relay.direction.queued.exit
  %v13_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v0.i, i32 %p1)
  %v13 = extractvalue { i32, i1 } %v13_pair, 0
  %v13_overflow = extractvalue { i32, i1 } %v13_pair, 1
  br i1 %v13_overflow, label %v13_trap, label %v13_ok

v13_trap:                                         ; preds = %b9
  tail call void @llvm.trap()
  unreachable

v13_ok:                                           ; preds = %b9
  %v15 = icmp eq i32 %v13, %v1.i
  br i1 %v15, label %b10, label %b12

b10:                                              ; preds = %v13_ok
  %v20_field2 = insertvalue %struct.relay.direction.Direction zeroinitializer, i1 %v12.i.i, 2
  %v20 = insertvalue %struct.relay.direction.Direction %v20_field2, i1 %v9.i, 3
  %v21 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v20, 1
  br label %common.ret

b12:                                              ; preds = %v13_ok
  %v25_field0 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v13, 0
  %v25_field1 = insertvalue %struct.relay.direction.Direction %v25_field0, i32 %v1.i, 1
  %v25_field2 = insertvalue %struct.relay.direction.Direction %v25_field1, i1 %v12.i.i, 2
  %v25 = insertvalue %struct.relay.direction.Direction %v25_field2, i1 %v9.i, 3
  %v26 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v25, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i1 @liza_relay.direction.needs_fin(%struct.relay.direction.Direction %p0) local_unnamed_addr #2 {
b0:
  %v0.i = extractvalue %struct.relay.direction.Direction %p0, 0
  %v1.i = extractvalue %struct.relay.direction.Direction %p0, 1
  %v2.i = icmp ule i32 %v0.i, %v1.i
  %v6.i = icmp ult i32 %v1.i, 2049
  %v7.i = and i1 %v2.i, %v6.i
  %v12.i = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16.i = icmp eq i32 %v0.i, %v1.i
  %v17.i = and i1 %v12.i, %v16.i
  %or.cond = select i1 %v7.i, i1 %v17.i, i1 false
  %v9.i = extractvalue %struct.relay.direction.Direction %p0, 3
  %v11 = xor i1 %v9.i, true
  %v12 = select i1 %or.cond, i1 %v11, i1 false
  ret i1 %v12
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.6 @liza_relay.direction.shutdown(%struct.relay.direction.Direction %p0) local_unnamed_addr #2 {
b0:
  %v0.i.i = extractvalue %struct.relay.direction.Direction %p0, 0
  %v1.i.i = extractvalue %struct.relay.direction.Direction %p0, 1
  %v2.i.i = icmp ule i32 %v0.i.i, %v1.i.i
  %v6.i.i = icmp ult i32 %v1.i.i, 2049
  %v7.i.i = and i1 %v2.i.i, %v6.i.i
  br i1 %v7.i.i, label %b4.i.i, label %common.ret

b4.i.i:                                           ; preds = %b0
  %v9.i.i = extractvalue %struct.relay.direction.Direction %p0, 3
  %v12.i.i = extractvalue %struct.relay.direction.Direction %p0, 2
  %v16.i.i = icmp eq i32 %v0.i.i, %v1.i.i
  %v9.i.i.not = xor i1 %v9.i.i, true
  %or.cond8.i = and i1 %v12.i.i, %v16.i.i
  %or.cond = select i1 %v9.i.i.not, i1 %or.cond8.i, i1 false
  br i1 %or.cond, label %b3, label %common.ret

common.ret:                                       ; preds = %b4.i.i, %b0, %b3
  %common.ret.op = phi %variant.6 [ %v9, %b3 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b0 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b4.i.i ]
  ret %variant.6 %common.ret.op

b3:                                               ; preds = %b4.i.i
  %v8_field0 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i.i, 0
  %v8_field1 = insertvalue %struct.relay.direction.Direction %v8_field0, i32 %v0.i.i, 1
  %v8_field2 = insertvalue %struct.relay.direction.Direction %v8_field1, i1 true, 2
  %v8 = insertvalue %struct.relay.direction.Direction %v8_field2, i1 true, 3
  %v9 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v8, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %struct.liza_proxy.Pair @liza_liza_proxy.empty_pair() local_unnamed_addr #2 {
b0:
  ret %struct.liza_proxy.Pair { %variant.0 { i32 1, [3 x i64] zeroinitializer, [0 x i8] zeroinitializer }, %variant.0 { i32 1, [3 x i64] zeroinitializer, [0 x i8] zeroinitializer }, i1 false, %struct.relay.direction.Direction zeroinitializer, %struct.relay.direction.Direction zeroinitializer }
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i1 @liza_liza_proxy.retry(%variant.5 %p0) local_unnamed_addr #2 {
b0:
  %v0 = extractvalue %variant.5 %p0, 0
  %switch.cast = trunc i32 %v0 to i12
  %switch.downshift = lshr i12 268, %switch.cast
  %switch.masked = trunc i12 %switch.downshift to i1
  ret i1 %switch.masked
}

define range(i32 0, 4) i32 @liza_liza_proxy.exchange(ptr %p0, { ptr, i32 } %p1, i16 %p2, i1 %p3) local_unnamed_addr {
b0:
  %out.i.i126 = alloca [3 x i64], align 8
  %out.i.i = alloca [3 x i64], align 8
  %v2_mem.sroa.10.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.13.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.14.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.17.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.18.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.29.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.32.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.33.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.36.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.37.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.48.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.51.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.52.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.55.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.56.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.67.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.70.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.71.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.74.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.75.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.86.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.89.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.90.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.93.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.94.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.105.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.108.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.109.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.112.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.113.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.124.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.127.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.128.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.131.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.132.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.143.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.146.sroa.0 = alloca i8, align 4
  %v2_mem.sroa.147.sroa.0 = alloca i8, align 1
  %v2_mem.sroa.150.sroa.0 = alloca i8, align 8
  %v2_mem.sroa.151.sroa.0 = alloca i8, align 1
  %v33_mem.sroa.3.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.3.sroa.41 = alloca [6 x i8], align 2
  %v33_mem.sroa.5.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.5.sroa.41 = alloca [6 x i8], align 2
  %v33_mem.sroa.7.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.7.sroa.41 = alloca [6 x i8], align 2
  %v33_mem.sroa.9.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.9.sroa.41 = alloca [6 x i8], align 2
  %v33_mem.sroa.11.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.11.sroa.41 = alloca [6 x i8], align 2
  %v33_mem.sroa.13.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.13.sroa.41 = alloca [6 x i8], align 2
  %v33_mem.sroa.15.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.15.sroa.41 = alloca [6 x i8], align 2
  %v33_mem.sroa.17.sroa.21 = alloca [3 x i8], align 1
  %v33_mem.sroa.17.sroa.41 = alloca [6 x i8], align 2
  %v53_mem.sroa.6.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.7.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.8.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.9.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.9.sroa.24 = alloca [6 x i8], align 2
  %v53_mem.sroa.10.sroa.14 = alloca [3 x i8], align 1
  %v53_mem.sroa.10.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.10.sroa.24 = alloca [6 x i8], align 2
  %v53_mem.sroa.11.sroa.14 = alloca [3 x i8], align 1
  %v53_mem.sroa.11.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.11.sroa.24 = alloca [6 x i8], align 2
  %v53_mem.sroa.12.sroa.14 = alloca [3 x i8], align 1
  %v53_mem.sroa.12.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.12.sroa.24 = alloca [6 x i8], align 2
  %v53_mem.sroa.13.sroa.14 = alloca [3 x i8], align 1
  %v53_mem.sroa.13.sroa.19 = alloca [2 x i8], align 2
  %v53_mem.sroa.13.sroa.24 = alloca [6 x i8], align 2
  %v53_next.sroa.8.sroa.11 = alloca [3 x i8], align 1
  %v108_mem = alloca [8 x %struct.liza_proxy.Pair], align 8
  %v109_mem.sroa.3.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.3.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.3.sroa.41 = alloca [6 x i8], align 2
  %v109_mem.sroa.5.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.5.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.5.sroa.41 = alloca [6 x i8], align 2
  %v109_mem.sroa.7.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.7.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.7.sroa.41 = alloca [6 x i8], align 2
  %v109_mem.sroa.9.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.9.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.9.sroa.41 = alloca [6 x i8], align 2
  %v109_mem.sroa.11.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.11.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.11.sroa.41 = alloca [6 x i8], align 2
  %v109_mem.sroa.13.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.13.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.13.sroa.41 = alloca [6 x i8], align 2
  %v109_mem.sroa.15.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.15.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.15.sroa.41 = alloca [6 x i8], align 2
  %v109_mem.sroa.17.sroa.21 = alloca [3 x i8], align 1
  %v109_mem.sroa.17.sroa.31 = alloca [2 x i8], align 2
  %v109_mem.sroa.17.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.3.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.3.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.3.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.5.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.5.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.5.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.7.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.7.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.7.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.9.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.9.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.9.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.11.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.11.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.11.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.13.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.13.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.13.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.15.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.15.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.15.sroa.41 = alloca [6 x i8], align 2
  %v112_mem.sroa.17.sroa.21 = alloca [3 x i8], align 1
  %v112_mem.sroa.17.sroa.31 = alloca [2 x i8], align 2
  %v112_mem.sroa.17.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.3.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.3.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.7.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.7.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.11.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.11.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.15.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.15.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.19.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.19.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.23.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.23.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.27.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.27.sroa.41 = alloca [6 x i8], align 2
  %v116_mem.sroa.31.sroa.21 = alloca [3 x i8], align 1
  %v116_mem.sroa.31.sroa.41 = alloca [6 x i8], align 2
  %v122_mem = alloca [8 x %struct.liza_proxy.Pair], align 8
  %v122_next.sroa.12.sroa.13 = alloca [3 x i8], align 1
  %v122_next.sroa.12.sroa.23 = alloca [6 x i8], align 2
  %v122_next.sroa.14.sroa.13 = alloca [3 x i8], align 1
  %v122_next.sroa.14.sroa.23 = alloca [6 x i8], align 2
  %v122_next.sroa.16.sroa.13 = alloca [3 x i8], align 1
  %v122_next.sroa.16.sroa.23 = alloca [6 x i8], align 2
  %v122_next.sroa.18.sroa.13 = alloca [3 x i8], align 1
  %v122_next.sroa.18.sroa.23 = alloca [6 x i8], align 2
  %v556_mem = alloca [8 x %struct.liza_proxy.Pair], align 8
  %v558_mem.sroa.3.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.3.sroa.22 = alloca [6 x i8], align 2
  %v558_mem.sroa.5.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.5.sroa.22 = alloca [6 x i8], align 2
  %v558_mem.sroa.7.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.7.sroa.22 = alloca [6 x i8], align 2
  %v558_mem.sroa.9.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.9.sroa.22 = alloca [6 x i8], align 2
  %v558_mem.sroa.11.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.11.sroa.22 = alloca [6 x i8], align 2
  %v558_mem.sroa.13.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.13.sroa.22 = alloca [6 x i8], align 2
  %v558_mem.sroa.15.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.15.sroa.22 = alloca [6 x i8], align 2
  %v558_mem.sroa.17.sroa.12 = alloca [3 x i8], align 1
  %v558_mem.sroa.17.sroa.22 = alloca [6 x i8], align 2
  store i1 false, ptr %v2_mem.sroa.10.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.13.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.14.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.17.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.18.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.29.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.32.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.33.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.36.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.37.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.48.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.51.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.52.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.55.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.56.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.67.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.70.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.71.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.74.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.75.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.86.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.89.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.90.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.93.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.94.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.105.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.108.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.109.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.112.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.113.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.124.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.127.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.128.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.131.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.132.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.143.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.146.sroa.0, align 4
  store i1 false, ptr %v2_mem.sroa.147.sroa.0, align 1
  store i1 false, ptr %v2_mem.sroa.150.sroa.0, align 8
  store i1 false, ptr %v2_mem.sroa.151.sroa.0, align 1
  %raw.i.i = tail call i64 @liza_rt_reactor_port(ptr %p0)
  %v3.i.i = icmp ult i64 %raw.i.i, 4294967296
  br i1 %v3.i.i, label %b1.i.i, label %v8_ok.i.i

b1.i.i:                                           ; preds = %b0
  %v4.i.i = trunc nuw i64 %raw.i.i to i32
  %v5.i.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i, 1
  br label %liza_net.reactor_port.exit

v8_ok.i.i:                                        ; preds = %b0
  %v1.i.i = lshr i64 %raw.i.i, 32
  %v8.i.i = trunc nuw i64 %v1.i.i to i32
  switch i32 %v8.i.i, label %b36.i.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i.i
    i32 2, label %b4.i.i.i
    i32 3, label %b7.i.i.i
    i32 4, label %b10.i.i.i
    i32 5, label %b13.i.i.i
    i32 6, label %b16.i.i.i
    i32 12, label %b34.i.i.i
    i32 8, label %b22.i.i.i
    i32 9, label %b25.i.i.i
    i32 10, label %b28.i.i.i
    i32 11, label %b31.i.i.i
  ]

b4.i.i.i:                                         ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b7.i.i.i:                                         ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b10.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b13.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b16.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b22.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b25.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b28.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b31.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b34.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

b36.i.i.i:                                        ; preds = %v8_ok.i.i
  br label %liza___liza_reactor_error.exit.i.i

liza___liza_reactor_error.exit.i.i:               ; preds = %b36.i.i.i, %b34.i.i.i, %b31.i.i.i, %b28.i.i.i, %b25.i.i.i, %b22.i.i.i, %b16.i.i.i, %b13.i.i.i, %b10.i.i.i, %b7.i.i.i, %b4.i.i.i, %v8_ok.i.i
  %common.ret.op.i.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i ], [ zeroinitializer, %v8_ok.i.i ]
  %v10.i.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i, 2
  br label %liza_net.reactor_port.exit

liza_net.reactor_port.exit:                       ; preds = %b1.i.i, %liza___liza_reactor_error.exit.i.i
  %common.ret.op.i.i = phi %variant.9 [ %v5.i.i, %b1.i.i ], [ %v10.i.i, %liza___liza_reactor_error.exit.i.i ]
  %v7 = extractvalue %variant.9 %common.ret.op.i.i, 0
  %switch = icmp eq i32 %v7, 1
  br i1 %switch, label %b12_to_b13, label %v12_ok

v12_ok:                                           ; preds = %liza_net.reactor_port.exit
  %v11 = extractvalue %variant.9 %common.ret.op.i.i, 1
  %v12 = zext i32 %v11 to i64
  %result.i.i = tail call i64 @liza_rt_print_u64(i64 %v12)
  %v1.i.i45 = and i64 %result.i.i, 4294967295
  %v3.i.i46 = lshr i64 %result.i.i, 32
  %trunc.i.i = trunc nuw i64 %v3.i.i46 to i32
  switch i32 %trunc.i.i, label %b18.i.i [
    i32 0, label %b1.i.i49
    i32 1, label %b4.i.i
    i32 2, label %b7.i.i
    i32 3, label %b10.i.i
    i32 4, label %b13.i.i
    i32 5, label %b16.i.i
  ]

b1.i.i49:                                         ; preds = %v12_ok
  %v6.i.i = insertvalue %variant.7 zeroinitializer, i64 %v1.i.i45, 1
  br label %liza_console.print_u64.exit

b4.i.i:                                           ; preds = %v12_ok
  %v10.i.i48 = insertvalue %struct.IoFailure zeroinitializer, i64 %v1.i.i45, 1
  %v11.i.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v10.i.i48, 2
  br label %liza_console.print_u64.exit

b7.i.i:                                           ; preds = %v12_ok
  %v15.i.i = insertvalue %struct.IoFailure { %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i45, 1
  %v16.i.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v15.i.i, 2
  br label %liza_console.print_u64.exit

b10.i.i:                                          ; preds = %v12_ok
  %v20.i.i = insertvalue %struct.IoFailure { %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i45, 1
  %v21.i.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v20.i.i, 2
  br label %liza_console.print_u64.exit

b13.i.i:                                          ; preds = %v12_ok
  %v25.i.i = insertvalue %struct.IoFailure { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i45, 1
  %v26.i.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v25.i.i, 2
  br label %liza_console.print_u64.exit

b16.i.i:                                          ; preds = %v12_ok
  %v30.i.i = insertvalue %struct.IoFailure { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i45, 1
  %v31.i.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v30.i.i, 2
  br label %liza_console.print_u64.exit

b18.i.i:                                          ; preds = %v12_ok
  %v33.i.i = insertvalue %struct.IoFailure { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i45, 1
  %v34.i.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v33.i.i, 2
  br label %liza_console.print_u64.exit

liza_console.print_u64.exit:                      ; preds = %b1.i.i49, %b4.i.i, %b7.i.i, %b10.i.i, %b13.i.i, %b16.i.i, %b18.i.i
  %common.ret.op.i.i47 = phi %variant.7 [ %v6.i.i, %b1.i.i49 ], [ %v11.i.i, %b4.i.i ], [ %v16.i.i, %b7.i.i ], [ %v21.i.i, %b10.i.i ], [ %v26.i.i, %b13.i.i ], [ %v31.i.i, %b16.i.i ], [ %v34.i.i, %b18.i.i ]
  %v14 = extractvalue %variant.7 %common.ret.op.i.i47, 0
  %switch7 = icmp eq i32 %v14, 0
  %result.i.i50 = tail call i64 @liza_rt_write_text(ptr nonnull @text.liza_proxy.exchange.v21, i32 1)
  %v1.i.i51 = and i64 %result.i.i50, 4294967295
  %v3.i.i52 = lshr i64 %result.i.i50, 32
  %trunc.i.i53 = trunc nuw i64 %v3.i.i52 to i32
  switch i32 %trunc.i.i53, label %b18.i.i72 [
    i32 0, label %b1.i.i70
    i32 1, label %b4.i.i67
    i32 2, label %b7.i.i64
    i32 3, label %b10.i.i61
    i32 4, label %b13.i.i58
    i32 5, label %b16.i.i54
  ]

b1.i.i70:                                         ; preds = %liza_console.print_u64.exit
  %v6.i.i71 = insertvalue %variant.7 zeroinitializer, i64 %v1.i.i51, 1
  br label %liza_console.write.exit

b4.i.i67:                                         ; preds = %liza_console.print_u64.exit
  %v10.i.i68 = insertvalue %struct.IoFailure zeroinitializer, i64 %v1.i.i51, 1
  %v11.i.i69 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v10.i.i68, 2
  br label %liza_console.write.exit

b7.i.i64:                                         ; preds = %liza_console.print_u64.exit
  %v15.i.i65 = insertvalue %struct.IoFailure { %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i51, 1
  %v16.i.i66 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v15.i.i65, 2
  br label %liza_console.write.exit

b10.i.i61:                                        ; preds = %liza_console.print_u64.exit
  %v20.i.i62 = insertvalue %struct.IoFailure { %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i51, 1
  %v21.i.i63 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v20.i.i62, 2
  br label %liza_console.write.exit

b13.i.i58:                                        ; preds = %liza_console.print_u64.exit
  %v25.i.i59 = insertvalue %struct.IoFailure { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i51, 1
  %v26.i.i60 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v25.i.i59, 2
  br label %liza_console.write.exit

b16.i.i54:                                        ; preds = %liza_console.print_u64.exit
  %v30.i.i55 = insertvalue %struct.IoFailure { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i51, 1
  %v31.i.i56 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v30.i.i55, 2
  br label %liza_console.write.exit

b18.i.i72:                                        ; preds = %liza_console.print_u64.exit
  %v33.i.i73 = insertvalue %struct.IoFailure { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i.i51, 1
  %v34.i.i74 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v33.i.i73, 2
  br label %liza_console.write.exit

liza_console.write.exit:                          ; preds = %b1.i.i70, %b4.i.i67, %b7.i.i64, %b10.i.i61, %b13.i.i58, %b16.i.i54, %b18.i.i72
  %common.ret.op.i.i57 = phi %variant.7 [ %v6.i.i71, %b1.i.i70 ], [ %v11.i.i69, %b4.i.i67 ], [ %v16.i.i66, %b7.i.i64 ], [ %v21.i.i63, %b10.i.i61 ], [ %v26.i.i60, %b13.i.i58 ], [ %v31.i.i56, %b16.i.i54 ], [ %v34.i.i74, %b18.i.i72 ]
  %v23 = extractvalue %variant.7 %common.ret.op.i.i57, 0
  %switch34 = icmp eq i32 %v23, 0
  %spec.select = select i1 %switch34, i1 %switch7, i1 false
  %spec.select36 = select i1 %spec.select, i32 0, i32 3
  br label %b12_to_b13

b14:                                              ; preds = %b14.lr.ph, %b61_to_b13
  %v33_mem.sroa.17.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %89, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %88, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %87, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %86, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %85, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %84, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %83, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.31.sroa.0.0 = phi i16 [ undef, %b14.lr.ph ], [ %82, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.39.0 = phi i8 [ %v2_mem.sroa.37.sroa.0.0.v2_mem.sroa.37.sroa.0.0.v2_mem.sroa.37.sroa.0.0.v33_next.sroa.8.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.37.0 = phi i8 [ %v2_mem.sroa.36.sroa.0.0.v2_mem.sroa.36.sroa.0.0.v2_mem.sroa.36.sroa.0.0.v33_next.sroa.8.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.29.0 = phi i8 [ %v2_mem.sroa.33.sroa.0.0.v2_mem.sroa.33.sroa.0.0.v2_mem.sroa.33.sroa.0.0.v33_next.sroa.8.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.27.0 = phi i8 [ %v2_mem.sroa.32.sroa.0.0.v2_mem.sroa.32.sroa.0.0.v2_mem.sroa.32.sroa.0.0.v33_next.sroa.8.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.19.0 = phi i8 [ %v2_mem.sroa.29.sroa.0.0.v2_mem.sroa.29.sroa.0.0.v2_mem.sroa.29.sroa.0.0.v33_next.sroa.8.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.5.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.8.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.39.0 = phi i8 [ %v2_mem.sroa.56.sroa.0.0.v2_mem.sroa.56.sroa.0.0.v2_mem.sroa.56.sroa.0.0.v33_next.sroa.12.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.37.0 = phi i8 [ %v2_mem.sroa.55.sroa.0.0.v2_mem.sroa.55.sroa.0.0.v2_mem.sroa.55.sroa.0.0.v33_next.sroa.12.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.29.0 = phi i8 [ %v2_mem.sroa.52.sroa.0.0.v2_mem.sroa.52.sroa.0.0.v2_mem.sroa.52.sroa.0.0.v33_next.sroa.12.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.27.0 = phi i8 [ %v2_mem.sroa.51.sroa.0.0.v2_mem.sroa.51.sroa.0.0.v2_mem.sroa.51.sroa.0.0.v33_next.sroa.12.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.19.0 = phi i8 [ %v2_mem.sroa.48.sroa.0.0.v2_mem.sroa.48.sroa.0.0.v2_mem.sroa.48.sroa.0.0.v33_next.sroa.12.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.7.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.12.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.39.0 = phi i8 [ %v2_mem.sroa.75.sroa.0.0.v2_mem.sroa.75.sroa.0.0.v2_mem.sroa.75.sroa.0.0.v33_next.sroa.16.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.37.0 = phi i8 [ %v2_mem.sroa.74.sroa.0.0.v2_mem.sroa.74.sroa.0.0.v2_mem.sroa.74.sroa.0.0.v33_next.sroa.16.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.29.0 = phi i8 [ %v2_mem.sroa.71.sroa.0.0.v2_mem.sroa.71.sroa.0.0.v2_mem.sroa.71.sroa.0.0.v33_next.sroa.16.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.27.0 = phi i8 [ %v2_mem.sroa.70.sroa.0.0.v2_mem.sroa.70.sroa.0.0.v2_mem.sroa.70.sroa.0.0.v33_next.sroa.16.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.19.0 = phi i8 [ %v2_mem.sroa.67.sroa.0.0.v2_mem.sroa.67.sroa.0.0.v2_mem.sroa.67.sroa.0.0.v33_next.sroa.16.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.9.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.16.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.39.0 = phi i8 [ %v2_mem.sroa.94.sroa.0.0.v2_mem.sroa.94.sroa.0.0.v2_mem.sroa.94.sroa.0.0.v33_next.sroa.20.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.37.0 = phi i8 [ %v2_mem.sroa.93.sroa.0.0.v2_mem.sroa.93.sroa.0.0.v2_mem.sroa.93.sroa.0.0.v33_next.sroa.20.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.29.0 = phi i8 [ %v2_mem.sroa.90.sroa.0.0.v2_mem.sroa.90.sroa.0.0.v2_mem.sroa.90.sroa.0.0.v33_next.sroa.20.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.27.0 = phi i8 [ %v2_mem.sroa.89.sroa.0.0.v2_mem.sroa.89.sroa.0.0.v2_mem.sroa.89.sroa.0.0.v33_next.sroa.20.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.19.0 = phi i8 [ %v2_mem.sroa.86.sroa.0.0.v2_mem.sroa.86.sroa.0.0.v2_mem.sroa.86.sroa.0.0.v33_next.sroa.20.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.11.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.20.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.39.0 = phi i8 [ %v2_mem.sroa.113.sroa.0.0.v2_mem.sroa.113.sroa.0.0.v2_mem.sroa.113.sroa.0.0.v33_next.sroa.24.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.37.0 = phi i8 [ %v2_mem.sroa.112.sroa.0.0.v2_mem.sroa.112.sroa.0.0.v2_mem.sroa.112.sroa.0.0.v33_next.sroa.24.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.29.0 = phi i8 [ %v2_mem.sroa.109.sroa.0.0.v2_mem.sroa.109.sroa.0.0.v2_mem.sroa.109.sroa.0.0.v33_next.sroa.24.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.27.0 = phi i8 [ %v2_mem.sroa.108.sroa.0.0.v2_mem.sroa.108.sroa.0.0.v2_mem.sroa.108.sroa.0.0.v33_next.sroa.24.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.19.0 = phi i8 [ %v2_mem.sroa.105.sroa.0.0.v2_mem.sroa.105.sroa.0.0.v2_mem.sroa.105.sroa.0.0.v33_next.sroa.24.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.13.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.24.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.19.0 = phi i8 [ %v2_mem.sroa.10.sroa.0.0.v2_mem.sroa.10.sroa.0.0.v2_mem.sroa.10.sroa.0.0.v33_next.sroa.4.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.27.0 = phi i8 [ %v2_mem.sroa.13.sroa.0.0.v2_mem.sroa.13.sroa.0.0.v2_mem.sroa.13.sroa.0.0.v33_next.sroa.4.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.29.0 = phi i8 [ %v2_mem.sroa.14.sroa.0.0.v2_mem.sroa.14.sroa.0.0.v2_mem.sroa.14.sroa.0.0.v33_next.sroa.4.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.37.0 = phi i8 [ %v2_mem.sroa.17.sroa.0.0.v2_mem.sroa.17.sroa.0.0.v2_mem.sroa.17.sroa.0.0.v33_next.sroa.4.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.3.sroa.39.0 = phi i8 [ %v2_mem.sroa.18.sroa.0.0.v2_mem.sroa.18.sroa.0.0.v2_mem.sroa.18.sroa.0.0.v33_next.sroa.4.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.4.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.39.0 = phi i8 [ %v2_mem.sroa.132.sroa.0.0.v2_mem.sroa.132.sroa.0.0.v2_mem.sroa.132.sroa.0.0.v33_next.sroa.28.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.37.0 = phi i8 [ %v2_mem.sroa.131.sroa.0.0.v2_mem.sroa.131.sroa.0.0.v2_mem.sroa.131.sroa.0.0.v33_next.sroa.28.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.29.0 = phi i8 [ %v2_mem.sroa.128.sroa.0.0.v2_mem.sroa.128.sroa.0.0.v2_mem.sroa.128.sroa.0.0.v33_next.sroa.28.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.27.0 = phi i8 [ %v2_mem.sroa.127.sroa.0.0.v2_mem.sroa.127.sroa.0.0.v2_mem.sroa.127.sroa.0.0.v33_next.sroa.28.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.19.0 = phi i8 [ %v2_mem.sroa.124.sroa.0.0.v2_mem.sroa.124.sroa.0.0.v2_mem.sroa.124.sroa.0.0.v33_next.sroa.28.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.15.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.28.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.39.0 = phi i8 [ %v2_mem.sroa.151.sroa.0.0.v2_mem.sroa.151.sroa.0.0.v2_mem.sroa.151.sroa.0.0.v33_next.sroa.32.sroa.22.85.copyload, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.22.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.37.0 = phi i8 [ %v2_mem.sroa.150.sroa.0.0.v2_mem.sroa.150.sroa.0.0.v2_mem.sroa.150.sroa.0.0.v33_next.sroa.32.sroa.21.84.copyload, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.21.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.35.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.20.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.33.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.19.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.29.0 = phi i8 [ %v2_mem.sroa.147.sroa.0.0.v2_mem.sroa.147.sroa.0.0.v2_mem.sroa.147.sroa.0.0.v33_next.sroa.32.sroa.17.73.copyload, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.17.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.27.0 = phi i8 [ %v2_mem.sroa.146.sroa.0.0.v2_mem.sroa.146.sroa.0.0.v2_mem.sroa.146.sroa.0.0.v33_next.sroa.32.sroa.16.72.copyload, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.16.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.25.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.15.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.23.0 = phi i32 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.14.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.19.0 = phi i8 [ %v2_mem.sroa.143.sroa.0.0.v2_mem.sroa.143.sroa.0.0.v2_mem.sroa.143.sroa.0.0.v33_next.sroa.32.sroa.12.60.copyload, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.12.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.17.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.11.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.15.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.10.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.13.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.9.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.11.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.8.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.9.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.7.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.7.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.6.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.5.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.5.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.3.0 = phi i64 [ 0, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.4.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.17.sroa.0.0 = phi i32 [ undef, %b14.lr.ph ], [ %v33_next.sroa.32.sroa.0.0.copyload, %b61_to_b13 ]
  %v33_mem.sroa.16.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.30.0.copyload1331, %b61_to_b13 ]
  %v33_mem.sroa.14.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.26.0.copyload1330, %b61_to_b13 ]
  %v33_mem.sroa.12.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.22.0.copyload1329, %b61_to_b13 ]
  %v33_mem.sroa.10.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.18.0.copyload1328, %b61_to_b13 ]
  %v33_mem.sroa.8.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.14.0.copyload1327, %b61_to_b13 ]
  %v33_mem.sroa.6.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.10.0.copyload1326, %b61_to_b13 ]
  %v33_mem.sroa.4.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.6.0.copyload1325, %b61_to_b13 ]
  %v33_mem.sroa.0.0 = phi i32 [ 1, %b14.lr.ph ], [ %v33_next.sroa.0.0.copyload1324, %b61_to_b13 ]
  %v361109 = phi i32 [ %v31, %b14.lr.ph ], [ %v125.lcssa, %b61_to_b13 ]
  %v351108 = phi i1 [ false, %b14.lr.ph ], [ %v118, %b61_to_b13 ]
  %raw.i.i75 = call i64 @liza_rt_reactor_poll(ptr %p0, i32 1000)
  %v3.i.i76 = icmp ult i64 %raw.i.i75, 4294967296
  br i1 %v3.i.i76, label %b1.i.i95, label %v8_ok.i.i77

b1.i.i95:                                         ; preds = %b14
  %v4.i.i96 = trunc nuw i64 %raw.i.i75 to i32
  %v5.i.i97 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i96, 1
  br label %liza_net.reactor_poll.exit

v8_ok.i.i77:                                      ; preds = %b14
  %v1.i.i78 = lshr i64 %raw.i.i75, 32
  %v8.i.i79 = trunc nuw i64 %v1.i.i78 to i32
  switch i32 %v8.i.i79, label %b36.i.i.i94 [
    i32 1, label %liza___liza_reactor_error.exit.i.i81
    i32 2, label %b4.i.i.i93
    i32 3, label %b7.i.i.i92
    i32 4, label %b10.i.i.i91
    i32 5, label %b13.i.i.i90
    i32 6, label %b16.i.i.i89
    i32 12, label %b34.i.i.i88
    i32 8, label %b22.i.i.i87
    i32 9, label %b25.i.i.i86
    i32 10, label %b28.i.i.i85
    i32 11, label %b31.i.i.i80
  ]

b4.i.i.i93:                                       ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b7.i.i.i92:                                       ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b10.i.i.i91:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b13.i.i.i90:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b16.i.i.i89:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b22.i.i.i87:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b25.i.i.i86:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b28.i.i.i85:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b31.i.i.i80:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b34.i.i.i88:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

b36.i.i.i94:                                      ; preds = %v8_ok.i.i77
  br label %liza___liza_reactor_error.exit.i.i81

liza___liza_reactor_error.exit.i.i81:             ; preds = %b36.i.i.i94, %b34.i.i.i88, %b31.i.i.i80, %b28.i.i.i85, %b25.i.i.i86, %b22.i.i.i87, %b16.i.i.i89, %b13.i.i.i90, %b10.i.i.i91, %b7.i.i.i92, %b4.i.i.i93, %v8_ok.i.i77
  %common.ret.op.i.i.i82 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i93 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i92 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i91 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i90 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i89 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i87 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i86 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i85 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i80 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i88 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i94 ], [ zeroinitializer, %v8_ok.i.i77 ]
  %v10.i.i83 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i82, 2
  br label %liza_net.reactor_poll.exit

liza_net.reactor_poll.exit:                       ; preds = %b1.i.i95, %liza___liza_reactor_error.exit.i.i81
  %common.ret.op.i.i84 = phi %variant.9 [ %v5.i.i97, %b1.i.i95 ], [ %v10.i.i83, %liza___liza_reactor_error.exit.i.i81 ]
  %v39 = extractvalue %variant.9 %common.ret.op.i.i84, 0
  %switch9 = icmp eq i32 %v39, 1
  br i1 %switch9, label %b17, label %b22_to_b23

b15:                                              ; preds = %b61_to_b13, %b12_to_b13
  %v36.lcssa = phi i32 [ %v31, %b12_to_b13 ], [ %v125.lcssa, %b61_to_b13 ]
  %raw.i.i98 = call i32 @liza_rt_reactor_close(ptr %p0)
  %cond = icmp eq i32 %raw.i.i98, 0
  %spec.select1042 = select i1 %cond, i32 %v36.lcssa, i32 3
  ret i32 %spec.select1042

b17:                                              ; preds = %liza_net.reactor_poll.exit
  %v40 = extractvalue %variant.9 %common.ret.op.i.i84, 2
  %v0.i = extractvalue %variant.5 %v40, 0
  switch i32 %v0.i, label %b1.i [
    i32 2, label %0
    i32 3, label %0
    i32 0, label %b22_to_b23
    i32 1, label %b22_to_b23
    i32 4, label %b22_to_b23
    i32 5, label %b22_to_b23
    i32 6, label %b22_to_b23
    i32 7, label %b22_to_b23
    i32 8, label %0
    i32 9, label %b22_to_b23
    i32 10, label %b22_to_b23
    i32 11, label %b22_to_b23
  ]

b1.i:                                             ; preds = %b17
  unreachable

0:                                                ; preds = %b17, %b17, %b17
  br label %b22_to_b23

b42:                                              ; preds = %b22_to_b23
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %out.i.i)
  %code.i.i = call i32 @liza_rt_reactor_accept(ptr %p0, ptr nonnull %out.i.i)
  %value.fca.0.load.i.i = load i64, ptr %out.i.i, align 8
  %value.fca.1.load.i.i = load i64, ptr %value.fca.1.gep.i.i, align 8
  %value.fca.2.load.i.i = load i64, ptr %value.fca.2.gep.i.i, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %out.i.i)
  switch i32 %code.i.i, label %b36.i.i120 [
    i32 0, label %b1.i119
    i32 1, label %liza___liza_reactor_error.exit.i107
    i32 2, label %b4.i.i118
    i32 3, label %b7.i.i117
    i32 4, label %b10.i.i116
    i32 5, label %b13.i.i115
    i32 6, label %b16.i.i114
    i32 12, label %b34.i.i113
    i32 8, label %b22.i.i112
    i32 9, label %b25.i.i111
    i32 10, label %b28.i.i110
    i32 11, label %b31.i.i106
  ]

b1.i119:                                          ; preds = %b42
  %value.fca.0.insert.i.i = insertvalue [3 x i64] poison, i64 %value.fca.0.load.i.i, 0
  %value.fca.1.insert.i.i = insertvalue [3 x i64] %value.fca.0.insert.i.i, i64 %value.fca.1.load.i.i, 1
  %value.fca.2.insert.i.i = insertvalue [3 x i64] %value.fca.1.insert.i.i, i64 %value.fca.2.load.i.i, 2
  %v5.i = insertvalue %variant.11 zeroinitializer, [3 x i64] %value.fca.2.insert.i.i, 1
  br label %liza_net.reactor_accept.exit

b4.i.i118:                                        ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b7.i.i117:                                        ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b10.i.i116:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b13.i.i115:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b16.i.i114:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b22.i.i112:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b25.i.i111:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b28.i.i110:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b31.i.i106:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b34.i.i113:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

b36.i.i120:                                       ; preds = %b42
  br label %liza___liza_reactor_error.exit.i107

liza___liza_reactor_error.exit.i107:              ; preds = %b36.i.i120, %b34.i.i113, %b31.i.i106, %b28.i.i110, %b25.i.i111, %b22.i.i112, %b16.i.i114, %b13.i.i115, %b10.i.i116, %b7.i.i117, %b4.i.i118, %b42
  %common.ret.op.i.i108 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i118 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i117 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i116 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i115 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i114 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i112 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i111 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i110 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i106 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i113 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i120 ], [ zeroinitializer, %b42 ]
  %v8.i = insertvalue %variant.11 { i32 1, [3 x i64] zeroinitializer, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i108, 2
  br label %liza_net.reactor_accept.exit

liza_net.reactor_accept.exit:                     ; preds = %b1.i119, %liza___liza_reactor_error.exit.i107
  %common.ret.op.i109 = phi %variant.11 [ %v5.i, %b1.i119 ], [ %v8.i, %liza___liza_reactor_error.exit.i107 ]
  %v82 = extractvalue %variant.11 %common.ret.op.i109, 0
  %switch13 = icmp eq i32 %v82, 1
  br i1 %switch13, label %b45, label %b49

b45:                                              ; preds = %liza_net.reactor_accept.exit
  %v83 = extractvalue %variant.11 %common.ret.op.i109, 2
  %v0.i121 = extractvalue %variant.5 %v83, 0
  switch i32 %v0.i121, label %b1.i124 [
    i32 2, label %1
    i32 3, label %1
    i32 0, label %liza_liza_proxy.retry.exit125
    i32 1, label %liza_liza_proxy.retry.exit125
    i32 4, label %liza_liza_proxy.retry.exit125
    i32 5, label %liza_liza_proxy.retry.exit125
    i32 6, label %liza_liza_proxy.retry.exit125
    i32 7, label %liza_liza_proxy.retry.exit125
    i32 8, label %1
    i32 9, label %liza_liza_proxy.retry.exit125
    i32 10, label %liza_liza_proxy.retry.exit125
    i32 11, label %liza_liza_proxy.retry.exit125
  ]

b1.i124:                                          ; preds = %b45
  unreachable

1:                                                ; preds = %b45, %b45, %b45
  br label %liza_liza_proxy.retry.exit125

liza_liza_proxy.retry.exit125:                    ; preds = %b45, %b45, %b45, %b45, %b45, %b45, %b45, %b45, %b45, %1
  %common.ret.op.i123926 = phi i1 [ true, %1 ], [ false, %b45 ], [ false, %b45 ], [ false, %b45 ], [ false, %b45 ], [ false, %b45 ], [ false, %b45 ], [ false, %b45 ], [ false, %b45 ], [ false, %b45 ]
  %2 = phi i32 [ %v49, %1 ], [ 3, %b45 ], [ 3, %b45 ], [ 3, %b45 ], [ 3, %b45 ], [ 3, %b45 ], [ 3, %b45 ], [ 3, %b45 ], [ 3, %b45 ], [ 3, %b45 ]
  br label %b57_to_b58

b49:                                              ; preds = %liza_net.reactor_accept.exit
  %v90 = extractvalue %variant.11 %common.ret.op.i109, 1
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %out.i.i126)
  %code.i.i127 = call i32 @liza_rt_reactor_connect(ptr %p0, i16 %p2, ptr nonnull %out.i.i126)
  %value.fca.0.load.i.i128 = load i64, ptr %out.i.i126, align 8
  %value.fca.1.load.i.i130 = load i64, ptr %value.fca.1.gep.i.i129, align 8
  %value.fca.2.load.i.i132 = load i64, ptr %value.fca.2.gep.i.i131, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %out.i.i126)
  switch i32 %code.i.i127, label %b36.i.i152 [
    i32 0, label %b1.i147
    i32 1, label %liza___liza_reactor_error.exit.i134
    i32 2, label %b4.i.i146
    i32 3, label %b7.i.i145
    i32 4, label %b10.i.i144
    i32 5, label %b13.i.i143
    i32 6, label %b16.i.i142
    i32 12, label %b34.i.i141
    i32 8, label %b22.i.i140
    i32 9, label %b25.i.i139
    i32 10, label %b28.i.i138
    i32 11, label %b31.i.i133
  ]

b1.i147:                                          ; preds = %b49
  %value.fca.0.insert.i.i148 = insertvalue [3 x i64] poison, i64 %value.fca.0.load.i.i128, 0
  %value.fca.1.insert.i.i149 = insertvalue [3 x i64] %value.fca.0.insert.i.i148, i64 %value.fca.1.load.i.i130, 1
  %value.fca.2.insert.i.i150 = insertvalue [3 x i64] %value.fca.1.insert.i.i149, i64 %value.fca.2.load.i.i132, 2
  %v5.i151 = insertvalue %variant.11 zeroinitializer, [3 x i64] %value.fca.2.insert.i.i150, 1
  br label %liza_net.reactor_connect.exit

b4.i.i146:                                        ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b7.i.i145:                                        ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b10.i.i144:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b13.i.i143:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b16.i.i142:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b22.i.i140:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b25.i.i139:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b28.i.i138:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b31.i.i133:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b34.i.i141:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

b36.i.i152:                                       ; preds = %b49
  br label %liza___liza_reactor_error.exit.i134

liza___liza_reactor_error.exit.i134:              ; preds = %b36.i.i152, %b34.i.i141, %b31.i.i133, %b28.i.i138, %b25.i.i139, %b22.i.i140, %b16.i.i142, %b13.i.i143, %b10.i.i144, %b7.i.i145, %b4.i.i146, %b49
  %common.ret.op.i.i135 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i146 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i145 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i144 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i143 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i142 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i140 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i139 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i138 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i133 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i141 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i152 ], [ zeroinitializer, %b49 ]
  %v8.i136 = insertvalue %variant.11 { i32 1, [3 x i64] zeroinitializer, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i135, 2
  br label %liza_net.reactor_connect.exit

liza_net.reactor_connect.exit:                    ; preds = %b1.i147, %liza___liza_reactor_error.exit.i134
  %common.ret.op.i137 = phi %variant.11 [ %v5.i151, %b1.i147 ], [ %v8.i136, %liza___liza_reactor_error.exit.i134 ]
  %v93 = extractvalue %variant.11 %common.ret.op.i137, 0
  %switch14 = icmp eq i32 %v93, 1
  br i1 %switch14, label %b51, label %v101_ok

b51:                                              ; preds = %liza_net.reactor_connect.exit
  %id0.i.i = extractvalue [3 x i64] %v90, 0
  %id1.i.i = extractvalue [3 x i64] %v90, 1
  %id2.i.i = extractvalue [3 x i64] %v90, 2
  %raw.i.i153 = call i64 @liza_rt_reactor_disconnect(ptr %p0, i64 %id0.i.i, i64 %id1.i.i, i64 %id2.i.i)
  %.v562 = select i1 %p3, i32 3, i32 %v49
  %v53_mem.sroa.6.sroa.19.0.4135 = load i16, ptr %v53_mem.sroa.6.sroa.19, align 2
  %v53_mem.sroa.7.sroa.19.0.4134 = load i16, ptr %v53_mem.sroa.7.sroa.19, align 2
  %v53_mem.sroa.8.sroa.19.0.4133 = load i16, ptr %v53_mem.sroa.8.sroa.19, align 2
  %v53_mem.sroa.9.sroa.19.0.4132 = load i16, ptr %v53_mem.sroa.9.sroa.19, align 2
  %v53_mem.sroa.10.sroa.19.0.4131 = load i16, ptr %v53_mem.sroa.10.sroa.19, align 2
  %v53_mem.sroa.11.sroa.19.0.4130 = load i16, ptr %v53_mem.sroa.11.sroa.19, align 2
  %v53_mem.sroa.12.sroa.19.0.4129 = load i16, ptr %v53_mem.sroa.12.sroa.19, align 2
  %v53_mem.sroa.13.sroa.19.0.4128 = load i16, ptr %v53_mem.sroa.13.sroa.19, align 2
  br label %b56_to_b57

v101_ok:                                          ; preds = %liza_net.reactor_connect.exit
  %v100 = extractvalue %variant.11 %common.ret.op.i137, 1
  %v101_offset = zext nneg i32 %v68.7 to i64
  store i32 %v33_mem.sroa.0.0, ptr %v108_mem, align 8
  store i32 %v33_mem.sroa.3.sroa.0.0, ptr %v53_mem.sroa.6.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.3.sroa.3.0, ptr %v53_mem.sroa.6.sroa.5.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.3.sroa.5.0, ptr %v53_mem.sroa.6.sroa.6.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.3.sroa.7.0, ptr %v53_mem.sroa.6.sroa.7.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.3.sroa.9.0, ptr %v53_mem.sroa.6.sroa.8.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.3.sroa.11.0, ptr %v53_mem.sroa.6.sroa.9.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.3.sroa.13.0, ptr %v53_mem.sroa.6.sroa.10.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.3.sroa.15.0, ptr %v53_mem.sroa.6.sroa.11.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.3.sroa.17.0, ptr %v53_mem.sroa.6.sroa.12.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.3.sroa.19.0, ptr %v53_mem.sroa.6.sroa.13.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.6.sroa.14.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.3.sroa.21, i64 3, i1 false)
  store i32 %v33_mem.sroa.3.sroa.23.0, ptr %v53_mem.sroa.6.sroa.15.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.3.sroa.25.0, ptr %v53_mem.sroa.6.sroa.16.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.3.sroa.27.0, ptr %v53_mem.sroa.6.sroa.17.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.3.sroa.29.0, ptr %v53_mem.sroa.6.sroa.18.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.6.sroa.19.0. = load i16, ptr %v53_mem.sroa.6.sroa.19, align 2
  store i16 %v53_mem.sroa.6.sroa.19.0., ptr %v53_mem.sroa.6.sroa.19.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.3.sroa.33.0, ptr %v53_mem.sroa.6.sroa.20.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.3.sroa.35.0, ptr %v53_mem.sroa.6.sroa.21.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.3.sroa.37.0, ptr %v53_mem.sroa.6.sroa.22.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.3.sroa.39.0, ptr %v53_mem.sroa.6.sroa.23.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.6.sroa.24.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.3.sroa.41, i64 6, i1 false)
  store i32 %v33_mem.sroa.4.0, ptr %v53_mem.sroa.61127.0.v108_mem.sroa_idx, align 8
  store i32 %v33_mem.sroa.5.sroa.0.0, ptr %v53_mem.sroa.7.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.5.sroa.3.0, ptr %v53_mem.sroa.7.sroa.5.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.5.sroa.5.0, ptr %v53_mem.sroa.7.sroa.6.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.5.sroa.7.0, ptr %v53_mem.sroa.7.sroa.7.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.5.sroa.9.0, ptr %v53_mem.sroa.7.sroa.8.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.5.sroa.11.0, ptr %v53_mem.sroa.7.sroa.9.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.5.sroa.13.0, ptr %v53_mem.sroa.7.sroa.10.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.5.sroa.15.0, ptr %v53_mem.sroa.7.sroa.11.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.5.sroa.17.0, ptr %v53_mem.sroa.7.sroa.12.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.5.sroa.19.0, ptr %v53_mem.sroa.7.sroa.13.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.7.sroa.14.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.5.sroa.21, i64 3, i1 false)
  store i32 %v33_mem.sroa.5.sroa.23.0, ptr %v53_mem.sroa.7.sroa.15.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.5.sroa.25.0, ptr %v53_mem.sroa.7.sroa.16.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.5.sroa.27.0, ptr %v53_mem.sroa.7.sroa.17.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.5.sroa.29.0, ptr %v53_mem.sroa.7.sroa.18.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.7.sroa.19.0. = load i16, ptr %v53_mem.sroa.7.sroa.19, align 2
  store i16 %v53_mem.sroa.7.sroa.19.0., ptr %v53_mem.sroa.7.sroa.19.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.5.sroa.33.0, ptr %v53_mem.sroa.7.sroa.20.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.5.sroa.35.0, ptr %v53_mem.sroa.7.sroa.21.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.5.sroa.37.0, ptr %v53_mem.sroa.7.sroa.22.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.5.sroa.39.0, ptr %v53_mem.sroa.7.sroa.23.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.7.sroa.24.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.5.sroa.41, i64 6, i1 false)
  store i32 %v33_mem.sroa.6.0, ptr %v53_mem.sroa.71132.0.v108_mem.sroa_idx, align 8
  store i32 %v33_mem.sroa.7.sroa.0.0, ptr %v53_mem.sroa.8.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.7.sroa.3.0, ptr %v53_mem.sroa.8.sroa.5.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.7.sroa.5.0, ptr %v53_mem.sroa.8.sroa.6.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.7.sroa.7.0, ptr %v53_mem.sroa.8.sroa.7.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.7.sroa.9.0, ptr %v53_mem.sroa.8.sroa.8.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.7.sroa.11.0, ptr %v53_mem.sroa.8.sroa.9.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.7.sroa.13.0, ptr %v53_mem.sroa.8.sroa.10.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.7.sroa.15.0, ptr %v53_mem.sroa.8.sroa.11.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.7.sroa.17.0, ptr %v53_mem.sroa.8.sroa.12.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.7.sroa.19.0, ptr %v53_mem.sroa.8.sroa.13.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.8.sroa.14.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.7.sroa.21, i64 3, i1 false)
  store i32 %v33_mem.sroa.7.sroa.23.0, ptr %v53_mem.sroa.8.sroa.15.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.7.sroa.25.0, ptr %v53_mem.sroa.8.sroa.16.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.7.sroa.27.0, ptr %v53_mem.sroa.8.sroa.17.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.7.sroa.29.0, ptr %v53_mem.sroa.8.sroa.18.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.8.sroa.19.0. = load i16, ptr %v53_mem.sroa.8.sroa.19, align 2
  store i16 %v53_mem.sroa.8.sroa.19.0., ptr %v53_mem.sroa.8.sroa.19.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.7.sroa.33.0, ptr %v53_mem.sroa.8.sroa.20.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.7.sroa.35.0, ptr %v53_mem.sroa.8.sroa.21.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.7.sroa.37.0, ptr %v53_mem.sroa.8.sroa.22.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.7.sroa.39.0, ptr %v53_mem.sroa.8.sroa.23.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.8.sroa.24.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.7.sroa.41, i64 6, i1 false)
  store i32 %v33_mem.sroa.8.0, ptr %v53_mem.sroa.81137.0.v108_mem.sroa_idx, align 8
  store i32 %v33_mem.sroa.9.sroa.0.0, ptr %v53_mem.sroa.9.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.9.sroa.3.0, ptr %v53_mem.sroa.9.sroa.5.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.9.sroa.5.0, ptr %v53_mem.sroa.9.sroa.6.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.9.sroa.7.0, ptr %v53_mem.sroa.9.sroa.7.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.9.sroa.9.0, ptr %v53_mem.sroa.9.sroa.8.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.9.sroa.11.0, ptr %v53_mem.sroa.9.sroa.9.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.9.sroa.13.0, ptr %v53_mem.sroa.9.sroa.10.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.9.sroa.15.0, ptr %v53_mem.sroa.9.sroa.11.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.9.sroa.17.0, ptr %v53_mem.sroa.9.sroa.12.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.9.sroa.19.0, ptr %v53_mem.sroa.9.sroa.13.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.9.sroa.14.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v53_next.sroa.8.sroa.11, i64 3, i1 false)
  store i32 %v33_mem.sroa.9.sroa.23.0, ptr %v53_mem.sroa.9.sroa.15.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.9.sroa.25.0, ptr %v53_mem.sroa.9.sroa.16.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.9.sroa.27.0, ptr %v53_mem.sroa.9.sroa.17.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.9.sroa.29.0, ptr %v53_mem.sroa.9.sroa.18.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.9.sroa.19.0. = load i16, ptr %v53_mem.sroa.9.sroa.19, align 2
  store i16 %v53_mem.sroa.9.sroa.19.0., ptr %v53_mem.sroa.9.sroa.19.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.9.sroa.33.0, ptr %v53_mem.sroa.9.sroa.20.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.9.sroa.35.0, ptr %v53_mem.sroa.9.sroa.21.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.9.sroa.37.0, ptr %v53_mem.sroa.9.sroa.22.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.9.sroa.39.0, ptr %v53_mem.sroa.9.sroa.23.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.9.sroa.24.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.9.sroa.24, i64 6, i1 false)
  store i32 %v33_mem.sroa.10.0, ptr %v53_mem.sroa.91142.0.v108_mem.sroa_idx, align 8
  store i32 %v33_mem.sroa.11.sroa.0.0, ptr %v53_mem.sroa.10.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.11.sroa.3.0, ptr %v53_mem.sroa.10.sroa.5.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.11.sroa.5.0, ptr %v53_mem.sroa.10.sroa.6.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.11.sroa.7.0, ptr %v53_mem.sroa.10.sroa.7.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.11.sroa.9.0, ptr %v53_mem.sroa.10.sroa.8.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.11.sroa.11.0, ptr %v53_mem.sroa.10.sroa.9.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.11.sroa.13.0, ptr %v53_mem.sroa.10.sroa.10.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.11.sroa.15.0, ptr %v53_mem.sroa.10.sroa.11.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.11.sroa.17.0, ptr %v53_mem.sroa.10.sroa.12.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.11.sroa.19.0, ptr %v53_mem.sroa.10.sroa.13.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.10.sroa.14.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.10.sroa.14, i64 3, i1 false)
  store i32 %v33_mem.sroa.11.sroa.23.0, ptr %v53_mem.sroa.10.sroa.15.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.11.sroa.25.0, ptr %v53_mem.sroa.10.sroa.16.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.11.sroa.27.0, ptr %v53_mem.sroa.10.sroa.17.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.11.sroa.29.0, ptr %v53_mem.sroa.10.sroa.18.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.10.sroa.19.0. = load i16, ptr %v53_mem.sroa.10.sroa.19, align 2
  store i16 %v53_mem.sroa.10.sroa.19.0., ptr %v53_mem.sroa.10.sroa.19.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.11.sroa.33.0, ptr %v53_mem.sroa.10.sroa.20.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.11.sroa.35.0, ptr %v53_mem.sroa.10.sroa.21.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.11.sroa.37.0, ptr %v53_mem.sroa.10.sroa.22.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.11.sroa.39.0, ptr %v53_mem.sroa.10.sroa.23.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.10.sroa.24.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.10.sroa.24, i64 6, i1 false)
  store i32 %v33_mem.sroa.12.0, ptr %v53_mem.sroa.101147.0.v108_mem.sroa_idx, align 8
  store i32 %v33_mem.sroa.13.sroa.0.0, ptr %v53_mem.sroa.11.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.13.sroa.3.0, ptr %v53_mem.sroa.11.sroa.5.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.13.sroa.5.0, ptr %v53_mem.sroa.11.sroa.6.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.13.sroa.7.0, ptr %v53_mem.sroa.11.sroa.7.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.13.sroa.9.0, ptr %v53_mem.sroa.11.sroa.8.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.13.sroa.11.0, ptr %v53_mem.sroa.11.sroa.9.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.13.sroa.13.0, ptr %v53_mem.sroa.11.sroa.10.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.13.sroa.15.0, ptr %v53_mem.sroa.11.sroa.11.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.13.sroa.17.0, ptr %v53_mem.sroa.11.sroa.12.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.13.sroa.19.0, ptr %v53_mem.sroa.11.sroa.13.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.11.sroa.14.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.11.sroa.14, i64 3, i1 false)
  store i32 %v33_mem.sroa.13.sroa.23.0, ptr %v53_mem.sroa.11.sroa.15.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.13.sroa.25.0, ptr %v53_mem.sroa.11.sroa.16.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.13.sroa.27.0, ptr %v53_mem.sroa.11.sroa.17.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.13.sroa.29.0, ptr %v53_mem.sroa.11.sroa.18.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.11.sroa.19.0. = load i16, ptr %v53_mem.sroa.11.sroa.19, align 2
  store i16 %v53_mem.sroa.11.sroa.19.0., ptr %v53_mem.sroa.11.sroa.19.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.13.sroa.33.0, ptr %v53_mem.sroa.11.sroa.20.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.13.sroa.35.0, ptr %v53_mem.sroa.11.sroa.21.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.13.sroa.37.0, ptr %v53_mem.sroa.11.sroa.22.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.13.sroa.39.0, ptr %v53_mem.sroa.11.sroa.23.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.11.sroa.24.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.11.sroa.24, i64 6, i1 false)
  store i32 %v33_mem.sroa.14.0, ptr %v53_mem.sroa.111152.0.v108_mem.sroa_idx, align 8
  store i32 %v33_mem.sroa.15.sroa.0.0, ptr %v53_mem.sroa.12.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.15.sroa.3.0, ptr %v53_mem.sroa.12.sroa.5.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.15.sroa.5.0, ptr %v53_mem.sroa.12.sroa.6.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.15.sroa.7.0, ptr %v53_mem.sroa.12.sroa.7.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.15.sroa.9.0, ptr %v53_mem.sroa.12.sroa.8.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.15.sroa.11.0, ptr %v53_mem.sroa.12.sroa.9.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.15.sroa.13.0, ptr %v53_mem.sroa.12.sroa.10.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.15.sroa.15.0, ptr %v53_mem.sroa.12.sroa.11.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.15.sroa.17.0, ptr %v53_mem.sroa.12.sroa.12.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.15.sroa.19.0, ptr %v53_mem.sroa.12.sroa.13.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.12.sroa.14.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.12.sroa.14, i64 3, i1 false)
  store i32 %v33_mem.sroa.15.sroa.23.0, ptr %v53_mem.sroa.12.sroa.15.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.15.sroa.25.0, ptr %v53_mem.sroa.12.sroa.16.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.15.sroa.27.0, ptr %v53_mem.sroa.12.sroa.17.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.15.sroa.29.0, ptr %v53_mem.sroa.12.sroa.18.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.12.sroa.19.0. = load i16, ptr %v53_mem.sroa.12.sroa.19, align 2
  store i16 %v53_mem.sroa.12.sroa.19.0., ptr %v53_mem.sroa.12.sroa.19.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.15.sroa.33.0, ptr %v53_mem.sroa.12.sroa.20.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.15.sroa.35.0, ptr %v53_mem.sroa.12.sroa.21.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.15.sroa.37.0, ptr %v53_mem.sroa.12.sroa.22.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.15.sroa.39.0, ptr %v53_mem.sroa.12.sroa.23.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.12.sroa.24.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.12.sroa.24, i64 6, i1 false)
  store i32 %v33_mem.sroa.16.0, ptr %v53_mem.sroa.121157.0.v108_mem.sroa_idx, align 8
  store i32 %v33_mem.sroa.17.sroa.0.0, ptr %v53_mem.sroa.13.0.v108_mem.sroa_idx, align 4
  store i64 %v33_mem.sroa.17.sroa.3.0, ptr %v53_mem.sroa.13.sroa.5.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.17.sroa.5.0, ptr %v53_mem.sroa.13.sroa.6.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.17.sroa.7.0, ptr %v53_mem.sroa.13.sroa.7.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.17.sroa.9.0, ptr %v53_mem.sroa.13.sroa.8.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.17.sroa.11.0, ptr %v53_mem.sroa.13.sroa.9.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i64 %v33_mem.sroa.17.sroa.13.0, ptr %v53_mem.sroa.13.sroa.10.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.17.sroa.15.0, ptr %v53_mem.sroa.13.sroa.11.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i64 %v33_mem.sroa.17.sroa.17.0, ptr %v53_mem.sroa.13.sroa.12.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.17.sroa.19.0, ptr %v53_mem.sroa.13.sroa.13.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.13.sroa.14.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.13.sroa.14, i64 3, i1 false)
  store i32 %v33_mem.sroa.17.sroa.23.0, ptr %v53_mem.sroa.13.sroa.15.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i32 %v33_mem.sroa.17.sroa.25.0, ptr %v53_mem.sroa.13.sroa.16.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.17.sroa.27.0, ptr %v53_mem.sroa.13.sroa.17.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.17.sroa.29.0, ptr %v53_mem.sroa.13.sroa.18.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v53_mem.sroa.13.sroa.19.0. = load i16, ptr %v53_mem.sroa.13.sroa.19, align 2
  store i16 %v53_mem.sroa.13.sroa.19.0., ptr %v53_mem.sroa.13.sroa.19.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 2
  store i32 %v33_mem.sroa.17.sroa.33.0, ptr %v53_mem.sroa.13.sroa.20.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i32 %v33_mem.sroa.17.sroa.35.0, ptr %v53_mem.sroa.13.sroa.21.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  store i8 %v33_mem.sroa.17.sroa.37.0, ptr %v53_mem.sroa.13.sroa.22.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  store i8 %v33_mem.sroa.17.sroa.39.0, ptr %v53_mem.sroa.13.sroa.23.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.13.sroa.24.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.13.sroa.24, i64 6, i1 false)
  %v108_part = getelementptr [8 x %struct.liza_proxy.Pair], ptr %v108_mem, i64 0, i64 %v101_offset
  store i32 0, ptr %v108_part, align 8
  %v107.fca.0.1.0.extract = extractvalue [3 x i64] %v90, 0
  %v107.fca.0.1.0.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 8
  store i64 %v107.fca.0.1.0.extract, ptr %v107.fca.0.1.0.gep, align 8
  %v107.fca.0.1.1.extract = extractvalue [3 x i64] %v90, 1
  %v107.fca.0.1.1.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 16
  store i64 %v107.fca.0.1.1.extract, ptr %v107.fca.0.1.1.gep, align 8
  %v107.fca.0.1.2.extract = extractvalue [3 x i64] %v90, 2
  %v107.fca.0.1.2.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 24
  store i64 %v107.fca.0.1.2.extract, ptr %v107.fca.0.1.2.gep, align 8
  %v107.fca.1.0.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 32
  store i32 0, ptr %v107.fca.1.0.gep, align 8
  %v107.fca.1.1.0.extract = extractvalue [3 x i64] %v100, 0
  %v107.fca.1.1.0.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 40
  store i64 %v107.fca.1.1.0.extract, ptr %v107.fca.1.1.0.gep, align 8
  %v107.fca.1.1.1.extract = extractvalue [3 x i64] %v100, 1
  %v107.fca.1.1.1.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 48
  store i64 %v107.fca.1.1.1.extract, ptr %v107.fca.1.1.1.gep, align 8
  %v107.fca.1.1.2.extract = extractvalue [3 x i64] %v100, 2
  %v107.fca.1.1.2.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 56
  store i64 %v107.fca.1.1.2.extract, ptr %v107.fca.1.1.2.gep, align 8
  %v107.fca.2.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 64
  store i1 false, ptr %v107.fca.2.gep, align 8
  %v107.fca.3.0.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 68
  %v107.fca.4.0.gep = getelementptr inbounds nuw i8, ptr %v108_part, i64 80
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(10) %v107.fca.3.0.gep, i8 0, i64 10, i1 false)
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(10) %v107.fca.4.0.gep, i8 0, i64 10, i1 false)
  %v109_next.sroa.0.0.copyload = load i32, ptr %v108_mem, align 8
  %v109_next.sroa.4.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.6.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.4.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.6.sroa.5.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.6.sroa.6.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.6.sroa.7.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.6.sroa.8.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.6.sroa.9.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.4.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.6.sroa.10.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.6.sroa.11.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.6.sroa.12.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.6.sroa.13.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.6.sroa.15.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.4.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.6.sroa.16.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.6.sroa.17.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.4.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.6.sroa.18.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 1
  %3 = load i16, ptr %v53_mem.sroa.6.sroa.19.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.4.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.6.sroa.20.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.6.sroa.21.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.4.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.6.sroa.22.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.4.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.6.sroa.23.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v109_next.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.61127.0.v108_mem.sroa_idx, align 8
  %v109_next.sroa.10.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.7.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.10.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.7.sroa.5.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.7.sroa.6.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.7.sroa.7.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.7.sroa.8.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.7.sroa.9.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.10.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.7.sroa.10.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.7.sroa.11.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.7.sroa.12.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.7.sroa.13.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.7.sroa.15.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.10.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.7.sroa.16.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.7.sroa.17.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.10.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.7.sroa.18.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 1
  %4 = load i16, ptr %v53_mem.sroa.7.sroa.19.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.10.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.7.sroa.20.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.7.sroa.21.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.10.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.7.sroa.22.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.10.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.7.sroa.23.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v109_next.sroa.13.0.copyload = load i32, ptr %v53_mem.sroa.71132.0.v108_mem.sroa_idx, align 8
  %v109_next.sroa.16.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.8.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.16.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.8.sroa.5.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.8.sroa.6.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.8.sroa.7.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.8.sroa.8.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.8.sroa.9.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.16.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.8.sroa.10.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.8.sroa.11.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.8.sroa.12.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.8.sroa.13.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.8.sroa.15.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.16.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.8.sroa.16.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.8.sroa.17.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.16.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.8.sroa.18.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 1
  %5 = load i16, ptr %v53_mem.sroa.8.sroa.19.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.16.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.8.sroa.20.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.8.sroa.21.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.16.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.8.sroa.22.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.16.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.8.sroa.23.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v109_next.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.81137.0.v108_mem.sroa_idx, align 8
  %v109_next.sroa.22.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.9.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.22.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.9.sroa.5.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.9.sroa.6.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.9.sroa.7.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.9.sroa.8.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.9.sroa.9.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.22.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.9.sroa.10.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.9.sroa.11.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.9.sroa.12.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.9.sroa.13.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.9.sroa.15.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.22.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.9.sroa.16.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.9.sroa.17.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.22.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.9.sroa.18.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 1
  %6 = load i16, ptr %v53_mem.sroa.9.sroa.19.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.22.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.9.sroa.20.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.9.sroa.21.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.22.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.9.sroa.22.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.22.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.9.sroa.23.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v109_next.sroa.25.0.copyload = load i32, ptr %v53_mem.sroa.91142.0.v108_mem.sroa_idx, align 8
  %v109_next.sroa.28.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.10.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.28.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.10.sroa.5.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.10.sroa.6.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.10.sroa.7.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.10.sroa.8.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.10.sroa.9.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.28.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.10.sroa.10.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.10.sroa.11.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.10.sroa.12.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.10.sroa.13.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.10.sroa.15.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.28.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.10.sroa.16.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.10.sroa.17.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.28.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.10.sroa.18.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 1
  %7 = load i16, ptr %v53_mem.sroa.10.sroa.19.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.28.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.10.sroa.20.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.10.sroa.21.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.28.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.10.sroa.22.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.28.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.10.sroa.23.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v109_next.sroa.31.0.copyload = load i32, ptr %v53_mem.sroa.101147.0.v108_mem.sroa_idx, align 8
  %v109_next.sroa.34.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.11.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.34.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.11.sroa.5.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.11.sroa.6.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.11.sroa.7.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.11.sroa.8.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.11.sroa.9.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.34.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.11.sroa.10.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.11.sroa.11.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.11.sroa.12.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.11.sroa.13.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.11.sroa.15.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.34.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.11.sroa.16.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.11.sroa.17.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.34.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.11.sroa.18.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 1
  %8 = load i16, ptr %v53_mem.sroa.11.sroa.19.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.34.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.11.sroa.20.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.11.sroa.21.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.34.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.11.sroa.22.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.34.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.11.sroa.23.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v109_next.sroa.37.0.copyload = load i32, ptr %v53_mem.sroa.111152.0.v108_mem.sroa_idx, align 8
  %v109_next.sroa.40.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.12.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.40.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.12.sroa.5.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.12.sroa.6.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.12.sroa.7.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.12.sroa.8.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.12.sroa.9.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.40.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.12.sroa.10.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.12.sroa.11.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.12.sroa.12.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.12.sroa.13.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.12.sroa.15.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.40.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.12.sroa.16.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.12.sroa.17.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.40.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.12.sroa.18.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 1
  %9 = load i16, ptr %v53_mem.sroa.12.sroa.19.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.40.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.12.sroa.20.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.12.sroa.21.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.40.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.12.sroa.22.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.40.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.12.sroa.23.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, align 1
  %v109_next.sroa.43.0.copyload = load i32, ptr %v53_mem.sroa.121157.0.v108_mem.sroa_idx, align 8
  %v109_next.sroa.46.sroa.0.0.copyload = load i32, ptr %v53_mem.sroa.13.0.v108_mem.sroa_idx, align 4
  %v109_next.sroa.46.sroa.4.0.copyload = load i64, ptr %v53_mem.sroa.13.sroa.5.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.5.0.copyload = load i64, ptr %v53_mem.sroa.13.sroa.6.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.6.0.copyload = load i64, ptr %v53_mem.sroa.13.sroa.7.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.7.0.copyload = load i32, ptr %v53_mem.sroa.13.sroa.8.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.8.0.copyload = load i32, ptr %v53_mem.sroa.13.sroa.9.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.46.sroa.9.0.copyload = load i64, ptr %v53_mem.sroa.13.sroa.10.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.10.0.copyload = load i64, ptr %v53_mem.sroa.13.sroa.11.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.11.0.copyload = load i64, ptr %v53_mem.sroa.13.sroa.12.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.12.0.copyload = load i8, ptr %v53_mem.sroa.13.sroa.13.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.14.0.copyload = load i32, ptr %v53_mem.sroa.13.sroa.15.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.46.sroa.15.0.copyload = load i32, ptr %v53_mem.sroa.13.sroa.16.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.16.0.copyload = load i8, ptr %v53_mem.sroa.13.sroa.17.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.46.sroa.17.0.copyload = load i8, ptr %v53_mem.sroa.13.sroa.18.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 1
  %10 = load i16, ptr %v53_mem.sroa.13.sroa.19.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 2
  %v109_next.sroa.46.sroa.19.0.copyload = load i32, ptr %v53_mem.sroa.13.sroa.20.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.20.0.copyload = load i32, ptr %v53_mem.sroa.13.sroa.21.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 4
  %v109_next.sroa.46.sroa.21.0.copyload = load i8, ptr %v53_mem.sroa.13.sroa.22.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 8
  %v109_next.sroa.46.sroa.22.0.copyload = load i8, ptr %v53_mem.sroa.13.sroa.23.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, align 1
  br label %b56_to_b57

v132_ok:                                          ; preds = %b58_to_b59, %b274_to_b59
  %indvars.iv = phi i64 [ %indvars.iv.next, %b274_to_b59 ], [ 0, %b58_to_b59 ]
  %v1251105 = phi i32 [ %v560, %b274_to_b59 ], [ %v119, %b58_to_b59 ]
  %v132_ptr = getelementptr [8 x %struct.liza_proxy.Pair], ptr %v122_mem, i64 0, i64 %indvars.iv
  %v132.fca.0.0.load = load i32, ptr %v132_ptr, align 8
  %v132.fca.0.0.insert = insertvalue %struct.liza_proxy.Pair poison, i32 %v132.fca.0.0.load, 0, 0
  %v132.fca.0.1.0.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 8
  %v132.fca.0.1.0.load = load i64, ptr %v132.fca.0.1.0.gep, align 8
  %v132.fca.0.1.0.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.0.0.insert, i64 %v132.fca.0.1.0.load, 0, 1, 0
  %v132.fca.0.1.1.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 16
  %v132.fca.0.1.1.load = load i64, ptr %v132.fca.0.1.1.gep, align 8
  %v132.fca.0.1.1.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.0.1.0.insert, i64 %v132.fca.0.1.1.load, 0, 1, 1
  %v132.fca.0.1.2.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 24
  %v132.fca.0.1.2.load = load i64, ptr %v132.fca.0.1.2.gep, align 8
  %v132.fca.0.1.2.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.0.1.1.insert, i64 %v132.fca.0.1.2.load, 0, 1, 2
  %v132.fca.1.0.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 32
  %v132.fca.1.0.load = load i32, ptr %v132.fca.1.0.gep, align 8
  %v132.fca.1.0.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.0.1.2.insert, i32 %v132.fca.1.0.load, 1, 0
  %v132.fca.1.1.0.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 40
  %v132.fca.1.1.0.load = load i64, ptr %v132.fca.1.1.0.gep, align 8
  %v132.fca.1.1.0.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.1.0.insert, i64 %v132.fca.1.1.0.load, 1, 1, 0
  %v132.fca.1.1.1.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 48
  %v132.fca.1.1.1.load = load i64, ptr %v132.fca.1.1.1.gep, align 8
  %v132.fca.1.1.1.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.1.1.0.insert, i64 %v132.fca.1.1.1.load, 1, 1, 1
  %v132.fca.1.1.2.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 56
  %v132.fca.1.1.2.load = load i64, ptr %v132.fca.1.1.2.gep, align 8
  %v132.fca.1.1.2.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.1.1.1.insert, i64 %v132.fca.1.1.2.load, 1, 1, 2
  %v132.fca.2.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 64
  %v132.fca.2.load = load i1, ptr %v132.fca.2.gep, align 8
  %v132.fca.2.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.1.1.2.insert, i1 %v132.fca.2.load, 2
  %v132.fca.3.0.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 68
  %v132.fca.3.0.load = load i32, ptr %v132.fca.3.0.gep, align 4
  %v132.fca.3.0.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.2.insert, i32 %v132.fca.3.0.load, 3, 0
  %v132.fca.3.1.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 72
  %v132.fca.3.1.load = load i32, ptr %v132.fca.3.1.gep, align 8
  %v132.fca.3.1.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.3.0.insert, i32 %v132.fca.3.1.load, 3, 1
  %v132.fca.3.2.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 76
  %v132.fca.3.2.load = load i1, ptr %v132.fca.3.2.gep, align 4
  %v132.fca.3.2.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.3.1.insert, i1 %v132.fca.3.2.load, 3, 2
  %v132.fca.3.3.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 77
  %v132.fca.3.3.load = load i1, ptr %v132.fca.3.3.gep, align 1
  %v132.fca.3.3.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.3.2.insert, i1 %v132.fca.3.3.load, 3, 3
  %v132.fca.4.0.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 80
  %v132.fca.4.0.load = load i32, ptr %v132.fca.4.0.gep, align 8
  %v132.fca.4.0.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.3.3.insert, i32 %v132.fca.4.0.load, 4, 0
  %v132.fca.4.1.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 84
  %v132.fca.4.1.load = load i32, ptr %v132.fca.4.1.gep, align 4
  %v132.fca.4.1.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.4.0.insert, i32 %v132.fca.4.1.load, 4, 1
  %v132.fca.4.2.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 88
  %v132.fca.4.2.load = load i1, ptr %v132.fca.4.2.gep, align 8
  %v132.fca.4.2.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.4.1.insert, i1 %v132.fca.4.2.load, 4, 2
  %v132.fca.4.3.gep = getelementptr inbounds nuw i8, ptr %v132_ptr, i64 89
  %v132.fca.4.3.load = load i1, ptr %v132.fca.4.3.gep, align 1
  %v132.fca.4.3.insert = insertvalue %struct.liza_proxy.Pair %v132.fca.4.2.insert, i1 %v132.fca.4.3.load, 4, 3
  %switch15 = icmp eq i32 %v132.fca.0.0.load, 1
  br i1 %switch15, label %b66_to_b274, label %b67

b67:                                              ; preds = %v132_ok
  %switch16 = icmp eq i32 %v132.fca.1.0.load, 1
  br i1 %switch16, label %v554_ok, label %b70

b70:                                              ; preds = %b67
  %raw.i.i179 = call i64 @liza_rt_reactor_ready(ptr %p0, i64 %v132.fca.0.1.0.load, i64 %v132.fca.0.1.1.load, i64 %v132.fca.0.1.2.load)
  %v3.i.i180 = icmp ult i64 %raw.i.i179, 4294967296
  br i1 %v3.i.i180, label %b1.i.i199, label %v8_ok.i.i181

b1.i.i199:                                        ; preds = %b70
  %v4.i.i200 = trunc nuw i64 %raw.i.i179 to i32
  %v5.i.i201 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i200, 1
  br label %liza_net.reactor_ready.exit

v8_ok.i.i181:                                     ; preds = %b70
  %v1.i.i182 = lshr i64 %raw.i.i179, 32
  %v8.i.i183 = trunc nuw i64 %v1.i.i182 to i32
  switch i32 %v8.i.i183, label %b36.i.i.i198 [
    i32 1, label %liza___liza_reactor_error.exit.i.i185
    i32 2, label %b4.i.i.i197
    i32 3, label %b7.i.i.i196
    i32 4, label %b10.i.i.i195
    i32 5, label %b13.i.i.i194
    i32 6, label %b16.i.i.i193
    i32 12, label %b34.i.i.i192
    i32 8, label %b22.i.i.i191
    i32 9, label %b25.i.i.i190
    i32 10, label %b28.i.i.i189
    i32 11, label %b31.i.i.i184
  ]

b4.i.i.i197:                                      ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b7.i.i.i196:                                      ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b10.i.i.i195:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b13.i.i.i194:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b16.i.i.i193:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b22.i.i.i191:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b25.i.i.i190:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b28.i.i.i189:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b31.i.i.i184:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b34.i.i.i192:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

b36.i.i.i198:                                     ; preds = %v8_ok.i.i181
  br label %liza___liza_reactor_error.exit.i.i185

liza___liza_reactor_error.exit.i.i185:            ; preds = %b36.i.i.i198, %b34.i.i.i192, %b31.i.i.i184, %b28.i.i.i189, %b25.i.i.i190, %b22.i.i.i191, %b16.i.i.i193, %b13.i.i.i194, %b10.i.i.i195, %b7.i.i.i196, %b4.i.i.i197, %v8_ok.i.i181
  %common.ret.op.i.i.i186 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i197 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i196 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i195 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i194 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i193 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i191 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i190 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i189 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i184 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i192 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i198 ], [ zeroinitializer, %v8_ok.i.i181 ]
  %v10.i.i187 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i186, 2
  br label %liza_net.reactor_ready.exit

liza_net.reactor_ready.exit:                      ; preds = %b1.i.i199, %liza___liza_reactor_error.exit.i.i185
  %common.ret.op.i.i188 = phi %variant.9 [ %v5.i.i201, %b1.i.i199 ], [ %v10.i.i187, %liza___liza_reactor_error.exit.i.i185 ]
  %v147 = extractvalue %variant.9 %common.ret.op.i.i188, 0
  %switch17 = icmp ne i32 %v147, 1
  %v151 = extractvalue %variant.9 %common.ret.op.i.i188, 1
  %11 = and i32 %v151, 5
  %12 = icmp ne i32 %11, 0
  %v153 = select i1 %switch17, i32 0, i32 3
  %raw.i.i205 = call i64 @liza_rt_reactor_ready(ptr %p0, i64 %v132.fca.1.1.0.load, i64 %v132.fca.1.1.1.load, i64 %v132.fca.1.1.2.load)
  %v3.i.i206 = icmp ult i64 %raw.i.i205, 4294967296
  br i1 %v3.i.i206, label %b1.i.i225, label %v8_ok.i.i207

b1.i.i225:                                        ; preds = %liza_net.reactor_ready.exit
  %v4.i.i226 = trunc nuw i64 %raw.i.i205 to i32
  %v5.i.i227 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i226, 1
  br label %liza_net.reactor_ready.exit228

v8_ok.i.i207:                                     ; preds = %liza_net.reactor_ready.exit
  %v1.i.i208 = lshr i64 %raw.i.i205, 32
  %v8.i.i209 = trunc nuw i64 %v1.i.i208 to i32
  switch i32 %v8.i.i209, label %b36.i.i.i224 [
    i32 1, label %liza___liza_reactor_error.exit.i.i211
    i32 2, label %b4.i.i.i223
    i32 3, label %b7.i.i.i222
    i32 4, label %b10.i.i.i221
    i32 5, label %b13.i.i.i220
    i32 6, label %b16.i.i.i219
    i32 12, label %b34.i.i.i218
    i32 8, label %b22.i.i.i217
    i32 9, label %b25.i.i.i216
    i32 10, label %b28.i.i.i215
    i32 11, label %b31.i.i.i210
  ]

b4.i.i.i223:                                      ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b7.i.i.i222:                                      ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b10.i.i.i221:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b13.i.i.i220:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b16.i.i.i219:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b22.i.i.i217:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b25.i.i.i216:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b28.i.i.i215:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b31.i.i.i210:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b34.i.i.i218:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

b36.i.i.i224:                                     ; preds = %v8_ok.i.i207
  br label %liza___liza_reactor_error.exit.i.i211

liza___liza_reactor_error.exit.i.i211:            ; preds = %b36.i.i.i224, %b34.i.i.i218, %b31.i.i.i210, %b28.i.i.i215, %b25.i.i.i216, %b22.i.i.i217, %b16.i.i.i219, %b13.i.i.i220, %b10.i.i.i221, %b7.i.i.i222, %b4.i.i.i223, %v8_ok.i.i207
  %common.ret.op.i.i.i212 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i223 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i222 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i221 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i220 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i219 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i217 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i216 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i215 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i210 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i218 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i224 ], [ zeroinitializer, %v8_ok.i.i207 ]
  %v10.i.i213 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i212, 2
  br label %liza_net.reactor_ready.exit228

liza_net.reactor_ready.exit228:                   ; preds = %b1.i.i225, %liza___liza_reactor_error.exit.i.i211
  %common.ret.op.i.i214 = phi %variant.9 [ %v5.i.i227, %b1.i.i225 ], [ %v10.i.i213, %liza___liza_reactor_error.exit.i.i211 ]
  %v156 = extractvalue %variant.9 %common.ret.op.i.i214, 0
  %switch44 = icmp eq i32 %v156, 1
  br i1 %switch44, label %b259, label %b78

b78:                                              ; preds = %liza_net.reactor_ready.exit228
  %v160 = extractvalue %variant.9 %common.ret.op.i.i214, 1
  %13 = and i32 %v160, 5
  %14 = icmp ne i32 %13, 0
  %not.v161 = xor i1 %switch17, true
  %15 = select i1 %not.v161, i1 true, i1 %v132.fca.2.load
  br i1 %15, label %b91, label %b82

b82:                                              ; preds = %b78
  %raw.i.i232 = call i64 @liza_rt_reactor_finish_connect(ptr %p0, i64 %v132.fca.1.1.0.load, i64 %v132.fca.1.1.1.load, i64 %v132.fca.1.1.2.load)
  %v4.i = icmp ult i64 %raw.i.i232, 4294967296
  br i1 %v4.i, label %b1.i247, label %v10_ok.i

b1.i247:                                          ; preds = %b82
  %v6.i248 = icmp eq i64 %raw.i.i232, 1
  %v7.i = insertvalue %variant.12 zeroinitializer, i1 %v6.i248, 1
  br label %liza_net.reactor_finish_connect.exit

v10_ok.i:                                         ; preds = %b82
  %v2.i = lshr i64 %raw.i.i232, 32
  %v10.i = trunc nuw i64 %v2.i to i32
  switch i32 %v10.i, label %b36.i.i246 [
    i32 1, label %liza___liza_reactor_error.exit.i234
    i32 2, label %b4.i.i245
    i32 3, label %b7.i.i244
    i32 4, label %b10.i.i243
    i32 5, label %b13.i.i242
    i32 6, label %b16.i.i241
    i32 12, label %b34.i.i240
    i32 8, label %b22.i.i239
    i32 9, label %b25.i.i238
    i32 10, label %b28.i.i237
    i32 11, label %b31.i.i233
  ]

b4.i.i245:                                        ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b7.i.i244:                                        ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b10.i.i243:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b13.i.i242:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b16.i.i241:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b22.i.i239:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b25.i.i238:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b28.i.i237:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b31.i.i233:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b34.i.i240:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

b36.i.i246:                                       ; preds = %v10_ok.i
  br label %liza___liza_reactor_error.exit.i234

liza___liza_reactor_error.exit.i234:              ; preds = %b36.i.i246, %b34.i.i240, %b31.i.i233, %b28.i.i237, %b25.i.i238, %b22.i.i239, %b16.i.i241, %b13.i.i242, %b10.i.i243, %b7.i.i244, %b4.i.i245, %v10_ok.i
  %common.ret.op.i.i235 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i245 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i244 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i243 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i242 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i241 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i239 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i238 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i237 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i233 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i240 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i246 ], [ zeroinitializer, %v10_ok.i ]
  %v12.i = insertvalue %variant.12 { i32 1, i1 false, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i235, 2
  br label %liza_net.reactor_finish_connect.exit

liza_net.reactor_finish_connect.exit:             ; preds = %b1.i247, %liza___liza_reactor_error.exit.i234
  %common.ret.op.i236 = phi %variant.12 [ %v7.i, %b1.i247 ], [ %v12.i, %liza___liza_reactor_error.exit.i234 ]
  %v169 = extractvalue %variant.12 %common.ret.op.i236, 0
  %switch18 = icmp eq i32 %v169, 1
  br i1 %switch18, label %b85, label %b89

b85:                                              ; preds = %liza_net.reactor_finish_connect.exit
  %v170 = extractvalue %variant.12 %common.ret.op.i236, 2
  %v0.i249 = extractvalue %variant.5 %v170, 0
  switch i32 %v0.i249, label %b1.i252 [
    i32 2, label %b95
    i32 3, label %b95
    i32 0, label %b259
    i32 1, label %b259
    i32 4, label %b259
    i32 5, label %b259
    i32 6, label %b259
    i32 7, label %b259
    i32 8, label %b95
    i32 9, label %b259
    i32 10, label %b259
    i32 11, label %b259
  ]

b1.i252:                                          ; preds = %b85
  unreachable

b89:                                              ; preds = %liza_net.reactor_finish_connect.exit
  %v177 = extractvalue %variant.12 %common.ret.op.i236, 1
  %v179 = insertvalue %struct.liza_proxy.Pair %v132.fca.4.3.insert, i1 %v177, 2
  br label %b95

b91:                                              ; preds = %b78
  br i1 %switch17, label %b95, label %b259

b95:                                              ; preds = %b85, %b85, %b85, %b89, %b91
  %v183942 = phi %struct.liza_proxy.Pair [ %v132.fca.4.3.insert, %b91 ], [ %v179, %b89 ], [ %v132.fca.4.3.insert, %b85 ], [ %v132.fca.4.3.insert, %b85 ], [ %v132.fca.4.3.insert, %b85 ]
  %v190 = extractvalue %struct.liza_proxy.Pair %v183942, 3
  %v0.i.i = extractvalue %struct.relay.direction.Direction %v190, 0
  %v1.i.i254 = extractvalue %struct.relay.direction.Direction %v190, 1
  %v2.i.i = icmp ule i32 %v0.i.i, %v1.i.i254
  %v6.i.i255 = icmp ult i32 %v1.i.i254, 2049
  %v7.i.i = and i1 %v2.i.i, %v6.i.i255
  br i1 %v7.i.i, label %b4.i.i257, label %b114

b4.i.i257:                                        ; preds = %b95
  %v9.i.i = extractvalue %struct.relay.direction.Direction %v190, 3
  %v9.i.not.i = xor i1 %v9.i.i, true
  %v12.i.i = extractvalue %struct.relay.direction.Direction %v190, 2
  %v16.i.i258 = icmp eq i32 %v0.i.i, %v1.i.i254
  %v17.i.i = and i1 %v12.i.i, %v16.i.i258
  %or.cond.i = select i1 %v9.i.not.i, i1 true, i1 %v17.i.i
  br i1 %or.cond.i, label %liza_relay.direction.readable.exit, label %b114

liza_relay.direction.readable.exit:               ; preds = %b4.i.i257
  %v1931040 = icmp ne i32 %v1.i.i254, 2048
  %not.v12.i.i = xor i1 %v12.i.i, true
  %v193 = and i1 %v1931040, %not.v12.i.i
  %16 = select i1 %v193, i1 %switch17, i1 false
  %or.cond = select i1 %16, i1 %12, i1 false
  br i1 %or.cond, label %b4.i.i266, label %b114

b4.i.i266:                                        ; preds = %liza_relay.direction.readable.exit
  %indvars.iv.tr = trunc nuw nsw i64 %indvars.iv to i32
  %17 = shl nuw nsw i32 %indvars.iv.tr, 12
  %v206_pair1034 = or disjoint i32 %v1.i.i254, %17
  %v8_pair4.i274 = sub nuw nsw i32 2048, %v1.i.i254
  %spec.select.i275 = select i1 %v12.i.i, i32 0, i32 %v8_pair4.i274
  %raw.i = call i64 @liza_rt_reactor_read(ptr %p0, i64 %v132.fca.0.1.0.load, i64 %v132.fca.0.1.1.load, i64 %v132.fca.0.1.2.load, ptr %p.i, i32 %n.i, i32 %v206_pair1034, i32 %spec.select.i275)
  %count_read.i = trunc i64 %raw.i to i32
  %failed.i = icmp ugt i64 %raw.i, 4294967295
  br i1 %failed.i, label %b104, label %b1.i295

b104:                                             ; preds = %b4.i.i266
  %wide.i = lshr i64 %raw.i, 32
  %code.i = trunc nuw i64 %wide.i to i32
  switch i32 %code.i, label %b1.i280 [
    i32 3, label %b114
    i32 4, label %b114
    i32 1, label %b259
    i32 2, label %b259
    i32 5, label %b259
    i32 6, label %b259
    i32 7, label %b259
    i32 8, label %b259
    i32 9, label %b114
    i32 10, label %b259
    i32 11, label %b259
    i32 12, label %b259
  ]

b1.i280:                                          ; preds = %b104
  unreachable

b1.i295:                                          ; preds = %b4.i.i266
  %or.cond25.i = or i1 %v9.i.i, %v12.i.i
  %v12.i297 = icmp ult i32 %v8_pair4.i274, %count_read.i
  %or.cond26.i = select i1 %or.cond25.i, i1 true, i1 %v12.i297
  br i1 %or.cond26.i, label %liza_relay.direction.read.exit, label %b12.i

b12.i:                                            ; preds = %b1.i295
  %v17.i = icmp eq i32 %count_read.i, 0
  br i1 %v17.i, label %b13.i, label %v26_ok.i

b13.i:                                            ; preds = %b12.i
  %v22_field0.i = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i.i, 0
  %v22_field1.i = insertvalue %struct.relay.direction.Direction %v22_field0.i, i32 %v1.i.i254, 1
  %v22_field2.i = insertvalue %struct.relay.direction.Direction %v22_field1.i, i1 true, 2
  %v22.i = insertvalue %struct.relay.direction.Direction %v22_field2.i, i1 false, 3
  %v23.i = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v22.i, 1
  br label %liza_relay.direction.read.exit

v26_ok.i:                                         ; preds = %b12.i
  %v26_pair23.i = add nuw nsw i32 %v1.i.i254, %count_read.i
  %v29_field0.i = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i.i, 0
  %v29_field1.i = insertvalue %struct.relay.direction.Direction %v29_field0.i, i32 %v26_pair23.i, 1
  %v29_field2.i = insertvalue %struct.relay.direction.Direction %v29_field1.i, i1 false, 2
  %v29.i = insertvalue %struct.relay.direction.Direction %v29_field2.i, i1 false, 3
  %v30.i = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v29.i, 1
  br label %liza_relay.direction.read.exit

liza_relay.direction.read.exit:                   ; preds = %b1.i295, %b13.i, %v26_ok.i
  %common.ret.op.i287 = phi %variant.6 [ %v23.i, %b13.i ], [ %v30.i, %v26_ok.i ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b1.i295 ]
  %v225 = extractvalue %variant.6 %common.ret.op.i287, 0
  %switch20 = icmp eq i32 %v225, 1
  br i1 %switch20, label %b259, label %b111

b111:                                             ; preds = %liza_relay.direction.read.exit
  %v229 = extractvalue %variant.6 %common.ret.op.i287, 1
  %v231 = insertvalue %struct.liza_proxy.Pair %v183942, %struct.relay.direction.Direction %v229, 3
  br label %b114

b114:                                             ; preds = %b104, %b104, %b104, %b4.i.i257, %b95, %b111, %liza_relay.direction.readable.exit
  %v239 = phi %struct.liza_proxy.Pair [ %v183942, %liza_relay.direction.readable.exit ], [ %v231, %b111 ], [ %v183942, %b95 ], [ %v183942, %b4.i.i257 ], [ %v183942, %b104 ], [ %v183942, %b104 ], [ %v183942, %b104 ]
  %v243 = extractvalue %struct.liza_proxy.Pair %v239, 2
  br i1 %v243, label %b118, label %b134

b118:                                             ; preds = %b114
  %v246 = extractvalue %struct.liza_proxy.Pair %v239, 3
  %v0.i.i298 = extractvalue %struct.relay.direction.Direction %v246, 0
  %v1.i.i299 = extractvalue %struct.relay.direction.Direction %v246, 1
  %v2.i.i300 = icmp ugt i32 %v0.i.i298, %v1.i.i299
  %v6.i.i301 = icmp ugt i32 %v1.i.i299, 2048
  %v7.i.i302.not4118 = or i1 %v2.i.i300, %v6.i.i301
  %v9.i.i305 = extractvalue %struct.relay.direction.Direction %v246, 3
  %v249.not = icmp eq i32 %v1.i.i299, %v0.i.i298
  %or.cond1111 = or i1 %v9.i.i305, %v249.not
  %or.cond4065 = select i1 %v7.i.i302.not4118, i1 true, i1 %or.cond1111
  br i1 %or.cond4065, label %b134, label %v253_ok

v253_ok:                                          ; preds = %b118
  %indvars.iv.tr4051 = trunc nuw nsw i64 %indvars.iv to i32
  %18 = shl nuw nsw i32 %indvars.iv.tr4051, 12
  %v256_pair = call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %18, i32 %v0.i.i298)
  %v256_overflow = extractvalue { i32, i1 } %v256_pair, 1
  br i1 %v256_overflow, label %v256_trap, label %b3.i325

v256_trap:                                        ; preds = %v253_ok
  call void @llvm.trap()
  unreachable

b3.i325:                                          ; preds = %v253_ok
  %v5_pair.i326 = call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v1.i.i299, i32 %v0.i.i298)
  %v5_overflow.i328 = extractvalue { i32, i1 } %v5_pair.i326, 1
  br i1 %v5_overflow.i328, label %v5_trap.i329, label %liza_relay.direction.queued.exit330

v5_trap.i329:                                     ; preds = %b3.i325
  call void @llvm.trap()
  unreachable

liza_relay.direction.queued.exit330:              ; preds = %b3.i325
  %v256 = extractvalue { i32, i1 } %v256_pair, 0
  %v5.i327 = extractvalue { i32, i1 } %v5_pair.i326, 0
  %raw.i.i334 = call i64 @liza_rt_reactor_write(ptr %p0, i64 %v132.fca.1.1.0.load, i64 %v132.fca.1.1.1.load, i64 %v132.fca.1.1.2.load, ptr %p.i, i32 %n.i, i32 %v256, i32 %v5.i327)
  %v3.i.i335 = icmp ult i64 %raw.i.i334, 4294967296
  br i1 %v3.i.i335, label %b1.i.i354, label %v8_ok.i.i336

b1.i.i354:                                        ; preds = %liza_relay.direction.queued.exit330
  %v4.i.i355 = trunc nuw i64 %raw.i.i334 to i32
  %v5.i.i356 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i355, 1
  br label %liza_net.reactor_write.exit

v8_ok.i.i336:                                     ; preds = %liza_relay.direction.queued.exit330
  %v1.i.i337 = lshr i64 %raw.i.i334, 32
  %v8.i.i338 = trunc nuw i64 %v1.i.i337 to i32
  switch i32 %v8.i.i338, label %b36.i.i.i353 [
    i32 1, label %liza___liza_reactor_error.exit.i.i340
    i32 2, label %b4.i.i.i352
    i32 3, label %b7.i.i.i351
    i32 4, label %b10.i.i.i350
    i32 5, label %b13.i.i.i349
    i32 6, label %b16.i.i.i348
    i32 12, label %b34.i.i.i347
    i32 8, label %b22.i.i.i346
    i32 9, label %b25.i.i.i345
    i32 10, label %b28.i.i.i344
    i32 11, label %b31.i.i.i339
  ]

b4.i.i.i352:                                      ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b7.i.i.i351:                                      ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b10.i.i.i350:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b13.i.i.i349:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b16.i.i.i348:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b22.i.i.i346:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b25.i.i.i345:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b28.i.i.i344:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b31.i.i.i339:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b34.i.i.i347:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

b36.i.i.i353:                                     ; preds = %v8_ok.i.i336
  br label %liza___liza_reactor_error.exit.i.i340

liza___liza_reactor_error.exit.i.i340:            ; preds = %b36.i.i.i353, %b34.i.i.i347, %b31.i.i.i339, %b28.i.i.i344, %b25.i.i.i345, %b22.i.i.i346, %b16.i.i.i348, %b13.i.i.i349, %b10.i.i.i350, %b7.i.i.i351, %b4.i.i.i352, %v8_ok.i.i336
  %common.ret.op.i.i.i341 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i352 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i351 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i350 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i349 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i348 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i346 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i345 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i344 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i339 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i347 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i353 ], [ zeroinitializer, %v8_ok.i.i336 ]
  %v10.i.i342 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i341, 2
  br label %liza_net.reactor_write.exit

liza_net.reactor_write.exit:                      ; preds = %b1.i.i354, %liza___liza_reactor_error.exit.i.i340
  %common.ret.op.i.i343 = phi %variant.9 [ %v5.i.i356, %b1.i.i354 ], [ %v10.i.i342, %liza___liza_reactor_error.exit.i.i340 ]
  %v260 = extractvalue %variant.9 %common.ret.op.i.i343, 0
  %switch21 = icmp eq i32 %v260, 1
  br i1 %switch21, label %b124, label %b4.i.i368

b124:                                             ; preds = %liza_net.reactor_write.exit
  %v261 = extractvalue %variant.9 %common.ret.op.i.i343, 2
  %v0.i357 = extractvalue %variant.5 %v261, 0
  switch i32 %v0.i357, label %b1.i360 [
    i32 2, label %b134
    i32 3, label %b134
    i32 0, label %b259
    i32 1, label %b259
    i32 4, label %b259
    i32 5, label %b259
    i32 6, label %b259
    i32 7, label %b259
    i32 8, label %b134
    i32 9, label %b259
    i32 10, label %b259
    i32 11, label %b259
  ]

b1.i360:                                          ; preds = %b124
  unreachable

b4.i.i368:                                        ; preds = %liza_net.reactor_write.exit
  %v268 = extractvalue %variant.9 %common.ret.op.i.i343, 1
  %v4.i370 = icmp eq i32 %v268, 0
  br i1 %v4.i370, label %liza_relay.direction.write.exit, label %b3.i.i

b3.i.i:                                           ; preds = %b4.i.i368
  %v12.i.i.i = extractvalue %struct.relay.direction.Direction %v246, 2
  %v8.i373 = icmp ugt i32 %v268, %v5.i327
  br i1 %v8.i373, label %liza_relay.direction.write.exit, label %b9.i

b9.i:                                             ; preds = %b3.i.i
  %v13_pair.i = call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v0.i.i298, i32 %v268)
  %v13.i = extractvalue { i32, i1 } %v13_pair.i, 0
  %v13_overflow.i = extractvalue { i32, i1 } %v13_pair.i, 1
  br i1 %v13_overflow.i, label %v13_trap.i, label %v13_ok.i

v13_trap.i:                                       ; preds = %b9.i
  call void @llvm.trap()
  unreachable

v13_ok.i:                                         ; preds = %b9.i
  %v15.i = icmp eq i32 %v13.i, %v1.i.i299
  br i1 %v15.i, label %b10.i, label %b12.i374

b10.i:                                            ; preds = %v13_ok.i
  %v20_field2.i = insertvalue %struct.relay.direction.Direction zeroinitializer, i1 %v12.i.i.i, 2
  %v20.i = insertvalue %struct.relay.direction.Direction %v20_field2.i, i1 false, 3
  %v21.i = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v20.i, 1
  br label %liza_relay.direction.write.exit

b12.i374:                                         ; preds = %v13_ok.i
  %v25_field0.i = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v13.i, 0
  %v25_field1.i = insertvalue %struct.relay.direction.Direction %v25_field0.i, i32 %v1.i.i299, 1
  %v25_field2.i = insertvalue %struct.relay.direction.Direction %v25_field1.i, i1 %v12.i.i.i, 2
  %v25.i = insertvalue %struct.relay.direction.Direction %v25_field2.i, i1 false, 3
  %v26.i = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v25.i, 1
  br label %liza_relay.direction.write.exit

liza_relay.direction.write.exit:                  ; preds = %b4.i.i368, %b3.i.i, %b10.i, %b12.i374
  %common.ret.op.i367 = phi %variant.6 [ %v21.i, %b10.i ], [ %v26.i, %b12.i374 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b4.i.i368 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b3.i.i ]
  %v271 = extractvalue %variant.6 %common.ret.op.i367, 0
  %switch22 = icmp eq i32 %v271, 1
  br i1 %switch22, label %b259, label %b131

b131:                                             ; preds = %liza_relay.direction.write.exit
  %v275 = extractvalue %variant.6 %common.ret.op.i367, 1
  %v277 = insertvalue %struct.liza_proxy.Pair %v239, %struct.relay.direction.Direction %v275, 3
  br label %b134

b134:                                             ; preds = %b124, %b124, %b124, %b118, %b131, %b114
  %v284 = phi %struct.liza_proxy.Pair [ %v239, %b114 ], [ %v277, %b131 ], [ %v239, %b118 ], [ %v239, %b124 ], [ %v239, %b124 ], [ %v239, %b124 ]
  %v288 = extractvalue %struct.liza_proxy.Pair %v284, 2
  br i1 %v288, label %b138, label %b154

b138:                                             ; preds = %b134
  %v291 = extractvalue %struct.liza_proxy.Pair %v284, 3
  %v0.i.i378 = extractvalue %struct.relay.direction.Direction %v291, 0
  %v1.i.i379 = extractvalue %struct.relay.direction.Direction %v291, 1
  %v2.i.i380 = icmp ule i32 %v0.i.i378, %v1.i.i379
  %v6.i.i381 = icmp ult i32 %v1.i.i379, 2049
  %v7.i.i382 = and i1 %v2.i.i380, %v6.i.i381
  br i1 %v7.i.i382, label %b4.i.i385, label %b154

b4.i.i385:                                        ; preds = %b138
  %v9.i.i386 = extractvalue %struct.relay.direction.Direction %v291, 3
  %v12.i.i387 = extractvalue %struct.relay.direction.Direction %v291, 2
  %v16.i.i388 = icmp eq i32 %v0.i.i378, %v1.i.i379
  %v9.i.i386.not = xor i1 %v9.i.i386, true
  %or.cond8.i = and i1 %v12.i.i387, %v16.i.i388
  %or.cond1036 = select i1 %v9.i.i386.not, i1 %or.cond8.i, i1 false
  br i1 %or.cond1036, label %b141, label %b154

b141:                                             ; preds = %b4.i.i385
  %raw.i.i394 = call i64 @liza_rt_reactor_shutdown_write(ptr %p0, i64 %v132.fca.1.1.0.load, i64 %v132.fca.1.1.1.load, i64 %v132.fca.1.1.2.load)
  %v3.i.i395 = icmp ult i64 %raw.i.i394, 4294967296
  br i1 %v3.i.i395, label %b1.i.i414, label %v8_ok.i.i396

b1.i.i414:                                        ; preds = %b141
  %v4.i.i415 = trunc nuw i64 %raw.i.i394 to i32
  %v5.i.i416 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i415, 1
  br label %liza_net.reactor_shutdown_write.exit

v8_ok.i.i396:                                     ; preds = %b141
  %v1.i.i397 = lshr i64 %raw.i.i394, 32
  %v8.i.i398 = trunc nuw i64 %v1.i.i397 to i32
  switch i32 %v8.i.i398, label %b36.i.i.i413 [
    i32 1, label %liza___liza_reactor_error.exit.i.i400
    i32 2, label %b4.i.i.i412
    i32 3, label %b7.i.i.i411
    i32 4, label %b10.i.i.i410
    i32 5, label %b13.i.i.i409
    i32 6, label %b16.i.i.i408
    i32 12, label %b34.i.i.i407
    i32 8, label %b22.i.i.i406
    i32 9, label %b25.i.i.i405
    i32 10, label %b28.i.i.i404
    i32 11, label %b31.i.i.i399
  ]

b4.i.i.i412:                                      ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b7.i.i.i411:                                      ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b10.i.i.i410:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b13.i.i.i409:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b16.i.i.i408:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b22.i.i.i406:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b25.i.i.i405:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b28.i.i.i404:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b31.i.i.i399:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b34.i.i.i407:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

b36.i.i.i413:                                     ; preds = %v8_ok.i.i396
  br label %liza___liza_reactor_error.exit.i.i400

liza___liza_reactor_error.exit.i.i400:            ; preds = %b36.i.i.i413, %b34.i.i.i407, %b31.i.i.i399, %b28.i.i.i404, %b25.i.i.i405, %b22.i.i.i406, %b16.i.i.i408, %b13.i.i.i409, %b10.i.i.i410, %b7.i.i.i411, %b4.i.i.i412, %v8_ok.i.i396
  %common.ret.op.i.i.i401 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i412 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i411 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i410 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i409 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i408 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i406 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i405 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i404 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i399 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i407 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i413 ], [ zeroinitializer, %v8_ok.i.i396 ]
  %v10.i.i402 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i401, 2
  br label %liza_net.reactor_shutdown_write.exit

liza_net.reactor_shutdown_write.exit:             ; preds = %b1.i.i414, %liza___liza_reactor_error.exit.i.i400
  %common.ret.op.i.i403 = phi %variant.9 [ %v5.i.i416, %b1.i.i414 ], [ %v10.i.i402, %liza___liza_reactor_error.exit.i.i400 ]
  %v295 = extractvalue %variant.9 %common.ret.op.i.i403, 0
  %switch23 = icmp eq i32 %v295, 1
  br i1 %switch23, label %b144, label %b151

b144:                                             ; preds = %liza_net.reactor_shutdown_write.exit
  %v296 = extractvalue %variant.9 %common.ret.op.i.i403, 2
  %v0.i417 = extractvalue %variant.5 %v296, 0
  switch i32 %v0.i417, label %b1.i420 [
    i32 2, label %b154
    i32 3, label %b154
    i32 0, label %b259
    i32 1, label %b259
    i32 4, label %b259
    i32 5, label %b259
    i32 6, label %b259
    i32 7, label %b259
    i32 8, label %b154
    i32 9, label %b259
    i32 10, label %b259
    i32 11, label %b259
  ]

b1.i420:                                          ; preds = %b144
  unreachable

b151:                                             ; preds = %liza_net.reactor_shutdown_write.exit
  %v8_field0.i = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i.i378, 0
  %v8_field1.i = insertvalue %struct.relay.direction.Direction %v8_field0.i, i32 %v0.i.i378, 1
  %v8_field2.i = insertvalue %struct.relay.direction.Direction %v8_field1.i, i1 true, 2
  %v8.i428 = insertvalue %struct.relay.direction.Direction %v8_field2.i, i1 true, 3
  %v312 = insertvalue %struct.liza_proxy.Pair %v284, %struct.relay.direction.Direction %v8.i428, 3
  br label %b154

b154:                                             ; preds = %b4.i.i385, %b144, %b144, %b144, %b138, %b151, %b134
  %v319 = phi %struct.liza_proxy.Pair [ %v284, %b134 ], [ %v312, %b151 ], [ %v284, %b138 ], [ %v284, %b144 ], [ %v284, %b144 ], [ %v284, %b144 ], [ %v284, %b4.i.i385 ]
  %v323 = extractvalue %struct.liza_proxy.Pair %v319, 2
  br i1 %v323, label %b158, label %b177

b158:                                             ; preds = %b154
  %v326 = extractvalue %struct.liza_proxy.Pair %v319, 4
  %v0.i.i429 = extractvalue %struct.relay.direction.Direction %v326, 0
  %v1.i.i430 = extractvalue %struct.relay.direction.Direction %v326, 1
  %v2.i.i431 = icmp ule i32 %v0.i.i429, %v1.i.i430
  %v6.i.i432 = icmp ult i32 %v1.i.i430, 2049
  %v7.i.i433 = and i1 %v2.i.i431, %v6.i.i432
  br i1 %v7.i.i433, label %b4.i.i435, label %b177

b4.i.i435:                                        ; preds = %b158
  %v9.i.i436 = extractvalue %struct.relay.direction.Direction %v326, 3
  %v9.i.not.i437 = xor i1 %v9.i.i436, true
  %v12.i.i438 = extractvalue %struct.relay.direction.Direction %v326, 2
  %v16.i.i439 = icmp eq i32 %v0.i.i429, %v1.i.i430
  %v17.i.i440 = and i1 %v12.i.i438, %v16.i.i439
  %or.cond.i441 = select i1 %v9.i.not.i437, i1 true, i1 %v17.i.i440
  br i1 %or.cond.i441, label %liza_relay.direction.readable.exit445, label %b177

liza_relay.direction.readable.exit445:            ; preds = %b4.i.i435
  %v3291041 = icmp ne i32 %v1.i.i430, 2048
  %not.v12.i.i438 = xor i1 %v12.i.i438, true
  %v329 = and i1 %v3291041, %not.v12.i.i438
  %or.cond5 = select i1 %v329, i1 %14, i1 false
  br i1 %or.cond5, label %b4.i.i452, label %b177

b4.i.i452:                                        ; preds = %liza_relay.direction.readable.exit445
  %indvars.iv.tr4052 = trunc nuw nsw i64 %indvars.iv to i32
  %19 = shl nuw nsw i32 %indvars.iv.tr4052, 12
  %20 = or disjoint i32 %19, 2048
  %v344_pair1035 = add nuw nsw i32 %20, %v1.i.i430
  %v8_pair4.i460 = sub nuw nsw i32 2048, %v1.i.i430
  %spec.select.i461 = select i1 %v12.i.i438, i32 0, i32 %v8_pair4.i460
  %raw.i465 = call i64 @liza_rt_reactor_read(ptr %p0, i64 %v132.fca.1.1.0.load, i64 %v132.fca.1.1.1.load, i64 %v132.fca.1.1.2.load, ptr %p.i, i32 %n.i, i32 %v344_pair1035, i32 %spec.select.i461)
  %count_read.i466 = trunc i64 %raw.i465 to i32
  %failed.i469 = icmp ugt i64 %raw.i465, 4294967295
  br i1 %failed.i469, label %b167, label %b1.i496

b167:                                             ; preds = %b4.i.i452
  %wide.i467 = lshr i64 %raw.i465, 32
  %code.i468 = trunc nuw i64 %wide.i467 to i32
  switch i32 %code.i468, label %b1.i481 [
    i32 3, label %b177
    i32 4, label %b177
    i32 1, label %b259
    i32 2, label %b259
    i32 5, label %b259
    i32 6, label %b259
    i32 7, label %b259
    i32 8, label %b259
    i32 9, label %b177
    i32 10, label %b259
    i32 11, label %b259
    i32 12, label %b259
  ]

b1.i481:                                          ; preds = %b167
  unreachable

b1.i496:                                          ; preds = %b4.i.i452
  %or.cond25.i498 = or i1 %v9.i.i436, %v12.i.i438
  %v12.i500 = icmp ult i32 %v8_pair4.i460, %count_read.i466
  %or.cond26.i501 = select i1 %or.cond25.i498, i1 true, i1 %v12.i500
  br i1 %or.cond26.i501, label %liza_relay.direction.read.exit517, label %b12.i502

b12.i502:                                         ; preds = %b1.i496
  %v17.i503 = icmp eq i32 %count_read.i466, 0
  br i1 %v17.i503, label %b13.i511, label %v26_ok.i504

b13.i511:                                         ; preds = %b12.i502
  %v22_field0.i512 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i.i429, 0
  %v22_field1.i513 = insertvalue %struct.relay.direction.Direction %v22_field0.i512, i32 %v1.i.i430, 1
  %v22_field2.i514 = insertvalue %struct.relay.direction.Direction %v22_field1.i513, i1 true, 2
  %v22.i515 = insertvalue %struct.relay.direction.Direction %v22_field2.i514, i1 false, 3
  %v23.i516 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v22.i515, 1
  br label %liza_relay.direction.read.exit517

v26_ok.i504:                                      ; preds = %b12.i502
  %v26_pair23.i505 = add nuw nsw i32 %v1.i.i430, %count_read.i466
  %v29_field0.i506 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i.i429, 0
  %v29_field1.i507 = insertvalue %struct.relay.direction.Direction %v29_field0.i506, i32 %v26_pair23.i505, 1
  %v29_field2.i508 = insertvalue %struct.relay.direction.Direction %v29_field1.i507, i1 false, 2
  %v29.i509 = insertvalue %struct.relay.direction.Direction %v29_field2.i508, i1 false, 3
  %v30.i510 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v29.i509, 1
  br label %liza_relay.direction.read.exit517

liza_relay.direction.read.exit517:                ; preds = %b1.i496, %b13.i511, %v26_ok.i504
  %common.ret.op.i488 = phi %variant.6 [ %v23.i516, %b13.i511 ], [ %v30.i510, %v26_ok.i504 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b1.i496 ]
  %v363 = extractvalue %variant.6 %common.ret.op.i488, 0
  %switch26 = icmp eq i32 %v363, 1
  br i1 %switch26, label %b259, label %b174

b174:                                             ; preds = %liza_relay.direction.read.exit517
  %v367 = extractvalue %variant.6 %common.ret.op.i488, 1
  %v369 = insertvalue %struct.liza_proxy.Pair %v319, %struct.relay.direction.Direction %v367, 4
  br label %b177

b177:                                             ; preds = %b167, %b167, %b167, %b4.i.i435, %b158, %b174, %liza_relay.direction.readable.exit445, %b154
  %v377 = phi %struct.liza_proxy.Pair [ %v319, %b154 ], [ %v319, %liza_relay.direction.readable.exit445 ], [ %v369, %b174 ], [ %v319, %b158 ], [ %v319, %b4.i.i435 ], [ %v319, %b167 ], [ %v319, %b167 ], [ %v319, %b167 ]
  %v381 = extractvalue %struct.liza_proxy.Pair %v377, 2
  br i1 %v381, label %b181, label %b197

b181:                                             ; preds = %b177
  %v384 = extractvalue %struct.liza_proxy.Pair %v377, 4
  %v0.i.i518 = extractvalue %struct.relay.direction.Direction %v384, 0
  %v1.i.i519 = extractvalue %struct.relay.direction.Direction %v384, 1
  %v2.i.i520 = icmp ugt i32 %v0.i.i518, %v1.i.i519
  %v6.i.i521 = icmp ugt i32 %v1.i.i519, 2048
  %v7.i.i522.not4119 = or i1 %v2.i.i520, %v6.i.i521
  %v9.i.i525 = extractvalue %struct.relay.direction.Direction %v384, 3
  %v387.not = icmp eq i32 %v1.i.i519, %v0.i.i518
  %or.cond1112 = or i1 %v9.i.i525, %v387.not
  %or.cond4066 = select i1 %v7.i.i522.not4119, i1 true, i1 %or.cond1112
  br i1 %or.cond4066, label %b197, label %v393_ok

v393_ok:                                          ; preds = %b181
  %indvars.iv.tr4053 = trunc nuw nsw i64 %indvars.iv to i32
  %21 = shl nuw nsw i32 %indvars.iv.tr4053, 12
  %22 = or disjoint i32 %21, 2048
  %v396_pair = call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %22, i32 %v0.i.i518)
  %v396_overflow = extractvalue { i32, i1 } %v396_pair, 1
  br i1 %v396_overflow, label %v396_trap, label %b3.i550

v396_trap:                                        ; preds = %v393_ok
  call void @llvm.trap()
  unreachable

b3.i550:                                          ; preds = %v393_ok
  %v5_pair.i551 = call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v1.i.i519, i32 %v0.i.i518)
  %v5_overflow.i553 = extractvalue { i32, i1 } %v5_pair.i551, 1
  br i1 %v5_overflow.i553, label %v5_trap.i554, label %liza_relay.direction.queued.exit555

v5_trap.i554:                                     ; preds = %b3.i550
  call void @llvm.trap()
  unreachable

liza_relay.direction.queued.exit555:              ; preds = %b3.i550
  %v396 = extractvalue { i32, i1 } %v396_pair, 0
  %v5.i552 = extractvalue { i32, i1 } %v5_pair.i551, 0
  %raw.i.i561 = call i64 @liza_rt_reactor_write(ptr %p0, i64 %v132.fca.0.1.0.load, i64 %v132.fca.0.1.1.load, i64 %v132.fca.0.1.2.load, ptr %p.i, i32 %n.i, i32 %v396, i32 %v5.i552)
  %v3.i.i562 = icmp ult i64 %raw.i.i561, 4294967296
  br i1 %v3.i.i562, label %b1.i.i581, label %v8_ok.i.i563

b1.i.i581:                                        ; preds = %liza_relay.direction.queued.exit555
  %v4.i.i582 = trunc nuw i64 %raw.i.i561 to i32
  %v5.i.i583 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i582, 1
  br label %liza_net.reactor_write.exit584

v8_ok.i.i563:                                     ; preds = %liza_relay.direction.queued.exit555
  %v1.i.i564 = lshr i64 %raw.i.i561, 32
  %v8.i.i565 = trunc nuw i64 %v1.i.i564 to i32
  switch i32 %v8.i.i565, label %b36.i.i.i580 [
    i32 1, label %liza___liza_reactor_error.exit.i.i567
    i32 2, label %b4.i.i.i579
    i32 3, label %b7.i.i.i578
    i32 4, label %b10.i.i.i577
    i32 5, label %b13.i.i.i576
    i32 6, label %b16.i.i.i575
    i32 12, label %b34.i.i.i574
    i32 8, label %b22.i.i.i573
    i32 9, label %b25.i.i.i572
    i32 10, label %b28.i.i.i571
    i32 11, label %b31.i.i.i566
  ]

b4.i.i.i579:                                      ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b7.i.i.i578:                                      ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b10.i.i.i577:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b13.i.i.i576:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b16.i.i.i575:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b22.i.i.i573:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b25.i.i.i572:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b28.i.i.i571:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b31.i.i.i566:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b34.i.i.i574:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

b36.i.i.i580:                                     ; preds = %v8_ok.i.i563
  br label %liza___liza_reactor_error.exit.i.i567

liza___liza_reactor_error.exit.i.i567:            ; preds = %b36.i.i.i580, %b34.i.i.i574, %b31.i.i.i566, %b28.i.i.i571, %b25.i.i.i572, %b22.i.i.i573, %b16.i.i.i575, %b13.i.i.i576, %b10.i.i.i577, %b7.i.i.i578, %b4.i.i.i579, %v8_ok.i.i563
  %common.ret.op.i.i.i568 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i579 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i578 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i577 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i576 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i575 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i573 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i572 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i571 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i566 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i574 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i580 ], [ zeroinitializer, %v8_ok.i.i563 ]
  %v10.i.i569 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i568, 2
  br label %liza_net.reactor_write.exit584

liza_net.reactor_write.exit584:                   ; preds = %b1.i.i581, %liza___liza_reactor_error.exit.i.i567
  %common.ret.op.i.i570 = phi %variant.9 [ %v5.i.i583, %b1.i.i581 ], [ %v10.i.i569, %liza___liza_reactor_error.exit.i.i567 ]
  %v400 = extractvalue %variant.9 %common.ret.op.i.i570, 0
  %switch27 = icmp eq i32 %v400, 1
  br i1 %switch27, label %b187, label %b4.i.i596

b187:                                             ; preds = %liza_net.reactor_write.exit584
  %v401 = extractvalue %variant.9 %common.ret.op.i.i570, 2
  %v0.i585 = extractvalue %variant.5 %v401, 0
  switch i32 %v0.i585, label %b1.i588 [
    i32 2, label %b197
    i32 3, label %b197
    i32 0, label %b259
    i32 1, label %b259
    i32 4, label %b259
    i32 5, label %b259
    i32 6, label %b259
    i32 7, label %b259
    i32 8, label %b197
    i32 9, label %b259
    i32 10, label %b259
    i32 11, label %b259
  ]

b1.i588:                                          ; preds = %b187
  unreachable

b4.i.i596:                                        ; preds = %liza_net.reactor_write.exit584
  %v408 = extractvalue %variant.9 %common.ret.op.i.i570, 1
  %v4.i600 = icmp eq i32 %v408, 0
  br i1 %v4.i600, label %liza_relay.direction.write.exit636, label %b3.i.i608

b3.i.i608:                                        ; preds = %b4.i.i596
  %v12.i.i.i604 = extractvalue %struct.relay.direction.Direction %v384, 2
  %v8.i613 = icmp ugt i32 %v408, %v5.i552
  br i1 %v8.i613, label %liza_relay.direction.write.exit636, label %b9.i614

b9.i614:                                          ; preds = %b3.i.i608
  %v13_pair.i615 = call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v0.i.i518, i32 %v408)
  %v13.i616 = extractvalue { i32, i1 } %v13_pair.i615, 0
  %v13_overflow.i617 = extractvalue { i32, i1 } %v13_pair.i615, 1
  br i1 %v13_overflow.i617, label %v13_trap.i630, label %v13_ok.i618

v13_trap.i630:                                    ; preds = %b9.i614
  call void @llvm.trap()
  unreachable

v13_ok.i618:                                      ; preds = %b9.i614
  %v15.i619 = icmp eq i32 %v13.i616, %v1.i.i519
  br i1 %v15.i619, label %b10.i626, label %b12.i620

b10.i626:                                         ; preds = %v13_ok.i618
  %v20_field2.i627 = insertvalue %struct.relay.direction.Direction zeroinitializer, i1 %v12.i.i.i604, 2
  %v20.i628 = insertvalue %struct.relay.direction.Direction %v20_field2.i627, i1 false, 3
  %v21.i629 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v20.i628, 1
  br label %liza_relay.direction.write.exit636

b12.i620:                                         ; preds = %v13_ok.i618
  %v25_field0.i621 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v13.i616, 0
  %v25_field1.i622 = insertvalue %struct.relay.direction.Direction %v25_field0.i621, i32 %v1.i.i519, 1
  %v25_field2.i623 = insertvalue %struct.relay.direction.Direction %v25_field1.i622, i1 %v12.i.i.i604, 2
  %v25.i624 = insertvalue %struct.relay.direction.Direction %v25_field2.i623, i1 false, 3
  %v26.i625 = insertvalue %variant.6 zeroinitializer, %struct.relay.direction.Direction %v25.i624, 1
  br label %liza_relay.direction.write.exit636

liza_relay.direction.write.exit636:               ; preds = %b4.i.i596, %b3.i.i608, %b10.i626, %b12.i620
  %common.ret.op.i595 = phi %variant.6 [ %v21.i629, %b10.i626 ], [ %v26.i625, %b12.i620 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b4.i.i596 ], [ { i32 1, %struct.relay.direction.Direction zeroinitializer, %variant.2 zeroinitializer }, %b3.i.i608 ]
  %v411 = extractvalue %variant.6 %common.ret.op.i595, 0
  %switch28 = icmp eq i32 %v411, 1
  br i1 %switch28, label %b259, label %b194

b194:                                             ; preds = %liza_relay.direction.write.exit636
  %v415 = extractvalue %variant.6 %common.ret.op.i595, 1
  %v417 = insertvalue %struct.liza_proxy.Pair %v377, %struct.relay.direction.Direction %v415, 4
  br label %b197

b197:                                             ; preds = %b187, %b187, %b187, %b181, %b194, %b177
  %v424 = phi %struct.liza_proxy.Pair [ %v377, %b177 ], [ %v417, %b194 ], [ %v377, %b181 ], [ %v377, %b187 ], [ %v377, %b187 ], [ %v377, %b187 ]
  %v428 = extractvalue %struct.liza_proxy.Pair %v424, 2
  br i1 %v428, label %b201, label %b217

b201:                                             ; preds = %b197
  %v431 = extractvalue %struct.liza_proxy.Pair %v424, 4
  %v0.i.i637 = extractvalue %struct.relay.direction.Direction %v431, 0
  %v1.i.i638 = extractvalue %struct.relay.direction.Direction %v431, 1
  %v2.i.i639 = icmp ule i32 %v0.i.i637, %v1.i.i638
  %v6.i.i640 = icmp ult i32 %v1.i.i638, 2049
  %v7.i.i641 = and i1 %v2.i.i639, %v6.i.i640
  br i1 %v7.i.i641, label %b4.i.i644, label %b217

b4.i.i644:                                        ; preds = %b201
  %v9.i.i645 = extractvalue %struct.relay.direction.Direction %v431, 3
  %v12.i.i646 = extractvalue %struct.relay.direction.Direction %v431, 2
  %v16.i.i647 = icmp eq i32 %v0.i.i637, %v1.i.i638
  %v9.i.i645.not = xor i1 %v9.i.i645, true
  %or.cond8.i649 = and i1 %v12.i.i646, %v16.i.i647
  %or.cond1037 = select i1 %v9.i.i645.not, i1 %or.cond8.i649, i1 false
  br i1 %or.cond1037, label %b204, label %b217

b204:                                             ; preds = %b4.i.i644
  %raw.i.i658 = call i64 @liza_rt_reactor_shutdown_write(ptr %p0, i64 %v132.fca.0.1.0.load, i64 %v132.fca.0.1.1.load, i64 %v132.fca.0.1.2.load)
  %v3.i.i659 = icmp ult i64 %raw.i.i658, 4294967296
  br i1 %v3.i.i659, label %b1.i.i678, label %v8_ok.i.i660

b1.i.i678:                                        ; preds = %b204
  %v4.i.i679 = trunc nuw i64 %raw.i.i658 to i32
  %v5.i.i680 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i679, 1
  br label %liza_net.reactor_shutdown_write.exit681

v8_ok.i.i660:                                     ; preds = %b204
  %v1.i.i661 = lshr i64 %raw.i.i658, 32
  %v8.i.i662 = trunc nuw i64 %v1.i.i661 to i32
  switch i32 %v8.i.i662, label %b36.i.i.i677 [
    i32 1, label %liza___liza_reactor_error.exit.i.i664
    i32 2, label %b4.i.i.i676
    i32 3, label %b7.i.i.i675
    i32 4, label %b10.i.i.i674
    i32 5, label %b13.i.i.i673
    i32 6, label %b16.i.i.i672
    i32 12, label %b34.i.i.i671
    i32 8, label %b22.i.i.i670
    i32 9, label %b25.i.i.i669
    i32 10, label %b28.i.i.i668
    i32 11, label %b31.i.i.i663
  ]

b4.i.i.i676:                                      ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b7.i.i.i675:                                      ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b10.i.i.i674:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b13.i.i.i673:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b16.i.i.i672:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b22.i.i.i670:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b25.i.i.i669:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b28.i.i.i668:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b31.i.i.i663:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b34.i.i.i671:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

b36.i.i.i677:                                     ; preds = %v8_ok.i.i660
  br label %liza___liza_reactor_error.exit.i.i664

liza___liza_reactor_error.exit.i.i664:            ; preds = %b36.i.i.i677, %b34.i.i.i671, %b31.i.i.i663, %b28.i.i.i668, %b25.i.i.i669, %b22.i.i.i670, %b16.i.i.i672, %b13.i.i.i673, %b10.i.i.i674, %b7.i.i.i675, %b4.i.i.i676, %v8_ok.i.i660
  %common.ret.op.i.i.i665 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i676 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i675 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i674 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i673 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i672 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i670 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i669 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i668 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i663 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i671 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i677 ], [ zeroinitializer, %v8_ok.i.i660 ]
  %v10.i.i666 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i665, 2
  br label %liza_net.reactor_shutdown_write.exit681

liza_net.reactor_shutdown_write.exit681:          ; preds = %b1.i.i678, %liza___liza_reactor_error.exit.i.i664
  %common.ret.op.i.i667 = phi %variant.9 [ %v5.i.i680, %b1.i.i678 ], [ %v10.i.i666, %liza___liza_reactor_error.exit.i.i664 ]
  %v435 = extractvalue %variant.9 %common.ret.op.i.i667, 0
  %switch29 = icmp eq i32 %v435, 1
  br i1 %switch29, label %b207, label %b214

b207:                                             ; preds = %liza_net.reactor_shutdown_write.exit681
  %v436 = extractvalue %variant.9 %common.ret.op.i.i667, 2
  %v0.i682 = extractvalue %variant.5 %v436, 0
  switch i32 %v0.i682, label %b1.i685 [
    i32 2, label %b217
    i32 3, label %b217
    i32 0, label %b259
    i32 1, label %b259
    i32 4, label %b259
    i32 5, label %b259
    i32 6, label %b259
    i32 7, label %b259
    i32 8, label %b217
    i32 9, label %b259
    i32 10, label %b259
    i32 11, label %b259
  ]

b1.i685:                                          ; preds = %b207
  unreachable

b214:                                             ; preds = %liza_net.reactor_shutdown_write.exit681
  %v8_field0.i701 = insertvalue %struct.relay.direction.Direction zeroinitializer, i32 %v0.i.i637, 0
  %v8_field1.i702 = insertvalue %struct.relay.direction.Direction %v8_field0.i701, i32 %v0.i.i637, 1
  %v8_field2.i703 = insertvalue %struct.relay.direction.Direction %v8_field1.i702, i1 true, 2
  %v8.i704 = insertvalue %struct.relay.direction.Direction %v8_field2.i703, i1 true, 3
  %v452 = insertvalue %struct.liza_proxy.Pair %v424, %struct.relay.direction.Direction %v8.i704, 4
  br label %b217

b217:                                             ; preds = %b207, %b207, %b207, %b4.i.i644, %b201, %b214, %b197
  %v459 = phi %struct.liza_proxy.Pair [ %v424, %b197 ], [ %v452, %b214 ], [ %v424, %b201 ], [ %v424, %b4.i.i644 ], [ %v424, %b207 ], [ %v424, %b207 ], [ %v424, %b207 ]
  %v463 = extractvalue %struct.liza_proxy.Pair %v459, 3
  %v464 = extractvalue %struct.relay.direction.Direction %v463, 3
  %v467 = extractvalue %struct.liza_proxy.Pair %v459, 4
  %v468 = extractvalue %struct.relay.direction.Direction %v467, 3
  %23 = xor i1 %v468, true
  %24 = select i1 %v464, i1 %v468, i1 false
  br i1 %24, label %b259, label %b227

b227:                                             ; preds = %b217
  %v0.i.i707 = extractvalue %struct.relay.direction.Direction %v463, 0
  %v1.i.i708 = extractvalue %struct.relay.direction.Direction %v463, 1
  %v2.i.i709 = icmp ule i32 %v0.i.i707, %v1.i.i708
  %v6.i.i710 = icmp ult i32 %v1.i.i708, 2049
  %v7.i.i711 = and i1 %v2.i.i709, %v6.i.i710
  br i1 %v7.i.i711, label %b4.i.i713, label %liza_relay.direction.readable.exit723

b4.i.i713:                                        ; preds = %b227
  %v9.i.not.i715 = xor i1 %v464, true
  %v12.i.i716 = extractvalue %struct.relay.direction.Direction %v463, 2
  %v16.i.i717 = icmp eq i32 %v0.i.i707, %v1.i.i708
  %v17.i.i718 = and i1 %v12.i.i716, %v16.i.i717
  %or.cond.i719 = select i1 %v9.i.not.i715, i1 true, i1 %v17.i.i718
  br i1 %or.cond.i719, label %b1.i720, label %liza_relay.direction.readable.exit723

b1.i720:                                          ; preds = %b4.i.i713
  %25 = icmp ne i32 %v1.i.i708, 2048
  %not.v12.i.i716 = xor i1 %v12.i.i716, true
  %26 = and i1 %25, %not.v12.i.i716
  %27 = zext i1 %26 to i32
  br label %liza_relay.direction.readable.exit723

liza_relay.direction.readable.exit723:            ; preds = %b227, %b4.i.i713, %b1.i720
  %common.ret.op.i712 = phi i32 [ 0, %b227 ], [ 0, %b4.i.i713 ], [ %27, %b1.i720 ]
  %v0.i.i724 = extractvalue %struct.relay.direction.Direction %v467, 0
  %v1.i.i725 = extractvalue %struct.relay.direction.Direction %v467, 1
  %v2.i.i726 = icmp ule i32 %v0.i.i724, %v1.i.i725
  %v6.i.i727 = icmp ult i32 %v1.i.i725, 2049
  %v7.i.i728 = and i1 %v2.i.i726, %v6.i.i727
  br i1 %v7.i.i728, label %b4.i.i730, label %b237.thread

b4.i.i730:                                        ; preds = %liza_relay.direction.readable.exit723
  %v482.not = icmp eq i32 %v1.i.i725, %v0.i.i724
  %v12.i.i752 = extractvalue %struct.relay.direction.Direction %v467, 2
  %not.v482.not = xor i1 %v482.not, true
  %or.cond1038 = select i1 %not.v482.not, i1 true, i1 %v12.i.i752
  %or.cond4067 = select i1 %23, i1 %or.cond1038, i1 false
  %v488 = or disjoint i32 %common.ret.op.i712, 2
  %v489 = select i1 %or.cond4067, i32 %v488, i32 %common.ret.op.i712
  %v491 = extractvalue %struct.liza_proxy.Pair %v459, 2
  br i1 %v491, label %b4.i.i767, label %b249

b237.thread:                                      ; preds = %liza_relay.direction.readable.exit723
  %v4911029 = extractvalue %struct.liza_proxy.Pair %v459, 2
  br i1 %v4911029, label %liza_relay.direction.readable.exit777, label %b249

b4.i.i767:                                        ; preds = %b4.i.i730
  %v17.i.i772 = and i1 %v12.i.i752, %v482.not
  %or.cond.i773 = select i1 %23, i1 true, i1 %v17.i.i772
  br i1 %or.cond.i773, label %b1.i774, label %liza_relay.direction.readable.exit777

b1.i774:                                          ; preds = %b4.i.i767
  %28 = icmp ne i32 %v1.i.i725, 2048
  %not.v12.i.i770 = xor i1 %v12.i.i752, true
  %29 = and i1 %28, %not.v12.i.i770
  %30 = zext i1 %29 to i32
  br label %liza_relay.direction.readable.exit777

liza_relay.direction.readable.exit777:            ; preds = %b237.thread, %b4.i.i767, %b1.i774
  %v48910311033 = phi i32 [ %v489, %b4.i.i767 ], [ %v489, %b1.i774 ], [ %common.ret.op.i712, %b237.thread ]
  %common.ret.op.i766 = phi i32 [ 0, %b4.i.i767 ], [ %30, %b1.i774 ], [ 0, %b237.thread ]
  br i1 %v7.i.i711, label %b4.i.i784, label %b249

b4.i.i784:                                        ; preds = %liza_relay.direction.readable.exit777
  %v502.not = icmp eq i32 %v1.i.i708, %v0.i.i707
  %or.cond1114 = or i1 %v464, %v502.not
  br i1 %or.cond1114, label %b4.i.i804, label %b246

b4.i.i804:                                        ; preds = %b4.i.i784
  %v12.i.i806 = extractvalue %struct.relay.direction.Direction %v463, 2
  %v464.not = xor i1 %v464, true
  %or.cond8.i809 = and i1 %v12.i.i806, %v502.not
  %or.cond1039 = select i1 %v464.not, i1 %or.cond8.i809, i1 false
  br i1 %or.cond1039, label %b246, label %b249

b246:                                             ; preds = %b4.i.i784, %b4.i.i804
  %v508 = or disjoint i32 %common.ret.op.i766, 2
  br label %b249

b249:                                             ; preds = %b4.i.i804, %liza_relay.direction.readable.exit777, %b237.thread, %b246, %b4.i.i730
  %v4891030 = phi i32 [ %v489, %b4.i.i730 ], [ %v48910311033, %b246 ], [ %common.ret.op.i712, %b237.thread ], [ %v48910311033, %liza_relay.direction.readable.exit777 ], [ %v48910311033, %b4.i.i804 ]
  %v510 = phi i32 [ 2, %b4.i.i730 ], [ %v508, %b246 ], [ 2, %b237.thread ], [ %common.ret.op.i766, %liza_relay.direction.readable.exit777 ], [ %common.ret.op.i766, %b4.i.i804 ]
  %raw.i.i818 = call i64 @liza_rt_reactor_interest(ptr %p0, i64 %v132.fca.0.1.0.load, i64 %v132.fca.0.1.1.load, i64 %v132.fca.0.1.2.load, i32 %v4891030)
  %v3.i.i819 = icmp ult i64 %raw.i.i818, 4294967296
  br i1 %v3.i.i819, label %b1.i.i838, label %v8_ok.i.i820

b1.i.i838:                                        ; preds = %b249
  %v4.i.i839 = trunc nuw i64 %raw.i.i818 to i32
  %v5.i.i840 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i839, 1
  br label %liza_net.reactor_interest.exit

v8_ok.i.i820:                                     ; preds = %b249
  %v1.i.i821 = lshr i64 %raw.i.i818, 32
  %v8.i.i822 = trunc nuw i64 %v1.i.i821 to i32
  switch i32 %v8.i.i822, label %b36.i.i.i837 [
    i32 1, label %liza___liza_reactor_error.exit.i.i824
    i32 2, label %b4.i.i.i836
    i32 3, label %b7.i.i.i835
    i32 4, label %b10.i.i.i834
    i32 5, label %b13.i.i.i833
    i32 6, label %b16.i.i.i832
    i32 12, label %b34.i.i.i831
    i32 8, label %b22.i.i.i830
    i32 9, label %b25.i.i.i829
    i32 10, label %b28.i.i.i828
    i32 11, label %b31.i.i.i823
  ]

b4.i.i.i836:                                      ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b7.i.i.i835:                                      ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b10.i.i.i834:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b13.i.i.i833:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b16.i.i.i832:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b22.i.i.i830:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b25.i.i.i829:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b28.i.i.i828:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b31.i.i.i823:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b34.i.i.i831:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

b36.i.i.i837:                                     ; preds = %v8_ok.i.i820
  br label %liza___liza_reactor_error.exit.i.i824

liza___liza_reactor_error.exit.i.i824:            ; preds = %b36.i.i.i837, %b34.i.i.i831, %b31.i.i.i823, %b28.i.i.i828, %b25.i.i.i829, %b22.i.i.i830, %b16.i.i.i832, %b13.i.i.i833, %b10.i.i.i834, %b7.i.i.i835, %b4.i.i.i836, %v8_ok.i.i820
  %common.ret.op.i.i.i825 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i836 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i835 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i834 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i833 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i832 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i830 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i829 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i828 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i823 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i831 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i837 ], [ zeroinitializer, %v8_ok.i.i820 ]
  %v10.i.i826 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i825, 2
  br label %liza_net.reactor_interest.exit

liza_net.reactor_interest.exit:                   ; preds = %b1.i.i838, %liza___liza_reactor_error.exit.i.i824
  %common.ret.op.i.i827 = phi %variant.9 [ %v5.i.i840, %b1.i.i838 ], [ %v10.i.i826, %liza___liza_reactor_error.exit.i.i824 ]
  %v512 = extractvalue %variant.9 %common.ret.op.i.i827, 0
  %switch31 = icmp ne i32 %v512, 0
  %raw.i.i844 = call i64 @liza_rt_reactor_interest(ptr %p0, i64 %v132.fca.1.1.0.load, i64 %v132.fca.1.1.1.load, i64 %v132.fca.1.1.2.load, i32 %v510)
  %v3.i.i845 = icmp ult i64 %raw.i.i844, 4294967296
  br i1 %v3.i.i845, label %b1.i.i864, label %v8_ok.i.i846

b1.i.i864:                                        ; preds = %liza_net.reactor_interest.exit
  %v4.i.i865 = trunc nuw i64 %raw.i.i844 to i32
  %v5.i.i866 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i865, 1
  br label %b258

v8_ok.i.i846:                                     ; preds = %liza_net.reactor_interest.exit
  %v1.i.i847 = lshr i64 %raw.i.i844, 32
  %v8.i.i848 = trunc nuw i64 %v1.i.i847 to i32
  switch i32 %v8.i.i848, label %b36.i.i.i863 [
    i32 1, label %liza___liza_reactor_error.exit.i.i850
    i32 2, label %b4.i.i.i862
    i32 3, label %b7.i.i.i861
    i32 4, label %b10.i.i.i860
    i32 5, label %b13.i.i.i859
    i32 6, label %b16.i.i.i858
    i32 12, label %b34.i.i.i857
    i32 8, label %b22.i.i.i856
    i32 9, label %b25.i.i.i855
    i32 10, label %b28.i.i.i854
    i32 11, label %b31.i.i.i849
  ]

b4.i.i.i862:                                      ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b7.i.i.i861:                                      ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b10.i.i.i860:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b13.i.i.i859:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b16.i.i.i858:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b22.i.i.i856:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b25.i.i.i855:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b28.i.i.i854:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b31.i.i.i849:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b34.i.i.i857:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

b36.i.i.i863:                                     ; preds = %v8_ok.i.i846
  br label %liza___liza_reactor_error.exit.i.i850

liza___liza_reactor_error.exit.i.i850:            ; preds = %b36.i.i.i863, %b34.i.i.i857, %b31.i.i.i849, %b28.i.i.i854, %b25.i.i.i855, %b22.i.i.i856, %b16.i.i.i858, %b13.i.i.i859, %b10.i.i.i860, %b7.i.i.i861, %b4.i.i.i862, %v8_ok.i.i846
  %common.ret.op.i.i.i851 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i862 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i861 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i860 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i859 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i858 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i856 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i855 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i854 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i849 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i857 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i863 ], [ zeroinitializer, %v8_ok.i.i846 ]
  %v10.i.i852 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i851, 2
  br label %b258

b258:                                             ; preds = %liza___liza_reactor_error.exit.i.i850, %b1.i.i864
  %common.ret.op.i.i853 = phi %variant.9 [ %v5.i.i866, %b1.i.i864 ], [ %v10.i.i852, %liza___liza_reactor_error.exit.i.i850 ]
  %v520 = extractvalue %variant.9 %common.ret.op.i.i853, 0
  %switch37 = icmp ne i32 %v520, 0
  %spec.select39 = select i1 %switch37, i1 true, i1 %switch31
  br i1 %spec.select39, label %b259, label %v554_ok

b259:                                             ; preds = %liza_net.reactor_ready.exit228, %b85, %b85, %b85, %b85, %b85, %b85, %b85, %b85, %b85, %b91, %liza_relay.direction.read.exit, %b104, %b104, %b104, %b104, %b104, %b104, %b104, %b104, %b104, %liza_relay.direction.write.exit, %b124, %b124, %b124, %b124, %b124, %b124, %b124, %b124, %b124, %b144, %b144, %b144, %b144, %b144, %b144, %b144, %b144, %b144, %liza_relay.direction.read.exit517, %b167, %b167, %b167, %b167, %b167, %b167, %b167, %b167, %b167, %liza_relay.direction.write.exit636, %b187, %b187, %b187, %b187, %b187, %b187, %b187, %b187, %b187, %b207, %b207, %b207, %b207, %b207, %b207, %b207, %b207, %b207, %b217, %b258
  %v5281027 = phi i32 [ 3, %b258 ], [ %v153, %b217 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b207 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %b187 ], [ 3, %liza_relay.direction.write.exit636 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %b167 ], [ 3, %liza_relay.direction.read.exit517 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b144 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %b124 ], [ 3, %liza_relay.direction.write.exit ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %b104 ], [ 3, %liza_relay.direction.read.exit ], [ 3, %b91 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %b85 ], [ 3, %liza_net.reactor_ready.exit228 ]
  %raw.i.i871 = call i64 @liza_rt_reactor_disconnect(ptr %p0, i64 %v132.fca.0.1.0.load, i64 %v132.fca.0.1.1.load, i64 %v132.fca.0.1.2.load)
  %v3.i.i872 = icmp ult i64 %raw.i.i871, 4294967296
  br i1 %v3.i.i872, label %b1.i.i891, label %v8_ok.i.i873

b1.i.i891:                                        ; preds = %b259
  %v4.i.i892 = trunc nuw i64 %raw.i.i871 to i32
  %v5.i.i893 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i892, 1
  br label %liza_net.reactor_disconnect.exit894

v8_ok.i.i873:                                     ; preds = %b259
  %v1.i.i874 = lshr i64 %raw.i.i871, 32
  %v8.i.i875 = trunc nuw i64 %v1.i.i874 to i32
  switch i32 %v8.i.i875, label %b36.i.i.i890 [
    i32 1, label %liza___liza_reactor_error.exit.i.i877
    i32 2, label %b4.i.i.i889
    i32 3, label %b7.i.i.i888
    i32 4, label %b10.i.i.i887
    i32 5, label %b13.i.i.i886
    i32 6, label %b16.i.i.i885
    i32 12, label %b34.i.i.i884
    i32 8, label %b22.i.i.i883
    i32 9, label %b25.i.i.i882
    i32 10, label %b28.i.i.i881
    i32 11, label %b31.i.i.i876
  ]

b4.i.i.i889:                                      ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b7.i.i.i888:                                      ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b10.i.i.i887:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b13.i.i.i886:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b16.i.i.i885:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b22.i.i.i883:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b25.i.i.i882:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b28.i.i.i881:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b31.i.i.i876:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b34.i.i.i884:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

b36.i.i.i890:                                     ; preds = %v8_ok.i.i873
  br label %liza___liza_reactor_error.exit.i.i877

liza___liza_reactor_error.exit.i.i877:            ; preds = %b36.i.i.i890, %b34.i.i.i884, %b31.i.i.i876, %b28.i.i.i881, %b25.i.i.i882, %b22.i.i.i883, %b16.i.i.i885, %b13.i.i.i886, %b10.i.i.i887, %b7.i.i.i888, %b4.i.i.i889, %v8_ok.i.i873
  %common.ret.op.i.i.i878 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i889 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i888 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i887 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i886 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i885 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i883 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i882 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i881 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i876 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i884 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i890 ], [ zeroinitializer, %v8_ok.i.i873 ]
  %v10.i.i879 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i878, 2
  br label %liza_net.reactor_disconnect.exit894

liza_net.reactor_disconnect.exit894:              ; preds = %b1.i.i891, %liza___liza_reactor_error.exit.i.i877
  %common.ret.op.i.i880 = phi %variant.9 [ %v5.i.i893, %b1.i.i891 ], [ %v10.i.i879, %liza___liza_reactor_error.exit.i.i877 ]
  %v531 = extractvalue %variant.9 %common.ret.op.i.i880, 0
  %switch33 = icmp eq i32 %v531, 0
  %raw.i.i898 = call i64 @liza_rt_reactor_disconnect(ptr %p0, i64 %v132.fca.1.1.0.load, i64 %v132.fca.1.1.1.load, i64 %v132.fca.1.1.2.load)
  %v3.i.i899 = icmp ult i64 %raw.i.i898, 4294967296
  br i1 %v3.i.i899, label %b1.i.i918, label %v8_ok.i.i900

b1.i.i918:                                        ; preds = %liza_net.reactor_disconnect.exit894
  %v4.i.i919 = trunc nuw i64 %raw.i.i898 to i32
  %v5.i.i920 = insertvalue %variant.9 zeroinitializer, i32 %v4.i.i919, 1
  br label %liza_net.reactor_disconnect.exit921

v8_ok.i.i900:                                     ; preds = %liza_net.reactor_disconnect.exit894
  %v1.i.i901 = lshr i64 %raw.i.i898, 32
  %v8.i.i902 = trunc nuw i64 %v1.i.i901 to i32
  switch i32 %v8.i.i902, label %b36.i.i.i917 [
    i32 1, label %liza___liza_reactor_error.exit.i.i904
    i32 2, label %b4.i.i.i916
    i32 3, label %b7.i.i.i915
    i32 4, label %b10.i.i.i914
    i32 5, label %b13.i.i.i913
    i32 6, label %b16.i.i.i912
    i32 12, label %b34.i.i.i911
    i32 8, label %b22.i.i.i910
    i32 9, label %b25.i.i.i909
    i32 10, label %b28.i.i.i908
    i32 11, label %b31.i.i.i903
  ]

b4.i.i.i916:                                      ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b7.i.i.i915:                                      ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b10.i.i.i914:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b13.i.i.i913:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b16.i.i.i912:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b22.i.i.i910:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b25.i.i.i909:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b28.i.i.i908:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b31.i.i.i903:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b34.i.i.i911:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

b36.i.i.i917:                                     ; preds = %v8_ok.i.i900
  br label %liza___liza_reactor_error.exit.i.i904

liza___liza_reactor_error.exit.i.i904:            ; preds = %b36.i.i.i917, %b34.i.i.i911, %b31.i.i.i903, %b28.i.i.i908, %b25.i.i.i909, %b22.i.i.i910, %b16.i.i.i912, %b13.i.i.i913, %b10.i.i.i914, %b7.i.i.i915, %b4.i.i.i916, %v8_ok.i.i900
  %common.ret.op.i.i.i905 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i.i916 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i.i915 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i.i914 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i.i913 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i.i912 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i.i910 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i.i909 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i.i908 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i.i903 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i.i911 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i.i917 ], [ zeroinitializer, %v8_ok.i.i900 ]
  %v10.i.i906 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i.i905, 2
  br label %liza_net.reactor_disconnect.exit921

liza_net.reactor_disconnect.exit921:              ; preds = %b1.i.i918, %liza___liza_reactor_error.exit.i.i904
  %common.ret.op.i.i907 = phi %variant.9 [ %v5.i.i920, %b1.i.i918 ], [ %v10.i.i906, %liza___liza_reactor_error.exit.i.i904 ]
  %v537 = extractvalue %variant.9 %common.ret.op.i.i907, 0
  %switch41 = icmp eq i32 %v537, 0
  %31 = select i1 %switch41, i1 %switch33, i1 false
  %spec.select43 = select i1 %31, i32 %v5281027, i32 3
  %v541.v125 = select i1 %p3, i32 %spec.select43, i32 %v1251105
  br label %v554_ok

v554_ok:                                          ; preds = %b258, %liza_net.reactor_disconnect.exit921, %b67
  %v551 = phi i1 [ false, %b67 ], [ true, %b258 ], [ %not.p3, %liza_net.reactor_disconnect.exit921 ]
  %v552 = phi i32 [ 3, %b67 ], [ %v1251105, %b258 ], [ %v541.v125, %liza_net.reactor_disconnect.exit921 ]
  %v553 = phi %struct.liza_proxy.Pair [ %v132.fca.4.3.insert, %b67 ], [ %v459, %b258 ], [ { %variant.0 { i32 1, [3 x i64] zeroinitializer, [0 x i8] zeroinitializer }, %variant.0 { i32 1, [3 x i64] zeroinitializer, [0 x i8] zeroinitializer }, i1 false, %struct.relay.direction.Direction zeroinitializer, %struct.relay.direction.Direction zeroinitializer }, %liza_net.reactor_disconnect.exit921 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(768) %v556_mem, ptr noundef nonnull align 8 dereferenceable(768) %v122_mem, i64 768, i1 false)
  %v556_part = getelementptr [8 x %struct.liza_proxy.Pair], ptr %v556_mem, i64 0, i64 %indvars.iv
  %v553.fca.0.0.extract = extractvalue %struct.liza_proxy.Pair %v553, 0, 0
  store i32 %v553.fca.0.0.extract, ptr %v556_part, align 8
  %v553.fca.0.1.0.extract = extractvalue %struct.liza_proxy.Pair %v553, 0, 1, 0
  %v553.fca.0.1.0.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 8
  store i64 %v553.fca.0.1.0.extract, ptr %v553.fca.0.1.0.gep, align 8
  %v553.fca.0.1.1.extract = extractvalue %struct.liza_proxy.Pair %v553, 0, 1, 1
  %v553.fca.0.1.1.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 16
  store i64 %v553.fca.0.1.1.extract, ptr %v553.fca.0.1.1.gep, align 8
  %v553.fca.0.1.2.extract = extractvalue %struct.liza_proxy.Pair %v553, 0, 1, 2
  %v553.fca.0.1.2.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 24
  store i64 %v553.fca.0.1.2.extract, ptr %v553.fca.0.1.2.gep, align 8
  %v553.fca.1.0.extract = extractvalue %struct.liza_proxy.Pair %v553, 1, 0
  %v553.fca.1.0.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 32
  store i32 %v553.fca.1.0.extract, ptr %v553.fca.1.0.gep, align 8
  %v553.fca.1.1.0.extract = extractvalue %struct.liza_proxy.Pair %v553, 1, 1, 0
  %v553.fca.1.1.0.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 40
  store i64 %v553.fca.1.1.0.extract, ptr %v553.fca.1.1.0.gep, align 8
  %v553.fca.1.1.1.extract = extractvalue %struct.liza_proxy.Pair %v553, 1, 1, 1
  %v553.fca.1.1.1.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 48
  store i64 %v553.fca.1.1.1.extract, ptr %v553.fca.1.1.1.gep, align 8
  %v553.fca.1.1.2.extract = extractvalue %struct.liza_proxy.Pair %v553, 1, 1, 2
  %v553.fca.1.1.2.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 56
  store i64 %v553.fca.1.1.2.extract, ptr %v553.fca.1.1.2.gep, align 8
  %v553.fca.2.extract = extractvalue %struct.liza_proxy.Pair %v553, 2
  %v553.fca.2.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 64
  store i1 %v553.fca.2.extract, ptr %v553.fca.2.gep, align 8
  %v553.fca.3.0.extract = extractvalue %struct.liza_proxy.Pair %v553, 3, 0
  %v553.fca.3.0.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 68
  store i32 %v553.fca.3.0.extract, ptr %v553.fca.3.0.gep, align 4
  %v553.fca.3.1.extract = extractvalue %struct.liza_proxy.Pair %v553, 3, 1
  %v553.fca.3.1.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 72
  store i32 %v553.fca.3.1.extract, ptr %v553.fca.3.1.gep, align 8
  %v553.fca.3.2.extract = extractvalue %struct.liza_proxy.Pair %v553, 3, 2
  %v553.fca.3.2.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 76
  store i1 %v553.fca.3.2.extract, ptr %v553.fca.3.2.gep, align 4
  %v553.fca.3.3.extract = extractvalue %struct.liza_proxy.Pair %v553, 3, 3
  %v553.fca.3.3.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 77
  store i1 %v553.fca.3.3.extract, ptr %v553.fca.3.3.gep, align 1
  %v553.fca.4.0.extract = extractvalue %struct.liza_proxy.Pair %v553, 4, 0
  %v553.fca.4.0.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 80
  store i32 %v553.fca.4.0.extract, ptr %v553.fca.4.0.gep, align 8
  %v553.fca.4.1.extract = extractvalue %struct.liza_proxy.Pair %v553, 4, 1
  %v553.fca.4.1.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 84
  store i32 %v553.fca.4.1.extract, ptr %v553.fca.4.1.gep, align 4
  %v553.fca.4.2.extract = extractvalue %struct.liza_proxy.Pair %v553, 4, 2
  %v553.fca.4.2.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 88
  store i1 %v553.fca.4.2.extract, ptr %v553.fca.4.2.gep, align 8
  %v553.fca.4.3.extract = extractvalue %struct.liza_proxy.Pair %v553, 4, 3
  %v553.fca.4.3.gep = getelementptr inbounds nuw i8, ptr %v556_part, i64 89
  store i1 %v553.fca.4.3.extract, ptr %v553.fca.4.3.gep, align 1
  %32 = load <2 x i64>, ptr %v558_next.sroa.4.sroa.4.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.8.0.copyload4020 = load i64, ptr %v558_next.sroa.4.sroa.8.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %33 = load <2 x i32>, ptr %v558_next.sroa.4.sroa.10.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %34 = load <2 x i64>, ptr %v558_next.sroa.4.sroa.14.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.18.0.copyload4025 = load i64, ptr %v558_next.sroa.4.sroa.18.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.20.0.copyload4026 = load i8, ptr %v558_next.sroa.4.sroa.20.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %35 = load <2 x i32>, ptr %v558_next.sroa.4.sroa.24.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.4.sroa.28.0.copyload4029 = load i8, ptr %v558_next.sroa.4.sroa.28.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.4.sroa.30.0.copyload4030 = load i8, ptr %v558_next.sroa.4.sroa.30.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 1
  %36 = load i16, ptr %v558_next.sroa.4.sroa.32.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 2
  %37 = load <2 x i32>, ptr %v558_next.sroa.4.sroa.34.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.38.0.copyload4033 = load i8, ptr %v558_next.sroa.4.sroa.38.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.40.0.copyload4034 = load i8, ptr %v558_next.sroa.4.sroa.40.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, align 1
  %38 = load <2 x i32>, ptr %v558_next.sroa.6.0.v556_mem.sroa_idx, align 8
  %39 = load <2 x i64>, ptr %v558_next.sroa.8.sroa.4.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.8.0.copyload3686 = load i64, ptr %v558_next.sroa.8.sroa.8.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %40 = load <2 x i32>, ptr %v558_next.sroa.8.sroa.10.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %41 = load <2 x i64>, ptr %v558_next.sroa.8.sroa.14.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.18.0.copyload3691 = load i64, ptr %v558_next.sroa.8.sroa.18.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.20.0.copyload3692 = load i8, ptr %v558_next.sroa.8.sroa.20.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %42 = load <2 x i32>, ptr %v558_next.sroa.8.sroa.24.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.8.sroa.28.0.copyload3695 = load i8, ptr %v558_next.sroa.8.sroa.28.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.8.sroa.30.0.copyload3696 = load i8, ptr %v558_next.sroa.8.sroa.30.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 1
  %43 = load i16, ptr %v558_next.sroa.8.sroa.32.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 2
  %44 = load <2 x i32>, ptr %v558_next.sroa.8.sroa.34.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.38.0.copyload3699 = load i8, ptr %v558_next.sroa.8.sroa.38.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.40.0.copyload3700 = load i8, ptr %v558_next.sroa.8.sroa.40.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, align 1
  %45 = load <2 x i32>, ptr %v558_next.sroa.10.0.v556_mem.sroa_idx, align 8
  %46 = load <2 x i64>, ptr %v558_next.sroa.12.sroa.4.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.8.0.copyload3352 = load i64, ptr %v558_next.sroa.12.sroa.8.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %47 = load <2 x i32>, ptr %v558_next.sroa.12.sroa.10.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %48 = load <2 x i64>, ptr %v558_next.sroa.12.sroa.14.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.18.0.copyload3357 = load i64, ptr %v558_next.sroa.12.sroa.18.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.20.0.copyload3358 = load i8, ptr %v558_next.sroa.12.sroa.20.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %49 = load <2 x i32>, ptr %v558_next.sroa.12.sroa.24.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.12.sroa.28.0.copyload3361 = load i8, ptr %v558_next.sroa.12.sroa.28.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.12.sroa.30.0.copyload3362 = load i8, ptr %v558_next.sroa.12.sroa.30.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 1
  %50 = load i16, ptr %v558_next.sroa.12.sroa.32.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 2
  %51 = load <2 x i32>, ptr %v558_next.sroa.12.sroa.34.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.38.0.copyload3365 = load i8, ptr %v558_next.sroa.12.sroa.38.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.40.0.copyload3366 = load i8, ptr %v558_next.sroa.12.sroa.40.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, align 1
  %52 = load <2 x i32>, ptr %v558_next.sroa.14.0.v556_mem.sroa_idx, align 8
  %53 = load <2 x i64>, ptr %v558_next.sroa.16.sroa.4.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.8.0.copyload3018 = load i64, ptr %v558_next.sroa.16.sroa.8.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %54 = load <2 x i32>, ptr %v558_next.sroa.16.sroa.10.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %55 = load <2 x i64>, ptr %v558_next.sroa.16.sroa.14.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.18.0.copyload3023 = load i64, ptr %v558_next.sroa.16.sroa.18.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.20.0.copyload3024 = load i8, ptr %v558_next.sroa.16.sroa.20.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %56 = load <2 x i32>, ptr %v558_next.sroa.16.sroa.24.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.16.sroa.28.0.copyload3027 = load i8, ptr %v558_next.sroa.16.sroa.28.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.16.sroa.30.0.copyload3028 = load i8, ptr %v558_next.sroa.16.sroa.30.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 1
  %57 = load i16, ptr %v558_next.sroa.16.sroa.32.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 2
  %v558_next.sroa.16.sroa.34.0.copyload3029 = load i32, ptr %v558_next.sroa.16.sroa.34.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.36.0.copyload3030 = load i32, ptr %v558_next.sroa.16.sroa.36.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.16.sroa.38.0.copyload3031 = load i8, ptr %v558_next.sroa.16.sroa.38.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.40.0.copyload3032 = load i8, ptr %v558_next.sroa.16.sroa.40.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, align 1
  %v558_next.sroa.18.0.copyload1251 = load i32, ptr %v558_next.sroa.18.0.v556_mem.sroa_idx, align 8
  %v558_next.sroa.20.sroa.0.0.copyload2681 = load i32, ptr %v558_next.sroa.20.0.v556_mem.sroa_idx, align 4
  %v558_next.sroa.20.sroa.4.0.copyload2682 = load i64, ptr %v558_next.sroa.20.sroa.4.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.6.0.copyload2683 = load i64, ptr %v558_next.sroa.20.sroa.6.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.8.0.copyload2684 = load i64, ptr %v558_next.sroa.20.sroa.8.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.10.0.copyload2685 = load i32, ptr %v558_next.sroa.20.sroa.10.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.12.0.copyload2686 = load i32, ptr %v558_next.sroa.20.sroa.12.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.20.sroa.14.0.copyload2687 = load i64, ptr %v558_next.sroa.20.sroa.14.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.16.0.copyload2688 = load i64, ptr %v558_next.sroa.20.sroa.16.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.18.0.copyload2689 = load i64, ptr %v558_next.sroa.20.sroa.18.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.20.0.copyload2690 = load i8, ptr %v558_next.sroa.20.sroa.20.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %58 = load <2 x i32>, ptr %v558_next.sroa.20.sroa.24.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.20.sroa.28.0.copyload2693 = load i8, ptr %v558_next.sroa.20.sroa.28.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.20.sroa.30.0.copyload2694 = load i8, ptr %v558_next.sroa.20.sroa.30.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 1
  %59 = load i16, ptr %v558_next.sroa.20.sroa.32.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 2
  %60 = load <2 x i32>, ptr %v558_next.sroa.20.sroa.34.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.38.0.copyload2697 = load i8, ptr %v558_next.sroa.20.sroa.38.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.40.0.copyload2698 = load i8, ptr %v558_next.sroa.20.sroa.40.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, align 1
  %61 = load <2 x i32>, ptr %v558_next.sroa.22.0.v556_mem.sroa_idx, align 8
  %62 = load <2 x i64>, ptr %v558_next.sroa.24.sroa.4.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.8.0.copyload2350 = load i64, ptr %v558_next.sroa.24.sroa.8.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %63 = load <2 x i32>, ptr %v558_next.sroa.24.sroa.10.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %64 = load <2 x i64>, ptr %v558_next.sroa.24.sroa.14.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.18.0.copyload2355 = load i64, ptr %v558_next.sroa.24.sroa.18.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.20.0.copyload2356 = load i8, ptr %v558_next.sroa.24.sroa.20.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %65 = load <2 x i32>, ptr %v558_next.sroa.24.sroa.24.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.24.sroa.28.0.copyload2359 = load i8, ptr %v558_next.sroa.24.sroa.28.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.24.sroa.30.0.copyload2360 = load i8, ptr %v558_next.sroa.24.sroa.30.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 1
  %66 = load i16, ptr %v558_next.sroa.24.sroa.32.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 2
  %67 = load <2 x i32>, ptr %v558_next.sroa.24.sroa.34.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.38.0.copyload2363 = load i8, ptr %v558_next.sroa.24.sroa.38.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.40.0.copyload2364 = load i8, ptr %v558_next.sroa.24.sroa.40.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, align 1
  %68 = load <2 x i32>, ptr %v558_next.sroa.26.0.v556_mem.sroa_idx, align 8
  %69 = load <2 x i64>, ptr %v558_next.sroa.28.sroa.4.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.8.0.copyload2016 = load i64, ptr %v558_next.sroa.28.sroa.8.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %70 = load <2 x i32>, ptr %v558_next.sroa.28.sroa.10.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %71 = load <2 x i64>, ptr %v558_next.sroa.28.sroa.14.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.18.0.copyload2021 = load i64, ptr %v558_next.sroa.28.sroa.18.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.20.0.copyload2022 = load i8, ptr %v558_next.sroa.28.sroa.20.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %72 = load <2 x i32>, ptr %v558_next.sroa.28.sroa.24.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.28.sroa.28.0.copyload2025 = load i8, ptr %v558_next.sroa.28.sroa.28.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.28.sroa.30.0.copyload2026 = load i8, ptr %v558_next.sroa.28.sroa.30.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 1
  %73 = load i16, ptr %v558_next.sroa.28.sroa.32.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 2
  %74 = load <2 x i32>, ptr %v558_next.sroa.28.sroa.34.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.38.0.copyload2029 = load i8, ptr %v558_next.sroa.28.sroa.38.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.40.0.copyload2030 = load i8, ptr %v558_next.sroa.28.sroa.40.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, align 1
  %75 = load <2 x i32>, ptr %v558_next.sroa.30.0.v556_mem.sroa_idx, align 8
  %76 = load <2 x i64>, ptr %v558_next.sroa.32.sroa.4.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.8.0.copyload1682 = load i64, ptr %v558_next.sroa.32.sroa.8.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %77 = load <2 x i32>, ptr %v558_next.sroa.32.sroa.10.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %78 = load <2 x i64>, ptr %v558_next.sroa.32.sroa.14.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.18.0.copyload1687 = load i64, ptr %v558_next.sroa.32.sroa.18.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.20.0.copyload1688 = load i8, ptr %v558_next.sroa.32.sroa.20.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %79 = load <2 x i32>, ptr %v558_next.sroa.32.sroa.24.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.32.sroa.28.0.copyload1691 = load i8, ptr %v558_next.sroa.32.sroa.28.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.32.sroa.30.0.copyload1692 = load i8, ptr %v558_next.sroa.32.sroa.30.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 1
  %80 = load i16, ptr %v558_next.sroa.32.sroa.32.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 2
  %81 = load <2 x i32>, ptr %v558_next.sroa.32.sroa.34.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.38.0.copyload1695 = load i8, ptr %v558_next.sroa.32.sroa.38.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.40.0.copyload1696 = load i8, ptr %v558_next.sroa.32.sroa.40.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, align 1
  br label %b274_to_b59

b12_to_b13:                                       ; preds = %liza_console.write.exit, %liza_net.reactor_port.exit
  %v30 = phi i1 [ false, %liza_net.reactor_port.exit ], [ %spec.select, %liza_console.write.exit ]
  %v31 = phi i32 [ 3, %liza_net.reactor_port.exit ], [ %spec.select36, %liza_console.write.exit ]
  br i1 %v30, label %b14.lr.ph, label %b15

b14.lr.ph:                                        ; preds = %b12_to_b13
  %v2_mem.sroa.151.sroa.0.0.v2_mem.sroa.151.sroa.0.0.v2_mem.sroa.151.sroa.0.0.v33_next.sroa.32.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.151.sroa.0, align 1
  %v2_mem.sroa.150.sroa.0.0.v2_mem.sroa.150.sroa.0.0.v2_mem.sroa.150.sroa.0.0.v33_next.sroa.32.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.150.sroa.0, align 8
  %v2_mem.sroa.147.sroa.0.0.v2_mem.sroa.147.sroa.0.0.v2_mem.sroa.147.sroa.0.0.v33_next.sroa.32.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.147.sroa.0, align 1
  %v2_mem.sroa.146.sroa.0.0.v2_mem.sroa.146.sroa.0.0.v2_mem.sroa.146.sroa.0.0.v33_next.sroa.32.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.146.sroa.0, align 4
  %v2_mem.sroa.143.sroa.0.0.v2_mem.sroa.143.sroa.0.0.v2_mem.sroa.143.sroa.0.0.v33_next.sroa.32.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.143.sroa.0, align 8
  %v2_mem.sroa.132.sroa.0.0.v2_mem.sroa.132.sroa.0.0.v2_mem.sroa.132.sroa.0.0.v33_next.sroa.28.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.132.sroa.0, align 1
  %v2_mem.sroa.131.sroa.0.0.v2_mem.sroa.131.sroa.0.0.v2_mem.sroa.131.sroa.0.0.v33_next.sroa.28.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.131.sroa.0, align 8
  %v2_mem.sroa.128.sroa.0.0.v2_mem.sroa.128.sroa.0.0.v2_mem.sroa.128.sroa.0.0.v33_next.sroa.28.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.128.sroa.0, align 1
  %v2_mem.sroa.127.sroa.0.0.v2_mem.sroa.127.sroa.0.0.v2_mem.sroa.127.sroa.0.0.v33_next.sroa.28.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.127.sroa.0, align 4
  %v2_mem.sroa.124.sroa.0.0.v2_mem.sroa.124.sroa.0.0.v2_mem.sroa.124.sroa.0.0.v33_next.sroa.28.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.124.sroa.0, align 8
  %v2_mem.sroa.113.sroa.0.0.v2_mem.sroa.113.sroa.0.0.v2_mem.sroa.113.sroa.0.0.v33_next.sroa.24.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.113.sroa.0, align 1
  %v2_mem.sroa.112.sroa.0.0.v2_mem.sroa.112.sroa.0.0.v2_mem.sroa.112.sroa.0.0.v33_next.sroa.24.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.112.sroa.0, align 8
  %v2_mem.sroa.109.sroa.0.0.v2_mem.sroa.109.sroa.0.0.v2_mem.sroa.109.sroa.0.0.v33_next.sroa.24.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.109.sroa.0, align 1
  %v2_mem.sroa.108.sroa.0.0.v2_mem.sroa.108.sroa.0.0.v2_mem.sroa.108.sroa.0.0.v33_next.sroa.24.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.108.sroa.0, align 4
  %v2_mem.sroa.105.sroa.0.0.v2_mem.sroa.105.sroa.0.0.v2_mem.sroa.105.sroa.0.0.v33_next.sroa.24.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.105.sroa.0, align 8
  %v2_mem.sroa.94.sroa.0.0.v2_mem.sroa.94.sroa.0.0.v2_mem.sroa.94.sroa.0.0.v33_next.sroa.20.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.94.sroa.0, align 1
  %v2_mem.sroa.93.sroa.0.0.v2_mem.sroa.93.sroa.0.0.v2_mem.sroa.93.sroa.0.0.v33_next.sroa.20.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.93.sroa.0, align 8
  %v2_mem.sroa.90.sroa.0.0.v2_mem.sroa.90.sroa.0.0.v2_mem.sroa.90.sroa.0.0.v33_next.sroa.20.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.90.sroa.0, align 1
  %v2_mem.sroa.89.sroa.0.0.v2_mem.sroa.89.sroa.0.0.v2_mem.sroa.89.sroa.0.0.v33_next.sroa.20.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.89.sroa.0, align 4
  %v2_mem.sroa.86.sroa.0.0.v2_mem.sroa.86.sroa.0.0.v2_mem.sroa.86.sroa.0.0.v33_next.sroa.20.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.86.sroa.0, align 8
  %v2_mem.sroa.75.sroa.0.0.v2_mem.sroa.75.sroa.0.0.v2_mem.sroa.75.sroa.0.0.v33_next.sroa.16.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.75.sroa.0, align 1
  %v2_mem.sroa.74.sroa.0.0.v2_mem.sroa.74.sroa.0.0.v2_mem.sroa.74.sroa.0.0.v33_next.sroa.16.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.74.sroa.0, align 8
  %v2_mem.sroa.71.sroa.0.0.v2_mem.sroa.71.sroa.0.0.v2_mem.sroa.71.sroa.0.0.v33_next.sroa.16.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.71.sroa.0, align 1
  %v2_mem.sroa.70.sroa.0.0.v2_mem.sroa.70.sroa.0.0.v2_mem.sroa.70.sroa.0.0.v33_next.sroa.16.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.70.sroa.0, align 4
  %v2_mem.sroa.67.sroa.0.0.v2_mem.sroa.67.sroa.0.0.v2_mem.sroa.67.sroa.0.0.v33_next.sroa.16.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.67.sroa.0, align 8
  %v2_mem.sroa.56.sroa.0.0.v2_mem.sroa.56.sroa.0.0.v2_mem.sroa.56.sroa.0.0.v33_next.sroa.12.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.56.sroa.0, align 1
  %v2_mem.sroa.55.sroa.0.0.v2_mem.sroa.55.sroa.0.0.v2_mem.sroa.55.sroa.0.0.v33_next.sroa.12.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.55.sroa.0, align 8
  %v2_mem.sroa.52.sroa.0.0.v2_mem.sroa.52.sroa.0.0.v2_mem.sroa.52.sroa.0.0.v33_next.sroa.12.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.52.sroa.0, align 1
  %v2_mem.sroa.51.sroa.0.0.v2_mem.sroa.51.sroa.0.0.v2_mem.sroa.51.sroa.0.0.v33_next.sroa.12.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.51.sroa.0, align 4
  %v2_mem.sroa.48.sroa.0.0.v2_mem.sroa.48.sroa.0.0.v2_mem.sroa.48.sroa.0.0.v33_next.sroa.12.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.48.sroa.0, align 8
  %v2_mem.sroa.37.sroa.0.0.v2_mem.sroa.37.sroa.0.0.v2_mem.sroa.37.sroa.0.0.v33_next.sroa.8.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.37.sroa.0, align 1
  %v2_mem.sroa.36.sroa.0.0.v2_mem.sroa.36.sroa.0.0.v2_mem.sroa.36.sroa.0.0.v33_next.sroa.8.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.36.sroa.0, align 8
  %v2_mem.sroa.33.sroa.0.0.v2_mem.sroa.33.sroa.0.0.v2_mem.sroa.33.sroa.0.0.v33_next.sroa.8.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.33.sroa.0, align 1
  %v2_mem.sroa.32.sroa.0.0.v2_mem.sroa.32.sroa.0.0.v2_mem.sroa.32.sroa.0.0.v33_next.sroa.8.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.32.sroa.0, align 4
  %v2_mem.sroa.29.sroa.0.0.v2_mem.sroa.29.sroa.0.0.v2_mem.sroa.29.sroa.0.0.v33_next.sroa.8.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.29.sroa.0, align 8
  %v2_mem.sroa.18.sroa.0.0.v2_mem.sroa.18.sroa.0.0.v2_mem.sroa.18.sroa.0.0.v33_next.sroa.4.sroa.22.85.copyload = load i8, ptr %v2_mem.sroa.18.sroa.0, align 1
  %v2_mem.sroa.17.sroa.0.0.v2_mem.sroa.17.sroa.0.0.v2_mem.sroa.17.sroa.0.0.v33_next.sroa.4.sroa.21.84.copyload = load i8, ptr %v2_mem.sroa.17.sroa.0, align 8
  %v2_mem.sroa.14.sroa.0.0.v2_mem.sroa.14.sroa.0.0.v2_mem.sroa.14.sroa.0.0.v33_next.sroa.4.sroa.17.73.copyload = load i8, ptr %v2_mem.sroa.14.sroa.0, align 1
  %v2_mem.sroa.13.sroa.0.0.v2_mem.sroa.13.sroa.0.0.v2_mem.sroa.13.sroa.0.0.v33_next.sroa.4.sroa.16.72.copyload = load i8, ptr %v2_mem.sroa.13.sroa.0, align 4
  %v2_mem.sroa.10.sroa.0.0.v2_mem.sroa.10.sroa.0.0.v2_mem.sroa.10.sroa.0.0.v33_next.sroa.4.sroa.12.60.copyload = load i8, ptr %v2_mem.sroa.10.sroa.0, align 8
  %value.fca.1.gep.i.i = getelementptr inbounds nuw i8, ptr %out.i.i, i64 8
  %value.fca.2.gep.i.i = getelementptr inbounds nuw i8, ptr %out.i.i, i64 16
  %value.fca.1.gep.i.i129 = getelementptr inbounds nuw i8, ptr %out.i.i126, i64 8
  %value.fca.2.gep.i.i131 = getelementptr inbounds nuw i8, ptr %out.i.i126, i64 16
  %not.p3 = xor i1 %p3, true
  %p.i = extractvalue { ptr, i32 } %p1, 0
  %n.i = extractvalue { ptr, i32 } %p1, 1
  %v53_mem.sroa.6.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 4
  %v53_mem.sroa.6.sroa.5.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 8
  %v53_mem.sroa.6.sroa.6.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 16
  %v53_mem.sroa.6.sroa.7.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 24
  %v53_mem.sroa.6.sroa.8.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 32
  %v53_mem.sroa.6.sroa.9.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 36
  %v53_mem.sroa.6.sroa.10.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 40
  %v53_mem.sroa.6.sroa.11.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 48
  %v53_mem.sroa.6.sroa.12.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 56
  %v53_mem.sroa.6.sroa.13.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 64
  %v53_mem.sroa.6.sroa.14.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 65
  %v53_mem.sroa.6.sroa.15.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 68
  %v53_mem.sroa.6.sroa.16.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 72
  %v53_mem.sroa.6.sroa.17.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 76
  %v53_mem.sroa.6.sroa.18.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 77
  %v53_mem.sroa.6.sroa.19.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 78
  %v53_mem.sroa.6.sroa.20.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 80
  %v53_mem.sroa.6.sroa.21.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 84
  %v53_mem.sroa.6.sroa.22.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 88
  %v53_mem.sroa.6.sroa.23.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 89
  %v53_mem.sroa.6.sroa.24.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 90
  %v53_mem.sroa.61127.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 96
  %v53_mem.sroa.7.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 100
  %v53_mem.sroa.7.sroa.5.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 104
  %v53_mem.sroa.7.sroa.6.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 112
  %v53_mem.sroa.7.sroa.7.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 120
  %v53_mem.sroa.7.sroa.8.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 128
  %v53_mem.sroa.7.sroa.9.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 132
  %v53_mem.sroa.7.sroa.10.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 136
  %v53_mem.sroa.7.sroa.11.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 144
  %v53_mem.sroa.7.sroa.12.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 152
  %v53_mem.sroa.7.sroa.13.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 160
  %v53_mem.sroa.7.sroa.14.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 161
  %v53_mem.sroa.7.sroa.15.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 164
  %v53_mem.sroa.7.sroa.16.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 168
  %v53_mem.sroa.7.sroa.17.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 172
  %v53_mem.sroa.7.sroa.18.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 173
  %v53_mem.sroa.7.sroa.19.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 174
  %v53_mem.sroa.7.sroa.20.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 176
  %v53_mem.sroa.7.sroa.21.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 180
  %v53_mem.sroa.7.sroa.22.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 184
  %v53_mem.sroa.7.sroa.23.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 185
  %v53_mem.sroa.7.sroa.24.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 186
  %v53_mem.sroa.71132.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 192
  %v53_mem.sroa.8.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 196
  %v53_mem.sroa.8.sroa.5.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 200
  %v53_mem.sroa.8.sroa.6.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 208
  %v53_mem.sroa.8.sroa.7.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 216
  %v53_mem.sroa.8.sroa.8.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 224
  %v53_mem.sroa.8.sroa.9.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 228
  %v53_mem.sroa.8.sroa.10.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 232
  %v53_mem.sroa.8.sroa.11.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 240
  %v53_mem.sroa.8.sroa.12.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 248
  %v53_mem.sroa.8.sroa.13.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 256
  %v53_mem.sroa.8.sroa.14.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 257
  %v53_mem.sroa.8.sroa.15.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 260
  %v53_mem.sroa.8.sroa.16.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 264
  %v53_mem.sroa.8.sroa.17.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 268
  %v53_mem.sroa.8.sroa.18.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 269
  %v53_mem.sroa.8.sroa.19.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 270
  %v53_mem.sroa.8.sroa.20.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 272
  %v53_mem.sroa.8.sroa.21.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 276
  %v53_mem.sroa.8.sroa.22.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 280
  %v53_mem.sroa.8.sroa.23.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 281
  %v53_mem.sroa.8.sroa.24.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 282
  %v53_mem.sroa.81137.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 288
  %v53_mem.sroa.9.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 292
  %v53_mem.sroa.9.sroa.5.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 296
  %v53_mem.sroa.9.sroa.6.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 304
  %v53_mem.sroa.9.sroa.7.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 312
  %v53_mem.sroa.9.sroa.8.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 320
  %v53_mem.sroa.9.sroa.9.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 324
  %v53_mem.sroa.9.sroa.10.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 328
  %v53_mem.sroa.9.sroa.11.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 336
  %v53_mem.sroa.9.sroa.12.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 344
  %v53_mem.sroa.9.sroa.13.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 352
  %v53_mem.sroa.9.sroa.14.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 353
  %v53_mem.sroa.9.sroa.15.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 356
  %v53_mem.sroa.9.sroa.16.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 360
  %v53_mem.sroa.9.sroa.17.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 364
  %v53_mem.sroa.9.sroa.18.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 365
  %v53_mem.sroa.9.sroa.19.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 366
  %v53_mem.sroa.9.sroa.20.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 368
  %v53_mem.sroa.9.sroa.21.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 372
  %v53_mem.sroa.9.sroa.22.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 376
  %v53_mem.sroa.9.sroa.23.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 377
  %v53_mem.sroa.9.sroa.24.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 378
  %v53_mem.sroa.91142.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 384
  %v53_mem.sroa.10.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 388
  %v53_mem.sroa.10.sroa.5.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 392
  %v53_mem.sroa.10.sroa.6.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 400
  %v53_mem.sroa.10.sroa.7.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 408
  %v53_mem.sroa.10.sroa.8.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 416
  %v53_mem.sroa.10.sroa.9.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 420
  %v53_mem.sroa.10.sroa.10.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 424
  %v53_mem.sroa.10.sroa.11.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 432
  %v53_mem.sroa.10.sroa.12.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 440
  %v53_mem.sroa.10.sroa.13.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 448
  %v53_mem.sroa.10.sroa.14.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 449
  %v53_mem.sroa.10.sroa.15.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 452
  %v53_mem.sroa.10.sroa.16.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 456
  %v53_mem.sroa.10.sroa.17.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 460
  %v53_mem.sroa.10.sroa.18.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 461
  %v53_mem.sroa.10.sroa.19.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 462
  %v53_mem.sroa.10.sroa.20.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 464
  %v53_mem.sroa.10.sroa.21.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 468
  %v53_mem.sroa.10.sroa.22.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 472
  %v53_mem.sroa.10.sroa.23.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 473
  %v53_mem.sroa.10.sroa.24.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 474
  %v53_mem.sroa.101147.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 480
  %v53_mem.sroa.11.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 484
  %v53_mem.sroa.11.sroa.5.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 488
  %v53_mem.sroa.11.sroa.6.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 496
  %v53_mem.sroa.11.sroa.7.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 504
  %v53_mem.sroa.11.sroa.8.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 512
  %v53_mem.sroa.11.sroa.9.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 516
  %v53_mem.sroa.11.sroa.10.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 520
  %v53_mem.sroa.11.sroa.11.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 528
  %v53_mem.sroa.11.sroa.12.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 536
  %v53_mem.sroa.11.sroa.13.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 544
  %v53_mem.sroa.11.sroa.14.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 545
  %v53_mem.sroa.11.sroa.15.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 548
  %v53_mem.sroa.11.sroa.16.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 552
  %v53_mem.sroa.11.sroa.17.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 556
  %v53_mem.sroa.11.sroa.18.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 557
  %v53_mem.sroa.11.sroa.19.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 558
  %v53_mem.sroa.11.sroa.20.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 560
  %v53_mem.sroa.11.sroa.21.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 564
  %v53_mem.sroa.11.sroa.22.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 568
  %v53_mem.sroa.11.sroa.23.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 569
  %v53_mem.sroa.11.sroa.24.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 570
  %v53_mem.sroa.111152.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 576
  %v53_mem.sroa.12.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 580
  %v53_mem.sroa.12.sroa.5.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 584
  %v53_mem.sroa.12.sroa.6.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 592
  %v53_mem.sroa.12.sroa.7.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 600
  %v53_mem.sroa.12.sroa.8.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 608
  %v53_mem.sroa.12.sroa.9.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 612
  %v53_mem.sroa.12.sroa.10.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 616
  %v53_mem.sroa.12.sroa.11.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 624
  %v53_mem.sroa.12.sroa.12.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 632
  %v53_mem.sroa.12.sroa.13.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 640
  %v53_mem.sroa.12.sroa.14.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 641
  %v53_mem.sroa.12.sroa.15.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 644
  %v53_mem.sroa.12.sroa.16.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 648
  %v53_mem.sroa.12.sroa.17.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 652
  %v53_mem.sroa.12.sroa.18.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 653
  %v53_mem.sroa.12.sroa.19.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 654
  %v53_mem.sroa.12.sroa.20.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 656
  %v53_mem.sroa.12.sroa.21.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 660
  %v53_mem.sroa.12.sroa.22.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 664
  %v53_mem.sroa.12.sroa.23.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 665
  %v53_mem.sroa.12.sroa.24.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 666
  %v53_mem.sroa.121157.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 672
  %v53_mem.sroa.13.0.v108_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 676
  %v53_mem.sroa.13.sroa.5.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 680
  %v53_mem.sroa.13.sroa.6.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 688
  %v53_mem.sroa.13.sroa.7.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 696
  %v53_mem.sroa.13.sroa.8.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 704
  %v53_mem.sroa.13.sroa.9.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 708
  %v53_mem.sroa.13.sroa.10.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 712
  %v53_mem.sroa.13.sroa.11.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 720
  %v53_mem.sroa.13.sroa.12.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 728
  %v53_mem.sroa.13.sroa.13.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 736
  %v53_mem.sroa.13.sroa.14.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 737
  %v53_mem.sroa.13.sroa.15.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 740
  %v53_mem.sroa.13.sroa.16.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 744
  %v53_mem.sroa.13.sroa.17.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 748
  %v53_mem.sroa.13.sroa.18.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 749
  %v53_mem.sroa.13.sroa.19.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 750
  %v53_mem.sroa.13.sroa.20.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 752
  %v53_mem.sroa.13.sroa.21.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 756
  %v53_mem.sroa.13.sroa.22.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 760
  %v53_mem.sroa.13.sroa.23.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 761
  %v53_mem.sroa.13.sroa.24.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v108_mem, i64 762
  %v122_next.sroa.4.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 4
  %v122_next.sroa.4.sroa.4.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 8
  %v122_next.sroa.4.sroa.5.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 16
  %v122_next.sroa.4.sroa.6.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 24
  %v122_next.sroa.4.sroa.7.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 32
  %v122_next.sroa.4.sroa.8.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 36
  %v122_next.sroa.4.sroa.9.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 40
  %v122_next.sroa.4.sroa.10.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 48
  %v122_next.sroa.4.sroa.11.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 56
  %v122_next.sroa.4.sroa.12.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 64
  %v122_next.sroa.4.sroa.13.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 65
  %v122_next.sroa.4.sroa.14.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 68
  %v122_next.sroa.4.sroa.15.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 72
  %v122_next.sroa.4.sroa.16.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 76
  %v122_next.sroa.4.sroa.17.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 77
  %v122_next.sroa.4.sroa.18.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 78
  %v122_next.sroa.4.sroa.19.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 80
  %v122_next.sroa.4.sroa.20.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 84
  %v122_next.sroa.4.sroa.21.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 88
  %v122_next.sroa.4.sroa.22.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 89
  %v122_next.sroa.4.sroa.23.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 90
  %v122_next.sroa.5.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 96
  %v122_next.sroa.6.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 100
  %v122_next.sroa.6.sroa.4.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 104
  %v122_next.sroa.6.sroa.5.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 112
  %v122_next.sroa.6.sroa.6.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 120
  %v122_next.sroa.6.sroa.7.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 128
  %v122_next.sroa.6.sroa.8.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 132
  %v122_next.sroa.6.sroa.9.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 136
  %v122_next.sroa.6.sroa.10.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 144
  %v122_next.sroa.6.sroa.11.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 152
  %v122_next.sroa.6.sroa.12.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 160
  %v122_next.sroa.6.sroa.13.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 161
  %v122_next.sroa.6.sroa.14.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 164
  %v122_next.sroa.6.sroa.15.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 168
  %v122_next.sroa.6.sroa.16.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 172
  %v122_next.sroa.6.sroa.17.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 173
  %v122_next.sroa.6.sroa.18.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 174
  %v122_next.sroa.6.sroa.19.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 176
  %v122_next.sroa.6.sroa.20.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 180
  %v122_next.sroa.6.sroa.21.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 184
  %v122_next.sroa.6.sroa.22.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 185
  %v122_next.sroa.6.sroa.23.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 186
  %v122_next.sroa.7.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 192
  %v122_next.sroa.8.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 196
  %v122_next.sroa.8.sroa.4.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 200
  %v122_next.sroa.8.sroa.5.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 208
  %v122_next.sroa.8.sroa.6.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 216
  %v122_next.sroa.8.sroa.7.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 224
  %v122_next.sroa.8.sroa.8.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 228
  %v122_next.sroa.8.sroa.9.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 232
  %v122_next.sroa.8.sroa.10.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 240
  %v122_next.sroa.8.sroa.11.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 248
  %v122_next.sroa.8.sroa.12.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 256
  %v122_next.sroa.8.sroa.13.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 257
  %v122_next.sroa.8.sroa.14.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 260
  %v122_next.sroa.8.sroa.15.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 264
  %v122_next.sroa.8.sroa.16.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 268
  %v122_next.sroa.8.sroa.17.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 269
  %v122_next.sroa.8.sroa.18.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 270
  %v122_next.sroa.8.sroa.19.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 272
  %v122_next.sroa.8.sroa.20.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 276
  %v122_next.sroa.8.sroa.21.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 280
  %v122_next.sroa.8.sroa.22.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 281
  %v122_next.sroa.8.sroa.23.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 282
  %v122_next.sroa.9.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 288
  %v122_next.sroa.10.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 292
  %v122_next.sroa.10.sroa.4.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 296
  %v122_next.sroa.10.sroa.5.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 304
  %v122_next.sroa.10.sroa.6.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 312
  %v122_next.sroa.10.sroa.7.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 320
  %v122_next.sroa.10.sroa.8.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 324
  %v122_next.sroa.10.sroa.9.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 328
  %v122_next.sroa.10.sroa.10.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 336
  %v122_next.sroa.10.sroa.11.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 344
  %v122_next.sroa.10.sroa.12.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 352
  %v122_next.sroa.10.sroa.13.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 353
  %v122_next.sroa.10.sroa.14.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 356
  %v122_next.sroa.10.sroa.15.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 360
  %v122_next.sroa.10.sroa.16.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 364
  %v122_next.sroa.10.sroa.17.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 365
  %v122_next.sroa.10.sroa.18.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 366
  %v122_next.sroa.10.sroa.19.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 368
  %v122_next.sroa.10.sroa.20.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 372
  %v122_next.sroa.10.sroa.21.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 376
  %v122_next.sroa.10.sroa.22.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 377
  %v122_next.sroa.10.sroa.23.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 378
  %v122_next.sroa.11.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 384
  %v122_next.sroa.12.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 388
  %v122_next.sroa.12.sroa.4.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 392
  %v122_next.sroa.12.sroa.5.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 400
  %v122_next.sroa.12.sroa.6.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 408
  %v122_next.sroa.12.sroa.7.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 416
  %v122_next.sroa.12.sroa.8.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 420
  %v122_next.sroa.12.sroa.9.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 424
  %v122_next.sroa.12.sroa.10.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 432
  %v122_next.sroa.12.sroa.11.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 440
  %v122_next.sroa.12.sroa.12.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 448
  %v122_next.sroa.12.sroa.13.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 449
  %v122_next.sroa.12.sroa.14.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 452
  %v122_next.sroa.12.sroa.15.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 456
  %v122_next.sroa.12.sroa.16.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 460
  %v122_next.sroa.12.sroa.17.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 461
  %v122_next.sroa.12.sroa.18.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 462
  %v122_next.sroa.12.sroa.19.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 464
  %v122_next.sroa.12.sroa.20.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 468
  %v122_next.sroa.12.sroa.21.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 472
  %v122_next.sroa.12.sroa.22.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 473
  %v122_next.sroa.12.sroa.23.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 474
  %v122_next.sroa.13.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 480
  %v122_next.sroa.14.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 484
  %v122_next.sroa.14.sroa.4.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 488
  %v122_next.sroa.14.sroa.5.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 496
  %v122_next.sroa.14.sroa.6.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 504
  %v122_next.sroa.14.sroa.7.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 512
  %v122_next.sroa.14.sroa.8.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 516
  %v122_next.sroa.14.sroa.9.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 520
  %v122_next.sroa.14.sroa.10.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 528
  %v122_next.sroa.14.sroa.11.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 536
  %v122_next.sroa.14.sroa.12.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 544
  %v122_next.sroa.14.sroa.13.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 545
  %v122_next.sroa.14.sroa.14.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 548
  %v122_next.sroa.14.sroa.15.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 552
  %v122_next.sroa.14.sroa.16.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 556
  %v122_next.sroa.14.sroa.17.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 557
  %v122_next.sroa.14.sroa.18.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 558
  %v122_next.sroa.14.sroa.19.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 560
  %v122_next.sroa.14.sroa.20.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 564
  %v122_next.sroa.14.sroa.21.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 568
  %v122_next.sroa.14.sroa.22.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 569
  %v122_next.sroa.14.sroa.23.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 570
  %v122_next.sroa.15.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 576
  %v122_next.sroa.16.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 580
  %v122_next.sroa.16.sroa.4.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 584
  %v122_next.sroa.16.sroa.5.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 592
  %v122_next.sroa.16.sroa.6.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 600
  %v122_next.sroa.16.sroa.7.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 608
  %v122_next.sroa.16.sroa.8.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 612
  %v122_next.sroa.16.sroa.9.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 616
  %v122_next.sroa.16.sroa.10.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 624
  %v122_next.sroa.16.sroa.11.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 632
  %v122_next.sroa.16.sroa.12.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 640
  %v122_next.sroa.16.sroa.13.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 641
  %v122_next.sroa.16.sroa.14.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 644
  %v122_next.sroa.16.sroa.15.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 648
  %v122_next.sroa.16.sroa.16.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 652
  %v122_next.sroa.16.sroa.17.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 653
  %v122_next.sroa.16.sroa.18.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 654
  %v122_next.sroa.16.sroa.19.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 656
  %v122_next.sroa.16.sroa.20.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 660
  %v122_next.sroa.16.sroa.21.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 664
  %v122_next.sroa.16.sroa.22.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 665
  %v122_next.sroa.16.sroa.23.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 666
  %v122_next.sroa.17.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 672
  %v122_next.sroa.18.0.v122_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 676
  %v122_next.sroa.18.sroa.4.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 680
  %v122_next.sroa.18.sroa.5.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 688
  %v122_next.sroa.18.sroa.6.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 696
  %v122_next.sroa.18.sroa.7.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 704
  %v122_next.sroa.18.sroa.8.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 708
  %v122_next.sroa.18.sroa.9.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 712
  %v122_next.sroa.18.sroa.10.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 720
  %v122_next.sroa.18.sroa.11.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 728
  %v122_next.sroa.18.sroa.12.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 736
  %v122_next.sroa.18.sroa.13.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 737
  %v122_next.sroa.18.sroa.14.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 740
  %v122_next.sroa.18.sroa.15.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 744
  %v122_next.sroa.18.sroa.16.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 748
  %v122_next.sroa.18.sroa.17.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 749
  %v122_next.sroa.18.sroa.18.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 750
  %v122_next.sroa.18.sroa.19.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 752
  %v122_next.sroa.18.sroa.20.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 756
  %v122_next.sroa.18.sroa.21.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 760
  %v122_next.sroa.18.sroa.22.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 761
  %v122_next.sroa.18.sroa.23.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v122_mem, i64 762
  %v558_next.sroa.4.sroa.4.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 8
  %v558_next.sroa.4.sroa.8.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 24
  %v558_next.sroa.4.sroa.10.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 32
  %v558_next.sroa.4.sroa.14.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 40
  %v558_next.sroa.4.sroa.18.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 56
  %v558_next.sroa.4.sroa.20.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 64
  %v558_next.sroa.4.sroa.22.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 65
  %v558_next.sroa.4.sroa.24.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 68
  %v558_next.sroa.4.sroa.28.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 76
  %v558_next.sroa.4.sroa.30.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 77
  %v558_next.sroa.4.sroa.32.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 78
  %v558_next.sroa.4.sroa.34.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 80
  %v558_next.sroa.4.sroa.38.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 88
  %v558_next.sroa.4.sroa.40.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 89
  %v558_next.sroa.4.sroa.42.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 90
  %v558_next.sroa.6.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 96
  %v558_next.sroa.8.sroa.4.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 104
  %v558_next.sroa.8.sroa.8.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 120
  %v558_next.sroa.8.sroa.10.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 128
  %v558_next.sroa.8.sroa.14.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 136
  %v558_next.sroa.8.sroa.18.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 152
  %v558_next.sroa.8.sroa.20.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 160
  %v558_next.sroa.8.sroa.22.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 161
  %v558_next.sroa.8.sroa.24.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 164
  %v558_next.sroa.8.sroa.28.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 172
  %v558_next.sroa.8.sroa.30.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 173
  %v558_next.sroa.8.sroa.32.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 174
  %v558_next.sroa.8.sroa.34.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 176
  %v558_next.sroa.8.sroa.38.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 184
  %v558_next.sroa.8.sroa.40.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 185
  %v558_next.sroa.8.sroa.42.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 186
  %v558_next.sroa.10.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 192
  %v558_next.sroa.12.sroa.4.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 200
  %v558_next.sroa.12.sroa.8.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 216
  %v558_next.sroa.12.sroa.10.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 224
  %v558_next.sroa.12.sroa.14.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 232
  %v558_next.sroa.12.sroa.18.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 248
  %v558_next.sroa.12.sroa.20.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 256
  %v558_next.sroa.12.sroa.22.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 257
  %v558_next.sroa.12.sroa.24.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 260
  %v558_next.sroa.12.sroa.28.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 268
  %v558_next.sroa.12.sroa.30.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 269
  %v558_next.sroa.12.sroa.32.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 270
  %v558_next.sroa.12.sroa.34.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 272
  %v558_next.sroa.12.sroa.38.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 280
  %v558_next.sroa.12.sroa.40.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 281
  %v558_next.sroa.12.sroa.42.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 282
  %v558_next.sroa.14.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 288
  %v558_next.sroa.16.sroa.4.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 296
  %v558_next.sroa.16.sroa.8.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 312
  %v558_next.sroa.16.sroa.10.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 320
  %v558_next.sroa.16.sroa.14.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 328
  %v558_next.sroa.16.sroa.18.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 344
  %v558_next.sroa.16.sroa.20.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 352
  %v558_next.sroa.16.sroa.22.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 353
  %v558_next.sroa.16.sroa.24.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 356
  %v558_next.sroa.16.sroa.28.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 364
  %v558_next.sroa.16.sroa.30.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 365
  %v558_next.sroa.16.sroa.32.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 366
  %v558_next.sroa.16.sroa.34.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 368
  %v558_next.sroa.16.sroa.36.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 372
  %v558_next.sroa.16.sroa.38.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 376
  %v558_next.sroa.16.sroa.40.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 377
  %v558_next.sroa.16.sroa.42.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 378
  %v558_next.sroa.18.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 384
  %v558_next.sroa.20.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 388
  %v558_next.sroa.20.sroa.4.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 392
  %v558_next.sroa.20.sroa.6.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 400
  %v558_next.sroa.20.sroa.8.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 408
  %v558_next.sroa.20.sroa.10.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 416
  %v558_next.sroa.20.sroa.12.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 420
  %v558_next.sroa.20.sroa.14.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 424
  %v558_next.sroa.20.sroa.16.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 432
  %v558_next.sroa.20.sroa.18.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 440
  %v558_next.sroa.20.sroa.20.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 448
  %v558_next.sroa.20.sroa.22.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 449
  %v558_next.sroa.20.sroa.24.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 452
  %v558_next.sroa.20.sroa.28.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 460
  %v558_next.sroa.20.sroa.30.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 461
  %v558_next.sroa.20.sroa.32.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 462
  %v558_next.sroa.20.sroa.34.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 464
  %v558_next.sroa.20.sroa.38.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 472
  %v558_next.sroa.20.sroa.40.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 473
  %v558_next.sroa.20.sroa.42.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 474
  %v558_next.sroa.22.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 480
  %v558_next.sroa.24.sroa.4.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 488
  %v558_next.sroa.24.sroa.8.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 504
  %v558_next.sroa.24.sroa.10.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 512
  %v558_next.sroa.24.sroa.14.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 520
  %v558_next.sroa.24.sroa.18.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 536
  %v558_next.sroa.24.sroa.20.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 544
  %v558_next.sroa.24.sroa.22.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 545
  %v558_next.sroa.24.sroa.24.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 548
  %v558_next.sroa.24.sroa.28.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 556
  %v558_next.sroa.24.sroa.30.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 557
  %v558_next.sroa.24.sroa.32.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 558
  %v558_next.sroa.24.sroa.34.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 560
  %v558_next.sroa.24.sroa.38.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 568
  %v558_next.sroa.24.sroa.40.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 569
  %v558_next.sroa.24.sroa.42.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 570
  %v558_next.sroa.26.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 576
  %v558_next.sroa.28.sroa.4.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 584
  %v558_next.sroa.28.sroa.8.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 600
  %v558_next.sroa.28.sroa.10.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 608
  %v558_next.sroa.28.sroa.14.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 616
  %v558_next.sroa.28.sroa.18.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 632
  %v558_next.sroa.28.sroa.20.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 640
  %v558_next.sroa.28.sroa.22.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 641
  %v558_next.sroa.28.sroa.24.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 644
  %v558_next.sroa.28.sroa.28.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 652
  %v558_next.sroa.28.sroa.30.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 653
  %v558_next.sroa.28.sroa.32.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 654
  %v558_next.sroa.28.sroa.34.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 656
  %v558_next.sroa.28.sroa.38.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 664
  %v558_next.sroa.28.sroa.40.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 665
  %v558_next.sroa.28.sroa.42.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 666
  %v558_next.sroa.30.0.v556_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 672
  %v558_next.sroa.32.sroa.4.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 680
  %v558_next.sroa.32.sroa.8.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 696
  %v558_next.sroa.32.sroa.10.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 704
  %v558_next.sroa.32.sroa.14.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 712
  %v558_next.sroa.32.sroa.18.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 728
  %v558_next.sroa.32.sroa.20.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 736
  %v558_next.sroa.32.sroa.22.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 737
  %v558_next.sroa.32.sroa.24.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 740
  %v558_next.sroa.32.sroa.28.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 748
  %v558_next.sroa.32.sroa.30.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 749
  %v558_next.sroa.32.sroa.32.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 750
  %v558_next.sroa.32.sroa.34.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 752
  %v558_next.sroa.32.sroa.38.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 760
  %v558_next.sroa.32.sroa.40.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 761
  %v558_next.sroa.32.sroa.42.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %v556_mem, i64 762
  br label %b14

b61_to_b13:                                       ; preds = %b274_to_b59, %b58_to_b59.b61_to_b13_crit_edge
  %v33_next.sroa.20.sroa.11.0.copyload = phi i64 [ %v33_next.sroa.20.sroa.11.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.10.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.10.0.copyload = phi i64 [ %v33_next.sroa.20.sroa.10.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.9.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.9.0.copyload = phi i64 [ %v33_next.sroa.20.sroa.9.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.8.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.8.0.copyload = phi i32 [ %v33_next.sroa.20.sroa.8.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.7.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.7.0.copyload = phi i32 [ %v33_next.sroa.20.sroa.7.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.6.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.6.0.copyload = phi i64 [ %v33_next.sroa.20.sroa.6.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.5.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.5.0.copyload = phi i64 [ %v33_next.sroa.20.sroa.5.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.4.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.4.0.copyload = phi i64 [ %v33_next.sroa.20.sroa.4.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.3.0, %b274_to_b59 ]
  %v33_next.sroa.20.sroa.0.0.copyload = phi i32 [ %v33_next.sroa.20.sroa.0.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.11.sroa.0.0, %b274_to_b59 ]
  %v33_next.sroa.18.0.copyload1328 = phi i32 [ %v33_next.sroa.18.0.copyload1328.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.10.0, %b274_to_b59 ]
  %v33_next.sroa.16.sroa.22.0.copyload = phi i8 [ %v33_next.sroa.16.sroa.22.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.9.sroa.21.0, %b274_to_b59 ]
  %v33_next.sroa.16.sroa.21.0.copyload = phi i8 [ %v33_next.sroa.16.sroa.21.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.9.sroa.20.0, %b274_to_b59 ]
  %v33_next.sroa.16.sroa.20.0.copyload = phi i32 [ %v33_next.sroa.16.sroa.20.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.9.sroa.19.0, %b274_to_b59 ]
  %v33_next.sroa.16.sroa.19.0.copyload = phi i32 [ %v33_next.sroa.16.sroa.19.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.9.sroa.18.0, %b274_to_b59 ]
  %v33_next.sroa.16.sroa.17.0.copyload = phi i8 [ %v33_next.sroa.16.sroa.17.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.9.sroa.16.0, %b274_to_b59 ]
  %v33_next.sroa.16.sroa.16.0.copyload = phi i8 [ %v33_next.sroa.16.sroa.16.0.copyload.pre, %b58_to_b59.b61_to_b13_crit_edge ], [ %v558_mem.sroa.9.sroa.15.0, %b274_to_b59 ]
  %v123.lcssa = phi i1 [ false, %b58_to_b59.b61_to_b13_crit_edge ], [ %v559, %b274_to_b59 ]
  %v125.lcssa = phi i32 [ %v119, %b58_to_b59.b61_to_b13_crit_edge ], [ %v560, %b274_to_b59 ]
  %v33_next.sroa.0.0.copyload1324 = load i32, ptr %v122_mem, align 8
  %v33_next.sroa.4.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.4.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.4.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.4.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.5.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.5.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.6.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.7.0.copyload = load i32, ptr %v122_next.sroa.4.sroa.7.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.8.0.copyload = load i32, ptr %v122_next.sroa.4.sroa.8.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.4.sroa.9.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.9.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.10.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.10.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.11.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.11.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.12.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.3.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.4.sroa.13.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.4.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.4.sroa.14.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.4.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.4.sroa.15.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.16.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.16.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.4.sroa.17.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.17.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  %82 = load i16, ptr %v122_next.sroa.4.sroa.18.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v33_next.sroa.4.sroa.19.0.copyload = load i32, ptr %v122_next.sroa.4.sroa.19.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.20.0.copyload = load i32, ptr %v122_next.sroa.4.sroa.20.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.4.sroa.21.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.21.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.4.sroa.22.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.22.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.3.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.4.sroa.23.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  %v33_next.sroa.6.0.copyload1325 = load i32, ptr %v122_next.sroa.5.0.v122_mem.sroa_idx, align 8
  %v33_next.sroa.8.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.6.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.8.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.4.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.5.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.5.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.6.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.7.0.copyload = load i32, ptr %v122_next.sroa.6.sroa.7.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.8.0.copyload = load i32, ptr %v122_next.sroa.6.sroa.8.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.8.sroa.9.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.9.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.10.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.10.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.11.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.11.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.12.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.5.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.6.sroa.13.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.8.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.6.sroa.14.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.8.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.6.sroa.15.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.16.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.16.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.8.sroa.17.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.17.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  %83 = load i16, ptr %v122_next.sroa.6.sroa.18.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v33_next.sroa.8.sroa.19.0.copyload = load i32, ptr %v122_next.sroa.6.sroa.19.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.20.0.copyload = load i32, ptr %v122_next.sroa.6.sroa.20.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.8.sroa.21.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.21.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.8.sroa.22.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.22.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.5.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.6.sroa.23.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  %v33_next.sroa.10.0.copyload1326 = load i32, ptr %v122_next.sroa.7.0.v122_mem.sroa_idx, align 8
  %v33_next.sroa.12.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.8.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.12.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.4.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.5.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.5.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.6.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.7.0.copyload = load i32, ptr %v122_next.sroa.8.sroa.7.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.8.0.copyload = load i32, ptr %v122_next.sroa.8.sroa.8.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.12.sroa.9.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.9.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.10.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.10.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.11.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.11.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.12.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.7.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.8.sroa.13.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.12.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.8.sroa.14.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.12.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.8.sroa.15.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.16.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.16.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.12.sroa.17.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.17.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  %84 = load i16, ptr %v122_next.sroa.8.sroa.18.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v33_next.sroa.12.sroa.19.0.copyload = load i32, ptr %v122_next.sroa.8.sroa.19.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.20.0.copyload = load i32, ptr %v122_next.sroa.8.sroa.20.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.12.sroa.21.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.21.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.12.sroa.22.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.22.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.7.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.8.sroa.23.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  %v33_next.sroa.14.0.copyload1327 = load i32, ptr %v122_next.sroa.9.0.v122_mem.sroa_idx, align 8
  %v33_next.sroa.16.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.10.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.16.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.4.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.5.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.5.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.6.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.7.0.copyload = load i32, ptr %v122_next.sroa.10.sroa.7.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.8.0.copyload = load i32, ptr %v122_next.sroa.10.sroa.8.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.16.sroa.9.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.9.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.10.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.10.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.11.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.11.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.10.sroa.12.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.9.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.10.sroa.13.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.16.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.10.sroa.14.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.16.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.10.sroa.15.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %85 = load i16, ptr %v122_next.sroa.10.sroa.18.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.9.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.10.sroa.23.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  %v33_next.sroa.20.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.12.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.11.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.20.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.12.sroa.14.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.20.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.12.sroa.15.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.16.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.16.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.20.sroa.17.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.17.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  %86 = load i16, ptr %v122_next.sroa.12.sroa.18.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v33_next.sroa.20.sroa.19.0.copyload = load i32, ptr %v122_next.sroa.12.sroa.19.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.20.0.copyload = load i32, ptr %v122_next.sroa.12.sroa.20.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.20.sroa.21.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.21.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.22.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.22.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.11.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  %v33_next.sroa.22.0.copyload1329 = load i32, ptr %v122_next.sroa.13.0.v122_mem.sroa_idx, align 8
  %v33_next.sroa.24.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.14.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.24.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.4.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.5.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.5.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.6.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.7.0.copyload = load i32, ptr %v122_next.sroa.14.sroa.7.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.8.0.copyload = load i32, ptr %v122_next.sroa.14.sroa.8.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.24.sroa.9.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.9.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.10.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.10.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.11.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.11.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.12.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.13.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.24.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.14.sroa.14.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.24.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.14.sroa.15.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.16.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.16.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.24.sroa.17.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.17.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  %87 = load i16, ptr %v122_next.sroa.14.sroa.18.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v33_next.sroa.24.sroa.19.0.copyload = load i32, ptr %v122_next.sroa.14.sroa.19.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.20.0.copyload = load i32, ptr %v122_next.sroa.14.sroa.20.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.24.sroa.21.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.21.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.24.sroa.22.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.22.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.13.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  %v33_next.sroa.26.0.copyload1330 = load i32, ptr %v122_next.sroa.15.0.v122_mem.sroa_idx, align 8
  %v33_next.sroa.28.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.16.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.28.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.4.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.5.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.5.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.6.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.7.0.copyload = load i32, ptr %v122_next.sroa.16.sroa.7.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.8.0.copyload = load i32, ptr %v122_next.sroa.16.sroa.8.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.28.sroa.9.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.9.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.10.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.10.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.11.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.11.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.12.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.15.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.28.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.16.sroa.14.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.28.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.16.sroa.15.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.16.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.16.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.28.sroa.17.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.17.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  %88 = load i16, ptr %v122_next.sroa.16.sroa.18.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v33_next.sroa.28.sroa.19.0.copyload = load i32, ptr %v122_next.sroa.16.sroa.19.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.20.0.copyload = load i32, ptr %v122_next.sroa.16.sroa.20.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.28.sroa.21.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.21.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.28.sroa.22.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.22.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.15.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  %v33_next.sroa.30.0.copyload1331 = load i32, ptr %v122_next.sroa.17.0.v122_mem.sroa_idx, align 8
  %v33_next.sroa.32.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.18.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.32.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.4.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.5.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.5.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.6.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.7.0.copyload = load i32, ptr %v122_next.sroa.18.sroa.7.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.8.0.copyload = load i32, ptr %v122_next.sroa.18.sroa.8.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.32.sroa.9.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.9.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.10.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.10.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.11.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.11.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.12.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.12.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.17.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, i64 3, i1 false)
  %v33_next.sroa.32.sroa.14.0.copyload = load i32, ptr %v122_next.sroa.18.sroa.14.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.32.sroa.15.0.copyload = load i32, ptr %v122_next.sroa.18.sroa.15.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.16.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.16.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.32.sroa.17.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.17.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  %89 = load i16, ptr %v122_next.sroa.18.sroa.18.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v33_next.sroa.32.sroa.19.0.copyload = load i32, ptr %v122_next.sroa.18.sroa.19.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.20.0.copyload = load i32, ptr %v122_next.sroa.18.sroa.20.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.32.sroa.21.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.21.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.32.sroa.22.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.22.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.17.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, i64 6, i1 false)
  br i1 %v123.lcssa, label %b14, label %b15

b22_to_b23:                                       ; preds = %0, %b17, %b17, %b17, %b17, %b17, %b17, %b17, %b17, %b17, %liza_net.reactor_poll.exit
  %v48 = phi i1 [ true, %liza_net.reactor_poll.exit ], [ true, %0 ], [ false, %b17 ], [ false, %b17 ], [ false, %b17 ], [ false, %b17 ], [ false, %b17 ], [ false, %b17 ], [ false, %b17 ], [ false, %b17 ], [ false, %b17 ]
  %v49 = phi i32 [ %v361109, %liza_net.reactor_poll.exit ], [ %v361109, %0 ], [ 3, %b17 ], [ 3, %b17 ], [ 3, %b17 ], [ 3, %b17 ], [ 3, %b17 ], [ 3, %b17 ], [ 3, %b17 ], [ 3, %b17 ], [ 3, %b17 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_next.sroa.8.sroa.11, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.9.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.9.sroa.24, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.9.sroa.41, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.10.sroa.14, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.11.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.10.sroa.24, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.11.sroa.41, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.11.sroa.14, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.13.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.11.sroa.24, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.13.sroa.41, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.12.sroa.14, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.15.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.12.sroa.24, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.15.sroa.41, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v53_mem.sroa.13.sroa.14, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.17.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v53_mem.sroa.13.sroa.24, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.17.sroa.41, i64 6, i1 false)
  store i16 %v33_mem.sroa.3.sroa.31.sroa.0.0, ptr %v53_mem.sroa.6.sroa.19, align 2
  store i16 %v33_mem.sroa.5.sroa.31.sroa.0.0, ptr %v53_mem.sroa.7.sroa.19, align 2
  store i16 %v33_mem.sroa.7.sroa.31.sroa.0.0, ptr %v53_mem.sroa.8.sroa.19, align 2
  store i16 %v33_mem.sroa.9.sroa.31.sroa.0.0, ptr %v53_mem.sroa.9.sroa.19, align 2
  store i16 %v33_mem.sroa.11.sroa.31.sroa.0.0, ptr %v53_mem.sroa.10.sroa.19, align 2
  store i16 %v33_mem.sroa.13.sroa.31.sroa.0.0, ptr %v53_mem.sroa.11.sroa.19, align 2
  store i16 %v33_mem.sroa.15.sroa.31.sroa.0.0, ptr %v53_mem.sroa.12.sroa.19, align 2
  store i16 %v33_mem.sroa.17.sroa.31.sroa.0.0, ptr %v53_mem.sroa.13.sroa.19, align 2
  %switch11.not = icmp eq i32 %v33_mem.sroa.0.0, 1
  %switch11.1 = icmp eq i32 %v33_mem.sroa.4.0, 1
  %v68 = select i1 %switch11.1, i32 1, i32 8
  %v68.1 = select i1 %switch11.not, i32 0, i32 %v68
  %switch11.2 = icmp eq i32 %v33_mem.sroa.6.0, 1
  %v65.2 = icmp eq i32 %v68.1, 8
  %90 = select i1 %switch11.2, i1 %v65.2, i1 false
  %v68.2 = select i1 %90, i32 2, i32 %v68.1
  %switch11.3 = icmp eq i32 %v33_mem.sroa.8.0, 1
  %v65.3 = icmp eq i32 %v68.2, 8
  %91 = select i1 %switch11.3, i1 %v65.3, i1 false
  %v68.3 = select i1 %91, i32 3, i32 %v68.2
  %switch11.4 = icmp eq i32 %v33_mem.sroa.10.0, 1
  %v65.4 = icmp eq i32 %v68.3, 8
  %92 = select i1 %switch11.4, i1 %v65.4, i1 false
  %v68.4 = select i1 %92, i32 4, i32 %v68.3
  %switch11.5 = icmp eq i32 %v33_mem.sroa.12.0, 1
  %v65.5 = icmp eq i32 %v68.4, 8
  %93 = select i1 %switch11.5, i1 %v65.5, i1 false
  %v68.5 = select i1 %93, i32 5, i32 %v68.4
  %switch11.6 = icmp eq i32 %v33_mem.sroa.14.0, 1
  %v65.6 = icmp eq i32 %v68.5, 8
  %94 = select i1 %switch11.6, i1 %v65.6, i1 false
  %v68.6 = select i1 %94, i32 6, i32 %v68.5
  %switch11.7 = icmp eq i32 %v33_mem.sroa.16.0, 1
  %v65.7 = icmp eq i32 %v68.6, 8
  %95 = select i1 %switch11.7, i1 %v65.7, i1 false
  %v68.7 = select i1 %95, i32 7, i32 %v68.6
  %v73 = icmp samesign ugt i32 %v68.7, 7
  %not.v48 = xor i1 %v48, true
  %v74 = select i1 %not.v48, i1 true, i1 %v73
  %96 = select i1 %p3, i1 %v351108, i1 false
  %or.cond12 = select i1 %v74, i1 true, i1 %96
  br i1 %or.cond12, label %b58_to_b59, label %b42

b56_to_b57:                                       ; preds = %b51, %v101_ok
  %v109_next.sroa.46.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.13.sroa.19.0.4128, %b51 ], [ %10, %v101_ok ]
  %v109_next.sroa.40.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.12.sroa.19.0.4129, %b51 ], [ %9, %v101_ok ]
  %v109_next.sroa.34.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.11.sroa.19.0.4130, %b51 ], [ %8, %v101_ok ]
  %v109_next.sroa.28.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.10.sroa.19.0.4131, %b51 ], [ %7, %v101_ok ]
  %v109_next.sroa.22.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.9.sroa.19.0.4132, %b51 ], [ %6, %v101_ok ]
  %v109_next.sroa.16.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.8.sroa.19.0.4133, %b51 ], [ %5, %v101_ok ]
  %v109_next.sroa.10.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.7.sroa.19.0.4134, %b51 ], [ %4, %v101_ok ]
  %v109_next.sroa.4.sroa.18.sroa.0.0 = phi i16 [ %v53_mem.sroa.6.sroa.19.0.4135, %b51 ], [ %3, %v101_ok ]
  %v33_mem.sroa.17.sroa.41.sink4068 = phi ptr [ %v33_mem.sroa.17.sroa.41, %b51 ], [ %v53_mem.sroa.13.sroa.24.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.3.sroa.21.sink = phi ptr [ %v33_mem.sroa.3.sroa.21, %b51 ], [ %v53_mem.sroa.6.sroa.14.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.3.sroa.41.sink = phi ptr [ %v33_mem.sroa.3.sroa.41, %b51 ], [ %v53_mem.sroa.6.sroa.24.0.v53_mem.sroa.6.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.5.sroa.21.sink = phi ptr [ %v33_mem.sroa.5.sroa.21, %b51 ], [ %v53_mem.sroa.7.sroa.14.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.5.sroa.41.sink = phi ptr [ %v33_mem.sroa.5.sroa.41, %b51 ], [ %v53_mem.sroa.7.sroa.24.0.v53_mem.sroa.7.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.7.sroa.21.sink = phi ptr [ %v33_mem.sroa.7.sroa.21, %b51 ], [ %v53_mem.sroa.8.sroa.14.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.7.sroa.41.sink = phi ptr [ %v33_mem.sroa.7.sroa.41, %b51 ], [ %v53_mem.sroa.8.sroa.24.0.v53_mem.sroa.8.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.9.sroa.21.sink = phi ptr [ %v33_mem.sroa.9.sroa.21, %b51 ], [ %v53_mem.sroa.9.sroa.14.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.9.sroa.41.sink = phi ptr [ %v33_mem.sroa.9.sroa.41, %b51 ], [ %v53_mem.sroa.9.sroa.24.0.v53_mem.sroa.9.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.11.sroa.21.sink = phi ptr [ %v33_mem.sroa.11.sroa.21, %b51 ], [ %v53_mem.sroa.10.sroa.14.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.11.sroa.41.sink = phi ptr [ %v33_mem.sroa.11.sroa.41, %b51 ], [ %v53_mem.sroa.10.sroa.24.0.v53_mem.sroa.10.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.13.sroa.21.sink = phi ptr [ %v33_mem.sroa.13.sroa.21, %b51 ], [ %v53_mem.sroa.11.sroa.14.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.13.sroa.41.sink = phi ptr [ %v33_mem.sroa.13.sroa.41, %b51 ], [ %v53_mem.sroa.11.sroa.24.0.v53_mem.sroa.11.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.15.sroa.21.sink = phi ptr [ %v33_mem.sroa.15.sroa.21, %b51 ], [ %v53_mem.sroa.12.sroa.14.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.15.sroa.41.sink = phi ptr [ %v33_mem.sroa.15.sroa.41, %b51 ], [ %v53_mem.sroa.12.sroa.24.0.v53_mem.sroa.12.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v33_mem.sroa.17.sroa.21.sink = phi ptr [ %v33_mem.sroa.17.sroa.21, %b51 ], [ %v53_mem.sroa.13.sroa.14.0.v53_mem.sroa.13.0.v108_mem.sroa_idx.sroa_idx, %v101_ok ]
  %v109_mem.sroa.7.sroa.39.0 = phi i8 [ %v33_mem.sroa.7.sroa.39.0, %b51 ], [ %v109_next.sroa.16.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.37.0 = phi i8 [ %v33_mem.sroa.7.sroa.37.0, %b51 ], [ %v109_next.sroa.16.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.35.0 = phi i32 [ %v33_mem.sroa.7.sroa.35.0, %b51 ], [ %v109_next.sroa.16.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.33.0 = phi i32 [ %v33_mem.sroa.7.sroa.33.0, %b51 ], [ %v109_next.sroa.16.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.29.0 = phi i8 [ %v33_mem.sroa.7.sroa.29.0, %b51 ], [ %v109_next.sroa.16.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.27.0 = phi i8 [ %v33_mem.sroa.7.sroa.27.0, %b51 ], [ %v109_next.sroa.16.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.25.0 = phi i32 [ %v33_mem.sroa.7.sroa.25.0, %b51 ], [ %v109_next.sroa.16.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.23.0 = phi i32 [ %v33_mem.sroa.7.sroa.23.0, %b51 ], [ %v109_next.sroa.16.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.19.0 = phi i8 [ %v33_mem.sroa.7.sroa.19.0, %b51 ], [ %v109_next.sroa.16.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.17.0 = phi i64 [ %v33_mem.sroa.7.sroa.17.0, %b51 ], [ %v109_next.sroa.16.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.15.0 = phi i64 [ %v33_mem.sroa.7.sroa.15.0, %b51 ], [ %v109_next.sroa.16.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.13.0 = phi i64 [ %v33_mem.sroa.7.sroa.13.0, %b51 ], [ %v109_next.sroa.16.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.11.0 = phi i32 [ %v33_mem.sroa.7.sroa.11.0, %b51 ], [ %v109_next.sroa.16.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.9.0 = phi i32 [ %v33_mem.sroa.7.sroa.9.0, %b51 ], [ %v109_next.sroa.16.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.7.0 = phi i64 [ %v33_mem.sroa.7.sroa.7.0, %b51 ], [ %v109_next.sroa.16.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.5.0 = phi i64 [ %v33_mem.sroa.7.sroa.5.0, %b51 ], [ %v109_next.sroa.16.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.3.0 = phi i64 [ %v33_mem.sroa.7.sroa.3.0, %b51 ], [ %v109_next.sroa.16.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.7.sroa.0.0 = phi i32 [ %v33_mem.sroa.7.sroa.0.0, %b51 ], [ %v109_next.sroa.16.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.0.0 = phi i32 [ %v33_mem.sroa.5.sroa.0.0, %b51 ], [ %v109_next.sroa.10.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.3.0 = phi i64 [ %v33_mem.sroa.5.sroa.3.0, %b51 ], [ %v109_next.sroa.10.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.5.0 = phi i64 [ %v33_mem.sroa.5.sroa.5.0, %b51 ], [ %v109_next.sroa.10.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.7.0 = phi i64 [ %v33_mem.sroa.5.sroa.7.0, %b51 ], [ %v109_next.sroa.10.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.9.0 = phi i32 [ %v33_mem.sroa.5.sroa.9.0, %b51 ], [ %v109_next.sroa.10.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.11.0 = phi i32 [ %v33_mem.sroa.5.sroa.11.0, %b51 ], [ %v109_next.sroa.10.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.13.0 = phi i64 [ %v33_mem.sroa.5.sroa.13.0, %b51 ], [ %v109_next.sroa.10.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.15.0 = phi i64 [ %v33_mem.sroa.5.sroa.15.0, %b51 ], [ %v109_next.sroa.10.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.17.0 = phi i64 [ %v33_mem.sroa.5.sroa.17.0, %b51 ], [ %v109_next.sroa.10.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.19.0 = phi i8 [ %v33_mem.sroa.5.sroa.19.0, %b51 ], [ %v109_next.sroa.10.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.23.0 = phi i32 [ %v33_mem.sroa.5.sroa.23.0, %b51 ], [ %v109_next.sroa.10.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.25.0 = phi i32 [ %v33_mem.sroa.5.sroa.25.0, %b51 ], [ %v109_next.sroa.10.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.27.0 = phi i8 [ %v33_mem.sroa.5.sroa.27.0, %b51 ], [ %v109_next.sroa.10.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.29.0 = phi i8 [ %v33_mem.sroa.5.sroa.29.0, %b51 ], [ %v109_next.sroa.10.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.33.0 = phi i32 [ %v33_mem.sroa.5.sroa.33.0, %b51 ], [ %v109_next.sroa.10.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.35.0 = phi i32 [ %v33_mem.sroa.5.sroa.35.0, %b51 ], [ %v109_next.sroa.10.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.37.0 = phi i8 [ %v33_mem.sroa.5.sroa.37.0, %b51 ], [ %v109_next.sroa.10.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.5.sroa.39.0 = phi i8 [ %v33_mem.sroa.5.sroa.39.0, %b51 ], [ %v109_next.sroa.10.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.39.0 = phi i8 [ %v33_mem.sroa.9.sroa.39.0, %b51 ], [ %v109_next.sroa.22.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.37.0 = phi i8 [ %v33_mem.sroa.9.sroa.37.0, %b51 ], [ %v109_next.sroa.22.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.35.0 = phi i32 [ %v33_mem.sroa.9.sroa.35.0, %b51 ], [ %v109_next.sroa.22.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.33.0 = phi i32 [ %v33_mem.sroa.9.sroa.33.0, %b51 ], [ %v109_next.sroa.22.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.29.0 = phi i8 [ %v33_mem.sroa.9.sroa.29.0, %b51 ], [ %v109_next.sroa.22.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.27.0 = phi i8 [ %v33_mem.sroa.9.sroa.27.0, %b51 ], [ %v109_next.sroa.22.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.25.0 = phi i32 [ %v33_mem.sroa.9.sroa.25.0, %b51 ], [ %v109_next.sroa.22.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.23.0 = phi i32 [ %v33_mem.sroa.9.sroa.23.0, %b51 ], [ %v109_next.sroa.22.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.19.0 = phi i8 [ %v33_mem.sroa.9.sroa.19.0, %b51 ], [ %v109_next.sroa.22.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.17.0 = phi i64 [ %v33_mem.sroa.9.sroa.17.0, %b51 ], [ %v109_next.sroa.22.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.15.0 = phi i64 [ %v33_mem.sroa.9.sroa.15.0, %b51 ], [ %v109_next.sroa.22.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.13.0 = phi i64 [ %v33_mem.sroa.9.sroa.13.0, %b51 ], [ %v109_next.sroa.22.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.11.0 = phi i32 [ %v33_mem.sroa.9.sroa.11.0, %b51 ], [ %v109_next.sroa.22.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.9.0 = phi i32 [ %v33_mem.sroa.9.sroa.9.0, %b51 ], [ %v109_next.sroa.22.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.7.0 = phi i64 [ %v33_mem.sroa.9.sroa.7.0, %b51 ], [ %v109_next.sroa.22.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.5.0 = phi i64 [ %v33_mem.sroa.9.sroa.5.0, %b51 ], [ %v109_next.sroa.22.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.3.0 = phi i64 [ %v33_mem.sroa.9.sroa.3.0, %b51 ], [ %v109_next.sroa.22.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.9.sroa.0.0 = phi i32 [ %v33_mem.sroa.9.sroa.0.0, %b51 ], [ %v109_next.sroa.22.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.39.0 = phi i8 [ %v33_mem.sroa.11.sroa.39.0, %b51 ], [ %v109_next.sroa.28.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.37.0 = phi i8 [ %v33_mem.sroa.11.sroa.37.0, %b51 ], [ %v109_next.sroa.28.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.35.0 = phi i32 [ %v33_mem.sroa.11.sroa.35.0, %b51 ], [ %v109_next.sroa.28.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.33.0 = phi i32 [ %v33_mem.sroa.11.sroa.33.0, %b51 ], [ %v109_next.sroa.28.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.29.0 = phi i8 [ %v33_mem.sroa.11.sroa.29.0, %b51 ], [ %v109_next.sroa.28.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.27.0 = phi i8 [ %v33_mem.sroa.11.sroa.27.0, %b51 ], [ %v109_next.sroa.28.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.25.0 = phi i32 [ %v33_mem.sroa.11.sroa.25.0, %b51 ], [ %v109_next.sroa.28.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.23.0 = phi i32 [ %v33_mem.sroa.11.sroa.23.0, %b51 ], [ %v109_next.sroa.28.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.19.0 = phi i8 [ %v33_mem.sroa.11.sroa.19.0, %b51 ], [ %v109_next.sroa.28.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.17.0 = phi i64 [ %v33_mem.sroa.11.sroa.17.0, %b51 ], [ %v109_next.sroa.28.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.15.0 = phi i64 [ %v33_mem.sroa.11.sroa.15.0, %b51 ], [ %v109_next.sroa.28.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.13.0 = phi i64 [ %v33_mem.sroa.11.sroa.13.0, %b51 ], [ %v109_next.sroa.28.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.11.0 = phi i32 [ %v33_mem.sroa.11.sroa.11.0, %b51 ], [ %v109_next.sroa.28.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.9.0 = phi i32 [ %v33_mem.sroa.11.sroa.9.0, %b51 ], [ %v109_next.sroa.28.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.7.0 = phi i64 [ %v33_mem.sroa.11.sroa.7.0, %b51 ], [ %v109_next.sroa.28.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.5.0 = phi i64 [ %v33_mem.sroa.11.sroa.5.0, %b51 ], [ %v109_next.sroa.28.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.3.0 = phi i64 [ %v33_mem.sroa.11.sroa.3.0, %b51 ], [ %v109_next.sroa.28.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.11.sroa.0.0 = phi i32 [ %v33_mem.sroa.11.sroa.0.0, %b51 ], [ %v109_next.sroa.28.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.39.0 = phi i8 [ %v33_mem.sroa.13.sroa.39.0, %b51 ], [ %v109_next.sroa.34.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.37.0 = phi i8 [ %v33_mem.sroa.13.sroa.37.0, %b51 ], [ %v109_next.sroa.34.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.35.0 = phi i32 [ %v33_mem.sroa.13.sroa.35.0, %b51 ], [ %v109_next.sroa.34.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.33.0 = phi i32 [ %v33_mem.sroa.13.sroa.33.0, %b51 ], [ %v109_next.sroa.34.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.29.0 = phi i8 [ %v33_mem.sroa.13.sroa.29.0, %b51 ], [ %v109_next.sroa.34.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.27.0 = phi i8 [ %v33_mem.sroa.13.sroa.27.0, %b51 ], [ %v109_next.sroa.34.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.25.0 = phi i32 [ %v33_mem.sroa.13.sroa.25.0, %b51 ], [ %v109_next.sroa.34.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.23.0 = phi i32 [ %v33_mem.sroa.13.sroa.23.0, %b51 ], [ %v109_next.sroa.34.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.19.0 = phi i8 [ %v33_mem.sroa.13.sroa.19.0, %b51 ], [ %v109_next.sroa.34.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.17.0 = phi i64 [ %v33_mem.sroa.13.sroa.17.0, %b51 ], [ %v109_next.sroa.34.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.15.0 = phi i64 [ %v33_mem.sroa.13.sroa.15.0, %b51 ], [ %v109_next.sroa.34.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.13.0 = phi i64 [ %v33_mem.sroa.13.sroa.13.0, %b51 ], [ %v109_next.sroa.34.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.11.0 = phi i32 [ %v33_mem.sroa.13.sroa.11.0, %b51 ], [ %v109_next.sroa.34.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.9.0 = phi i32 [ %v33_mem.sroa.13.sroa.9.0, %b51 ], [ %v109_next.sroa.34.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.7.0 = phi i64 [ %v33_mem.sroa.13.sroa.7.0, %b51 ], [ %v109_next.sroa.34.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.5.0 = phi i64 [ %v33_mem.sroa.13.sroa.5.0, %b51 ], [ %v109_next.sroa.34.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.3.0 = phi i64 [ %v33_mem.sroa.13.sroa.3.0, %b51 ], [ %v109_next.sroa.34.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.13.sroa.0.0 = phi i32 [ %v33_mem.sroa.13.sroa.0.0, %b51 ], [ %v109_next.sroa.34.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.39.0 = phi i8 [ %v33_mem.sroa.15.sroa.39.0, %b51 ], [ %v109_next.sroa.40.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.37.0 = phi i8 [ %v33_mem.sroa.15.sroa.37.0, %b51 ], [ %v109_next.sroa.40.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.35.0 = phi i32 [ %v33_mem.sroa.15.sroa.35.0, %b51 ], [ %v109_next.sroa.40.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.33.0 = phi i32 [ %v33_mem.sroa.15.sroa.33.0, %b51 ], [ %v109_next.sroa.40.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.29.0 = phi i8 [ %v33_mem.sroa.15.sroa.29.0, %b51 ], [ %v109_next.sroa.40.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.27.0 = phi i8 [ %v33_mem.sroa.15.sroa.27.0, %b51 ], [ %v109_next.sroa.40.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.25.0 = phi i32 [ %v33_mem.sroa.15.sroa.25.0, %b51 ], [ %v109_next.sroa.40.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.23.0 = phi i32 [ %v33_mem.sroa.15.sroa.23.0, %b51 ], [ %v109_next.sroa.40.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.19.0 = phi i8 [ %v33_mem.sroa.15.sroa.19.0, %b51 ], [ %v109_next.sroa.40.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.17.0 = phi i64 [ %v33_mem.sroa.15.sroa.17.0, %b51 ], [ %v109_next.sroa.40.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.15.0 = phi i64 [ %v33_mem.sroa.15.sroa.15.0, %b51 ], [ %v109_next.sroa.40.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.13.0 = phi i64 [ %v33_mem.sroa.15.sroa.13.0, %b51 ], [ %v109_next.sroa.40.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.11.0 = phi i32 [ %v33_mem.sroa.15.sroa.11.0, %b51 ], [ %v109_next.sroa.40.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.9.0 = phi i32 [ %v33_mem.sroa.15.sroa.9.0, %b51 ], [ %v109_next.sroa.40.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.7.0 = phi i64 [ %v33_mem.sroa.15.sroa.7.0, %b51 ], [ %v109_next.sroa.40.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.5.0 = phi i64 [ %v33_mem.sroa.15.sroa.5.0, %b51 ], [ %v109_next.sroa.40.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.3.0 = phi i64 [ %v33_mem.sroa.15.sroa.3.0, %b51 ], [ %v109_next.sroa.40.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.15.sroa.0.0 = phi i32 [ %v33_mem.sroa.15.sroa.0.0, %b51 ], [ %v109_next.sroa.40.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.39.0 = phi i8 [ %v33_mem.sroa.17.sroa.39.0, %b51 ], [ %v109_next.sroa.46.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.37.0 = phi i8 [ %v33_mem.sroa.17.sroa.37.0, %b51 ], [ %v109_next.sroa.46.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.35.0 = phi i32 [ %v33_mem.sroa.17.sroa.35.0, %b51 ], [ %v109_next.sroa.46.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.33.0 = phi i32 [ %v33_mem.sroa.17.sroa.33.0, %b51 ], [ %v109_next.sroa.46.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.29.0 = phi i8 [ %v33_mem.sroa.17.sroa.29.0, %b51 ], [ %v109_next.sroa.46.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.27.0 = phi i8 [ %v33_mem.sroa.17.sroa.27.0, %b51 ], [ %v109_next.sroa.46.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.25.0 = phi i32 [ %v33_mem.sroa.17.sroa.25.0, %b51 ], [ %v109_next.sroa.46.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.23.0 = phi i32 [ %v33_mem.sroa.17.sroa.23.0, %b51 ], [ %v109_next.sroa.46.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.19.0 = phi i8 [ %v33_mem.sroa.17.sroa.19.0, %b51 ], [ %v109_next.sroa.46.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.17.0 = phi i64 [ %v33_mem.sroa.17.sroa.17.0, %b51 ], [ %v109_next.sroa.46.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.15.0 = phi i64 [ %v33_mem.sroa.17.sroa.15.0, %b51 ], [ %v109_next.sroa.46.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.13.0 = phi i64 [ %v33_mem.sroa.17.sroa.13.0, %b51 ], [ %v109_next.sroa.46.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.11.0 = phi i32 [ %v33_mem.sroa.17.sroa.11.0, %b51 ], [ %v109_next.sroa.46.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.9.0 = phi i32 [ %v33_mem.sroa.17.sroa.9.0, %b51 ], [ %v109_next.sroa.46.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.7.0 = phi i64 [ %v33_mem.sroa.17.sroa.7.0, %b51 ], [ %v109_next.sroa.46.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.5.0 = phi i64 [ %v33_mem.sroa.17.sroa.5.0, %b51 ], [ %v109_next.sroa.46.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.3.0 = phi i64 [ %v33_mem.sroa.17.sroa.3.0, %b51 ], [ %v109_next.sroa.46.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.17.sroa.0.0 = phi i32 [ %v33_mem.sroa.17.sroa.0.0, %b51 ], [ %v109_next.sroa.46.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.0.0 = phi i32 [ %v33_mem.sroa.3.sroa.0.0, %b51 ], [ %v109_next.sroa.4.sroa.0.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.3.0 = phi i64 [ %v33_mem.sroa.3.sroa.3.0, %b51 ], [ %v109_next.sroa.4.sroa.4.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.5.0 = phi i64 [ %v33_mem.sroa.3.sroa.5.0, %b51 ], [ %v109_next.sroa.4.sroa.5.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.7.0 = phi i64 [ %v33_mem.sroa.3.sroa.7.0, %b51 ], [ %v109_next.sroa.4.sroa.6.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.9.0 = phi i32 [ %v33_mem.sroa.3.sroa.9.0, %b51 ], [ %v109_next.sroa.4.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.11.0 = phi i32 [ %v33_mem.sroa.3.sroa.11.0, %b51 ], [ %v109_next.sroa.4.sroa.8.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.13.0 = phi i64 [ %v33_mem.sroa.3.sroa.13.0, %b51 ], [ %v109_next.sroa.4.sroa.9.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.15.0 = phi i64 [ %v33_mem.sroa.3.sroa.15.0, %b51 ], [ %v109_next.sroa.4.sroa.10.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.17.0 = phi i64 [ %v33_mem.sroa.3.sroa.17.0, %b51 ], [ %v109_next.sroa.4.sroa.11.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.19.0 = phi i8 [ %v33_mem.sroa.3.sroa.19.0, %b51 ], [ %v109_next.sroa.4.sroa.12.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.23.0 = phi i32 [ %v33_mem.sroa.3.sroa.23.0, %b51 ], [ %v109_next.sroa.4.sroa.14.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.25.0 = phi i32 [ %v33_mem.sroa.3.sroa.25.0, %b51 ], [ %v109_next.sroa.4.sroa.15.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.27.0 = phi i8 [ %v33_mem.sroa.3.sroa.27.0, %b51 ], [ %v109_next.sroa.4.sroa.16.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.29.0 = phi i8 [ %v33_mem.sroa.3.sroa.29.0, %b51 ], [ %v109_next.sroa.4.sroa.17.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.33.0 = phi i32 [ %v33_mem.sroa.3.sroa.33.0, %b51 ], [ %v109_next.sroa.4.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.35.0 = phi i32 [ %v33_mem.sroa.3.sroa.35.0, %b51 ], [ %v109_next.sroa.4.sroa.20.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.37.0 = phi i8 [ %v33_mem.sroa.3.sroa.37.0, %b51 ], [ %v109_next.sroa.4.sroa.21.0.copyload, %v101_ok ]
  %v109_mem.sroa.3.sroa.39.0 = phi i8 [ %v33_mem.sroa.3.sroa.39.0, %b51 ], [ %v109_next.sroa.4.sroa.22.0.copyload, %v101_ok ]
  %v109_mem.sroa.16.0 = phi i32 [ %v33_mem.sroa.16.0, %b51 ], [ %v109_next.sroa.43.0.copyload, %v101_ok ]
  %v109_mem.sroa.14.0 = phi i32 [ %v33_mem.sroa.14.0, %b51 ], [ %v109_next.sroa.37.0.copyload, %v101_ok ]
  %v109_mem.sroa.12.0 = phi i32 [ %v33_mem.sroa.12.0, %b51 ], [ %v109_next.sroa.31.0.copyload, %v101_ok ]
  %v109_mem.sroa.10.0 = phi i32 [ %v33_mem.sroa.10.0, %b51 ], [ %v109_next.sroa.25.0.copyload, %v101_ok ]
  %v109_mem.sroa.8.0 = phi i32 [ %v33_mem.sroa.8.0, %b51 ], [ %v109_next.sroa.19.0.copyload, %v101_ok ]
  %v109_mem.sroa.6.0 = phi i32 [ %v33_mem.sroa.6.0, %b51 ], [ %v109_next.sroa.13.0.copyload, %v101_ok ]
  %v109_mem.sroa.4.0 = phi i32 [ %v33_mem.sroa.4.0, %b51 ], [ %v109_next.sroa.7.0.copyload, %v101_ok ]
  %v109_mem.sroa.0.0 = phi i32 [ %v33_mem.sroa.0.0, %b51 ], [ %v109_next.sroa.0.0.copyload, %v101_ok ]
  %v110 = phi i1 [ %not.p3, %b51 ], [ true, %v101_ok ]
  %v111 = phi i32 [ %.v562, %b51 ], [ %v49, %v101_ok ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.3.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.3.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.4.sroa.18.sroa.0.0, ptr %v109_mem.sroa.3.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.3.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.3.sroa.41.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.5.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.5.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.10.sroa.18.sroa.0.0, ptr %v109_mem.sroa.5.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.5.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.5.sroa.41.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.7.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.7.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.16.sroa.18.sroa.0.0, ptr %v109_mem.sroa.7.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.7.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.7.sroa.41.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.9.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.9.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.22.sroa.18.sroa.0.0, ptr %v109_mem.sroa.9.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.9.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.9.sroa.41.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.11.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.11.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.28.sroa.18.sroa.0.0, ptr %v109_mem.sroa.11.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.11.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.11.sroa.41.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.13.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.13.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.34.sroa.18.sroa.0.0, ptr %v109_mem.sroa.13.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.13.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.13.sroa.41.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.15.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.15.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.40.sroa.18.sroa.0.0, ptr %v109_mem.sroa.15.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.15.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.15.sroa.41.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v109_mem.sroa.17.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.17.sroa.21.sink, i64 3, i1 false)
  store i16 %v109_next.sroa.46.sroa.18.sroa.0.0, ptr %v109_mem.sroa.17.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v109_mem.sroa.17.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.17.sroa.41.sink4068, i64 6, i1 false)
  br label %b57_to_b58

b57_to_b58:                                       ; preds = %liza_liza_proxy.retry.exit125, %b56_to_b57
  %v33_mem.sroa.3.sroa.21.sink4100 = phi ptr [ %v33_mem.sroa.3.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.6.sroa.19.sink = phi ptr [ %v53_mem.sroa.6.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.3.sroa.41.sink4099 = phi ptr [ %v33_mem.sroa.3.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.41, %b56_to_b57 ]
  %v33_mem.sroa.5.sroa.21.sink4098 = phi ptr [ %v33_mem.sroa.5.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.7.sroa.19.sink = phi ptr [ %v53_mem.sroa.7.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.5.sroa.41.sink4097 = phi ptr [ %v33_mem.sroa.5.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.41, %b56_to_b57 ]
  %v33_mem.sroa.7.sroa.21.sink4096 = phi ptr [ %v33_mem.sroa.7.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.8.sroa.19.sink = phi ptr [ %v53_mem.sroa.8.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.7.sroa.41.sink4095 = phi ptr [ %v33_mem.sroa.7.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.41, %b56_to_b57 ]
  %v33_mem.sroa.9.sroa.21.sink4094 = phi ptr [ %v33_mem.sroa.9.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.9.sroa.19.sink = phi ptr [ %v53_mem.sroa.9.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.9.sroa.41.sink4093 = phi ptr [ %v33_mem.sroa.9.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.41, %b56_to_b57 ]
  %v33_mem.sroa.11.sroa.21.sink4092 = phi ptr [ %v33_mem.sroa.11.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.10.sroa.19.sink = phi ptr [ %v53_mem.sroa.10.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.11.sroa.41.sink4091 = phi ptr [ %v33_mem.sroa.11.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.41, %b56_to_b57 ]
  %v33_mem.sroa.13.sroa.21.sink4090 = phi ptr [ %v33_mem.sroa.13.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.11.sroa.19.sink = phi ptr [ %v53_mem.sroa.11.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.13.sroa.41.sink4089 = phi ptr [ %v33_mem.sroa.13.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.41, %b56_to_b57 ]
  %v33_mem.sroa.15.sroa.21.sink4088 = phi ptr [ %v33_mem.sroa.15.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.12.sroa.19.sink = phi ptr [ %v53_mem.sroa.12.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.15.sroa.41.sink4087 = phi ptr [ %v33_mem.sroa.15.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.41, %b56_to_b57 ]
  %v33_mem.sroa.17.sroa.21.sink4086 = phi ptr [ %v33_mem.sroa.17.sroa.21, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.21, %b56_to_b57 ]
  %v53_mem.sroa.13.sroa.19.sink = phi ptr [ %v53_mem.sroa.13.sroa.19, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.31, %b56_to_b57 ]
  %v33_mem.sroa.17.sroa.41.sink4085 = phi ptr [ %v33_mem.sroa.17.sroa.41, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.41, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.39.0 = phi i8 [ %v33_mem.sroa.7.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.37.0 = phi i8 [ %v33_mem.sroa.7.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.35.0 = phi i32 [ %v33_mem.sroa.7.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.33.0 = phi i32 [ %v33_mem.sroa.7.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.29.0 = phi i8 [ %v33_mem.sroa.7.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.27.0 = phi i8 [ %v33_mem.sroa.7.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.25.0 = phi i32 [ %v33_mem.sroa.7.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.23.0 = phi i32 [ %v33_mem.sroa.7.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.19.0 = phi i8 [ %v33_mem.sroa.7.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.17.0 = phi i64 [ %v33_mem.sroa.7.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.15.0 = phi i64 [ %v33_mem.sroa.7.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.13.0 = phi i64 [ %v33_mem.sroa.7.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.11.0 = phi i32 [ %v33_mem.sroa.7.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.9.0 = phi i32 [ %v33_mem.sroa.7.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.7.0 = phi i64 [ %v33_mem.sroa.7.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.5.0 = phi i64 [ %v33_mem.sroa.7.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.3.0 = phi i64 [ %v33_mem.sroa.7.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.7.sroa.0.0 = phi i32 [ %v33_mem.sroa.7.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.7.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.0.0 = phi i32 [ %v33_mem.sroa.5.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.39.0 = phi i8 [ %v33_mem.sroa.9.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.37.0 = phi i8 [ %v33_mem.sroa.9.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.35.0 = phi i32 [ %v33_mem.sroa.9.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.33.0 = phi i32 [ %v33_mem.sroa.9.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.29.0 = phi i8 [ %v33_mem.sroa.9.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.27.0 = phi i8 [ %v33_mem.sroa.9.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.25.0 = phi i32 [ %v33_mem.sroa.9.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.23.0 = phi i32 [ %v33_mem.sroa.9.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.19.0 = phi i8 [ %v33_mem.sroa.9.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.17.0 = phi i64 [ %v33_mem.sroa.9.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.15.0 = phi i64 [ %v33_mem.sroa.9.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.13.0 = phi i64 [ %v33_mem.sroa.9.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.11.0 = phi i32 [ %v33_mem.sroa.9.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.9.0 = phi i32 [ %v33_mem.sroa.9.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.7.0 = phi i64 [ %v33_mem.sroa.9.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.5.0 = phi i64 [ %v33_mem.sroa.9.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.3.0 = phi i64 [ %v33_mem.sroa.9.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.9.sroa.0.0 = phi i32 [ %v33_mem.sroa.9.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.9.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.3.0 = phi i64 [ %v33_mem.sroa.5.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.5.0 = phi i64 [ %v33_mem.sroa.5.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.7.0 = phi i64 [ %v33_mem.sroa.5.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.9.0 = phi i32 [ %v33_mem.sroa.5.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.11.0 = phi i32 [ %v33_mem.sroa.5.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.13.0 = phi i64 [ %v33_mem.sroa.5.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.15.0 = phi i64 [ %v33_mem.sroa.5.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.17.0 = phi i64 [ %v33_mem.sroa.5.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.19.0 = phi i8 [ %v33_mem.sroa.5.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.23.0 = phi i32 [ %v33_mem.sroa.5.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.25.0 = phi i32 [ %v33_mem.sroa.5.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.27.0 = phi i8 [ %v33_mem.sroa.5.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.29.0 = phi i8 [ %v33_mem.sroa.5.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.33.0 = phi i32 [ %v33_mem.sroa.5.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.35.0 = phi i32 [ %v33_mem.sroa.5.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.37.0 = phi i8 [ %v33_mem.sroa.5.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.5.sroa.39.0 = phi i8 [ %v33_mem.sroa.5.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.5.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.39.0 = phi i8 [ %v33_mem.sroa.11.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.37.0 = phi i8 [ %v33_mem.sroa.11.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.35.0 = phi i32 [ %v33_mem.sroa.11.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.33.0 = phi i32 [ %v33_mem.sroa.11.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.29.0 = phi i8 [ %v33_mem.sroa.11.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.27.0 = phi i8 [ %v33_mem.sroa.11.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.25.0 = phi i32 [ %v33_mem.sroa.11.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.23.0 = phi i32 [ %v33_mem.sroa.11.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.19.0 = phi i8 [ %v33_mem.sroa.11.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.17.0 = phi i64 [ %v33_mem.sroa.11.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.15.0 = phi i64 [ %v33_mem.sroa.11.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.13.0 = phi i64 [ %v33_mem.sroa.11.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.11.0 = phi i32 [ %v33_mem.sroa.11.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.9.0 = phi i32 [ %v33_mem.sroa.11.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.7.0 = phi i64 [ %v33_mem.sroa.11.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.5.0 = phi i64 [ %v33_mem.sroa.11.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.3.0 = phi i64 [ %v33_mem.sroa.11.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.11.sroa.0.0 = phi i32 [ %v33_mem.sroa.11.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.11.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.39.0 = phi i8 [ %v33_mem.sroa.13.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.37.0 = phi i8 [ %v33_mem.sroa.13.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.35.0 = phi i32 [ %v33_mem.sroa.13.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.33.0 = phi i32 [ %v33_mem.sroa.13.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.29.0 = phi i8 [ %v33_mem.sroa.13.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.27.0 = phi i8 [ %v33_mem.sroa.13.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.25.0 = phi i32 [ %v33_mem.sroa.13.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.23.0 = phi i32 [ %v33_mem.sroa.13.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.19.0 = phi i8 [ %v33_mem.sroa.13.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.17.0 = phi i64 [ %v33_mem.sroa.13.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.15.0 = phi i64 [ %v33_mem.sroa.13.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.13.0 = phi i64 [ %v33_mem.sroa.13.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.11.0 = phi i32 [ %v33_mem.sroa.13.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.9.0 = phi i32 [ %v33_mem.sroa.13.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.7.0 = phi i64 [ %v33_mem.sroa.13.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.5.0 = phi i64 [ %v33_mem.sroa.13.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.3.0 = phi i64 [ %v33_mem.sroa.13.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.13.sroa.0.0 = phi i32 [ %v33_mem.sroa.13.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.13.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.39.0 = phi i8 [ %v33_mem.sroa.15.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.37.0 = phi i8 [ %v33_mem.sroa.15.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.35.0 = phi i32 [ %v33_mem.sroa.15.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.33.0 = phi i32 [ %v33_mem.sroa.15.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.29.0 = phi i8 [ %v33_mem.sroa.15.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.27.0 = phi i8 [ %v33_mem.sroa.15.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.25.0 = phi i32 [ %v33_mem.sroa.15.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.23.0 = phi i32 [ %v33_mem.sroa.15.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.19.0 = phi i8 [ %v33_mem.sroa.15.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.17.0 = phi i64 [ %v33_mem.sroa.15.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.15.0 = phi i64 [ %v33_mem.sroa.15.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.13.0 = phi i64 [ %v33_mem.sroa.15.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.11.0 = phi i32 [ %v33_mem.sroa.15.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.9.0 = phi i32 [ %v33_mem.sroa.15.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.7.0 = phi i64 [ %v33_mem.sroa.15.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.5.0 = phi i64 [ %v33_mem.sroa.15.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.3.0 = phi i64 [ %v33_mem.sroa.15.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.15.sroa.0.0 = phi i32 [ %v33_mem.sroa.15.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.15.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.39.0 = phi i8 [ %v33_mem.sroa.17.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.37.0 = phi i8 [ %v33_mem.sroa.17.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.35.0 = phi i32 [ %v33_mem.sroa.17.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.33.0 = phi i32 [ %v33_mem.sroa.17.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.29.0 = phi i8 [ %v33_mem.sroa.17.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.27.0 = phi i8 [ %v33_mem.sroa.17.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.25.0 = phi i32 [ %v33_mem.sroa.17.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.23.0 = phi i32 [ %v33_mem.sroa.17.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.19.0 = phi i8 [ %v33_mem.sroa.17.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.17.0 = phi i64 [ %v33_mem.sroa.17.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.15.0 = phi i64 [ %v33_mem.sroa.17.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.13.0 = phi i64 [ %v33_mem.sroa.17.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.11.0 = phi i32 [ %v33_mem.sroa.17.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.9.0 = phi i32 [ %v33_mem.sroa.17.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.7.0 = phi i64 [ %v33_mem.sroa.17.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.5.0 = phi i64 [ %v33_mem.sroa.17.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.3.0 = phi i64 [ %v33_mem.sroa.17.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.17.sroa.0.0 = phi i32 [ %v33_mem.sroa.17.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.17.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.0.0 = phi i32 [ %v33_mem.sroa.3.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.0.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.3.0 = phi i64 [ %v33_mem.sroa.3.sroa.3.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.3.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.5.0 = phi i64 [ %v33_mem.sroa.3.sroa.5.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.5.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.7.0 = phi i64 [ %v33_mem.sroa.3.sroa.7.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.7.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.9.0 = phi i32 [ %v33_mem.sroa.3.sroa.9.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.9.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.11.0 = phi i32 [ %v33_mem.sroa.3.sroa.11.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.11.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.13.0 = phi i64 [ %v33_mem.sroa.3.sroa.13.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.13.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.15.0 = phi i64 [ %v33_mem.sroa.3.sroa.15.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.15.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.17.0 = phi i64 [ %v33_mem.sroa.3.sroa.17.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.17.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.19.0 = phi i8 [ %v33_mem.sroa.3.sroa.19.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.19.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.23.0 = phi i32 [ %v33_mem.sroa.3.sroa.23.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.23.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.25.0 = phi i32 [ %v33_mem.sroa.3.sroa.25.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.25.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.27.0 = phi i8 [ %v33_mem.sroa.3.sroa.27.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.27.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.29.0 = phi i8 [ %v33_mem.sroa.3.sroa.29.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.29.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.33.0 = phi i32 [ %v33_mem.sroa.3.sroa.33.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.33.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.35.0 = phi i32 [ %v33_mem.sroa.3.sroa.35.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.35.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.37.0 = phi i8 [ %v33_mem.sroa.3.sroa.37.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.37.0, %b56_to_b57 ]
  %v112_mem.sroa.3.sroa.39.0 = phi i8 [ %v33_mem.sroa.3.sroa.39.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.3.sroa.39.0, %b56_to_b57 ]
  %v112_mem.sroa.16.0 = phi i32 [ %v33_mem.sroa.16.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.16.0, %b56_to_b57 ]
  %v112_mem.sroa.14.0 = phi i32 [ %v33_mem.sroa.14.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.14.0, %b56_to_b57 ]
  %v112_mem.sroa.12.0 = phi i32 [ %v33_mem.sroa.12.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.12.0, %b56_to_b57 ]
  %v112_mem.sroa.10.0 = phi i32 [ %v33_mem.sroa.10.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.10.0, %b56_to_b57 ]
  %v112_mem.sroa.8.0 = phi i32 [ %v33_mem.sroa.8.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.8.0, %b56_to_b57 ]
  %v112_mem.sroa.6.0 = phi i32 [ %v33_mem.sroa.6.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.6.0, %b56_to_b57 ]
  %v112_mem.sroa.4.0 = phi i32 [ %v33_mem.sroa.4.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.4.0, %b56_to_b57 ]
  %v112_mem.sroa.0.0 = phi i32 [ %v33_mem.sroa.0.0, %liza_liza_proxy.retry.exit125 ], [ %v109_mem.sroa.0.0, %b56_to_b57 ]
  %v113 = phi i1 [ %common.ret.op.i123926, %liza_liza_proxy.retry.exit125 ], [ %v110, %b56_to_b57 ]
  %v114 = phi i1 [ %v351108, %liza_liza_proxy.retry.exit125 ], [ true, %b56_to_b57 ]
  %v115 = phi i32 [ %2, %liza_liza_proxy.retry.exit125 ], [ %v111, %b56_to_b57 ]
  %97 = load i16, ptr %v53_mem.sroa.6.sroa.19.sink, align 2
  %98 = load i16, ptr %v53_mem.sroa.7.sroa.19.sink, align 2
  %99 = load i16, ptr %v53_mem.sroa.8.sroa.19.sink, align 2
  %100 = load i16, ptr %v53_mem.sroa.9.sroa.19.sink, align 2
  %101 = load i16, ptr %v53_mem.sroa.10.sroa.19.sink, align 2
  %102 = load i16, ptr %v53_mem.sroa.11.sroa.19.sink, align 2
  %103 = load i16, ptr %v53_mem.sroa.12.sroa.19.sink, align 2
  %104 = load i16, ptr %v53_mem.sroa.13.sroa.19.sink, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.3.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.3.sroa.21.sink4100, i64 3, i1 false)
  store i16 %97, ptr %v112_mem.sroa.3.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.3.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.3.sroa.41.sink4099, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.5.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.5.sroa.21.sink4098, i64 3, i1 false)
  store i16 %98, ptr %v112_mem.sroa.5.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.5.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.5.sroa.41.sink4097, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.7.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.7.sroa.21.sink4096, i64 3, i1 false)
  store i16 %99, ptr %v112_mem.sroa.7.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.7.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.7.sroa.41.sink4095, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.9.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.9.sroa.21.sink4094, i64 3, i1 false)
  store i16 %100, ptr %v112_mem.sroa.9.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.9.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.9.sroa.41.sink4093, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.11.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.11.sroa.21.sink4092, i64 3, i1 false)
  store i16 %101, ptr %v112_mem.sroa.11.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.11.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.11.sroa.41.sink4091, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.13.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.13.sroa.21.sink4090, i64 3, i1 false)
  store i16 %102, ptr %v112_mem.sroa.13.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.13.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.13.sroa.41.sink4089, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.15.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.15.sroa.21.sink4088, i64 3, i1 false)
  store i16 %103, ptr %v112_mem.sroa.15.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.15.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.15.sroa.41.sink4087, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.17.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v33_mem.sroa.17.sroa.21.sink4086, i64 3, i1 false)
  store i16 %104, ptr %v112_mem.sroa.17.sroa.31, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.17.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v33_mem.sroa.17.sroa.41.sink4085, i64 6, i1 false)
  br label %b58_to_b59

b58_to_b59:                                       ; preds = %b22_to_b23, %b57_to_b58
  %v112_mem.sroa.3.sroa.21.sink4116 = phi ptr [ %v112_mem.sroa.3.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.3.sroa.31.sink = phi ptr [ %v112_mem.sroa.3.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.6.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.3.sroa.41.sink4115 = phi ptr [ %v112_mem.sroa.3.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.41, %b22_to_b23 ]
  %v112_mem.sroa.5.sroa.21.sink4114 = phi ptr [ %v112_mem.sroa.5.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.5.sroa.31.sink = phi ptr [ %v112_mem.sroa.5.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.7.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.5.sroa.41.sink4113 = phi ptr [ %v112_mem.sroa.5.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.41, %b22_to_b23 ]
  %v112_mem.sroa.7.sroa.21.sink4112 = phi ptr [ %v112_mem.sroa.7.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.7.sroa.31.sink = phi ptr [ %v112_mem.sroa.7.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.8.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.7.sroa.41.sink4111 = phi ptr [ %v112_mem.sroa.7.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.41, %b22_to_b23 ]
  %v112_mem.sroa.9.sroa.21.sink4110 = phi ptr [ %v112_mem.sroa.9.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.9.sroa.31.sink = phi ptr [ %v112_mem.sroa.9.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.9.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.9.sroa.41.sink4109 = phi ptr [ %v112_mem.sroa.9.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.41, %b22_to_b23 ]
  %v112_mem.sroa.11.sroa.21.sink4108 = phi ptr [ %v112_mem.sroa.11.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.11.sroa.31.sink = phi ptr [ %v112_mem.sroa.11.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.10.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.11.sroa.41.sink4107 = phi ptr [ %v112_mem.sroa.11.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.41, %b22_to_b23 ]
  %v112_mem.sroa.13.sroa.21.sink4106 = phi ptr [ %v112_mem.sroa.13.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.13.sroa.31.sink = phi ptr [ %v112_mem.sroa.13.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.11.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.13.sroa.41.sink4105 = phi ptr [ %v112_mem.sroa.13.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.41, %b22_to_b23 ]
  %v112_mem.sroa.15.sroa.21.sink4104 = phi ptr [ %v112_mem.sroa.15.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.15.sroa.31.sink = phi ptr [ %v112_mem.sroa.15.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.12.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.15.sroa.41.sink4103 = phi ptr [ %v112_mem.sroa.15.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.41, %b22_to_b23 ]
  %v112_mem.sroa.17.sroa.21.sink4102 = phi ptr [ %v112_mem.sroa.17.sroa.21, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.21, %b22_to_b23 ]
  %v112_mem.sroa.17.sroa.31.sink = phi ptr [ %v112_mem.sroa.17.sroa.31, %b57_to_b58 ], [ %v53_mem.sroa.13.sroa.19, %b22_to_b23 ]
  %v112_mem.sroa.17.sroa.41.sink4101 = phi ptr [ %v112_mem.sroa.17.sroa.41, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.41, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.39.0 = phi i8 [ %v112_mem.sroa.7.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.37.0 = phi i8 [ %v112_mem.sroa.7.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.35.0 = phi i32 [ %v112_mem.sroa.7.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.33.0 = phi i32 [ %v112_mem.sroa.7.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.29.0 = phi i8 [ %v112_mem.sroa.7.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.27.0 = phi i8 [ %v112_mem.sroa.7.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.25.0 = phi i32 [ %v112_mem.sroa.7.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.23.0 = phi i32 [ %v112_mem.sroa.7.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.19.0 = phi i8 [ %v112_mem.sroa.7.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.17.0 = phi i64 [ %v112_mem.sroa.7.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.15.0 = phi i64 [ %v112_mem.sroa.7.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.13.0 = phi i64 [ %v112_mem.sroa.7.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.11.0 = phi i32 [ %v112_mem.sroa.7.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.9.0 = phi i32 [ %v112_mem.sroa.7.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.7.0 = phi i64 [ %v112_mem.sroa.7.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.5.0 = phi i64 [ %v112_mem.sroa.7.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.3.0 = phi i64 [ %v112_mem.sroa.7.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.11.sroa.0.0 = phi i32 [ %v112_mem.sroa.7.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.7.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.39.0 = phi i8 [ %v112_mem.sroa.9.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.37.0 = phi i8 [ %v112_mem.sroa.9.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.35.0 = phi i32 [ %v112_mem.sroa.9.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.33.0 = phi i32 [ %v112_mem.sroa.9.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.29.0 = phi i8 [ %v112_mem.sroa.9.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.27.0 = phi i8 [ %v112_mem.sroa.9.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.25.0 = phi i32 [ %v112_mem.sroa.9.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.23.0 = phi i32 [ %v112_mem.sroa.9.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.19.0 = phi i8 [ %v112_mem.sroa.9.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.17.0 = phi i64 [ %v112_mem.sroa.9.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.15.0 = phi i64 [ %v112_mem.sroa.9.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.13.0 = phi i64 [ %v112_mem.sroa.9.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.11.0 = phi i32 [ %v112_mem.sroa.9.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.9.0 = phi i32 [ %v112_mem.sroa.9.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.7.0 = phi i64 [ %v112_mem.sroa.9.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.5.0 = phi i64 [ %v112_mem.sroa.9.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.3.0 = phi i64 [ %v112_mem.sroa.9.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.15.sroa.0.0 = phi i32 [ %v112_mem.sroa.9.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.9.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.0.0 = phi i32 [ %v112_mem.sroa.5.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.3.0 = phi i64 [ %v112_mem.sroa.5.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.39.0 = phi i8 [ %v112_mem.sroa.11.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.37.0 = phi i8 [ %v112_mem.sroa.11.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.35.0 = phi i32 [ %v112_mem.sroa.11.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.33.0 = phi i32 [ %v112_mem.sroa.11.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.29.0 = phi i8 [ %v112_mem.sroa.11.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.27.0 = phi i8 [ %v112_mem.sroa.11.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.25.0 = phi i32 [ %v112_mem.sroa.11.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.23.0 = phi i32 [ %v112_mem.sroa.11.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.19.0 = phi i8 [ %v112_mem.sroa.11.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.17.0 = phi i64 [ %v112_mem.sroa.11.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.15.0 = phi i64 [ %v112_mem.sroa.11.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.13.0 = phi i64 [ %v112_mem.sroa.11.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.11.0 = phi i32 [ %v112_mem.sroa.11.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.9.0 = phi i32 [ %v112_mem.sroa.11.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.7.0 = phi i64 [ %v112_mem.sroa.11.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.5.0 = phi i64 [ %v112_mem.sroa.11.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.3.0 = phi i64 [ %v112_mem.sroa.11.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.19.sroa.0.0 = phi i32 [ %v112_mem.sroa.11.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.11.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.5.0 = phi i64 [ %v112_mem.sroa.5.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.7.0 = phi i64 [ %v112_mem.sroa.5.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.9.0 = phi i32 [ %v112_mem.sroa.5.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.11.0 = phi i32 [ %v112_mem.sroa.5.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.13.0 = phi i64 [ %v112_mem.sroa.5.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.15.0 = phi i64 [ %v112_mem.sroa.5.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.17.0 = phi i64 [ %v112_mem.sroa.5.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.19.0 = phi i8 [ %v112_mem.sroa.5.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.23.0 = phi i32 [ %v112_mem.sroa.5.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.25.0 = phi i32 [ %v112_mem.sroa.5.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.27.0 = phi i8 [ %v112_mem.sroa.5.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.29.0 = phi i8 [ %v112_mem.sroa.5.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.33.0 = phi i32 [ %v112_mem.sroa.5.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.35.0 = phi i32 [ %v112_mem.sroa.5.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.37.0 = phi i8 [ %v112_mem.sroa.5.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.7.sroa.39.0 = phi i8 [ %v112_mem.sroa.5.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.5.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.39.0 = phi i8 [ %v112_mem.sroa.13.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.37.0 = phi i8 [ %v112_mem.sroa.13.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.35.0 = phi i32 [ %v112_mem.sroa.13.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.33.0 = phi i32 [ %v112_mem.sroa.13.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.29.0 = phi i8 [ %v112_mem.sroa.13.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.27.0 = phi i8 [ %v112_mem.sroa.13.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.25.0 = phi i32 [ %v112_mem.sroa.13.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.23.0 = phi i32 [ %v112_mem.sroa.13.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.19.0 = phi i8 [ %v112_mem.sroa.13.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.17.0 = phi i64 [ %v112_mem.sroa.13.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.15.0 = phi i64 [ %v112_mem.sroa.13.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.13.0 = phi i64 [ %v112_mem.sroa.13.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.11.0 = phi i32 [ %v112_mem.sroa.13.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.9.0 = phi i32 [ %v112_mem.sroa.13.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.7.0 = phi i64 [ %v112_mem.sroa.13.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.5.0 = phi i64 [ %v112_mem.sroa.13.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.3.0 = phi i64 [ %v112_mem.sroa.13.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.23.sroa.0.0 = phi i32 [ %v112_mem.sroa.13.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.13.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.39.0 = phi i8 [ %v112_mem.sroa.15.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.37.0 = phi i8 [ %v112_mem.sroa.15.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.35.0 = phi i32 [ %v112_mem.sroa.15.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.33.0 = phi i32 [ %v112_mem.sroa.15.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.29.0 = phi i8 [ %v112_mem.sroa.15.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.27.0 = phi i8 [ %v112_mem.sroa.15.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.25.0 = phi i32 [ %v112_mem.sroa.15.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.23.0 = phi i32 [ %v112_mem.sroa.15.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.19.0 = phi i8 [ %v112_mem.sroa.15.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.17.0 = phi i64 [ %v112_mem.sroa.15.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.15.0 = phi i64 [ %v112_mem.sroa.15.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.13.0 = phi i64 [ %v112_mem.sroa.15.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.11.0 = phi i32 [ %v112_mem.sroa.15.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.9.0 = phi i32 [ %v112_mem.sroa.15.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.7.0 = phi i64 [ %v112_mem.sroa.15.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.5.0 = phi i64 [ %v112_mem.sroa.15.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.3.0 = phi i64 [ %v112_mem.sroa.15.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.27.sroa.0.0 = phi i32 [ %v112_mem.sroa.15.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.15.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.39.0 = phi i8 [ %v112_mem.sroa.17.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.37.0 = phi i8 [ %v112_mem.sroa.17.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.35.0 = phi i32 [ %v112_mem.sroa.17.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.33.0 = phi i32 [ %v112_mem.sroa.17.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.29.0 = phi i8 [ %v112_mem.sroa.17.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.27.0 = phi i8 [ %v112_mem.sroa.17.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.25.0 = phi i32 [ %v112_mem.sroa.17.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.23.0 = phi i32 [ %v112_mem.sroa.17.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.19.0 = phi i8 [ %v112_mem.sroa.17.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.17.0 = phi i64 [ %v112_mem.sroa.17.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.15.0 = phi i64 [ %v112_mem.sroa.17.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.13.0 = phi i64 [ %v112_mem.sroa.17.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.11.0 = phi i32 [ %v112_mem.sroa.17.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.9.0 = phi i32 [ %v112_mem.sroa.17.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.7.0 = phi i64 [ %v112_mem.sroa.17.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.5.0 = phi i64 [ %v112_mem.sroa.17.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.3.0 = phi i64 [ %v112_mem.sroa.17.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.31.sroa.0.0 = phi i32 [ %v112_mem.sroa.17.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.17.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.0.0 = phi i32 [ %v112_mem.sroa.3.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.0.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.3.0 = phi i64 [ %v112_mem.sroa.3.sroa.3.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.3.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.5.0 = phi i64 [ %v112_mem.sroa.3.sroa.5.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.5.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.7.0 = phi i64 [ %v112_mem.sroa.3.sroa.7.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.7.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.9.0 = phi i32 [ %v112_mem.sroa.3.sroa.9.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.9.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.11.0 = phi i32 [ %v112_mem.sroa.3.sroa.11.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.11.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.13.0 = phi i64 [ %v112_mem.sroa.3.sroa.13.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.13.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.15.0 = phi i64 [ %v112_mem.sroa.3.sroa.15.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.15.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.17.0 = phi i64 [ %v112_mem.sroa.3.sroa.17.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.17.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.19.0 = phi i8 [ %v112_mem.sroa.3.sroa.19.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.19.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.23.0 = phi i32 [ %v112_mem.sroa.3.sroa.23.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.23.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.25.0 = phi i32 [ %v112_mem.sroa.3.sroa.25.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.25.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.27.0 = phi i8 [ %v112_mem.sroa.3.sroa.27.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.27.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.29.0 = phi i8 [ %v112_mem.sroa.3.sroa.29.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.29.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.33.0 = phi i32 [ %v112_mem.sroa.3.sroa.33.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.33.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.35.0 = phi i32 [ %v112_mem.sroa.3.sroa.35.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.35.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.37.0 = phi i8 [ %v112_mem.sroa.3.sroa.37.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.37.0, %b22_to_b23 ]
  %v116_mem.sroa.3.sroa.39.0 = phi i8 [ %v112_mem.sroa.3.sroa.39.0, %b57_to_b58 ], [ %v33_mem.sroa.3.sroa.39.0, %b22_to_b23 ]
  %v116_mem.sroa.29.0 = phi i32 [ %v112_mem.sroa.16.0, %b57_to_b58 ], [ %v33_mem.sroa.16.0, %b22_to_b23 ]
  %v116_mem.sroa.25.0 = phi i32 [ %v112_mem.sroa.14.0, %b57_to_b58 ], [ %v33_mem.sroa.14.0, %b22_to_b23 ]
  %v116_mem.sroa.21.0 = phi i32 [ %v112_mem.sroa.12.0, %b57_to_b58 ], [ %v33_mem.sroa.12.0, %b22_to_b23 ]
  %v116_mem.sroa.17.0 = phi i32 [ %v112_mem.sroa.10.0, %b57_to_b58 ], [ %v33_mem.sroa.10.0, %b22_to_b23 ]
  %v116_mem.sroa.13.0 = phi i32 [ %v112_mem.sroa.8.0, %b57_to_b58 ], [ %v33_mem.sroa.8.0, %b22_to_b23 ]
  %v116_mem.sroa.9.0 = phi i32 [ %v112_mem.sroa.6.0, %b57_to_b58 ], [ %v33_mem.sroa.6.0, %b22_to_b23 ]
  %v116_mem.sroa.5.0 = phi i32 [ %v112_mem.sroa.4.0, %b57_to_b58 ], [ %v33_mem.sroa.4.0, %b22_to_b23 ]
  %v116_mem.sroa.0.0 = phi i32 [ %v112_mem.sroa.0.0, %b57_to_b58 ], [ %v33_mem.sroa.0.0, %b22_to_b23 ]
  %v117 = phi i1 [ %v113, %b57_to_b58 ], [ %v48, %b22_to_b23 ]
  %v118 = phi i1 [ %v114, %b57_to_b58 ], [ %v351108, %b22_to_b23 ]
  %v119 = phi i32 [ %v115, %b57_to_b58 ], [ %v49, %b22_to_b23 ]
  %105 = load i16, ptr %v112_mem.sroa.3.sroa.31.sink, align 2
  %106 = load i16, ptr %v112_mem.sroa.5.sroa.31.sink, align 2
  %107 = load i16, ptr %v112_mem.sroa.7.sroa.31.sink, align 2
  %108 = load i16, ptr %v112_mem.sroa.9.sroa.31.sink, align 2
  %109 = load i16, ptr %v112_mem.sroa.11.sroa.31.sink, align 2
  %110 = load i16, ptr %v112_mem.sroa.13.sroa.31.sink, align 2
  %111 = load i16, ptr %v112_mem.sroa.15.sroa.31.sink, align 2
  %112 = load i16, ptr %v112_mem.sroa.17.sroa.31.sink, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.3.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.3.sroa.21.sink4116, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.3.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.3.sroa.41.sink4115, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.7.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.5.sroa.21.sink4114, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.7.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.5.sroa.41.sink4113, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.11.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.7.sroa.21.sink4112, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.11.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.7.sroa.41.sink4111, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.15.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.9.sroa.21.sink4110, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.15.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.9.sroa.41.sink4109, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.19.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.11.sroa.21.sink4108, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.19.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.11.sroa.41.sink4107, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.23.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.13.sroa.21.sink4106, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.23.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.13.sroa.41.sink4105, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.27.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.15.sroa.21.sink4104, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.27.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.15.sroa.41.sink4103, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.31.sroa.21, ptr noundef nonnull align 1 dereferenceable(3) %v112_mem.sroa.17.sroa.21.sink4102, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.31.sroa.41, ptr noundef nonnull align 2 dereferenceable(6) %v112_mem.sroa.17.sroa.41.sink4101, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.19.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.19.sroa.41, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.23.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.23.sroa.41, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.27.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.27.sroa.41, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.31.sroa.21, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.31.sroa.41, i64 6, i1 false)
  store i32 %v116_mem.sroa.0.0, ptr %v122_mem, align 8
  store i32 %v116_mem.sroa.3.sroa.0.0, ptr %v122_next.sroa.4.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.3.sroa.3.0, ptr %v122_next.sroa.4.sroa.4.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.3.sroa.5.0, ptr %v122_next.sroa.4.sroa.5.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.3.sroa.7.0, ptr %v122_next.sroa.4.sroa.6.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.3.sroa.9.0, ptr %v122_next.sroa.4.sroa.7.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.3.sroa.11.0, ptr %v122_next.sroa.4.sroa.8.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.3.sroa.13.0, ptr %v122_next.sroa.4.sroa.9.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.3.sroa.15.0, ptr %v122_next.sroa.4.sroa.10.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.3.sroa.17.0, ptr %v122_next.sroa.4.sroa.11.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.3.sroa.19.0, ptr %v122_next.sroa.4.sroa.12.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.4.sroa.13.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.3.sroa.21, i64 3, i1 false)
  store i32 %v116_mem.sroa.3.sroa.23.0, ptr %v122_next.sroa.4.sroa.14.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.3.sroa.25.0, ptr %v122_next.sroa.4.sroa.15.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.3.sroa.27.0, ptr %v122_next.sroa.4.sroa.16.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.3.sroa.29.0, ptr %v122_next.sroa.4.sroa.17.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %105, ptr %v122_next.sroa.4.sroa.18.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.3.sroa.33.0, ptr %v122_next.sroa.4.sroa.19.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.3.sroa.35.0, ptr %v122_next.sroa.4.sroa.20.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.3.sroa.37.0, ptr %v122_next.sroa.4.sroa.21.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.3.sroa.39.0, ptr %v122_next.sroa.4.sroa.22.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.4.sroa.23.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.3.sroa.41, i64 6, i1 false)
  store i32 %v116_mem.sroa.5.0, ptr %v122_next.sroa.5.0.v122_mem.sroa_idx, align 8
  store i32 %v116_mem.sroa.7.sroa.0.0, ptr %v122_next.sroa.6.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.7.sroa.3.0, ptr %v122_next.sroa.6.sroa.4.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.7.sroa.5.0, ptr %v122_next.sroa.6.sroa.5.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.7.sroa.7.0, ptr %v122_next.sroa.6.sroa.6.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.7.sroa.9.0, ptr %v122_next.sroa.6.sroa.7.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.7.sroa.11.0, ptr %v122_next.sroa.6.sroa.8.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.7.sroa.13.0, ptr %v122_next.sroa.6.sroa.9.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.7.sroa.15.0, ptr %v122_next.sroa.6.sroa.10.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.7.sroa.17.0, ptr %v122_next.sroa.6.sroa.11.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.7.sroa.19.0, ptr %v122_next.sroa.6.sroa.12.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.6.sroa.13.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.7.sroa.21, i64 3, i1 false)
  store i32 %v116_mem.sroa.7.sroa.23.0, ptr %v122_next.sroa.6.sroa.14.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.7.sroa.25.0, ptr %v122_next.sroa.6.sroa.15.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.7.sroa.27.0, ptr %v122_next.sroa.6.sroa.16.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.7.sroa.29.0, ptr %v122_next.sroa.6.sroa.17.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %106, ptr %v122_next.sroa.6.sroa.18.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.7.sroa.33.0, ptr %v122_next.sroa.6.sroa.19.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.7.sroa.35.0, ptr %v122_next.sroa.6.sroa.20.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.7.sroa.37.0, ptr %v122_next.sroa.6.sroa.21.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.7.sroa.39.0, ptr %v122_next.sroa.6.sroa.22.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.6.sroa.23.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.7.sroa.41, i64 6, i1 false)
  store i32 %v116_mem.sroa.9.0, ptr %v122_next.sroa.7.0.v122_mem.sroa_idx, align 8
  store i32 %v116_mem.sroa.11.sroa.0.0, ptr %v122_next.sroa.8.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.11.sroa.3.0, ptr %v122_next.sroa.8.sroa.4.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.11.sroa.5.0, ptr %v122_next.sroa.8.sroa.5.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.11.sroa.7.0, ptr %v122_next.sroa.8.sroa.6.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.11.sroa.9.0, ptr %v122_next.sroa.8.sroa.7.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.11.sroa.11.0, ptr %v122_next.sroa.8.sroa.8.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.11.sroa.13.0, ptr %v122_next.sroa.8.sroa.9.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.11.sroa.15.0, ptr %v122_next.sroa.8.sroa.10.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.11.sroa.17.0, ptr %v122_next.sroa.8.sroa.11.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.11.sroa.19.0, ptr %v122_next.sroa.8.sroa.12.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.8.sroa.13.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.11.sroa.21, i64 3, i1 false)
  store i32 %v116_mem.sroa.11.sroa.23.0, ptr %v122_next.sroa.8.sroa.14.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.11.sroa.25.0, ptr %v122_next.sroa.8.sroa.15.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.11.sroa.27.0, ptr %v122_next.sroa.8.sroa.16.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.11.sroa.29.0, ptr %v122_next.sroa.8.sroa.17.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %107, ptr %v122_next.sroa.8.sroa.18.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.11.sroa.33.0, ptr %v122_next.sroa.8.sroa.19.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.11.sroa.35.0, ptr %v122_next.sroa.8.sroa.20.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.11.sroa.37.0, ptr %v122_next.sroa.8.sroa.21.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.11.sroa.39.0, ptr %v122_next.sroa.8.sroa.22.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.8.sroa.23.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.11.sroa.41, i64 6, i1 false)
  store i32 %v116_mem.sroa.13.0, ptr %v122_next.sroa.9.0.v122_mem.sroa_idx, align 8
  store i32 %v116_mem.sroa.15.sroa.0.0, ptr %v122_next.sroa.10.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.15.sroa.3.0, ptr %v122_next.sroa.10.sroa.4.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.15.sroa.5.0, ptr %v122_next.sroa.10.sroa.5.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.15.sroa.7.0, ptr %v122_next.sroa.10.sroa.6.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.15.sroa.9.0, ptr %v122_next.sroa.10.sroa.7.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.15.sroa.11.0, ptr %v122_next.sroa.10.sroa.8.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.15.sroa.13.0, ptr %v122_next.sroa.10.sroa.9.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.15.sroa.15.0, ptr %v122_next.sroa.10.sroa.10.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.15.sroa.17.0, ptr %v122_next.sroa.10.sroa.11.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.15.sroa.19.0, ptr %v122_next.sroa.10.sroa.12.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.10.sroa.13.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v116_mem.sroa.15.sroa.21, i64 3, i1 false)
  store i32 %v116_mem.sroa.15.sroa.23.0, ptr %v122_next.sroa.10.sroa.14.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.15.sroa.25.0, ptr %v122_next.sroa.10.sroa.15.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.15.sroa.27.0, ptr %v122_next.sroa.10.sroa.16.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.15.sroa.29.0, ptr %v122_next.sroa.10.sroa.17.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %108, ptr %v122_next.sroa.10.sroa.18.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.15.sroa.33.0, ptr %v122_next.sroa.10.sroa.19.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.15.sroa.35.0, ptr %v122_next.sroa.10.sroa.20.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.15.sroa.37.0, ptr %v122_next.sroa.10.sroa.21.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.15.sroa.39.0, ptr %v122_next.sroa.10.sroa.22.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.10.sroa.23.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v116_mem.sroa.15.sroa.41, i64 6, i1 false)
  store i32 %v116_mem.sroa.17.0, ptr %v122_next.sroa.11.0.v122_mem.sroa_idx, align 8
  store i32 %v116_mem.sroa.19.sroa.0.0, ptr %v122_next.sroa.12.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.19.sroa.3.0, ptr %v122_next.sroa.12.sroa.4.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.19.sroa.5.0, ptr %v122_next.sroa.12.sroa.5.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.19.sroa.7.0, ptr %v122_next.sroa.12.sroa.6.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.19.sroa.9.0, ptr %v122_next.sroa.12.sroa.7.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.19.sroa.11.0, ptr %v122_next.sroa.12.sroa.8.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.19.sroa.13.0, ptr %v122_next.sroa.12.sroa.9.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.19.sroa.15.0, ptr %v122_next.sroa.12.sroa.10.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.19.sroa.17.0, ptr %v122_next.sroa.12.sroa.11.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.19.sroa.19.0, ptr %v122_next.sroa.12.sroa.12.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13, i64 3, i1 false)
  store i32 %v116_mem.sroa.19.sroa.23.0, ptr %v122_next.sroa.12.sroa.14.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.19.sroa.25.0, ptr %v122_next.sroa.12.sroa.15.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.19.sroa.27.0, ptr %v122_next.sroa.12.sroa.16.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.19.sroa.29.0, ptr %v122_next.sroa.12.sroa.17.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %109, ptr %v122_next.sroa.12.sroa.18.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.19.sroa.33.0, ptr %v122_next.sroa.12.sroa.19.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.19.sroa.35.0, ptr %v122_next.sroa.12.sroa.20.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.19.sroa.37.0, ptr %v122_next.sroa.12.sroa.21.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.19.sroa.39.0, ptr %v122_next.sroa.12.sroa.22.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23, i64 6, i1 false)
  store i32 %v116_mem.sroa.21.0, ptr %v122_next.sroa.13.0.v122_mem.sroa_idx, align 8
  store i32 %v116_mem.sroa.23.sroa.0.0, ptr %v122_next.sroa.14.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.23.sroa.3.0, ptr %v122_next.sroa.14.sroa.4.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.23.sroa.5.0, ptr %v122_next.sroa.14.sroa.5.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.23.sroa.7.0, ptr %v122_next.sroa.14.sroa.6.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.23.sroa.9.0, ptr %v122_next.sroa.14.sroa.7.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.23.sroa.11.0, ptr %v122_next.sroa.14.sroa.8.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.23.sroa.13.0, ptr %v122_next.sroa.14.sroa.9.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.23.sroa.15.0, ptr %v122_next.sroa.14.sroa.10.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.23.sroa.17.0, ptr %v122_next.sroa.14.sroa.11.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.23.sroa.19.0, ptr %v122_next.sroa.14.sroa.12.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13, i64 3, i1 false)
  store i32 %v116_mem.sroa.23.sroa.23.0, ptr %v122_next.sroa.14.sroa.14.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.23.sroa.25.0, ptr %v122_next.sroa.14.sroa.15.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.23.sroa.27.0, ptr %v122_next.sroa.14.sroa.16.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.23.sroa.29.0, ptr %v122_next.sroa.14.sroa.17.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %110, ptr %v122_next.sroa.14.sroa.18.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.23.sroa.33.0, ptr %v122_next.sroa.14.sroa.19.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.23.sroa.35.0, ptr %v122_next.sroa.14.sroa.20.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.23.sroa.37.0, ptr %v122_next.sroa.14.sroa.21.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.23.sroa.39.0, ptr %v122_next.sroa.14.sroa.22.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23, i64 6, i1 false)
  store i32 %v116_mem.sroa.25.0, ptr %v122_next.sroa.15.0.v122_mem.sroa_idx, align 8
  store i32 %v116_mem.sroa.27.sroa.0.0, ptr %v122_next.sroa.16.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.27.sroa.3.0, ptr %v122_next.sroa.16.sroa.4.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.27.sroa.5.0, ptr %v122_next.sroa.16.sroa.5.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.27.sroa.7.0, ptr %v122_next.sroa.16.sroa.6.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.27.sroa.9.0, ptr %v122_next.sroa.16.sroa.7.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.27.sroa.11.0, ptr %v122_next.sroa.16.sroa.8.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.27.sroa.13.0, ptr %v122_next.sroa.16.sroa.9.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.27.sroa.15.0, ptr %v122_next.sroa.16.sroa.10.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.27.sroa.17.0, ptr %v122_next.sroa.16.sroa.11.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.27.sroa.19.0, ptr %v122_next.sroa.16.sroa.12.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13, i64 3, i1 false)
  store i32 %v116_mem.sroa.27.sroa.23.0, ptr %v122_next.sroa.16.sroa.14.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.27.sroa.25.0, ptr %v122_next.sroa.16.sroa.15.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.27.sroa.27.0, ptr %v122_next.sroa.16.sroa.16.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.27.sroa.29.0, ptr %v122_next.sroa.16.sroa.17.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %111, ptr %v122_next.sroa.16.sroa.18.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.27.sroa.33.0, ptr %v122_next.sroa.16.sroa.19.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.27.sroa.35.0, ptr %v122_next.sroa.16.sroa.20.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.27.sroa.37.0, ptr %v122_next.sroa.16.sroa.21.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.27.sroa.39.0, ptr %v122_next.sroa.16.sroa.22.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23, i64 6, i1 false)
  store i32 %v116_mem.sroa.29.0, ptr %v122_next.sroa.17.0.v122_mem.sroa_idx, align 8
  store i32 %v116_mem.sroa.31.sroa.0.0, ptr %v122_next.sroa.18.0.v122_mem.sroa_idx, align 4
  store i64 %v116_mem.sroa.31.sroa.3.0, ptr %v122_next.sroa.18.sroa.4.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.31.sroa.5.0, ptr %v122_next.sroa.18.sroa.5.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.31.sroa.7.0, ptr %v122_next.sroa.18.sroa.6.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.31.sroa.9.0, ptr %v122_next.sroa.18.sroa.7.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.31.sroa.11.0, ptr %v122_next.sroa.18.sroa.8.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v116_mem.sroa.31.sroa.13.0, ptr %v122_next.sroa.18.sroa.9.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.31.sroa.15.0, ptr %v122_next.sroa.18.sroa.10.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v116_mem.sroa.31.sroa.17.0, ptr %v122_next.sroa.18.sroa.11.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.31.sroa.19.0, ptr %v122_next.sroa.18.sroa.12.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13, i64 3, i1 false)
  store i32 %v116_mem.sroa.31.sroa.23.0, ptr %v122_next.sroa.18.sroa.14.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i32 %v116_mem.sroa.31.sroa.25.0, ptr %v122_next.sroa.18.sroa.15.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.31.sroa.27.0, ptr %v122_next.sroa.18.sroa.16.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.31.sroa.29.0, ptr %v122_next.sroa.18.sroa.17.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %112, ptr %v122_next.sroa.18.sroa.18.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v116_mem.sroa.31.sroa.33.0, ptr %v122_next.sroa.18.sroa.19.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v116_mem.sroa.31.sroa.35.0, ptr %v122_next.sroa.18.sroa.20.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v116_mem.sroa.31.sroa.37.0, ptr %v122_next.sroa.18.sroa.21.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v116_mem.sroa.31.sroa.39.0, ptr %v122_next.sroa.18.sroa.22.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23, i64 6, i1 false)
  br i1 %v117, label %v132_ok, label %b58_to_b59.b61_to_b13_crit_edge

b58_to_b59.b61_to_b13_crit_edge:                  ; preds = %b58_to_b59
  %v33_next.sroa.16.sroa.16.0.copyload.pre = load i8, ptr %v122_next.sroa.10.sroa.16.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.16.sroa.17.0.copyload.pre = load i8, ptr %v122_next.sroa.10.sroa.17.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  %v33_next.sroa.16.sroa.19.0.copyload.pre = load i32, ptr %v122_next.sroa.10.sroa.19.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.20.0.copyload.pre = load i32, ptr %v122_next.sroa.10.sroa.20.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.16.sroa.21.0.copyload.pre = load i8, ptr %v122_next.sroa.10.sroa.21.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.16.sroa.22.0.copyload.pre = load i8, ptr %v122_next.sroa.10.sroa.22.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  %v33_next.sroa.18.0.copyload1328.pre = load i32, ptr %v122_next.sroa.11.0.v122_mem.sroa_idx, align 8
  %v33_next.sroa.20.sroa.0.0.copyload.pre = load i32, ptr %v122_next.sroa.12.0.v122_mem.sroa_idx, align 4
  %v33_next.sroa.20.sroa.4.0.copyload.pre = load i64, ptr %v122_next.sroa.12.sroa.4.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.5.0.copyload.pre = load i64, ptr %v122_next.sroa.12.sroa.5.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.6.0.copyload.pre = load i64, ptr %v122_next.sroa.12.sroa.6.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.7.0.copyload.pre = load i32, ptr %v122_next.sroa.12.sroa.7.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.8.0.copyload.pre = load i32, ptr %v122_next.sroa.12.sroa.8.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v33_next.sroa.20.sroa.9.0.copyload.pre = load i64, ptr %v122_next.sroa.12.sroa.9.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.10.0.copyload.pre = load i64, ptr %v122_next.sroa.12.sroa.10.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v33_next.sroa.20.sroa.11.0.copyload.pre = load i64, ptr %v122_next.sroa.12.sroa.11.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  br label %b61_to_b13

b274_to_b59:                                      ; preds = %b66_to_b274, %v554_ok
  %v558_next.sroa.4.sroa.32.sroa.0.0 = phi i16 [ %160, %b66_to_b274 ], [ %36, %v554_ok ]
  %v558_next.sroa.8.sroa.32.sroa.0.0 = phi i16 [ %167, %b66_to_b274 ], [ %43, %v554_ok ]
  %v558_next.sroa.12.sroa.32.sroa.0.0 = phi i16 [ %174, %b66_to_b274 ], [ %50, %v554_ok ]
  %v558_next.sroa.16.sroa.32.sroa.0.0 = phi i16 [ %181, %b66_to_b274 ], [ %57, %v554_ok ]
  %v558_next.sroa.20.sroa.32.sroa.0.0 = phi i16 [ %183, %b66_to_b274 ], [ %59, %v554_ok ]
  %v558_next.sroa.24.sroa.32.sroa.0.0 = phi i16 [ %190, %b66_to_b274 ], [ %66, %v554_ok ]
  %v558_next.sroa.28.sroa.32.sroa.0.0 = phi i16 [ %197, %b66_to_b274 ], [ %73, %v554_ok ]
  %v558_next.sroa.32.sroa.32.sroa.0.0 = phi i16 [ %204, %b66_to_b274 ], [ %80, %v554_ok ]
  %v122_next.sroa.18.sroa.23.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx.sink4117 = phi ptr [ %v122_next.sroa.18.sroa.23.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.42.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.4.sroa.13.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.4.sroa.13.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.22.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.4.sroa.23.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.4.sroa.23.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.42.0.v558_next.sroa.4.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.6.sroa.13.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.6.sroa.13.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.22.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.6.sroa.23.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.6.sroa.23.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.42.0.v558_next.sroa.8.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.8.sroa.13.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.8.sroa.13.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.22.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.8.sroa.23.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.8.sroa.23.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.42.0.v558_next.sroa.12.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.10.sroa.13.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.10.sroa.13.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.22.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.10.sroa.23.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.10.sroa.23.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.42.0.v558_next.sroa.16.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.12.sroa.13.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.12.sroa.13.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.22.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.12.sroa.23.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.12.sroa.23.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.42.0.v558_next.sroa.20.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.14.sroa.13.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.14.sroa.13.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.22.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.14.sroa.23.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.14.sroa.23.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.42.0.v558_next.sroa.24.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.16.sroa.13.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.16.sroa.13.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.22.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.16.sroa.23.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.16.sroa.23.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.42.0.v558_next.sroa.28.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v122_next.sroa.18.sroa.13.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx.sink = phi ptr [ %v122_next.sroa.18.sroa.13.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.22.0.v558_next.sroa.32.0.v556_mem.sroa_idx.sroa_idx, %v554_ok ]
  %v558_mem.sroa.7.sroa.21.0 = phi i8 [ %v558_next.sroa.12.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.40.0.copyload3366, %v554_ok ]
  %v558_mem.sroa.7.sroa.20.0 = phi i8 [ %v558_next.sroa.12.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.38.0.copyload3365, %v554_ok ]
  %v558_mem.sroa.7.sroa.16.0 = phi i8 [ %v558_next.sroa.12.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.30.0.copyload3362, %v554_ok ]
  %v558_mem.sroa.7.sroa.15.0 = phi i8 [ %v558_next.sroa.12.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.28.0.copyload3361, %v554_ok ]
  %v558_mem.sroa.7.sroa.11.0 = phi i8 [ %v558_next.sroa.12.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.20.0.copyload3358, %v554_ok ]
  %v558_mem.sroa.7.sroa.10.0 = phi i64 [ %v558_next.sroa.12.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.18.0.copyload3357, %v554_ok ]
  %v558_mem.sroa.7.sroa.5.0 = phi i64 [ %v558_next.sroa.12.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.12.sroa.8.0.copyload3352, %v554_ok ]
  %v558_mem.sroa.9.sroa.21.0 = phi i8 [ %v558_next.sroa.16.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.40.0.copyload3032, %v554_ok ]
  %v558_mem.sroa.9.sroa.20.0 = phi i8 [ %v558_next.sroa.16.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.38.0.copyload3031, %v554_ok ]
  %v558_mem.sroa.9.sroa.19.0 = phi i32 [ %v558_next.sroa.16.sroa.36.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.36.0.copyload3030, %v554_ok ]
  %v558_mem.sroa.9.sroa.18.0 = phi i32 [ %v558_next.sroa.16.sroa.34.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.34.0.copyload3029, %v554_ok ]
  %v558_mem.sroa.9.sroa.16.0 = phi i8 [ %v558_next.sroa.16.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.30.0.copyload3028, %v554_ok ]
  %v558_mem.sroa.9.sroa.15.0 = phi i8 [ %v558_next.sroa.16.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.28.0.copyload3027, %v554_ok ]
  %v558_mem.sroa.9.sroa.11.0 = phi i8 [ %v558_next.sroa.16.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.20.0.copyload3024, %v554_ok ]
  %v558_mem.sroa.9.sroa.10.0 = phi i64 [ %v558_next.sroa.16.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.18.0.copyload3023, %v554_ok ]
  %v558_mem.sroa.9.sroa.5.0 = phi i64 [ %v558_next.sroa.16.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.16.sroa.8.0.copyload3018, %v554_ok ]
  %v558_mem.sroa.11.sroa.21.0 = phi i8 [ %v558_next.sroa.20.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.40.0.copyload2698, %v554_ok ]
  %v558_mem.sroa.11.sroa.20.0 = phi i8 [ %v558_next.sroa.20.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.38.0.copyload2697, %v554_ok ]
  %v558_mem.sroa.11.sroa.16.0 = phi i8 [ %v558_next.sroa.20.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.30.0.copyload2694, %v554_ok ]
  %v558_mem.sroa.11.sroa.15.0 = phi i8 [ %v558_next.sroa.20.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.28.0.copyload2693, %v554_ok ]
  %v558_mem.sroa.11.sroa.11.0 = phi i8 [ %v558_next.sroa.20.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.20.0.copyload2690, %v554_ok ]
  %v558_mem.sroa.11.sroa.10.0 = phi i64 [ %v558_next.sroa.20.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.18.0.copyload2689, %v554_ok ]
  %v558_mem.sroa.11.sroa.9.0 = phi i64 [ %v558_next.sroa.20.sroa.16.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.16.0.copyload2688, %v554_ok ]
  %v558_mem.sroa.11.sroa.8.0 = phi i64 [ %v558_next.sroa.20.sroa.14.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.14.0.copyload2687, %v554_ok ]
  %v558_mem.sroa.11.sroa.7.0 = phi i32 [ %v558_next.sroa.20.sroa.12.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.12.0.copyload2686, %v554_ok ]
  %v558_mem.sroa.11.sroa.6.0 = phi i32 [ %v558_next.sroa.20.sroa.10.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.10.0.copyload2685, %v554_ok ]
  %v558_mem.sroa.11.sroa.5.0 = phi i64 [ %v558_next.sroa.20.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.8.0.copyload2684, %v554_ok ]
  %v558_mem.sroa.11.sroa.4.0 = phi i64 [ %v558_next.sroa.20.sroa.6.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.6.0.copyload2683, %v554_ok ]
  %v558_mem.sroa.11.sroa.3.0 = phi i64 [ %v558_next.sroa.20.sroa.4.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.4.0.copyload2682, %v554_ok ]
  %v558_mem.sroa.11.sroa.0.0 = phi i32 [ %v558_next.sroa.20.sroa.0.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.20.sroa.0.0.copyload2681, %v554_ok ]
  %v558_mem.sroa.13.sroa.21.0 = phi i8 [ %v558_next.sroa.24.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.40.0.copyload2364, %v554_ok ]
  %v558_mem.sroa.13.sroa.20.0 = phi i8 [ %v558_next.sroa.24.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.38.0.copyload2363, %v554_ok ]
  %v558_mem.sroa.13.sroa.16.0 = phi i8 [ %v558_next.sroa.24.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.30.0.copyload2360, %v554_ok ]
  %v558_mem.sroa.13.sroa.15.0 = phi i8 [ %v558_next.sroa.24.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.28.0.copyload2359, %v554_ok ]
  %v558_mem.sroa.13.sroa.11.0 = phi i8 [ %v558_next.sroa.24.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.20.0.copyload2356, %v554_ok ]
  %v558_mem.sroa.13.sroa.10.0 = phi i64 [ %v558_next.sroa.24.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.18.0.copyload2355, %v554_ok ]
  %v558_mem.sroa.13.sroa.5.0 = phi i64 [ %v558_next.sroa.24.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.24.sroa.8.0.copyload2350, %v554_ok ]
  %v558_mem.sroa.5.sroa.5.0 = phi i64 [ %v558_next.sroa.8.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.8.0.copyload3686, %v554_ok ]
  %v558_mem.sroa.5.sroa.10.0 = phi i64 [ %v558_next.sroa.8.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.18.0.copyload3691, %v554_ok ]
  %v558_mem.sroa.5.sroa.11.0 = phi i8 [ %v558_next.sroa.8.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.20.0.copyload3692, %v554_ok ]
  %v558_mem.sroa.5.sroa.15.0 = phi i8 [ %v558_next.sroa.8.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.28.0.copyload3695, %v554_ok ]
  %v558_mem.sroa.5.sroa.16.0 = phi i8 [ %v558_next.sroa.8.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.30.0.copyload3696, %v554_ok ]
  %v558_mem.sroa.5.sroa.20.0 = phi i8 [ %v558_next.sroa.8.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.38.0.copyload3699, %v554_ok ]
  %v558_mem.sroa.5.sroa.21.0 = phi i8 [ %v558_next.sroa.8.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.8.sroa.40.0.copyload3700, %v554_ok ]
  %v558_mem.sroa.15.sroa.21.0 = phi i8 [ %v558_next.sroa.28.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.40.0.copyload2030, %v554_ok ]
  %v558_mem.sroa.15.sroa.20.0 = phi i8 [ %v558_next.sroa.28.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.38.0.copyload2029, %v554_ok ]
  %v558_mem.sroa.15.sroa.16.0 = phi i8 [ %v558_next.sroa.28.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.30.0.copyload2026, %v554_ok ]
  %v558_mem.sroa.15.sroa.15.0 = phi i8 [ %v558_next.sroa.28.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.28.0.copyload2025, %v554_ok ]
  %v558_mem.sroa.15.sroa.11.0 = phi i8 [ %v558_next.sroa.28.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.20.0.copyload2022, %v554_ok ]
  %v558_mem.sroa.15.sroa.10.0 = phi i64 [ %v558_next.sroa.28.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.18.0.copyload2021, %v554_ok ]
  %v558_mem.sroa.15.sroa.5.0 = phi i64 [ %v558_next.sroa.28.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.28.sroa.8.0.copyload2016, %v554_ok ]
  %v558_mem.sroa.17.sroa.21.0 = phi i8 [ %v558_next.sroa.32.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.40.0.copyload1696, %v554_ok ]
  %v558_mem.sroa.17.sroa.20.0 = phi i8 [ %v558_next.sroa.32.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.38.0.copyload1695, %v554_ok ]
  %v558_mem.sroa.17.sroa.16.0 = phi i8 [ %v558_next.sroa.32.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.30.0.copyload1692, %v554_ok ]
  %v558_mem.sroa.17.sroa.15.0 = phi i8 [ %v558_next.sroa.32.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.28.0.copyload1691, %v554_ok ]
  %v558_mem.sroa.17.sroa.11.0 = phi i8 [ %v558_next.sroa.32.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.20.0.copyload1688, %v554_ok ]
  %v558_mem.sroa.17.sroa.10.0 = phi i64 [ %v558_next.sroa.32.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.18.0.copyload1687, %v554_ok ]
  %v558_mem.sroa.17.sroa.5.0 = phi i64 [ %v558_next.sroa.32.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.32.sroa.8.0.copyload1682, %v554_ok ]
  %v558_mem.sroa.3.sroa.5.0 = phi i64 [ %v558_next.sroa.4.sroa.8.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.8.0.copyload4020, %v554_ok ]
  %v558_mem.sroa.3.sroa.10.0 = phi i64 [ %v558_next.sroa.4.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.18.0.copyload4025, %v554_ok ]
  %v558_mem.sroa.3.sroa.11.0 = phi i8 [ %v558_next.sroa.4.sroa.20.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.20.0.copyload4026, %v554_ok ]
  %v558_mem.sroa.3.sroa.15.0 = phi i8 [ %v558_next.sroa.4.sroa.28.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.28.0.copyload4029, %v554_ok ]
  %v558_mem.sroa.3.sroa.16.0 = phi i8 [ %v558_next.sroa.4.sroa.30.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.30.0.copyload4030, %v554_ok ]
  %v558_mem.sroa.3.sroa.20.0 = phi i8 [ %v558_next.sroa.4.sroa.38.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.38.0.copyload4033, %v554_ok ]
  %v558_mem.sroa.3.sroa.21.0 = phi i8 [ %v558_next.sroa.4.sroa.40.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.4.sroa.40.0.copyload4034, %v554_ok ]
  %v558_mem.sroa.10.0 = phi i32 [ %v558_next.sroa.18.0.copyload, %b66_to_b274 ], [ %v558_next.sroa.18.0.copyload1251, %v554_ok ]
  %v559 = phi i1 [ true, %b66_to_b274 ], [ %v551, %v554_ok ]
  %v560 = phi i32 [ %v1251105, %b66_to_b274 ], [ %v552, %v554_ok ]
  %.in = phi ptr [ %v122_mem, %b66_to_b274 ], [ %v556_mem, %v554_ok ]
  %113 = phi <2 x i32> [ %157, %b66_to_b274 ], [ %33, %v554_ok ]
  %114 = phi <2 x i32> [ %159, %b66_to_b274 ], [ %35, %v554_ok ]
  %115 = phi <2 x i32> [ %161, %b66_to_b274 ], [ %37, %v554_ok ]
  %116 = phi <2 x i32> [ %162, %b66_to_b274 ], [ %38, %v554_ok ]
  %117 = phi <2 x i32> [ %164, %b66_to_b274 ], [ %40, %v554_ok ]
  %118 = phi <2 x i32> [ %166, %b66_to_b274 ], [ %42, %v554_ok ]
  %119 = phi <2 x i32> [ %168, %b66_to_b274 ], [ %44, %v554_ok ]
  %120 = phi <2 x i32> [ %169, %b66_to_b274 ], [ %45, %v554_ok ]
  %121 = phi <2 x i32> [ %171, %b66_to_b274 ], [ %47, %v554_ok ]
  %122 = phi <2 x i32> [ %173, %b66_to_b274 ], [ %49, %v554_ok ]
  %123 = phi <2 x i32> [ %175, %b66_to_b274 ], [ %51, %v554_ok ]
  %124 = phi <2 x i32> [ %176, %b66_to_b274 ], [ %52, %v554_ok ]
  %125 = phi <2 x i32> [ %178, %b66_to_b274 ], [ %54, %v554_ok ]
  %126 = phi <2 x i32> [ %180, %b66_to_b274 ], [ %56, %v554_ok ]
  %127 = phi <2 x i32> [ %182, %b66_to_b274 ], [ %58, %v554_ok ]
  %128 = phi <2 x i32> [ %184, %b66_to_b274 ], [ %60, %v554_ok ]
  %129 = phi <2 x i32> [ %185, %b66_to_b274 ], [ %61, %v554_ok ]
  %130 = phi <2 x i32> [ %187, %b66_to_b274 ], [ %63, %v554_ok ]
  %131 = phi <2 x i32> [ %189, %b66_to_b274 ], [ %65, %v554_ok ]
  %132 = phi <2 x i32> [ %191, %b66_to_b274 ], [ %67, %v554_ok ]
  %133 = phi <2 x i32> [ %192, %b66_to_b274 ], [ %68, %v554_ok ]
  %134 = phi <2 x i32> [ %194, %b66_to_b274 ], [ %70, %v554_ok ]
  %135 = phi <2 x i32> [ %196, %b66_to_b274 ], [ %72, %v554_ok ]
  %136 = phi <2 x i32> [ %198, %b66_to_b274 ], [ %74, %v554_ok ]
  %137 = phi <2 x i32> [ %199, %b66_to_b274 ], [ %75, %v554_ok ]
  %138 = phi <2 x i32> [ %201, %b66_to_b274 ], [ %77, %v554_ok ]
  %139 = phi <2 x i32> [ %203, %b66_to_b274 ], [ %79, %v554_ok ]
  %140 = phi <2 x i32> [ %205, %b66_to_b274 ], [ %81, %v554_ok ]
  %141 = phi <2 x i64> [ %156, %b66_to_b274 ], [ %32, %v554_ok ]
  %142 = phi <2 x i64> [ %158, %b66_to_b274 ], [ %34, %v554_ok ]
  %143 = phi <2 x i64> [ %163, %b66_to_b274 ], [ %39, %v554_ok ]
  %144 = phi <2 x i64> [ %165, %b66_to_b274 ], [ %41, %v554_ok ]
  %145 = phi <2 x i64> [ %170, %b66_to_b274 ], [ %46, %v554_ok ]
  %146 = phi <2 x i64> [ %172, %b66_to_b274 ], [ %48, %v554_ok ]
  %147 = phi <2 x i64> [ %177, %b66_to_b274 ], [ %53, %v554_ok ]
  %148 = phi <2 x i64> [ %179, %b66_to_b274 ], [ %55, %v554_ok ]
  %149 = phi <2 x i64> [ %186, %b66_to_b274 ], [ %62, %v554_ok ]
  %150 = phi <2 x i64> [ %188, %b66_to_b274 ], [ %64, %v554_ok ]
  %151 = phi <2 x i64> [ %193, %b66_to_b274 ], [ %69, %v554_ok ]
  %152 = phi <2 x i64> [ %195, %b66_to_b274 ], [ %71, %v554_ok ]
  %153 = phi <2 x i64> [ %200, %b66_to_b274 ], [ %76, %v554_ok ]
  %154 = phi <2 x i64> [ %202, %b66_to_b274 ], [ %78, %v554_ok ]
  %155 = load <2 x i32>, ptr %.in, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.3.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.4.sroa.13.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.3.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.4.sroa.23.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.5.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.6.sroa.13.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.5.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.6.sroa.23.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.7.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.8.sroa.13.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.7.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.8.sroa.23.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.9.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.10.sroa.13.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.9.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.10.sroa.23.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.11.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.11.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.13.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.13.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.15.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.15.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx.sink, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.17.sroa.12, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx.sink, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.17.sroa.22, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx.sink4117, i64 6, i1 false)
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.11.sroa.12, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.11.sroa.22, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.13.sroa.12, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.13.sroa.22, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.15.sroa.12, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.15.sroa.22, i64 6, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.17.sroa.12, i64 3, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.17.sroa.22, i64 6, i1 false)
  store <2 x i32> %155, ptr %v122_mem, align 8
  store <2 x i64> %141, ptr %v122_next.sroa.4.sroa.4.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.3.sroa.5.0, ptr %v122_next.sroa.4.sroa.6.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i32> %113, ptr %v122_next.sroa.4.sroa.7.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i64> %142, ptr %v122_next.sroa.4.sroa.9.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.3.sroa.10.0, ptr %v122_next.sroa.4.sroa.11.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.3.sroa.11.0, ptr %v122_next.sroa.4.sroa.12.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.4.sroa.13.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.3.sroa.12, i64 3, i1 false)
  store <2 x i32> %114, ptr %v122_next.sroa.4.sroa.14.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.3.sroa.15.0, ptr %v122_next.sroa.4.sroa.16.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.3.sroa.16.0, ptr %v122_next.sroa.4.sroa.17.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.4.sroa.32.sroa.0.0, ptr %v122_next.sroa.4.sroa.18.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 2
  store <2 x i32> %115, ptr %v122_next.sroa.4.sroa.19.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.3.sroa.20.0, ptr %v122_next.sroa.4.sroa.21.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.3.sroa.21.0, ptr %v122_next.sroa.4.sroa.22.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.4.sroa.23.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.3.sroa.22, i64 6, i1 false)
  store <2 x i32> %116, ptr %v122_next.sroa.5.0.v122_mem.sroa_idx, align 8
  store <2 x i64> %143, ptr %v122_next.sroa.6.sroa.4.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.5.sroa.5.0, ptr %v122_next.sroa.6.sroa.6.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i32> %117, ptr %v122_next.sroa.6.sroa.7.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i64> %144, ptr %v122_next.sroa.6.sroa.9.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.5.sroa.10.0, ptr %v122_next.sroa.6.sroa.11.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.5.sroa.11.0, ptr %v122_next.sroa.6.sroa.12.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.6.sroa.13.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.5.sroa.12, i64 3, i1 false)
  store <2 x i32> %118, ptr %v122_next.sroa.6.sroa.14.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.5.sroa.15.0, ptr %v122_next.sroa.6.sroa.16.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.5.sroa.16.0, ptr %v122_next.sroa.6.sroa.17.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.8.sroa.32.sroa.0.0, ptr %v122_next.sroa.6.sroa.18.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 2
  store <2 x i32> %119, ptr %v122_next.sroa.6.sroa.19.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.5.sroa.20.0, ptr %v122_next.sroa.6.sroa.21.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.5.sroa.21.0, ptr %v122_next.sroa.6.sroa.22.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.6.sroa.23.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.5.sroa.22, i64 6, i1 false)
  store <2 x i32> %120, ptr %v122_next.sroa.7.0.v122_mem.sroa_idx, align 8
  store <2 x i64> %145, ptr %v122_next.sroa.8.sroa.4.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.7.sroa.5.0, ptr %v122_next.sroa.8.sroa.6.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i32> %121, ptr %v122_next.sroa.8.sroa.7.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i64> %146, ptr %v122_next.sroa.8.sroa.9.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.7.sroa.10.0, ptr %v122_next.sroa.8.sroa.11.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.7.sroa.11.0, ptr %v122_next.sroa.8.sroa.12.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.8.sroa.13.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.7.sroa.12, i64 3, i1 false)
  store <2 x i32> %122, ptr %v122_next.sroa.8.sroa.14.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.7.sroa.15.0, ptr %v122_next.sroa.8.sroa.16.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.7.sroa.16.0, ptr %v122_next.sroa.8.sroa.17.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.12.sroa.32.sroa.0.0, ptr %v122_next.sroa.8.sroa.18.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 2
  store <2 x i32> %123, ptr %v122_next.sroa.8.sroa.19.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.7.sroa.20.0, ptr %v122_next.sroa.8.sroa.21.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.7.sroa.21.0, ptr %v122_next.sroa.8.sroa.22.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.8.sroa.23.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.7.sroa.22, i64 6, i1 false)
  store <2 x i32> %124, ptr %v122_next.sroa.9.0.v122_mem.sroa_idx, align 8
  store <2 x i64> %147, ptr %v122_next.sroa.10.sroa.4.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.9.sroa.5.0, ptr %v122_next.sroa.10.sroa.6.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i32> %125, ptr %v122_next.sroa.10.sroa.7.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i64> %148, ptr %v122_next.sroa.10.sroa.9.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.9.sroa.10.0, ptr %v122_next.sroa.10.sroa.11.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.9.sroa.11.0, ptr %v122_next.sroa.10.sroa.12.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.10.sroa.13.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v558_mem.sroa.9.sroa.12, i64 3, i1 false)
  store <2 x i32> %126, ptr %v122_next.sroa.10.sroa.14.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.9.sroa.15.0, ptr %v122_next.sroa.10.sroa.16.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.9.sroa.16.0, ptr %v122_next.sroa.10.sroa.17.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.16.sroa.32.sroa.0.0, ptr %v122_next.sroa.10.sroa.18.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 2
  store i32 %v558_mem.sroa.9.sroa.18.0, ptr %v122_next.sroa.10.sroa.19.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v558_mem.sroa.9.sroa.19.0, ptr %v122_next.sroa.10.sroa.20.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.9.sroa.20.0, ptr %v122_next.sroa.10.sroa.21.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.9.sroa.21.0, ptr %v122_next.sroa.10.sroa.22.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.10.sroa.23.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v558_mem.sroa.9.sroa.22, i64 6, i1 false)
  store i32 %v558_mem.sroa.10.0, ptr %v122_next.sroa.11.0.v122_mem.sroa_idx, align 8
  store i32 %v558_mem.sroa.11.sroa.0.0, ptr %v122_next.sroa.12.0.v122_mem.sroa_idx, align 4
  store i64 %v558_mem.sroa.11.sroa.3.0, ptr %v122_next.sroa.12.sroa.4.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.11.sroa.4.0, ptr %v122_next.sroa.12.sroa.5.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.11.sroa.5.0, ptr %v122_next.sroa.12.sroa.6.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v558_mem.sroa.11.sroa.6.0, ptr %v122_next.sroa.12.sroa.7.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i32 %v558_mem.sroa.11.sroa.7.0, ptr %v122_next.sroa.12.sroa.8.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i64 %v558_mem.sroa.11.sroa.8.0, ptr %v122_next.sroa.12.sroa.9.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.11.sroa.9.0, ptr %v122_next.sroa.12.sroa.10.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.11.sroa.10.0, ptr %v122_next.sroa.12.sroa.11.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.11.sroa.11.0, ptr %v122_next.sroa.12.sroa.12.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.12.sroa.13, i64 3, i1 false)
  store <2 x i32> %127, ptr %v122_next.sroa.12.sroa.14.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.11.sroa.15.0, ptr %v122_next.sroa.12.sroa.16.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.11.sroa.16.0, ptr %v122_next.sroa.12.sroa.17.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.20.sroa.32.sroa.0.0, ptr %v122_next.sroa.12.sroa.18.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 2
  store <2 x i32> %128, ptr %v122_next.sroa.12.sroa.19.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.11.sroa.20.0, ptr %v122_next.sroa.12.sroa.21.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.11.sroa.21.0, ptr %v122_next.sroa.12.sroa.22.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.12.sroa.23, i64 6, i1 false)
  store <2 x i32> %129, ptr %v122_next.sroa.13.0.v122_mem.sroa_idx, align 8
  store <2 x i64> %149, ptr %v122_next.sroa.14.sroa.4.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.13.sroa.5.0, ptr %v122_next.sroa.14.sroa.6.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i32> %130, ptr %v122_next.sroa.14.sroa.7.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i64> %150, ptr %v122_next.sroa.14.sroa.9.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.13.sroa.10.0, ptr %v122_next.sroa.14.sroa.11.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.13.sroa.11.0, ptr %v122_next.sroa.14.sroa.12.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.14.sroa.13, i64 3, i1 false)
  store <2 x i32> %131, ptr %v122_next.sroa.14.sroa.14.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.13.sroa.15.0, ptr %v122_next.sroa.14.sroa.16.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.13.sroa.16.0, ptr %v122_next.sroa.14.sroa.17.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.24.sroa.32.sroa.0.0, ptr %v122_next.sroa.14.sroa.18.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 2
  store <2 x i32> %132, ptr %v122_next.sroa.14.sroa.19.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.13.sroa.20.0, ptr %v122_next.sroa.14.sroa.21.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.13.sroa.21.0, ptr %v122_next.sroa.14.sroa.22.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.14.sroa.23, i64 6, i1 false)
  store <2 x i32> %133, ptr %v122_next.sroa.15.0.v122_mem.sroa_idx, align 8
  store <2 x i64> %151, ptr %v122_next.sroa.16.sroa.4.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.15.sroa.5.0, ptr %v122_next.sroa.16.sroa.6.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i32> %134, ptr %v122_next.sroa.16.sroa.7.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i64> %152, ptr %v122_next.sroa.16.sroa.9.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.15.sroa.10.0, ptr %v122_next.sroa.16.sroa.11.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.15.sroa.11.0, ptr %v122_next.sroa.16.sroa.12.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.16.sroa.13, i64 3, i1 false)
  store <2 x i32> %135, ptr %v122_next.sroa.16.sroa.14.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.15.sroa.15.0, ptr %v122_next.sroa.16.sroa.16.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.15.sroa.16.0, ptr %v122_next.sroa.16.sroa.17.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.28.sroa.32.sroa.0.0, ptr %v122_next.sroa.16.sroa.18.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 2
  store <2 x i32> %136, ptr %v122_next.sroa.16.sroa.19.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.15.sroa.20.0, ptr %v122_next.sroa.16.sroa.21.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.15.sroa.21.0, ptr %v122_next.sroa.16.sroa.22.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.16.sroa.23, i64 6, i1 false)
  store <2 x i32> %137, ptr %v122_next.sroa.17.0.v122_mem.sroa_idx, align 8
  store <2 x i64> %153, ptr %v122_next.sroa.18.sroa.4.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.17.sroa.5.0, ptr %v122_next.sroa.18.sroa.6.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i32> %138, ptr %v122_next.sroa.18.sroa.7.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store <2 x i64> %154, ptr %v122_next.sroa.18.sroa.9.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i64 %v558_mem.sroa.17.sroa.10.0, ptr %v122_next.sroa.18.sroa.11.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.17.sroa.11.0, ptr %v122_next.sroa.18.sroa.12.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %v122_next.sroa.18.sroa.13, i64 3, i1 false)
  store <2 x i32> %139, ptr %v122_next.sroa.18.sroa.14.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.17.sroa.15.0, ptr %v122_next.sroa.18.sroa.16.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  store i8 %v558_mem.sroa.17.sroa.16.0, ptr %v122_next.sroa.18.sroa.17.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  store i16 %v558_next.sroa.32.sroa.32.sroa.0.0, ptr %v122_next.sroa.18.sroa.18.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 2
  store <2 x i32> %140, ptr %v122_next.sroa.18.sroa.19.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.17.sroa.20.0, ptr %v122_next.sroa.18.sroa.21.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  store i8 %v558_mem.sroa.17.sroa.21.0, ptr %v122_next.sroa.18.sroa.22.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, ptr noundef nonnull align 2 dereferenceable(6) %v122_next.sroa.18.sroa.23, i64 6, i1 false)
  %v129 = icmp samesign ult i64 %indvars.iv, 7
  %v123. = select i1 %v129, i1 %v559, i1 false
  br i1 %v123., label %v132_ok, label %b61_to_b13

b66_to_b274:                                      ; preds = %v132_ok
  %156 = load <2 x i64>, ptr %v122_next.sroa.4.sroa.4.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.6.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %157 = load <2 x i32>, ptr %v122_next.sroa.4.sroa.7.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %158 = load <2 x i64>, ptr %v122_next.sroa.4.sroa.9.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.4.sroa.11.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.12.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %159 = load <2 x i32>, ptr %v122_next.sroa.4.sroa.14.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.4.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.16.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.4.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.17.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  %160 = load i16, ptr %v122_next.sroa.4.sroa.18.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 2
  %161 = load <2 x i32>, ptr %v122_next.sroa.4.sroa.19.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.21.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.4.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.4.sroa.22.0.v122_next.sroa.4.0.v122_mem.sroa_idx.sroa_idx, align 1
  %162 = load <2 x i32>, ptr %v122_next.sroa.5.0.v122_mem.sroa_idx, align 8
  %163 = load <2 x i64>, ptr %v122_next.sroa.6.sroa.4.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.6.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %164 = load <2 x i32>, ptr %v122_next.sroa.6.sroa.7.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %165 = load <2 x i64>, ptr %v122_next.sroa.6.sroa.9.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.6.sroa.11.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.12.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %166 = load <2 x i32>, ptr %v122_next.sroa.6.sroa.14.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.8.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.16.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.8.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.17.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  %167 = load i16, ptr %v122_next.sroa.6.sroa.18.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 2
  %168 = load <2 x i32>, ptr %v122_next.sroa.6.sroa.19.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.21.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.8.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.6.sroa.22.0.v122_next.sroa.6.0.v122_mem.sroa_idx.sroa_idx, align 1
  %169 = load <2 x i32>, ptr %v122_next.sroa.7.0.v122_mem.sroa_idx, align 8
  %170 = load <2 x i64>, ptr %v122_next.sroa.8.sroa.4.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.6.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %171 = load <2 x i32>, ptr %v122_next.sroa.8.sroa.7.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %172 = load <2 x i64>, ptr %v122_next.sroa.8.sroa.9.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.8.sroa.11.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.12.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %173 = load <2 x i32>, ptr %v122_next.sroa.8.sroa.14.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.12.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.16.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.12.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.17.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  %174 = load i16, ptr %v122_next.sroa.8.sroa.18.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 2
  %175 = load <2 x i32>, ptr %v122_next.sroa.8.sroa.19.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.21.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.12.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.8.sroa.22.0.v122_next.sroa.8.0.v122_mem.sroa_idx.sroa_idx, align 1
  %176 = load <2 x i32>, ptr %v122_next.sroa.9.0.v122_mem.sroa_idx, align 8
  %177 = load <2 x i64>, ptr %v122_next.sroa.10.sroa.4.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.6.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %178 = load <2 x i32>, ptr %v122_next.sroa.10.sroa.7.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %179 = load <2 x i64>, ptr %v122_next.sroa.10.sroa.9.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.10.sroa.11.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.10.sroa.12.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %180 = load <2 x i32>, ptr %v122_next.sroa.10.sroa.14.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.16.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.10.sroa.16.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.16.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.10.sroa.17.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  %181 = load i16, ptr %v122_next.sroa.10.sroa.18.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 2
  %v558_next.sroa.16.sroa.34.0.copyload = load i32, ptr %v122_next.sroa.10.sroa.19.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.36.0.copyload = load i32, ptr %v122_next.sroa.10.sroa.20.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.16.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.10.sroa.21.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.16.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.10.sroa.22.0.v122_next.sroa.10.0.v122_mem.sroa_idx.sroa_idx, align 1
  %v558_next.sroa.18.0.copyload = load i32, ptr %v122_next.sroa.11.0.v122_mem.sroa_idx, align 8
  %v558_next.sroa.20.sroa.0.0.copyload = load i32, ptr %v122_next.sroa.12.0.v122_mem.sroa_idx, align 4
  %v558_next.sroa.20.sroa.4.0.copyload = load i64, ptr %v122_next.sroa.12.sroa.4.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.6.0.copyload = load i64, ptr %v122_next.sroa.12.sroa.5.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.12.sroa.6.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.10.0.copyload = load i32, ptr %v122_next.sroa.12.sroa.7.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.12.0.copyload = load i32, ptr %v122_next.sroa.12.sroa.8.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.20.sroa.14.0.copyload = load i64, ptr %v122_next.sroa.12.sroa.9.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.16.0.copyload = load i64, ptr %v122_next.sroa.12.sroa.10.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.12.sroa.11.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.12.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %182 = load <2 x i32>, ptr %v122_next.sroa.12.sroa.14.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.20.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.16.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.20.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.17.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  %183 = load i16, ptr %v122_next.sroa.12.sroa.18.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 2
  %184 = load <2 x i32>, ptr %v122_next.sroa.12.sroa.19.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.21.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.20.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.12.sroa.22.0.v122_next.sroa.12.0.v122_mem.sroa_idx.sroa_idx, align 1
  %185 = load <2 x i32>, ptr %v122_next.sroa.13.0.v122_mem.sroa_idx, align 8
  %186 = load <2 x i64>, ptr %v122_next.sroa.14.sroa.4.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.6.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %187 = load <2 x i32>, ptr %v122_next.sroa.14.sroa.7.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %188 = load <2 x i64>, ptr %v122_next.sroa.14.sroa.9.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.14.sroa.11.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.12.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %189 = load <2 x i32>, ptr %v122_next.sroa.14.sroa.14.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.24.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.16.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.24.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.17.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  %190 = load i16, ptr %v122_next.sroa.14.sroa.18.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 2
  %191 = load <2 x i32>, ptr %v122_next.sroa.14.sroa.19.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.21.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.24.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.14.sroa.22.0.v122_next.sroa.14.0.v122_mem.sroa_idx.sroa_idx, align 1
  %192 = load <2 x i32>, ptr %v122_next.sroa.15.0.v122_mem.sroa_idx, align 8
  %193 = load <2 x i64>, ptr %v122_next.sroa.16.sroa.4.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.6.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %194 = load <2 x i32>, ptr %v122_next.sroa.16.sroa.7.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %195 = load <2 x i64>, ptr %v122_next.sroa.16.sroa.9.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.16.sroa.11.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.12.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %196 = load <2 x i32>, ptr %v122_next.sroa.16.sroa.14.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.28.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.16.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.28.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.17.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  %197 = load i16, ptr %v122_next.sroa.16.sroa.18.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 2
  %198 = load <2 x i32>, ptr %v122_next.sroa.16.sroa.19.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.21.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.28.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.16.sroa.22.0.v122_next.sroa.16.0.v122_mem.sroa_idx.sroa_idx, align 1
  %199 = load <2 x i32>, ptr %v122_next.sroa.17.0.v122_mem.sroa_idx, align 8
  %200 = load <2 x i64>, ptr %v122_next.sroa.18.sroa.4.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.8.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.6.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %201 = load <2 x i32>, ptr %v122_next.sroa.18.sroa.7.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %202 = load <2 x i64>, ptr %v122_next.sroa.18.sroa.9.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.18.0.copyload = load i64, ptr %v122_next.sroa.18.sroa.11.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.20.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.12.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %203 = load <2 x i32>, ptr %v122_next.sroa.18.sroa.14.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.32.sroa.28.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.16.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 4
  %v558_next.sroa.32.sroa.30.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.17.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  %204 = load i16, ptr %v122_next.sroa.18.sroa.18.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 2
  %205 = load <2 x i32>, ptr %v122_next.sroa.18.sroa.19.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.38.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.21.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 8
  %v558_next.sroa.32.sroa.40.0.copyload = load i8, ptr %v122_next.sroa.18.sroa.22.0.v122_next.sroa.18.0.v122_mem.sroa_idx.sroa_idx, align 1
  br label %b274_to_b59
}

define range(i32 0, 4) i32 @liza_liza_proxy.serve(ptr %p0, i16 %p1, i1 %p2) local_unnamed_addr {
b0:
  %v1_error = alloca i32, align 4
  %v10_error = alloca i32, align 4
  %v1_ptr = call ptr @liza_rt_region_create(i64 32768, ptr nonnull %v1_error)
  %v1_code = load i32, ptr %v1_error, align 4
  %v1_failed.not.not = icmp eq i32 %v1_code, 0
  br i1 %v1_failed.not.not, label %b3, label %b2

common.ret:                                       ; preds = %b5, %b2, %v10_body.preheader
  %common.ret.op = phi i32 [ %v21, %v10_body.preheader ], [ 3, %b2 ], [ 3, %b5 ]
  ret i32 %common.ret.op

b2:                                               ; preds = %b0
  %raw.i.i = call i32 @liza_rt_reactor_close(ptr %p0)
  br label %common.ret

b3:                                               ; preds = %b0
  %v10_ptr = call ptr @liza_rt_region_alloc(ptr %v1_ptr, i64 1, i64 1, i32 32768, ptr nonnull %v10_error)
  %v10_code = load i32, ptr %v10_error, align 4
  %v10_failed.not = icmp eq i32 %v10_code, 0
  br i1 %v10_failed.not, label %v10_body.preheader, label %b5

v10_body.preheader:                               ; preds = %b3
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32768) %v10_ptr, i8 0, i64 32768, i1 false)
  %v10_buffer0 = insertvalue { ptr, i32 } zeroinitializer, ptr %v10_ptr, 0
  %v10_buffer = insertvalue { ptr, i32 } %v10_buffer0, i32 32768, 1
  %v21 = call i32 @liza_liza_proxy.exchange(ptr %p0, { ptr, i32 } %v10_buffer, i16 %p1, i1 %p2)
  call void @liza_rt_region_close(ptr %v1_ptr)
  br label %common.ret

b5:                                               ; preds = %b3
  call void @liza_rt_region_close(ptr %v1_ptr)
  %raw.i.i2 = call i32 @liza_rt_reactor_close(ptr %p0)
  br label %common.ret
}

define range(i32 0, 4) i32 @liza_main() local_unnamed_addr {
b0:
  %v1_error.i = alloca i32, align 4
  %v10_error.i = alloca i32, align 4
  %out.i.i = alloca ptr, align 8
  %n.i.i = tail call i32 @liza_rt_cli_count()
  %v5.not = icmp eq i32 %n.i.i, 1
  br i1 %v5.not, label %b16, label %b1

b1:                                               ; preds = %b0
  %n.i.i2 = tail call i32 @liza_rt_cli_count()
  %v8.not = icmp eq i32 %n.i.i2, 2
  br i1 %v8.not, label %b5, label %b3

common.ret:                                       ; preds = %b18, %b12, %b3, %b5, %liza_liza_proxy.serve.exit
  %common.ret.op = phi i32 [ %common.ret.op.i65, %liza_liza_proxy.serve.exit ], [ 2, %b5 ], [ 2, %b3 ], [ 2, %b12 ], [ 3, %b18 ]
  ret i32 %common.ret.op

b3:                                               ; preds = %b1
  %result.i.i = tail call i64 @liza_rt_err_text(ptr nonnull @text.main.v9, i32 41)
  br label %common.ret

b5:                                               ; preds = %b1
  %n.i.i.i = tail call i32 @liza_rt_cli_count()
  %v1.not.i = icmp ult i32 %n.i.i.i, 2
  br i1 %v1.not.i, label %common.ret, label %b8

b8:                                               ; preds = %b5
  %r.i.i = tail call i32 @liza_rt_cli_equals(i32 1, ptr nonnull @text.main.v17, i32 6)
  %b.i.i.not = icmp eq i32 %r.i.i, 0
  br i1 %b.i.i.not, label %b9, label %b14

b9:                                               ; preds = %b8
  %r.i.i3 = tail call i32 @liza_rt_cli_equals(i32 1, ptr nonnull @text.main.v21, i32 11)
  %b.i.i4.not = icmp eq i32 %r.i.i3, 0
  br i1 %b.i.i4.not, label %b12, label %b14

b12:                                              ; preds = %b9
  %result.i.i5 = tail call i64 @liza_rt_err_text(ptr nonnull @text.main.v25, i32 41)
  br label %common.ret

b14:                                              ; preds = %b9, %b8
  %r.i.i31 = tail call i32 @liza_rt_cli_equals(i32 1, ptr nonnull @text.main.v28, i32 6)
  %b.i.i32 = icmp ne i32 %r.i.i31, 0
  br label %b16

b16:                                              ; preds = %b0, %b14
  %v31 = phi i1 [ %b.i.i32, %b14 ], [ false, %b0 ]
  %v32 = phi i16 [ 0, %b14 ], [ 9004, %b0 ]
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %out.i.i)
  %code.i.i = call i32 @liza_rt_reactor_create(i16 %v32, i32 16, ptr nonnull %out.i.i)
  %value.i.i = load ptr, ptr %out.i.i, align 8
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %out.i.i)
  switch i32 %code.i.i, label %b36.i.i [
    i32 0, label %b1.i
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i38
    i32 3, label %b7.i.i37
    i32 4, label %b10.i.i36
    i32 5, label %b13.i.i35
    i32 6, label %b16.i.i34
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b1.i:                                             ; preds = %b16
  %v5.i = insertvalue %variant.10 zeroinitializer, ptr %value.i.i, 1
  br label %liza_net.reactor_create.exit

b4.i.i38:                                         ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b7.i.i37:                                         ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b10.i.i36:                                        ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b13.i.i35:                                        ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b16.i.i34:                                        ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %b16
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i34, %b13.i.i35, %b10.i.i36, %b7.i.i37, %b4.i.i38, %b16
  %common.ret.op.i.i33 = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i38 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i37 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i36 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i35 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i34 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %b16 ]
  %v8.i = insertvalue %variant.10 { i32 1, ptr null, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i33, 2
  br label %liza_net.reactor_create.exit

liza_net.reactor_create.exit:                     ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.10 [ %v5.i, %b1.i ], [ %v8.i, %liza___liza_reactor_error.exit.i ]
  %v35 = extractvalue %variant.10 %common.ret.op.i, 0
  %switch1 = icmp eq i32 %v35, 1
  br i1 %switch1, label %b18, label %b19

b18:                                              ; preds = %liza_net.reactor_create.exit
  %result.i.i39 = call i64 @liza_rt_err_text(ptr nonnull @text.main.v37, i32 31)
  br label %common.ret

b19:                                              ; preds = %liza_net.reactor_create.exit
  %v40 = extractvalue %variant.10 %common.ret.op.i, 1
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %v1_error.i)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %v10_error.i)
  %v1_ptr.i = call ptr @liza_rt_region_create(i64 32768, ptr nonnull %v1_error.i)
  %v1_code.i = load i32, ptr %v1_error.i, align 4
  %v1_failed.not.not.i = icmp eq i32 %v1_code.i, 0
  br i1 %v1_failed.not.not.i, label %b3.i, label %b2.i

b2.i:                                             ; preds = %b19
  %raw.i.i.i = call i32 @liza_rt_reactor_close(ptr %v40)
  br label %liza_liza_proxy.serve.exit

b3.i:                                             ; preds = %b19
  %v10_ptr.i = call ptr @liza_rt_region_alloc(ptr %v1_ptr.i, i64 1, i64 1, i32 32768, ptr nonnull %v10_error.i)
  %v10_code.i = load i32, ptr %v10_error.i, align 4
  %v10_failed.not.i = icmp eq i32 %v10_code.i, 0
  br i1 %v10_failed.not.i, label %v10_body.preheader.i, label %b5.i

v10_body.preheader.i:                             ; preds = %b3.i
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(32768) %v10_ptr.i, i8 0, i64 32768, i1 false)
  %v10_buffer0.i = insertvalue { ptr, i32 } zeroinitializer, ptr %v10_ptr.i, 0
  %v10_buffer.i = insertvalue { ptr, i32 } %v10_buffer0.i, i32 32768, 1
  %v21.i = call i32 @liza_liza_proxy.exchange(ptr %v40, { ptr, i32 } %v10_buffer.i, i16 9003, i1 %v31)
  call void @liza_rt_region_close(ptr %v1_ptr.i)
  br label %liza_liza_proxy.serve.exit

b5.i:                                             ; preds = %b3.i
  call void @liza_rt_region_close(ptr %v1_ptr.i)
  %raw.i.i2.i = call i32 @liza_rt_reactor_close(ptr %v40)
  br label %liza_liza_proxy.serve.exit

liza_liza_proxy.serve.exit:                       ; preds = %b2.i, %v10_body.preheader.i, %b5.i
  %common.ret.op.i65 = phi i32 [ %v21.i, %v10_body.preheader.i ], [ 3, %b2.i ], [ 3, %b5.i ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %v1_error.i)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %v10_error.i)
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.7 @liza___liza_decode(i64 %p0) local_unnamed_addr #2 {
b0:
  %v1 = and i64 %p0, 4294967295
  %v3 = lshr i64 %p0, 32
  %trunc = trunc nuw i64 %v3 to i32
  switch i32 %trunc, label %b18 [
    i32 0, label %b1
    i32 1, label %b4
    i32 2, label %b7
    i32 3, label %b10
    i32 4, label %b13
    i32 5, label %b16
  ]

common.ret:                                       ; preds = %b18, %b16, %b13, %b10, %b7, %b4, %b1
  %common.ret.op = phi %variant.7 [ %v6, %b1 ], [ %v11, %b4 ], [ %v16, %b7 ], [ %v21, %b10 ], [ %v26, %b13 ], [ %v31, %b16 ], [ %v34, %b18 ]
  ret %variant.7 %common.ret.op

b1:                                               ; preds = %b0
  %v6 = insertvalue %variant.7 zeroinitializer, i64 %v1, 1
  br label %common.ret

b4:                                               ; preds = %b0
  %v10 = insertvalue %struct.IoFailure zeroinitializer, i64 %v1, 1
  %v11 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v10, 2
  br label %common.ret

b7:                                               ; preds = %b0
  %v15 = insertvalue %struct.IoFailure { %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1, 1
  %v16 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v15, 2
  br label %common.ret

b10:                                              ; preds = %b0
  %v20 = insertvalue %struct.IoFailure { %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1, 1
  %v21 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v20, 2
  br label %common.ret

b13:                                              ; preds = %b0
  %v25 = insertvalue %struct.IoFailure { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1, 1
  %v26 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v25, 2
  br label %common.ret

b16:                                              ; preds = %b0
  %v30 = insertvalue %struct.IoFailure { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1, 1
  %v31 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v30, 2
  br label %common.ret

b18:                                              ; preds = %b0
  %v33 = insertvalue %struct.IoFailure { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1, 1
  %v34 = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v33, 2
  br label %common.ret
}

define %variant.7 @liza_console.write({ ptr, i32 } %p0) local_unnamed_addr {
b0:
  %data.i = extractvalue { ptr, i32 } %p0, 0
  %length.i = extractvalue { ptr, i32 } %p0, 1
  %result.i = tail call i64 @liza_rt_write_text(ptr %data.i, i32 %length.i)
  %v1.i = and i64 %result.i, 4294967295
  %v3.i = lshr i64 %result.i, 32
  %trunc.i = trunc nuw i64 %v3.i to i32
  switch i32 %trunc.i, label %b18.i [
    i32 0, label %b1.i
    i32 1, label %b4.i
    i32 2, label %b7.i
    i32 3, label %b10.i
    i32 4, label %b13.i
    i32 5, label %b16.i
  ]

b1.i:                                             ; preds = %b0
  %v6.i = insertvalue %variant.7 zeroinitializer, i64 %v1.i, 1
  br label %liza___liza_decode.exit

b4.i:                                             ; preds = %b0
  %v10.i = insertvalue %struct.IoFailure zeroinitializer, i64 %v1.i, 1
  %v11.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v10.i, 2
  br label %liza___liza_decode.exit

b7.i:                                             ; preds = %b0
  %v15.i = insertvalue %struct.IoFailure { %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v16.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v15.i, 2
  br label %liza___liza_decode.exit

b10.i:                                            ; preds = %b0
  %v20.i = insertvalue %struct.IoFailure { %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v21.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v20.i, 2
  br label %liza___liza_decode.exit

b13.i:                                            ; preds = %b0
  %v25.i = insertvalue %struct.IoFailure { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v26.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v25.i, 2
  br label %liza___liza_decode.exit

b16.i:                                            ; preds = %b0
  %v30.i = insertvalue %struct.IoFailure { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v31.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v30.i, 2
  br label %liza___liza_decode.exit

b18.i:                                            ; preds = %b0
  %v33.i = insertvalue %struct.IoFailure { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v34.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v33.i, 2
  br label %liza___liza_decode.exit

liza___liza_decode.exit:                          ; preds = %b1.i, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b18.i
  %common.ret.op.i = phi %variant.7 [ %v6.i, %b1.i ], [ %v11.i, %b4.i ], [ %v16.i, %b7.i ], [ %v21.i, %b10.i ], [ %v26.i, %b13.i ], [ %v31.i, %b16.i ], [ %v34.i, %b18.i ]
  ret %variant.7 %common.ret.op.i
}

define %variant.7 @liza_console.print_u64(i64 %p0) local_unnamed_addr {
b0:
  %result.i = tail call i64 @liza_rt_print_u64(i64 %p0)
  %v1.i = and i64 %result.i, 4294967295
  %v3.i = lshr i64 %result.i, 32
  %trunc.i = trunc nuw i64 %v3.i to i32
  switch i32 %trunc.i, label %b18.i [
    i32 0, label %b1.i
    i32 1, label %b4.i
    i32 2, label %b7.i
    i32 3, label %b10.i
    i32 4, label %b13.i
    i32 5, label %b16.i
  ]

b1.i:                                             ; preds = %b0
  %v6.i = insertvalue %variant.7 zeroinitializer, i64 %v1.i, 1
  br label %liza___liza_decode.exit

b4.i:                                             ; preds = %b0
  %v10.i = insertvalue %struct.IoFailure zeroinitializer, i64 %v1.i, 1
  %v11.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v10.i, 2
  br label %liza___liza_decode.exit

b7.i:                                             ; preds = %b0
  %v15.i = insertvalue %struct.IoFailure { %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v16.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v15.i, 2
  br label %liza___liza_decode.exit

b10.i:                                            ; preds = %b0
  %v20.i = insertvalue %struct.IoFailure { %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v21.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v20.i, 2
  br label %liza___liza_decode.exit

b13.i:                                            ; preds = %b0
  %v25.i = insertvalue %struct.IoFailure { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v26.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v25.i, 2
  br label %liza___liza_decode.exit

b16.i:                                            ; preds = %b0
  %v30.i = insertvalue %struct.IoFailure { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v31.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v30.i, 2
  br label %liza___liza_decode.exit

b18.i:                                            ; preds = %b0
  %v33.i = insertvalue %struct.IoFailure { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v34.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v33.i, 2
  br label %liza___liza_decode.exit

liza___liza_decode.exit:                          ; preds = %b1.i, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b18.i
  %common.ret.op.i = phi %variant.7 [ %v6.i, %b1.i ], [ %v11.i, %b4.i ], [ %v16.i, %b7.i ], [ %v21.i, %b10.i ], [ %v26.i, %b13.i ], [ %v31.i, %b16.i ], [ %v34.i, %b18.i ]
  ret %variant.7 %common.ret.op.i
}

define %variant.7 @liza_console.err({ ptr, i32 } %p0) local_unnamed_addr {
b0:
  %data.i = extractvalue { ptr, i32 } %p0, 0
  %length.i = extractvalue { ptr, i32 } %p0, 1
  %result.i = tail call i64 @liza_rt_err_text(ptr %data.i, i32 %length.i)
  %v1.i = and i64 %result.i, 4294967295
  %v3.i = lshr i64 %result.i, 32
  %trunc.i = trunc nuw i64 %v3.i to i32
  switch i32 %trunc.i, label %b18.i [
    i32 0, label %b1.i
    i32 1, label %b4.i
    i32 2, label %b7.i
    i32 3, label %b10.i
    i32 4, label %b13.i
    i32 5, label %b16.i
  ]

b1.i:                                             ; preds = %b0
  %v6.i = insertvalue %variant.7 zeroinitializer, i64 %v1.i, 1
  br label %liza___liza_decode.exit

b4.i:                                             ; preds = %b0
  %v10.i = insertvalue %struct.IoFailure zeroinitializer, i64 %v1.i, 1
  %v11.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v10.i, 2
  br label %liza___liza_decode.exit

b7.i:                                             ; preds = %b0
  %v15.i = insertvalue %struct.IoFailure { %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v16.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v15.i, 2
  br label %liza___liza_decode.exit

b10.i:                                            ; preds = %b0
  %v20.i = insertvalue %struct.IoFailure { %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v21.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v20.i, 2
  br label %liza___liza_decode.exit

b13.i:                                            ; preds = %b0
  %v25.i = insertvalue %struct.IoFailure { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v26.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v25.i, 2
  br label %liza___liza_decode.exit

b16.i:                                            ; preds = %b0
  %v30.i = insertvalue %struct.IoFailure { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v31.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v30.i, 2
  br label %liza___liza_decode.exit

b18.i:                                            ; preds = %b0
  %v33.i = insertvalue %struct.IoFailure { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v1.i, 1
  %v34.i = insertvalue %variant.7 { i32 1, i64 0, %struct.IoFailure zeroinitializer }, %struct.IoFailure %v33.i, 2
  br label %liza___liza_decode.exit

liza___liza_decode.exit:                          ; preds = %b1.i, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b18.i
  %common.ret.op.i = phi %variant.7 [ %v6.i, %b1.i ], [ %v11.i, %b4.i ], [ %v16.i, %b7.i ], [ %v21.i, %b10.i ], [ %v26.i, %b13.i ], [ %v31.i, %b16.i ], [ %v34.i, %b18.i ]
  ret %variant.7 %common.ret.op.i
}

define i32 @liza_cli.count() local_unnamed_addr {
b0:
  %n.i = tail call i32 @liza_rt_cli_count()
  ret i32 %n.i
}

define %variant.8 @liza_cli.arg(i32 %p0) local_unnamed_addr {
b0:
  %n.i.i = tail call i32 @liza_rt_cli_count()
  %v1.not = icmp ult i32 %p0, %n.i.i
  %v4 = insertvalue %variant.8 zeroinitializer, i32 %p0, 1
  %spec.select = select i1 %v1.not, %variant.8 %v4, %variant.8 { i32 1, i32 0, [0 x i8] zeroinitializer }
  ret %variant.8 %spec.select
}

define i1 @liza_cli.equals(i32 %p0, { ptr, i32 } %p1) local_unnamed_addr {
b0:
  %p.i = extractvalue { ptr, i32 } %p1, 0
  %n.i = extractvalue { ptr, i32 } %p1, 1
  %r.i = tail call i32 @liza_rt_cli_equals(i32 %p0, ptr %p.i, i32 %n.i)
  %b.i = icmp ne i32 %r.i, 0
  ret i1 %b.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.5 @liza___liza_reactor_error(i32 %p0) local_unnamed_addr #2 {
b0:
  switch i32 %p0, label %b36 [
    i32 1, label %common.ret
    i32 2, label %b4
    i32 3, label %b7
    i32 4, label %b10
    i32 5, label %b13
    i32 6, label %b16
    i32 12, label %b34
    i32 8, label %b22
    i32 9, label %b25
    i32 10, label %b28
    i32 11, label %b31
  ]

common.ret:                                       ; preds = %b0, %b36, %b34, %b31, %b28, %b25, %b22, %b16, %b13, %b10, %b7, %b4
  %common.ret.op = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4 ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7 ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10 ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13 ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16 ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22 ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25 ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28 ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31 ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34 ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36 ], [ zeroinitializer, %b0 ]
  ret %variant.5 %common.ret.op

b4:                                               ; preds = %b0
  br label %common.ret

b7:                                               ; preds = %b0
  br label %common.ret

b10:                                              ; preds = %b0
  br label %common.ret

b13:                                              ; preds = %b0
  br label %common.ret

b16:                                              ; preds = %b0
  br label %common.ret

b22:                                              ; preds = %b0
  br label %common.ret

b25:                                              ; preds = %b0
  br label %common.ret

b28:                                              ; preds = %b0
  br label %common.ret

b31:                                              ; preds = %b0
  br label %common.ret

b34:                                              ; preds = %b0
  br label %common.ret

b36:                                              ; preds = %b0
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.9 @liza___liza_reactor_status(i64 %p0) local_unnamed_addr #2 {
b0:
  %v3 = icmp ult i64 %p0, 4294967296
  br i1 %v3, label %b1, label %v8_ok

common.ret:                                       ; preds = %liza___liza_reactor_error.exit, %b1
  %common.ret.op = phi %variant.9 [ %v5, %b1 ], [ %v10, %liza___liza_reactor_error.exit ]
  ret %variant.9 %common.ret.op

b1:                                               ; preds = %b0
  %v4 = trunc nuw i64 %p0 to i32
  %v5 = insertvalue %variant.9 zeroinitializer, i32 %v4, 1
  br label %common.ret

v8_ok:                                            ; preds = %b0
  %v1 = lshr i64 %p0, 32
  %v8 = trunc nuw i64 %v1 to i32
  switch i32 %v8, label %b36.i [
    i32 1, label %liza___liza_reactor_error.exit
    i32 2, label %b4.i
    i32 3, label %b7.i
    i32 4, label %b10.i
    i32 5, label %b13.i
    i32 6, label %b16.i
    i32 12, label %b34.i
    i32 8, label %b22.i
    i32 9, label %b25.i
    i32 10, label %b28.i
    i32 11, label %b31.i
  ]

b4.i:                                             ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b7.i:                                             ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b10.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b13.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b16.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b22.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b25.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b28.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b31.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b34.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

b36.i:                                            ; preds = %v8_ok
  br label %liza___liza_reactor_error.exit

liza___liza_reactor_error.exit:                   ; preds = %v8_ok, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b22.i, %b25.i, %b28.i, %b31.i, %b34.i, %b36.i
  %common.ret.op.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i ], [ zeroinitializer, %v8_ok ]
  %v10 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i, 2
  br label %common.ret
}

define %variant.10 @liza_net.reactor_create(i16 %p0, i32 %p1) local_unnamed_addr {
b0:
  %out.i = alloca ptr, align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %out.i)
  %code.i = call i32 @liza_rt_reactor_create(i16 %p0, i32 %p1, ptr nonnull %out.i)
  %value.i = load ptr, ptr %out.i, align 8
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %out.i)
  switch i32 %code.i, label %b36.i [
    i32 0, label %b1
    i32 1, label %liza___liza_reactor_error.exit
    i32 2, label %b4.i
    i32 3, label %b7.i
    i32 4, label %b10.i
    i32 5, label %b13.i
    i32 6, label %b16.i
    i32 12, label %b34.i
    i32 8, label %b22.i
    i32 9, label %b25.i
    i32 10, label %b28.i
    i32 11, label %b31.i
  ]

common.ret:                                       ; preds = %liza___liza_reactor_error.exit, %b1
  %common.ret.op = phi %variant.10 [ %v5, %b1 ], [ %v8, %liza___liza_reactor_error.exit ]
  ret %variant.10 %common.ret.op

b1:                                               ; preds = %b0
  %v5 = insertvalue %variant.10 zeroinitializer, ptr %value.i, 1
  br label %common.ret

b4.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b7.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b10.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b13.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b16.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b22.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b25.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b28.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b31.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b34.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b36.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

liza___liza_reactor_error.exit:                   ; preds = %b0, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b22.i, %b25.i, %b28.i, %b31.i, %b34.i, %b36.i
  %common.ret.op.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i ], [ zeroinitializer, %b0 ]
  %v8 = insertvalue %variant.10 { i32 1, ptr null, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i, 2
  br label %common.ret
}

define %variant.11 @liza_net.reactor_accept(ptr %p0) local_unnamed_addr {
b0:
  %out.i = alloca [3 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %out.i)
  %code.i = call i32 @liza_rt_reactor_accept(ptr %p0, ptr nonnull %out.i)
  %value.fca.0.load.i = load i64, ptr %out.i, align 8
  %value.fca.1.gep.i = getelementptr inbounds nuw i8, ptr %out.i, i64 8
  %value.fca.1.load.i = load i64, ptr %value.fca.1.gep.i, align 8
  %value.fca.2.gep.i = getelementptr inbounds nuw i8, ptr %out.i, i64 16
  %value.fca.2.load.i = load i64, ptr %value.fca.2.gep.i, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %out.i)
  switch i32 %code.i, label %b36.i [
    i32 0, label %b1
    i32 1, label %liza___liza_reactor_error.exit
    i32 2, label %b4.i
    i32 3, label %b7.i
    i32 4, label %b10.i
    i32 5, label %b13.i
    i32 6, label %b16.i
    i32 12, label %b34.i
    i32 8, label %b22.i
    i32 9, label %b25.i
    i32 10, label %b28.i
    i32 11, label %b31.i
  ]

common.ret:                                       ; preds = %liza___liza_reactor_error.exit, %b1
  %common.ret.op = phi %variant.11 [ %v5, %b1 ], [ %v8, %liza___liza_reactor_error.exit ]
  ret %variant.11 %common.ret.op

b1:                                               ; preds = %b0
  %value.fca.0.insert.i = insertvalue [3 x i64] poison, i64 %value.fca.0.load.i, 0
  %value.fca.1.insert.i = insertvalue [3 x i64] %value.fca.0.insert.i, i64 %value.fca.1.load.i, 1
  %value.fca.2.insert.i = insertvalue [3 x i64] %value.fca.1.insert.i, i64 %value.fca.2.load.i, 2
  %v5 = insertvalue %variant.11 zeroinitializer, [3 x i64] %value.fca.2.insert.i, 1
  br label %common.ret

b4.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b7.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b10.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b13.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b16.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b22.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b25.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b28.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b31.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b34.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b36.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

liza___liza_reactor_error.exit:                   ; preds = %b0, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b22.i, %b25.i, %b28.i, %b31.i, %b34.i, %b36.i
  %common.ret.op.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i ], [ zeroinitializer, %b0 ]
  %v8 = insertvalue %variant.11 { i32 1, [3 x i64] zeroinitializer, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i, 2
  br label %common.ret
}

define %variant.9 @liza_net.reactor_close(ptr %p0) local_unnamed_addr {
b0:
  %raw.i = tail call i32 @liza_rt_reactor_close(ptr %p0)
  switch i32 %raw.i, label %b36.i [
    i32 0, label %common.ret
    i32 1, label %liza___liza_reactor_error.exit
    i32 2, label %b4.i
    i32 3, label %b7.i
    i32 4, label %b10.i
    i32 5, label %b13.i
    i32 6, label %b16.i
    i32 12, label %b34.i
    i32 8, label %b22.i
    i32 9, label %b25.i
    i32 10, label %b28.i
    i32 11, label %b31.i
  ]

common.ret:                                       ; preds = %b0, %liza___liza_reactor_error.exit
  %common.ret.op = phi %variant.9 [ %v6, %liza___liza_reactor_error.exit ], [ zeroinitializer, %b0 ]
  ret %variant.9 %common.ret.op

b4.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b7.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b10.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b13.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b16.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b22.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b25.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b28.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b31.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b34.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b36.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

liza___liza_reactor_error.exit:                   ; preds = %b0, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b22.i, %b25.i, %b28.i, %b31.i, %b34.i, %b36.i
  %common.ret.op.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i ], [ zeroinitializer, %b0 ]
  %v6 = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i, 2
  br label %common.ret
}

define %variant.9 @liza_net.reactor_port(ptr %p0) local_unnamed_addr {
b0:
  %raw.i = tail call i64 @liza_rt_reactor_port(ptr %p0)
  %v3.i = icmp ult i64 %raw.i, 4294967296
  br i1 %v3.i, label %b1.i, label %v8_ok.i

b1.i:                                             ; preds = %b0
  %v4.i = trunc nuw i64 %raw.i to i32
  %v5.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i, 1
  br label %liza___liza_reactor_status.exit

v8_ok.i:                                          ; preds = %b0
  %v1.i = lshr i64 %raw.i, 32
  %v8.i = trunc nuw i64 %v1.i to i32
  switch i32 %v8.i, label %b36.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i
    i32 3, label %b7.i.i
    i32 4, label %b10.i.i
    i32 5, label %b13.i.i
    i32 6, label %b16.i.i
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b4.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b7.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b10.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b13.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b16.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i, %b13.i.i, %b10.i.i, %b7.i.i, %b4.i.i, %v8_ok.i
  %common.ret.op.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %v8_ok.i ]
  %v10.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i, 2
  br label %liza___liza_reactor_status.exit

liza___liza_reactor_status.exit:                  ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.9 [ %v5.i, %b1.i ], [ %v10.i, %liza___liza_reactor_error.exit.i ]
  ret %variant.9 %common.ret.op.i
}

define %variant.9 @liza_net.reactor_poll(ptr %p0, i32 %p1) local_unnamed_addr {
b0:
  %raw.i = tail call i64 @liza_rt_reactor_poll(ptr %p0, i32 %p1)
  %v3.i = icmp ult i64 %raw.i, 4294967296
  br i1 %v3.i, label %b1.i, label %v8_ok.i

b1.i:                                             ; preds = %b0
  %v4.i = trunc nuw i64 %raw.i to i32
  %v5.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i, 1
  br label %liza___liza_reactor_status.exit

v8_ok.i:                                          ; preds = %b0
  %v1.i = lshr i64 %raw.i, 32
  %v8.i = trunc nuw i64 %v1.i to i32
  switch i32 %v8.i, label %b36.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i
    i32 3, label %b7.i.i
    i32 4, label %b10.i.i
    i32 5, label %b13.i.i
    i32 6, label %b16.i.i
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b4.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b7.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b10.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b13.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b16.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i, %b13.i.i, %b10.i.i, %b7.i.i, %b4.i.i, %v8_ok.i
  %common.ret.op.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %v8_ok.i ]
  %v10.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i, 2
  br label %liza___liza_reactor_status.exit

liza___liza_reactor_status.exit:                  ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.9 [ %v5.i, %b1.i ], [ %v10.i, %liza___liza_reactor_error.exit.i ]
  ret %variant.9 %common.ret.op.i
}

define %variant.9 @liza_net.reactor_interest(ptr %p0, [3 x i64] %p1, i32 %p2) local_unnamed_addr {
b0:
  %id0.i = extractvalue [3 x i64] %p1, 0
  %id1.i = extractvalue [3 x i64] %p1, 1
  %id2.i = extractvalue [3 x i64] %p1, 2
  %raw.i = tail call i64 @liza_rt_reactor_interest(ptr %p0, i64 %id0.i, i64 %id1.i, i64 %id2.i, i32 %p2)
  %v3.i = icmp ult i64 %raw.i, 4294967296
  br i1 %v3.i, label %b1.i, label %v8_ok.i

b1.i:                                             ; preds = %b0
  %v4.i = trunc nuw i64 %raw.i to i32
  %v5.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i, 1
  br label %liza___liza_reactor_status.exit

v8_ok.i:                                          ; preds = %b0
  %v1.i = lshr i64 %raw.i, 32
  %v8.i = trunc nuw i64 %v1.i to i32
  switch i32 %v8.i, label %b36.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i
    i32 3, label %b7.i.i
    i32 4, label %b10.i.i
    i32 5, label %b13.i.i
    i32 6, label %b16.i.i
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b4.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b7.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b10.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b13.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b16.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i, %b13.i.i, %b10.i.i, %b7.i.i, %b4.i.i, %v8_ok.i
  %common.ret.op.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %v8_ok.i ]
  %v10.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i, 2
  br label %liza___liza_reactor_status.exit

liza___liza_reactor_status.exit:                  ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.9 [ %v5.i, %b1.i ], [ %v10.i, %liza___liza_reactor_error.exit.i ]
  ret %variant.9 %common.ret.op.i
}

define %variant.9 @liza_net.reactor_ready(ptr %p0, [3 x i64] %p1) local_unnamed_addr {
b0:
  %id0.i = extractvalue [3 x i64] %p1, 0
  %id1.i = extractvalue [3 x i64] %p1, 1
  %id2.i = extractvalue [3 x i64] %p1, 2
  %raw.i = tail call i64 @liza_rt_reactor_ready(ptr %p0, i64 %id0.i, i64 %id1.i, i64 %id2.i)
  %v3.i = icmp ult i64 %raw.i, 4294967296
  br i1 %v3.i, label %b1.i, label %v8_ok.i

b1.i:                                             ; preds = %b0
  %v4.i = trunc nuw i64 %raw.i to i32
  %v5.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i, 1
  br label %liza___liza_reactor_status.exit

v8_ok.i:                                          ; preds = %b0
  %v1.i = lshr i64 %raw.i, 32
  %v8.i = trunc nuw i64 %v1.i to i32
  switch i32 %v8.i, label %b36.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i
    i32 3, label %b7.i.i
    i32 4, label %b10.i.i
    i32 5, label %b13.i.i
    i32 6, label %b16.i.i
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b4.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b7.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b10.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b13.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b16.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i, %b13.i.i, %b10.i.i, %b7.i.i, %b4.i.i, %v8_ok.i
  %common.ret.op.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %v8_ok.i ]
  %v10.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i, 2
  br label %liza___liza_reactor_status.exit

liza___liza_reactor_status.exit:                  ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.9 [ %v5.i, %b1.i ], [ %v10.i, %liza___liza_reactor_error.exit.i ]
  ret %variant.9 %common.ret.op.i
}

define %variant.9 @liza_net.reactor_disconnect(ptr %p0, [3 x i64] %p1) local_unnamed_addr {
b0:
  %id0.i = extractvalue [3 x i64] %p1, 0
  %id1.i = extractvalue [3 x i64] %p1, 1
  %id2.i = extractvalue [3 x i64] %p1, 2
  %raw.i = tail call i64 @liza_rt_reactor_disconnect(ptr %p0, i64 %id0.i, i64 %id1.i, i64 %id2.i)
  %v3.i = icmp ult i64 %raw.i, 4294967296
  br i1 %v3.i, label %b1.i, label %v8_ok.i

b1.i:                                             ; preds = %b0
  %v4.i = trunc nuw i64 %raw.i to i32
  %v5.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i, 1
  br label %liza___liza_reactor_status.exit

v8_ok.i:                                          ; preds = %b0
  %v1.i = lshr i64 %raw.i, 32
  %v8.i = trunc nuw i64 %v1.i to i32
  switch i32 %v8.i, label %b36.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i
    i32 3, label %b7.i.i
    i32 4, label %b10.i.i
    i32 5, label %b13.i.i
    i32 6, label %b16.i.i
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b4.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b7.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b10.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b13.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b16.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i, %b13.i.i, %b10.i.i, %b7.i.i, %b4.i.i, %v8_ok.i
  %common.ret.op.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %v8_ok.i ]
  %v10.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i, 2
  br label %liza___liza_reactor_status.exit

liza___liza_reactor_status.exit:                  ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.9 [ %v5.i, %b1.i ], [ %v10.i, %liza___liza_reactor_error.exit.i ]
  ret %variant.9 %common.ret.op.i
}

define %variant.9 @liza_net.reactor_write(ptr %p0, [3 x i64] %p1, { ptr, i32 } %p2, i32 %p3, i32 %p4) local_unnamed_addr {
b0:
  %id0.i = extractvalue [3 x i64] %p1, 0
  %id1.i = extractvalue [3 x i64] %p1, 1
  %id2.i = extractvalue [3 x i64] %p1, 2
  %p.i = extractvalue { ptr, i32 } %p2, 0
  %n.i = extractvalue { ptr, i32 } %p2, 1
  %raw.i = tail call i64 @liza_rt_reactor_write(ptr %p0, i64 %id0.i, i64 %id1.i, i64 %id2.i, ptr %p.i, i32 %n.i, i32 %p3, i32 %p4)
  %v3.i = icmp ult i64 %raw.i, 4294967296
  br i1 %v3.i, label %b1.i, label %v8_ok.i

b1.i:                                             ; preds = %b0
  %v4.i = trunc nuw i64 %raw.i to i32
  %v5.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i, 1
  br label %liza___liza_reactor_status.exit

v8_ok.i:                                          ; preds = %b0
  %v1.i = lshr i64 %raw.i, 32
  %v8.i = trunc nuw i64 %v1.i to i32
  switch i32 %v8.i, label %b36.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i
    i32 3, label %b7.i.i
    i32 4, label %b10.i.i
    i32 5, label %b13.i.i
    i32 6, label %b16.i.i
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b4.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b7.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b10.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b13.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b16.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i, %b13.i.i, %b10.i.i, %b7.i.i, %b4.i.i, %v8_ok.i
  %common.ret.op.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %v8_ok.i ]
  %v10.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i, 2
  br label %liza___liza_reactor_status.exit

liza___liza_reactor_status.exit:                  ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.9 [ %v5.i, %b1.i ], [ %v10.i, %liza___liza_reactor_error.exit.i ]
  ret %variant.9 %common.ret.op.i
}

define %variant.11 @liza_net.reactor_connect(ptr %p0, i16 %p1) local_unnamed_addr {
b0:
  %out.i = alloca [3 x i64], align 8
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %out.i)
  %code.i = call i32 @liza_rt_reactor_connect(ptr %p0, i16 %p1, ptr nonnull %out.i)
  %value.fca.0.load.i = load i64, ptr %out.i, align 8
  %value.fca.1.gep.i = getelementptr inbounds nuw i8, ptr %out.i, i64 8
  %value.fca.1.load.i = load i64, ptr %value.fca.1.gep.i, align 8
  %value.fca.2.gep.i = getelementptr inbounds nuw i8, ptr %out.i, i64 16
  %value.fca.2.load.i = load i64, ptr %value.fca.2.gep.i, align 8
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %out.i)
  switch i32 %code.i, label %b36.i [
    i32 0, label %b1
    i32 1, label %liza___liza_reactor_error.exit
    i32 2, label %b4.i
    i32 3, label %b7.i
    i32 4, label %b10.i
    i32 5, label %b13.i
    i32 6, label %b16.i
    i32 12, label %b34.i
    i32 8, label %b22.i
    i32 9, label %b25.i
    i32 10, label %b28.i
    i32 11, label %b31.i
  ]

common.ret:                                       ; preds = %liza___liza_reactor_error.exit, %b1
  %common.ret.op = phi %variant.11 [ %v5, %b1 ], [ %v8, %liza___liza_reactor_error.exit ]
  ret %variant.11 %common.ret.op

b1:                                               ; preds = %b0
  %value.fca.0.insert.i = insertvalue [3 x i64] poison, i64 %value.fca.0.load.i, 0
  %value.fca.1.insert.i = insertvalue [3 x i64] %value.fca.0.insert.i, i64 %value.fca.1.load.i, 1
  %value.fca.2.insert.i = insertvalue [3 x i64] %value.fca.1.insert.i, i64 %value.fca.2.load.i, 2
  %v5 = insertvalue %variant.11 zeroinitializer, [3 x i64] %value.fca.2.insert.i, 1
  br label %common.ret

b4.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b7.i:                                             ; preds = %b0
  br label %liza___liza_reactor_error.exit

b10.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b13.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b16.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b22.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b25.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b28.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b31.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b34.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

b36.i:                                            ; preds = %b0
  br label %liza___liza_reactor_error.exit

liza___liza_reactor_error.exit:                   ; preds = %b0, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b22.i, %b25.i, %b28.i, %b31.i, %b34.i, %b36.i
  %common.ret.op.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i ], [ zeroinitializer, %b0 ]
  %v8 = insertvalue %variant.11 { i32 1, [3 x i64] zeroinitializer, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i, 2
  br label %common.ret
}

define %variant.12 @liza_net.reactor_finish_connect(ptr %p0, [3 x i64] %p1) local_unnamed_addr {
b0:
  %id0.i = extractvalue [3 x i64] %p1, 0
  %id1.i = extractvalue [3 x i64] %p1, 1
  %id2.i = extractvalue [3 x i64] %p1, 2
  %raw.i = tail call i64 @liza_rt_reactor_finish_connect(ptr %p0, i64 %id0.i, i64 %id1.i, i64 %id2.i)
  %v4 = icmp ult i64 %raw.i, 4294967296
  br i1 %v4, label %b1, label %v10_ok

common.ret:                                       ; preds = %liza___liza_reactor_error.exit, %b1
  %common.ret.op = phi %variant.12 [ %v7, %b1 ], [ %v12, %liza___liza_reactor_error.exit ]
  ret %variant.12 %common.ret.op

b1:                                               ; preds = %b0
  %v6 = icmp eq i64 %raw.i, 1
  %v7 = insertvalue %variant.12 zeroinitializer, i1 %v6, 1
  br label %common.ret

v10_ok:                                           ; preds = %b0
  %v2 = lshr i64 %raw.i, 32
  %v10 = trunc nuw i64 %v2 to i32
  switch i32 %v10, label %b36.i [
    i32 1, label %liza___liza_reactor_error.exit
    i32 2, label %b4.i
    i32 3, label %b7.i
    i32 4, label %b10.i
    i32 5, label %b13.i
    i32 6, label %b16.i
    i32 12, label %b34.i
    i32 8, label %b22.i
    i32 9, label %b25.i
    i32 10, label %b28.i
    i32 11, label %b31.i
  ]

b4.i:                                             ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b7.i:                                             ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b10.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b13.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b16.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b22.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b25.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b28.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b31.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b34.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

b36.i:                                            ; preds = %v10_ok
  br label %liza___liza_reactor_error.exit

liza___liza_reactor_error.exit:                   ; preds = %v10_ok, %b4.i, %b7.i, %b10.i, %b13.i, %b16.i, %b22.i, %b25.i, %b28.i, %b31.i, %b34.i, %b36.i
  %common.ret.op.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i ], [ zeroinitializer, %v10_ok ]
  %v12 = insertvalue %variant.12 { i32 1, i1 false, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i, 2
  br label %common.ret
}

define %variant.9 @liza_net.reactor_shutdown_write(ptr %p0, [3 x i64] %p1) local_unnamed_addr {
b0:
  %id0.i = extractvalue [3 x i64] %p1, 0
  %id1.i = extractvalue [3 x i64] %p1, 1
  %id2.i = extractvalue [3 x i64] %p1, 2
  %raw.i = tail call i64 @liza_rt_reactor_shutdown_write(ptr %p0, i64 %id0.i, i64 %id1.i, i64 %id2.i)
  %v3.i = icmp ult i64 %raw.i, 4294967296
  br i1 %v3.i, label %b1.i, label %v8_ok.i

b1.i:                                             ; preds = %b0
  %v4.i = trunc nuw i64 %raw.i to i32
  %v5.i = insertvalue %variant.9 zeroinitializer, i32 %v4.i, 1
  br label %liza___liza_reactor_status.exit

v8_ok.i:                                          ; preds = %b0
  %v1.i = lshr i64 %raw.i, 32
  %v8.i = trunc nuw i64 %v1.i to i32
  switch i32 %v8.i, label %b36.i.i [
    i32 1, label %liza___liza_reactor_error.exit.i
    i32 2, label %b4.i.i
    i32 3, label %b7.i.i
    i32 4, label %b10.i.i
    i32 5, label %b13.i.i
    i32 6, label %b16.i.i
    i32 12, label %b34.i.i
    i32 8, label %b22.i.i
    i32 9, label %b25.i.i
    i32 10, label %b28.i.i
    i32 11, label %b31.i.i
  ]

b4.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b7.i.i:                                           ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b10.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b13.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b16.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b22.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b25.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b28.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b31.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b34.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

b36.i.i:                                          ; preds = %v8_ok.i
  br label %liza___liza_reactor_error.exit.i

liza___liza_reactor_error.exit.i:                 ; preds = %b36.i.i, %b34.i.i, %b31.i.i, %b28.i.i, %b25.i.i, %b22.i.i, %b16.i.i, %b13.i.i, %b10.i.i, %b7.i.i, %b4.i.i, %v8_ok.i
  %common.ret.op.i.i = phi %variant.5 [ { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b4.i.i ], [ { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b7.i.i ], [ { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b10.i.i ], [ { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b13.i.i ], [ { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b16.i.i ], [ { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b22.i.i ], [ { i32 8, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b25.i.i ], [ { i32 9, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b28.i.i ], [ { i32 10, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b31.i.i ], [ { i32 11, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b34.i.i ], [ { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %b36.i.i ], [ zeroinitializer, %v8_ok.i ]
  %v10.i = insertvalue %variant.9 { i32 1, i32 0, %variant.5 zeroinitializer }, %variant.5 %common.ret.op.i.i, 2
  br label %liza___liza_reactor_status.exit

liza___liza_reactor_status.exit:                  ; preds = %b1.i, %liza___liza_reactor_error.exit.i
  %common.ret.op.i = phi %variant.9 [ %v5.i, %b1.i ], [ %v10.i, %liza___liza_reactor_error.exit.i ]
  ret %variant.9 %common.ret.op.i
}

declare void @liza_rt_cli_init(i32, ptr) local_unnamed_addr

define range(i32 0, 4) i32 @main(i32 %argc, ptr %argv) local_unnamed_addr {
entry:
  tail call void @liza_rt_cli_init(i32 %argc, ptr %argv)
  %result = tail call i32 @liza_main()
  ret i32 %result
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #6

attributes #0 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
attributes #3 = { nounwind memory(inaccessiblemem: write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: write) }
