	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza___liza_write_text         ; -- Begin function liza___liza_write_text
	.p2align	2
_liza___liza_write_text:                ; @liza___liza_write_text
	.cfi_startproc
; %bb.0:
	b	_liza_rt_write_text
	.cfi_endproc
                                        ; -- End function
	.globl	_liza___liza_print_u64          ; -- Begin function liza___liza_print_u64
	.p2align	2
_liza___liza_print_u64:                 ; @liza___liza_print_u64
	.cfi_startproc
; %bb.0:
	b	_liza_rt_print_u64
	.cfi_endproc
                                        ; -- End function
	.globl	_liza___liza_err_text           ; -- Begin function liza___liza_err_text
	.p2align	2
_liza___liza_err_text:                  ; @liza___liza_err_text
	.cfi_startproc
; %bb.0:
	b	_liza_rt_err_text
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_relay.direction.empty     ; -- Begin function liza_relay.direction.empty
	.p2align	2
_liza_relay.direction.empty:            ; @liza_relay.direction.empty
; %bb.0:                                ; %b0
	mov	w0, wzr
	mov	w1, wzr
	mov	w2, wzr
	mov	w3, wzr
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.valid     ; -- Begin function liza_relay.direction.valid
	.p2align	2
_liza_relay.direction.valid:            ; @liza_relay.direction.valid
; %bb.0:                                ; %b0
	mov	w8, w0
	cmp	w0, w1
	mov	w0, wzr
	b.hi	LBB4_4
; %bb.1:                                ; %b0
	cmp	w1, #2048
	b.hi	LBB4_4
; %bb.2:                                ; %b4
	tbz	w3, #0, LBB4_5
; %bb.3:                                ; %b6
	cmp	w8, w1
	cset	w8, eq
	and	w0, w2, w8
LBB4_4:                                 ; %b12
	ret
LBB4_5:
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.readable  ; -- Begin function liza_relay.direction.readable
	.p2align	2
_liza_relay.direction.readable:         ; @liza_relay.direction.readable
; %bb.0:                                ; %b0
	mov	w8, w0
	cmp	w0, w1
	mov	w0, wzr
	b.hi	LBB5_6
; %bb.1:                                ; %b0
	cmp	w1, #2048
	b.hi	LBB5_6
; %bb.2:                                ; %b4.i
	cmp	w8, w1
	cset	w8, eq
	tbz	w3, #0, LBB5_5
; %bb.3:                                ; %b4.i
	and	w8, w2, w8
	cbnz	w8, LBB5_5
; %bb.4:
	mov	w0, wzr
	ret
LBB5_5:                                 ; %b1
	mov	w8, #2048                       ; =0x800
	tst	w2, #0x1
	sub	w8, w8, w1
	csel	w0, wzr, w8, ne
LBB5_6:                                 ; %common.ret
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.queued    ; -- Begin function liza_relay.direction.queued
	.p2align	2
_liza_relay.direction.queued:           ; @liza_relay.direction.queued
; %bb.0:                                ; %b0
	cmp	w0, w1
	mov	w8, wzr
	b.hi	LBB6_6
; %bb.1:                                ; %b0
	cmp	w1, #2048
	b.hi	LBB6_6
; %bb.2:                                ; %b4.i
	cmp	w0, w1
	cset	w8, eq
	tbz	w3, #0, LBB6_5
; %bb.3:                                ; %b4.i
	and	w8, w2, w8
	tbnz	w8, #0, LBB6_5
; %bb.4:
	mov	w8, wzr
	mov	w0, w8
	ret
LBB6_5:                                 ; %b3
	subs	w8, w1, w0
	b.lo	LBB6_7
LBB6_6:                                 ; %common.ret
	mov	w0, w8
	ret
LBB6_7:                                 ; %v5_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_relay.direction.read      ; -- Begin function liza_relay.direction.read
	.p2align	2
_liza_relay.direction.read:             ; @liza_relay.direction.read
; %bb.0:                                ; %b0
	mov	w9, w1
	mov	w8, w0
	mov	w1, wzr
	cmp	w0, w9
	mov	w0, #1                          ; =0x1
	b.hi	LBB7_9
; %bb.1:                                ; %b0
	mov	w10, w2
	cmp	w9, #2048
	mov	w2, w1
	mov	w11, w1
	mov	w12, w1
	mov	w5, w1
	b.hi	LBB7_10
; %bb.2:                                ; %b4.i
	cmp	w8, w9
	cset	w11, eq
	tbz	w3, #0, LBB7_5
; %bb.3:                                ; %b4.i
	and	w11, w10, w11
	cbnz	w11, LBB7_5
; %bb.4:
	mov	w1, wzr
	mov	w2, wzr
	mov	w12, wzr
	mov	w5, wzr
	b	LBB7_10
LBB7_5:                                 ; %b1
	mov	w11, #2048                      ; =0x800
	orr	w10, w3, w10
	mov	w1, wzr
	subs	w11, w11, w9
	cset	w12, eq
	orr	w10, w10, w12
	tbnz	w10, #0, LBB7_9
; %bb.6:                                ; %b1
	cmp	w4, w11
	mov	w2, w1
	mov	w11, w1
	mov	w12, w1
	mov	w5, w1
	b.hi	LBB7_10
; %bb.7:                                ; %b12
	mov	w0, wzr
	cbz	w4, LBB7_11
; %bb.8:                                ; %v26_ok
	mov	w11, wzr
	mov	w12, wzr
	mov	w5, wzr
	add	w2, w9, w4
	mov	w1, w8
	b	LBB7_10
LBB7_9:
	mov	w2, w1
	mov	w11, w1
	mov	w12, w1
	mov	w5, w1
LBB7_10:                                ; %common.ret
	and	w3, w11, #0x1
	and	w4, w12, #0x1
	ret
LBB7_11:                                ; %b13
	mov	w12, wzr
	mov	w5, wzr
	mov	w11, #1                         ; =0x1
	mov	w1, w8
	mov	w2, w9
	b	LBB7_10
                                        ; -- End function
	.globl	_liza_relay.direction.write     ; -- Begin function liza_relay.direction.write
	.p2align	2
_liza_relay.direction.write:            ; @liza_relay.direction.write
; %bb.0:                                ; %b0
	mov	w8, w1
	mov	w9, w0
	mov	w1, wzr
	cmp	w0, w8
	mov	w0, #1                          ; =0x1
	b.hi	LBB8_4
; %bb.1:                                ; %b0
	cmp	w8, #2048
	mov	w6, w1
	mov	w10, w1
	mov	w11, w1
	mov	w5, w1
	b.hi	LBB8_19
; %bb.2:                                ; %b4.i
	tbz	w3, #0, LBB8_5
; %bb.3:                                ; %b6.i
	cmp	w9, w8
	cset	w10, eq
	and	w10, w2, w10
	mov	w1, wzr
	cbnz	w10, LBB8_6
LBB8_4:
	mov	w6, w1
	mov	w10, w1
	mov	w11, w1
	mov	w5, w1
	b	LBB8_19
LBB8_5:
	mov	w10, #1                         ; =0x1
	mov	w1, wzr
	cbz	w10, LBB8_4
LBB8_6:                                 ; %liza_relay.direction.valid.exit
	mov	w6, w1
	mov	w10, w1
	mov	w11, w1
	mov	w5, w1
	cbz	w4, LBB8_19
; %bb.7:                                ; %b4.i.i
	cmp	w9, w8
	cset	w10, eq
	tbz	w3, #0, LBB8_10
; %bb.8:                                ; %b4.i.i
	and	w10, w2, w10
	cbnz	w10, LBB8_10
; %bb.9:
	mov	w1, wzr
	mov	w6, wzr
	b	LBB8_13
LBB8_10:                                ; %b3.i
	subs	w10, w8, w9
	b.lo	LBB8_20
; %bb.11:                               ; %liza_relay.direction.queued.exit
	cmp	w4, w10
	b.ls	LBB8_14
; %bb.12:
	mov	w1, wzr
	mov	w6, wzr
	mov	w10, wzr
LBB8_13:                                ; %common.ret
	mov	w11, wzr
	mov	w5, wzr
	b	LBB8_19
LBB8_14:                                ; %b9
	adds	w1, w9, w4
	b.hs	LBB8_20
; %bb.15:                               ; %v13_ok
	cmp	w1, w8
	b.ne	LBB8_17
; %bb.16:                               ; %b10
	mov	w0, wzr
	mov	w1, wzr
	mov	w6, wzr
	mov	w5, wzr
	b	LBB8_18
LBB8_17:                                ; %b12
	mov	w0, wzr
	mov	w5, wzr
	mov	w6, w8
LBB8_18:                                ; %common.ret
	mov	w10, w2
	mov	w11, w3
LBB8_19:                                ; %common.ret
	and	w3, w10, #0x1
	and	w4, w11, #0x1
	mov	w2, w6
	ret
LBB8_20:                                ; %v5_trap.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza_relay.direction.needs_fin ; -- Begin function liza_relay.direction.needs_fin
	.p2align	2
_liza_relay.direction.needs_fin:        ; @liza_relay.direction.needs_fin
; %bb.0:                                ; %b0
	cmp	w0, w1
	eor	w8, w3, #0x1
	cset	w9, ls
	cset	w10, eq
	cmp	w1, #2049
	csel	w9, wzr, w9, hs
	and	w10, w2, w10
	and	w9, w9, w10
	and	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.shutdown  ; -- Begin function liza_relay.direction.shutdown
	.p2align	2
_liza_relay.direction.shutdown:         ; @liza_relay.direction.shutdown
; %bb.0:                                ; %b0
	mov	w9, w1
	mov	w8, w0
	mov	w1, wzr
	cmp	w0, w9
	mov	w0, #1                          ; =0x1
	b.hi	LBB10_6
; %bb.1:                                ; %b0
	cmp	w9, #2048
	mov	w10, w1
	mov	w5, w1
	b.hi	LBB10_7
; %bb.2:                                ; %b4.i.i
	mov	w1, wzr
	tbnz	w3, #0, LBB10_6
; %bb.3:                                ; %b4.i.i
	tbz	w2, #0, LBB10_6
; %bb.4:                                ; %b4.i.i
	cmp	w8, w9
	mov	w10, w1
	mov	w5, w1
	b.ne	LBB10_7
; %bb.5:                                ; %b3
	mov	w0, wzr
	mov	w5, wzr
	mov	w10, #1                         ; =0x1
	mov	w1, w8
	b	LBB10_7
LBB10_6:
	mov	w10, w1
	mov	w5, w1
LBB10_7:                                ; %common.ret
	and	w3, w10, #0x1
	and	w4, w10, #0x1
	mov	w2, w1
	ret
                                        ; -- End function
	.globl	_liza_liza_proxy.empty_pair     ; -- Begin function liza_liza_proxy.empty_pair
	.p2align	2
_liza_liza_proxy.empty_pair:            ; @liza_liza_proxy.empty_pair
; %bb.0:                                ; %b0
	movi.2d	v0, #0000000000000000
	mov	w9, #1                          ; =0x1
	strh	wzr, [x8, #88]
	str	xzr, [x8, #80]
	strh	wzr, [x8, #76]
	stur	xzr, [x8, #68]
	strb	wzr, [x8, #64]
	str	xzr, [x8, #56]
	stur	q0, [x8, #40]
	str	w9, [x8, #32]
	str	xzr, [x8, #24]
	stur	q0, [x8, #8]
	str	w9, [x8]
	ret
                                        ; -- End function
	.globl	_liza_liza_proxy.retry          ; -- Begin function liza_liza_proxy.retry
	.p2align	2
_liza_liza_proxy.retry:                 ; @liza_liza_proxy.retry
; %bb.0:                                ; %b0
	mov	w8, #268                        ; =0x10c
	lsr	w8, w8, w0
	and	w0, w8, #0x1
	ret
                                        ; -- End function
	.globl	_liza_liza_proxy.exchange       ; -- Begin function liza_liza_proxy.exchange
	.p2align	2
_liza_liza_proxy.exchange:              ; @liza_liza_proxy.exchange
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #464
	.cfi_def_cfa_offset 4720
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	add	x8, sp, #433
	str	w4, [sp, #412]                  ; 4-byte Folded Spill
	mov	x20, x0
	strb	wzr, [x8, #4095]
	add	x8, sp, #429
	strb	wzr, [x8, #4095]
	add	x8, sp, #428
	strb	wzr, [x8, #4095]
	add	x8, sp, #425
	strb	wzr, [x8, #4095]
	add	x8, sp, #424
	strb	wzr, [x8, #4095]
	add	x8, sp, #417
	strb	wzr, [x8, #4095]
	add	x8, sp, #413
	strb	wzr, [x8, #4095]
	add	x8, sp, #412
	strb	wzr, [x8, #4095]
	add	x8, sp, #409
	strb	wzr, [x8, #4095]
	add	x8, sp, #408
	strb	wzr, [x8, #4095]
	add	x8, sp, #401
	strb	wzr, [x8, #4095]
	add	x8, sp, #397
	strb	wzr, [x8, #4095]
	add	x8, sp, #396
	strb	wzr, [x8, #4095]
	add	x8, sp, #393
	strb	wzr, [x8, #4095]
	add	x8, sp, #392
	strb	wzr, [x8, #4095]
	add	x8, sp, #385
	strb	wzr, [x8, #4095]
	add	x8, sp, #381
	strb	wzr, [x8, #4095]
	add	x8, sp, #380
	strb	wzr, [x8, #4095]
	add	x8, sp, #377
	strb	wzr, [x8, #4095]
	add	x8, sp, #376
	strb	wzr, [x8, #4095]
	add	x8, sp, #369
	strb	wzr, [x8, #4095]
	add	x8, sp, #365
	strb	wzr, [x8, #4095]
	add	x8, sp, #364
	strb	wzr, [x8, #4095]
	add	x8, sp, #361
	strb	wzr, [x8, #4095]
	add	x8, sp, #360
	strb	wzr, [x8, #4095]
	add	x8, sp, #353
	strb	wzr, [x8, #4095]
	add	x8, sp, #349
	strb	wzr, [x8, #4095]
	add	x8, sp, #348
	strb	wzr, [x8, #4095]
	add	x8, sp, #345
	strb	wzr, [x8, #4095]
	add	x8, sp, #344
	strb	wzr, [x8, #4095]
	add	x8, sp, #337
	strb	wzr, [x8, #4095]
	add	x8, sp, #333
	strb	wzr, [x8, #4095]
	add	x8, sp, #332
	strb	wzr, [x8, #4095]
	add	x8, sp, #329
	strb	wzr, [x8, #4095]
	add	x8, sp, #328
	strb	wzr, [x8, #4095]
	add	x8, sp, #321
	strb	wzr, [x8, #4095]
	add	x8, sp, #317
	strb	wzr, [x8, #4095]
	add	x8, sp, #316
	strb	wzr, [x8, #4095]
	add	x8, sp, #313
	strb	wzr, [x8, #4095]
	add	x8, sp, #312
	str	w3, [sp, #140]                  ; 4-byte Folded Spill
	str	w2, [sp, #152]                  ; 4-byte Folded Spill
	str	x1, [sp, #144]                  ; 8-byte Folded Spill
	strb	wzr, [x8, #4095]
	bl	_liza_rt_reactor_port
	lsr	x8, x0, #32
	cbz	x8, LBB13_4
; %bb.1:                                ; %v8_ok.i.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_3
; %bb.2:                                ; %v8_ok.i.i
Lloh0:
	adrp	x9, lJTI13_0@PAGE
Lloh1:
	add	x9, x9, lJTI13_0@PAGEOFF
	adr	x10, LBB13_3
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_3:                                ; %liza___liza_reactor_error.exit.i.i
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB13_4:                                ; %liza_net.reactor_port.exit
	cmp	w8, #1
	b.ne	LBB13_6
; %bb.5:
	mov	w8, wzr
	mov	w21, #3                         ; =0x3
	str	x20, [sp, #720]                 ; 8-byte Folded Spill
	cbnz	w8, LBB13_23
	b	LBB13_318
LBB13_6:                                ; %v12_ok
	mov	w0, w0
	bl	_liza_rt_print_u64
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB13_10
; %bb.7:                                ; %v12_ok
	cbz	w8, LBB13_319
; %bb.8:                                ; %v12_ok
	cmp	w8, #1
	b.eq	LBB13_13
; %bb.9:                                ; %v12_ok
	cmp	w8, #2
	b	LBB13_13
LBB13_10:                               ; %v12_ok
	cmp	w8, #3
	b.eq	LBB13_13
; %bb.11:                               ; %v12_ok
	cmp	w8, #4
	b.eq	LBB13_13
; %bb.12:                               ; %v12_ok
	cmp	w8, #5
LBB13_13:                               ; %b18.i.i
	mov	w19, #1                         ; =0x1
LBB13_14:                               ; %liza_console.print_u64.exit
Lloh2:
	adrp	x0, l_text.liza_proxy.exchange.v21@PAGE
Lloh3:
	add	x0, x0, l_text.liza_proxy.exchange.v21@PAGEOFF
	mov	w1, #1                          ; =0x1
	bl	_liza_rt_write_text
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB13_18
; %bb.15:                               ; %liza_console.print_u64.exit
	cbz	w8, LBB13_22
; %bb.16:                               ; %liza_console.print_u64.exit
	cmp	w8, #1
	b.eq	LBB13_22
; %bb.17:                               ; %liza_console.print_u64.exit
	cmp	w8, #2
	b	LBB13_21
LBB13_18:                               ; %liza_console.print_u64.exit
	cmp	w8, #3
	b.eq	LBB13_21
; %bb.19:                               ; %liza_console.print_u64.exit
	cmp	w8, #4
	b.eq	LBB13_21
; %bb.20:                               ; %liza_console.print_u64.exit
	cmp	w8, #5
LBB13_21:                               ; %b18.i.i72
	mov	w8, #1                          ; =0x1
LBB13_22:                               ; %liza_console.write.exit
	orr	w8, w8, w19
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	cset	w8, eq
	csel	w21, wzr, w9, eq
	str	x20, [sp, #720]                 ; 8-byte Folded Spill
	cbz	w8, LBB13_318
LBB13_23:                               ; %b14.lr.ph
	add	x8, sp, #1600
	mov	w7, wzr
	str	w21, [sp, #1320]                ; 4-byte Folded Spill
	add	x9, x8, #65
	add	x10, x8, #474
	str	wzr, [sp, #1152]                ; 4-byte Folded Spill
	str	x9, [sp, #584]                  ; 8-byte Folded Spill
	add	x9, x8, #90
                                        ; implicit-def: $w20
                                        ; implicit-def: $w23
                                        ; implicit-def: $w28
                                        ; implicit-def: $w26
                                        ; implicit-def: $w27
                                        ; implicit-def: $w25
                                        ; implicit-def: $w22
                                        ; implicit-def: $w24
	str	x9, [sp, #576]                  ; 8-byte Folded Spill
	add	x9, x8, #161
	str	x9, [sp, #568]                  ; 8-byte Folded Spill
	add	x9, x8, #186
	str	x9, [sp, #560]                  ; 8-byte Folded Spill
	add	x9, x8, #257
	str	x9, [sp, #552]                  ; 8-byte Folded Spill
	add	x9, x8, #282
	str	x9, [sp, #544]                  ; 8-byte Folded Spill
	add	x9, x8, #353
	str	x9, [sp, #536]                  ; 8-byte Folded Spill
	add	x9, x8, #378
	str	x9, [sp, #528]                  ; 8-byte Folded Spill
	add	x9, x8, #449
	str	x9, [sp, #520]                  ; 8-byte Folded Spill
	add	x9, x8, #545
	stp	x9, x10, [sp, #504]             ; 16-byte Folded Spill
	add	x10, x8, #570
	add	x9, x8, #641
	stp	x9, x10, [sp, #488]             ; 16-byte Folded Spill
	add	x10, x8, #666
	add	x9, x8, #737
	add	x8, x8, #762
	stp	x9, x10, [sp, #472]             ; 16-byte Folded Spill
	add	x10, sp, #3472
	str	x8, [sp, #464]                  ; 8-byte Folded Spill
	add	x8, sp, #2416
	add	x11, x10, #65
	add	x4, x8, #260
	add	x8, sp, #312
	add	x9, sp, #1600
	ldrb	w8, [x8, #4095]
	add	x9, x9, #260
	add	x12, x4, #324
	str	x9, [sp, #456]                  ; 8-byte Folded Spill
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	add	x8, sp, #313
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1144]                ; 8-byte Folded Spill
	str	wzr, [sp, #1136]                ; 4-byte Folded Spill
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	add	x8, sp, #316
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #984]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1016]                ; 8-byte Folded Spill
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	add	x8, sp, #317
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1008]                ; 8-byte Folded Spill
	str	xzr, [sp, #1192]                ; 8-byte Folded Spill
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	add	x8, sp, #321
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1208]                ; 8-byte Folded Spill
	str	xzr, [sp, #1200]                ; 8-byte Folded Spill
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	add	x8, sp, #328
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1132]                ; 4-byte Folded Spill
	str	wzr, [sp, #1120]                ; 4-byte Folded Spill
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	add	x8, sp, #329
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1112]                ; 8-byte Folded Spill
	str	xzr, [sp, #952]                 ; 8-byte Folded Spill
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	add	x8, sp, #332
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #944]                 ; 8-byte Folded Spill
	str	xzr, [sp, #936]                 ; 8-byte Folded Spill
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	add	x8, sp, #333
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #976]                 ; 8-byte Folded Spill
	str	xzr, [sp, #968]                 ; 8-byte Folded Spill
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	add	x8, sp, #337
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #960]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1464]                ; 8-byte Folded Spill
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	add	x8, sp, #344
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1080]                ; 4-byte Folded Spill
	str	wzr, [sp, #1076]                ; 4-byte Folded Spill
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	add	x8, sp, #345
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #904]                 ; 8-byte Folded Spill
	str	xzr, [sp, #896]                 ; 8-byte Folded Spill
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	add	x8, sp, #348
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #888]                 ; 8-byte Folded Spill
	str	xzr, [sp, #928]                 ; 8-byte Folded Spill
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	add	x8, sp, #349
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #920]                 ; 8-byte Folded Spill
	str	xzr, [sp, #912]                 ; 8-byte Folded Spill
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	add	x8, sp, #353
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1184]                ; 8-byte Folded Spill
	str	wzr, [sp, #1176]                ; 4-byte Folded Spill
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	add	x8, sp, #360
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1480]                ; 8-byte Folded Spill
	str	xzr, [sp, #1472]                ; 8-byte Folded Spill
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	add	x8, sp, #361
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1432]                ; 8-byte Folded Spill
	str	xzr, [sp, #1440]                ; 8-byte Folded Spill
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	add	x8, sp, #364
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1448]                ; 8-byte Folded Spill
	str	xzr, [sp, #1456]                ; 8-byte Folded Spill
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	add	x8, sp, #365
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1168]                ; 4-byte Folded Spill
	str	xzr, [sp, #1160]                ; 8-byte Folded Spill
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	add	x8, sp, #369
	ldrb	w13, [x8, #4095]
	add	x8, sp, #376
	str	wzr, [sp, #1156]                ; 4-byte Folded Spill
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1064]                ; 8-byte Folded Spill
	str	xzr, [sp, #1056]                ; 8-byte Folded Spill
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	add	x8, sp, #377
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1048]                ; 8-byte Folded Spill
	str	xzr, [sp, #1104]                ; 8-byte Folded Spill
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	add	x8, sp, #380
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1096]                ; 8-byte Folded Spill
	str	xzr, [sp, #1088]                ; 8-byte Folded Spill
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	add	x8, sp, #381
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #240]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1296]                ; 8-byte Folded Spill
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	add	x8, sp, #385
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1288]                ; 8-byte Folded Spill
	str	xzr, [sp, #1280]                ; 8-byte Folded Spill
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	add	x8, sp, #392
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1272]                ; 8-byte Folded Spill
	str	xzr, [sp, #1248]                ; 8-byte Folded Spill
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	add	x8, sp, #393
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1240]                ; 4-byte Folded Spill
	str	wzr, [sp, #1232]                ; 4-byte Folded Spill
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	add	x8, sp, #396
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1224]                ; 4-byte Folded Spill
	str	wzr, [sp, #1220]                ; 4-byte Folded Spill
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	add	x8, sp, #397
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1040]                ; 8-byte Folded Spill
	str	xzr, [sp, #1032]                ; 8-byte Folded Spill
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	add	x8, sp, #401
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #848]                 ; 8-byte Folded Spill
	str	xzr, [sp, #840]                 ; 8-byte Folded Spill
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	add	x8, sp, #408
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #832]                 ; 8-byte Folded Spill
	str	xzr, [sp, #880]                 ; 8-byte Folded Spill
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	add	x8, sp, #409
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #872]                 ; 8-byte Folded Spill
	str	xzr, [sp, #864]                 ; 8-byte Folded Spill
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	add	x8, sp, #412
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1000]                ; 8-byte Folded Spill
	str	wzr, [sp, #1028]                ; 4-byte Folded Spill
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	add	x8, sp, #413
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #996]                 ; 4-byte Folded Spill
	str	xzr, [sp, #856]                 ; 8-byte Folded Spill
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	add	x8, sp, #417
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #800]                 ; 8-byte Folded Spill
	str	xzr, [sp, #792]                 ; 8-byte Folded Spill
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	add	x8, sp, #424
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #824]                 ; 8-byte Folded Spill
	str	xzr, [sp, #816]                 ; 8-byte Folded Spill
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	add	x8, sp, #425
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #808]                 ; 8-byte Folded Spill
	str	wzr, [sp, #156]                 ; 4-byte Folded Spill
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	add	x8, sp, #428
	ldrb	w8, [x8, #4095]
	str	x4, [sp, #592]                  ; 8-byte Folded Spill
	str	x12, [sp, #736]                 ; 8-byte Folded Spill
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	add	x8, sp, #429
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	add	x8, sp, #433
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #412]                  ; 4-byte Folded Reload
	eor	w8, w8, #0x1
	str	w8, [sp, #408]                  ; 4-byte Folded Spill
	add	x8, x10, #90
	stp	x8, x11, [sp, #112]             ; 16-byte Folded Spill
	add	x8, x10, #186
	add	x11, x10, #161
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	add	x8, x10, #257
	stp	x8, x11, [sp, #96]              ; 16-byte Folded Spill
	add	x11, x10, #282
	add	x8, x10, #353
	stp	x8, x11, [sp, #80]              ; 16-byte Folded Spill
	add	x11, x10, #378
	add	x8, x10, #449
	stp	x8, x11, [sp, #64]              ; 16-byte Folded Spill
	add	x11, x10, #474
	add	x8, x10, #545
	stp	x8, x11, [sp, #48]              ; 16-byte Folded Spill
	add	x11, x10, #570
	add	x8, x10, #641
	stp	x8, x11, [sp, #32]              ; 16-byte Folded Spill
	add	x11, x10, #666
	add	x8, x10, #737
	stp	x8, x11, [sp, #16]              ; 16-byte Folded Spill
	add	x8, sp, #2416
	add	x10, x10, #762
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
	add	x10, x8, #449
	add	x19, x8, #65
	str	x10, [sp, #640]                 ; 8-byte Folded Spill
	add	x10, x8, #474
	add	x1, x8, #90
	str	x10, [sp, #632]                 ; 8-byte Folded Spill
	add	x10, x8, #545
	add	x2, x8, #161
	str	x10, [sp, #624]                 ; 8-byte Folded Spill
	add	x10, x8, #570
	add	x17, x8, #186
	str	x10, [sp, #712]                 ; 8-byte Folded Spill
	add	x10, x4, #356
	add	x16, x8, #257
	str	x10, [sp, #776]                 ; 8-byte Folded Spill
	add	x10, x4, #420
	add	x3, x8, #282
	str	x10, [sp, #768]                 ; 8-byte Folded Spill
	add	x10, x4, #452
	add	x0, x8, #353
	str	x10, [sp, #760]                 ; 8-byte Folded Spill
	add	x10, x8, #737
	add	x6, x8, #378
	add	x14, x8, #641
	add	x15, x8, #666
	str	x10, [sp, #600]                 ; 8-byte Folded Spill
	add	x30, x8, #762
	add	x10, x9, #260
	add	x8, x9, #324
	stp	x8, x10, [sp, #440]             ; 16-byte Folded Spill
	add	x10, x9, #356
	add	x8, x9, #420
	stp	x8, x10, [sp, #424]             ; 16-byte Folded Spill
	add	x8, x9, #452
	mov	w9, #1                          ; =0x1
	str	x8, [sp, #416]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	add	x11, x4, #260
	mov	w10, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
	str	x19, [sp, #696]                 ; 8-byte Folded Spill
	str	w8, [sp, #264]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x1, [sp, #688]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x2, [sp, #680]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x17, [sp, #672]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x16, [sp, #664]                 ; 8-byte Folded Spill
	str	w8, [sp, #260]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x3, [sp, #656]                  ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x0, [sp, #752]                  ; 8-byte Folded Spill
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x6, [sp, #648]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x11, [sp, #744]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x14, [sp, #616]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x15, [sp, #608]                 ; 8-byte Folded Spill
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x30, [sp, #704]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	stp	w8, w9, [sp, #252]              ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #248]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	str	w8, [sp, #1492]                 ; 4-byte Folded Spill
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	str	w8, [sp, #1496]                 ; 4-byte Folded Spill
	str	w8, [sp, #1328]                 ; 4-byte Folded Spill
	b	LBB13_26
LBB13_24:                               ; %b58_to_b59.b61_to_b13_crit_edge
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldrb	w9, [sp, #2792]
	ldrb	w8, [sp, #2780]
	mov	w5, wzr
	ldr	w10, [sp, #2788]
	ldr	x19, [sp, #2808]
	ldr	x24, [sp, #2816]
	str	w9, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2793]
	ldr	x25, [sp, #2824]
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2781]
	ldr	x13, [sp, #2840]
	str	w9, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2800]
	ldr	x27, [sp, #2848]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2784]
	ldr	x28, [sp, #2856]
	str	w9, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2804]
	str	w9, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2832]
	str	w9, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2836]
	str	w9, [sp, #1384]                 ; 4-byte Folded Spill
LBB13_25:                               ; %b61_to_b13
                                        ;   in Loop: Header=BB13_26 Depth=1
	str	w10, [sp, #1464]                ; 4-byte Folded Spill
	ldr	w10, [x1]
	ldrb	w9, [x0, #2]
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	add	x11, sp, #311
	ldrh	w8, [x0]
	str	w10, [sp, #4396]
	ldr	w10, [sp, #2416]
	ldr	x0, [sp, #752]                  ; 8-byte Folded Reload
	strh	w8, [sp, #4404]
	ldrh	w8, [x1, #4]
	ldrh	w26, [sp, #2878]
	str	w10, [sp, #1328]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2420]
	strb	w9, [x11, #4095]
	ldrb	w9, [x2, #2]
	strh	w8, [sp, #4400]
	ldrh	w8, [x2]
	str	w10, [sp, #224]                 ; 4-byte Folded Spill
	add	x10, sp, #299
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2424]
	ldrh	w9, [x17, #4]
	strh	w8, [sp, #4392]
	ldr	w8, [x17]
	str	x10, [sp, #240]                 ; 8-byte Folded Spill
	ldr	x10, [sp, #2432]
	str	w8, [sp, #4384]
	ldrh	w8, [x3]
	str	x10, [sp, #1296]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2440]
	strh	w8, [sp, #4380]
	ldr	w8, [x16]
	str	x10, [sp, #1288]                ; 8-byte Folded Spill
	ldr	w10, [sp, #2448]
	str	w8, [sp, #4372]
	ldrh	w8, [x0]
	str	w10, [sp, #312]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2452]
	strh	w8, [sp, #4368]
	ldr	w8, [x6]
	strh	w9, [sp, #4388]
	ldrb	w9, [x3, #2]
	str	w10, [sp, #220]                 ; 4-byte Folded Spill
	add	x10, sp, #287
	str	w8, [sp, #4360]
	ldrh	w8, [x21]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2456]
	ldrh	w9, [x16, #4]
	strh	w8, [sp, #4356]
	ldr	w8, [x20]
	str	x10, [sp, #1280]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2464]
	str	w8, [sp, #4348]
	ldrh	w8, [x23]
	str	x10, [sp, #1272]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2472]
	strh	w8, [sp, #4344]
	ldr	w8, [x22]
	str	x10, [sp, #1248]                ; 8-byte Folded Spill
	ldrb	w10, [sp, #2480]
	strh	w9, [sp, #4376]
	ldrb	w9, [x0, #2]
	str	w8, [sp, #4336]
	ldrh	w8, [x14]
	str	w10, [sp, #784]                 ; 4-byte Folded Spill
	add	x10, sp, #275
	strb	w9, [x10, #4095]
	ldr	w10, [sp, #2484]
	ldrh	w9, [x6, #4]
	strh	w8, [sp, #4332]
	ldr	w8, [x15]
	str	w10, [sp, #1240]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2488]
	str	w8, [sp, #4324]
	ldrh	w8, [x7]
	str	w10, [sp, #1232]                ; 4-byte Folded Spill
	ldrb	w10, [sp, #2492]
	strh	w8, [sp, #4320]
	ldr	x8, [sp, #2552]
	str	w10, [sp, #400]                 ; 4-byte Folded Spill
	ldrb	w10, [sp, #2493]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2560]
	strh	w9, [sp, #4364]
	ldrb	w9, [x21, #2]
	ldr	w21, [sp, #732]                 ; 4-byte Folded Reload
	str	w10, [sp, #404]                 ; 4-byte Folded Spill
	add	x10, sp, #263
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2568]
	strb	w9, [x10, #4095]
	ldr	w10, [sp, #2496]
	ldrh	w9, [x20, #4]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2576]
	ldrh	w20, [sp, #3166]
	str	w10, [sp, #1224]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2500]
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2580]
	str	w10, [sp, #1220]                ; 4-byte Folded Spill
	ldrb	w10, [sp, #2504]
	strh	w9, [sp, #4352]
	ldrb	w9, [x23, #2]
	ldrh	w23, [sp, #3070]
	str	w8, [sp, #1136]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2584]
	str	w10, [sp, #396]                 ; 4-byte Folded Spill
	add	x10, sp, #251
	strb	w9, [x10, #4095]
	ldrb	w10, [sp, #2505]
	ldrh	w9, [x22, #4]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2588]
	ldrh	w22, [sp, #2590]
	str	w10, [sp, #392]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2512]
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2589]
	str	w10, [sp, #1496]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2516]
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2592]
	strh	w9, [sp, #4340]
	ldrb	w9, [x14, #2]
	str	w10, [sp, #216]                 ; 4-byte Folded Spill
	add	x10, sp, #239
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2596]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2520]
	ldrh	w9, [x15, #4]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2600]
	str	x10, [sp, #1200]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2528]
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2601]
	str	x10, [sp, #1208]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2536]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2608]
	str	x10, [sp, #1192]                ; 8-byte Folded Spill
	ldr	w10, [sp, #2544]
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2616]
	str	w10, [sp, #264]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2548]
	strh	w9, [sp, #4328]
	ldrb	w9, [x7, #2]
	ldr	w7, [sp, #2884]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2624]
	str	w10, [sp, #212]                 ; 4-byte Folded Spill
	add	x10, sp, #227
	strb	w9, [x10, #4095]
	ldrh	w9, [x30, #4]
	ldr	w10, [sp, #2640]
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2632]
	strh	w9, [sp, #4316]
	ldr	w9, [sp, #2612]
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2644]
	str	x28, [sp, #1480]                ; 8-byte Folded Spill
	ldrh	w28, [sp, #2974]
	stp	w9, w8, [sp, #204]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2648]
	ldr	w9, [sp, #2708]
	str	x27, [sp, #1472]                ; 8-byte Folded Spill
	ldrh	w27, [sp, #2782]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2656]
	str	x13, [sp, #1432]                ; 8-byte Folded Spill
	ldrb	w13, [sp, #2864]
	str	x8, [sp, #944]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2664]
	str	x25, [sp, #1440]                ; 8-byte Folded Spill
	ldrh	w25, [sp, #2686]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2672]
	str	x24, [sp, #1448]                ; 8-byte Folded Spill
	ldrh	w24, [sp, #2494]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2676]
	str	x19, [sp, #1456]                ; 8-byte Folded Spill
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2680]
	str	w21, [sp, #1320]                ; 4-byte Folded Spill
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2684]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2685]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2688]
	str	w8, [sp, #1120]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2692]
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2696]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2697]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2704]
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2712]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2720]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2728]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2736]
	str	w8, [sp, #260]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2740]
	stp	w9, w8, [sp, #196]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2744]
	ldr	w9, [sp, #2900]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2752]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2760]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2768]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2772]
	str	w8, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2776]
	str	w8, [sp, #1080]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2868]
	str	w8, [sp, #1176]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2872]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2876]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2877]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2880]
	str	w8, [sp, #1188]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2888]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2889]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2896]
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2904]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2912]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2920]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2928]
	str	w8, [sp, #256]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2932]
	stp	w9, w8, [sp, #188]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2936]
	ldr	w9, [sp, #2996]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2944]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2952]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2960]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2964]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2968]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2972]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2973]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2976]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2980]
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2984]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2985]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2992]
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3000]
	str	x8, [sp, #864]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3008]
	str	x8, [sp, #872]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3016]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3024]
	str	w8, [sp, #252]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3028]
	stp	w9, w8, [sp, #180]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3032]
	ldr	w9, [sp, #3092]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3040]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3048]
	str	x8, [sp, #848]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3056]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3060]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3064]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3068]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3069]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3072]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3076]
	str	w8, [sp, #1044]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3080]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3081]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3088]
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3096]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3104]
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3112]
	str	x8, [sp, #824]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3120]
	str	w8, [sp, #248]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3124]
	stp	w9, w8, [sp, #172]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3128]
	ldr	w9, [sp, #3172]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3136]
	str	w9, [sp, #1004]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #3176]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3144]
	str	w9, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #3177]
	str	x8, [sp, #856]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3152]
	str	w9, [sp, #388]                  ; 4-byte Folded Spill
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3156]
	str	w8, [sp, #996]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3160]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3164]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3165]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3168]
	str	w8, [sp, #1028]                 ; 4-byte Folded Spill
	ldr	w8, [x30]
	str	w8, [sp, #4312]
	tbz	w5, #0, LBB13_318
LBB13_26:                               ; %b14
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_80 Depth 2
	ldr	x0, [sp, #720]                  ; 8-byte Folded Reload
	mov	w1, #1000                       ; =0x3e8
	stp	w10, w13, [sp, #228]            ; 8-byte Folded Spill
	str	w7, [sp, #236]                  ; 4-byte Folded Spill
	bl	_liza_rt_reactor_poll
	lsr	x8, x0, #32
	cbnz	x8, LBB13_28
; %bb.27:                               ; %b1.i.i95
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, wzr
	b	LBB13_42
LBB13_28:                               ; %v8_ok.i.i77
                                        ;   in Loop: Header=BB13_26 Depth=1
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_40
; %bb.29:                               ; %v8_ok.i.i77
                                        ;   in Loop: Header=BB13_26 Depth=1
Lloh4:
	adrp	x12, lJTI13_1@PAGE
Lloh5:
	add	x12, x12, lJTI13_1@PAGEOFF
	mov	w9, wzr
	adr	x10, LBB13_30
	ldrb	w11, [x12, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_30:                               ; %b4.i.i.i93
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #1                          ; =0x1
	b	LBB13_41
LBB13_31:                               ; %b34.i.i.i88
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #11                         ; =0xb
	b	LBB13_41
LBB13_32:                               ; %b13.i.i.i90
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #4                          ; =0x4
	b	LBB13_41
LBB13_33:                               ; %b16.i.i.i89
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #5                          ; =0x5
	b	LBB13_41
LBB13_34:                               ; %b10.i.i.i91
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #3                          ; =0x3
	b	LBB13_41
LBB13_35:                               ; %b7.i.i.i92
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #2                          ; =0x2
	b	LBB13_41
LBB13_36:                               ; %b22.i.i.i87
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #7                          ; =0x7
	b	LBB13_41
LBB13_37:                               ; %b25.i.i.i86
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #8                          ; =0x8
	b	LBB13_41
LBB13_38:                               ; %b31.i.i.i80
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #10                         ; =0xa
	b	LBB13_41
LBB13_39:                               ; %b28.i.i.i85
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #9                          ; =0x9
	b	LBB13_41
LBB13_40:                               ; %b36.i.i.i94
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #6                          ; =0x6
LBB13_41:                               ; %liza___liza_reactor_error.exit.i.i81
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, #1                          ; =0x1
LBB13_42:                               ; %liza_net.reactor_poll.exit
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB13_45
; %bb.43:                               ; %b17
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w10, #1                         ; =0x1
	ldr	w8, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w11, #3                         ; =0x3
	lsl	w9, w10, w9
	mov	w10, #3827                      ; =0xef3
	mov	w14, wzr
	tst	w9, w10
	b.ne	LBB13_47
; %bb.44:                               ;   in Loop: Header=BB13_26 Depth=1
	ldr	w11, [sp, #1320]                ; 4-byte Folded Reload
	b	LBB13_46
LBB13_45:                               ;   in Loop: Header=BB13_26 Depth=1
	ldr	w11, [sp, #1320]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1492]                 ; 4-byte Folded Reload
LBB13_46:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w14, #1                         ; =0x1
LBB13_47:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w13, [sp, #1496]                ; 4-byte Folded Reload
	ldrh	w9, [sp, #4368]
	add	x10, sp, #275
	str	w11, [sp, #732]                 ; 4-byte Folded Spill
	ldrb	w10, [x10, #4095]
	add	x15, sp, #1, lsl #12            ; =4096
	cmp	w13, #1
	ldr	w13, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w11, [sp, #4360]
	ldrh	w12, [sp, #4364]
	strh	w9, [sp, #4244]
	mov	w9, #8                          ; =0x8
	csinc	w9, w9, wzr, ne
	cmp	w13, #1
	add	x13, sp, #151
	strb	w10, [x13, #4095]
	ldrh	w10, [sp, #4356]
	csel	w9, wzr, w9, eq
	str	w11, [sp, #4296]
	add	x11, sp, #263
	cmp	w9, #8
	strh	w12, [sp, #4300]
	ldr	w12, [sp, #1344]                ; 4-byte Folded Reload
	ldrb	w11, [x11, #4095]
	strh	w10, [sp, #4292]
	ldrh	w10, [sp, #4352]
	add	x17, sp, #1, lsl #12            ; =4096
	ccmp	w12, #1, #0, eq
	add	x12, sp, #199
	strh	w24, [sp, #4310]
	strb	w11, [x12, #4095]
	mov	w12, #2                         ; =0x2
	ldr	w11, [sp, #4348]
	csel	w9, w12, w9, eq
	strh	w10, [sp, #4288]
	add	x10, sp, #251
	ldr	w12, [sp, #1352]                ; 4-byte Folded Reload
	ldrb	w10, [x10, #4095]
	cmp	w9, #8
	str	w11, [sp, #4284]
	ldrh	w11, [sp, #4344]
	add	x0, sp, #1, lsl #12             ; =4096
	ccmp	w12, #1, #0, eq
	add	x12, sp, #187
	strh	w22, [sp, #4308]
	strb	w10, [x12, #4095]
	mov	w12, #3                         ; =0x3
	ldr	w10, [sp, #4336]
	csel	w9, w12, w9, eq
	strh	w11, [sp, #4280]
	ldrh	w11, [sp, #4340]
	cmp	w9, #8
	str	w10, [sp, #4272]
	ldrh	w10, [sp, #4332]
	ccmp	w8, #1, #0, eq
	add	x8, sp, #239
	strh	w11, [sp, #4276]
	ldrb	w11, [x8, #4095]
	mov	w12, #4                         ; =0x4
	add	x8, sp, #175
	csel	w9, w12, w9, eq
	strh	w10, [sp, #4268]
	ldr	w10, [sp, #4324]
	strb	w11, [x8, #4095]
	ldr	w8, [sp, #1364]                 ; 4-byte Folded Reload
	cmp	w9, #8
	ldrh	w11, [sp, #4328]
	str	w10, [sp, #4260]
	mov	w12, #5                         ; =0x5
	ccmp	w8, #1, #0, eq
	add	x8, sp, #227
	strh	w25, [sp, #4306]
	ldrb	w10, [x8, #4095]
	add	x8, sp, #163
	csel	w9, w12, w9, eq
	strh	w11, [sp, #4264]
	ldrh	w11, [sp, #4320]
	cmp	w9, #8
	strb	w10, [x8, #4095]
	ldr	w8, [sp, #1368]                 ; 4-byte Folded Reload
	ldrh	w10, [sp, #4316]
	strh	w11, [sp, #4256]
	mov	w11, #6                         ; =0x6
	add	x1, sp, #1, lsl #12             ; =4096
	ccmp	w8, #1, #0, eq
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	strh	w10, [sp, #4252]
	csel	w9, w11, w9, eq
	ldr	w11, [sp, #4312]
	mov	w10, #7                         ; =0x7
	cmp	w9, #8
	strh	w27, [sp, #4304]
	add	x2, sp, #1, lsl #12             ; =4096
	ccmp	w8, #1, #0, eq
	strh	w26, [sp, #4290]
	add	x4, sp, #1, lsl #12             ; =4096
	strh	w28, [sp, #4278]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	strh	w23, [sp, #4266]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x13, sp, #1, lsl #12            ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x26, sp, #1, lsl #12            ; =4096
	add	x27, sp, #1, lsl #12            ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x28, sp, #1, lsl #12            ; =4096
	csel	w21, w10, w9, eq
	add	x15, x15, #216
	add	x17, x17, #224
	add	x0, x0, #228
	add	x1, x1, #236
	add	x2, x2, #240
	add	x4, x4, #248
	add	x5, x5, #252
	add	x6, x6, #260
	add	x19, x19, #264
	add	x22, x22, #208
	add	x23, x23, #272
	add	x24, x24, #276
	add	x13, x13, #210
	add	x7, x7, #284
	add	x25, x25, #288
	add	x16, x16, #212
	add	x26, x26, #296
	add	x27, x27, #300
	add	x3, x3, #214
	add	x28, x28, #308
	str	w11, [sp, #4248]
	strh	w20, [sp, #4254]
	str	w14, [sp, #1320]                ; 4-byte Folded Spill
	cbz	w14, LBB13_54
; %bb.48:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x9, [sp, #712]                  ; 8-byte Folded Reload
	cmp	w21, #7
	b.hi	LBB13_53
; %bb.49:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w20, [sp, #412]                 ; 4-byte Folded Reload
	ldr	w8, [sp, #156]                  ; 4-byte Folded Reload
	and	w20, w20, w8
	tbnz	w20, #0, LBB13_53
; %bb.50:                               ; %b42
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x19, [sp, #720]                 ; 8-byte Folded Reload
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #440
	mov	x0, x19
	bl	_liza_rt_reactor_accept
	cmp	w0, #12
	b.hi	LBB13_65
; %bb.51:                               ; %b42
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, w0
Lloh6:
	adrp	x11, lJTI13_2@PAGE
Lloh7:
	add	x11, x11, lJTI13_2@PAGEOFF
	adr	x9, LBB13_52
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	mov	w27, wzr
	br	x9
LBB13_52:                               ; %b1.i119
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x20, [sp, #4536]
	ldr	x22, [sp, #4544]
	mov	w8, wzr
	ldr	x23, [sp, #4552]
	mov	w27, wzr
	b	LBB13_67
LBB13_53:                               ;   in Loop: Header=BB13_26 Depth=1
	add	x14, sp, #1, lsl #12            ; =4096
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	add	x10, sp, #1, lsl #12            ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x14, x14, #158
	add	x10, x10, #170
	add	x11, x11, #182
	add	x12, x12, #194
	str	x14, [sp, #160]                 ; 8-byte Folded Spill
	b	LBB13_78
LBB13_54:                               ;   in Loop: Header=BB13_26 Depth=1
	add	x8, sp, #1, lsl #12             ; =4096
	ldr	x9, [sp, #712]                  ; 8-byte Folded Reload
	add	x10, sp, #1, lsl #12            ; =4096
	add	x8, x8, #158
	add	x11, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	add	x10, x10, #170
	add	x11, x11, #182
	add	x12, x12, #194
	b	LBB13_78
LBB13_55:                               ; %b31.i.i106
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #10                        ; =0xa
	b	LBB13_66
LBB13_56:                               ; %b4.i.i118
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #1                         ; =0x1
	b	LBB13_66
LBB13_57:                               ; %b13.i.i115
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #4                         ; =0x4
	b	LBB13_66
LBB13_58:                               ; %b34.i.i113
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #11                        ; =0xb
	b	LBB13_66
LBB13_59:                               ; %b16.i.i114
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #5                         ; =0x5
	b	LBB13_66
LBB13_60:                               ; %b22.i.i112
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #7                         ; =0x7
	b	LBB13_66
LBB13_61:                               ; %b7.i.i117
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #2                         ; =0x2
	b	LBB13_66
LBB13_62:                               ; %b10.i.i116
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #3                         ; =0x3
	b	LBB13_66
LBB13_63:                               ; %b28.i.i110
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #9                         ; =0x9
	b	LBB13_66
LBB13_64:                               ; %b25.i.i111
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #8                         ; =0x8
	b	LBB13_66
LBB13_65:                               ; %b36.i.i120
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #6                         ; =0x6
LBB13_66:                               ; %liza___liza_reactor_error.exit.i107
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	x20, xzr
	mov	x22, xzr
	mov	x23, xzr
	mov	w8, #1                          ; =0x1
LBB13_67:                               ; %liza_net.reactor_accept.exit
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x28, [sp, #1480]                ; 8-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB13_70
; %bb.68:                               ; %b45
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w21, #1                         ; =0x1
	add	x3, sp, #1, lsl #12             ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	lsl	w21, w21, w27
	add	x7, sp, #1, lsl #12             ; =4096
	add	x14, sp, #1, lsl #12            ; =4096
	add	x13, sp, #1, lsl #12            ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x17, sp, #1, lsl #12            ; =4096
	add	x9, sp, #1, lsl #12             ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x26, sp, #1, lsl #12            ; =4096
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	mov	w27, #3827                      ; =0xef3
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	add	x3, x3, #216
	add	x16, x16, #158
	add	x7, x7, #224
	add	x14, x14, #228
	add	x13, x13, #170
	add	x19, x19, #236
	add	x12, x12, #240
	add	x4, x4, #182
	add	x11, x11, #248
	add	x1, x1, #252
	add	x10, x10, #194
	add	x17, x17, #260
	add	x9, x9, #264
	add	x15, x15, #208
	add	x0, x0, #272
	add	x2, x2, #276
	add	x5, x5, #210
	add	x6, x6, #284
	add	x23, x23, #288
	add	x24, x24, #212
	add	x22, x22, #296
	add	x25, x25, #300
	add	x20, x20, #214
	add	x26, x26, #308
	tst	w21, w27
	b.eq	LBB13_316
; %bb.69:                               ;   in Loop: Header=BB13_26 Depth=1
	mov	w21, #3                         ; =0x3
	str	wzr, [sp, #1320]                ; 4-byte Folded Spill
	str	w21, [sp, #732]                 ; 4-byte Folded Spill
	b	LBB13_77
LBB13_70:                               ; %b49
                                        ;   in Loop: Header=BB13_26 Depth=1
	add	x2, sp, #1, lsl #12             ; =4096
	ldr	w1, [sp, #140]                  ; 4-byte Folded Reload
	mov	x0, x19
	add	x2, x2, #440
	bl	_liza_rt_reactor_connect
	cmp	w0, #12
	b.hi	LBB13_72
; %bb.71:                               ; %b49
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, w0
Lloh8:
	adrp	x11, lJTI13_3@PAGE
Lloh9:
	add	x11, x11, lJTI13_3@PAGEOFF
	adr	x9, LBB13_72
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_72:                               ; %liza___liza_reactor_error.exit.i134
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	x10, xzr
	mov	x9, xzr
	mov	x8, xzr
	mov	w11, #1                         ; =0x1
LBB13_73:                               ; %liza_net.reactor_connect.exit
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x27, [sp, #1472]                ; 8-byte Folded Reload
	ldr	w13, [sp, #1428]                ; 4-byte Folded Reload
	cmp	w11, #1
	ldr	w14, [sp, #1416]                ; 4-byte Folded Reload
	ldr	w15, [sp, #1408]                ; 4-byte Folded Reload
	ldr	w16, [sp, #1404]                ; 4-byte Folded Reload
	ldr	w17, [sp, #1388]                ; 4-byte Folded Reload
	ldr	w0, [sp, #1392]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1384]                 ; 4-byte Folded Reload
	b.ne	LBB13_75
; %bb.74:                               ; %b51
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	x2, x22
	mov	x3, x23
	bl	_liza_rt_reactor_disconnect
	ldr	w8, [sp, #412]                  ; 4-byte Folded Reload
	ldr	w13, [sp, #732]                 ; 4-byte Folded Reload
	add	x17, sp, #1, lsl #12            ; =4096
	ldrh	w9, [sp, #4310]
	ldrh	w10, [sp, #4308]
	add	x0, sp, #1, lsl #12             ; =4096
	tst	w8, #0x1
	mov	w8, #3                          ; =0x3
	ldrh	w11, [sp, #4306]
	csel	w13, w8, w13, ne
	ldr	w8, [sp, #408]                  ; 4-byte Folded Reload
	ldrh	w12, [sp, #4304]
	str	w13, [sp, #732]                 ; 4-byte Folded Spill
	ldrh	w14, [sp, #4290]
	ldrh	w13, [sp, #4278]
	ldrh	w15, [sp, #4266]
	add	x16, sp, #1, lsl #12            ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	ldrh	w6, [sp, #4254]
	add	x26, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x17, x17, #224
	add	x0, x0, #228
	add	x16, x16, #236
	add	x2, x2, #240
	add	x3, x3, #248
	add	x4, x4, #252
	add	x5, x5, #260
	add	x7, x7, #264
	add	x19, x19, #272
	add	x20, x20, #276
	add	x22, x22, #284
	add	x23, x23, #288
	add	x24, x24, #296
	add	x25, x25, #300
	add	x26, x26, #308
	add	x1, x1, #216
	str	w8, [sp, #1320]                 ; 4-byte Folded Spill
	b	LBB13_76
LBB13_75:                               ; %v101_ok
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w11, [sp, #1328]                ; 4-byte Folded Reload
	ldr	x26, [sp, #120]                 ; 8-byte Folded Reload
	mov	x30, x22
	ldr	x25, [sp, #112]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #104]                 ; 8-byte Folded Reload
	mov	x6, x20
	str	w11, [sp, #3472]
	ldrh	w11, [sp, #4404]
	ldr	x2, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x22, [sp, #96]                  ; 8-byte Folded Reload
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x5, [sp, #64]                   ; 8-byte Folded Reload
	strh	w11, [x26]
	ldr	w11, [sp, #1240]                ; 4-byte Folded Reload
	ldr	w12, [sp, #224]                 ; 4-byte Folded Reload
	ldr	x4, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #48]                   ; 8-byte Folded Reload
	strb	w16, [sp, #3848]
	str	w11, [sp, #3540]
	ldr	w11, [sp, #1232]                ; 4-byte Folded Reload
	ldr	x16, [sp, #32]                  ; 8-byte Folded Reload
	str	w12, [sp, #3476]
	ldr	x12, [sp, #240]                 ; 8-byte Folded Reload
	str	w11, [sp, #3544]
	ldr	w11, [sp, #400]                 ; 4-byte Folded Reload
	str	x12, [sp, #3480]
	ldr	x12, [sp, #1296]                ; 8-byte Folded Reload
	strb	w11, [sp, #3548]
	ldrh	w11, [sp, #4310]
	str	x12, [sp, #3488]
	ldr	x12, [sp, #1288]                ; 8-byte Folded Reload
	strh	w11, [sp, #3550]
	ldr	w11, [sp, #1224]                ; 4-byte Folded Reload
	str	x12, [sp, #3496]
	ldr	w12, [sp, #312]                 ; 4-byte Folded Reload
	str	w11, [sp, #3552]
	ldr	w11, [sp, #1220]                ; 4-byte Folded Reload
	str	w12, [sp, #3504]
	ldr	w12, [sp, #220]                 ; 4-byte Folded Reload
	str	w11, [sp, #3556]
	ldr	w11, [sp, #396]                 ; 4-byte Folded Reload
	str	w12, [sp, #3508]
	ldr	x12, [sp, #1280]                ; 8-byte Folded Reload
	strb	w11, [sp, #3560]
	ldr	w11, [sp, #4396]
	str	x12, [sp, #3512]
	ldr	x12, [sp, #1272]                ; 8-byte Folded Reload
	str	w11, [x25]
	ldr	w11, [sp, #1496]                ; 4-byte Folded Reload
	str	x12, [sp, #3520]
	ldr	x12, [sp, #1248]                ; 8-byte Folded Reload
	str	w11, [sp, #3568]
	ldr	w11, [sp, #216]                 ; 4-byte Folded Reload
	str	x12, [sp, #3528]
	ldr	w12, [sp, #784]                 ; 4-byte Folded Reload
	str	w11, [sp, #3572]
	ldr	x11, [sp, #1200]                ; 8-byte Folded Reload
	strb	w12, [sp, #3536]
	add	x12, sp, #311
	str	x11, [sp, #3576]
	ldr	x11, [sp, #1208]                ; 8-byte Folded Reload
	ldrb	w12, [x12, #4095]
	strb	w13, [sp, #3836]
	add	x13, sp, #17
	str	x11, [sp, #3584]
	ldr	x11, [sp, #1192]                ; 8-byte Folded Reload
	strb	w12, [x26, #2]
	ldr	w12, [sp, #404]                 ; 4-byte Folded Reload
	str	x11, [sp, #3592]
	ldr	w11, [sp, #264]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3549]
	ldr	w12, [sp, #392]                 ; 4-byte Folded Reload
	str	w11, [sp, #3600]
	ldr	w11, [sp, #212]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3561]
	ldrh	w12, [sp, #4400]
	str	w11, [sp, #3604]
	ldr	x11, [sp, #1008]                ; 8-byte Folded Reload
	strh	w12, [x25, #4]
	ldr	w12, [sp, #268]                 ; 4-byte Folded Reload
	str	x11, [sp, #3608]
	ldr	x11, [sp, #1016]                ; 8-byte Folded Reload
	strb	w12, [sp, #3632]
	ldrh	w12, [sp, #4392]
	str	x11, [sp, #3616]
	ldr	x11, [sp, #984]                 ; 8-byte Folded Reload
	strh	w12, [x24]
	ldr	w12, [sp, #280]                 ; 4-byte Folded Reload
	str	x11, [sp, #3624]
	add	x11, sp, #299
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3645]
	ldr	w12, [sp, #284]                 ; 4-byte Folded Reload
	str	w0, [sp, #3888]
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	strb	w11, [x24, #2]
	ldr	w11, [sp, #1136]                ; 4-byte Folded Reload
	strb	w12, [sp, #3657]
	ldr	w12, [sp, #4384]
	str	w11, [sp, #3636]
	ldr	w11, [sp, #1144]                ; 4-byte Folded Reload
	str	w12, [x2]
	ldr	w12, [sp, #288]                 ; 4-byte Folded Reload
	str	w11, [sp, #3640]
	ldr	w11, [sp, #272]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3728]
	ldrh	w12, [sp, #4380]
	strb	w11, [sp, #3644]
	ldrh	w11, [sp, #4308]
	strh	w12, [x22]
	ldr	w12, [sp, #300]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3646]
	ldr	w11, [sp, #1148]                ; 4-byte Folded Reload
	strb	w12, [sp, #3741]
	ldr	w12, [sp, #304]                 ; 4-byte Folded Reload
	str	w11, [sp, #3648]
	ldr	w11, [sp, #1152]                ; 4-byte Folded Reload
	strb	w12, [sp, #3753]
	ldr	w12, [sp, #4372]
	str	w11, [sp, #3652]
	ldr	w11, [sp, #276]                 ; 4-byte Folded Reload
	str	w12, [x20]
	ldr	w12, [sp, #308]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3656]
	ldrh	w11, [sp, #4388]
	strb	w12, [sp, #3824]
	ldrh	w12, [sp, #4244]
	strh	w11, [x2, #4]
	ldr	w11, [sp, #1344]                ; 4-byte Folded Reload
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	strb	w14, [sp, #3837]
	add	x14, sp, #42
	str	w11, [sp, #3664]
	ldr	w11, [sp, #204]                 ; 4-byte Folded Reload
	str	w17, [sp, #3860]
	ldr	x17, [sp, #16]                  ; 8-byte Folded Reload
	str	w11, [sp, #3668]
	ldr	x11, [sp, #960]                 ; 8-byte Folded Reload
	str	w1, [sp, #3892]
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	str	x11, [sp, #3672]
	ldr	x11, [sp, #968]                 ; 8-byte Folded Reload
	strb	w15, [sp, #3849]
	ldp	x7, x19, [sp, #72]              ; 16-byte Folded Reload
	str	x11, [sp, #3680]
	ldr	x11, [sp, #976]                 ; 8-byte Folded Reload
	str	x27, [sp, #3904]
	str	x11, [sp, #3688]
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
	strh	w12, [x19]
	ldr	w12, [sp, #4296]
	str	w11, [sp, #3696]
	ldr	w11, [sp, #208]                 ; 4-byte Folded Reload
	str	w12, [x7]
	ldr	w12, [sp, #232]                 ; 4-byte Folded Reload
	str	w11, [sp, #3700]
	ldr	x11, [sp, #936]                 ; 8-byte Folded Reload
	strb	w12, [sp, #3920]
	ldrh	w12, [sp, #4292]
	str	x11, [sp, #3704]
	ldr	x11, [sp, #944]                 ; 8-byte Folded Reload
	strh	w12, [x5]
	ldr	w12, [sp, #324]                 ; 4-byte Folded Reload
	str	x11, [sp, #3712]
	ldr	x11, [sp, #952]                 ; 8-byte Folded Reload
	strb	w12, [sp, #3933]
	ldr	w12, [sp, #328]                 ; 4-byte Folded Reload
	str	x11, [sp, #3720]
	add	x11, sp, #287
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3945]
	ldr	w12, [sp, #4284]
	str	x28, [sp, #3912]
	strb	w11, [x22, #2]
	ldr	w11, [sp, #1112]                ; 4-byte Folded Reload
	str	w12, [x4]
	ldr	w12, [sp, #332]                 ; 4-byte Folded Reload
	str	w11, [sp, #3732]
	ldr	w11, [sp, #1116]                ; 4-byte Folded Reload
	strb	w12, [sp, #4016]
	ldrh	w12, [sp, #4280]
	str	w11, [sp, #3736]
	ldr	w11, [sp, #292]                 ; 4-byte Folded Reload
	strh	w12, [x3]
	ldr	w12, [sp, #344]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3740]
	ldrh	w11, [sp, #4306]
	strb	w12, [sp, #4029]
	ldr	w12, [sp, #348]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3742]
	ldr	w11, [sp, #1120]                ; 4-byte Folded Reload
	strb	w12, [sp, #4041]
	ldr	w12, [sp, #4272]
	str	w11, [sp, #3744]
	ldr	w11, [sp, #1132]                ; 4-byte Folded Reload
	str	w12, [x2]
	ldr	w12, [sp, #352]                 ; 4-byte Folded Reload
	str	w11, [sp, #3748]
	ldr	w11, [sp, #296]                 ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	add	x13, sp, #30
	ldrh	w12, [sp, #4268]
	strb	w11, [sp, #3752]
	ldrh	w11, [sp, #4376]
	strh	w12, [x16]
	add	x12, sp, #29
	strh	w11, [x20, #4]
	ldr	w11, [sp, #1352]                ; 4-byte Folded Reload
	str	w11, [sp, #3760]
	ldr	w11, [sp, #196]                 ; 4-byte Folded Reload
	str	w11, [sp, #3764]
	ldr	x11, [sp, #912]                 ; 8-byte Folded Reload
	str	x11, [sp, #3768]
	ldr	x11, [sp, #920]                 ; 8-byte Folded Reload
	str	x11, [sp, #3776]
	ldr	x11, [sp, #928]                 ; 8-byte Folded Reload
	str	x11, [sp, #3784]
	ldr	w11, [sp, #260]                 ; 4-byte Folded Reload
	str	w11, [sp, #3792]
	ldr	w11, [sp, #200]                 ; 4-byte Folded Reload
	str	w11, [sp, #3796]
	ldr	x11, [sp, #888]                 ; 8-byte Folded Reload
	str	x11, [sp, #3800]
	ldr	x11, [sp, #896]                 ; 8-byte Folded Reload
	str	x11, [sp, #3808]
	ldr	x11, [sp, #904]                 ; 8-byte Folded Reload
	str	x11, [sp, #3816]
	add	x11, sp, #151
	ldrb	w11, [x11, #4095]
	strb	w11, [x19, #2]
	ldr	w11, [sp, #1076]                ; 4-byte Folded Reload
	str	w11, [sp, #3828]
	ldr	w11, [sp, #1080]                ; 4-byte Folded Reload
	str	w11, [sp, #3832]
	ldrh	w11, [sp, #4304]
	strh	w11, [sp, #3838]
	ldr	w11, [sp, #1468]                ; 4-byte Folded Reload
	str	w11, [sp, #3840]
	ldr	w11, [sp, #1464]                ; 4-byte Folded Reload
	str	w11, [sp, #3844]
	ldrh	w11, [sp, #4300]
	strh	w11, [x7, #4]
	ldr	w11, [sp, #1492]                ; 4-byte Folded Reload
	str	w11, [sp, #3856]
	ldr	x11, [sp, #1456]                ; 8-byte Folded Reload
	str	x11, [sp, #3864]
	ldr	x11, [sp, #1448]                ; 8-byte Folded Reload
	str	x11, [sp, #3872]
	ldr	x11, [sp, #1440]                ; 8-byte Folded Reload
	str	x11, [sp, #3880]
	ldr	x11, [sp, #1432]                ; 8-byte Folded Reload
	str	x11, [sp, #3896]
	add	x11, sp, #199
	ldrb	w11, [x11, #4095]
	strb	w11, [x5, #2]
	ldr	w11, [sp, #1176]                ; 4-byte Folded Reload
	str	w11, [sp, #3924]
	ldr	w11, [sp, #1184]                ; 4-byte Folded Reload
	str	w11, [sp, #3928]
	ldr	w11, [sp, #316]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3932]
	ldrh	w11, [sp, #4290]
	strh	w11, [sp, #3934]
	ldr	w11, [sp, #1188]                ; 4-byte Folded Reload
	str	w11, [sp, #3936]
	ldr	w11, [sp, #236]                 ; 4-byte Folded Reload
	str	w11, [sp, #3940]
	ldr	w11, [sp, #320]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3944]
	ldrh	w11, [sp, #4288]
	strh	w11, [x4, #4]
	ldr	w11, [sp, #1364]                ; 4-byte Folded Reload
	str	w11, [sp, #3952]
	ldr	w11, [sp, #188]                 ; 4-byte Folded Reload
	str	w11, [sp, #3956]
	ldr	x11, [sp, #1088]                ; 8-byte Folded Reload
	str	x11, [sp, #3960]
	ldr	x11, [sp, #1096]                ; 8-byte Folded Reload
	str	x11, [sp, #3968]
	ldr	x11, [sp, #1104]                ; 8-byte Folded Reload
	str	x11, [sp, #3976]
	ldr	w11, [sp, #256]                 ; 4-byte Folded Reload
	str	w11, [sp, #3984]
	ldr	w11, [sp, #192]                 ; 4-byte Folded Reload
	str	w11, [sp, #3988]
	ldr	x11, [sp, #1048]                ; 8-byte Folded Reload
	str	x11, [sp, #3992]
	ldr	x11, [sp, #1056]                ; 8-byte Folded Reload
	str	x11, [sp, #4000]
	ldr	x11, [sp, #1064]                ; 8-byte Folded Reload
	str	x11, [sp, #4008]
	add	x11, sp, #187
	ldrb	w11, [x11, #4095]
	strb	w11, [x3, #2]
	ldr	w11, [sp, #1156]                ; 4-byte Folded Reload
	str	w11, [sp, #4020]
	ldr	w11, [sp, #1160]                ; 4-byte Folded Reload
	str	w11, [sp, #4024]
	ldr	w11, [sp, #336]                 ; 4-byte Folded Reload
	strb	w11, [sp, #4028]
	ldrh	w11, [sp, #4278]
	strh	w11, [sp, #4030]
	ldr	w11, [sp, #1164]                ; 4-byte Folded Reload
	str	w11, [sp, #4032]
	ldr	w11, [sp, #1168]                ; 4-byte Folded Reload
	str	w11, [sp, #4036]
	ldr	w11, [sp, #340]                 ; 4-byte Folded Reload
	strb	w11, [sp, #4040]
	ldrh	w11, [sp, #4276]
	strh	w11, [x2, #4]
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	str	w11, [sp, #4048]
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	str	w11, [sp, #4052]
	ldr	x11, [sp, #864]                 ; 8-byte Folded Reload
	str	x11, [sp, #4056]
	ldr	x11, [sp, #872]                 ; 8-byte Folded Reload
	str	x11, [sp, #4064]
	ldr	x11, [sp, #880]                 ; 8-byte Folded Reload
	str	x11, [sp, #4072]
	ldr	w11, [sp, #252]                 ; 4-byte Folded Reload
	str	w11, [sp, #4080]
	ldr	w11, [sp, #184]                 ; 4-byte Folded Reload
	str	w11, [sp, #4084]
	ldr	x11, [sp, #832]                 ; 8-byte Folded Reload
	str	x11, [sp, #4088]
	ldr	x11, [sp, #840]                 ; 8-byte Folded Reload
	str	x11, [sp, #4096]
	ldr	x11, [sp, #848]                 ; 8-byte Folded Reload
	str	x11, [sp, #4104]
	add	x11, sp, #175
	ldrb	w11, [x11, #4095]
	strb	w11, [x16, #2]
	ldr	w11, [sp, #1032]                ; 4-byte Folded Reload
	str	w11, [sp, #4116]
	ldr	w11, [sp, #1036]                ; 4-byte Folded Reload
	str	w11, [sp, #4120]
	ldr	w11, [sp, #356]                 ; 4-byte Folded Reload
	strb	w11, [x12, #4095]
	ldrh	w11, [sp, #4266]
	ldr	w12, [sp, #360]                 ; 4-byte Folded Reload
	strh	w11, [sp, #4126]
	ldr	w11, [sp, #1040]                ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #364]                 ; 4-byte Folded Reload
	add	x13, sp, #41
	str	w11, [sp, #4128]
	ldr	w11, [sp, #1044]                ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #4260]
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	str	w11, [sp, #4132]
	ldrh	w11, [sp, #4264]
	str	w12, [x0]
	ldr	x12, [sp, #856]                 ; 8-byte Folded Reload
	strh	w11, [x0, #4]
	ldr	w11, [sp, #1380]                ; 4-byte Folded Reload
	str	x12, [sp, #4200]
	ldrh	w12, [sp, #4256]
	str	w11, [sp, #4144]
	ldr	w11, [sp, #172]                 ; 4-byte Folded Reload
	strb	w13, [x14, #4095]
	ldr	w13, [sp, #372]                 ; 4-byte Folded Reload
	add	x14, sp, #113
	str	w11, [sp, #4148]
	ldr	x11, [sp, #808]                 ; 8-byte Folded Reload
	strh	w12, [x17]
	ldr	w12, [sp, #376]                 ; 4-byte Folded Reload
	str	x11, [sp, #4152]
	ldr	x11, [sp, #816]                 ; 8-byte Folded Reload
	strb	w13, [x14, #4095]
	add	x13, sp, #125
	add	x14, sp, #138
	str	x11, [sp, #4160]
	ldr	x11, [sp, #824]                 ; 8-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #380]                 ; 4-byte Folded Reload
	add	x13, sp, #126
	str	x11, [sp, #4168]
	ldr	w11, [sp, #248]                 ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #384]                 ; 4-byte Folded Reload
	add	x13, sp, #137
	str	w11, [sp, #4176]
	ldr	w11, [sp, #176]                 ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w13, [sp, #388]                 ; 4-byte Folded Reload
	ldr	w12, [sp, #4248]
	str	w11, [sp, #4180]
	ldr	x11, [sp, #792]                 ; 8-byte Folded Reload
	strb	w13, [x14, #4095]
	add	x13, sp, #3472
	mov	w14, #96                        ; =0x60
	str	x11, [sp, #4184]
	ldr	x11, [sp, #800]                 ; 8-byte Folded Reload
	umaddl	x13, w21, w14, x13
	str	w12, [x1]
	str	x11, [sp, #4192]
	add	x11, sp, #163
	ldrb	w11, [x11, #4095]
	strb	wzr, [x13, #64]
	strb	w11, [x17, #2]
	ldr	w11, [sp, #996]                 ; 4-byte Folded Reload
	str	wzr, [x13]
	str	w11, [sp, #4212]
	ldr	w11, [sp, #1000]                ; 4-byte Folded Reload
	str	wzr, [x13, #32]
	str	w11, [sp, #4216]
	ldrh	w11, [sp, #4254]
	strh	wzr, [x13, #76]
	strh	w11, [sp, #4222]
	ldr	w11, [sp, #1028]                ; 4-byte Folded Reload
	stur	xzr, [x13, #68]
	str	w11, [sp, #4224]
	ldr	w11, [sp, #1004]                ; 4-byte Folded Reload
	str	w11, [sp, #4228]
	ldrh	w11, [sp, #4252]
	stp	x10, x9, [x13, #40]
	ldr	w10, [sp, #3472]
	strh	w11, [x1, #4]
	ldr	w11, [sp, #3668]
	str	x8, [x13, #56]
	ldr	w8, [sp, #3504]
	str	w10, [sp, #1328]                ; 4-byte Folded Spill
	ldr	w10, [sp, #3476]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3508]
	stp	x6, x30, [x13, #8]
	stp	w8, w10, [sp, #220]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3512]
	ldr	w10, [sp, #3572]
	str	x23, [x13, #24]
	ldr	x9, [sp, #3480]
	ldrh	w12, [sp, #3838]
	str	x8, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3520]
	ldrh	w14, [sp, #3934]
	strh	wzr, [x13, #88]
	ldrh	w15, [sp, #4126]
	ldrh	w6, [sp, #4222]
	str	x8, [sp, #1272]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3528]
	ldr	x28, [sp, #3912]
	str	xzr, [x13, #80]
	ldrh	w13, [sp, #4030]
	ldr	x23, [sp, #128]                 ; 8-byte Folded Reload
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3536]
	ldr	x27, [sp, #3904]
	str	x9, [sp, #240]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #3488]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3540]
	str	x9, [sp, #1296]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #3496]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3544]
	str	x9, [sp, #1288]                 ; 8-byte Folded Spill
	ldrh	w9, [sp, #3550]
	str	w8, [sp, #1232]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3548]
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3549]
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3552]
	str	w8, [sp, #1224]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3556]
	str	w8, [sp, #1220]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3560]
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3561]
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3568]
	str	w8, [sp, #1496]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3576]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3584]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3592]
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3600]
	str	w8, [sp, #264]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3604]
	stp	w8, w10, [sp, #212]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3608]
	ldrh	w10, [sp, #3646]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3616]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3624]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3632]
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3636]
	str	w8, [sp, #1136]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3640]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3644]
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3645]
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3648]
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3652]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3656]
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3657]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3664]
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3672]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3680]
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3688]
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3696]
	str	w8, [sp, #228]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3700]
	stp	w11, w8, [sp, #204]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3704]
	ldrh	w11, [sp, #3742]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3712]
	str	x8, [sp, #944]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3720]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3728]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3732]
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3736]
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3740]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3741]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3744]
	str	w8, [sp, #1120]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3748]
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3752]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3753]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3760]
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3764]
	str	w8, [sp, #196]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3768]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3776]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3784]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3792]
	str	w8, [sp, #260]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3796]
	str	w8, [sp, #200]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3800]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3808]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3816]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3824]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3828]
	str	w8, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3832]
	str	w8, [sp, #1080]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3836]
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3837]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3840]
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3844]
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3848]
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3849]
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3856]
	str	w8, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3860]
	str	w8, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3864]
	str	x8, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3872]
	str	x8, [sp, #1448]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3880]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3888]
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3892]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3896]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3920]
	str	w8, [sp, #232]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3924]
	str	w8, [sp, #1176]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3928]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3932]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3933]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3936]
	str	w8, [sp, #1188]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3940]
	str	w8, [sp, #236]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3944]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3945]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3952]
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3956]
	str	w8, [sp, #188]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3960]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3968]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3976]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3984]
	str	w8, [sp, #256]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3988]
	str	w8, [sp, #192]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3992]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4000]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4008]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #4016]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4020]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4024]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #4028]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #4029]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4032]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4036]
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #4040]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #4041]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4048]
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4052]
	str	w8, [sp, #180]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4056]
	str	x8, [sp, #864]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4064]
	str	x8, [sp, #872]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4072]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #4080]
	str	w8, [sp, #252]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4084]
	str	w8, [sp, #184]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4088]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4096]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4104]
	str	x8, [sp, #848]                  ; 8-byte Folded Spill
	add	x8, sp, #17
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4116]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4120]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	add	x8, sp, #29
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	add	x8, sp, #30
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4128]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4132]
	str	w8, [sp, #1044]                 ; 4-byte Folded Spill
	add	x8, sp, #41
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	add	x8, sp, #42
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4144]
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4148]
	str	w8, [sp, #172]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4152]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4160]
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4168]
	str	x8, [sp, #824]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #4176]
	str	w8, [sp, #248]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4180]
	str	w8, [sp, #176]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4184]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4192]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4200]
	str	x8, [sp, #856]                  ; 8-byte Folded Spill
	add	x8, sp, #113
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4212]
	str	w8, [sp, #996]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4216]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	add	x8, sp, #125
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	add	x8, sp, #126
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4224]
	str	w8, [sp, #1028]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4228]
	str	w8, [sp, #1004]                 ; 4-byte Folded Spill
	add	x8, sp, #137
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1320]                 ; 4-byte Folded Spill
	add	x8, sp, #138
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
LBB13_76:                               ; %b56_to_b57
                                        ;   in Loop: Header=BB13_26 Depth=1
	strh	w9, [sp, #3466]
	ldr	w9, [x25]
	ldrh	w21, [x26]
	strh	w10, [sp, #3454]
	ldrh	w10, [x23, #4]
	ldrb	w26, [x26, #2]
	str	w9, [sp, #3460]
	ldrh	w9, [x24]
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	strh	w10, [sp, #3452]
	ldrh	w10, [x22]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	strh	w9, [sp, #3456]
	ldr	w9, [x23]
	add	x23, sp, #3448
	strh	w10, [sp, #3444]
	ldr	w10, [x20]
	str	w9, [sp, #3448]
	ldrb	w9, [x22, #2]
	ldrh	w22, [x1, #4]
	str	w10, [sp, #3436]
	ldrh	w10, [x19]
	strb	w9, [sp, #3446]
	ldrh	w9, [x20, #4]
	ldrb	w20, [x17, #2]
	strh	w10, [sp, #3432]
	ldr	w10, [x7]
	strh	w9, [sp, #3440]
	ldrb	w9, [x19, #2]
	add	x19, sp, #3396
	str	w10, [sp, #3424]
	ldrh	w10, [x5]
	strb	w9, [sp, #3434]
	ldrh	w9, [x7, #4]
	add	x7, sp, #3384
	strh	w21, [sp, #3468]
	ldrh	w21, [x25, #4]
	add	x25, sp, #3460
	strh	w9, [sp, #3428]
	ldrb	w9, [x5, #2]
	ldrh	w5, [x17]
	add	x17, sp, #3420
	strh	w10, [sp, #3420]
	ldr	w10, [x4]
	strh	w12, [sp, #3430]
	ldrb	w12, [x3, #2]
	strb	w9, [sp, #3422]
	ldrh	w9, [x4, #4]
	add	x4, sp, #3406
	strh	w21, [sp, #3464]
	ldrb	w21, [x24, #2]
	add	x24, sp, #3454
	str	w10, [sp, #3412]
	mov	w10, #1                         ; =0x1
	strh	w11, [sp, #3442]
	ldrh	w11, [x3]
	add	x3, sp, #3376
	strh	w14, [sp, #3418]
	ldrh	w14, [x2, #4]
	strh	w9, [sp, #3416]
	ldr	w9, [x2]
	ldr	w2, [x0]
	str	w10, [sp, #156]                 ; 4-byte Folded Spill
	ldrh	w10, [x16]
	ldrh	w0, [x0, #4]
	strb	w12, [sp, #3410]
	ldrb	w12, [x16, #2]
	add	x16, sp, #3382
	strb	w21, [sp, #3458]
	ldr	w21, [x1]
	add	x1, sp, #3412
	strb	w26, [sp, #3470]
	add	x26, sp, #3468
	strh	w11, [sp, #3408]
	add	x11, sp, #3408
	strh	w13, [sp, #3406]
	add	x13, sp, #3394
	strh	w14, [sp, #3404]
	add	x14, sp, #3388
	str	w9, [sp, #3400]
	add	x9, sp, #3424
	strb	w12, [sp, #3398]
	add	x12, sp, #3400
	strh	w10, [sp, #3396]
	add	x10, sp, #3418
	strh	w15, [sp, #3394]
	add	x15, sp, #3430
	strh	w0, [sp, #3392]
	add	x0, sp, #3432
	str	w2, [sp, #3388]
	add	x2, sp, #3436
	strb	w20, [sp, #3386]
	add	x20, sp, #3466
	strh	w5, [sp, #3384]
	add	x5, sp, #3442
	strh	w6, [sp, #3382]
	add	x6, sp, #3444
	strh	w22, [sp, #3380]
	add	x22, sp, #3456
	str	x28, [sp, #1480]                ; 8-byte Folded Spill
	str	x27, [sp, #1472]                ; 8-byte Folded Spill
	str	w21, [sp, #3376]
LBB13_77:                               ; %b57_to_b58
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldrh	w20, [x20]
	ldrh	w21, [x26]
	add	x27, sp, #3364
	ldrh	w5, [x5]
	ldrb	w26, [x26, #2]
	add	x28, sp, #3372
	strh	w20, [sp, #3370]
	ldrh	w20, [x25, #4]
	ldrh	w15, [x15]
	strh	w21, [sp, #3372]
	ldr	w21, [x25]
	add	x25, sp, #3352
	strh	w20, [sp, #3368]
	ldrb	w20, [x22, #2]
	str	w21, [sp, #3364]
	ldrh	w21, [x22]
	ldrh	w22, [x24]
	add	x24, sp, #3340
	strb	w20, [sp, #3362]
	ldr	w20, [x23]
	strh	w21, [sp, #3360]
	ldrh	w21, [x23, #4]
	add	x23, sp, #3336
	str	w20, [sp, #3352]
	ldrh	w20, [x6]
	ldrb	w6, [x6, #2]
	strh	w5, [sp, #3346]
	ldrb	w5, [x0, #2]
	ldrh	w0, [x0]
	strh	w20, [sp, #3348]
	ldrh	w20, [x4]
	add	x4, sp, #3312
	strb	w6, [sp, #3350]
	ldrh	w6, [x2, #4]
	ldr	w2, [x2]
	strh	w20, [sp, #3310]
	ldr	w20, [x12]
	strh	w21, [sp, #3356]
	ldrb	w21, [x19, #2]
	str	w20, [sp, #3304]
	ldrh	w20, [x19]
	add	x19, sp, #3328
	str	w2, [sp, #3340]
	ldr	w2, [x9]
	strb	w5, [sp, #3338]
	ldrh	w5, [x10]
	add	x10, sp, #3298
	strb	w21, [sp, #3302]
	ldr	w21, [x14]
	strh	w20, [sp, #3300]
	ldrh	w20, [x14, #4]
	strh	w22, [sp, #3358]
	ldrh	w22, [x13]
	add	x13, sp, #3346
	strh	w6, [sp, #3344]
	ldrb	w6, [x11, #2]
	strh	w0, [sp, #3336]
	ldrh	w0, [x9, #4]
	add	x9, sp, #3286
	str	w2, [sp, #3328]
	ldrh	w2, [x17]
	strh	w5, [sp, #3322]
	ldr	w5, [x1]
	strh	w20, [sp, #3296]
	ldrb	w20, [x7, #2]
	str	w21, [sp, #3292]
	ldrh	w21, [x7]
	add	x7, sp, #3348
	strh	w0, [sp, #3332]
	ldrb	w0, [x17, #2]
	add	x17, sp, #3288
	strh	w2, [sp, #3324]
	ldrh	w2, [x1, #4]
	add	x1, sp, #3300
	str	w5, [sp, #3316]
	ldrh	w5, [x11]
	add	x11, sp, #3310
	strb	w6, [sp, #3314]
	ldrh	w6, [x12, #4]
	add	x12, sp, #3322
	strh	w22, [sp, #3298]
	ldrh	w22, [x16]
	add	x16, sp, #3358
	str	x9, [sp, #160]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #712]                  ; 8-byte Folded Reload
	strb	w20, [sp, #3290]
	ldrh	w20, [x3, #4]
	strh	w21, [sp, #3288]
	ldr	w21, [x3]
	add	x3, sp, #3370
	strb	w26, [sp, #3374]
	add	x26, sp, #3360
	strh	w15, [sp, #3334]
	add	x15, sp, #3280
	strb	w0, [sp, #3326]
	add	x0, sp, #3292
	strh	w2, [sp, #3320]
	add	x2, sp, #3304
	strh	w5, [sp, #3312]
	add	x5, sp, #3316
	strh	w6, [sp, #3308]
	add	x6, sp, #3324
	strh	w22, [sp, #3286]
	add	x22, sp, #3334
	strh	w20, [sp, #3284]
	str	w21, [sp, #3280]
LBB13_78:                               ; %b58_to_b59
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w20, [sp, #1328]                ; 4-byte Folded Reload
	str	x8, [sp, #2424]
	ldr	x8, [sp, #1296]                 ; 8-byte Folded Reload
	ldrb	w21, [x28, #2]
	ldrh	w14, [x13]
	ldrh	w12, [x12]
	str	w20, [sp, #2416]
	ldrh	w20, [x28]
	ldrh	w11, [x11]
	str	x8, [sp, #2432]
	ldr	x8, [sp, #1288]                 ; 8-byte Folded Reload
	ldrh	w13, [x22]
	mov	x22, x9
	strh	w20, [sp, #3276]
	ldr	w20, [x27]
	str	x8, [sp, #2440]
	ldr	w8, [sp, #312]                  ; 4-byte Folded Reload
	ldrh	w10, [x10]
	str	w20, [sp, #3268]
	ldrb	w20, [x26, #2]
	str	w8, [sp, #2448]
	ldr	w8, [sp, #220]                  ; 4-byte Folded Reload
	strb	w20, [sp, #3266]
	ldr	w20, [x25]
	str	w8, [sp, #2452]
	ldr	x8, [sp, #1280]                 ; 8-byte Folded Reload
	str	w20, [sp, #3256]
	ldrh	w20, [x7]
	ldrb	w7, [x7, #2]
	str	x8, [sp, #2456]
	ldr	x8, [sp, #1272]                 ; 8-byte Folded Reload
	strb	w7, [sp, #3254]
	ldrh	w7, [x24, #4]
	strh	w20, [sp, #3252]
	ldr	w20, [x24]
	strh	w7, [sp, #3248]
	ldrh	w7, [x23]
	str	w20, [sp, #3244]
	ldrb	w20, [x23, #2]
	ldr	x23, [sp, #624]                 ; 8-byte Folded Reload
	strh	w7, [sp, #3240]
	ldr	w7, [x19]
	strb	w20, [sp, #3242]
	ldrh	w20, [x19, #4]
	ldrb	w19, [x6, #2]
	str	w7, [sp, #3232]
	ldrh	w7, [x5, #4]
	ldr	w5, [x5]
	ldrh	w6, [x6]
	strb	w19, [sp, #3230]
	str	w5, [sp, #3220]
	ldrh	w5, [x2, #4]
	ldr	w2, [x2]
	strh	w6, [sp, #3228]
	ldrb	w6, [x4, #2]
	ldrh	w4, [x4]
	str	w2, [sp, #3208]
	ldrh	w2, [x0, #4]
	ldr	w0, [x0]
	strh	w4, [sp, #3216]
	ldrb	w4, [x1, #2]
	ldrh	w1, [x1]
	str	w0, [sp, #3196]
	ldrh	w0, [x15, #4]
	ldr	w15, [x15]
	strh	w1, [sp, #3204]
	ldrb	w1, [x17, #2]
	ldrh	w17, [x17]
	str	w15, [sp, #3184]
	ldrh	w15, [sp, #3228]
	strh	w17, [sp, #3192]
	ldrb	w17, [sp, #3230]
	strh	w15, [sp, #2412]
	ldr	w15, [sp, #3220]
	strh	w7, [sp, #3224]
	ldr	x7, [sp, #600]                  ; 8-byte Folded Reload
	strb	w17, [sp, #2414]
	ldrh	w17, [sp, #3224]
	str	w15, [sp, #2404]
	ldrh	w15, [sp, #3216]
	strb	w6, [sp, #3218]
	ldr	x6, [sp, #648]                  ; 8-byte Folded Reload
	strh	w17, [sp, #2408]
	ldrb	w17, [sp, #3218]
	strh	w15, [sp, #2400]
	ldr	w15, [sp, #3208]
	strh	w5, [sp, #3212]
	strb	w17, [sp, #2402]
	ldrh	w17, [sp, #3212]
	str	w15, [sp, #2392]
	ldrh	w15, [sp, #3204]
	strb	w4, [sp, #3206]
	strh	w17, [sp, #2396]
	ldrb	w17, [sp, #3206]
	strh	w15, [sp, #2388]
	ldr	w15, [sp, #3196]
	strh	w2, [sp, #3200]
	strb	w17, [sp, #2390]
	ldrh	w17, [sp, #3200]
	str	w15, [sp, #2380]
	ldrh	w15, [sp, #3192]
	strb	w1, [sp, #3194]
	strh	w17, [sp, #2384]
	ldrb	w17, [sp, #3194]
	strh	w15, [sp, #2376]
	ldr	w15, [sp, #3184]
	str	x8, [sp, #2464]
	ldr	x8, [sp, #1248]                 ; 8-byte Folded Reload
	strh	w0, [sp, #3188]
	strb	w17, [sp, #2378]
	ldrh	w17, [sp, #3188]
	str	w15, [sp, #2368]
	ldr	w15, [sp, #224]                 ; 4-byte Folded Reload
	str	x8, [sp, #2472]
	ldr	w8, [sp, #784]                  ; 4-byte Folded Reload
	strb	w21, [sp, #3278]
	ldrh	w21, [x27, #4]
	strh	w17, [sp, #2372]
	ldrh	w17, [sp, #3276]
	str	w15, [sp, #2420]
	ldrb	w15, [sp, #3278]
	strb	w8, [sp, #2480]
	ldr	x8, [sp, #696]                  ; 8-byte Folded Reload
	strh	w21, [sp, #3272]
	ldrh	w21, [x26]
	mov	x0, x8
	strb	w15, [x8, #2]
	ldrh	w15, [x3]
	strh	w17, [x8]
	ldr	w8, [sp, #1240]                 ; 4-byte Folded Reload
	ldr	w17, [sp, #3268]
	strh	w15, [sp, #2494]
	ldrh	w15, [sp, #3272]
	str	w8, [sp, #2484]
	ldr	w8, [sp, #1232]                 ; 4-byte Folded Reload
	strh	w21, [sp, #3264]
	ldrh	w21, [x25, #4]
	str	w8, [sp, #2488]
	ldr	w8, [sp, #400]                  ; 4-byte Folded Reload
	strh	w21, [sp, #3260]
	ldr	x21, [sp, #640]                 ; 8-byte Folded Reload
	strb	w8, [sp, #2492]
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	strh	w14, [sp, #2686]
	ldrh	w14, [sp, #3248]
	strb	w8, [sp, #2493]
	ldr	w8, [sp, #1224]                 ; 4-byte Folded Reload
	strh	w20, [sp, #3236]
	ldr	x20, [sp, #632]                 ; 8-byte Folded Reload
	str	w8, [sp, #2496]
	ldr	w8, [sp, #1220]                 ; 4-byte Folded Reload
	strh	w12, [sp, #2878]
	ldrh	w12, [sp, #2408]
	str	w8, [sp, #2500]
	ldr	w8, [sp, #396]                  ; 4-byte Folded Reload
	strh	w12, [x20, #4]
	ldrb	w12, [sp, #2402]
	strb	w8, [sp, #2504]
	ldr	w8, [sp, #392]                  ; 4-byte Folded Reload
	strb	w12, [x23, #2]
	ldr	w12, [sp, #2392]
	strb	w8, [sp, #2505]
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	strh	w11, [sp, #2974]
	ldrh	w11, [sp, #2396]
	mov	x1, x8
	strh	w15, [x8, #4]
	ldrb	w15, [sp, #3266]
	str	w17, [x8]
	ldr	w8, [sp, #1496]                 ; 4-byte Folded Reload
	ldrh	w17, [sp, #3264]
	strh	w11, [x9, #4]
	ldrb	w11, [sp, #2390]
	str	w8, [sp, #2512]
	ldr	w8, [sp, #216]                  ; 4-byte Folded Reload
	str	w12, [x9]
	ldrh	w12, [sp, #2388]
	str	w8, [sp, #2516]
	ldr	x8, [sp, #1200]                 ; 8-byte Folded Reload
	strh	w13, [sp, #2782]
	ldrh	w13, [sp, #3236]
	str	x8, [sp, #2520]
	ldr	x8, [sp, #1208]                 ; 8-byte Folded Reload
	strh	w13, [x6, #4]
	ldrb	w13, [sp, #2414]
	str	x8, [sp, #2528]
	ldr	x8, [sp, #1192]                 ; 8-byte Folded Reload
	strh	w10, [sp, #3070]
	ldrh	w10, [sp, #2384]
	str	x8, [sp, #2536]
	ldr	w8, [sp, #264]                  ; 4-byte Folded Reload
	strb	w13, [x21, #2]
	ldr	w13, [sp, #2404]
	str	w8, [sp, #2544]
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	str	w13, [x20]
	ldrh	w13, [sp, #2400]
	str	w8, [sp, #2548]
	ldr	x8, [sp, #1008]                 ; 8-byte Folded Reload
	strh	w13, [x23]
	str	x8, [sp, #2552]
	ldr	x8, [sp, #1016]                 ; 8-byte Folded Reload
	str	x8, [sp, #2560]
	ldr	x8, [sp, #984]                  ; 8-byte Folded Reload
	str	x8, [sp, #2568]
	ldr	w8, [sp, #268]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2576]
	ldr	x8, [sp, #680]                  ; 8-byte Folded Reload
	mov	x2, x8
	strb	w15, [x8, #2]
	ldrh	w15, [x16]
	strh	w17, [x8]
	ldr	w8, [sp, #1136]                 ; 4-byte Folded Reload
	ldr	w16, [sp, #3256]
	strh	w15, [sp, #2590]
	ldrh	w15, [sp, #3260]
	ldr	x17, [sp, #672]                 ; 8-byte Folded Reload
	str	w8, [sp, #2580]
	ldr	w8, [sp, #1144]                 ; 4-byte Folded Reload
	strh	w15, [x17, #4]
	ldrb	w15, [sp, #3254]
	str	w8, [sp, #2584]
	ldr	w8, [sp, #272]                  ; 4-byte Folded Reload
	str	w16, [x17]
	ldrh	w16, [sp, #3252]
	strb	w8, [sp, #2588]
	ldr	w8, [sp, #280]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2589]
	ldr	w8, [sp, #1148]                 ; 4-byte Folded Reload
	str	w8, [sp, #2592]
	ldr	w8, [sp, #1152]                 ; 4-byte Folded Reload
	str	w8, [sp, #2596]
	ldr	w8, [sp, #276]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2600]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2601]
	ldr	w8, [sp, #1344]                 ; 4-byte Folded Reload
	str	w8, [sp, #2608]
	ldr	w8, [sp, #204]                  ; 4-byte Folded Reload
	str	w8, [sp, #2612]
	ldr	x8, [sp, #960]                  ; 8-byte Folded Reload
	str	x8, [sp, #2616]
	ldr	x8, [sp, #968]                  ; 8-byte Folded Reload
	str	x8, [sp, #2624]
	ldr	x8, [sp, #976]                  ; 8-byte Folded Reload
	str	x8, [sp, #2632]
	ldr	w8, [sp, #228]                  ; 4-byte Folded Reload
	str	w8, [sp, #2640]
	ldr	w8, [sp, #208]                  ; 4-byte Folded Reload
	str	w8, [sp, #2644]
	ldr	x8, [sp, #936]                  ; 8-byte Folded Reload
	str	x8, [sp, #2648]
	ldr	x8, [sp, #944]                  ; 8-byte Folded Reload
	str	x8, [sp, #2656]
	ldr	x8, [sp, #952]                  ; 8-byte Folded Reload
	str	x8, [sp, #2664]
	ldr	w8, [sp, #288]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2672]
	ldr	x8, [sp, #664]                  ; 8-byte Folded Reload
	strb	w15, [x8, #2]
	mov	x3, x8
	ldr	w15, [sp, #3244]
	strh	w16, [x8]
	ldr	w8, [sp, #1112]                 ; 4-byte Folded Reload
	str	w8, [sp, #2676]
	ldr	w8, [sp, #1116]                 ; 4-byte Folded Reload
	str	w8, [sp, #2680]
	ldr	w8, [sp, #292]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2684]
	ldr	w8, [sp, #300]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2685]
	ldr	w8, [sp, #1120]                 ; 4-byte Folded Reload
	str	w8, [sp, #2688]
	ldr	w8, [sp, #1132]                 ; 4-byte Folded Reload
	str	w8, [sp, #2692]
	ldr	w8, [sp, #296]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2696]
	ldr	w8, [sp, #304]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2697]
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	strh	w14, [x8, #4]
	mov	x16, x8
	ldrb	w14, [sp, #3242]
	str	w15, [x8]
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	ldrh	w15, [sp, #3240]
	str	w8, [sp, #2704]
	ldr	w8, [sp, #196]                  ; 4-byte Folded Reload
	str	w8, [sp, #2708]
	ldr	x8, [sp, #912]                  ; 8-byte Folded Reload
	str	x8, [sp, #2712]
	ldr	x8, [sp, #920]                  ; 8-byte Folded Reload
	str	x8, [sp, #2720]
	ldr	x8, [sp, #928]                  ; 8-byte Folded Reload
	str	x8, [sp, #2728]
	ldr	w8, [sp, #260]                  ; 4-byte Folded Reload
	str	w8, [sp, #2736]
	ldr	w8, [sp, #200]                  ; 4-byte Folded Reload
	str	w8, [sp, #2740]
	ldr	x8, [sp, #888]                  ; 8-byte Folded Reload
	str	x8, [sp, #2744]
	ldr	x8, [sp, #896]                  ; 8-byte Folded Reload
	str	x8, [sp, #2752]
	ldr	x8, [sp, #904]                  ; 8-byte Folded Reload
	str	x8, [sp, #2760]
	ldr	w8, [sp, #308]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2768]
	ldr	x8, [sp, #752]                  ; 8-byte Folded Reload
	strb	w14, [x8, #2]
	ldr	w14, [sp, #3232]
	strh	w15, [x8]
	ldr	w8, [sp, #1076]                 ; 4-byte Folded Reload
	ldr	x15, [sp, #608]                 ; 8-byte Folded Reload
	str	w14, [x6]
	ldrh	w14, [sp, #2412]
	str	w8, [sp, #2772]
	ldr	w8, [sp, #1080]                 ; 4-byte Folded Reload
	strh	w14, [x21]
	ldr	x14, [sp, #616]                 ; 8-byte Folded Reload
	str	w8, [sp, #2776]
	ldr	w8, [sp, #1428]                 ; 4-byte Folded Reload
	strb	w11, [x14, #2]
	ldr	w11, [sp, #2380]
	strb	w8, [sp, #2780]
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	strh	w10, [x15, #4]
	ldrb	w10, [sp, #2378]
	strb	w8, [sp, #2781]
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	str	w11, [x15]
	ldrh	w11, [sp, #2376]
	str	w8, [sp, #2784]
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	strb	w10, [x7, #2]
	ldr	w10, [sp, #2368]
	str	w8, [sp, #2788]
	ldr	w8, [sp, #1404]                 ; 4-byte Folded Reload
	strh	w12, [x14]
	strb	w8, [sp, #2792]
	ldr	w8, [sp, #1408]                 ; 4-byte Folded Reload
	strh	w11, [x7]
	strb	w8, [sp, #2793]
	ldr	w8, [sp, #1492]                 ; 4-byte Folded Reload
	str	w10, [x30]
	str	w8, [sp, #2800]
	ldr	w8, [sp, #1388]                 ; 4-byte Folded Reload
	str	w8, [sp, #2804]
	ldr	x8, [sp, #1456]                 ; 8-byte Folded Reload
	str	x8, [sp, #2808]
	ldr	x8, [sp, #1448]                 ; 8-byte Folded Reload
	str	x8, [sp, #2816]
	ldr	x8, [sp, #1440]                 ; 8-byte Folded Reload
	str	x8, [sp, #2824]
	ldr	w8, [sp, #1392]                 ; 4-byte Folded Reload
	str	w8, [sp, #2832]
	ldr	w8, [sp, #1384]                 ; 4-byte Folded Reload
	str	w8, [sp, #2836]
	ldr	x8, [sp, #1432]                 ; 8-byte Folded Reload
	str	x8, [sp, #2840]
	ldr	x8, [sp, #1472]                 ; 8-byte Folded Reload
	str	x8, [sp, #2848]
	ldr	x8, [sp, #1480]                 ; 8-byte Folded Reload
	str	x8, [sp, #2856]
	ldr	w8, [sp, #232]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2864]
	ldr	w8, [sp, #1176]                 ; 4-byte Folded Reload
	str	w8, [sp, #2868]
	ldr	w8, [sp, #1184]                 ; 4-byte Folded Reload
	str	w8, [sp, #2872]
	ldr	w8, [sp, #316]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2876]
	ldr	w8, [sp, #324]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2877]
	ldr	w8, [sp, #1188]                 ; 4-byte Folded Reload
	str	w8, [sp, #2880]
	ldr	w8, [sp, #236]                  ; 4-byte Folded Reload
	str	w8, [sp, #2884]
	ldr	w8, [sp, #320]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2888]
	ldr	w8, [sp, #328]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2889]
	ldr	w8, [sp, #1364]                 ; 4-byte Folded Reload
	str	w8, [sp, #2896]
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	str	w8, [sp, #2900]
	ldr	x8, [sp, #1088]                 ; 8-byte Folded Reload
	str	x8, [sp, #2904]
	ldr	x8, [sp, #1096]                 ; 8-byte Folded Reload
	str	x8, [sp, #2912]
	ldr	x8, [sp, #1104]                 ; 8-byte Folded Reload
	str	x8, [sp, #2920]
	ldr	w8, [sp, #256]                  ; 4-byte Folded Reload
	str	w8, [sp, #2928]
	ldr	w8, [sp, #192]                  ; 4-byte Folded Reload
	str	w8, [sp, #2932]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	str	x8, [sp, #2936]
	ldr	x8, [sp, #1056]                 ; 8-byte Folded Reload
	str	x8, [sp, #2944]
	ldr	x8, [sp, #1064]                 ; 8-byte Folded Reload
	str	x8, [sp, #2952]
	ldr	w8, [sp, #332]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2960]
	ldr	w8, [sp, #1156]                 ; 4-byte Folded Reload
	str	w8, [sp, #2964]
	ldr	w8, [sp, #1160]                 ; 4-byte Folded Reload
	str	w8, [sp, #2968]
	ldr	w8, [sp, #336]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2972]
	ldr	w8, [sp, #344]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2973]
	ldr	w8, [sp, #1164]                 ; 4-byte Folded Reload
	str	w8, [sp, #2976]
	ldr	w8, [sp, #1168]                 ; 4-byte Folded Reload
	str	w8, [sp, #2980]
	ldr	w8, [sp, #340]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2984]
	ldr	w8, [sp, #348]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2985]
	ldr	w8, [sp, #1368]                 ; 4-byte Folded Reload
	str	w8, [sp, #2992]
	ldr	w8, [sp, #180]                  ; 4-byte Folded Reload
	str	w8, [sp, #2996]
	ldr	x8, [sp, #864]                  ; 8-byte Folded Reload
	str	x8, [sp, #3000]
	ldr	x8, [sp, #872]                  ; 8-byte Folded Reload
	str	x8, [sp, #3008]
	ldr	x8, [sp, #880]                  ; 8-byte Folded Reload
	str	x8, [sp, #3016]
	ldr	w8, [sp, #252]                  ; 4-byte Folded Reload
	str	w8, [sp, #3024]
	ldr	w8, [sp, #184]                  ; 4-byte Folded Reload
	str	w8, [sp, #3028]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	str	x8, [sp, #3032]
	ldr	x8, [sp, #840]                  ; 8-byte Folded Reload
	str	x8, [sp, #3040]
	ldr	x8, [sp, #848]                  ; 8-byte Folded Reload
	str	x8, [sp, #3048]
	ldr	w8, [sp, #352]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3056]
	ldr	w8, [sp, #1032]                 ; 4-byte Folded Reload
	str	w8, [sp, #3060]
	ldr	w8, [sp, #1036]                 ; 4-byte Folded Reload
	str	w8, [sp, #3064]
	ldr	w8, [sp, #356]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3068]
	ldr	w8, [sp, #360]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3069]
	ldr	w8, [sp, #1040]                 ; 4-byte Folded Reload
	str	w8, [sp, #3072]
	ldr	w8, [sp, #1044]                 ; 4-byte Folded Reload
	str	w8, [sp, #3076]
	ldr	w8, [sp, #364]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3080]
	ldr	w8, [sp, #368]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3081]
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	str	w8, [sp, #3088]
	ldr	w8, [sp, #172]                  ; 4-byte Folded Reload
	str	w8, [sp, #3092]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	str	x8, [sp, #3096]
	ldr	x8, [sp, #816]                  ; 8-byte Folded Reload
	str	x8, [sp, #3104]
	ldr	x8, [sp, #824]                  ; 8-byte Folded Reload
	str	x8, [sp, #3112]
	ldr	w8, [sp, #248]                  ; 4-byte Folded Reload
	str	w8, [sp, #3120]
	ldr	w8, [sp, #176]                  ; 4-byte Folded Reload
	str	w8, [sp, #3124]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	str	x8, [sp, #3128]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	str	x8, [sp, #3136]
	ldr	x8, [sp, #856]                  ; 8-byte Folded Reload
	str	x8, [sp, #3144]
	ldr	w8, [sp, #372]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3152]
	ldr	w8, [sp, #996]                  ; 4-byte Folded Reload
	str	w8, [sp, #3156]
	ldr	w8, [sp, #1000]                 ; 4-byte Folded Reload
	str	w8, [sp, #3160]
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldrh	w9, [x8]
	ldr	w8, [sp, #376]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3164]
	ldr	w8, [sp, #380]                  ; 4-byte Folded Reload
	strh	w9, [sp, #3166]
	ldrh	w9, [sp, #2372]
	strb	w8, [sp, #3165]
	ldr	w8, [sp, #1028]                 ; 4-byte Folded Reload
	strh	w9, [x30, #4]
	str	w8, [sp, #3168]
	ldr	w8, [sp, #1004]                 ; 4-byte Folded Reload
	str	w8, [sp, #3172]
	ldr	w8, [sp, #384]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3176]
	ldr	w8, [sp, #388]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3177]
	ldr	w8, [sp, #1320]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_24
; %bb.79:                               ; %v132_ok.preheader
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, #2048                       ; =0x800
	ldr	x4, [sp, #592]                  ; 8-byte Folded Reload
	ldr	x11, [sp, #744]                 ; 8-byte Folded Reload
	ldr	x12, [sp, #736]                 ; 8-byte Folded Reload
	mov	x26, xzr
	str	xzr, [sp, #1368]                ; 8-byte Folded Spill
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	add	x9, sp, #2416
LBB13_80:                               ; %v132_ok
                                        ;   Parent Loop BB13_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, sp, #2416
	str	x26, [sp, #1496]                ; 8-byte Folded Spill
	add	x8, x8, x26
	ldr	w27, [x8]
	cmp	w27, #1
	b.ne	LBB13_82
; %bb.81:                               ; %b66_to_b274
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x8, [sp, #2440]
	ldr	d0, [sp, #2592]
	mov	x19, x7
	ldur	q17, [x9, #8]
	ldur	q30, [x9, #40]
	add	x26, sp, #2416
	str	x8, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2472]
	mov	x10, x2
	str	d0, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #2608]
	add	x7, sp, #2416
	str	x8, [sp, #1224]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2480]
	mov	x25, x6
	str	d0, [sp, #1344]                 ; 8-byte Folded Spill
	ldur	q0, [x9, #200]
	mov	x24, x21
	str	w8, [sp, #1220]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2492]
	mov	x28, x20
	str	q0, [sp, #1328]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #2640]
	mov	x13, x14
	str	w8, [sp, #1208]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2493]
	mov	x27, x19
	str	d0, [sp, #1320]                 ; 8-byte Folded Spill
	ldur	q0, [x9, #232]
	ldur	d31, [x9, #68]
	str	w8, [sp, #1200]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2494]
	ldur	q10, [x9, #104]
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	ldr	d0, [x4]
	ldur	q12, [x9, #136]
	str	w8, [sp, #1192]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2504]
	ldur	d13, [x9, #164]
	str	d0, [sp, #1288]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #2688]
	ldr	x9, [sp, #768]                  ; 8-byte Folded Reload
	str	w8, [sp, #1188]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2505]
	ldr	x5, [sp, #752]                  ; 8-byte Folded Reload
	str	d0, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #2704]
	ldr	q4, [x9]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2536]
	ldr	x9, [sp, #760]                  ; 8-byte Folded Reload
	str	d0, [sp, #1272]                 ; 8-byte Folded Spill
	ldur	q0, [x4, #36]
	ldr	d14, [sp, #2448]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2568]
	ldr	d8, [sp, #2496]
	str	q0, [sp, #1248]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #2736]
	ldr	d9, [sp, #2512]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2576]
	ldr	d11, [sp, #2544]
	str	d0, [sp, #1240]                 ; 8-byte Folded Spill
	ldur	q18, [x4, #68]
	ldr	d19, [x4, #96]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2588]
	ldr	d20, [x4, #192]
	ldr	d21, [sp, #2880]
	ldr	d22, [sp, #2896]
	ldur	q23, [x4, #228]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2589]
	ldr	d24, [sp, #2928]
	ldr	q25, [x11]
	mov	x11, x1
	ldr	d26, [x4, #288]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2590]
	ldr	d27, [sp, #2976]
	ldr	d28, [sp, #2992]
	ldr	q29, [x12]
	mov	x12, x0
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2600]
	ldr	d15, [sp, #3024]
	ldr	d1, [x4, #384]
	ldr	d2, [sp, #3072]
	ldr	d3, [sp, #3088]
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2601]
	ldr	d5, [sp, #3120]
	ldr	q6, [x9]
	mov	x9, x15
	ldr	d7, [x4, #480]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2632]
	ldr	d16, [sp, #3168]
	str	x30, [sp, #832]                 ; 8-byte Folded Spill
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2664]
	str	x17, [sp, #792]                 ; 8-byte Folded Spill
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2672]
	str	x3, [sp, #800]                  ; 8-byte Folded Spill
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2684]
	str	x16, [sp, #816]                 ; 8-byte Folded Spill
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2685]
	str	x5, [sp, #824]                  ; 8-byte Folded Spill
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2686]
	str	x23, [sp, #784]                 ; 8-byte Folded Spill
	str	w8, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2696]
	str	x22, [sp, #808]                 ; 8-byte Folded Spill
	str	w8, [sp, #1088]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2697]
	str	w8, [sp, #1096]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2728]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2760]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2768]
	str	w8, [sp, #1064]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2780]
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2781]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2782]
	str	w8, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2784]
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2788]
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2792]
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2793]
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2800]
	str	w8, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2804]
	str	w8, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2808]
	str	x8, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2816]
	str	x8, [sp, #1448]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2824]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2832]
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2836]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2840]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2848]
	str	x8, [sp, #1472]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2856]
	str	x8, [sp, #1480]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2864]
	str	w8, [sp, #1016]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2876]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2877]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2878]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2888]
	str	w8, [sp, #1028]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2889]
	str	w8, [sp, #1044]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2920]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2952]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2960]
	str	w8, [sp, #968]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2972]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2973]
	str	w8, [sp, #996]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2974]
	str	w8, [sp, #984]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2984]
	str	w8, [sp, #976]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2985]
	str	w8, [sp, #1004]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3016]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3048]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3056]
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3068]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3069]
	str	w8, [sp, #880]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #3070]
	str	w8, [sp, #904]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3080]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3081]
	str	w8, [sp, #888]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3112]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3144]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3152]
	str	w8, [sp, #912]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3164]
	str	w8, [sp, #936]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3165]
	str	w8, [sp, #920]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #3166]
	str	w8, [sp, #928]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3176]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3177]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #776]                  ; 8-byte Folded Reload
	ldr	q0, [x8]
	b	LBB13_108
LBB13_82:                               ; %b67
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldrb	w10, [x8, #64]
	ldp	x23, x26, [x8, #8]
	ldr	w9, [x8, #32]
	ldr	x11, [x8, #24]
	ldr	x19, [x8, #56]
	str	w10, [sp, #1440]                ; 4-byte Folded Spill
	ldr	w10, [x8, #68]
	ldrb	w22, [x8, #88]
	cmp	w9, #1
	ldr	x0, [sp, #720]                  ; 8-byte Folded Reload
	str	w9, [sp, #1428]                 ; 4-byte Folded Spill
	str	w10, [sp, #1492]                ; 4-byte Folded Spill
	ldr	w10, [x8, #72]
	ldp	x20, x25, [x8, #40]
	str	w10, [sp, #1480]                ; 4-byte Folded Spill
	ldrb	w10, [x8, #76]
	str	w10, [sp, #1456]                ; 4-byte Folded Spill
	ldrb	w10, [x8, #77]
	str	w10, [sp, #1472]                ; 4-byte Folded Spill
	ldp	w10, w21, [x8, #80]
	ldrb	w8, [x8, #89]
	str	w10, [sp, #1448]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	str	w21, [sp, #1468]                ; 4-byte Folded Spill
	b.ne	LBB13_84
; %bb.83:                               ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	str	w22, [sp, #1432]                ; 4-byte Folded Spill
	ldr	w22, [sp, #1428]                ; 4-byte Folded Reload
	mov	x28, x26
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	str	wzr, [sp, #1364]                ; 4-byte Folded Spill
	str	w8, [sp, #732]                  ; 4-byte Folded Spill
	mov	x24, x20
	mov	x20, x11
	b	LBB13_107
LBB13_84:                               ; %b70
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x1, x23
	mov	x2, x26
	mov	x3, x11
	mov	x24, x25
	mov	x25, x19
	mov	x28, x0
	str	x23, [sp, #1408]                ; 8-byte Folded Spill
	mov	x19, x11
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	str	x19, [sp, #1416]                ; 8-byte Folded Spill
	cbnz	x8, LBB13_86
; %bb.85:                               ; %b1.i.i199
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x23, x0
	mov	w21, wzr
	b	LBB13_89
LBB13_86:                               ; %v8_ok.i.i181
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_88
; %bb.87:                               ; %v8_ok.i.i181
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh10:
	adrp	x11, lJTI13_4@PAGE
Lloh11:
	add	x11, x11, lJTI13_4@PAGEOFF
	adr	x9, LBB13_88
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_88:                               ; %liza___liza_reactor_error.exit.i.i185
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w23, wzr
	mov	w21, #1                         ; =0x1
LBB13_89:                               ; %liza_net.reactor_ready.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x19, x25
	cmp	w21, #1
	mov	w8, #3                          ; =0x3
	csel	w8, wzr, w8, ne
	mov	x0, x28
	mov	x1, x20
	mov	x2, x24
	mov	x3, x19
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	mov	x25, x24
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	cbz	x8, LBB13_93
; %bb.90:                               ; %v8_ok.i.i207
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_92
; %bb.91:                               ; %v8_ok.i.i207
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh12:
	adrp	x11, lJTI13_5@PAGE
Lloh13:
	add	x11, x11, lJTI13_5@PAGEOFF
	adr	x9, LBB13_92
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_92:                               ; %liza___liza_reactor_error.exit.i.i211
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB13_93:                               ; %liza_net.reactor_ready.exit228
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x24, x20
	cmp	w8, #1
	b.ne	LBB13_97
LBB13_94:                               ;   in Loop: Header=BB13_80 Depth=2
	mov	w22, #3                         ; =0x3
LBB13_95:                               ; %b259
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x2, x26
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB13_99
; %bb.96:                               ; %b1.i.i891
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w27, wzr
	b	LBB13_102
LBB13_97:                               ; %b78
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #1
	ldr	w9, [sp, #1440]                 ; 4-byte Folded Reload
	str	x0, [sp, #1392]                 ; 8-byte Folded Spill
	cset	w8, eq
	str	w22, [sp, #1432]                ; 4-byte Folded Spill
	orr	w8, w8, w9
	tbz	w8, #0, LBB13_110
; %bb.98:                               ; %b91
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	cmp	w21, #1
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	b.eq	LBB13_94
	b	LBB13_129
LBB13_99:                               ; %v8_ok.i.i873
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_101
; %bb.100:                              ; %v8_ok.i.i873
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh14:
	adrp	x11, lJTI13_13@PAGE
Lloh15:
	add	x11, x11, lJTI13_13@PAGEOFF
	adr	x9, LBB13_101
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_101:                              ; %liza___liza_reactor_error.exit.i.i877
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w27, #1                         ; =0x1
LBB13_102:                              ; %liza_net.reactor_disconnect.exit894
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbz	x8, LBB13_106
; %bb.103:                              ; %v8_ok.i.i900
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_105
; %bb.104:                              ; %v8_ok.i.i900
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh16:
	adrp	x11, lJTI13_14@PAGE
Lloh17:
	add	x11, x11, lJTI13_14@PAGEOFF
	adr	x9, LBB13_105
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_105:                              ; %liza___liza_reactor_error.exit.i.i904
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
LBB13_106:                              ; %liza_net.reactor_disconnect.exit921
                                        ;   in Loop: Header=BB13_80 Depth=2
	orr	w8, w8, w27
	ldr	w9, [sp, #412]                  ; 4-byte Folded Reload
	mov	x23, xzr
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	mov	x28, xzr
	csel	w8, w22, w8, eq
	tst	w9, #0x1
	ldr	w9, [sp, #732]                  ; 4-byte Folded Reload
	mov	x20, xzr
	mov	x24, xzr
	mov	x25, xzr
	csel	w9, w8, w9, ne
	ldr	w8, [sp, #408]                  ; 4-byte Folded Reload
	mov	x19, xzr
	mov	w26, wzr
	mov	w27, #1                         ; =0x1
	mov	w22, #1                         ; =0x1
	str	wzr, [sp, #1492]                ; 4-byte Folded Spill
	str	wzr, [sp, #1480]                ; 4-byte Folded Spill
	str	wzr, [sp, #1456]                ; 4-byte Folded Spill
	str	wzr, [sp, #1472]                ; 4-byte Folded Spill
	str	wzr, [sp, #1448]                ; 4-byte Folded Spill
	str	xzr, [sp, #1464]                ; 8-byte Folded Spill
	str	wzr, [sp, #1432]                ; 4-byte Folded Spill
	str	w9, [sp, #732]                  ; 4-byte Folded Spill
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
LBB13_107:                              ; %v554_ok
                                        ;   in Loop: Header=BB13_80 Depth=2
	add	x0, sp, #1600
	add	x1, sp, #2416
	mov	w2, #768                        ; =0x300
	add	x21, sp, #1600
	bl	_memcpy
	ldr	x8, [sp, #1496]                 ; 8-byte Folded Reload
	and	w9, w26, #0x1
	ldr	w10, [sp, #1492]                ; 4-byte Folded Reload
	ldr	x12, [sp, #584]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #592]                  ; 8-byte Folded Reload
	add	x26, sp, #1600
	add	x8, x21, x8
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #688]                  ; 8-byte Folded Reload
	str	w27, [x8]
	ldr	x2, [sp, #680]                  ; 8-byte Folded Reload
	add	x7, sp, #2416
	stp	x23, x28, [x8, #8]
	ldr	x17, [sp, #672]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #664]                  ; 8-byte Folded Reload
	str	x20, [x8, #24]
	ldr	x16, [sp, #656]                 ; 8-byte Folded Reload
	ldr	x5, [sp, #752]                  ; 8-byte Folded Reload
	strb	w9, [x8, #64]
	add	x9, sp, #1353
	ldr	x6, [sp, #648]                  ; 8-byte Folded Reload
	ldur	q17, [x9, #255]
	ldr	x9, [sp, #1624]
	str	w22, [x8, #32]
	stp	x24, x25, [x8, #40]
	ldr	d14, [sp, #1632]
	ldr	x25, [sp, #528]                 ; 8-byte Folded Reload
	str	x9, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #1480]                 ; 4-byte Folded Reload
	ldr	x24, [sp, #520]                 ; 8-byte Folded Reload
	str	x19, [x8, #56]
	ldr	x21, [sp, #640]                 ; 8-byte Folded Reload
	ldr	x20, [sp, #632]                 ; 8-byte Folded Reload
	stp	w10, w9, [x8, #68]
	add	x10, sp, #1600
	ldr	w9, [sp, #1456]                 ; 4-byte Folded Reload
	ldr	x11, [sp, #1656]
	ldur	q30, [x10, #40]
	ldur	d31, [x10, #68]
	and	w9, w9, #0x1
	ldr	x23, [sp, #624]                 ; 8-byte Folded Reload
	ldr	x22, [sp, #712]                 ; 8-byte Folded Reload
	strb	w9, [x8, #76]
	ldr	w9, [sp, #1472]                 ; 4-byte Folded Reload
	ldr	x14, [sp, #616]                 ; 8-byte Folded Reload
	str	x11, [sp, #1224]                ; 8-byte Folded Spill
	ldrb	w11, [sp, #1664]
	ldr	x15, [sp, #608]                 ; 8-byte Folded Reload
	and	w9, w9, #0x1
	ldr	x19, [sp, #600]                 ; 8-byte Folded Reload
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	strb	w9, [x8, #77]
	ldrb	w9, [sp, #1676]
	str	w11, [sp, #1220]                ; 4-byte Folded Spill
	ldr	w11, [sp, #1448]                ; 4-byte Folded Reload
	str	w9, [sp, #1208]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1677]
	str	w9, [sp, #1200]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	stp	w11, w9, [x8, #80]
	ldr	w9, [sp, #1432]                 ; 4-byte Folded Reload
	ldrh	w11, [sp, #1678]
	ldr	d8, [sp, #1680]
	and	w9, w9, #0x1
	str	w11, [sp, #1192]                ; 4-byte Folded Spill
	strb	w9, [x8, #88]
	ldr	w9, [sp, #1464]                 ; 4-byte Folded Reload
	ldrb	w11, [sp, #1688]
	and	w9, w9, #0x1
	strb	w9, [x8, #89]
	ldrb	w9, [sp, #1868]
	ldr	d0, [sp, #1776]
	ldur	q10, [x10, #104]
	ldur	q12, [x10, #136]
	ldur	d13, [x10, #164]
	ldrb	w8, [sp, #1689]
	str	w9, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1869]
	ldr	d9, [sp, #1696]
	str	d0, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #1792]
	ldr	d11, [sp, #1728]
	str	w9, [sp, #1112]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1870]
	ldr	d21, [sp, #2064]
	str	d0, [sp, #1344]                 ; 8-byte Folded Spill
	ldur	q0, [x10, #200]
	ldr	d22, [sp, #2080]
	str	w9, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1880]
	ldr	d24, [sp, #2112]
	str	q0, [sp, #1328]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #1824]
	ldr	d27, [sp, #2160]
	str	w9, [sp, #1088]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1881]
	ldr	d28, [sp, #2176]
	str	d0, [sp, #1320]                 ; 8-byte Folded Spill
	ldur	q0, [x10, #232]
	ldr	d15, [sp, #2208]
	str	w9, [sp, #1096]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1912]
	ldr	d2, [sp, #2256]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #1720]
	ldr	d3, [sp, #2272]
	str	x9, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #1944]
	ldr	d5, [sp, #2304]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1752]
	ldr	d16, [sp, #2352]
	str	x9, [sp, #1056]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1952]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1760]
	str	w9, [sp, #1064]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1964]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1772]
	str	w9, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1965]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1773]
	str	w9, [sp, #1416]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1966]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #1774]
	str	w9, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1968]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1784]
	str	w9, [sp, #1468]                 ; 4-byte Folded Spill
	ldp	x9, x10, [sp, #440]             ; 16-byte Folded Reload
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1785]
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	ldr	q29, [x9]
	ldr	w9, [sp, #1972]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #1816]
	str	w11, [sp, #1188]                ; 4-byte Folded Spill
	ldr	q25, [x10]
	str	w9, [sp, #1464]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1976]
	ldr	x11, [sp, #576]                 ; 8-byte Folded Reload
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1848]
	ldr	x10, [sp, #568]                 ; 8-byte Folded Reload
	str	w9, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1977]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1856]
	str	w9, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1984]
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #456]                  ; 8-byte Folded Reload
	str	w9, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1988]
	ldr	d0, [x8]
	ldur	q18, [x8, #68]
	ldr	d19, [x8, #96]
	str	w9, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1992]
	ldr	d20, [x8, #192]
	str	d0, [sp, #1288]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #1872]
	ldur	q23, [x8, #228]
	str	x9, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2000]
	ldr	d26, [x8, #288]
	str	d0, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #1888]
	ldr	d1, [x8, #384]
	str	x9, [sp, #1448]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2008]
	ldr	d7, [x8, #480]
	str	d0, [sp, #1272]                 ; 8-byte Folded Spill
	ldur	q0, [x8, #36]
	str	x9, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #2016]
	str	q0, [sp, #1248]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #1920]
	str	w9, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2020]
	str	d0, [sp, #1240]                 ; 8-byte Folded Spill
	str	w9, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #2024]
	str	x9, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2032]
	str	x9, [sp, #1472]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2040]
	str	x9, [sp, #1480]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #2048]
	str	w9, [sp, #1016]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2060]
	str	w9, [sp, #1040]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2061]
	str	w9, [sp, #1036]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #2062]
	str	w9, [sp, #1032]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2072]
	str	w9, [sp, #1028]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2073]
	str	w9, [sp, #1044]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #2104]
	str	x9, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2136]
	str	x9, [sp, #960]                  ; 8-byte Folded Spill
	ldrb	w9, [sp, #2144]
	str	w9, [sp, #968]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2156]
	str	w9, [sp, #1000]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2157]
	str	w9, [sp, #996]                  ; 4-byte Folded Spill
	ldrh	w9, [sp, #2158]
	str	w9, [sp, #984]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2168]
	str	w9, [sp, #976]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2169]
	str	w9, [sp, #1004]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #2200]
	str	x9, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #464]                  ; 8-byte Folded Reload
	str	x9, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #2232]
	str	x9, [sp, #840]                  ; 8-byte Folded Spill
	ldrb	w9, [sp, #2240]
	str	w9, [sp, #848]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2252]
	str	w9, [sp, #872]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2253]
	str	w9, [sp, #880]                  ; 4-byte Folded Spill
	ldrh	w9, [sp, #2254]
	str	w9, [sp, #904]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2264]
	str	w9, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2265]
	str	w9, [sp, #888]                  ; 4-byte Folded Spill
	ldr	x9, [sp, #2296]
	str	x9, [sp, #952]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #560]                  ; 8-byte Folded Reload
	str	x9, [sp, #792]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #552]                  ; 8-byte Folded Reload
	str	x9, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #544]                  ; 8-byte Folded Reload
	str	x9, [sp, #816]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	str	x9, [sp, #824]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #2328]
	str	x9, [sp, #896]                  ; 8-byte Folded Spill
	ldrb	w9, [sp, #2336]
	str	w9, [sp, #912]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2348]
	str	w9, [sp, #936]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2349]
	str	w9, [sp, #920]                  ; 4-byte Folded Spill
	ldrh	w9, [sp, #2350]
	str	w9, [sp, #928]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2360]
	str	w9, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2361]
	str	w9, [sp, #944]                  ; 4-byte Folded Spill
	ldp	x9, x28, [sp, #504]             ; 16-byte Folded Reload
	str	x9, [sp, #784]                  ; 8-byte Folded Spill
	ldp	x13, x9, [sp, #488]             ; 16-byte Folded Reload
	str	x9, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #432]                  ; 8-byte Folded Reload
	ldr	q0, [x9]
	ldr	x9, [sp, #424]                  ; 8-byte Folded Reload
	ldr	q4, [x9]
	ldr	x9, [sp, #416]                  ; 8-byte Folded Reload
	ldr	q6, [x9]
	ldp	x27, x9, [sp, #472]             ; 16-byte Folded Reload
LBB13_108:                              ; %b274_to_b59
                                        ;   in Loop: Header=BB13_80 Depth=2
	stur	q17, [x7, #8]
	ldr	d17, [x26]
	ldrh	w26, [x12]
	ldrb	w12, [x12, #2]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	stur	q30, [x7, #40]
	strh	w26, [sp, #1596]
	ldr	w26, [x11]
	ldrh	w11, [x11, #4]
	strb	w12, [sp, #1598]
	ldrh	w12, [x10]
	ldrb	w10, [x10, #2]
	strh	w11, [sp, #1592]
	ldrh	w11, [x8, #4]
	strb	w10, [sp, #1586]
	ldr	w10, [x8]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	strh	w11, [sp, #1580]
	ldrb	w11, [x8, #2]
	str	w10, [sp, #1576]
	ldrh	w10, [x8]
	ldr	x8, [sp, #816]                  ; 8-byte Folded Reload
	str	w26, [sp, #1588]
	ldr	x26, [sp, #1368]                ; 8-byte Folded Reload
	strb	w11, [sp, #1574]
	cmp	x26, #6
	ldrh	w11, [x8, #4]
	strh	w10, [sp, #1572]
	ldr	w10, [x8]
	ldr	x8, [sp, #824]                  ; 8-byte Folded Reload
	strh	w12, [sp, #1584]
	strh	w11, [sp, #1568]
	ldr	x12, [sp, #736]                 ; 8-byte Folded Reload
	ldrb	w11, [x8, #2]
	str	w10, [sp, #1564]
	ldrh	w10, [x8]
	ldr	x8, [sp, #784]                  ; 8-byte Folded Reload
	str	d17, [sp, #2416]
	ldr	d17, [sp, #1352]                ; 8-byte Folded Reload
	strb	w11, [sp, #1562]
	ldrh	w11, [x25, #4]
	strh	w10, [sp, #1560]
	ldr	w10, [x25]
	ldr	x25, [sp, #1440]                ; 8-byte Folded Reload
	strh	w11, [sp, #1556]
	ldrb	w11, [x24, #2]
	str	w10, [sp, #1552]
	ldrh	w10, [x24]
	ldr	x24, [sp, #1448]                ; 8-byte Folded Reload
	strb	w11, [sp, #1550]
	ldrh	w11, [x28, #4]
	strh	w10, [sp, #1548]
	ldr	w10, [x28]
	ldr	x28, [sp, #1480]                ; 8-byte Folded Reload
	strh	w11, [sp, #1544]
	ldrb	w11, [x8, #2]
	str	w10, [sp, #1540]
	ldrh	w10, [x8]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	strb	w11, [sp, #1538]
	ldrh	w11, [x8, #4]
	strh	w10, [sp, #1536]
	ldr	w10, [x8]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	str	d17, [sp, #2592]
	ldr	d17, [sp, #1344]                ; 8-byte Folded Reload
	strh	w11, [sp, #1532]
	ldrb	w11, [x13, #2]
	str	w10, [sp, #1528]
	ldrh	w10, [x13]
	ldr	x13, [sp, #1456]                ; 8-byte Folded Reload
	strb	w11, [sp, #1526]
	ldrh	w11, [x9, #4]
	strh	w10, [sp, #1524]
	ldr	w10, [x9]
	ldr	w9, [x8]
	strh	w11, [sp, #1520]
	ldrb	w11, [x27, #2]
	str	w9, [sp, #1504]
	ldrh	w9, [sp, #1548]
	strb	w11, [sp, #1514]
	ldrh	w11, [x8, #4]
	ldr	x8, [sp, #1232]                 ; 8-byte Folded Reload
	strh	w9, [sp, #2412]
	ldr	w9, [sp, #1540]
	str	x8, [sp, #2440]
	ldr	x8, [sp, #1224]                 ; 8-byte Folded Reload
	str	w9, [sp, #2404]
	ldrh	w9, [sp, #1536]
	str	x8, [sp, #2472]
	ldr	w8, [sp, #1220]                 ; 4-byte Folded Reload
	strh	w9, [sp, #2400]
	ldr	w9, [sp, #1528]
	strb	w8, [sp, #2480]
	ldr	w8, [sp, #1208]                 ; 4-byte Folded Reload
	str	w9, [sp, #2392]
	ldrh	w9, [sp, #1524]
	strb	w8, [sp, #2492]
	ldr	w8, [sp, #1200]                 ; 4-byte Folded Reload
	str	w10, [sp, #1516]
	ldrh	w10, [x27]
	ldr	x27, [sp, #1472]                ; 8-byte Folded Reload
	strb	w8, [sp, #2493]
	ldr	w8, [sp, #1192]                 ; 4-byte Folded Reload
	strh	w9, [sp, #2388]
	ldr	w9, [sp, #1516]
	strh	w8, [sp, #2494]
	ldr	w8, [sp, #1188]                 ; 4-byte Folded Reload
	strh	w10, [sp, #1512]
	ldrb	w10, [sp, #1550]
	strb	w8, [sp, #2504]
	ldr	w8, [sp, #1184]                 ; 4-byte Folded Reload
	str	w9, [sp, #2380]
	ldrh	w9, [sp, #1512]
	strb	w8, [sp, #2505]
	ldr	x8, [sp, #1176]                 ; 8-byte Folded Reload
	strh	w9, [sp, #2376]
	ldr	w9, [sp, #1504]
	str	x8, [sp, #2536]
	ldr	x8, [sp, #1168]                 ; 8-byte Folded Reload
	str	w9, [sp, #2368]
	ldrb	w9, [sp, #1598]
	str	x8, [sp, #2568]
	ldr	w8, [sp, #1164]                 ; 4-byte Folded Reload
	strb	w9, [x0, #2]
	ldrh	w9, [sp, #1592]
	strb	w8, [sp, #2576]
	ldr	w8, [sp, #1160]                 ; 4-byte Folded Reload
	strh	w9, [x1, #4]
	ldrb	w9, [sp, #1586]
	strb	w8, [sp, #2588]
	ldr	w8, [sp, #1156]                 ; 4-byte Folded Reload
	strb	w9, [x2, #2]
	ldrh	w9, [sp, #1580]
	strb	w8, [sp, #2589]
	ldr	w8, [sp, #1152]                 ; 4-byte Folded Reload
	strb	w10, [sp, #2414]
	ldrh	w10, [sp, #1544]
	strh	w8, [sp, #2590]
	ldr	w8, [sp, #1148]                 ; 4-byte Folded Reload
	strh	w9, [x17, #4]
	ldrb	w9, [sp, #1574]
	strb	w8, [sp, #2600]
	ldr	w8, [sp, #1144]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2408]
	ldrb	w10, [sp, #1538]
	strb	w8, [sp, #2601]
	ldr	x8, [sp, #1136]                 ; 8-byte Folded Reload
	strb	w9, [x3, #2]
	ldrh	w9, [sp, #1568]
	str	x8, [sp, #2632]
	ldr	x8, [sp, #1120]                 ; 8-byte Folded Reload
	strb	w10, [sp, #2402]
	ldrh	w10, [sp, #1532]
	str	x8, [sp, #2664]
	ldr	w8, [sp, #1132]                 ; 4-byte Folded Reload
	strh	w9, [x16, #4]
	ldrb	w9, [sp, #1562]
	strb	w8, [sp, #2672]
	ldr	w8, [sp, #1116]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2396]
	ldrb	w10, [sp, #1526]
	strb	w8, [sp, #2684]
	ldr	w8, [sp, #1112]                 ; 4-byte Folded Reload
	strb	w9, [x5, #2]
	ldrh	w9, [sp, #1556]
	strb	w8, [sp, #2685]
	ldr	w8, [sp, #1104]                 ; 4-byte Folded Reload
	strb	w10, [sp, #2390]
	ldrh	w10, [sp, #1520]
	strh	w8, [sp, #2686]
	ldr	w8, [sp, #1088]                 ; 4-byte Folded Reload
	strh	w9, [x6, #4]
	ldrb	w9, [sp, #2414]
	strb	w8, [sp, #2696]
	ldr	w8, [sp, #1096]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2384]
	ldrb	w10, [sp, #1514]
	strb	w8, [sp, #2697]
	ldr	x8, [sp, #1080]                 ; 8-byte Folded Reload
	strh	w11, [sp, #1508]
	ldr	x11, [sp, #744]                 ; 8-byte Folded Reload
	str	x8, [sp, #2728]
	ldr	x8, [sp, #1056]                 ; 8-byte Folded Reload
	strb	w9, [x21, #2]
	ldrh	w9, [sp, #2408]
	str	x8, [sp, #2760]
	ldr	w8, [sp, #1064]                 ; 4-byte Folded Reload
	strb	w10, [sp, #2378]
	ldrh	w10, [sp, #1508]
	strb	w8, [sp, #2768]
	ldr	w8, [sp, #1076]                 ; 4-byte Folded Reload
	strh	w9, [x20, #4]
	ldrb	w9, [sp, #2402]
	strh	w8, [sp, #2782]
	ldr	w8, [sp, #1016]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2372]
	ldrh	w10, [sp, #1596]
	strb	w8, [sp, #2864]
	ldr	w8, [sp, #1040]                 ; 4-byte Folded Reload
	strb	w9, [x23, #2]
	ldrh	w9, [sp, #2396]
	strb	w8, [sp, #2876]
	ldr	w8, [sp, #1036]                 ; 4-byte Folded Reload
	strh	w10, [x0]
	ldr	w10, [sp, #1588]
	strb	w8, [sp, #2877]
	ldr	w8, [sp, #1032]                 ; 4-byte Folded Reload
	strh	w9, [x22, #4]
	ldrb	w9, [sp, #2390]
	strh	w8, [sp, #2878]
	ldr	w8, [sp, #1028]                 ; 4-byte Folded Reload
	str	w10, [x1]
	ldrh	w10, [sp, #1584]
	strb	w8, [sp, #2888]
	ldr	w8, [sp, #1044]                 ; 4-byte Folded Reload
	strb	w9, [x14, #2]
	ldrh	w9, [sp, #2384]
	strb	w8, [sp, #2889]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	strh	w10, [x2]
	ldr	w10, [sp, #1576]
	str	x8, [sp, #2920]
	ldr	x8, [sp, #960]                  ; 8-byte Folded Reload
	strh	w9, [x15, #4]
	ldrb	w9, [sp, #2378]
	str	x8, [sp, #2952]
	ldr	w8, [sp, #968]                  ; 4-byte Folded Reload
	str	w10, [x17]
	ldrh	w10, [sp, #1572]
	strb	w8, [sp, #2960]
	ldr	w8, [sp, #1000]                 ; 4-byte Folded Reload
	strb	w9, [x19, #2]
	ldr	w9, [sp, #944]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2972]
	ldr	w8, [sp, #996]                  ; 4-byte Folded Reload
	strh	w10, [x3]
	ldr	w10, [sp, #1564]
	strb	w8, [sp, #2973]
	ldr	w8, [sp, #984]                  ; 4-byte Folded Reload
	strb	w9, [sp, #3177]
	ldr	w9, [sp, #2368]
	strh	w8, [sp, #2974]
	ldr	w8, [sp, #976]                  ; 4-byte Folded Reload
	str	w10, [x16]
	ldrh	w10, [sp, #1560]
	strb	w8, [sp, #2984]
	ldr	w8, [sp, #1004]                 ; 4-byte Folded Reload
	str	w9, [x30]
	ldr	w9, [sp, #1404]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2985]
	ldr	x8, [sp, #1008]                 ; 8-byte Folded Reload
	strh	w10, [x5]
	ldr	w10, [sp, #1552]
	ldr	x5, [sp, #1432]                 ; 8-byte Folded Reload
	str	x8, [sp, #3016]
	ldr	x8, [sp, #840]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2792]
	ldr	w9, [sp, #1408]                 ; 4-byte Folded Reload
	str	x8, [sp, #3048]
	ldr	w8, [sp, #848]                  ; 4-byte Folded Reload
	str	w10, [x6]
	ldrh	w10, [sp, #2412]
	strb	w8, [sp, #3056]
	ldr	w8, [sp, #872]                  ; 4-byte Folded Reload
	str	d17, [sp, #2608]
	ldr	q17, [sp, #1328]                ; 16-byte Folded Reload
	strb	w8, [sp, #3068]
	ldr	w8, [sp, #880]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2793]
	ldr	w9, [sp, #1492]                 ; 4-byte Folded Reload
	strb	w8, [sp, #3069]
	ldr	w8, [sp, #904]                  ; 4-byte Folded Reload
	strh	w10, [x21]
	ldr	w10, [sp, #2404]
	strh	w8, [sp, #3070]
	ldr	w8, [sp, #856]                  ; 4-byte Folded Reload
	stur	q17, [x7, #200]
	ldr	d17, [sp, #1320]                ; 8-byte Folded Reload
	strb	w8, [sp, #3080]
	ldr	w8, [sp, #888]                  ; 4-byte Folded Reload
	str	w9, [sp, #2800]
	ldr	w9, [sp, #1388]                 ; 4-byte Folded Reload
	strb	w8, [sp, #3081]
	ldr	x8, [sp, #952]                  ; 8-byte Folded Reload
	str	w10, [x20]
	ldrh	w10, [sp, #2400]
	str	x8, [sp, #3112]
	ldr	x8, [sp, #896]                  ; 8-byte Folded Reload
	str	d17, [sp, #2640]
	ldr	q17, [sp, #1296]                ; 16-byte Folded Reload
	str	x8, [sp, #3144]
	ldr	w8, [sp, #912]                  ; 4-byte Folded Reload
	str	w9, [sp, #2804]
	ldr	w9, [sp, #1392]                 ; 4-byte Folded Reload
	strb	w8, [sp, #3152]
	ldr	w8, [sp, #936]                  ; 4-byte Folded Reload
	strh	w10, [x23]
	ldr	w10, [sp, #2392]
	strb	w8, [sp, #3164]
	ldr	w8, [sp, #920]                  ; 4-byte Folded Reload
	stur	q17, [x7, #232]
	ldr	d17, [sp, #1288]                ; 8-byte Folded Reload
	strb	w8, [sp, #3165]
	ldr	w8, [sp, #928]                  ; 4-byte Folded Reload
	str	w9, [sp, #2832]
	ldr	w9, [sp, #1384]                 ; 4-byte Folded Reload
	strh	w8, [sp, #3166]
	ldr	w8, [sp, #864]                  ; 4-byte Folded Reload
	str	w10, [x22]
	ldrh	w10, [sp, #2388]
	strb	w8, [sp, #3176]
	ldrh	w8, [sp, #2372]
	str	d17, [x4]
	ldr	d17, [sp, #1280]                ; 8-byte Folded Reload
	str	w9, [sp, #2836]
	ldr	x9, [sp, #776]                  ; 8-byte Folded Reload
	strh	w10, [x14]
	ldr	w10, [sp, #2380]
	strh	w8, [x30, #4]
	ldr	w8, [sp, #1428]                 ; 4-byte Folded Reload
	str	d17, [sp, #2688]
	ldr	d17, [sp, #1272]                ; 8-byte Folded Reload
	str	q0, [x9]
	ldr	x9, [sp, #768]                  ; 8-byte Folded Reload
	str	w10, [x15]
	ldrh	w10, [sp, #2376]
	str	d17, [sp, #2704]
	ldr	q17, [sp, #1248]                ; 16-byte Folded Reload
	strb	w8, [sp, #2780]
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	str	q4, [x9]
	ldr	x9, [sp, #760]                  ; 8-byte Folded Reload
	strh	w10, [x19]
	ldr	w10, [sp, #1464]                ; 4-byte Folded Reload
	stur	q17, [x4, #36]
	ldr	d17, [sp, #1240]                ; 8-byte Folded Reload
	strb	w8, [sp, #2781]
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	stur	d31, [x7, #68]
	stur	q10, [x7, #104]
	stur	q12, [x7, #136]
	stur	d13, [x7, #164]
	mov	x7, x19
	mov	x19, x13
	str	x13, [sp, #2808]
	mov	x13, x5
	str	q6, [x9]
	add	x9, sp, #2416
	str	d14, [sp, #2448]
	str	d8, [sp, #2496]
	str	d9, [sp, #2512]
	str	d11, [sp, #2544]
	str	d17, [sp, #2736]
	stur	q18, [x4, #68]
	str	d19, [x4, #96]
	str	w8, [sp, #2784]
	str	w10, [sp, #2788]
	str	x24, [sp, #2816]
	str	x25, [sp, #2824]
	str	x5, [sp, #2840]
	str	x27, [sp, #2848]
	str	x28, [sp, #2856]
	str	d20, [x4, #192]
	str	d21, [sp, #2880]
	str	d22, [sp, #2896]
	stur	q23, [x4, #228]
	str	d24, [sp, #2928]
	str	q25, [x11]
	str	d26, [x4, #288]
	str	d27, [sp, #2976]
	str	d28, [sp, #2992]
	str	q29, [x12]
	str	d15, [sp, #3024]
	str	d1, [x4, #384]
	str	d2, [sp, #3072]
	str	d3, [sp, #3088]
	str	d5, [sp, #3120]
	str	d7, [x4, #480]
	str	d16, [sp, #3168]
	b.hi	LBB13_315
; %bb.109:                              ; %b274_to_b59
                                        ;   in Loop: Header=BB13_80 Depth=2
	add	x26, x26, #1
	ldr	w5, [sp, #1364]                 ; 4-byte Folded Reload
	str	x26, [sp, #1368]                ; 8-byte Folded Spill
	ldr	w26, [sp, #1380]                ; 4-byte Folded Reload
	add	w26, w26, #1, lsl #12           ; =4096
	str	w26, [sp, #1380]                ; 4-byte Folded Spill
	ldr	x26, [sp, #1496]                ; 8-byte Folded Reload
	add	x26, x26, #96
	tbnz	w5, #0, LBB13_80
	b	LBB13_25
LBB13_110:                              ; %b82
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	bl	_liza_rt_reactor_finish_connect
	lsr	x8, x0, #32
	cbnz	x8, LBB13_112
; %bb.111:                              ; %b1.i247
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	x0, #1
	mov	w10, wzr
	cset	w9, eq
	b	LBB13_126
LBB13_112:                              ; %v10_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_124
; %bb.113:                              ; %v10_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh18:
	adrp	x12, lJTI13_6@PAGE
Lloh19:
	add	x12, x12, lJTI13_6@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_114
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_114:                              ; %b4.i.i245
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_125
LBB13_115:                              ; %b34.i.i240
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_125
LBB13_116:                              ; %b13.i.i242
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_125
LBB13_117:                              ; %b16.i.i241
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_125
LBB13_118:                              ; %b10.i.i243
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_125
LBB13_119:                              ; %b7.i.i244
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_125
LBB13_120:                              ; %b22.i.i239
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_125
LBB13_121:                              ; %b25.i.i238
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_125
LBB13_122:                              ; %b31.i.i233
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_125
LBB13_123:                              ; %b28.i.i237
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_125
LBB13_124:                              ; %b36.i.i246
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_125:                              ; %liza___liza_reactor_error.exit.i234
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	mov	w10, #1                         ; =0x1
LBB13_126:                              ; %liza_net.reactor_finish_connect.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	cmp	w10, #1
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	b.ne	LBB13_128
; %bb.127:                              ; %b85
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_129
LBB13_128:                              ; %b89
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w8, w9, #0x1
	str	w8, [sp, #1440]                 ; 4-byte Folded Spill
LBB13_129:                              ; %b95
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.hi	LBB13_133
; %bb.130:                              ; %b95
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.hi	LBB13_133
; %bb.131:                              ; %b4.i.i257
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	ldr	w22, [sp, #1456]                ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w16, #0, LBB13_142
; %bb.132:                              ; %b4.i.i257
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w8, w22, w8
	cbnz	w8, LBB13_142
LBB13_133:                              ; %b114
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_172
; %bb.134:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.hi	LBB13_172
; %bb.135:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.hi	LBB13_172
; %bb.136:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbnz	w16, #0, LBB13_172
; %bb.137:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, w1
	b.eq	LBB13_172
; %bb.138:                              ; %v253_ok
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	sub	w8, w8, #2048
	adds	w6, w8, w1
	b.hs	LBB13_320
; %bb.139:                              ; %b3.i325
                                        ;   in Loop: Header=BB13_80 Depth=2
	subs	w23, w15, w1
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	b.lo	LBB13_320
; %bb.140:                              ; %liza_relay.direction.queued.exit330
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	mov	w7, w23
	mov	w21, w16
	mov	w22, w15
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1456]                ; 4-byte Folded Reload
	cbnz	x8, LBB13_148
; %bb.141:                              ; %b1.i.i354
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_170
LBB13_142:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.eq	LBB13_133
; %bb.143:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	eor	w8, w22, #0x1
	tbz	w8, #0, LBB13_133
; %bb.144:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #1
	b.eq	LBB13_133
; %bb.145:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	and	w8, w23, w8
	cbz	w8, LBB13_133
; %bb.146:                              ; %b4.i.i266
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	mov	w9, #2048                       ; =0x800
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	sub	w20, w9, w15
	tst	w22, #0x1
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	add	w8, w15, w8
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	sub	w6, w8, #2048
	csel	w7, wzr, w20, ne
	mov	x0, x28
	mov	x2, x26
	mov	w21, w16
	str	w15, [sp, #1480]                ; 4-byte Folded Spill
	mov	x23, x26
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB13_151
; %bb.147:                              ; %b104
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w22, #3                         ; =0x3
	mov	w16, w21
	mov	x26, x23
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_133
LBB13_148:                              ; %v8_ok.i.i336
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_168
; %bb.149:                              ; %v8_ok.i.i336
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh20:
	adrp	x12, lJTI13_7@PAGE
Lloh21:
	add	x12, x12, lJTI13_7@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_150
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_150:                              ; %b4.i.i.i352
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_169
LBB13_151:                              ; %b1.i295
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w14, [sp, #1464]                ; 4-byte Folded Reload
	mov	w1, wzr
	orr	w8, w21, w22
	mov	w9, #1                          ; =0x1
	tbnz	w8, #0, LBB13_155
; %bb.152:                              ; %b1.i295
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1432]                ; 4-byte Folded Reload
	cmp	w20, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	x26, x23
	b.lo	LBB13_156
; %bb.153:                              ; %b12.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	cbz	w0, LBB13_158
; %bb.154:                              ; %v26_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1480]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w8, w0
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_157
LBB13_155:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1432]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	x26, x23
LBB13_156:                              ; %liza_relay.direction.read.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #1
	b.eq	LBB13_94
LBB13_157:                              ; %b111
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w9, w11, #0x1
	and	w16, w10, #0x1
	and	w12, w12, #0x1
	and	w13, w13, #0x1
	and	w14, w14, #0x1
	mov	w15, w8
	str	w9, [sp, #1456]                 ; 4-byte Folded Spill
	str	w12, [sp, #1440]                ; 4-byte Folded Spill
	str	w13, [sp, #1432]                ; 4-byte Folded Spill
	str	w14, [sp, #1464]                ; 4-byte Folded Spill
	b	LBB13_133
LBB13_158:                              ; %b13.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w8, [sp, #1480]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_157
LBB13_159:                              ; %b34.i.i.i347
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_169
LBB13_160:                              ; %b13.i.i.i349
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_169
LBB13_161:                              ; %b16.i.i.i348
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_169
LBB13_162:                              ; %b10.i.i.i350
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_169
LBB13_163:                              ; %b7.i.i.i351
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_169
LBB13_164:                              ; %b22.i.i.i346
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_169
LBB13_165:                              ; %b25.i.i.i345
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_169
LBB13_166:                              ; %b31.i.i.i339
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_169
LBB13_167:                              ; %b28.i.i.i344
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_169
LBB13_168:                              ; %b36.i.i.i353
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_169:                              ; %liza___liza_reactor_error.exit.i.i340
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB13_170:                              ; %liza_net.reactor_write.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w15, w22
	mov	w16, w21
	cmp	w9, #1
	b.ne	LBB13_180
; %bb.171:                              ; %b124
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
LBB13_172:                              ; %b134
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_205
LBB13_173:                              ; %b138
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.hi	LBB13_205
; %bb.174:                              ; %b138
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.hi	LBB13_205
; %bb.175:                              ; %b4.i.i385
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbnz	w16, #0, LBB13_205
; %bb.176:                              ; %b4.i.i385
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1456]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_205
; %bb.177:                              ; %b4.i.i385
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.ne	LBB13_205
; %bb.178:                              ; %b141
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, w1
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	mov	w23, w16
	mov	w22, w15
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB13_183
; %bb.179:                              ; %b1.i.i414
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_203
LBB13_180:                              ; %b4.i.i368
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1432]                ; 4-byte Folded Reload
	cbz	w0, LBB13_182
; %bb.181:                              ; %b3.i.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w0, w23
	b.ls	LBB13_186
LBB13_182:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w1, wzr
	mov	w15, wzr
	mov	w14, wzr
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_191
LBB13_183:                              ; %v8_ok.i.i396
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_201
; %bb.184:                              ; %v8_ok.i.i396
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh22:
	adrp	x12, lJTI13_8@PAGE
Lloh23:
	add	x12, x12, lJTI13_8@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_185
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_185:                              ; %b4.i.i.i412
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_202
LBB13_186:                              ; %b9.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	adds	w1, w1, w0
	b.hs	LBB13_320
; %bb.187:                              ; %v13_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.ne	LBB13_189
; %bb.188:                              ; %b10.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	mov	w1, wzr
	mov	w15, wzr
	b	LBB13_190
LBB13_189:                              ; %b12.i374
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
LBB13_190:                              ; %liza_relay.direction.write.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB13_94
LBB13_191:                              ; %b131
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w16, w8, #0x1
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	and	w14, w14, #0x1
	and	w13, w13, #0x1
	and	w10, w10, #0x1
	str	w14, [sp, #1456]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w13, [sp, #1440]                ; 4-byte Folded Spill
	str	w10, [sp, #1432]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_173
	b	LBB13_205
LBB13_192:                              ; %b34.i.i.i407
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_202
LBB13_193:                              ; %b13.i.i.i409
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_202
LBB13_194:                              ; %b16.i.i.i408
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_202
LBB13_195:                              ; %b10.i.i.i410
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_202
LBB13_196:                              ; %b7.i.i.i411
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_202
LBB13_197:                              ; %b22.i.i.i406
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_202
LBB13_198:                              ; %b25.i.i.i405
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_202
LBB13_199:                              ; %b31.i.i.i399
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_202
LBB13_200:                              ; %b28.i.i.i404
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_202
LBB13_201:                              ; %b36.i.i.i413
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_202:                              ; %liza___liza_reactor_error.exit.i.i400
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
LBB13_203:                              ; %liza_net.reactor_shutdown_write.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1432]                ; 4-byte Folded Reload
	mov	w1, w20
	mov	w15, w22
	mov	w16, w23
	cmp	w9, #1
	b.ne	LBB13_215
; %bb.204:                              ; %b144
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
LBB13_205:                              ; %b154
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_216
LBB13_206:                              ; %b158
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1448]                 ; 4-byte Folded Reload
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	cmp	w8, w9
	b.hi	LBB13_216
; %bb.207:                              ; %b158
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #2048
	b.hi	LBB13_216
; %bb.208:                              ; %b4.i.i435
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w8, w9
	ldr	w22, [sp, #1432]                ; 4-byte Folded Reload
	ldr	w10, [sp, #1464]                ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w10, #0, LBB13_210
; %bb.209:                              ; %b4.i.i435
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w8, w22, w8
	cbz	w8, LBB13_216
LBB13_210:                              ; %liza_relay.direction.readable.exit445
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #2048
	b.eq	LBB13_216
; %bb.211:                              ; %liza_relay.direction.readable.exit445
                                        ;   in Loop: Header=BB13_80 Depth=2
	eor	w8, w22, #0x1
	tbz	w8, #0, LBB13_216
; %bb.212:                              ; %liza_relay.direction.readable.exit445
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x9, [sp, #1392]                 ; 8-byte Folded Reload
	mov	w8, #5                          ; =0x5
	and	w8, w9, w8
	cbz	w8, LBB13_216
; %bb.213:                              ; %b4.i.i452
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	mov	w8, #2048                       ; =0x800
	tst	w22, #0x1
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	sub	w20, w8, w9
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	mov	x0, x28
	csel	w7, wzr, w20, ne
	mov	x1, x24
	mov	x2, x25
	add	w6, w9, w8
	mov	x3, x19
	str	w16, [sp, #1472]                ; 4-byte Folded Spill
	mov	w21, w15
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB13_228
; %bb.214:                              ; %b167
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w22, #3                         ; =0x3
	mov	w15, w21
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_216
LBB13_215:                              ; %b151
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	and	w10, w10, #0x1
	and	w11, w11, #0x1
	mov	w15, w1
	mov	w16, #1                         ; =0x1
	str	w10, [sp, #1440]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w11, [sp, #1432]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1456]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_206
LBB13_216:                              ; %b177
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_254
LBB13_217:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w20, [sp, #1448]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	str	x26, [sp, #1392]                ; 8-byte Folded Spill
	cmp	w20, w8
	b.hi	LBB13_253
; %bb.218:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w8, #2048
	b.hi	LBB13_253
; %bb.219:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w9, [sp, #1464]                 ; 4-byte Folded Reload
	tbnz	w9, #0, LBB13_253
; %bb.220:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w8, w20
	b.eq	LBB13_253
; %bb.221:                              ; %v393_ok
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	adds	w6, w8, w20
	b.hs	LBB13_320
; %bb.222:                              ; %b3.i550
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	subs	w23, w8, w20
	b.lo	LBB13_320
; %bb.223:                              ; %liza_relay.direction.queued.exit555
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1392]                 ; 8-byte Folded Reload
	mov	x0, x28
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	mov	w7, w23
	mov	w21, w16
	mov	w22, w15
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1432]                ; 4-byte Folded Reload
	cbnz	x8, LBB13_225
; %bb.224:                              ; %b1.i.i581
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_243
LBB13_225:                              ; %v8_ok.i.i563
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_241
; %bb.226:                              ; %v8_ok.i.i563
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh24:
	adrp	x12, lJTI13_9@PAGE
Lloh25:
	add	x12, x12, lJTI13_9@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_227
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_227:                              ; %b4.i.i.i579
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_242
LBB13_228:                              ; %b1.i496
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	mov	w1, wzr
	mov	w9, #1                          ; =0x1
	orr	w8, w8, w22
	tbnz	w8, #0, LBB13_265
; %bb.229:                              ; %b1.i496
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1456]                ; 4-byte Folded Reload
	cmp	w20, w0
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
	b.lo	LBB13_266
; %bb.230:                              ; %b12.i502
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	cbz	w0, LBB13_268
; %bb.231:                              ; %v26_ok.i504
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1448]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w8, w0
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_267
LBB13_232:                              ; %b34.i.i.i574
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_242
LBB13_233:                              ; %b13.i.i.i576
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_242
LBB13_234:                              ; %b16.i.i.i575
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_242
LBB13_235:                              ; %b10.i.i.i577
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_242
LBB13_236:                              ; %b7.i.i.i578
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_242
LBB13_237:                              ; %b22.i.i.i573
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_242
LBB13_238:                              ; %b25.i.i.i572
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_242
LBB13_239:                              ; %b31.i.i.i566
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_242
LBB13_240:                              ; %b28.i.i.i571
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_242
LBB13_241:                              ; %b36.i.i.i580
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_242:                              ; %liza___liza_reactor_error.exit.i.i567
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB13_243:                              ; %liza_net.reactor_write.exit584
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w15, w22
	mov	w16, w21
	cmp	w9, #1
	b.ne	LBB13_245
; %bb.244:                              ; %b187
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	x26, [sp, #1392]                ; 8-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w22, #3                         ; =0x3
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_254
LBB13_245:                              ; %b4.i.i596
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1456]                ; 4-byte Folded Reload
	cbz	w0, LBB13_247
; %bb.246:                              ; %b3.i.i608
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w0, w23
	b.ls	LBB13_248
LBB13_247:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w20, wzr
	str	wzr, [sp, #1468]                ; 4-byte Folded Spill
	mov	w14, wzr
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB13_252
	b	LBB13_313
LBB13_248:                              ; %b9.i614
                                        ;   in Loop: Header=BB13_80 Depth=2
	adds	w20, w20, w0
	b.hs	LBB13_320
; %bb.249:                              ; %v13_ok.i618
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w9, wzr
	cmp	w20, w8
	b.ne	LBB13_251
; %bb.250:                              ; %b10.i626
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, wzr
	str	wzr, [sp, #1468]                ; 4-byte Folded Spill
LBB13_251:                              ; %liza_relay.direction.write.exit636
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB13_313
LBB13_252:                              ; %b194
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w14, w14, #0x1
	and	w8, w8, #0x1
	and	w13, w13, #0x1
	and	w10, w10, #0x1
	and	w16, w16, #0x1
	str	w20, [sp, #1448]                ; 4-byte Folded Spill
	str	w14, [sp, #1432]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	str	w13, [sp, #1440]                ; 4-byte Folded Spill
	str	w10, [sp, #1456]                ; 4-byte Folded Spill
LBB13_253:                              ; %b197
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x26, [sp, #1392]                ; 8-byte Folded Reload
LBB13_254:                              ; %b197
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_283
; %bb.255:                              ; %b201
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w20, [sp, #1448]                ; 4-byte Folded Reload
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	cmp	w20, w9
	b.hi	LBB13_283
; %bb.256:                              ; %b201
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #2048
	b.hi	LBB13_283
; %bb.257:                              ; %b4.i.i644
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_283
; %bb.258:                              ; %b4.i.i644
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_283
; %bb.259:                              ; %b4.i.i644
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w20, w9
	b.ne	LBB13_283
; %bb.260:                              ; %b204
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w21, w1
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x2, x26
	mov	w22, w16
	str	w15, [sp, #1480]                ; 4-byte Folded Spill
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB13_262
; %bb.261:                              ; %b1.i.i678
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_280
LBB13_262:                              ; %v8_ok.i.i660
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_278
; %bb.263:                              ; %v8_ok.i.i660
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh26:
	adrp	x12, lJTI13_10@PAGE
Lloh27:
	add	x12, x12, lJTI13_10@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_264
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_264:                              ; %b4.i.i.i676
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_279
LBB13_265:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1456]                ; 4-byte Folded Reload
	mov	w8, w1
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
LBB13_266:                              ; %liza_relay.direction.read.exit517
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #1
	b.eq	LBB13_94
LBB13_267:                              ; %b174
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w9, w11, #0x1
	str	w1, [sp, #1448]                 ; 4-byte Folded Spill
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	str	w9, [sp, #1432]                 ; 4-byte Folded Spill
	and	w9, w10, #0x1
	and	w12, w12, #0x1
	and	w13, w13, #0x1
	and	w16, w16, #0x1
	str	w9, [sp, #1464]                 ; 4-byte Folded Spill
	str	w12, [sp, #1440]                ; 4-byte Folded Spill
	str	w13, [sp, #1456]                ; 4-byte Folded Spill
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_217
	b	LBB13_254
LBB13_268:                              ; %b13.i511
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1448]                 ; 4-byte Folded Reload
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_267
LBB13_269:                              ; %b34.i.i.i671
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_279
LBB13_270:                              ; %b13.i.i.i673
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_279
LBB13_271:                              ; %b16.i.i.i672
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_279
LBB13_272:                              ; %b10.i.i.i674
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_279
LBB13_273:                              ; %b7.i.i.i675
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_279
LBB13_274:                              ; %b22.i.i.i670
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_279
LBB13_275:                              ; %b25.i.i.i669
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_279
LBB13_276:                              ; %b31.i.i.i663
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_279
LBB13_277:                              ; %b28.i.i.i668
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_279
LBB13_278:                              ; %b36.i.i.i677
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_279:                              ; %liza___liza_reactor_error.exit.i.i664
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
LBB13_280:                              ; %liza_net.reactor_shutdown_write.exit681
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1456]                ; 4-byte Folded Reload
	mov	w1, w21
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	mov	w16, w22
	cmp	w9, #1
	b.ne	LBB13_282
; %bb.281:                              ; %b207
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_283
LBB13_282:                              ; %b214
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w10, w10, #0x1
	and	w11, w11, #0x1
	and	w16, w16, #0x1
	mov	w8, #1                          ; =0x1
	str	w10, [sp, #1440]                ; 4-byte Folded Spill
	str	w11, [sp, #1456]                ; 4-byte Folded Spill
	str	w8, [sp, #1432]                 ; 4-byte Folded Spill
	str	w20, [sp, #1468]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
LBB13_283:                              ; %b217
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbz	w16, #0, LBB13_285
; %bb.284:                              ; %b217
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w22, [sp, #1404]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_95
LBB13_285:                              ; %b227
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	mov	w8, #2049                       ; =0x801
	ccmp	w15, w8, #2, ls
	cset	w8, lo
	cmp	w8, #1
	b.ne	LBB13_288
; %bb.286:                              ; %b4.i.i713
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	ldr	w10, [sp, #1456]                ; 4-byte Folded Reload
	cset	w9, eq
	tbz	w16, #0, LBB13_289
; %bb.287:                              ; %b4.i.i713
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w9, w10, w9
	cbnz	w9, LBB13_289
LBB13_288:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w4, wzr
	b	LBB13_290
LBB13_289:                              ; %b1.i720
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	eor	w10, w10, #0x1
	cset	w9, ne
	and	w4, w9, w10
LBB13_290:                              ; %liza_relay.direction.readable.exit723
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w13, [sp, #1448]                ; 4-byte Folded Reload
	ldr	w21, [sp, #1468]                ; 4-byte Folded Reload
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w22, [sp, #1432]                ; 4-byte Folded Reload
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	cmp	w13, w21
	str	w15, [sp, #1480]                ; 4-byte Folded Spill
	str	w16, [sp, #1472]                ; 4-byte Folded Spill
	b.hi	LBB13_295
; %bb.291:                              ; %liza_relay.direction.readable.exit723
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #2048
	b.hi	LBB13_295
; %bb.292:                              ; %b4.i.i730
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, w13
	ldr	w9, [sp, #1464]                 ; 4-byte Folded Reload
	orr	w11, w4, #0x2
	cset	w10, ne
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	eor	w9, w9, #0x1
	orr	w10, w10, w22
	and	w10, w9, w10
	tst	w10, #0x1
	csel	w4, w11, w4, ne
	tbz	w12, #0, LBB13_302
; %bb.293:                              ; %b4.i.i767
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, w13
	cset	w10, eq
	and	w10, w22, w10
	orr	w9, w9, w10
	tbz	w9, #0, LBB13_296
; %bb.294:                              ; %b1.i774
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #2048
	eor	w10, w22, #0x1
	cset	w9, ne
	and	w23, w9, w10
	cbnz	w8, LBB13_297
	b	LBB13_303
LBB13_295:                              ; %b237.thread
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	tbz	w12, #0, LBB13_302
LBB13_296:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w23, wzr
	cbz	w8, LBB13_303
LBB13_297:                              ; %b4.i.i784
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, w1
	cset	w8, ne
	bic	w8, w8, w16
	tbnz	w8, #0, LBB13_301
; %bb.298:                              ; %b4.i.i804
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbnz	w16, #0, LBB13_303
; %bb.299:                              ; %b4.i.i804
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1456]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_303
; %bb.300:                              ; %b4.i.i804
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, w1
	b.ne	LBB13_303
LBB13_301:                              ; %b246
                                        ;   in Loop: Header=BB13_80 Depth=2
	orr	w23, w23, #0x2
	b	LBB13_303
LBB13_302:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w23, #2                         ; =0x2
LBB13_303:                              ; %b249
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x2, x26
	str	x3, [sp, #1416]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	str	x26, [sp, #1392]                ; 8-byte Folded Spill
	cbnz	x8, LBB13_305
; %bb.304:                              ; %b1.i.i838
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, wzr
	b	LBB13_308
LBB13_305:                              ; %v8_ok.i.i820
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_307
; %bb.306:                              ; %v8_ok.i.i820
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh28:
	adrp	x11, lJTI13_11@PAGE
Lloh29:
	add	x11, x11, lJTI13_11@PAGEOFF
	adr	x9, LBB13_307
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_307:                              ; %liza___liza_reactor_error.exit.i.i824
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, #1                         ; =0x1
LBB13_308:                              ; %liza_net.reactor_interest.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	mov	w4, w23
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbz	x8, LBB13_312
; %bb.309:                              ; %v8_ok.i.i846
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_311
; %bb.310:                              ; %v8_ok.i.i846
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh30:
	adrp	x11, lJTI13_12@PAGE
Lloh31:
	add	x11, x11, lJTI13_12@PAGEOFF
	adr	x9, LBB13_311
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_311:                              ; %liza___liza_reactor_error.exit.i.i850
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
LBB13_312:                              ; %b258
                                        ;   in Loop: Header=BB13_80 Depth=2
	orr	w8, w8, w20
	cbz	w8, LBB13_314
LBB13_313:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	x26, [sp, #1392]                ; 8-byte Folded Reload
	b	LBB13_94
LBB13_314:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	ldr	x23, [sp, #1408]                ; 8-byte Folded Reload
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	str	w22, [sp, #1432]                ; 4-byte Folded Spill
	ldr	w22, [sp, #1428]                ; 4-byte Folded Reload
	ldr	x28, [sp, #1392]                ; 8-byte Folded Reload
	ldr	x20, [sp, #1416]                ; 8-byte Folded Reload
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	str	w21, [sp, #1468]                ; 4-byte Folded Spill
	b	LBB13_107
LBB13_315:                              ;   in Loop: Header=BB13_26 Depth=1
	ldr	w5, [sp, #1364]                 ; 4-byte Folded Reload
	b	LBB13_25
LBB13_316:                              ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #1                          ; =0x1
	add	x3, sp, #1, lsl #12             ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	str	w9, [sp, #1320]                 ; 4-byte Folded Spill
	add	x7, sp, #1, lsl #12             ; =4096
	add	x14, sp, #1, lsl #12            ; =4096
	add	x13, sp, #1, lsl #12            ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x17, sp, #1, lsl #12            ; =4096
	add	x9, sp, #1, lsl #12             ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x26, sp, #1, lsl #12            ; =4096
	add	x3, x3, #216
	add	x16, x16, #158
	add	x7, x7, #224
	add	x14, x14, #228
	add	x13, x13, #170
	add	x19, x19, #236
	add	x12, x12, #240
	add	x4, x4, #182
	add	x11, x11, #248
	add	x1, x1, #252
	add	x10, x10, #194
	add	x17, x17, #260
	add	x9, x9, #264
	add	x15, x15, #208
	add	x0, x0, #272
	add	x2, x2, #276
	add	x5, x5, #210
	add	x6, x6, #284
	add	x23, x23, #288
	add	x24, x24, #212
	add	x22, x22, #296
	add	x25, x25, #300
	add	x20, x20, #214
	add	x26, x26, #308
	b	LBB13_77
LBB13_317:                              ; %b1.i147
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x10, [sp, #4536]
	ldr	x9, [sp, #4544]
	mov	w11, wzr
	ldr	x8, [sp, #4552]
	b	LBB13_73
LBB13_318:                              ; %b15
	ldr	x0, [sp, #720]                  ; 8-byte Folded Reload
	bl	_liza_rt_reactor_close
	mov	w8, #3                          ; =0x3
	cmp	w0, #0
	csel	w0, w21, w8, eq
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #464
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB13_319:                              ; %b1.i.i49
	mov	w19, wzr
	b	LBB13_14
LBB13_320:                              ; %v256_trap
	brk	#0x1
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc
	.section	__TEXT,__const
lJTI13_0:
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
lJTI13_1:
	.byte	(LBB13_41-LBB13_30)>>2
	.byte	(LBB13_30-LBB13_30)>>2
	.byte	(LBB13_35-LBB13_30)>>2
	.byte	(LBB13_34-LBB13_30)>>2
	.byte	(LBB13_32-LBB13_30)>>2
	.byte	(LBB13_33-LBB13_30)>>2
	.byte	(LBB13_40-LBB13_30)>>2
	.byte	(LBB13_36-LBB13_30)>>2
	.byte	(LBB13_37-LBB13_30)>>2
	.byte	(LBB13_39-LBB13_30)>>2
	.byte	(LBB13_38-LBB13_30)>>2
	.byte	(LBB13_31-LBB13_30)>>2
lJTI13_2:
	.byte	(LBB13_52-LBB13_52)>>2
	.byte	(LBB13_66-LBB13_52)>>2
	.byte	(LBB13_56-LBB13_52)>>2
	.byte	(LBB13_61-LBB13_52)>>2
	.byte	(LBB13_62-LBB13_52)>>2
	.byte	(LBB13_57-LBB13_52)>>2
	.byte	(LBB13_59-LBB13_52)>>2
	.byte	(LBB13_65-LBB13_52)>>2
	.byte	(LBB13_60-LBB13_52)>>2
	.byte	(LBB13_64-LBB13_52)>>2
	.byte	(LBB13_63-LBB13_52)>>2
	.byte	(LBB13_55-LBB13_52)>>2
	.byte	(LBB13_58-LBB13_52)>>2
	.p2align	1, 0x0
lJTI13_3:
	.short	(LBB13_317-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
lJTI13_4:
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
lJTI13_5:
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
lJTI13_6:
	.byte	(LBB13_125-LBB13_114)>>2
	.byte	(LBB13_114-LBB13_114)>>2
	.byte	(LBB13_119-LBB13_114)>>2
	.byte	(LBB13_118-LBB13_114)>>2
	.byte	(LBB13_116-LBB13_114)>>2
	.byte	(LBB13_117-LBB13_114)>>2
	.byte	(LBB13_124-LBB13_114)>>2
	.byte	(LBB13_120-LBB13_114)>>2
	.byte	(LBB13_121-LBB13_114)>>2
	.byte	(LBB13_123-LBB13_114)>>2
	.byte	(LBB13_122-LBB13_114)>>2
	.byte	(LBB13_115-LBB13_114)>>2
lJTI13_7:
	.byte	(LBB13_169-LBB13_150)>>2
	.byte	(LBB13_150-LBB13_150)>>2
	.byte	(LBB13_163-LBB13_150)>>2
	.byte	(LBB13_162-LBB13_150)>>2
	.byte	(LBB13_160-LBB13_150)>>2
	.byte	(LBB13_161-LBB13_150)>>2
	.byte	(LBB13_168-LBB13_150)>>2
	.byte	(LBB13_164-LBB13_150)>>2
	.byte	(LBB13_165-LBB13_150)>>2
	.byte	(LBB13_167-LBB13_150)>>2
	.byte	(LBB13_166-LBB13_150)>>2
	.byte	(LBB13_159-LBB13_150)>>2
lJTI13_8:
	.byte	(LBB13_202-LBB13_185)>>2
	.byte	(LBB13_185-LBB13_185)>>2
	.byte	(LBB13_196-LBB13_185)>>2
	.byte	(LBB13_195-LBB13_185)>>2
	.byte	(LBB13_193-LBB13_185)>>2
	.byte	(LBB13_194-LBB13_185)>>2
	.byte	(LBB13_201-LBB13_185)>>2
	.byte	(LBB13_197-LBB13_185)>>2
	.byte	(LBB13_198-LBB13_185)>>2
	.byte	(LBB13_200-LBB13_185)>>2
	.byte	(LBB13_199-LBB13_185)>>2
	.byte	(LBB13_192-LBB13_185)>>2
lJTI13_9:
	.byte	(LBB13_242-LBB13_227)>>2
	.byte	(LBB13_227-LBB13_227)>>2
	.byte	(LBB13_236-LBB13_227)>>2
	.byte	(LBB13_235-LBB13_227)>>2
	.byte	(LBB13_233-LBB13_227)>>2
	.byte	(LBB13_234-LBB13_227)>>2
	.byte	(LBB13_241-LBB13_227)>>2
	.byte	(LBB13_237-LBB13_227)>>2
	.byte	(LBB13_238-LBB13_227)>>2
	.byte	(LBB13_240-LBB13_227)>>2
	.byte	(LBB13_239-LBB13_227)>>2
	.byte	(LBB13_232-LBB13_227)>>2
lJTI13_10:
	.byte	(LBB13_279-LBB13_264)>>2
	.byte	(LBB13_264-LBB13_264)>>2
	.byte	(LBB13_273-LBB13_264)>>2
	.byte	(LBB13_272-LBB13_264)>>2
	.byte	(LBB13_270-LBB13_264)>>2
	.byte	(LBB13_271-LBB13_264)>>2
	.byte	(LBB13_278-LBB13_264)>>2
	.byte	(LBB13_274-LBB13_264)>>2
	.byte	(LBB13_275-LBB13_264)>>2
	.byte	(LBB13_277-LBB13_264)>>2
	.byte	(LBB13_276-LBB13_264)>>2
	.byte	(LBB13_269-LBB13_264)>>2
lJTI13_11:
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
lJTI13_12:
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
lJTI13_13:
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
lJTI13_14:
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_liza_proxy.serve          ; -- Begin function liza_liza_proxy.serve
	.p2align	2
_liza_liza_proxy.serve:                 ; @liza_liza_proxy.serve
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #256
	.cfi_def_cfa_offset 4512
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	mov	w20, w1
	mov	x19, x0
	add	x1, sp, #1484
	mov	w0, #32768                      ; =0x8000
	mov	w22, w2
	bl	_liza_rt_region_create
	ldr	w8, [sp, #1484]
	cbnz	w8, LBB14_3
; %bb.1:                                ; %b3
	add	x4, sp, #1480
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	w3, #32768                      ; =0x8000
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	bl	_liza_rt_region_alloc
	ldr	w8, [sp, #1480]
	cbz	w8, LBB14_5
; %bb.2:                                ; %b5
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_liza_rt_region_close
LBB14_3:                                ; %b2
	mov	x0, x19
	bl	_liza_rt_reactor_close
	mov	w0, #3                          ; =0x3
LBB14_4:                                ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #256
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB14_5:                                ; %v10_body.preheader
	mov	w1, #32768                      ; =0x8000
	mov	x21, x0
	bl	_bzero
	add	x8, sp, #225
	mov	x0, x19
	strb	wzr, [x8, #4095]
	add	x8, sp, #221
	strb	wzr, [x8, #4095]
	add	x8, sp, #220
	strb	wzr, [x8, #4095]
	add	x8, sp, #217
	strb	wzr, [x8, #4095]
	add	x8, sp, #216
	strb	wzr, [x8, #4095]
	add	x8, sp, #209
	strb	wzr, [x8, #4095]
	add	x8, sp, #205
	strb	wzr, [x8, #4095]
	add	x8, sp, #204
	strb	wzr, [x8, #4095]
	add	x8, sp, #201
	strb	wzr, [x8, #4095]
	add	x8, sp, #200
	strb	wzr, [x8, #4095]
	add	x8, sp, #193
	strb	wzr, [x8, #4095]
	add	x8, sp, #189
	strb	wzr, [x8, #4095]
	add	x8, sp, #188
	strb	wzr, [x8, #4095]
	add	x8, sp, #185
	strb	wzr, [x8, #4095]
	add	x8, sp, #184
	strb	wzr, [x8, #4095]
	add	x8, sp, #177
	strb	wzr, [x8, #4095]
	add	x8, sp, #173
	strb	wzr, [x8, #4095]
	add	x8, sp, #172
	strb	wzr, [x8, #4095]
	add	x8, sp, #169
	strb	wzr, [x8, #4095]
	add	x8, sp, #168
	strb	wzr, [x8, #4095]
	add	x8, sp, #161
	strb	wzr, [x8, #4095]
	add	x8, sp, #157
	strb	wzr, [x8, #4095]
	add	x8, sp, #156
	strb	wzr, [x8, #4095]
	add	x8, sp, #153
	strb	wzr, [x8, #4095]
	add	x8, sp, #152
	strb	wzr, [x8, #4095]
	add	x8, sp, #145
	strb	wzr, [x8, #4095]
	add	x8, sp, #141
	strb	wzr, [x8, #4095]
	add	x8, sp, #140
	strb	wzr, [x8, #4095]
	add	x8, sp, #137
	strb	wzr, [x8, #4095]
	add	x8, sp, #136
	strb	wzr, [x8, #4095]
	add	x8, sp, #129
	strb	wzr, [x8, #4095]
	add	x8, sp, #125
	strb	wzr, [x8, #4095]
	add	x8, sp, #124
	strb	wzr, [x8, #4095]
	add	x8, sp, #121
	strb	wzr, [x8, #4095]
	add	x8, sp, #120
	strb	wzr, [x8, #4095]
	add	x8, sp, #113
	strb	wzr, [x8, #4095]
	add	x8, sp, #109
	strb	wzr, [x8, #4095]
	add	x8, sp, #108
	strb	wzr, [x8, #4095]
	add	x8, sp, #105
	strb	wzr, [x8, #4095]
	add	x8, sp, #104
	strb	wzr, [x8, #4095]
	bl	_liza_rt_reactor_port
	lsr	x8, x0, #32
	str	x19, [sp, #688]                 ; 8-byte Folded Spill
	str	w22, [sp, #404]                 ; 4-byte Folded Spill
	str	w20, [sp, #140]                 ; 4-byte Folded Spill
	str	x21, [sp, #152]                 ; 8-byte Folded Spill
	cbz	x8, LBB14_9
; %bb.6:                                ; %v8_ok.i.i.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB14_8
; %bb.7:                                ; %v8_ok.i.i.i
Lloh32:
	adrp	x9, lJTI14_0@PAGE
Lloh33:
	add	x9, x9, lJTI14_0@PAGEOFF
	adr	x10, LBB14_8
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB14_8:                                ; %liza___liza_reactor_error.exit.i.i.i
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB14_9:                                ; %liza_net.reactor_port.exit.i
	cmp	w8, #1
	mov	w9, #3                          ; =0x3
	b.eq	LBB14_323
; %bb.10:                               ; %v12_ok.i
	mov	w0, w0
	bl	_liza_rt_print_u64
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB14_14
; %bb.11:                               ; %v12_ok.i
	cbz	w8, LBB14_324
; %bb.12:                               ; %v12_ok.i
	cmp	w8, #1
	b.eq	LBB14_17
; %bb.13:                               ; %v12_ok.i
	cmp	w8, #2
	b	LBB14_17
LBB14_14:                               ; %v12_ok.i
	cmp	w8, #3
	b.eq	LBB14_17
; %bb.15:                               ; %v12_ok.i
	cmp	w8, #4
	b.eq	LBB14_17
; %bb.16:                               ; %v12_ok.i
	cmp	w8, #5
LBB14_17:                               ; %b18.i.i.i
	mov	w19, #1                         ; =0x1
LBB14_18:                               ; %liza_console.print_u64.exit.i
Lloh34:
	adrp	x0, l_text.liza_proxy.exchange.v21@PAGE
Lloh35:
	add	x0, x0, l_text.liza_proxy.exchange.v21@PAGEOFF
	mov	w1, #1                          ; =0x1
	bl	_liza_rt_write_text
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB14_22
; %bb.19:                               ; %liza_console.print_u64.exit.i
	cbz	w8, LBB14_26
; %bb.20:                               ; %liza_console.print_u64.exit.i
	cmp	w8, #1
	b.eq	LBB14_26
; %bb.21:                               ; %liza_console.print_u64.exit.i
	cmp	w8, #2
	b	LBB14_25
LBB14_22:                               ; %liza_console.print_u64.exit.i
	cmp	w8, #3
	b.eq	LBB14_25
; %bb.23:                               ; %liza_console.print_u64.exit.i
	cmp	w8, #4
	b.eq	LBB14_25
; %bb.24:                               ; %liza_console.print_u64.exit.i
	cmp	w8, #5
LBB14_25:                               ; %b13.i.i58.i
	mov	w8, #1                          ; =0x1
LBB14_26:                               ; %b12_to_b13.i
	orr	w8, w8, w19
	mov	w9, #3                          ; =0x3
	cbnz	w8, LBB14_323
; %bb.27:                               ; %b14.lr.ph.i
	add	x8, sp, #1488
	mov	x14, xzr
	mov	x15, xzr
	add	x9, x8, #65
	add	x10, x8, #378
	mov	w17, wzr
	str	x9, [sp, #568]                  ; 8-byte Folded Spill
	add	x9, x8, #90
	mov	w26, wzr
	str	x9, [sp, #560]                  ; 8-byte Folded Spill
	add	x9, x8, #161
	mov	w21, wzr
	str	x9, [sp, #552]                  ; 8-byte Folded Spill
	add	x9, x8, #186
	mov	x27, xzr
	str	x9, [sp, #544]                  ; 8-byte Folded Spill
	add	x9, x8, #257
	mov	x1, xzr
	str	x9, [sp, #536]                  ; 8-byte Folded Spill
	add	x9, x8, #282
	mov	x7, xzr
	str	x9, [sp, #528]                  ; 8-byte Folded Spill
	add	x9, x8, #353
	mov	w19, wzr
	str	x9, [sp, #520]                  ; 8-byte Folded Spill
	add	x9, x8, #449
                                        ; implicit-def: $w23
                                        ; implicit-def: $w22
                                        ; implicit-def: $w20
	stp	x9, x10, [sp, #504]             ; 16-byte Folded Spill
	add	x10, x8, #474
	add	x9, x8, #545
	stp	x9, x10, [sp, #488]             ; 16-byte Folded Spill
	add	x10, x8, #570
	add	x9, x8, #641
	stp	x9, x10, [sp, #472]             ; 16-byte Folded Spill
	add	x10, x8, #666
	add	x9, x8, #737
	stp	x9, x10, [sp, #456]             ; 16-byte Folded Spill
	add	x9, sp, #2304
	add	x10, sp, #225
	add	x13, x9, #260
	add	x9, sp, #104
	ldrb	w10, [x10, #4095]
	ldrb	w9, [x9, #4095]
	add	x8, x8, #762
	str	xzr, [sp, #1240]                ; 8-byte Folded Spill
	str	w10, [sp, #976]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #404]                 ; 4-byte Folded Reload
	str	w9, [sp, #392]                  ; 4-byte Folded Spill
	add	x9, sp, #105
	ldrb	w9, [x9, #4095]
	eor	w10, w10, #0x1
	str	x8, [sp, #448]                  ; 8-byte Folded Spill
	str	w10, [sp, #400]                 ; 4-byte Folded Spill
	add	x8, sp, #1488
	str	w9, [sp, #384]                  ; 4-byte Folded Spill
	add	x9, sp, #108
	add	x8, x8, #260
	ldrb	w9, [x9, #4095]
	str	x8, [sp, #440]                  ; 8-byte Folded Spill
	str	wzr, [sp, #1260]                ; 4-byte Folded Spill
	str	w9, [sp, #380]                  ; 4-byte Folded Spill
	add	x9, sp, #109
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #1248]                ; 4-byte Folded Spill
	str	xzr, [sp, #1208]                ; 8-byte Folded Spill
	str	w9, [sp, #376]                  ; 4-byte Folded Spill
	add	x9, sp, #113
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1232]                ; 8-byte Folded Spill
	str	xzr, [sp, #1224]                ; 8-byte Folded Spill
	str	w9, [sp, #372]                  ; 4-byte Folded Spill
	add	x9, sp, #120
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1304]                ; 8-byte Folded Spill
	str	wzr, [sp, #1148]                ; 4-byte Folded Spill
	str	w9, [sp, #368]                  ; 4-byte Folded Spill
	add	x9, sp, #121
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #1136]                ; 4-byte Folded Spill
	str	wzr, [sp, #1164]                ; 4-byte Folded Spill
	str	w9, [sp, #364]                  ; 4-byte Folded Spill
	add	x9, sp, #124
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #1152]                ; 4-byte Folded Spill
	str	xzr, [sp, #1104]                ; 8-byte Folded Spill
	str	w9, [sp, #360]                  ; 4-byte Folded Spill
	add	x9, sp, #125
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1096]                ; 8-byte Folded Spill
	str	xzr, [sp, #1088]                ; 8-byte Folded Spill
	str	w9, [sp, #356]                  ; 4-byte Folded Spill
	add	x9, sp, #129
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1128]                ; 8-byte Folded Spill
	str	xzr, [sp, #1120]                ; 8-byte Folded Spill
	str	w9, [sp, #352]                  ; 4-byte Folded Spill
	add	x9, sp, #136
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1112]                ; 8-byte Folded Spill
	str	wzr, [sp, #1452]                ; 4-byte Folded Spill
	str	w9, [sp, #348]                  ; 4-byte Folded Spill
	add	x9, sp, #137
	ldrb	w9, [x9, #4095]
	stp	wzr, wzr, [sp, #164]            ; 8-byte Folded Spill
	str	xzr, [sp, #1056]                ; 8-byte Folded Spill
	str	w9, [sp, #344]                  ; 4-byte Folded Spill
	add	x9, sp, #140
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1048]                ; 8-byte Folded Spill
	str	xzr, [sp, #1040]                ; 8-byte Folded Spill
	str	w9, [sp, #848]                  ; 4-byte Folded Spill
	add	x9, sp, #141
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1080]                ; 8-byte Folded Spill
	str	xzr, [sp, #1072]                ; 8-byte Folded Spill
	str	w9, [sp, #844]                  ; 4-byte Folded Spill
	add	x9, sp, #145
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1064]                ; 8-byte Folded Spill
	str	wzr, [sp, #948]                 ; 4-byte Folded Spill
	str	w9, [sp, #852]                  ; 4-byte Folded Spill
	add	x9, sp, #152
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #952]                 ; 4-byte Folded Spill
	str	xzr, [sp, #792]                 ; 8-byte Folded Spill
	str	w9, [sp, #860]                  ; 4-byte Folded Spill
	add	x9, sp, #153
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #800]                 ; 8-byte Folded Spill
	str	xzr, [sp, #808]                 ; 8-byte Folded Spill
	str	w9, [sp, #856]                  ; 4-byte Folded Spill
	add	x9, sp, #156
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1464]                ; 8-byte Folded Spill
	str	xzr, [sp, #1440]                ; 8-byte Folded Spill
	str	w9, [sp, #868]                  ; 4-byte Folded Spill
	add	x9, sp, #157
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #876]                 ; 4-byte Folded Spill
	str	xzr, [sp, #880]                 ; 8-byte Folded Spill
	str	w9, [sp, #864]                  ; 4-byte Folded Spill
	add	x9, sp, #161
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #900]                 ; 4-byte Folded Spill
	str	xzr, [sp, #888]                 ; 8-byte Folded Spill
	str	w9, [sp, #872]                  ; 4-byte Folded Spill
	add	x9, sp, #168
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #904]                 ; 8-byte Folded Spill
	str	xzr, [sp, #912]                 ; 8-byte Folded Spill
	str	w9, [sp, #780]                  ; 4-byte Folded Spill
	add	x9, sp, #169
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #920]                 ; 8-byte Folded Spill
	str	xzr, [sp, #928]                 ; 8-byte Folded Spill
	str	w9, [sp, #776]                  ; 4-byte Folded Spill
	add	x9, sp, #172
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #936]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1368]                ; 8-byte Folded Spill
	str	w9, [sp, #784]                  ; 4-byte Folded Spill
	add	x9, sp, #173
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1360]                ; 8-byte Folded Spill
	str	xzr, [sp, #1352]                ; 8-byte Folded Spill
	str	w9, [sp, #788]                  ; 4-byte Folded Spill
	add	x9, sp, #177
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1344]                ; 8-byte Folded Spill
	str	wzr, [sp, #1336]                ; 4-byte Folded Spill
	str	w9, [sp, #340]                  ; 4-byte Folded Spill
	add	x9, sp, #184
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #1332]                ; 4-byte Folded Spill
	str	wzr, [sp, #1320]                ; 4-byte Folded Spill
	str	w9, [sp, #324]                  ; 4-byte Folded Spill
	add	x9, sp, #185
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #1312]                ; 4-byte Folded Spill
	str	xzr, [sp, #1296]                ; 8-byte Folded Spill
	str	w9, [sp, #300]                  ; 4-byte Folded Spill
	add	x9, sp, #188
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1032]                ; 8-byte Folded Spill
	str	xzr, [sp, #1000]                ; 8-byte Folded Spill
	str	w9, [sp, #320]                  ; 4-byte Folded Spill
	add	x9, sp, #189
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #992]                 ; 8-byte Folded Spill
	str	xzr, [sp, #984]                 ; 8-byte Folded Spill
	str	w9, [sp, #308]                  ; 4-byte Folded Spill
	add	x9, sp, #193
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1024]                ; 8-byte Folded Spill
	str	xzr, [sp, #1016]                ; 8-byte Folded Spill
	str	w9, [sp, #304]                  ; 4-byte Folded Spill
	add	x9, sp, #200
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1008]                ; 8-byte Folded Spill
	str	wzr, [sp, #1280]                ; 4-byte Folded Spill
	str	w9, [sp, #332]                  ; 4-byte Folded Spill
	add	x9, sp, #201
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #1292]                ; 4-byte Folded Spill
	str	wzr, [sp, #1276]                ; 4-byte Folded Spill
	str	w9, [sp, #316]                  ; 4-byte Folded Spill
	add	x9, sp, #204
	ldrb	w9, [x9, #4095]
	str	wzr, [sp, #1264]                ; 4-byte Folded Spill
	str	xzr, [sp, #1216]                ; 8-byte Folded Spill
	str	w9, [sp, #336]                  ; 4-byte Folded Spill
	add	x9, sp, #205
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1176]                ; 8-byte Folded Spill
	str	xzr, [sp, #1168]                ; 8-byte Folded Spill
	str	w9, [sp, #328]                  ; 4-byte Folded Spill
	add	x9, sp, #209
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1200]                ; 8-byte Folded Spill
	str	xzr, [sp, #1192]                ; 8-byte Folded Spill
	str	w9, [sp, #312]                  ; 4-byte Folded Spill
	add	x9, sp, #216
	ldrb	w9, [x9, #4095]
	str	xzr, [sp, #1184]                ; 8-byte Folded Spill
	str	wzr, [sp, #160]                 ; 4-byte Folded Spill
	str	w9, [sp, #388]                  ; 4-byte Folded Spill
	add	x9, sp, #217
	ldrb	w9, [x9, #4095]
	str	x13, [sp, #584]                 ; 8-byte Folded Spill
	str	w9, [sp, #396]                  ; 4-byte Folded Spill
	add	x9, sp, #220
	ldrb	w9, [x9, #4095]
	str	w9, [sp, #700]                  ; 4-byte Folded Spill
	add	x9, sp, #221
	ldrb	w9, [x9, #4095]
	str	w9, [sp, #968]                  ; 4-byte Folded Spill
	add	x9, sp, #3264
	add	x11, x9, #65
	add	x10, x9, #90
	stp	x10, x11, [sp, #120]            ; 16-byte Folded Spill
	add	x11, x9, #161
	add	x10, x9, #186
	stp	x10, x11, [sp, #104]            ; 16-byte Folded Spill
	add	x11, x9, #257
	add	x10, x9, #282
	stp	x10, x11, [sp, #88]             ; 16-byte Folded Spill
	add	x11, x9, #353
	add	x10, x9, #378
	stp	x10, x11, [sp, #72]             ; 16-byte Folded Spill
	add	x11, x9, #449
	add	x10, x9, #474
	stp	x10, x11, [sp, #56]             ; 16-byte Folded Spill
	add	x11, x9, #545
	add	x10, x9, #570
	stp	x10, x11, [sp, #40]             ; 16-byte Folded Spill
	add	x11, x9, #641
	add	x10, x9, #666
	stp	x10, x11, [sp, #24]             ; 16-byte Folded Spill
	add	x11, x9, #737
	add	x10, sp, #2304
	add	x9, x9, #762
	add	x12, x10, #161
	add	x4, x10, #186
	stp	x9, x11, [sp, #8]               ; 16-byte Folded Spill
	add	x9, x10, #65
	add	x6, x10, #282
	str	x9, [sp, #656]                  ; 8-byte Folded Spill
	add	x9, x10, #90
	add	x16, x10, #353
	str	x9, [sp, #680]                  ; 8-byte Folded Spill
	add	x9, x10, #257
	add	x30, x10, #449
	str	x9, [sp, #640]                  ; 8-byte Folded Spill
	add	x9, x10, #378
	add	x0, x10, #474
	str	x9, [sp, #752]                  ; 8-byte Folded Spill
	add	x9, x13, #324
	add	x11, x10, #545
	str	x9, [sp, #728]                  ; 8-byte Folded Spill
	add	x9, x13, #356
	add	x24, x10, #570
	str	x9, [sp, #720]                  ; 8-byte Folded Spill
	add	x9, x10, #641
	add	x2, x10, #737
	str	x9, [sp, #744]                  ; 8-byte Folded Spill
	add	x9, x10, #666
	add	x3, x10, #762
	str	x9, [sp, #736]                  ; 8-byte Folded Spill
	add	x9, x13, #420
	add	x10, x8, #324
	str	x9, [sp, #712]                  ; 8-byte Folded Spill
	add	x9, x13, #452
	mov	x25, x16
	str	x9, [sp, #704]                  ; 8-byte Folded Spill
	add	x9, x8, #356
	stp	x9, x10, [sp, #424]             ; 16-byte Folded Spill
	add	x9, x8, #420
	add	x8, x8, #452
	stp	x8, x9, [sp, #408]              ; 16-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w10, #1                         ; =0x1
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x16, [sp, #576]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x12, [sp, #648]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x4, [sp, #672]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x6, [sp, #664]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x30, [sp, #632]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x0, [sp, #624]                  ; 8-byte Folded Spill
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x11, [sp, #616]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x24, [sp, #608]                 ; 8-byte Folded Spill
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x2, [sp, #600]                  ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x3, [sp, #592]                  ; 8-byte Folded Spill
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #772]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1436]                 ; 4-byte Folded Spill
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	str	w8, [sp, #956]                  ; 4-byte Folded Spill
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	str	w8, [sp, #1472]                 ; 4-byte Folded Spill
	str	w8, [sp, #1424]                 ; 4-byte Folded Spill
	b	LBB14_30
LBB14_28:                               ;   in Loop: Header=BB14_30 Depth=1
	ldr	x21, [sp, #680]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #672]                  ; 8-byte Folded Reload
	mov	w28, wzr
	ldr	x6, [sp, #664]                  ; 8-byte Folded Reload
	str	x23, [sp, #1464]                ; 8-byte Folded Spill
LBB14_29:                               ; %b61_to_b13.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	w10, [x21]
	ldrb	w9, [x1, #2]
	add	x13, sp, #103
	ldrh	w8, [x1]
	ldr	x1, [sp, #2312]
	mov	x25, x20
	str	w10, [sp, #4188]
	ldr	w10, [sp, #2304]
	ldr	x7, [sp, #2320]
	strb	w9, [x13, #4095]
	ldrb	w9, [x12, #2]
	ldr	w26, [sp, #2760]
	str	w10, [sp, #1424]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2308]
	ldrh	w22, [sp, #2958]
	strh	w8, [sp, #4196]
	ldrh	w8, [x21, #4]
	ldr	w21, [sp, #2756]
	str	w10, [sp, #224]                 ; 4-byte Folded Spill
	add	x10, sp, #91
	ldrh	w23, [sp, #3054]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2328]
	ldrh	w9, [x4, #4]
	strh	w8, [sp, #4192]
	ldrh	w8, [x12]
	str	x10, [sp, #1368]                ; 8-byte Folded Spill
	ldr	w10, [sp, #2336]
	strh	w9, [sp, #4180]
	ldrb	w9, [x19, #2]
	str	w10, [sp, #276]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2340]
	strh	w8, [sp, #4184]
	ldr	w8, [x4]
	str	w10, [sp, #220]                 ; 4-byte Folded Spill
	add	x10, sp, #79
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2344]
	ldrh	w9, [x6, #4]
	str	w8, [sp, #4176]
	ldrh	w8, [x19]
	str	x10, [sp, #1360]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2352]
	strh	w8, [sp, #4172]
	ldr	w8, [x6]
	str	x10, [sp, #1352]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2360]
	strh	w9, [sp, #4168]
	ldrb	w9, [x20, #2]
	str	x10, [sp, #1344]                ; 8-byte Folded Spill
	ldrb	w10, [sp, #2368]
	str	w8, [sp, #4164]
	ldrh	w8, [x20]
	ldrh	w20, [sp, #2478]
	str	w10, [sp, #976]                 ; 4-byte Folded Spill
	add	x10, sp, #67
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #752]                 ; 8-byte Folded Reload
	strh	w8, [sp, #4160]
	ldr	w8, [x10]
	ldrh	w9, [x10, #4]
	ldr	w10, [sp, #2372]
	str	w8, [sp, #4152]
	ldrh	w8, [x30]
	str	w10, [sp, #1336]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2376]
	strh	w8, [sp, #4148]
	ldr	w8, [x0]
	str	w10, [sp, #1332]                ; 4-byte Folded Spill
	ldrb	w10, [sp, #2380]
	str	w8, [sp, #4140]
	ldrh	w8, [x11]
	str	w10, [sp, #968]                 ; 4-byte Folded Spill
	ldrb	w10, [sp, #2381]
	strh	w8, [sp, #4136]
	ldr	w8, [x17]
	strh	w9, [sp, #4156]
	ldrb	w9, [x30, #2]
	str	w8, [sp, #4128]
	ldrh	w8, [x15]
	str	w10, [sp, #700]                 ; 4-byte Folded Spill
	add	x10, sp, #55
	strh	w8, [sp, #4124]
	ldr	w8, [x14]
	strb	w9, [x10, #4095]
	ldrh	w10, [sp, #2382]
	ldrh	w9, [x0, #4]
	str	w8, [sp, #4116]
	ldrh	w8, [x2]
	str	w10, [sp, #232]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2384]
	strh	w8, [sp, #4112]
	ldr	x8, [sp, #2440]
	str	w10, [sp, #1320]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2388]
	str	x8, [sp, #1224]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2448]
	str	w10, [sp, #1312]                ; 4-byte Folded Spill
	ldrb	w10, [sp, #2392]
	str	x8, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2456]
	strh	w9, [sp, #4144]
	ldrb	w9, [x11, #2]
	ldr	w11, [sp, #2404]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2464]
	str	w10, [sp, #396]                 ; 4-byte Folded Spill
	add	x10, sp, #43
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2468]
	strb	w9, [x10, #4095]
	ldrb	w10, [sp, #2393]
	ldrh	w9, [x17, #4]
	str	w8, [sp, #1248]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2472]
	ldr	w17, [sp, #960]                 ; 4-byte Folded Reload
	str	w10, [sp, #388]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2400]
	str	w8, [sp, #1260]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2476]
	strh	w9, [sp, #4132]
	ldrb	w9, [x15, #2]
	ldr	x15, [sp, #2416]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2477]
	str	w10, [sp, #1472]                ; 4-byte Folded Spill
	add	x10, sp, #31
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2480]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2408]
	ldrh	w9, [x14, #4]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2484]
	ldr	x14, [sp, #2424]
	str	x10, [sp, #1304]                ; 8-byte Folded Spill
	ldr	w10, [sp, #2432]
	str	w8, [sp, #1244]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2488]
	str	w10, [sp, #296]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2436]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2489]
	strh	w9, [sp, #4120]
	ldrb	w9, [x2, #2]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2496]
	stp	w10, w11, [sp, #212]            ; 8-byte Folded Spill
	add	x10, sp, #19
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2504]
	strb	w9, [x10, #4095]
	ldrh	w9, [x3, #4]
	ldr	w10, [sp, #2816]
	str	x8, [sp, #1112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2512]
	strh	w9, [sp, #4108]
	ldr	w9, [sp, #2500]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2520]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2528]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2532]
	stp	w9, w8, [sp, #204]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2536]
	ldr	w9, [sp, #2596]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2544]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2552]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2560]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2564]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2568]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2572]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2573]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2574]
	str	w8, [sp, #228]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2576]
	str	w8, [sp, #1136]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2580]
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2584]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2585]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2592]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2600]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2608]
	str	x8, [sp, #1072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2616]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2624]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2628]
	stp	w9, w8, [sp, #196]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2632]
	ldr	w9, [sp, #2884]
	str	x8, [sp, #1040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2640]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2648]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2656]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2752]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2764]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2765]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2766]
	str	w8, [sp, #176]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2768]
	str	w8, [sp, #952]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2772]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2776]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2777]
	str	w8, [sp, #860]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2784]
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2788]
	str	w8, [sp, #820]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #2792]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2800]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2808]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2820]
	str	w8, [sp, #816]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #2824]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2832]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2840]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2848]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2852]
	str	w8, [sp, #900]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2856]
	str	w8, [sp, #884]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2860]
	str	w8, [sp, #844]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2861]
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2862]
	str	w8, [sp, #172]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2864]
	str	w8, [sp, #880]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2868]
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2872]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2873]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2880]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2888]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2896]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2904]
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2912]
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2916]
	stp	w9, w8, [sp, #180]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2920]
	ldr	w9, [sp, #2980]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2928]
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2936]
	str	x8, [sp, #1000]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2944]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2948]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2952]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2956]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2957]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2960]
	str	w8, [sp, #1296]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2964]
	str	w8, [sp, #1300]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2968]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2969]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2976]
	str	w8, [sp, #1436]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2984]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2992]
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3000]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3008]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3012]
	stp	w9, w8, [sp, #188]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3016]
	ldr	w9, [sp, #3060]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3024]
	str	w9, [sp, #1280]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #3064]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3032]
	str	w9, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #3065]
	str	x8, [sp, #1216]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3040]
	str	w9, [sp, #392]                  ; 4-byte Folded Spill
	ldr	w9, [sp, #696]                  ; 4-byte Folded Reload
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3044]
	mov	w19, w9
	str	w8, [sp, #1264]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3048]
	str	w8, [sp, #1276]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3052]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3053]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3056]
	str	w8, [sp, #1292]                 ; 4-byte Folded Spill
	ldr	w8, [x3]
	str	w8, [sp, #4104]
	tbz	w28, #0, LBB14_323
LBB14_30:                               ; %b14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_82 Depth 2
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	stp	x7, x1, [sp, #256]              ; 16-byte Folded Spill
	mov	w1, #1000                       ; =0x3e8
	stp	x14, x15, [sp, #240]            ; 16-byte Folded Spill
	str	w10, [sp, #832]                 ; 4-byte Folded Spill
	str	x27, [sp, #1456]                ; 8-byte Folded Spill
	str	w17, [sp, #960]                 ; 4-byte Folded Spill
	bl	_liza_rt_reactor_poll
	lsr	x8, x0, #32
	cbnz	x8, LBB14_32
; %bb.31:                               ; %b1.i.i95.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldp	w17, w15, [sp, #228]            ; 8-byte Folded Reload
	ldp	w4, w0, [sp, #172]              ; 8-byte Folded Reload
	ldr	w13, [sp, #956]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #964]                 ; 4-byte Folded Reload
	mov	w9, wzr
	mov	w5, w22
	mov	w7, w23
	b	LBB14_46
LBB14_32:                               ; %v8_ok.i.i77.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldp	w17, w15, [sp, #228]            ; 8-byte Folded Reload
	ldp	w4, w0, [sp, #172]              ; 8-byte Folded Reload
	sub	w9, w8, #1
	ldr	w13, [sp, #956]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #964]                 ; 4-byte Folded Reload
	cmp	w9, #11
	mov	w5, w22
	mov	w7, w23
	b.hi	LBB14_44
; %bb.33:                               ; %v8_ok.i.i77.i
                                        ;   in Loop: Header=BB14_30 Depth=1
Lloh36:
	adrp	x12, lJTI14_1@PAGE
Lloh37:
	add	x12, x12, lJTI14_1@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB14_34
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB14_34:                               ; %b4.i.i.i93.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB14_45
LBB14_35:                               ; %b34.i.i.i88.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #11                         ; =0xb
	b	LBB14_45
LBB14_36:                               ; %b13.i.i.i90.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB14_45
LBB14_37:                               ; %b16.i.i.i89.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB14_45
LBB14_38:                               ; %b10.i.i.i91.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #3                          ; =0x3
	b	LBB14_45
LBB14_39:                               ; %b7.i.i.i92.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB14_45
LBB14_40:                               ; %b22.i.i.i87.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB14_45
LBB14_41:                               ; %b25.i.i.i86.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB14_45
LBB14_42:                               ; %b31.i.i.i80.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #10                         ; =0xa
	b	LBB14_45
LBB14_43:                               ; %b28.i.i.i85.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB14_45
LBB14_44:                               ; %b36.i.i.i94.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #6                          ; =0x6
LBB14_45:                               ; %liza___liza_reactor_error.exit.i.i81.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w9, #1                          ; =0x1
LBB14_46:                               ; %liza_net.reactor_poll.exit.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	cmp	w9, #1
	str	w21, [sp, #840]                 ; 4-byte Folded Spill
	str	w26, [sp, #836]                 ; 4-byte Folded Spill
	b.ne	LBB14_48
; %bb.47:                               ; %b17.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w9, #1                          ; =0x1
	mov	w1, #3                          ; =0x3
	mov	w28, wzr
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB14_49
LBB14_48:                               ;   in Loop: Header=BB14_30 Depth=1
	mov	w28, #1                         ; =0x1
	mov	w1, w19
LBB14_49:                               ; %b22_to_b23.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	add	x9, sp, #67
	ldr	w12, [sp, #1472]                ; 4-byte Folded Reload
	ldrh	w8, [sp, #4160]
	ldrb	w9, [x9, #4095]
	ldr	w10, [sp, #4152]
	add	x16, sp, #1, lsl #12            ; =4096
	cmp	w12, #1
	ldr	w12, [sp, #1424]                ; 4-byte Folded Reload
	ldrh	w11, [sp, #4156]
	strb	w9, [sp, #4038]
	ldrh	w9, [sp, #4148]
	add	x26, sp, #1, lsl #12            ; =4096
	strh	w8, [sp, #4036]
	mov	w8, #8                          ; =0x8
	add	x2, sp, #1, lsl #12             ; =4096
	strh	w9, [sp, #4084]
	ldrh	w9, [sp, #4144]
	csinc	w8, w8, wzr, ne
	cmp	w12, #1
	str	w10, [sp, #4088]
	add	x10, sp, #55
	csel	w8, wzr, w8, eq
	strh	w11, [sp, #4092]
	ldrb	w10, [x10, #4095]
	ldr	w11, [sp, #1392]                ; 4-byte Folded Reload
	strh	w9, [sp, #4080]
	add	x9, sp, #43
	cmp	w8, #8
	ldrb	w9, [x9, #4095]
	strb	w10, [sp, #4086]
	ccmp	w11, #1, #0, eq
	ldr	w10, [sp, #4140]
	mov	w11, #2                         ; =0x2
	csel	w8, w11, w8, eq
	ldr	w11, [sp, #1384]                ; 4-byte Folded Reload
	strb	w9, [sp, #4074]
	ldr	w9, [sp, #4128]
	cmp	w8, #8
	str	w10, [sp, #4076]
	ldrh	w10, [sp, #4136]
	ccmp	w11, #1, #0, eq
	mov	w11, #3                         ; =0x3
	str	w9, [sp, #4064]
	ldrh	w9, [sp, #4124]
	csel	w8, w11, w8, eq
	strh	w10, [sp, #4072]
	ldrh	w10, [sp, #4132]
	cmp	w8, #8
	strh	w9, [sp, #4060]
	ldr	w9, [sp, #4116]
	ccmp	w13, #1, #0, eq
	strh	w10, [sp, #4068]
	add	x10, sp, #31
	mov	w11, #4                         ; =0x4
	ldrb	w10, [x10, #4095]
	csel	w8, w11, w8, eq
	str	w9, [sp, #4052]
	add	x9, sp, #19
	cmp	w8, #8
	mov	w11, #5                         ; =0x5
	ldrb	w9, [x9, #4095]
	strb	w10, [sp, #4062]
	ldrh	w10, [sp, #4120]
	ccmp	w14, #1, #0, eq
	strh	w15, [sp, #4102]
	add	x15, sp, #1, lsl #12            ; =4096
	csel	w8, w11, w8, eq
	strb	w9, [sp, #4050]
	ldr	w9, [sp, #1416]                 ; 4-byte Folded Reload
	strh	w10, [sp, #4056]
	ldrh	w10, [sp, #4112]
	cmp	w8, #8
	ccmp	w9, #1, #0, eq
	ldrh	w9, [sp, #4108]
	strh	w17, [sp, #4098]
	strh	w10, [sp, #4048]
	mov	w10, #6                         ; =0x6
	add	x17, sp, #1, lsl #12            ; =4096
	csel	w8, w10, w8, eq
	strh	w9, [sp, #4044]
	ldr	w9, [sp, #1436]                 ; 4-byte Folded Reload
	cmp	w8, #8
	ldr	w10, [sp, #4104]
	strh	w0, [sp, #4082]
	ccmp	w9, #1, #0, eq
	mov	w9, #7                          ; =0x7
	add	x3, sp, #1, lsl #12             ; =4096
	csel	w19, w9, w8, eq
	ldr	w8, [sp, #824]                  ; 4-byte Folded Reload
	str	w10, [sp, #4040]
	add	x6, sp, #1, lsl #12             ; =4096
	strh	w5, [sp, #4058]
	add	x14, sp, #1, lsl #12            ; =4096
	strh	w8, [sp, #4096]
	add	x21, sp, #1, lsl #12            ; =4096
	add	x30, sp, #1, lsl #12            ; =4096
	strh	w7, [sp, #4046]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	add	x9, sp, #1, lsl #12             ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x15, x15, #8
	add	x16, x16, #16
	add	x17, x17, #20
	add	x26, x26, #28
	add	x2, x2, #32
	add	x3, x3, #40
	add	x6, x6, #44
	add	x14, x14, #52
	add	x21, x21, #56
	add	x27, sp, #1, lsl #12            ; =4096
	add	x30, x30, #64
	add	x8, x8, #68
	add	x24, x24, #2
	add	x7, x7, #76
	add	x9, x9, #80
	add	x0, x0, #4
	add	x10, x10, #88
	add	x11, x11, #92
	add	x5, x5, #6
	add	x12, x12, #100
	strh	w20, [sp, #4100]
	strh	w4, [sp, #4070]
	str	w28, [sp, #1376]                ; 4-byte Folded Spill
	str	w1, [sp, #696]                  ; 4-byte Folded Spill
	cbz	w28, LBB14_61
; %bb.50:                               ; %b22_to_b23.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	cmp	w19, #7
	b.hi	LBB14_61
; %bb.51:                               ; %b22_to_b23.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	w1, [sp, #160]                  ; 4-byte Folded Reload
	ldr	w24, [sp, #404]                 ; 4-byte Folded Reload
	add	x28, sp, #4058
	and	w24, w24, w1
	tbnz	w24, #0, LBB14_60
; %bb.52:                               ; %b42.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	add	x1, sp, #1, lsl #12             ; =4096
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	add	x1, x1, #232
	bl	_liza_rt_reactor_accept
	cmp	w0, #12
	b.hi	LBB14_74
; %bb.53:                               ; %b42.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, w0
Lloh38:
	adrp	x11, lJTI14_2@PAGE
Lloh39:
	add	x11, x11, lJTI14_2@PAGEOFF
	adr	x9, LBB14_54
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	mov	w25, wzr
	br	x9
LBB14_54:                               ; %b1.i119.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	x27, [sp, #4328]
	ldr	x28, [sp, #4336]
	mov	w8, wzr
	ldr	x9, [sp, #4344]
	mov	w25, wzr
	cmp	w8, #1
	b.eq	LBB14_76
LBB14_55:                               ; %b49.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	add	x2, sp, #1, lsl #12             ; =4096
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	ldr	w1, [sp, #140]                  ; 4-byte Folded Reload
	add	x2, x2, #232
	str	x9, [sp, #1376]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_connect
	cmp	w0, #12
	b.hi	LBB14_57
; %bb.56:                               ; %b49.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, w0
Lloh40:
	adrp	x11, lJTI14_3@PAGE
Lloh41:
	add	x11, x11, lJTI14_3@PAGEOFF
	adr	x9, LBB14_57
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB14_57:                               ; %liza___liza_reactor_error.exit.i134.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	x10, xzr
	mov	x9, xzr
	mov	x8, xzr
	mov	w11, #1                         ; =0x1
LBB14_58:                               ; %liza_net.reactor_connect.exit.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	x13, [sp, #808]                 ; 8-byte Folded Reload
	ldr	x14, [sp, #800]                 ; 8-byte Folded Reload
	cmp	w11, #1
	ldr	x15, [sp, #792]                 ; 8-byte Folded Reload
	ldr	w16, [sp, #788]                 ; 4-byte Folded Reload
	ldr	w6, [sp, #784]                  ; 4-byte Folded Reload
	ldr	w7, [sp, #780]                  ; 4-byte Folded Reload
	ldr	w21, [sp, #776]                 ; 4-byte Folded Reload
	ldr	w24, [sp, #768]                 ; 4-byte Folded Reload
	ldr	w25, [sp, #772]                 ; 4-byte Folded Reload
	ldr	w26, [sp, #764]                 ; 4-byte Folded Reload
	b.ne	LBB14_62
; %bb.59:                               ; %b51.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	mov	x1, x27
	mov	x2, x28
	bl	_liza_rt_reactor_disconnect
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	ldr	w13, [sp, #696]                 ; 4-byte Folded Reload
	mov	w9, #3                          ; =0x3
	ldp	w19, w7, [sp, #228]             ; 8-byte Folded Reload
	tst	w8, #0x1
	add	x8, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	csel	w13, w9, w13, ne
	add	x11, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	ldp	w28, w27, [sp, #172]            ; 8-byte Folded Reload
	str	w13, [sp, #696]                 ; 4-byte Folded Spill
	add	x13, sp, #1, lsl #12            ; =4096
	add	x14, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x17, sp, #1, lsl #12            ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x9, sp, #1, lsl #12             ; =4096
	ldr	w30, [sp, #400]                 ; 4-byte Folded Reload
	ldr	w26, [sp, #824]                 ; 4-byte Folded Reload
	add	x8, x8, #16
	add	x10, x10, #20
	add	x11, x11, #28
	add	x12, x12, #32
	add	x13, x13, #40
	add	x14, x14, #44
	add	x15, x15, #52
	add	x16, x16, #56
	add	x17, x17, #64
	add	x0, x0, #68
	add	x1, x1, #76
	add	x2, x2, #80
	add	x3, x3, #88
	add	x4, x4, #92
	add	x5, x5, #100
	add	x9, x9, #8
	b	LBB14_63
LBB14_60:                               ;   in Loop: Header=BB14_30 Depth=1
	ldr	x22, [sp, #752]                 ; 8-byte Folded Reload
	ldr	x23, [sp, #1464]                ; 8-byte Folded Reload
	add	x13, sp, #4046
	add	x24, sp, #1, lsl #12            ; =4096
	str	x13, [sp, #232]                 ; 8-byte Folded Spill
	add	x4, sp, #4082
	add	x13, sp, #4070
	add	x24, x24, #2
	b	LBB14_80
LBB14_61:                               ;   in Loop: Header=BB14_30 Depth=1
	ldr	x23, [sp, #1464]                ; 8-byte Folded Reload
	add	x13, sp, #4046
	ldr	x22, [sp, #752]                 ; 8-byte Folded Reload
	str	x13, [sp, #232]                 ; 8-byte Folded Spill
	add	x28, sp, #4058
	add	x4, sp, #4082
	add	x13, sp, #4070
	b	LBB14_80
LBB14_62:                               ; %v101_ok.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	w11, [sp, #1424]                ; 4-byte Folded Reload
	ldr	x5, [sp, #128]                  ; 8-byte Folded Reload
	mov	w30, #1                         ; =0x1
	ldr	x4, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #104]                  ; 8-byte Folded Reload
	str	w11, [sp, #3264]
	ldrh	w11, [sp, #4196]
	ldr	x1, [sp, #96]                   ; 8-byte Folded Reload
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x17, [sp, #80]                  ; 8-byte Folded Reload
	strb	w16, [sp, #3628]
	strh	w11, [x5]
	ldr	w11, [sp, #1336]                ; 4-byte Folded Reload
	ldr	x16, [sp, #72]                  ; 8-byte Folded Reload
	str	x15, [sp, #3704]
	ldr	x15, [sp, #64]                  ; 8-byte Folded Reload
	ldr	w12, [sp, #224]                 ; 4-byte Folded Reload
	str	w11, [sp, #3332]
	ldr	w11, [sp, #1332]                ; 4-byte Folded Reload
	str	x14, [sp, #3696]
	ldr	x14, [sp, #56]                  ; 8-byte Folded Reload
	str	w11, [sp, #3336]
	ldr	w11, [sp, #968]                 ; 4-byte Folded Reload
	str	w12, [sp, #3268]
	ldr	x12, [sp, #264]                 ; 8-byte Folded Reload
	strb	w11, [sp, #3340]
	ldr	w11, [sp, #700]                 ; 4-byte Folded Reload
	str	x12, [sp, #3272]
	ldr	x12, [sp, #256]                 ; 8-byte Folded Reload
	strb	w11, [sp, #3341]
	ldr	w11, [sp, #232]                 ; 4-byte Folded Reload
	strb	w6, [sp, #3629]
	ldr	x6, [sp, #48]                   ; 8-byte Folded Reload
	strh	w11, [sp, #3342]
	ldr	w11, [sp, #1320]                ; 4-byte Folded Reload
	str	x12, [sp, #3280]
	ldr	x12, [sp, #1368]                ; 8-byte Folded Reload
	str	w11, [sp, #3344]
	ldr	w11, [sp, #1312]                ; 4-byte Folded Reload
	str	x12, [sp, #3288]
	ldr	w12, [sp, #276]                 ; 4-byte Folded Reload
	str	w11, [sp, #3348]
	ldr	w11, [sp, #396]                 ; 4-byte Folded Reload
	str	w12, [sp, #3296]
	ldr	w12, [sp, #220]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3352]
	ldr	w11, [sp, #4188]
	str	w12, [sp, #3300]
	ldr	x12, [sp, #1360]                ; 8-byte Folded Reload
	str	w11, [x4]
	ldr	w11, [sp, #1472]                ; 4-byte Folded Reload
	str	x12, [sp, #3304]
	ldr	x12, [sp, #1352]                ; 8-byte Folded Reload
	str	w11, [sp, #3360]
	ldr	w11, [sp, #216]                 ; 4-byte Folded Reload
	str	x12, [sp, #3312]
	ldr	x12, [sp, #1344]                ; 8-byte Folded Reload
	str	w11, [sp, #3364]
	ldr	x11, [sp, #1304]                ; 8-byte Folded Reload
	str	x12, [sp, #3320]
	ldr	w12, [sp, #976]                 ; 4-byte Folded Reload
	str	x11, [sp, #3368]
	ldr	x11, [sp, #248]                 ; 8-byte Folded Reload
	strb	w12, [sp, #3328]
	add	x12, sp, #103
	str	x11, [sp, #3376]
	ldr	x11, [sp, #240]                 ; 8-byte Folded Reload
	ldrb	w12, [x12, #4095]
	strb	w7, [sp, #3641]
	ldr	x7, [sp, #40]                   ; 8-byte Folded Reload
	str	x11, [sp, #3384]
	ldr	w11, [sp, #296]                 ; 4-byte Folded Reload
	strb	w12, [x5, #2]
	ldr	w12, [sp, #388]                 ; 4-byte Folded Reload
	str	w11, [sp, #3392]
	ldr	w11, [sp, #212]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3353]
	ldrh	w12, [sp, #4192]
	str	w11, [sp, #3396]
	ldr	x11, [sp, #1224]                ; 8-byte Folded Reload
	strh	w12, [x4, #4]
	ldr	w12, [sp, #312]                 ; 4-byte Folded Reload
	str	x11, [sp, #3400]
	ldr	x11, [sp, #1232]                ; 8-byte Folded Reload
	strb	w12, [sp, #3424]
	ldrh	w12, [sp, #4184]
	str	x11, [sp, #3408]
	ldr	x11, [sp, #1208]                ; 8-byte Folded Reload
	strh	w12, [x3]
	ldr	w12, [sp, #332]                 ; 4-byte Folded Reload
	str	x11, [sp, #3416]
	add	x11, sp, #91
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3449]
	ldr	w12, [sp, #4176]
	strb	w21, [sp, #3640]
	ldr	x21, [sp, #32]                  ; 8-byte Folded Reload
	strb	w11, [x3, #2]
	ldr	w11, [sp, #1248]                ; 4-byte Folded Reload
	str	w12, [x2]
	ldr	w12, [sp, #304]                 ; 4-byte Folded Reload
	str	w11, [sp, #3428]
	ldr	w11, [sp, #1260]                ; 4-byte Folded Reload
	strb	w12, [sp, #3520]
	ldrh	w12, [sp, #4172]
	str	w11, [sp, #3432]
	ldr	w11, [sp, #328]                 ; 4-byte Folded Reload
	strh	w12, [x1]
	ldr	w12, [sp, #324]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3436]
	ldr	w11, [sp, #336]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3545]
	ldr	w12, [sp, #4164]
	strb	w11, [sp, #3437]
	ldr	w11, [sp, #1240]                ; 4-byte Folded Reload
	str	w12, [x0]
	ldr	w12, [sp, #340]                 ; 4-byte Folded Reload
	str	w11, [sp, #3440]
	ldr	w11, [sp, #1244]                ; 4-byte Folded Reload
	strb	w12, [sp, #3616]
	ldrh	w12, [sp, #4036]
	str	w11, [sp, #3444]
	ldr	w11, [sp, #316]                 ; 4-byte Folded Reload
	strh	w12, [x17]
	ldr	w12, [sp, #4088]
	strb	w11, [sp, #3448]
	ldrh	w11, [sp, #4180]
	str	w12, [x16]
	ldr	w12, [sp, #872]                 ; 4-byte Folded Reload
	strh	w11, [x2, #4]
	ldr	w11, [sp, #1392]                ; 4-byte Folded Reload
	strb	w12, [sp, #3712]
	ldrh	w12, [sp, #4084]
	str	w11, [sp, #3456]
	ldr	w11, [sp, #204]                 ; 4-byte Folded Reload
	strh	w12, [x15]
	ldr	w12, [sp, #868]                 ; 4-byte Folded Reload
	str	w11, [sp, #3460]
	ldr	x11, [sp, #1112]                ; 8-byte Folded Reload
	strb	w12, [sp, #3725]
	ldr	w12, [sp, #860]                 ; 4-byte Folded Reload
	str	x11, [sp, #3464]
	ldr	x11, [sp, #1120]                ; 8-byte Folded Reload
	str	w24, [sp, #3652]
	ldr	x24, [sp, #24]                  ; 8-byte Folded Reload
	str	x11, [sp, #3472]
	ldr	x11, [sp, #1128]                ; 8-byte Folded Reload
	strb	w12, [sp, #3737]
	ldr	w12, [sp, #4076]
	str	x11, [sp, #3480]
	ldr	w11, [sp, #292]                 ; 4-byte Folded Reload
	str	w12, [x14]
	ldr	w12, [sp, #852]                 ; 4-byte Folded Reload
	str	w11, [sp, #3488]
	ldr	w11, [sp, #208]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3808]
	ldrh	w12, [sp, #4072]
	str	w11, [sp, #3492]
	ldr	x11, [sp, #1088]                ; 8-byte Folded Reload
	strh	w12, [x6]
	ldr	w12, [sp, #848]                 ; 4-byte Folded Reload
	str	x11, [sp, #3496]
	ldr	x11, [sp, #1096]                ; 8-byte Folded Reload
	strb	w12, [sp, #3821]
	ldr	w12, [sp, #348]                 ; 4-byte Folded Reload
	str	x11, [sp, #3504]
	ldr	x11, [sp, #1104]                ; 8-byte Folded Reload
	strb	w12, [sp, #3833]
	ldr	w12, [sp, #4064]
	str	x11, [sp, #3512]
	add	x11, sp, #79
	ldrb	w11, [x11, #4095]
	str	w12, [x7]
	ldr	w12, [sp, #352]                 ; 4-byte Folded Reload
	str	w25, [sp, #3680]
	ldr	x25, [sp, #16]                  ; 8-byte Folded Reload
	strb	w11, [x1, #2]
	ldr	w11, [sp, #1152]                ; 4-byte Folded Reload
	strb	w12, [sp, #3904]
	ldrh	w12, [sp, #4060]
	str	w11, [sp, #3524]
	ldr	w11, [sp, #1164]                ; 4-byte Folded Reload
	strh	w12, [x21]
	ldr	w12, [sp, #360]                 ; 4-byte Folded Reload
	str	w11, [sp, #3528]
	ldr	w11, [sp, #308]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3917]
	ldr	w12, [sp, #364]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3532]
	ldr	w11, [sp, #320]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3928]
	ldr	w12, [sp, #4052]
	strb	w11, [sp, #3533]
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
	str	w12, [x24]
	ldr	x12, [sp, #1216]                ; 8-byte Folded Reload
	strh	w11, [sp, #3534]
	ldr	w11, [sp, #1136]                ; 4-byte Folded Reload
	str	x13, [sp, #3688]
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	str	w11, [sp, #3536]
	ldr	w11, [sp, #1148]                ; 4-byte Folded Reload
	str	x12, [sp, #3992]
	ldrh	w12, [sp, #4048]
	str	w11, [sp, #3540]
	ldr	w11, [sp, #300]                 ; 4-byte Folded Reload
	strb	w13, [sp, #3929]
	ldr	w13, [sp, #372]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3544]
	ldrh	w11, [sp, #4168]
	strh	w12, [x25]
	ldr	w12, [sp, #376]                 ; 4-byte Folded Reload
	strh	w11, [x0, #4]
	ldr	w11, [sp, #1384]                ; 4-byte Folded Reload
	strb	w13, [sp, #4000]
	ldr	w13, [sp, #392]                 ; 4-byte Folded Reload
	str	w11, [sp, #3552]
	ldr	w11, [sp, #196]                 ; 4-byte Folded Reload
	strb	w12, [sp, #4012]
	ldr	w12, [sp, #380]                 ; 4-byte Folded Reload
	str	w11, [sp, #3556]
	ldr	x11, [sp, #1064]                ; 8-byte Folded Reload
	strh	w20, [sp, #3438]
	mov	w20, #96                        ; =0x60
	str	x11, [sp, #3560]
	ldr	x11, [sp, #1072]                ; 8-byte Folded Reload
	strb	w13, [sp, #4025]
	add	x13, sp, #3264
	umaddl	x13, w19, w20, x13
	str	x11, [sp, #3568]
	ldr	x11, [sp, #1080]                ; 8-byte Folded Reload
	strb	w12, [sp, #4013]
	ldr	w12, [sp, #384]                 ; 4-byte Folded Reload
	ldr	x19, [sp, #8]                   ; 8-byte Folded Reload
	str	x11, [sp, #3576]
	ldr	w11, [sp, #288]                 ; 4-byte Folded Reload
	strb	w12, [sp, #4024]
	ldr	w12, [sp, #4040]
	str	w11, [sp, #3584]
	ldr	w11, [sp, #200]                 ; 4-byte Folded Reload
	str	w12, [x19]
	mov	x12, x7
	str	w11, [sp, #3588]
	ldr	x11, [sp, #1040]                ; 8-byte Folded Reload
	str	w26, [sp, #3684]
	str	x11, [sp, #3592]
	ldr	x11, [sp, #1048]                ; 8-byte Folded Reload
	str	x11, [sp, #3600]
	ldr	x11, [sp, #1056]                ; 8-byte Folded Reload
	str	x11, [sp, #3608]
	ldrb	w11, [sp, #4038]
	strb	w11, [x17, #2]
	ldr	w11, [sp, #168]                 ; 4-byte Folded Reload
	str	w11, [sp, #3620]
	ldr	w11, [sp, #164]                 ; 4-byte Folded Reload
	str	w11, [sp, #3624]
	ldr	w11, [sp, #824]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3630]
	ldr	w11, [sp, #960]                 ; 4-byte Folded Reload
	str	w11, [sp, #3632]
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	str	w11, [sp, #3636]
	ldrh	w11, [sp, #4092]
	strh	w11, [x16, #4]
	ldr	w11, [sp, #956]                 ; 4-byte Folded Reload
	str	w11, [sp, #3648]
	ldr	x11, [sp, #1440]                ; 8-byte Folded Reload
	str	x11, [sp, #3656]
	ldr	x11, [sp, #1464]                ; 8-byte Folded Reload
	str	x11, [sp, #3664]
	ldr	x11, [sp, #1456]                ; 8-byte Folded Reload
	str	x11, [sp, #3672]
	ldrb	w11, [sp, #4086]
	strb	w11, [x15, #2]
	ldr	w11, [sp, #840]                 ; 4-byte Folded Reload
	str	w11, [sp, #3716]
	ldr	w11, [sp, #836]                 ; 4-byte Folded Reload
	str	w11, [sp, #3720]
	ldr	w11, [sp, #864]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3724]
	ldrh	w11, [sp, #4082]
	strh	w11, [sp, #3726]
	ldr	w11, [sp, #952]                 ; 4-byte Folded Reload
	str	w11, [sp, #3728]
	ldr	w11, [sp, #948]                 ; 4-byte Folded Reload
	str	w11, [sp, #3732]
	ldr	w11, [sp, #856]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3736]
	ldrh	w11, [sp, #4080]
	strh	w11, [x14, #4]
	ldr	w11, [sp, #964]                 ; 4-byte Folded Reload
	str	w11, [sp, #3744]
	ldr	w11, [sp, #820]                 ; 4-byte Folded Reload
	str	w11, [sp, #3748]
	ldr	x11, [sp, #936]                 ; 8-byte Folded Reload
	str	x11, [sp, #3752]
	ldr	x11, [sp, #928]                 ; 8-byte Folded Reload
	str	x11, [sp, #3760]
	ldr	x11, [sp, #920]                 ; 8-byte Folded Reload
	str	x11, [sp, #3768]
	ldr	w11, [sp, #832]                 ; 4-byte Folded Reload
	str	w11, [sp, #3776]
	ldr	w11, [sp, #816]                 ; 4-byte Folded Reload
	str	w11, [sp, #3780]
	ldr	x11, [sp, #912]                 ; 8-byte Folded Reload
	str	x11, [sp, #3784]
	ldr	x11, [sp, #904]                 ; 8-byte Folded Reload
	str	x11, [sp, #3792]
	ldr	x11, [sp, #888]                 ; 8-byte Folded Reload
	str	x11, [sp, #3800]
	ldrb	w11, [sp, #4074]
	strb	w11, [x6, #2]
	ldr	w11, [sp, #900]                 ; 4-byte Folded Reload
	str	w11, [sp, #3812]
	ldr	w11, [sp, #884]                 ; 4-byte Folded Reload
	str	w11, [sp, #3816]
	ldr	w11, [sp, #844]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3820]
	ldrh	w11, [sp, #4070]
	strh	w11, [sp, #3822]
	ldr	w11, [sp, #880]                 ; 4-byte Folded Reload
	str	w11, [sp, #3824]
	ldr	w11, [sp, #876]                 ; 4-byte Folded Reload
	str	w11, [sp, #3828]
	ldr	w11, [sp, #344]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3832]
	ldrh	w11, [sp, #4068]
	strh	w11, [x7, #4]
	ldr	w11, [sp, #1416]                ; 4-byte Folded Reload
	str	w11, [sp, #3840]
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	str	w11, [sp, #3844]
	ldr	x11, [sp, #1008]                ; 8-byte Folded Reload
	str	x11, [sp, #3848]
	ldr	x11, [sp, #1016]                ; 8-byte Folded Reload
	str	x11, [sp, #3856]
	ldr	x11, [sp, #1024]                ; 8-byte Folded Reload
	str	x11, [sp, #3864]
	ldr	w11, [sp, #280]                 ; 4-byte Folded Reload
	str	w11, [sp, #3872]
	ldr	w11, [sp, #184]                 ; 4-byte Folded Reload
	str	w11, [sp, #3876]
	ldr	x11, [sp, #984]                 ; 8-byte Folded Reload
	str	x11, [sp, #3880]
	ldr	x11, [sp, #992]                 ; 8-byte Folded Reload
	str	x11, [sp, #3888]
	ldr	x11, [sp, #1000]                ; 8-byte Folded Reload
	str	x11, [sp, #3896]
	ldrb	w11, [sp, #4062]
	strb	w11, [x21, #2]
	ldr	w11, [sp, #1032]                ; 4-byte Folded Reload
	str	w11, [sp, #3908]
	ldr	w11, [sp, #1036]                ; 4-byte Folded Reload
	str	w11, [sp, #3912]
	ldr	w11, [sp, #356]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3916]
	ldrh	w11, [sp, #4058]
	strh	w11, [sp, #3918]
	ldr	w11, [sp, #1296]                ; 4-byte Folded Reload
	str	w11, [sp, #3920]
	ldr	w11, [sp, #1300]                ; 4-byte Folded Reload
	str	w11, [sp, #3924]
	ldrh	w11, [sp, #4056]
	strh	w11, [x24, #4]
	ldr	w11, [sp, #1436]                ; 4-byte Folded Reload
	str	w11, [sp, #3936]
	ldr	w11, [sp, #188]                 ; 4-byte Folded Reload
	str	w11, [sp, #3940]
	ldr	x11, [sp, #1184]                ; 8-byte Folded Reload
	str	x11, [sp, #3944]
	ldr	x11, [sp, #1192]                ; 8-byte Folded Reload
	str	x11, [sp, #3952]
	ldr	x11, [sp, #1200]                ; 8-byte Folded Reload
	str	x11, [sp, #3960]
	ldr	w11, [sp, #284]                 ; 4-byte Folded Reload
	str	w11, [sp, #3968]
	ldr	w11, [sp, #192]                 ; 4-byte Folded Reload
	strb	wzr, [x13, #64]
	str	w11, [sp, #3972]
	ldr	x11, [sp, #1168]                ; 8-byte Folded Reload
	str	x11, [sp, #3976]
	ldr	x11, [sp, #1176]                ; 8-byte Folded Reload
	str	x11, [sp, #3984]
	ldrb	w11, [sp, #4050]
	strb	w11, [x25, #2]
	ldr	w11, [sp, #1264]                ; 4-byte Folded Reload
	str	wzr, [x13]
	str	w11, [sp, #4004]
	ldr	w11, [sp, #1276]                ; 4-byte Folded Reload
	str	wzr, [x13, #32]
	str	w11, [sp, #4008]
	ldrh	w11, [sp, #4046]
	strh	wzr, [x13, #76]
	strh	w11, [sp, #4014]
	ldr	w11, [sp, #1292]                ; 4-byte Folded Reload
	stur	xzr, [x13, #68]
	str	w11, [sp, #4016]
	ldr	w11, [sp, #1280]                ; 4-byte Folded Reload
	str	w11, [sp, #4020]
	ldrh	w11, [sp, #4044]
	stp	x10, x9, [x13, #40]
	ldr	w10, [sp, #3264]
	strh	w11, [x19, #4]
	ldr	x11, [sp, #1376]                ; 8-byte Folded Reload
	str	x8, [x13, #56]
	ldr	w8, [sp, #3296]
	str	w10, [sp, #1424]                ; 4-byte Folded Spill
	ldr	w10, [sp, #3268]
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3300]
	stp	x27, x28, [x13, #8]
	stp	w8, w10, [sp, #220]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3304]
	ldr	x9, [sp, #3280]
	str	x11, [x13, #24]
	ldr	x11, [sp, #3272]
	ldrh	w10, [sp, #3342]
	str	x8, [sp, #1360]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3312]
	ldrh	w20, [sp, #3438]
	strh	wzr, [x13, #88]
	ldrh	w26, [sp, #3630]
	ldrh	w27, [sp, #3726]
	str	x8, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3320]
	ldrh	w28, [sp, #3822]
	str	xzr, [x13, #80]
	ldrh	w22, [sp, #3918]
	ldrh	w23, [sp, #4014]
	str	x8, [sp, #1344]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3328]
	mov	x13, x6
	stp	x9, x11, [sp, #256]             ; 16-byte Folded Spill
	ldr	x11, [sp, #3376]
	ldr	x9, [sp, #3288]
	str	w8, [sp, #976]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3332]
	mov	w7, w10
	str	x9, [sp, #1368]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #3364]
	mov	x10, x24
	str	w8, [sp, #1336]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3336]
	str	w8, [sp, #1332]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3340]
	str	w8, [sp, #968]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3341]
	str	w8, [sp, #700]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3344]
	str	w8, [sp, #1320]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3348]
	str	w8, [sp, #1312]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3352]
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3353]
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3360]
	str	w8, [sp, #1472]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3368]
	str	x8, [sp, #1304]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3384]
	stp	x8, x11, [sp, #240]             ; 16-byte Folded Spill
	ldr	w8, [sp, #3392]
	ldrh	w11, [sp, #3534]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3396]
	stp	w8, w9, [sp, #212]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3400]
	ldr	w9, [sp, #3460]
	str	x8, [sp, #1224]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3408]
	str	x8, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3416]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3424]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3428]
	str	w8, [sp, #1248]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3432]
	str	w8, [sp, #1260]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3436]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3437]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3440]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3444]
	str	w8, [sp, #1244]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3448]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3449]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3456]
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3464]
	str	x8, [sp, #1112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3472]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3480]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3488]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3492]
	stp	w9, w8, [sp, #204]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3496]
	ldr	w9, [sp, #3556]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3504]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3512]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3520]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3524]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3528]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3532]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3533]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3536]
	str	w8, [sp, #1136]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3540]
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3544]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3545]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3552]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3560]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3568]
	str	x8, [sp, #1072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3576]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3584]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3588]
	stp	w9, w8, [sp, #196]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3592]
	ldr	w9, [sp, #3620]
	str	x8, [sp, #1040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3600]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3608]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3616]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3624]
	stp	w8, w9, [sp, #164]              ; 8-byte Folded Spill
	ldrb	w8, [sp, #3628]
	ldr	w9, [sp, #3844]
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3629]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3632]
	str	w8, [sp, #960]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3636]
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3640]
	str	w8, [sp, #776]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3641]
	str	w8, [sp, #780]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3648]
	str	w8, [sp, #956]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3652]
	str	w8, [sp, #768]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3656]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3664]
	str	x8, [sp, #1464]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3672]
	str	x8, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3680]
	str	w8, [sp, #772]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3684]
	str	w8, [sp, #764]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3688]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3696]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3704]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3712]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3716]
	str	w8, [sp, #840]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3720]
	str	w8, [sp, #836]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3724]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3725]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3728]
	str	w8, [sp, #952]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3732]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3736]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3737]
	str	w8, [sp, #860]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3744]
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3748]
	str	w8, [sp, #820]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3752]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3760]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3768]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3776]
	str	w8, [sp, #832]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3780]
	str	w8, [sp, #816]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3784]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3792]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3800]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3808]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3812]
	str	w8, [sp, #900]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3816]
	str	w8, [sp, #884]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3820]
	str	w8, [sp, #844]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3821]
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3824]
	str	w8, [sp, #880]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3828]
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3832]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3833]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3840]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3848]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3856]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3864]
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3872]
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3876]
	stp	w9, w8, [sp, #180]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3880]
	ldr	w9, [sp, #3940]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3888]
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3896]
	str	x8, [sp, #1000]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3904]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3908]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3912]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3916]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3917]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3920]
	str	w8, [sp, #1296]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3924]
	str	w8, [sp, #1300]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3928]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3929]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3936]
	str	w8, [sp, #1436]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3944]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3952]
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3960]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3968]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3972]
	stp	w9, w8, [sp, #188]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3976]
	mov	x9, x19
	mov	w19, w11
	mov	x11, x21
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3984]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3992]
	str	x8, [sp, #1216]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #4000]
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4004]
	str	w8, [sp, #1264]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4008]
	str	w8, [sp, #1276]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #4012]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #4013]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4016]
	str	w8, [sp, #1292]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4020]
	str	w8, [sp, #1280]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #4024]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #4025]
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	mov	x8, x25
LBB14_63:                               ; %b56_to_b57.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldrh	w6, [x5]
	ldrb	w5, [x5, #2]
	strh	w7, [sp, #3258]
	ldr	w7, [x4]
	ldr	w24, [x9]
	ldrh	w21, [x9, #4]
	add	x9, sp, #3198
	strb	w5, [sp, #3262]
	ldrh	w5, [x3]
	ldrb	w3, [x3, #2]
	ldrh	w4, [x4, #4]
	str	w30, [sp, #1376]                ; 4-byte Folded Spill
	add	x30, sp, #3186
	strh	w6, [sp, #3260]
	add	x6, sp, #3236
	strb	w3, [sp, #3250]
	ldr	w3, [x2]
	ldrh	w2, [x2, #4]
	str	w7, [sp, #3252]
	add	x7, sp, #3176
	str	w3, [sp, #3240]
	ldrb	w3, [x1, #2]
	ldrh	w1, [x1]
	strh	w2, [sp, #3244]
	ldrh	w2, [x8]
	strh	w1, [sp, #3236]
	ldrh	w1, [x0, #4]
	ldr	w0, [x0]
	strh	w5, [sp, #3248]
	add	x5, sp, #3168
	strh	w1, [sp, #3232]
	ldrb	w1, [x17, #2]
	ldrh	w17, [x17]
	strh	w20, [sp, #3246]
	add	x20, sp, #3246
	strh	w17, [sp, #3224]
	ldrh	w17, [x16, #4]
	ldr	w16, [x16]
	strb	w3, [sp, #3238]
	add	x3, sp, #3234
	strh	w17, [sp, #3220]
	ldrb	w17, [x15, #2]
	ldrh	w15, [x15]
	str	w16, [sp, #3216]
	ldrh	w16, [x14, #4]
	ldr	w14, [x14]
	strh	w15, [sp, #3212]
	ldrh	w15, [x13]
	ldrb	w13, [x13, #2]
	str	w14, [sp, #3204]
	mov	w14, #1                         ; =0x1
	strb	w17, [sp, #3214]
	ldrb	w17, [x8, #2]
	add	x8, sp, #3188
	strh	w16, [sp, #3208]
	ldr	w16, [x12]
	ldrh	w12, [x12, #4]
	str	w14, [sp, #160]                 ; 4-byte Folded Spill
	ldrh	w14, [x11]
	ldrb	w11, [x11, #2]
	strh	w15, [sp, #3200]
	ldr	w15, [x10]
	ldrh	w10, [x10, #4]
	strh	w19, [sp, #3234]
	add	x19, sp, #3240
	str	w0, [sp, #3228]
	add	x0, sp, #3180
	strb	w1, [sp, #3226]
	add	x1, sp, #3224
	strb	w13, [sp, #3202]
	add	x13, sp, #3174
	strh	w12, [sp, #3196]
	add	x12, sp, #3192
	str	w16, [sp, #3192]
	add	x16, sp, #3212
	strb	w11, [sp, #3190]
	add	x11, sp, #3200
	strh	w14, [sp, #3188]
	add	x14, sp, #3210
	strh	w22, [sp, #3186]
	add	x22, sp, #3252
	strh	w10, [sp, #3184]
	add	x10, sp, #3204
	str	w15, [sp, #3180]
	add	x15, sp, #3216
	strb	w17, [sp, #3178]
	add	x17, sp, #3222
	strh	w2, [sp, #3176]
	add	x2, sp, #3228
	strh	w23, [sp, #3174]
	add	x23, sp, #3258
	strh	w21, [sp, #3172]
	add	x21, sp, #3248
	str	w24, [sp, #3168]
	add	x24, sp, #3260
	strh	w4, [sp, #3256]
	strh	w26, [sp, #3222]
	strh	w27, [sp, #3210]
	str	x13, [sp, #824]                 ; 8-byte Folded Spill
	strh	w28, [sp, #3198]
	b	LBB14_79
LBB14_64:                               ; %b31.i.i106.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #10                        ; =0xa
	b	LBB14_75
LBB14_65:                               ; %b4.i.i118.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #1                         ; =0x1
	b	LBB14_75
LBB14_66:                               ; %b13.i.i115.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #4                         ; =0x4
	b	LBB14_75
LBB14_67:                               ; %b34.i.i113.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #11                        ; =0xb
	b	LBB14_75
LBB14_68:                               ; %b16.i.i114.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #5                         ; =0x5
	b	LBB14_75
LBB14_69:                               ; %b22.i.i112.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #7                         ; =0x7
	b	LBB14_75
LBB14_70:                               ; %b7.i.i117.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #2                         ; =0x2
	b	LBB14_75
LBB14_71:                               ; %b10.i.i116.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #3                         ; =0x3
	b	LBB14_75
LBB14_72:                               ; %b28.i.i110.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #9                         ; =0x9
	b	LBB14_75
LBB14_73:                               ; %b25.i.i111.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #8                         ; =0x8
	b	LBB14_75
LBB14_74:                               ; %b36.i.i120.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #6                         ; =0x6
LBB14_75:                               ; %liza___liza_reactor_error.exit.i107.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	x27, xzr
	mov	x28, xzr
	mov	x9, xzr
	mov	w8, #1                          ; =0x1
	cmp	w8, #1
	b.ne	LBB14_55
LBB14_76:                               ; %b45.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	w26, #1                         ; =0x1
	add	x5, sp, #1, lsl #12             ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	lsl	w25, w26, w25
	add	x0, sp, #1, lsl #12             ; =4096
	add	x8, sp, #1, lsl #12             ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x21, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	mov	w26, #3827                      ; =0xef3
	add	x5, x5, #8
	add	x7, x7, #16
	add	x0, x0, #20
	add	x30, sp, #4058
	add	x8, x8, #28
	add	x12, x12, #32
	add	x9, sp, #4070
	add	x11, x11, #40
	add	x10, x10, #44
	add	x14, sp, #4082
	add	x16, x16, #52
	add	x15, x15, #56
	add	x17, sp, #1, lsl #12            ; =4096
	add	x1, x1, #64
	add	x2, x2, #68
	add	x3, x3, #2
	add	x6, x6, #76
	add	x19, x19, #80
	add	x20, x20, #4
	add	x21, x21, #88
	add	x22, x22, #92
	add	x23, x23, #6
	add	x24, x24, #100
	tst	w25, w26
	b.eq	LBB14_78
; %bb.77:                               ;   in Loop: Header=BB14_30 Depth=1
	mov	w25, #3                         ; =0x3
	add	x13, sp, #4046
	str	wzr, [sp, #1376]                ; 4-byte Folded Spill
	str	w25, [sp, #696]                 ; 4-byte Folded Spill
	str	x13, [sp, #824]                 ; 8-byte Folded Spill
	b	LBB14_79
LBB14_78:                               ;   in Loop: Header=BB14_30 Depth=1
	mov	w8, #1                          ; =0x1
	add	x5, sp, #1, lsl #12             ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	str	w8, [sp, #1376]                 ; 4-byte Folded Spill
	add	x8, sp, #4046
	add	x0, sp, #1, lsl #12             ; =4096
	str	x8, [sp, #824]                  ; 8-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x21, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x5, x5, #8
	add	x7, x7, #16
	add	x0, x0, #20
	add	x8, x8, #28
	add	x12, x12, #32
	add	x11, x11, #40
	add	x10, x10, #44
	add	x16, x16, #52
	add	x15, x15, #56
	add	x1, x1, #64
	add	x2, x2, #68
	add	x3, x3, #2
	add	x6, x6, #76
	add	x19, x19, #80
	add	x20, x20, #4
	add	x21, x21, #88
	add	x22, x22, #92
	add	x23, x23, #6
	add	x24, x24, #100
LBB14_79:                               ; %b57_to_b58.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldrh	w20, [x20]
	ldrh	w9, [x9]
	add	x13, sp, #3078
	ldrh	w23, [x23]
	ldrh	w3, [x3]
	add	x28, sp, #3090
	strh	w20, [sp, #3150]
	ldrh	w20, [x6]
	add	x26, sp, #3092
	ldrb	w6, [x6, #2]
	strh	w9, [sp, #3102]
	add	x4, sp, #3114
	ldr	w9, [x12]
	ldrh	w25, [x24]
	add	x27, sp, #3126
	strb	w6, [sp, #3142]
	ldrh	w6, [x2, #4]
	ldr	w2, [x2]
	str	w9, [sp, #3096]
	ldrh	w9, [x30]
	add	x30, sp, #3128
	str	w2, [sp, #3132]
	ldrh	w2, [x16]
	ldrh	w17, [x17]
	strh	w9, [sp, #3090]
	ldr	w9, [x0]
	ldrh	w14, [x14]
	strh	w2, [sp, #3116]
	ldrh	w2, [x10, #4]
	ldr	w10, [x10]
	strh	w23, [sp, #3162]
	ldrh	w23, [x21]
	ldrb	w21, [x21, #2]
	str	w10, [sp, #3108]
	ldrh	w10, [x11]
	ldrb	w24, [x24, #2]
	strh	w3, [sp, #3138]
	ldrb	w3, [x1, #2]
	ldrh	w1, [x1]
	strh	w10, [sp, #3104]
	ldrh	w10, [x12, #4]
	str	w9, [sp, #3084]
	ldr	x9, [sp, #824]                  ; 8-byte Folded Reload
	strh	w10, [sp, #3100]
	ldrb	w10, [x8, #2]
	ldrh	w8, [x8]
	strh	w25, [sp, #3164]
	ldr	w25, [x22]
	ldrh	w22, [x22, #4]
	strb	w10, [sp, #3094]
	ldrh	w10, [x0, #4]
	add	x0, sp, #3150
	strb	w21, [sp, #3154]
	ldr	w21, [x19]
	ldrh	w19, [x19, #4]
	strh	w1, [sp, #3128]
	ldrh	w1, [x15, #4]
	ldrh	w12, [x9]
	add	x9, sp, #3144
	strh	w17, [sp, #3126]
	ldr	w17, [x15]
	add	x15, sp, #3072
	strh	w14, [sp, #3114]
	ldrb	w14, [x11, #2]
	strh	w10, [sp, #3088]
	ldrb	w10, [x7, #2]
	ldrh	w11, [x7]
	add	x7, sp, #3140
	str	w25, [sp, #3156]
	ldr	x25, [sp, #576]                 ; 8-byte Folded Reload
	strh	w22, [sp, #3160]
	ldr	x22, [sp, #752]                 ; 8-byte Folded Reload
	strh	w23, [sp, #3152]
	ldr	x23, [sp, #1464]                ; 8-byte Folded Reload
	strh	w19, [sp, #3148]
	ldrh	w19, [x5, #4]
	strh	w20, [sp, #3140]
	ldr	w20, [x5]
	add	x5, sp, #3162
	strh	w1, [sp, #3124]
	ldrb	w1, [x16, #2]
	add	x16, sp, #3080
	strb	w24, [sp, #3166]
	add	x24, sp, #3138
	str	w21, [sp, #3144]
	add	x21, sp, #3120
	strh	w6, [sp, #3136]
	add	x6, sp, #3108
	strb	w3, [sp, #3130]
	add	x3, sp, #3104
	str	x13, [sp, #232]                 ; 8-byte Folded Spill
	add	x13, sp, #3102
	str	w17, [sp, #3120]
	add	x17, sp, #3084
	strh	w2, [sp, #3112]
	add	x2, sp, #3096
	strb	w14, [sp, #3106]
	add	x14, sp, #3116
	strh	w8, [sp, #3092]
	add	x8, sp, #3132
	strb	w10, [sp, #3082]
	add	x10, sp, #3152
	strh	w11, [sp, #3080]
	add	x11, sp, #3156
	strh	w12, [sp, #3078]
	add	x12, sp, #3164
	strb	w1, [sp, #3118]
	strh	w19, [sp, #3076]
	str	w20, [sp, #3072]
LBB14_80:                               ; %b58_to_b59.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	w1, [sp, #1424]                 ; 4-byte Folded Reload
	ldrh	w19, [x12]
	ldrb	w12, [x12, #2]
	ldr	x20, [sp, #680]                 ; 8-byte Folded Reload
	str	x23, [sp, #2704]
	str	w1, [sp, #2304]
	ldr	x1, [sp, #656]                  ; 8-byte Folded Reload
	strh	w19, [x1]
	ldr	w19, [x11]
	ldrh	w11, [x11, #4]
	strb	w12, [x1, #2]
	ldrb	w12, [x10, #2]
	ldrh	w10, [x10]
	str	w19, [x20]
	ldr	x19, [sp, #648]                 ; 8-byte Folded Reload
	strh	w11, [x20, #4]
	mov	x20, x25
	ldr	w11, [x9]
	strb	w12, [x19, #2]
	mov	x12, x19
	ldrh	w9, [x9, #4]
	strh	w10, [x19]
	ldr	x19, [sp, #672]                 ; 8-byte Folded Reload
	ldrh	w10, [x7]
	str	w11, [x19]
	ldr	x11, [sp, #664]                 ; 8-byte Folded Reload
	strh	w9, [x19, #4]
	ldr	x19, [sp, #640]                 ; 8-byte Folded Reload
	ldrb	w9, [x7, #2]
	ldr	w7, [sp, #1452]                 ; 4-byte Folded Reload
	strh	w10, [x19]
	ldr	w10, [x8]
	ldrh	w8, [x8, #4]
	strb	w9, [x19, #2]
	ldrb	w9, [x30, #2]
	strh	w8, [x11, #4]
	ldrh	w8, [x30]
	strb	w9, [x25, #2]
	ldrh	w9, [x21, #4]
	strh	w8, [x25]
	ldr	w8, [x21]
	strh	w9, [x22, #4]
	ldrb	w9, [x14, #2]
	str	w8, [x22]
	ldrh	w8, [x14]
	ldr	x22, [sp, #1440]                ; 8-byte Folded Reload
	strb	w9, [sp, #2302]
	ldrh	w9, [x6, #4]
	strh	w8, [sp, #2300]
	ldr	w8, [x6]
	strh	w9, [sp, #2296]
	ldrb	w9, [x3, #2]
	str	w8, [sp, #2292]
	ldrh	w8, [x3]
	ldr	x3, [sp, #592]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2290]
	ldrh	w9, [x2, #4]
	strh	w8, [sp, #2288]
	ldr	w8, [x2]
	ldr	x2, [sp, #600]                  ; 8-byte Folded Reload
	strh	w9, [sp, #2284]
	ldrb	w9, [x26, #2]
	str	w8, [sp, #2280]
	ldrh	w8, [x26]
	strb	w9, [sp, #2278]
	ldrh	w9, [x17, #4]
	strh	w8, [sp, #2276]
	ldr	w8, [x17]
	strh	w9, [sp, #2272]
	ldrb	w9, [x16, #2]
	str	w8, [sp, #2268]
	ldrh	w8, [x16]
	ldrh	w16, [x4]
	strb	w9, [sp, #2266]
	ldrh	w9, [x15, #4]
	strh	w8, [sp, #2264]
	ldr	w8, [x15]
	ldr	x15, [sp, #744]                 ; 8-byte Folded Reload
	strh	w9, [sp, #2260]
	str	w8, [sp, #2256]
	ldr	w8, [sp, #224]                  ; 4-byte Folded Reload
	str	w10, [x11]
	ldr	x10, [sp, #632]                 ; 8-byte Folded Reload
	str	w8, [sp, #2308]
	ldp	x8, x9, [sp, #256]              ; 16-byte Folded Reload
	mov	x30, x10
	str	w7, [sp, #2676]
	str	x22, [sp, #2696]
	str	x8, [sp, #2320]
	ldr	x8, [sp, #1368]                 ; 8-byte Folded Reload
	str	x9, [sp, #2312]
	ldr	w9, [sp, #700]                  ; 4-byte Folded Reload
	str	x8, [sp, #2328]
	ldr	w8, [sp, #276]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2381]
	str	w8, [sp, #2336]
	ldr	w8, [sp, #220]                  ; 4-byte Folded Reload
	strh	w16, [sp, #2766]
	str	w8, [sp, #2340]
	ldr	x8, [sp, #1360]                 ; 8-byte Folded Reload
	str	x8, [sp, #2344]
	ldr	x8, [sp, #1352]                 ; 8-byte Folded Reload
	str	x8, [sp, #2352]
	ldr	x8, [sp, #1344]                 ; 8-byte Folded Reload
	str	x8, [sp, #2360]
	ldr	w8, [sp, #976]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2368]
	ldr	w8, [sp, #1336]                 ; 4-byte Folded Reload
	str	w8, [sp, #2372]
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	str	w8, [sp, #2376]
	ldr	w8, [sp, #968]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2380]
	ldrh	w8, [x5]
	ldrh	w5, [x13]
	strh	w8, [sp, #2382]
	ldr	w8, [sp, #1320]                 ; 4-byte Folded Reload
	strh	w5, [sp, #2862]
	str	w8, [sp, #2384]
	ldr	w8, [sp, #1312]                 ; 4-byte Folded Reload
	str	w8, [sp, #2388]
	ldr	w8, [sp, #396]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2392]
	ldr	w8, [sp, #388]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2393]
	ldr	w8, [sp, #1472]                 ; 4-byte Folded Reload
	str	w8, [sp, #2400]
	ldr	w8, [sp, #216]                  ; 4-byte Folded Reload
	str	w8, [sp, #2404]
	ldr	x8, [sp, #1304]                 ; 8-byte Folded Reload
	str	x8, [sp, #2408]
	ldp	x8, x9, [sp, #240]              ; 16-byte Folded Reload
	str	x8, [sp, #2424]
	ldr	w8, [sp, #296]                  ; 4-byte Folded Reload
	str	x9, [sp, #2416]
	ldr	w9, [sp, #336]                  ; 4-byte Folded Reload
	str	w8, [sp, #2432]
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2477]
	ldr	w9, [sp, #320]                  ; 4-byte Folded Reload
	str	w8, [sp, #2436]
	ldr	x8, [sp, #1224]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2573]
	ldr	w9, [sp, #340]                  ; 4-byte Folded Reload
	str	x8, [sp, #2440]
	ldr	x8, [sp, #1232]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2656]
	ldrh	w9, [x14]
	str	x8, [sp, #2448]
	ldr	x8, [sp, #1208]                 ; 8-byte Folded Reload
	strh	w9, [x10]
	ldrh	w9, [sp, #2296]
	str	x8, [sp, #2456]
	ldr	w8, [sp, #312]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2464]
	ldr	w8, [sp, #1248]                 ; 4-byte Folded Reload
	str	w8, [sp, #2468]
	ldr	w8, [sp, #1260]                 ; 4-byte Folded Reload
	str	w8, [sp, #2472]
	ldr	w8, [sp, #328]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2476]
	ldrh	w8, [x0]
	ldr	x0, [sp, #624]                  ; 8-byte Folded Reload
	strh	w8, [sp, #2478]
	ldr	w8, [sp, #1240]                 ; 4-byte Folded Reload
	strh	w9, [x0, #4]
	ldrb	w9, [sp, #2290]
	str	w8, [sp, #2480]
	ldr	w8, [sp, #1244]                 ; 4-byte Folded Reload
	str	w8, [sp, #2484]
	ldr	w8, [sp, #316]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2488]
	ldr	w8, [sp, #332]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2489]
	ldr	w8, [sp, #1392]                 ; 4-byte Folded Reload
	str	w8, [sp, #2496]
	ldr	w8, [sp, #204]                  ; 4-byte Folded Reload
	str	w8, [sp, #2500]
	ldr	x8, [sp, #1112]                 ; 8-byte Folded Reload
	str	x8, [sp, #2504]
	ldr	x8, [sp, #1120]                 ; 8-byte Folded Reload
	str	x8, [sp, #2512]
	ldr	x8, [sp, #1128]                 ; 8-byte Folded Reload
	str	x8, [sp, #2520]
	ldr	w8, [sp, #292]                  ; 4-byte Folded Reload
	str	w8, [sp, #2528]
	ldr	w8, [sp, #208]                  ; 4-byte Folded Reload
	str	w8, [sp, #2532]
	ldr	x8, [sp, #1088]                 ; 8-byte Folded Reload
	str	x8, [sp, #2536]
	ldr	x8, [sp, #1096]                 ; 8-byte Folded Reload
	str	x8, [sp, #2544]
	ldr	x8, [sp, #1104]                 ; 8-byte Folded Reload
	str	x8, [sp, #2552]
	ldr	w8, [sp, #304]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2560]
	ldr	w8, [sp, #1152]                 ; 4-byte Folded Reload
	str	w8, [sp, #2564]
	ldr	w8, [sp, #1164]                 ; 4-byte Folded Reload
	str	w8, [sp, #2568]
	ldr	w8, [sp, #308]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2572]
	ldrh	w8, [x24]
	strh	w8, [sp, #2574]
	ldr	w8, [sp, #1136]                 ; 4-byte Folded Reload
	str	w8, [sp, #2576]
	ldr	w8, [sp, #1148]                 ; 4-byte Folded Reload
	str	w8, [sp, #2580]
	ldr	w8, [sp, #300]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2584]
	ldr	w8, [sp, #324]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2585]
	ldr	w8, [sp, #1384]                 ; 4-byte Folded Reload
	str	w8, [sp, #2592]
	ldr	w8, [sp, #196]                  ; 4-byte Folded Reload
	str	w8, [sp, #2596]
	ldr	x8, [sp, #1064]                 ; 8-byte Folded Reload
	str	x8, [sp, #2600]
	ldr	x8, [sp, #1072]                 ; 8-byte Folded Reload
	str	x8, [sp, #2608]
	ldr	x8, [sp, #1080]                 ; 8-byte Folded Reload
	str	x8, [sp, #2616]
	ldr	w8, [sp, #288]                  ; 4-byte Folded Reload
	str	w8, [sp, #2624]
	ldr	w8, [sp, #200]                  ; 4-byte Folded Reload
	str	w8, [sp, #2628]
	ldr	x8, [sp, #1040]                 ; 8-byte Folded Reload
	str	x8, [sp, #2632]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	str	x8, [sp, #2640]
	ldr	x8, [sp, #1056]                 ; 8-byte Folded Reload
	str	x8, [sp, #2648]
	ldrb	w8, [x14, #2]
	ldr	x14, [sp, #736]                 ; 8-byte Folded Reload
	strb	w8, [x10, #2]
	ldr	w8, [sp, #2292]
	ldr	x10, [sp, #616]                 ; 8-byte Folded Reload
	str	w8, [x0]
	ldrh	w8, [sp, #2288]
	mov	x11, x10
	strb	w9, [x10, #2]
	ldr	w9, [sp, #348]                  ; 4-byte Folded Reload
	strh	w8, [x10]
	ldr	w8, [sp, #344]                  ; 4-byte Folded Reload
	ldr	x10, [sp, #608]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2873]
	ldrh	w9, [sp, #2284]
	strb	w8, [sp, #2872]
	ldr	w8, [sp, #2280]
	mov	x17, x10
	strh	w9, [x10, #4]
	ldr	w9, [sp, #352]                  ; 4-byte Folded Reload
	str	w8, [x10]
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2944]
	ldrh	w9, [sp, #2276]
	str	w8, [sp, #2880]
	ldr	w8, [sp, #180]                  ; 4-byte Folded Reload
	strh	w9, [x15]
	str	w8, [sp, #2884]
	ldr	x8, [sp, #1008]                 ; 8-byte Folded Reload
	str	x8, [sp, #2888]
	ldr	x8, [sp, #1016]                 ; 8-byte Folded Reload
	str	x8, [sp, #2896]
	ldr	x8, [sp, #1024]                 ; 8-byte Folded Reload
	str	x8, [sp, #2904]
	ldr	w8, [sp, #280]                  ; 4-byte Folded Reload
	str	w8, [sp, #2912]
	ldr	w8, [sp, #184]                  ; 4-byte Folded Reload
	str	w8, [sp, #2916]
	ldr	x8, [sp, #984]                  ; 8-byte Folded Reload
	str	x8, [sp, #2920]
	ldr	x8, [sp, #992]                  ; 8-byte Folded Reload
	str	x8, [sp, #2928]
	ldr	x8, [sp, #1000]                 ; 8-byte Folded Reload
	str	x8, [sp, #2936]
	ldrb	w8, [sp, #2278]
	strb	w8, [x15, #2]
	ldr	w8, [sp, #1032]                 ; 4-byte Folded Reload
	str	w8, [sp, #2948]
	ldr	w8, [sp, #1036]                 ; 4-byte Folded Reload
	str	w8, [sp, #2952]
	ldp	w8, w9, [sp, #164]              ; 8-byte Folded Reload
	str	w8, [sp, #2664]
	ldr	w8, [sp, #788]                  ; 4-byte Folded Reload
	str	w9, [sp, #2660]
	ldrh	w9, [x27]
	ldr	x27, [sp, #1456]                ; 8-byte Folded Reload
	strb	w8, [sp, #2668]
	ldr	w8, [sp, #784]                  ; 4-byte Folded Reload
	str	w9, [sp, #824]                  ; 4-byte Folded Spill
	strb	w8, [sp, #2669]
	ldr	w8, [sp, #960]                  ; 4-byte Folded Reload
	strh	w9, [sp, #2670]
	ldr	w9, [sp, #356]                  ; 4-byte Folded Reload
	str	w8, [sp, #2672]
	ldr	w8, [sp, #776]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2956]
	ldr	w9, [sp, #360]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2680]
	ldr	w8, [sp, #780]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2957]
	ldr	w9, [sp, #368]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2681]
	ldr	w8, [sp, #956]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2969]
	ldr	w9, [sp, #2268]
	str	w8, [sp, #2688]
	ldr	w8, [sp, #768]                  ; 4-byte Folded Reload
	str	w9, [x14]
	ldr	w9, [sp, #372]                  ; 4-byte Folded Reload
	str	w8, [sp, #2692]
	ldr	w8, [sp, #772]                  ; 4-byte Folded Reload
	strb	w9, [sp, #3040]
	ldrh	w9, [sp, #2264]
	str	w8, [sp, #2720]
	ldr	w8, [sp, #764]                  ; 4-byte Folded Reload
	strh	w9, [x2]
	ldr	w9, [sp, #376]                  ; 4-byte Folded Reload
	str	w8, [sp, #2724]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	strb	w9, [sp, #3052]
	ldr	w9, [sp, #380]                  ; 4-byte Folded Reload
	str	x8, [sp, #2728]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	strb	w9, [sp, #3053]
	ldr	w9, [sp, #392]                  ; 4-byte Folded Reload
	str	x8, [sp, #2736]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	strb	w9, [sp, #3065]
	ldr	w9, [sp, #2256]
	str	x8, [sp, #2744]
	ldr	w8, [sp, #872]                  ; 4-byte Folded Reload
	str	x27, [sp, #2712]
	strb	w8, [sp, #2752]
	ldr	w8, [sp, #840]                  ; 4-byte Folded Reload
	str	w9, [x3]
	str	w8, [sp, #2756]
	ldr	w8, [sp, #836]                  ; 4-byte Folded Reload
	str	w8, [sp, #2760]
	ldr	w8, [sp, #864]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2764]
	ldr	w8, [sp, #868]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2765]
	ldr	w8, [sp, #952]                  ; 4-byte Folded Reload
	str	w8, [sp, #2768]
	ldr	w8, [sp, #948]                  ; 4-byte Folded Reload
	str	w8, [sp, #2772]
	ldr	w8, [sp, #856]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2776]
	ldr	w8, [sp, #860]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2777]
	ldr	w8, [sp, #964]                  ; 4-byte Folded Reload
	str	w8, [sp, #2784]
	ldr	w8, [sp, #820]                  ; 4-byte Folded Reload
	str	w8, [sp, #2788]
	ldr	x8, [sp, #936]                  ; 8-byte Folded Reload
	str	x8, [sp, #2792]
	ldr	x8, [sp, #928]                  ; 8-byte Folded Reload
	str	x8, [sp, #2800]
	ldr	x8, [sp, #920]                  ; 8-byte Folded Reload
	str	x8, [sp, #2808]
	ldr	w8, [sp, #832]                  ; 4-byte Folded Reload
	str	w8, [sp, #2816]
	ldr	w8, [sp, #816]                  ; 4-byte Folded Reload
	str	w8, [sp, #2820]
	ldr	x8, [sp, #912]                  ; 8-byte Folded Reload
	str	x8, [sp, #2824]
	ldr	x8, [sp, #904]                  ; 8-byte Folded Reload
	str	x8, [sp, #2832]
	ldr	x8, [sp, #888]                  ; 8-byte Folded Reload
	str	x8, [sp, #2840]
	ldr	w8, [sp, #852]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2848]
	ldr	w8, [sp, #900]                  ; 4-byte Folded Reload
	str	w8, [sp, #2852]
	ldr	w8, [sp, #884]                  ; 4-byte Folded Reload
	str	w8, [sp, #2856]
	ldr	w8, [sp, #844]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2860]
	ldr	w8, [sp, #848]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2861]
	ldr	w8, [sp, #880]                  ; 4-byte Folded Reload
	str	w8, [sp, #2864]
	ldr	w8, [sp, #876]                  ; 4-byte Folded Reload
	str	w8, [sp, #2868]
	ldrh	w8, [x28]
	strh	w8, [sp, #2958]
	ldr	w8, [sp, #1296]                 ; 4-byte Folded Reload
	str	w8, [sp, #2960]
	ldr	w8, [sp, #1300]                 ; 4-byte Folded Reload
	str	w8, [sp, #2964]
	ldr	w8, [sp, #364]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2968]
	ldrh	w8, [sp, #2272]
	strh	w8, [x14, #4]
	ldr	w8, [sp, #1436]                 ; 4-byte Folded Reload
	str	w8, [sp, #2976]
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	str	w8, [sp, #2980]
	ldr	x8, [sp, #1184]                 ; 8-byte Folded Reload
	str	x8, [sp, #2984]
	ldr	x8, [sp, #1192]                 ; 8-byte Folded Reload
	str	x8, [sp, #2992]
	ldr	x8, [sp, #1200]                 ; 8-byte Folded Reload
	str	x8, [sp, #3000]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	str	w8, [sp, #3008]
	ldr	w8, [sp, #192]                  ; 4-byte Folded Reload
	str	w8, [sp, #3012]
	ldr	x8, [sp, #1168]                 ; 8-byte Folded Reload
	str	x8, [sp, #3016]
	ldr	x8, [sp, #1176]                 ; 8-byte Folded Reload
	str	x8, [sp, #3024]
	ldr	x8, [sp, #1216]                 ; 8-byte Folded Reload
	str	x8, [sp, #3032]
	ldrb	w8, [sp, #2266]
	strb	w8, [x2, #2]
	ldr	w8, [sp, #1264]                 ; 4-byte Folded Reload
	str	w8, [sp, #3044]
	ldr	w8, [sp, #1276]                 ; 4-byte Folded Reload
	str	w8, [sp, #3048]
	ldr	x8, [sp, #232]                  ; 8-byte Folded Reload
	ldrh	w8, [x8]
	strh	w8, [sp, #3054]
	ldr	w8, [sp, #1292]                 ; 4-byte Folded Reload
	str	w8, [sp, #3056]
	ldr	w8, [sp, #1280]                 ; 4-byte Folded Reload
	str	w8, [sp, #3060]
	ldr	w8, [sp, #384]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3064]
	ldrh	w8, [sp, #2260]
	strh	w8, [x3, #4]
	ldr	w8, [sp, #1376]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_28
; %bb.81:                               ; %v132_ok.i.preheader
                                        ;   in Loop: Header=BB14_30 Depth=1
	mov	x25, x20
	ldr	x13, [sp, #584]                 ; 8-byte Folded Reload
	ldr	x21, [sp, #680]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #672]                  ; 8-byte Folded Reload
	ldr	x6, [sp, #664]                  ; 8-byte Folded Reload
	mov	x24, x0
	ldr	x9, [sp, #728]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #720]                 ; 8-byte Folded Reload
	mov	x0, x27
	ldr	x20, [sp, #712]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #704]                 ; 8-byte Folded Reload
	mov	x27, x23
	mov	x28, xzr
	str	xzr, [sp, #1472]                ; 8-byte Folded Spill
	str	wzr, [sp, #1436]                ; 4-byte Folded Spill
LBB14_82:                               ; %v132_ok.i
                                        ;   Parent Loop BB14_30 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x14, [sp, #1472]                ; 8-byte Folded Reload
	add	x8, sp, #2304
	str	x27, [sp, #1464]                ; 8-byte Folded Spill
	str	x28, [sp, #1416]                ; 8-byte Folded Spill
	add	x8, x8, x14
	str	x0, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	w27, [x8]
	cmp	w27, #1
	b.ne	LBB14_84
; %bb.83:                               ; %b66_to_b274.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #2308]
	ldr	x14, [sp, #2328]
	mov	x23, x17
	ldr	x27, [sp, #752]                 ; 8-byte Folded Reload
	ldr	x15, [sp, #744]                 ; 8-byte Folded Reload
	add	x17, sp, #2304
	str	w8, [sp, #700]                  ; 4-byte Folded Spill
	add	x8, sp, #2304
	ldr	d8, [sp, #2336]
	ldur	q0, [x8, #40]
	ldur	q1, [x8, #8]
	mov	x28, x15
	ldur	q4, [x8, #104]
	ldur	q6, [x8, #136]
	mov	x0, x2
	str	q0, [sp, #1392]                 ; 16-byte Folded Spill
	ldur	d0, [x8, #68]
	ldur	d7, [x8, #164]
	ldur	q18, [x8, #200]
	ldur	q20, [x8, #232]
	ldr	x8, [sp, #2552]
	str	x14, [sp, #1280]                ; 8-byte Folded Spill
	ldr	x14, [sp, #2360]
	ldr	d2, [sp, #2384]
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2560]
	ldr	d3, [sp, #2400]
	str	x14, [sp, #1376]                ; 8-byte Folded Spill
	ldrb	w14, [sp, #2368]
	ldr	d5, [sp, #2432]
	str	w8, [sp, #1260]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2572]
	ldr	d16, [sp, #2480]
	str	w14, [sp, #1368]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2380]
	ldr	d17, [sp, #2496]
	str	w8, [sp, #1244]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2573]
	ldr	d19, [sp, #2528]
	str	w14, [sp, #1360]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2381]
	ldr	d21, [x13]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2574]
	ldr	d22, [sp, #2576]
	str	w14, [sp, #1352]                ; 4-byte Folded Spill
	ldrh	w14, [sp, #2382]
	ldr	d23, [sp, #2592]
	str	w8, [sp, #1232]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2584]
	ldur	q24, [x13, #36]
	str	w14, [sp, #1344]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2392]
	ldr	d25, [sp, #2624]
	str	w8, [sp, #1216]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2585]
	ldur	q26, [x13, #68]
	str	w14, [sp, #1336]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2393]
	ldr	d27, [x13, #96]
	str	w8, [sp, #1224]                 ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	ldr	d28, [sp, #2880]
	str	w8, [sp, #1424]                 ; 4-byte Folded Spill
	add	x8, sp, #2304
	ldr	q29, [x9]
	mov	x9, x24
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2616]
	str	w14, [sp, #1332]                ; 4-byte Folded Spill
	ldr	x14, [sp, #2424]
	ldr	d30, [sp, #2912]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2648]
	ldr	q31, [x10]
	mov	x10, x30
	str	x14, [sp, #1320]                ; 8-byte Folded Spill
	ldr	x14, [sp, #2456]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2656]
	ldr	d9, [x13, #384]
	str	x14, [sp, #1312]                ; 8-byte Folded Spill
	ldrb	w14, [sp, #2464]
	ldr	d10, [sp, #2960]
	str	w8, [sp, #1192]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2872]
	ldr	d11, [sp, #2976]
	str	w14, [sp, #1304]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2476]
	ldr	q12, [x20]
	mov	x20, x24
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2873]
	str	w14, [sp, #1300]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2477]
	ldr	d13, [sp, #3008]
	str	w8, [sp, #1064]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2904]
	ldr	q14, [x26]
	str	w14, [sp, #1296]                ; 4-byte Folded Spill
	ldrh	w14, [sp, #2478]
	ldr	d15, [x13, #480]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2936]
	ldr	w24, [sp, #700]                 ; 4-byte Folded Reload
	str	w14, [sp, #1292]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2488]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2944]
	str	w14, [sp, #1176]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2489]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2956]
	str	w14, [sp, #1276]                ; 4-byte Folded Spill
	ldr	x14, [sp, #2520]
	str	w8, [sp, #1096]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2957]
	str	x14, [sp, #1264]                ; 8-byte Folded Spill
	ldrb	w14, [sp, #3052]
	str	w8, [sp, #1072]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2958]
	str	w14, [sp, #1104]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #3053]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2968]
	str	w14, [sp, #1080]                ; 4-byte Folded Spill
	ldrh	w14, [sp, #3054]
	str	w8, [sp, #1056]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2969]
	str	w14, [sp, #1048]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #3064]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3000]
	str	w14, [sp, #1088]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #3065]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3032]
	str	w14, [sp, #1112]                ; 4-byte Folded Spill
	ldr	x14, [sp, #736]                 ; 8-byte Folded Reload
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3040]
	mov	x26, x14
	str	d0, [sp, #1384]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #3056]
	str	x3, [sp, #968]                  ; 8-byte Folded Spill
	str	w7, [sp, #1452]                 ; 4-byte Folded Spill
	mov	x7, x23
	str	x22, [sp, #1440]                ; 8-byte Folded Spill
	mov	x22, x1
	str	x21, [sp, #984]                 ; 8-byte Folded Spill
	str	x12, [sp, #976]                 ; 8-byte Folded Spill
	str	x4, [sp, #1000]                 ; 8-byte Folded Spill
	str	x19, [sp, #992]                 ; 8-byte Folded Spill
	str	x6, [sp, #1008]                 ; 8-byte Folded Spill
	str	x25, [sp, #1016]                ; 8-byte Folded Spill
	str	x27, [sp, #1024]                ; 8-byte Folded Spill
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	mov	x8, x11
	str	w16, [sp, #1148]                ; 4-byte Folded Spill
	b	LBB14_111
LBB14_84:                               ; %b67.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldp	w23, w10, [x8, #68]
	ldp	x21, x2, [x8, #8]
	ldr	w9, [x8, #32]
	ldp	x24, x19, [x8, #40]
	ldr	x12, [x8, #24]
	cmp	w9, #1
	str	w10, [sp, #1464]                ; 4-byte Folded Spill
	ldrb	w10, [x8, #77]
	ldr	x26, [x8, #56]
	ldrb	w20, [x8, #64]
	ldrb	w22, [x8, #76]
	str	w10, [sp, #1456]                ; 4-byte Folded Spill
	ldr	x28, [sp, #688]                 ; 8-byte Folded Reload
	str	w9, [sp, #1368]                 ; 4-byte Folded Spill
	ldp	w11, w10, [x8, #80]
	str	w10, [sp, #1440]                ; 4-byte Folded Spill
	ldrb	w10, [x8, #88]
	ldrb	w8, [x8, #89]
	str	w11, [sp, #1360]                ; 4-byte Folded Spill
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	str	w10, [sp, #1352]                ; 4-byte Folded Spill
	b.ne	LBB14_86
; %bb.85:                               ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #3                          ; =0x3
	str	w22, [sp, #1392]                ; 4-byte Folded Spill
	ldr	w22, [sp, #1368]                ; 4-byte Folded Reload
	str	wzr, [sp, #1424]                ; 4-byte Folded Spill
	mov	x28, x2
	mov	x25, x19
	str	w8, [sp, #696]                  ; 4-byte Folded Spill
	mov	w19, w20
	str	w23, [sp, #1384]                ; 4-byte Folded Spill
	mov	x23, x12
	b	LBB14_110
LBB14_86:                               ; %b70.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	x0, x28
	mov	x1, x21
	mov	x3, x12
	mov	x25, x24
	str	x21, [sp, #1336]                ; 8-byte Folded Spill
	mov	x24, x12
	str	x2, [sp, #1424]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	str	x24, [sp, #1344]                ; 8-byte Folded Spill
	str	x26, [sp, #1376]                ; 8-byte Folded Spill
	cbnz	x8, LBB14_88
; %bb.87:                               ; %b1.i.i199.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	x21, x0
	mov	w26, wzr
	b	LBB14_91
LBB14_88:                               ; %v8_ok.i.i181.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB14_90
; %bb.89:                               ; %v8_ok.i.i181.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh42:
	adrp	x11, lJTI14_4@PAGE
Lloh43:
	add	x11, x11, lJTI14_4@PAGEOFF
	adr	x9, LBB14_90
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB14_90:                               ; %liza___liza_reactor_error.exit.i.i185.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w21, wzr
	mov	w26, #1                         ; =0x1
LBB14_91:                               ; %liza_net.reactor_ready.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w26, #1
	mov	w8, #3                          ; =0x3
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	csel	w8, wzr, w8, ne
	mov	x0, x28
	mov	x1, x25
	mov	x2, x19
	mov	x24, x25
	str	w8, [sp, #1320]                 ; 4-byte Folded Spill
	mov	x25, x19
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	cbz	x8, LBB14_95
; %bb.92:                               ; %v8_ok.i.i207.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB14_94
; %bb.93:                               ; %v8_ok.i.i207.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh44:
	adrp	x11, lJTI14_5@PAGE
Lloh45:
	add	x11, x11, lJTI14_5@PAGEOFF
	adr	x9, LBB14_94
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB14_94:                               ; %liza___liza_reactor_error.exit.i.i211.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB14_95:                               ; %liza_net.reactor_ready.exit228.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w8, #1
	b.ne	LBB14_99
LBB14_96:                               ;   in Loop: Header=BB14_82 Depth=2
	mov	w22, #3                         ; =0x3
LBB14_97:                               ; %b259.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1424]                 ; 8-byte Folded Reload
	mov	x0, x28
	ldr	x3, [sp, #1344]                 ; 8-byte Folded Reload
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB14_101
; %bb.98:                               ; %b1.i.i891.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	mov	w27, wzr
	b	LBB14_104
LBB14_99:                               ; %b78.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w26, #1
	str	x0, [sp, #1384]                 ; 8-byte Folded Spill
	cset	w8, eq
	str	w22, [sp, #1392]                ; 4-byte Folded Spill
	orr	w8, w8, w20
	tbz	w8, #0, LBB14_113
; %bb.100:                              ; %b91.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w15, [sp, #1464]                ; 4-byte Folded Reload
	mov	w1, w23
	ldr	w23, [sp, #1456]                ; 4-byte Folded Reload
	cmp	w26, #1
	str	w20, [sp, #1332]                ; 4-byte Folded Spill
	b.eq	LBB14_96
	b	LBB14_132
LBB14_101:                              ; %v8_ok.i.i873.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w8, w8, #1
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	cmp	w8, #11
	b.hi	LBB14_103
; %bb.102:                              ; %v8_ok.i.i873.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh46:
	adrp	x11, lJTI14_13@PAGE
Lloh47:
	add	x11, x11, lJTI14_13@PAGEOFF
	adr	x9, LBB14_103
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB14_103:                              ; %liza___liza_reactor_error.exit.i.i877.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w27, #1                         ; =0x1
LBB14_104:                              ; %liza_net.reactor_disconnect.exit894.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB14_106
; %bb.105:                              ; %b1.i.i918.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w12, [sp, #696]                 ; 4-byte Folded Reload
	b	LBB14_109
LBB14_106:                              ; %v8_ok.i.i900.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w8, w8, #1
	ldr	w12, [sp, #696]                 ; 4-byte Folded Reload
	cmp	w8, #11
	b.hi	LBB14_108
; %bb.107:                              ; %v8_ok.i.i900.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh48:
	adrp	x11, lJTI14_14@PAGE
Lloh49:
	add	x11, x11, lJTI14_14@PAGEOFF
	adr	x9, LBB14_108
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB14_108:                              ; %liza___liza_reactor_error.exit.i.i904.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #1                          ; =0x1
LBB14_109:                              ; %liza_net.reactor_disconnect.exit921.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	orr	w8, w8, w27
	ldr	w9, [sp, #404]                  ; 4-byte Folded Reload
	mov	x21, xzr
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	mov	x28, xzr
	csel	w8, w22, w8, eq
	tst	w9, #0x1
	mov	x23, xzr
	csel	w12, w8, w12, ne
	ldr	w8, [sp, #400]                  ; 4-byte Folded Reload
	mov	x24, xzr
	mov	x25, xzr
	mov	x26, xzr
	mov	w19, wzr
	mov	w27, #1                         ; =0x1
	mov	w22, #1                         ; =0x1
	str	wzr, [sp, #1384]                ; 4-byte Folded Spill
	str	wzr, [sp, #1464]                ; 4-byte Folded Spill
	str	wzr, [sp, #1392]                ; 4-byte Folded Spill
	str	wzr, [sp, #1456]                ; 4-byte Folded Spill
	str	wzr, [sp, #1360]                ; 4-byte Folded Spill
	str	wzr, [sp, #1440]                ; 4-byte Folded Spill
	str	wzr, [sp, #1352]                ; 4-byte Folded Spill
	str	wzr, [sp, #1452]                ; 4-byte Folded Spill
	str	w12, [sp, #696]                 ; 4-byte Folded Spill
	str	w8, [sp, #1424]                 ; 4-byte Folded Spill
LBB14_110:                              ; %v554_ok.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	add	x0, sp, #1488
	add	x1, sp, #2304
	mov	w2, #768                        ; =0x300
	add	x20, sp, #1488
	bl	_memcpy
	ldr	x8, [sp, #1472]                 ; 8-byte Folded Reload
	add	x9, sp, #1488
	ldr	w10, [sp, #1384]                ; 4-byte Folded Reload
	str	x9, [sp, #1208]                 ; 8-byte Folded Spill
	and	w9, w19, #0x1
	ldr	x13, [sp, #440]                 ; 8-byte Folded Reload
	add	x8, x20, x8
	ldr	x1, [sp, #656]                  ; 8-byte Folded Reload
	ldr	x12, [sp, #648]                 ; 8-byte Folded Reload
	str	w27, [x8]
	ldr	x4, [sp, #672]                  ; 8-byte Folded Reload
	add	x17, sp, #2304
	stp	x21, x28, [x8, #8]
	ldp	x28, x7, [sp, #472]             ; 16-byte Folded Reload
	str	x23, [x8, #24]
	ldr	x21, [sp, #680]                 ; 8-byte Folded Reload
	ldr	x19, [sp, #640]                 ; 8-byte Folded Reload
	strb	w9, [x8, #64]
	add	x9, sp, #1241
	ldr	x6, [sp, #664]                  ; 8-byte Folded Reload
	ldur	q1, [x9, #255]
	ldr	x9, [sp, #1512]
	str	w22, [x8, #32]
	stp	x24, x25, [x8, #40]
	ldr	w24, [sp, #1492]
	ldr	d8, [sp, #1520]
	str	x9, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #1464]                 ; 4-byte Folded Reload
	ldr	x22, [sp, #568]                 ; 8-byte Folded Reload
	str	x26, [x8, #56]
	ldr	x25, [sp, #576]                 ; 8-byte Folded Reload
	ldr	x27, [sp, #752]                 ; 8-byte Folded Reload
	stp	w10, w9, [x8, #68]
	add	x10, sp, #1273
	ldr	w9, [sp, #1392]                 ; 4-byte Folded Reload
	ldur	q0, [x10, #255]
	ldr	x10, [sp, #1544]
	ldr	x30, [sp, #632]                 ; 8-byte Folded Reload
	and	w9, w9, #0x1
	ldr	x20, [sp, #624]                 ; 8-byte Folded Reload
	ldr	x23, [sp, #608]                 ; 8-byte Folded Reload
	strb	w9, [x8, #76]
	ldr	w9, [sp, #1456]                 ; 4-byte Folded Reload
	ldr	x15, [sp, #744]                 ; 8-byte Folded Reload
	str	q0, [sp, #1392]                 ; 16-byte Folded Spill
	ldr	x14, [sp, #736]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #600]                  ; 8-byte Folded Reload
	and	w9, w9, #0x1
	str	x10, [sp, #1376]                ; 8-byte Folded Spill
	ldr	w10, [sp, #1360]                ; 4-byte Folded Reload
	strb	w9, [x8, #77]
	ldrb	w9, [sp, #1552]
	ldr	x3, [sp, #592]                  ; 8-byte Folded Reload
	ldp	x0, x26, [sp, #456]             ; 16-byte Folded Reload
	str	w9, [sp, #1368]                 ; 4-byte Folded Spill
	add	x9, sp, #1301
	ldur	d0, [x9, #255]
	ldrb	w9, [sp, #1564]
	str	w9, [sp, #1360]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1440]                 ; 4-byte Folded Reload
	str	d0, [sp, #1384]                 ; 8-byte Folded Spill
	stp	w10, w9, [x8, #80]
	ldr	w9, [sp, #1352]                 ; 4-byte Folded Reload
	ldrb	w10, [sp, #1565]
	ldr	d2, [sp, #1568]
	and	w9, w9, #0x1
	str	w10, [sp, #1352]                ; 4-byte Folded Spill
	ldrh	w10, [sp, #1566]
	strb	w9, [x8, #88]
	ldr	w9, [sp, #1452]                 ; 4-byte Folded Reload
	str	w10, [sp, #1344]                ; 4-byte Folded Spill
	and	w9, w9, #0x1
	strb	w9, [x8, #89]
	ldrb	w8, [sp, #1576]
	ldr	x9, [sp, #1640]
	ldrb	w11, [sp, #2236]
	ldr	d3, [sp, #1584]
	str	w8, [sp, #1336]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1577]
	ldr	d5, [sp, #1616]
	str	x9, [sp, #1312]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1648]
	ldr	d16, [sp, #1664]
	str	w8, [sp, #1332]                 ; 4-byte Folded Spill
	add	x8, sp, #1337
	ldr	d17, [sp, #1680]
	ldur	q4, [x8, #255]
	ldr	x8, [sp, #1608]
	str	w9, [sp, #1304]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1660]
	str	w11, [sp, #1104]                ; 4-byte Folded Spill
	ldrb	w11, [sp, #2237]
	str	x8, [sp, #1320]                 ; 8-byte Folded Spill
	add	x8, sp, #1488
	ldr	d19, [sp, #1712]
	ldur	q6, [x8, #136]
	ldur	d7, [x8, #164]
	ldur	q18, [x8, #200]
	ldur	q20, [x8, #232]
	ldr	x8, [sp, #1736]
	str	w9, [sp, #1300]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1661]
	str	w11, [sp, #1080]                ; 4-byte Folded Spill
	ldrh	w11, [sp, #2238]
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1744]
	ldr	d21, [x13]
	str	w9, [sp, #1296]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1662]
	ldr	d22, [sp, #1760]
	str	w8, [sp, #1260]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1756]
	ldr	d23, [sp, #1776]
	str	w9, [sp, #1292]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1672]
	ldur	q24, [x13, #36]
	str	w8, [sp, #1244]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1757]
	ldr	d25, [sp, #1808]
	str	w9, [sp, #1176]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1673]
	ldur	q26, [x13, #68]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #1758]
	ldr	d27, [x13, #96]
	str	w9, [sp, #1276]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1704]
	ldr	d28, [sp, #2064]
	str	w8, [sp, #1232]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1768]
	ldr	d30, [sp, #2096]
	str	x9, [sp, #1264]                 ; 8-byte Folded Spill
	ldr	d9, [x13, #384]
	ldr	d10, [sp, #2144]
	str	w8, [sp, #1216]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1769]
	ldr	d11, [sp, #2160]
	str	w11, [sp, #1048]                ; 4-byte Folded Spill
	ldrb	w11, [sp, #2248]
	ldr	d13, [sp, #2192]
	str	w8, [sp, #1224]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #1800]
	ldrh	w5, [sp, #2046]
	str	w11, [sp, #1088]                ; 4-byte Folded Spill
	ldrb	w11, [sp, #2249]
	ldr	d15, [x13, #480]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1832]
	ldr	d0, [sp, #2240]
	str	w11, [sp, #1112]                ; 4-byte Folded Spill
	ldr	x13, [sp, #584]                 ; 8-byte Folded Reload
	ldr	x11, [sp, #616]                 ; 8-byte Folded Reload
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1840]
	str	w8, [sp, #1192]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1852]
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1853]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #1854]
	str	w8, [sp, #824]                  ; 4-byte Folded Spill
	ldp	x8, x9, [sp, #424]              ; 16-byte Folded Reload
	ldr	q29, [x9]
	ldr	q31, [x8]
	ldp	x8, x9, [sp, #408]              ; 16-byte Folded Reload
	ldr	q14, [x8]
	ldr	w8, [sp, #1856]
	ldr	q12, [x9]
	str	w8, [sp, #960]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1860]
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1864]
	str	w8, [sp, #776]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1865]
	str	w8, [sp, #780]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1872]
	str	w8, [sp, #956]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1876]
	str	w8, [sp, #768]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1880]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1888]
	str	x8, [sp, #1464]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1896]
	str	x8, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #1904]
	str	w8, [sp, #772]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1908]
	str	w8, [sp, #764]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1912]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1920]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1928]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #1936]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1940]
	str	w8, [sp, #840]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1944]
	str	w8, [sp, #836]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1948]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1949]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #1950]
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1952]
	str	w8, [sp, #952]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1956]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1960]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1961]
	str	w8, [sp, #860]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1968]
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1972]
	str	w8, [sp, #820]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1976]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1984]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1992]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2000]
	str	w8, [sp, #832]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2004]
	str	w8, [sp, #816]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #448]                  ; 8-byte Folded Reload
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2008]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2016]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2024]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2032]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2036]
	str	w8, [sp, #900]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2040]
	str	w8, [sp, #884]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2044]
	str	w8, [sp, #844]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2045]
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #560]                  ; 8-byte Folded Reload
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #552]                  ; 8-byte Folded Reload
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #544]                  ; 8-byte Folded Reload
	str	x8, [sp, #1000]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2048]
	str	w8, [sp, #880]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2052]
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2056]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2057]
	str	w8, [sp, #1064]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2088]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2120]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2128]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #528]                  ; 8-byte Folded Reload
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #520]                  ; 8-byte Folded Reload
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldp	x10, x8, [sp, #504]             ; 16-byte Folded Reload
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2140]
	str	w8, [sp, #1096]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2141]
	str	w8, [sp, #1072]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2142]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2152]
	str	w8, [sp, #1056]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2153]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2184]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2216]
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2224]
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	ldp	x8, x9, [sp, #488]              ; 16-byte Folded Reload
LBB14_111:                              ; %b274_to_b59.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldrh	w16, [x10]
	ldrb	w10, [x10, #2]
	stur	q1, [x17, #8]
	ldr	q1, [sp, #1392]                 ; 16-byte Folded Reload
	str	w24, [sp, #2308]
	mov	x24, x20
	strh	w16, [sp, #2300]
	ldr	w16, [x9]
	ldrh	w9, [x9, #4]
	strb	w10, [sp, #2302]
	ldrh	w10, [x8]
	ldrb	w8, [x8, #2]
	strh	w9, [sp, #2296]
	ldrh	w9, [x7, #4]
	strb	w8, [sp, #2290]
	ldr	w8, [x7]
	ldr	w7, [sp, #1452]                 ; 4-byte Folded Reload
	strh	w9, [sp, #2284]
	ldrb	w9, [x28, #2]
	str	w8, [sp, #2280]
	ldrh	w8, [x28]
	ldr	x28, [sp, #704]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2278]
	ldr	w9, [x26]
	strh	w8, [sp, #2276]
	ldrh	w8, [x26, #4]
	ldr	x26, [sp, #712]                 ; 8-byte Folded Reload
	strh	w10, [sp, #2288]
	ldr	x10, [sp, #968]                 ; 8-byte Folded Reload
	str	w9, [sp, #2268]
	ldrh	w9, [x0]
	strh	w8, [sp, #2272]
	ldrb	w8, [x0, #2]
	ldr	x0, [sp, #1456]                 ; 8-byte Folded Reload
	strh	w9, [sp, #2264]
	ldr	w9, [x10]
	strb	w8, [sp, #2266]
	ldrh	w8, [x10, #4]
	ldr	x10, [sp, #984]                 ; 8-byte Folded Reload
	str	w9, [sp, #2256]
	ldr	x9, [sp, #1208]                 ; 8-byte Folded Reload
	strh	w8, [sp, #2260]
	ldr	x8, [sp, #1280]                 ; 8-byte Folded Reload
	ldr	w9, [x9]
	str	w16, [sp, #2292]
	str	x8, [sp, #2328]
	ldr	x8, [sp, #1376]                 ; 8-byte Folded Reload
	str	w9, [sp, #2304]
	ldr	w9, [sp, #1368]                 ; 4-byte Folded Reload
	str	x8, [sp, #2360]
	ldrb	w8, [x22, #2]
	strb	w9, [sp, #2368]
	ldrh	w9, [x22]
	ldr	x22, [sp, #1440]                ; 8-byte Folded Reload
	strb	w8, [x1, #2]
	ldr	w8, [sp, #1360]                 ; 4-byte Folded Reload
	strh	w9, [x1]
	ldr	w9, [sp, #1332]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2380]
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2393]
	ldr	w9, [x10]
	strb	w8, [sp, #2381]
	ldr	w8, [sp, #1344]                 ; 4-byte Folded Reload
	stur	q1, [x17, #40]
	ldr	d1, [sp, #1384]                 ; 8-byte Folded Reload
	strh	w8, [sp, #2382]
	ldr	w8, [sp, #1336]                 ; 4-byte Folded Reload
	stur	d1, [x17, #68]
	strb	w8, [sp, #2392]
	ldrh	w8, [x10, #4]
	ldr	x10, [sp, #976]                 ; 8-byte Folded Reload
	str	w9, [x21]
	ldr	w9, [sp, #1304]                 ; 4-byte Folded Reload
	strh	w8, [x21, #4]
	ldr	x8, [sp, #1320]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2464]
	ldrh	w9, [x10]
	str	x8, [sp, #2424]
	ldr	x8, [sp, #1312]                 ; 8-byte Folded Reload
	stur	q4, [x17, #104]
	str	x8, [sp, #2456]
	ldrb	w8, [x10, #2]
	ldr	x10, [sp, #1000]                ; 8-byte Folded Reload
	strh	w9, [x12]
	ldr	w9, [sp, #1276]                 ; 4-byte Folded Reload
	strb	w8, [x12, #2]
	ldr	w8, [sp, #1300]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2489]
	ldr	w9, [x10]
	strb	w8, [sp, #2476]
	ldr	w8, [sp, #1296]                 ; 4-byte Folded Reload
	stur	q6, [x17, #136]
	strb	w8, [sp, #2477]
	ldr	w8, [sp, #1292]                 ; 4-byte Folded Reload
	stur	d7, [x17, #164]
	strh	w8, [sp, #2478]
	ldr	w8, [sp, #1176]                 ; 4-byte Folded Reload
	stur	q18, [x17, #200]
	strb	w8, [sp, #2488]
	ldrh	w8, [x10, #4]
	ldr	x10, [sp, #992]                 ; 8-byte Folded Reload
	str	w9, [x4]
	ldr	w9, [sp, #1260]                 ; 4-byte Folded Reload
	strh	w8, [x4, #4]
	ldr	x8, [sp, #1264]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2560]
	ldrh	w9, [x10]
	str	x8, [sp, #2520]
	ldr	x8, [sp, #1248]                 ; 8-byte Folded Reload
	stur	q20, [x17, #232]
	mov	x17, x23
	str	x8, [sp, #2552]
	ldrb	w8, [x10, #2]
	ldr	x10, [sp, #1008]                ; 8-byte Folded Reload
	strh	w9, [x19]
	ldr	w9, [sp, #1224]                 ; 4-byte Folded Reload
	strb	w8, [x19, #2]
	ldr	w8, [sp, #1244]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2585]
	ldr	w9, [x10]
	strb	w8, [sp, #2572]
	ldr	w8, [sp, #1240]                 ; 4-byte Folded Reload
	str	d8, [sp, #2336]
	strb	w8, [sp, #2573]
	ldr	w8, [sp, #1232]                 ; 4-byte Folded Reload
	str	d2, [sp, #2384]
	strh	w8, [sp, #2574]
	ldr	w8, [sp, #1216]                 ; 4-byte Folded Reload
	str	d3, [sp, #2400]
	strb	w8, [sp, #2584]
	ldrh	w8, [x10, #4]
	ldr	x10, [sp, #1016]                ; 8-byte Folded Reload
	str	w9, [x6]
	ldr	w9, [sp, #1192]                 ; 4-byte Folded Reload
	strh	w8, [x6, #4]
	ldr	x8, [sp, #1200]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2656]
	ldrh	w9, [x10]
	str	x8, [sp, #2616]
	ldr	x8, [sp, #1184]                 ; 8-byte Folded Reload
	str	d5, [sp, #2432]
	str	x8, [sp, #2648]
	ldrb	w8, [x10, #2]
	ldr	x10, [sp, #1024]                ; 8-byte Folded Reload
	strh	w9, [x25]
	strb	w8, [x25, #2]
	ldrh	w8, [x10, #4]
	ldr	w9, [x10]
	ldr	x10, [sp, #720]                 ; 8-byte Folded Reload
	str	d16, [sp, #2480]
	strh	w8, [x27, #4]
	ldrb	w8, [sp, #2302]
	str	w9, [x27]
	ldrh	w9, [sp, #2300]
	ldr	x27, [sp, #1464]                ; 8-byte Folded Reload
	strb	w8, [x30, #2]
	ldrh	w8, [sp, #2296]
	strh	w9, [x30]
	ldr	w9, [sp, #2292]
	strh	w8, [x20, #4]
	ldrb	w8, [sp, #2290]
	str	w9, [x20]
	ldrh	w9, [sp, #2288]
	strb	w8, [x11, #2]
	ldr	w8, [sp, #1032]                 ; 4-byte Folded Reload
	strh	w9, [x11]
	ldr	w9, [sp, #1064]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2872]
	ldrh	w8, [sp, #2284]
	strb	w9, [sp, #2873]
	ldr	w9, [sp, #2280]
	strh	w8, [x23, #4]
	ldr	x8, [sp, #1120]                 ; 8-byte Folded Reload
	str	w9, [x23]
	ldr	w9, [sp, #1164]                 ; 4-byte Folded Reload
	str	x8, [sp, #2904]
	ldr	x8, [sp, #1128]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2944]
	ldrh	w9, [sp, #2276]
	str	x8, [sp, #2936]
	ldrb	w8, [sp, #2278]
	strh	w9, [x15]
	ldr	w9, [sp, #1040]                 ; 4-byte Folded Reload
	strb	w8, [x15, #2]
	ldr	w8, [sp, #1096]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2969]
	ldr	w9, [sp, #2268]
	strb	w8, [sp, #2956]
	ldr	w8, [sp, #1072]                 ; 4-byte Folded Reload
	str	w9, [x14]
	ldr	w9, [sp, #1168]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2957]
	ldr	w8, [sp, #1036]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3040]
	ldrh	w9, [sp, #2264]
	strh	w8, [sp, #2958]
	ldr	w8, [sp, #1056]                 ; 4-byte Folded Reload
	strh	w9, [x2]
	ldr	w9, [sp, #1112]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2968]
	ldrh	w8, [sp, #2272]
	strb	w9, [sp, #3065]
	ldr	w9, [sp, #2256]
	strh	w8, [x14, #4]
	ldr	x8, [sp, #1136]                 ; 8-byte Folded Reload
	str	w9, [x3]
	ldr	x9, [sp, #728]                  ; 8-byte Folded Reload
	str	x8, [sp, #3000]
	ldr	x8, [sp, #1152]                 ; 8-byte Folded Reload
	str	d17, [sp, #2496]
	str	x8, [sp, #3032]
	ldrb	w8, [sp, #2266]
	str	d19, [sp, #2528]
	strb	w8, [x2, #2]
	ldr	w8, [sp, #1104]                 ; 4-byte Folded Reload
	str	d21, [x13]
	strb	w8, [sp, #3052]
	ldr	w8, [sp, #1080]                 ; 4-byte Folded Reload
	str	d22, [sp, #2576]
	strb	w8, [sp, #3053]
	ldr	w8, [sp, #1048]                 ; 4-byte Folded Reload
	str	d23, [sp, #2592]
	strh	w8, [sp, #3054]
	ldr	w8, [sp, #1088]                 ; 4-byte Folded Reload
	stur	q24, [x13, #36]
	strb	w8, [sp, #3064]
	ldrh	w8, [sp, #2260]
	str	d25, [sp, #2624]
	strh	w8, [x3, #4]
	ldr	w8, [sp, #788]                  ; 4-byte Folded Reload
	stur	q26, [x13, #68]
	strb	w8, [sp, #2668]
	ldr	w8, [sp, #784]                  ; 4-byte Folded Reload
	str	d27, [x13, #96]
	strb	w8, [sp, #2669]
	ldr	w8, [sp, #824]                  ; 4-byte Folded Reload
	str	w7, [sp, #2676]
	strh	w8, [sp, #2670]
	ldr	w8, [sp, #960]                  ; 4-byte Folded Reload
	str	x22, [sp, #2696]
	str	w8, [sp, #2672]
	ldr	w8, [sp, #776]                  ; 4-byte Folded Reload
	str	x27, [sp, #2704]
	strb	w8, [sp, #2680]
	ldr	w8, [sp, #780]                  ; 4-byte Folded Reload
	str	x0, [sp, #2712]
	strb	w8, [sp, #2681]
	ldr	w8, [sp, #956]                  ; 4-byte Folded Reload
	strh	w5, [sp, #2862]
	str	w8, [sp, #2688]
	ldr	w8, [sp, #768]                  ; 4-byte Folded Reload
	str	d28, [sp, #2880]
	str	w8, [sp, #2692]
	ldr	w8, [sp, #772]                  ; 4-byte Folded Reload
	str	q29, [x9]
	str	w8, [sp, #2720]
	ldr	w8, [sp, #764]                  ; 4-byte Folded Reload
	str	d30, [sp, #2912]
	str	w8, [sp, #2724]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	str	q31, [x10]
	str	x8, [sp, #2728]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	str	d9, [x13, #384]
	str	x8, [sp, #2736]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	str	d10, [sp, #2960]
	str	x8, [sp, #2744]
	ldr	w8, [sp, #872]                  ; 4-byte Folded Reload
	str	d11, [sp, #2976]
	strb	w8, [sp, #2752]
	ldr	w8, [sp, #840]                  ; 4-byte Folded Reload
	str	q12, [x26]
	str	w8, [sp, #2756]
	ldr	w8, [sp, #836]                  ; 4-byte Folded Reload
	str	d13, [sp, #3008]
	str	w8, [sp, #2760]
	ldr	w8, [sp, #864]                  ; 4-byte Folded Reload
	str	q14, [x28]
	strb	w8, [sp, #2764]
	ldr	w8, [sp, #868]                  ; 4-byte Folded Reload
	str	d15, [x13, #480]
	strb	w8, [sp, #2765]
	ldr	w8, [sp, #1148]                 ; 4-byte Folded Reload
	str	d0, [sp, #3056]
	mov	w16, w8
	strh	w8, [sp, #2766]
	ldr	w8, [sp, #952]                  ; 4-byte Folded Reload
	str	w8, [sp, #2768]
	ldr	w8, [sp, #948]                  ; 4-byte Folded Reload
	str	w8, [sp, #2772]
	ldr	w8, [sp, #856]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2776]
	ldr	w8, [sp, #860]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2777]
	ldr	w8, [sp, #964]                  ; 4-byte Folded Reload
	str	w8, [sp, #2784]
	ldr	w8, [sp, #820]                  ; 4-byte Folded Reload
	str	w8, [sp, #2788]
	ldr	x8, [sp, #936]                  ; 8-byte Folded Reload
	str	x8, [sp, #2792]
	ldr	x8, [sp, #928]                  ; 8-byte Folded Reload
	str	x8, [sp, #2800]
	ldr	x8, [sp, #920]                  ; 8-byte Folded Reload
	str	x8, [sp, #2808]
	ldr	w8, [sp, #832]                  ; 4-byte Folded Reload
	str	w8, [sp, #2816]
	ldr	w8, [sp, #816]                  ; 4-byte Folded Reload
	str	w8, [sp, #2820]
	ldr	x8, [sp, #912]                  ; 8-byte Folded Reload
	str	x8, [sp, #2824]
	ldr	x8, [sp, #904]                  ; 8-byte Folded Reload
	str	x8, [sp, #2832]
	ldr	x8, [sp, #888]                  ; 8-byte Folded Reload
	str	x8, [sp, #2840]
	ldr	w8, [sp, #852]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2848]
	ldr	w8, [sp, #900]                  ; 4-byte Folded Reload
	str	w8, [sp, #2852]
	ldr	w8, [sp, #884]                  ; 4-byte Folded Reload
	str	w8, [sp, #2856]
	ldr	w8, [sp, #844]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2860]
	ldr	w8, [sp, #848]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2861]
	ldr	w8, [sp, #880]                  ; 4-byte Folded Reload
	str	w8, [sp, #2864]
	ldr	w8, [sp, #876]                  ; 4-byte Folded Reload
	str	w8, [sp, #2868]
	ldr	x8, [sp, #1416]                 ; 8-byte Folded Reload
	cmp	x8, #6
	b.hi	LBB14_321
; %bb.112:                              ; %b274_to_b59.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x23, [sp, #1472]                ; 8-byte Folded Reload
	mov	x20, x26
	mov	x26, x28
	add	x28, x8, #1
	ldr	w8, [sp, #1436]                 ; 4-byte Folded Reload
	add	x23, x23, #96
	str	x23, [sp, #1472]                ; 8-byte Folded Spill
	ldr	w23, [sp, #1424]                ; 4-byte Folded Reload
	add	w8, w8, #1, lsl #12             ; =4096
	str	w8, [sp, #1436]                 ; 4-byte Folded Spill
	tbnz	w23, #0, LBB14_82
	b	LBB14_321
LBB14_113:                              ; %b82.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	bl	_liza_rt_reactor_finish_connect
	lsr	x8, x0, #32
	cbnz	x8, LBB14_115
; %bb.114:                              ; %b1.i247.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	x0, #1
	mov	w10, wzr
	cset	w9, eq
	b	LBB14_129
LBB14_115:                              ; %v10_ok.i.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB14_127
; %bb.116:                              ; %v10_ok.i.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh50:
	adrp	x12, lJTI14_6@PAGE
Lloh51:
	add	x12, x12, lJTI14_6@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB14_117
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB14_117:                              ; %b4.i.i245.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB14_128
LBB14_118:                              ; %b34.i.i240.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB14_128
LBB14_119:                              ; %b13.i.i242.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB14_128
LBB14_120:                              ; %b16.i.i241.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB14_128
LBB14_121:                              ; %b10.i.i243.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB14_128
LBB14_122:                              ; %b7.i.i244.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB14_128
LBB14_123:                              ; %b22.i.i239.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB14_128
LBB14_124:                              ; %b25.i.i238.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB14_128
LBB14_125:                              ; %b31.i.i233.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB14_128
LBB14_126:                              ; %b28.i.i237.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB14_128
LBB14_127:                              ; %b36.i.i246.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #6                          ; =0x6
LBB14_128:                              ; %liza___liza_reactor_error.exit.i234.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	mov	w10, #1                         ; =0x1
LBB14_129:                              ; %liza_net.reactor_finish_connect.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w15, [sp, #1464]                ; 4-byte Folded Reload
	cmp	w10, #1
	mov	w1, w23
	b.ne	LBB14_131
; %bb.130:                              ; %b85.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w23, [sp, #1456]                ; 4-byte Folded Reload
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	str	w20, [sp, #1332]                ; 4-byte Folded Spill
	tst	w8, w9
	b.ne	LBB14_97
	b	LBB14_132
LBB14_131:                              ; %b89.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w23, [sp, #1456]                ; 4-byte Folded Reload
	and	w8, w9, #0x1
	str	w8, [sp, #1332]                 ; 4-byte Folded Spill
LBB14_132:                              ; %b95.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	b.hi	LBB14_136
; %bb.133:                              ; %b95.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, #2048
	b.hi	LBB14_136
; %bb.134:                              ; %b4.i.i257.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	ldr	w22, [sp, #1392]                ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w23, #0, LBB14_145
; %bb.135:                              ; %b4.i.i257.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	and	w8, w22, w8
	cbnz	w8, LBB14_145
LBB14_136:                              ; %b114.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_175
; %bb.137:                              ; %b118.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	b.hi	LBB14_175
; %bb.138:                              ; %b118.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, #2048
	b.hi	LBB14_175
; %bb.139:                              ; %b118.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	tbnz	w23, #0, LBB14_175
; %bb.140:                              ; %b118.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, w1
	b.eq	LBB14_175
; %bb.141:                              ; %v253_ok.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1436]                 ; 4-byte Folded Reload
	adds	w6, w8, w1
	b.hs	LBB14_325
; %bb.142:                              ; %b3.i325.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	subs	w21, w15, w1
	b.lo	LBB14_325
; %bb.143:                              ; %liza_relay.direction.queued.exit330.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	mov	w22, w1
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	w5, #32768                      ; =0x8000
	mov	w7, w21
	mov	w20, w15
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1332]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1392]                ; 4-byte Folded Reload
	cbnz	x8, LBB14_151
; %bb.144:                              ; %b1.i.i354.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	b	LBB14_173
LBB14_145:                              ; %liza_relay.direction.readable.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, #2048
	b.eq	LBB14_136
; %bb.146:                              ; %liza_relay.direction.readable.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	eor	w8, w22, #0x1
	tbz	w8, #0, LBB14_136
; %bb.147:                              ; %liza_relay.direction.readable.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w26, #1
	b.eq	LBB14_136
; %bb.148:                              ; %liza_relay.direction.readable.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #5                          ; =0x5
	and	w8, w21, w8
	cbz	w8, LBB14_136
; %bb.149:                              ; %b4.i.i266.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #2048                       ; =0x800
	mov	w21, w1
	tst	w22, #0x1
	sub	w19, w8, w15
	ldr	w8, [sp, #1436]                 ; 4-byte Folded Reload
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1424]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1344]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	csel	w7, wzr, w19, ne
	add	w6, w15, w8
	mov	x0, x28
	mov	w5, #32768                      ; =0x8000
	str	w15, [sp, #1464]                ; 4-byte Folded Spill
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB14_154
; %bb.150:                              ; %b104.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w15, [sp, #1464]                ; 4-byte Folded Reload
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w1, w21
	tst	w8, w9
	b.ne	LBB14_97
	b	LBB14_136
LBB14_151:                              ; %v8_ok.i.i336.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB14_171
; %bb.152:                              ; %v8_ok.i.i336.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh52:
	adrp	x12, lJTI14_7@PAGE
Lloh53:
	add	x12, x12, lJTI14_7@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB14_153
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB14_153:                              ; %b4.i.i.i352.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB14_172
LBB14_154:                              ; %b1.i295.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w1, wzr
	orr	w8, w23, w22
	mov	w9, #1                          ; =0x1
	tbnz	w8, #0, LBB14_158
; %bb.155:                              ; %b1.i295.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w12, [sp, #1332]                ; 4-byte Folded Reload
	cmp	w19, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	b.lo	LBB14_160
; %bb.156:                              ; %b12.i.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	cbz	w0, LBB14_159
; %bb.157:                              ; %v26_ok.i.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	mov	w1, w21
	add	w8, w8, w0
	b	LBB14_160
LBB14_158:                              ;   in Loop: Header=BB14_82 Depth=2
	ldr	w12, [sp, #1332]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	b	LBB14_160
LBB14_159:                              ; %b13.i.i21
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	mov	w1, w21
LBB14_160:                              ; %liza_relay.direction.read.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w9, #1
	b.eq	LBB14_96
; %bb.161:                              ; %b111.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	and	w9, w11, #0x1
	and	w23, w10, #0x1
	and	w12, w12, #0x1
	str	w9, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1352]                 ; 4-byte Folded Reload
	mov	w15, w8
	str	w12, [sp, #1332]                ; 4-byte Folded Spill
	and	w9, w9, #0x1
	str	w9, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1452]                 ; 4-byte Folded Reload
	and	w9, w9, #0x1
	str	w9, [sp, #1452]                 ; 4-byte Folded Spill
	b	LBB14_136
LBB14_162:                              ; %b34.i.i.i347.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB14_172
LBB14_163:                              ; %b13.i.i.i349.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB14_172
LBB14_164:                              ; %b16.i.i.i348.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB14_172
LBB14_165:                              ; %b10.i.i.i350.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB14_172
LBB14_166:                              ; %b7.i.i.i351.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB14_172
LBB14_167:                              ; %b22.i.i.i346.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB14_172
LBB14_168:                              ; %b25.i.i.i345.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB14_172
LBB14_169:                              ; %b31.i.i.i339.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB14_172
LBB14_170:                              ; %b28.i.i.i344.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB14_172
LBB14_171:                              ; %b36.i.i.i353.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #6                          ; =0x6
LBB14_172:                              ; %liza___liza_reactor_error.exit.i.i340.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB14_173:                              ; %liza_net.reactor_write.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w15, w20
	cmp	w9, #1
	mov	w1, w22
	b.ne	LBB14_183
; %bb.174:                              ; %b124.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB14_97
LBB14_175:                              ; %b134.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_209
LBB14_176:                              ; %b138.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	b.hi	LBB14_209
; %bb.177:                              ; %b138.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, #2048
	b.hi	LBB14_209
; %bb.178:                              ; %b4.i.i385.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	tbnz	w23, #0, LBB14_209
; %bb.179:                              ; %b4.i.i385.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1392]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_209
; %bb.180:                              ; %b4.i.i385.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	b.ne	LBB14_209
; %bb.181:                              ; %b141.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	mov	w21, w1
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	w20, w15
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB14_186
; %bb.182:                              ; %b1.i.i414.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	b	LBB14_206
LBB14_183:                              ; %b4.i.i368.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cbz	w0, LBB14_185
; %bb.184:                              ; %liza_relay.direction.queued.exit.i.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w0, w21
	b.ls	LBB14_189
LBB14_185:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w1, wzr
	mov	w15, wzr
	mov	w14, wzr
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB14_96
	b	LBB14_194
LBB14_186:                              ; %v8_ok.i.i396.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB14_204
; %bb.187:                              ; %v8_ok.i.i396.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh54:
	adrp	x12, lJTI14_8@PAGE
Lloh55:
	add	x12, x12, lJTI14_8@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB14_188
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB14_188:                              ; %b4.i.i.i412.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB14_205
LBB14_189:                              ; %b9.i.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	adds	w1, w1, w0
	b.hs	LBB14_325
; %bb.190:                              ; %v13_ok.i.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	b.ne	LBB14_192
; %bb.191:                              ; %b10.i.i19
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	mov	w1, wzr
	mov	w15, wzr
	b	LBB14_193
LBB14_192:                              ; %b12.i374.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
LBB14_193:                              ; %liza_relay.direction.write.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB14_96
LBB14_194:                              ; %b131.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	and	w23, w8, #0x1
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	and	w14, w14, #0x1
	and	w13, w13, #0x1
	str	w14, [sp, #1392]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w13, [sp, #1332]                ; 4-byte Folded Spill
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB14_176
	b	LBB14_209
LBB14_195:                              ; %b34.i.i.i407.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB14_205
LBB14_196:                              ; %b13.i.i.i409.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB14_205
LBB14_197:                              ; %b16.i.i.i408.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB14_205
LBB14_198:                              ; %b10.i.i.i410.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB14_205
LBB14_199:                              ; %b7.i.i.i411.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB14_205
LBB14_200:                              ; %b22.i.i.i406.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB14_205
LBB14_201:                              ; %b25.i.i.i405.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB14_205
LBB14_202:                              ; %b31.i.i.i399.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB14_205
LBB14_203:                              ; %b28.i.i.i404.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB14_205
LBB14_204:                              ; %b36.i.i.i413.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #6                          ; =0x6
LBB14_205:                              ; %liza___liza_reactor_error.exit.i.i400.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
LBB14_206:                              ; %liza_net.reactor_shutdown_write.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w10, [sp, #1332]                ; 4-byte Folded Reload
	mov	w15, w20
	cmp	w9, #1
	mov	w1, w21
	b.ne	LBB14_208
; %bb.207:                              ; %b144.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB14_97
	b	LBB14_209
LBB14_208:                              ; %b151.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	and	w10, w10, #0x1
	mov	w15, w1
	mov	w23, #1                         ; =0x1
	str	w10, [sp, #1332]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
LBB14_209:                              ; %b154.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_214
; %bb.210:                              ; %b158.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1360]                 ; 4-byte Folded Reload
	ldr	w9, [sp, #1440]                 ; 4-byte Folded Reload
	cmp	w8, w9
	b.hi	LBB14_214
; %bb.211:                              ; %b158.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w9, #2048
	b.hi	LBB14_214
; %bb.212:                              ; %b4.i.i435.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w8, w9
	ldr	w10, [sp, #1452]                ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w10, #0, LBB14_223
; %bb.213:                              ; %b4.i.i435.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w10, [sp, #1352]                ; 4-byte Folded Reload
	and	w8, w10, w8
	cbnz	w8, LBB14_223
LBB14_214:                              ; %b177.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_248
; %bb.215:                              ; %b181.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w19, [sp, #1360]                ; 4-byte Folded Reload
	ldr	w9, [sp, #1440]                 ; 4-byte Folded Reload
	cmp	w19, w9
	b.hi	LBB14_248
; %bb.216:                              ; %b181.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w9, #2048
	b.hi	LBB14_248
; %bb.217:                              ; %b181.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB14_248
; %bb.218:                              ; %b181.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w9, w19
	b.eq	LBB14_248
; %bb.219:                              ; %v393_ok.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1436]                 ; 4-byte Folded Reload
	add	w8, w8, #2048
	adds	w6, w8, w19
	b.hs	LBB14_325
; %bb.220:                              ; %b3.i550.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x3, [sp, #1344]                 ; 8-byte Folded Reload
	subs	w21, w9, w19
	b.lo	LBB14_325
; %bb.221:                              ; %liza_relay.direction.queued.exit555.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w20, w23
	mov	w23, w1
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1424]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	mov	x0, x28
	mov	w5, #32768                      ; =0x8000
	mov	w7, w21
	mov	w22, w15
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1332]                ; 4-byte Folded Reload
	cbnz	x8, LBB14_228
; %bb.222:                              ; %b1.i.i581.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	b	LBB14_246
LBB14_223:                              ; %liza_relay.direction.readable.exit445.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w9, #2048
	b.eq	LBB14_214
; %bb.224:                              ; %liza_relay.direction.readable.exit445.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	eor	w8, w8, #0x1
	tbz	w8, #0, LBB14_214
; %bb.225:                              ; %liza_relay.direction.readable.exit445.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x9, [sp, #1384]                 ; 8-byte Folded Reload
	mov	w8, #5                          ; =0x5
	and	w8, w9, w8
	cbz	w8, LBB14_214
; %bb.226:                              ; %b4.i.i452.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w9, [sp, #1440]                 ; 4-byte Folded Reload
	mov	w8, #2048                       ; =0x800
	ldr	w20, [sp, #1352]                ; 4-byte Folded Reload
	ldr	x3, [sp, #1376]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	mov	x0, x28
	sub	w19, w8, w9
	ldr	w8, [sp, #1436]                 ; 4-byte Folded Reload
	tst	w20, #0x1
	str	w1, [sp, #1384]                 ; 4-byte Folded Spill
	csel	w7, wzr, w19, ne
	mov	x1, x24
	add	w8, w9, w8
	mov	x2, x25
	mov	w5, #32768                      ; =0x8000
	add	w6, w8, #2048
	mov	w21, w15
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB14_231
; %bb.227:                              ; %b167.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1384]                 ; 4-byte Folded Reload
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w15, w21
	tst	w8, w9
	b.ne	LBB14_97
	b	LBB14_214
LBB14_228:                              ; %v8_ok.i.i563.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB14_244
; %bb.229:                              ; %v8_ok.i.i563.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh56:
	adrp	x12, lJTI14_9@PAGE
Lloh57:
	add	x12, x12, lJTI14_9@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB14_230
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB14_230:                              ; %b4.i.i.i579.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB14_245
LBB14_231:                              ; %b1.i496.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
	mov	w1, wzr
	mov	w9, #1                          ; =0x1
	orr	w8, w8, w20
	tbnz	w8, #0, LBB14_268
; %bb.232:                              ; %b1.i496.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w12, [sp, #1332]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1392]                ; 4-byte Folded Reload
	cmp	w19, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
	b.lo	LBB14_270
; %bb.233:                              ; %b12.i502.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	cbz	w0, LBB14_269
; %bb.234:                              ; %v26_ok.i504.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1360]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w8, w0
	b	LBB14_270
LBB14_235:                              ; %b34.i.i.i574.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB14_245
LBB14_236:                              ; %b13.i.i.i576.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB14_245
LBB14_237:                              ; %b16.i.i.i575.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB14_245
LBB14_238:                              ; %b10.i.i.i577.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB14_245
LBB14_239:                              ; %b7.i.i.i578.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB14_245
LBB14_240:                              ; %b22.i.i.i573.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB14_245
LBB14_241:                              ; %b25.i.i.i572.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB14_245
LBB14_242:                              ; %b31.i.i.i566.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB14_245
LBB14_243:                              ; %b28.i.i.i571.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB14_245
LBB14_244:                              ; %b36.i.i.i580.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #6                          ; =0x6
LBB14_245:                              ; %liza___liza_reactor_error.exit.i.i567.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB14_246:                              ; %liza_net.reactor_write.exit584.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w15, w22
	cmp	w9, #1
	b.ne	LBB14_256
; %bb.247:                              ; %b187.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	mov	w1, w23
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w23, w20
	tst	w8, w9
	b.ne	LBB14_97
LBB14_248:                              ; %b197.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB14_286
LBB14_249:                              ; %b201.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w19, [sp, #1360]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	ldr	w10, [sp, #1352]                ; 4-byte Folded Reload
	cmp	w19, w8
	b.hi	LBB14_286
; %bb.250:                              ; %b201.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w8, #2048
	b.hi	LBB14_286
; %bb.251:                              ; %b4.i.i644.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w9, [sp, #1452]                 ; 4-byte Folded Reload
	tbnz	w9, #0, LBB14_286
; %bb.252:                              ; %b4.i.i644.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	tbz	w10, #0, LBB14_286
; %bb.253:                              ; %b4.i.i644.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w19, w8
	b.ne	LBB14_286
; %bb.254:                              ; %b204.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	str	w1, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1424]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1344]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	w21, w15
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB14_259
; %bb.255:                              ; %b1.i.i678.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	b	LBB14_283
LBB14_256:                              ; %b4.i.i596.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w10, [sp, #1392]                ; 4-byte Folded Reload
	cbz	w0, LBB14_258
; %bb.257:                              ; %liza_relay.direction.queued.exit.i611.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w0, w21
	b.ls	LBB14_262
LBB14_258:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w19, wzr
	mov	w11, wzr
	str	wzr, [sp, #1352]                ; 4-byte Folded Spill
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB14_96
	b	LBB14_267
LBB14_259:                              ; %v8_ok.i.i660.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB14_281
; %bb.260:                              ; %v8_ok.i.i660.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh58:
	adrp	x12, lJTI14_10@PAGE
Lloh59:
	add	x12, x12, lJTI14_10@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB14_261
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB14_261:                              ; %b4.i.i.i676.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB14_282
LBB14_262:                              ; %b9.i614.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	adds	w19, w19, w0
	b.hs	LBB14_325
; %bb.263:                              ; %v13_ok.i618.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w11, [sp, #1440]                ; 4-byte Folded Reload
	cmp	w19, w11
	b.ne	LBB14_265
; %bb.264:                              ; %b10.i626.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
	mov	w19, wzr
	mov	w11, wzr
	b	LBB14_266
LBB14_265:                              ; %b12.i620.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, wzr
LBB14_266:                              ; %liza_relay.direction.write.exit636.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB14_96
LBB14_267:                              ; %b194.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w9, [sp, #1352]                 ; 4-byte Folded Reload
	and	w20, w20, #0x1
	and	w8, w8, #0x1
	and	w13, w13, #0x1
	and	w10, w10, #0x1
	mov	w1, w23
	and	w9, w9, #0x1
	mov	w23, w20
	str	w11, [sp, #1440]                ; 4-byte Folded Spill
	str	w19, [sp, #1360]                ; 4-byte Folded Spill
	str	w9, [sp, #1352]                 ; 4-byte Folded Spill
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	str	w13, [sp, #1332]                ; 4-byte Folded Spill
	str	w10, [sp, #1392]                ; 4-byte Folded Spill
	ldr	w8, [sp, #1332]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB14_249
	b	LBB14_286
LBB14_268:                              ;   in Loop: Header=BB14_82 Depth=2
	ldr	w12, [sp, #1332]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1392]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
	b	LBB14_270
LBB14_269:                              ; %b13.i511.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w1, [sp, #1360]                 ; 4-byte Folded Reload
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
LBB14_270:                              ; %liza_relay.direction.read.exit517.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w9, #1
	b.eq	LBB14_96
; %bb.271:                              ; %b174.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	and	w9, w11, #0x1
	str	w1, [sp, #1360]                 ; 4-byte Folded Spill
	ldr	w1, [sp, #1384]                 ; 4-byte Folded Reload
	str	w9, [sp, #1352]                 ; 4-byte Folded Spill
	and	w9, w10, #0x1
	and	w12, w12, #0x1
	and	w13, w13, #0x1
	and	w23, w23, #0x1
	str	w9, [sp, #1452]                 ; 4-byte Folded Spill
	str	w12, [sp, #1332]                ; 4-byte Folded Spill
	str	w13, [sp, #1392]                ; 4-byte Folded Spill
	str	w8, [sp, #1440]                 ; 4-byte Folded Spill
	b	LBB14_214
LBB14_272:                              ; %b34.i.i.i671.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB14_282
LBB14_273:                              ; %b13.i.i.i673.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB14_282
LBB14_274:                              ; %b16.i.i.i672.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB14_282
LBB14_275:                              ; %b10.i.i.i674.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB14_282
LBB14_276:                              ; %b7.i.i.i675.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB14_282
LBB14_277:                              ; %b22.i.i.i670.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB14_282
LBB14_278:                              ; %b25.i.i.i669.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB14_282
LBB14_279:                              ; %b31.i.i.i663.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB14_282
LBB14_280:                              ; %b28.i.i.i668.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB14_282
LBB14_281:                              ; %b36.i.i.i677.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w8, #6                          ; =0x6
LBB14_282:                              ; %liza___liza_reactor_error.exit.i.i664.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
LBB14_283:                              ; %liza_net.reactor_shutdown_write.exit681.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w10, [sp, #1332]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1392]                ; 4-byte Folded Reload
	mov	w15, w21
	cmp	w9, #1
	b.ne	LBB14_285
; %bb.284:                              ; %b207.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1384]                 ; 4-byte Folded Reload
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB14_97
	b	LBB14_286
LBB14_285:                              ; %b214.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w1, [sp, #1384]                 ; 4-byte Folded Reload
	and	w10, w10, #0x1
	and	w11, w11, #0x1
	and	w23, w23, #0x1
	mov	w8, #1                          ; =0x1
	str	w10, [sp, #1332]                ; 4-byte Folded Spill
	str	w11, [sp, #1392]                ; 4-byte Folded Spill
	str	w19, [sp, #1440]                ; 4-byte Folded Spill
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
LBB14_286:                              ; %b217.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	tbz	w23, #0, LBB14_288
; %bb.287:                              ; %b217.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w22, [sp, #1320]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB14_97
LBB14_288:                              ; %b227.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	mov	w8, #2049                       ; =0x801
	ccmp	w15, w8, #2, ls
	cset	w8, lo
	cmp	w8, #1
	b.ne	LBB14_292
; %bb.289:                              ; %b4.i.i713.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w1, w15
	ldr	w20, [sp, #1392]                ; 4-byte Folded Reload
	cset	w9, eq
	tbz	w23, #0, LBB14_293
; %bb.290:                              ; %b4.i.i713.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	and	w9, w20, w9
	cbnz	w9, LBB14_293
; %bb.291:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w4, wzr
	b	LBB14_294
LBB14_292:                              ;   in Loop: Header=BB14_82 Depth=2
	ldr	w12, [sp, #1332]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1360]                ; 4-byte Folded Reload
	mov	w4, wzr
	ldr	w20, [sp, #1392]                ; 4-byte Folded Reload
	b	LBB14_295
LBB14_293:                              ; %b1.i720.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, #2048
	eor	w10, w20, #0x1
	cset	w9, ne
	and	w4, w9, w10
LBB14_294:                              ; %liza_relay.direction.readable.exit723.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w12, [sp, #1332]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1360]                ; 4-byte Folded Reload
LBB14_295:                              ; %liza_relay.direction.readable.exit723.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	w14, [sp, #1440]                ; 4-byte Folded Reload
	str	w15, [sp, #1464]                ; 4-byte Folded Spill
	cmp	w13, w14
	b.hi	LBB14_300
; %bb.296:                              ; %liza_relay.direction.readable.exit723.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w14, #2048
	b.hi	LBB14_300
; %bb.297:                              ; %b4.i.i730.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w14, w13
	ldr	w9, [sp, #1452]                 ; 4-byte Folded Reload
	ldr	w16, [sp, #1352]                ; 4-byte Folded Reload
	cset	w10, ne
	orr	w11, w4, #0x2
	ldr	x3, [sp, #1344]                 ; 8-byte Folded Reload
	eor	w9, w9, #0x1
	orr	w10, w10, w16
	ldr	x26, [sp, #1376]                ; 8-byte Folded Reload
	and	w10, w9, w10
	mov	w22, w1
	tst	w10, #0x1
	csel	w4, w11, w4, ne
	tbz	w12, #0, LBB14_309
; %bb.298:                              ; %b4.i.i767.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w14, w13
	mov	w1, w22
	cset	w10, eq
	and	w10, w16, w10
	orr	w9, w9, w10
	tbz	w9, #0, LBB14_301
; %bb.299:                              ; %b1.i774.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w14, #2048
	eor	w10, w16, #0x1
	cset	w9, ne
	and	w21, w9, w10
	cbnz	w8, LBB14_302
	b	LBB14_307
LBB14_300:                              ; %b237.thread.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x3, [sp, #1344]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #1376]                ; 8-byte Folded Reload
	tbz	w12, #0, LBB14_308
LBB14_301:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w21, wzr
	cbz	w8, LBB14_307
LBB14_302:                              ; %b4.i.i784.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, w1
	cset	w8, ne
	bic	w8, w8, w23
	tbnz	w8, #0, LBB14_306
; %bb.303:                              ; %b4.i.i804.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	tbnz	w23, #0, LBB14_307
; %bb.304:                              ; %b4.i.i804.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	tbz	w20, #0, LBB14_307
; %bb.305:                              ; %b4.i.i804.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	cmp	w15, w1
	b.ne	LBB14_307
LBB14_306:                              ; %b246.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w22, w1
	orr	w21, w21, #0x2
	b	LBB14_310
LBB14_307:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w22, w1
	b	LBB14_310
LBB14_308:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w22, w1
LBB14_309:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w21, #2                         ; =0x2
LBB14_310:                              ; %b249.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1424]                 ; 8-byte Folded Reload
	mov	x0, x28
	str	x3, [sp, #1344]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbnz	x8, LBB14_312
; %bb.311:                              ; %b1.i.i838.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w19, wzr
	b	LBB14_315
LBB14_312:                              ; %v8_ok.i.i820.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB14_314
; %bb.313:                              ; %v8_ok.i.i820.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh60:
	adrp	x11, lJTI14_11@PAGE
Lloh61:
	add	x11, x11, lJTI14_11@PAGEOFF
	adr	x9, LBB14_314
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB14_314:                              ; %liza___liza_reactor_error.exit.i.i824.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w19, #1                         ; =0x1
LBB14_315:                              ; %liza_net.reactor_interest.exit.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x26
	mov	w4, w21
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbnz	x8, LBB14_317
; %bb.316:                              ; %b1.i.i864.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	ldr	x12, [sp, #1424]                ; 8-byte Folded Reload
	mov	w9, w23
	orr	w8, w8, w19
	cbnz	w8, LBB14_96
	b	LBB14_320
LBB14_317:                              ; %v8_ok.i.i846.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	sub	w8, w8, #1
	ldr	x12, [sp, #1424]                ; 8-byte Folded Reload
	cmp	w8, #11
	b.hi	LBB14_319
; %bb.318:                              ; %v8_ok.i.i846.i
                                        ;   in Loop: Header=BB14_82 Depth=2
Lloh62:
	adrp	x11, lJTI14_12@PAGE
Lloh63:
	add	x11, x11, lJTI14_12@PAGEOFF
	adr	x9, LBB14_319
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB14_319:                              ; %liza___liza_reactor_error.exit.i.i850.i
                                        ;   in Loop: Header=BB14_82 Depth=2
	mov	w9, w23
	mov	w8, #1                          ; =0x1
	orr	w8, w8, w19
	cbnz	w8, LBB14_96
LBB14_320:                              ;   in Loop: Header=BB14_82 Depth=2
	mov	w23, w22
	mov	w8, #1                          ; =0x1
	ldr	x21, [sp, #1336]                ; 8-byte Folded Reload
	ldr	w19, [sp, #1332]                ; 4-byte Folded Reload
	ldr	w22, [sp, #1368]                ; 4-byte Folded Reload
	str	w23, [sp, #1384]                ; 4-byte Folded Spill
	ldr	x23, [sp, #1344]                ; 8-byte Folded Reload
	str	w8, [sp, #1424]                 ; 4-byte Folded Spill
	mov	x28, x12
	str	w20, [sp, #1392]                ; 4-byte Folded Spill
	str	w9, [sp, #1456]                 ; 4-byte Folded Spill
	b	LBB14_110
LBB14_321:                              ; %b61_to_b13.i.loopexit
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	w9, [sp, #2660]
	ldr	w8, [sp, #2664]
	mov	x20, x25
	ldr	w28, [sp, #1424]                ; 4-byte Folded Reload
	mov	x27, x0
	mov	x0, x24
	stp	w8, w9, [sp, #164]              ; 8-byte Folded Spill
	b	LBB14_29
LBB14_322:                              ; %b1.i147.i
                                        ;   in Loop: Header=BB14_30 Depth=1
	ldr	x10, [sp, #4328]
	ldr	x9, [sp, #4336]
	mov	w11, wzr
	ldr	x8, [sp, #4344]
	b	LBB14_58
LBB14_323:                              ; %liza_liza_proxy.exchange.exit
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	mov	w19, w9
	bl	_liza_rt_reactor_close
	cmp	w0, #0
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	csel	w19, w19, w8, eq
	bl	_liza_rt_region_close
	mov	w0, w19
	b	LBB14_4
LBB14_324:                              ; %b1.i.i49.i
	mov	w19, wzr
	b	LBB14_18
LBB14_325:                              ; %v256_trap.i
	brk	#0x1
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh46, Lloh47
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh54, Lloh55
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh60, Lloh61
	.loh AdrpAdd	Lloh62, Lloh63
	.cfi_endproc
	.section	__TEXT,__const
lJTI14_0:
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
	.byte	(LBB14_8-LBB14_8)>>2
lJTI14_1:
	.byte	(LBB14_45-LBB14_34)>>2
	.byte	(LBB14_34-LBB14_34)>>2
	.byte	(LBB14_39-LBB14_34)>>2
	.byte	(LBB14_38-LBB14_34)>>2
	.byte	(LBB14_36-LBB14_34)>>2
	.byte	(LBB14_37-LBB14_34)>>2
	.byte	(LBB14_44-LBB14_34)>>2
	.byte	(LBB14_40-LBB14_34)>>2
	.byte	(LBB14_41-LBB14_34)>>2
	.byte	(LBB14_43-LBB14_34)>>2
	.byte	(LBB14_42-LBB14_34)>>2
	.byte	(LBB14_35-LBB14_34)>>2
	.p2align	1, 0x0
lJTI14_2:
	.short	(LBB14_54-LBB14_54)>>2
	.short	(LBB14_75-LBB14_54)>>2
	.short	(LBB14_65-LBB14_54)>>2
	.short	(LBB14_70-LBB14_54)>>2
	.short	(LBB14_71-LBB14_54)>>2
	.short	(LBB14_66-LBB14_54)>>2
	.short	(LBB14_68-LBB14_54)>>2
	.short	(LBB14_74-LBB14_54)>>2
	.short	(LBB14_69-LBB14_54)>>2
	.short	(LBB14_73-LBB14_54)>>2
	.short	(LBB14_72-LBB14_54)>>2
	.short	(LBB14_64-LBB14_54)>>2
	.short	(LBB14_67-LBB14_54)>>2
	.p2align	1, 0x0
lJTI14_3:
	.short	(LBB14_322-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
	.short	(LBB14_57-LBB14_57)>>2
lJTI14_4:
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
	.byte	(LBB14_90-LBB14_90)>>2
lJTI14_5:
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
	.byte	(LBB14_94-LBB14_94)>>2
lJTI14_6:
	.byte	(LBB14_128-LBB14_117)>>2
	.byte	(LBB14_117-LBB14_117)>>2
	.byte	(LBB14_122-LBB14_117)>>2
	.byte	(LBB14_121-LBB14_117)>>2
	.byte	(LBB14_119-LBB14_117)>>2
	.byte	(LBB14_120-LBB14_117)>>2
	.byte	(LBB14_127-LBB14_117)>>2
	.byte	(LBB14_123-LBB14_117)>>2
	.byte	(LBB14_124-LBB14_117)>>2
	.byte	(LBB14_126-LBB14_117)>>2
	.byte	(LBB14_125-LBB14_117)>>2
	.byte	(LBB14_118-LBB14_117)>>2
lJTI14_7:
	.byte	(LBB14_172-LBB14_153)>>2
	.byte	(LBB14_153-LBB14_153)>>2
	.byte	(LBB14_166-LBB14_153)>>2
	.byte	(LBB14_165-LBB14_153)>>2
	.byte	(LBB14_163-LBB14_153)>>2
	.byte	(LBB14_164-LBB14_153)>>2
	.byte	(LBB14_171-LBB14_153)>>2
	.byte	(LBB14_167-LBB14_153)>>2
	.byte	(LBB14_168-LBB14_153)>>2
	.byte	(LBB14_170-LBB14_153)>>2
	.byte	(LBB14_169-LBB14_153)>>2
	.byte	(LBB14_162-LBB14_153)>>2
lJTI14_8:
	.byte	(LBB14_205-LBB14_188)>>2
	.byte	(LBB14_188-LBB14_188)>>2
	.byte	(LBB14_199-LBB14_188)>>2
	.byte	(LBB14_198-LBB14_188)>>2
	.byte	(LBB14_196-LBB14_188)>>2
	.byte	(LBB14_197-LBB14_188)>>2
	.byte	(LBB14_204-LBB14_188)>>2
	.byte	(LBB14_200-LBB14_188)>>2
	.byte	(LBB14_201-LBB14_188)>>2
	.byte	(LBB14_203-LBB14_188)>>2
	.byte	(LBB14_202-LBB14_188)>>2
	.byte	(LBB14_195-LBB14_188)>>2
lJTI14_9:
	.byte	(LBB14_245-LBB14_230)>>2
	.byte	(LBB14_230-LBB14_230)>>2
	.byte	(LBB14_239-LBB14_230)>>2
	.byte	(LBB14_238-LBB14_230)>>2
	.byte	(LBB14_236-LBB14_230)>>2
	.byte	(LBB14_237-LBB14_230)>>2
	.byte	(LBB14_244-LBB14_230)>>2
	.byte	(LBB14_240-LBB14_230)>>2
	.byte	(LBB14_241-LBB14_230)>>2
	.byte	(LBB14_243-LBB14_230)>>2
	.byte	(LBB14_242-LBB14_230)>>2
	.byte	(LBB14_235-LBB14_230)>>2
lJTI14_10:
	.byte	(LBB14_282-LBB14_261)>>2
	.byte	(LBB14_261-LBB14_261)>>2
	.byte	(LBB14_276-LBB14_261)>>2
	.byte	(LBB14_275-LBB14_261)>>2
	.byte	(LBB14_273-LBB14_261)>>2
	.byte	(LBB14_274-LBB14_261)>>2
	.byte	(LBB14_281-LBB14_261)>>2
	.byte	(LBB14_277-LBB14_261)>>2
	.byte	(LBB14_278-LBB14_261)>>2
	.byte	(LBB14_280-LBB14_261)>>2
	.byte	(LBB14_279-LBB14_261)>>2
	.byte	(LBB14_272-LBB14_261)>>2
lJTI14_11:
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
	.byte	(LBB14_314-LBB14_314)>>2
lJTI14_12:
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
	.byte	(LBB14_319-LBB14_319)>>2
lJTI14_13:
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
	.byte	(LBB14_103-LBB14_103)>>2
lJTI14_14:
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
	.byte	(LBB14_108-LBB14_108)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #224
	.cfi_def_cfa_offset 4480
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	bl	_liza_rt_cli_count
	cmp	w0, #1
	b.ne	LBB15_6
; %bb.1:
	str	wzr, [sp, #404]                 ; 4-byte Folded Spill
	mov	w0, #9004                       ; =0x232c
LBB15_2:                                ; %b16
	add	x2, sp, #3232
	mov	w1, #16                         ; =0x10
	bl	_liza_rt_reactor_create
	cmp	w0, #12
	b.hi	LBB15_4
; %bb.3:                                ; %b16
	mov	w8, w0
Lloh64:
	adrp	x9, lJTI15_0@PAGE
Lloh65:
	add	x9, x9, lJTI15_0@PAGEOFF
	adr	x10, LBB15_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_4:                                ; %liza___liza_reactor_error.exit.i
	mov	x19, xzr
	mov	w8, #1                          ; =0x1
	cmp	w8, #1
	b.ne	LBB15_15
LBB15_5:                                ; %b18
Lloh66:
	adrp	x0, l_text.main.v37@PAGE
Lloh67:
	add	x0, x0, l_text.main.v37@PAGEOFF
	mov	w1, #31                         ; =0x1f
	bl	_liza_rt_err_text
	b	LBB15_19
LBB15_6:                                ; %b1
	bl	_liza_rt_cli_count
	cmp	w0, #2
	b.ne	LBB15_9
; %bb.7:                                ; %b5
	bl	_liza_rt_cli_count
	cmp	w0, #2
	b.hs	LBB15_11
; %bb.8:
	mov	w0, #2                          ; =0x2
	b	LBB15_20
LBB15_9:                                ; %b3
Lloh68:
	adrp	x0, l_text.main.v9@PAGE
Lloh69:
	add	x0, x0, l_text.main.v9@PAGEOFF
LBB15_10:                               ; %common.ret
	mov	w1, #41                         ; =0x29
	bl	_liza_rt_err_text
	mov	w0, #2                          ; =0x2
	b	LBB15_20
LBB15_11:                               ; %b8
Lloh70:
	adrp	x1, l_text.main.v17@PAGE
Lloh71:
	add	x1, x1, l_text.main.v17@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_liza_rt_cli_equals
	cbnz	w0, LBB15_13
; %bb.12:                               ; %b9
Lloh72:
	adrp	x1, l_text.main.v21@PAGE
Lloh73:
	add	x1, x1, l_text.main.v21@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #11                         ; =0xb
	bl	_liza_rt_cli_equals
	cbz	w0, LBB15_30
LBB15_13:                               ; %b14
Lloh74:
	adrp	x1, l_text.main.v28@PAGE
Lloh75:
	add	x1, x1, l_text.main.v28@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_liza_rt_cli_equals
	mov	w8, w0
	mov	w0, wzr
	cmp	w8, #0
	cset	w8, ne
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	b	LBB15_2
LBB15_14:                               ; %b1.i
	ldr	x19, [sp, #3232]
	mov	w8, wzr
	cmp	w8, #1
	b.eq	LBB15_5
LBB15_15:                               ; %b19
	add	x1, sp, #1452
	mov	w0, #32768                      ; =0x8000
	bl	_liza_rt_region_create
	ldr	w8, [sp, #1452]
	cbnz	w8, LBB15_18
; %bb.16:                               ; %b3.i
	add	x4, sp, #1448
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	w3, #32768                      ; =0x8000
	str	x0, [sp, #144]                  ; 8-byte Folded Spill
	bl	_liza_rt_region_alloc
	ldr	w8, [sp, #1448]
	cbz	w8, LBB15_21
; %bb.17:                               ; %b5.i
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	bl	_liza_rt_region_close
LBB15_18:                               ; %b2.i
	mov	x0, x19
	bl	_liza_rt_reactor_close
LBB15_19:                               ; %common.ret
	mov	w0, #3                          ; =0x3
LBB15_20:                               ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #224
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB15_21:                               ; %v10_body.preheader.i
	mov	w1, #32768                      ; =0x8000
	mov	x20, x0
	bl	_bzero
	add	x8, sp, #193
	mov	x0, x19
	strb	wzr, [x8, #4095]
	add	x8, sp, #189
	strb	wzr, [x8, #4095]
	add	x8, sp, #188
	strb	wzr, [x8, #4095]
	add	x8, sp, #185
	strb	wzr, [x8, #4095]
	add	x8, sp, #184
	strb	wzr, [x8, #4095]
	add	x8, sp, #177
	strb	wzr, [x8, #4095]
	add	x8, sp, #173
	strb	wzr, [x8, #4095]
	add	x8, sp, #172
	strb	wzr, [x8, #4095]
	add	x8, sp, #169
	strb	wzr, [x8, #4095]
	add	x8, sp, #168
	strb	wzr, [x8, #4095]
	add	x8, sp, #161
	strb	wzr, [x8, #4095]
	add	x8, sp, #157
	strb	wzr, [x8, #4095]
	add	x8, sp, #156
	strb	wzr, [x8, #4095]
	add	x8, sp, #153
	strb	wzr, [x8, #4095]
	add	x8, sp, #152
	strb	wzr, [x8, #4095]
	add	x8, sp, #145
	strb	wzr, [x8, #4095]
	add	x8, sp, #141
	strb	wzr, [x8, #4095]
	add	x8, sp, #140
	strb	wzr, [x8, #4095]
	add	x8, sp, #137
	strb	wzr, [x8, #4095]
	add	x8, sp, #136
	strb	wzr, [x8, #4095]
	add	x8, sp, #129
	strb	wzr, [x8, #4095]
	add	x8, sp, #125
	strb	wzr, [x8, #4095]
	add	x8, sp, #124
	strb	wzr, [x8, #4095]
	add	x8, sp, #121
	strb	wzr, [x8, #4095]
	add	x8, sp, #120
	strb	wzr, [x8, #4095]
	add	x8, sp, #113
	strb	wzr, [x8, #4095]
	add	x8, sp, #109
	strb	wzr, [x8, #4095]
	add	x8, sp, #108
	strb	wzr, [x8, #4095]
	add	x8, sp, #105
	strb	wzr, [x8, #4095]
	add	x8, sp, #104
	strb	wzr, [x8, #4095]
	add	x8, sp, #97
	strb	wzr, [x8, #4095]
	add	x8, sp, #93
	strb	wzr, [x8, #4095]
	add	x8, sp, #92
	strb	wzr, [x8, #4095]
	add	x8, sp, #89
	strb	wzr, [x8, #4095]
	add	x8, sp, #88
	strb	wzr, [x8, #4095]
	add	x8, sp, #81
	strb	wzr, [x8, #4095]
	add	x8, sp, #77
	strb	wzr, [x8, #4095]
	add	x8, sp, #76
	strb	wzr, [x8, #4095]
	add	x8, sp, #73
	strb	wzr, [x8, #4095]
	add	x8, sp, #72
	strb	wzr, [x8, #4095]
	bl	_liza_rt_reactor_port
	lsr	x8, x0, #32
	str	x19, [sp, #680]                 ; 8-byte Folded Spill
	str	x20, [sp, #152]                 ; 8-byte Folded Spill
	cbz	x8, LBB15_25
; %bb.22:                               ; %v8_ok.i.i.i.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB15_24
; %bb.23:                               ; %v8_ok.i.i.i.i
Lloh76:
	adrp	x9, lJTI15_1@PAGE
Lloh77:
	add	x9, x9, lJTI15_1@PAGEOFF
	adr	x10, LBB15_24
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_24:                               ; %liza___liza_reactor_error.exit.i.i.i.i
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB15_25:                               ; %liza_net.reactor_port.exit.i.i
	cmp	w8, #1
	mov	w20, #3                         ; =0x3
	b.eq	LBB15_344
; %bb.26:                               ; %v12_ok.i.i
	mov	w0, w0
	bl	_liza_rt_print_u64
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB15_31
; %bb.27:                               ; %v12_ok.i.i
	cbz	w8, LBB15_345
; %bb.28:                               ; %v12_ok.i.i
	cmp	w8, #1
	b.eq	LBB15_34
; %bb.29:                               ; %v12_ok.i.i
	cmp	w8, #2
	b	LBB15_34
LBB15_30:                               ; %b12
Lloh78:
	adrp	x0, l_text.main.v25@PAGE
Lloh79:
	add	x0, x0, l_text.main.v25@PAGEOFF
	b	LBB15_10
LBB15_31:                               ; %v12_ok.i.i
	cmp	w8, #3
	b.eq	LBB15_34
; %bb.32:                               ; %v12_ok.i.i
	cmp	w8, #4
	b.eq	LBB15_34
; %bb.33:                               ; %v12_ok.i.i
	cmp	w8, #5
LBB15_34:                               ; %b18.i.i.i.i
	mov	w19, #1                         ; =0x1
LBB15_35:                               ; %liza_console.print_u64.exit.i.i
Lloh80:
	adrp	x0, l_text.liza_proxy.exchange.v21@PAGE
Lloh81:
	add	x0, x0, l_text.liza_proxy.exchange.v21@PAGEOFF
	mov	w1, #1                          ; =0x1
	bl	_liza_rt_write_text
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB15_39
; %bb.36:                               ; %liza_console.print_u64.exit.i.i
	cbz	w8, LBB15_43
; %bb.37:                               ; %liza_console.print_u64.exit.i.i
	cmp	w8, #1
	b.eq	LBB15_43
; %bb.38:                               ; %liza_console.print_u64.exit.i.i
	cmp	w8, #2
	b	LBB15_42
LBB15_39:                               ; %liza_console.print_u64.exit.i.i
	cmp	w8, #3
	b.eq	LBB15_42
; %bb.40:                               ; %liza_console.print_u64.exit.i.i
	cmp	w8, #4
	b.eq	LBB15_42
; %bb.41:                               ; %liza_console.print_u64.exit.i.i
	cmp	w8, #5
LBB15_42:                               ; %b13.i.i58.i.i
	mov	w8, #1                          ; =0x1
LBB15_43:                               ; %b12_to_b13.i.i
	orr	w8, w8, w19
	mov	w20, #3                         ; =0x3
	cbnz	w8, LBB15_344
; %bb.44:                               ; %b14.lr.ph.i.i
	add	x8, sp, #1456
	mov	w0, wzr
	mov	w17, wzr
	add	x9, x8, #65
	add	x10, x8, #378
	mov	w16, wzr
	str	x9, [sp, #568]                  ; 8-byte Folded Spill
	add	x9, x8, #90
	mov	w15, wzr
	str	x9, [sp, #560]                  ; 8-byte Folded Spill
	add	x9, x8, #161
	mov	x5, xzr
	str	x9, [sp, #552]                  ; 8-byte Folded Spill
	add	x9, x8, #186
	mov	x4, xzr
	str	x9, [sp, #544]                  ; 8-byte Folded Spill
	add	x9, x8, #257
	mov	x3, xzr
	str	x9, [sp, #536]                  ; 8-byte Folded Spill
	add	x9, x8, #282
	mov	x2, xzr
	str	x9, [sp, #528]                  ; 8-byte Folded Spill
	add	x9, x8, #353
	mov	x1, xzr
	str	x9, [sp, #520]                  ; 8-byte Folded Spill
	add	x9, x8, #449
	mov	x7, xzr
	stp	x9, x10, [sp, #504]             ; 16-byte Folded Spill
	add	x10, x8, #474
	add	x9, x8, #545
	stp	x9, x10, [sp, #488]             ; 16-byte Folded Spill
	add	x10, x8, #570
	add	x9, x8, #641
	stp	x9, x10, [sp, #472]             ; 16-byte Folded Spill
	add	x10, x8, #666
	add	x9, x8, #737
	add	x8, x8, #762
	stp	x9, x10, [sp, #456]             ; 16-byte Folded Spill
	add	x9, sp, #2272
	str	x8, [sp, #448]                  ; 8-byte Folded Spill
	add	x8, sp, #1456
	add	x14, x9, #260
	add	x9, x8, #260
	add	x8, sp, #72
	add	x10, sp, #3232
	ldrb	w8, [x8, #4095]
	add	x11, x10, #65
	mov	w6, wzr
	mov	w19, wzr
	str	xzr, [sp, #1200]                ; 8-byte Folded Spill
                                        ; implicit-def: $w25
                                        ; implicit-def: $w21
                                        ; implicit-def: $w28
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	add	x8, sp, #73
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1208]                ; 8-byte Folded Spill
	str	xzr, [sp, #1144]                ; 8-byte Folded Spill
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	add	x8, sp, #76
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1184]                ; 8-byte Folded Spill
	str	xzr, [sp, #1176]                ; 8-byte Folded Spill
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	add	x8, sp, #77
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1248]                ; 8-byte Folded Spill
	str	xzr, [sp, #1264]                ; 8-byte Folded Spill
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	add	x8, sp, #81
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1256]                ; 8-byte Folded Spill
	str	xzr, [sp, #1104]                ; 8-byte Folded Spill
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	add	x8, sp, #88
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1112]                ; 8-byte Folded Spill
	str	xzr, [sp, #1072]                ; 8-byte Folded Spill
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	add	x8, sp, #89
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1064]                ; 8-byte Folded Spill
	str	xzr, [sp, #1056]                ; 8-byte Folded Spill
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	add	x8, sp, #92
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1096]                ; 8-byte Folded Spill
	str	xzr, [sp, #1088]                ; 8-byte Folded Spill
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	add	x8, sp, #93
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1080]                ; 8-byte Folded Spill
	str	xzr, [sp, #1408]                ; 8-byte Folded Spill
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	add	x8, sp, #97
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1368]                ; 4-byte Folded Spill
	str	wzr, [sp, #1404]                ; 4-byte Folded Spill
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	add	x8, sp, #104
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1120]                ; 8-byte Folded Spill
	str	xzr, [sp, #1024]                ; 8-byte Folded Spill
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	add	x8, sp, #105
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1016]                ; 8-byte Folded Spill
	str	xzr, [sp, #1048]                ; 8-byte Folded Spill
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	add	x8, sp, #108
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1040]                ; 8-byte Folded Spill
	str	xzr, [sp, #1032]                ; 8-byte Folded Spill
	str	w8, [sp, #892]                  ; 4-byte Folded Spill
	add	x8, sp, #109
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #792]                 ; 8-byte Folded Spill
	str	xzr, [sp, #800]                 ; 8-byte Folded Spill
	str	w8, [sp, #896]                  ; 4-byte Folded Spill
	add	x8, sp, #113
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1416]                ; 8-byte Folded Spill
	str	xzr, [sp, #1424]                ; 8-byte Folded Spill
	str	w8, [sp, #900]                  ; 4-byte Folded Spill
	add	x8, sp, #120
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1432]                ; 8-byte Folded Spill
	str	xzr, [sp, #952]                 ; 8-byte Folded Spill
	str	w8, [sp, #908]                  ; 4-byte Folded Spill
	add	x8, sp, #121
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #924]                 ; 4-byte Folded Spill
	str	xzr, [sp, #928]                 ; 8-byte Folded Spill
	str	w8, [sp, #904]                  ; 4-byte Folded Spill
	add	x8, sp, #124
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #944]                 ; 4-byte Folded Spill
	str	xzr, [sp, #936]                 ; 8-byte Folded Spill
	str	w8, [sp, #916]                  ; 4-byte Folded Spill
	add	x8, sp, #125
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1336]                ; 8-byte Folded Spill
	str	xzr, [sp, #1328]                ; 8-byte Folded Spill
	str	w8, [sp, #912]                  ; 4-byte Folded Spill
	add	x8, sp, #129
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1320]                ; 8-byte Folded Spill
	str	xzr, [sp, #1312]                ; 8-byte Folded Spill
	str	w8, [sp, #920]                  ; 4-byte Folded Spill
	add	x8, sp, #136
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1304]                ; 8-byte Folded Spill
	str	wzr, [sp, #1300]                ; 4-byte Folded Spill
	str	w8, [sp, #780]                  ; 4-byte Folded Spill
	add	x8, sp, #137
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1288]                ; 4-byte Folded Spill
	str	wzr, [sp, #1280]                ; 4-byte Folded Spill
	str	w8, [sp, #808]                  ; 4-byte Folded Spill
	add	x8, sp, #140
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1276]                ; 4-byte Folded Spill
	str	xzr, [sp, #1240]                ; 8-byte Folded Spill
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	add	x8, sp, #141
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1008]                ; 4-byte Folded Spill
	str	wzr, [sp, #1000]                ; 4-byte Folded Spill
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	add	x8, sp, #145
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #968]                 ; 8-byte Folded Spill
	str	xzr, [sp, #760]                 ; 8-byte Folded Spill
	str	w8, [sp, #168]                  ; 4-byte Folded Spill
	add	x8, sp, #152
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #392]                 ; 8-byte Folded Spill
	str	xzr, [sp, #992]                 ; 8-byte Folded Spill
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	add	x8, sp, #153
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #984]                 ; 8-byte Folded Spill
	str	xzr, [sp, #976]                 ; 8-byte Folded Spill
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	add	x8, sp, #156
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1232]                ; 4-byte Folded Spill
	str	wzr, [sp, #1228]                ; 4-byte Folded Spill
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	add	x8, sp, #157
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1216]                ; 4-byte Folded Spill
	str	xzr, [sp, #1192]                ; 8-byte Folded Spill
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	add	x8, sp, #161
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1136]                ; 8-byte Folded Spill
	str	xzr, [sp, #1128]                ; 8-byte Folded Spill
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	add	x8, sp, #168
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1168]                ; 8-byte Folded Spill
	str	xzr, [sp, #1160]                ; 8-byte Folded Spill
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	add	x8, sp, #169
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1152]                ; 8-byte Folded Spill
	str	wzr, [sp, #164]                 ; 4-byte Folded Spill
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	add	x8, sp, #172
	ldrb	w8, [x8, #4095]
	str	x9, [sp, #440]                  ; 8-byte Folded Spill
	str	x14, [sp, #696]                 ; 8-byte Folded Spill
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	add	x8, sp, #173
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	add	x8, sp, #177
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	add	x8, sp, #184
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	add	x8, sp, #185
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	add	x8, sp, #188
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	add	x8, sp, #189
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	add	x8, sp, #193
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	eor	w8, w8, #0x1
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	add	x8, x10, #90
	stp	x8, x11, [sp, #128]             ; 16-byte Folded Spill
	add	x11, x10, #161
	add	x8, x10, #186
	stp	x8, x11, [sp, #112]             ; 16-byte Folded Spill
	add	x11, x10, #257
	add	x8, x10, #282
	stp	x8, x11, [sp, #96]              ; 16-byte Folded Spill
	add	x11, x10, #353
	add	x8, x10, #378
	stp	x8, x11, [sp, #80]              ; 16-byte Folded Spill
	add	x11, x10, #449
	add	x8, x10, #474
	stp	x8, x11, [sp, #64]              ; 16-byte Folded Spill
	add	x11, x10, #545
	add	x8, x10, #570
	stp	x8, x11, [sp, #48]              ; 16-byte Folded Spill
	add	x11, x10, #641
	add	x8, x10, #666
	stp	x8, x11, [sp, #32]              ; 16-byte Folded Spill
	add	x11, x10, #737
	add	x8, sp, #2272
	add	x10, x10, #762
	add	x12, x8, #161
	add	x22, x8, #186
	stp	x10, x11, [sp, #16]             ; 16-byte Folded Spill
	add	x11, x8, #570
	add	x10, x8, #65
	str	x11, [sp, #616]                 ; 8-byte Folded Spill
	add	x11, x14, #324
	add	x26, x8, #353
	str	x11, [sp, #728]                 ; 8-byte Folded Spill
	add	x11, x14, #356
	add	x24, x8, #378
	str	x11, [sp, #720]                 ; 8-byte Folded Spill
	add	x11, x8, #641
	add	x13, x8, #449
	str	x11, [sp, #608]                 ; 8-byte Folded Spill
	add	x11, x8, #666
	add	x27, x8, #474
	str	x10, [sp, #656]                 ; 8-byte Folded Spill
	add	x10, x8, #90
	add	x30, x8, #545
	str	x11, [sp, #600]                 ; 8-byte Folded Spill
	add	x11, x14, #420
	str	x10, [sp, #648]                 ; 8-byte Folded Spill
	add	x10, x8, #257
	str	x11, [sp, #712]                 ; 8-byte Folded Spill
	add	x11, x14, #452
	str	x10, [sp, #632]                 ; 8-byte Folded Spill
	add	x10, x8, #282
	str	x11, [sp, #704]                 ; 8-byte Folded Spill
	add	x11, x8, #737
	add	x8, x8, #762
	str	x11, [sp, #592]                 ; 8-byte Folded Spill
	add	x11, x9, #324
	str	x8, [sp, #736]                  ; 8-byte Folded Spill
	add	x8, x9, #356
	stp	x8, x11, [sp, #424]             ; 16-byte Folded Spill
	add	x11, x9, #420
	add	x8, x9, #452
	stp	x8, x11, [sp, #408]             ; 16-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w11, #1                         ; =0x1
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x22, [sp, #584]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x24, [sp, #576]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x30, [sp, #744]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x12, [sp, #640]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x10, [sp, #664]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x26, [sp, #672]                 ; 8-byte Folded Spill
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x13, [sp, #752]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x27, [sp, #624]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #812]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #888]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #264]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1388]                 ; 4-byte Folded Spill
	str	w8, [sp, #1360]                 ; 4-byte Folded Spill
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	str	w8, [sp, #1440]                 ; 4-byte Folded Spill
	str	w8, [sp, #1376]                 ; 4-byte Folded Spill
	b	LBB15_47
LBB15_45:                               ;   in Loop: Header=BB15_47 Depth=1
	ldr	x26, [sp, #672]                 ; 8-byte Folded Reload
	str	wzr, [sp, #1392]                ; 4-byte Folded Spill
LBB15_46:                               ; %b61_to_b13.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	w10, [x21]
	ldrb	w9, [x23, #2]
	add	x11, sp, #71
	ldrh	w8, [x23]
	ldr	x13, [sp, #752]                 ; 8-byte Folded Reload
	ldr	w20, [sp, #692]                 ; 4-byte Folded Reload
	str	w10, [sp, #4156]
	ldr	w10, [sp, #2272]
	ldr	w15, [sp, #2724]
	mov	w19, w20
	strb	w9, [x11, #4095]
	ldrb	w9, [x12, #2]
	str	w10, [sp, #1376]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2276]
	ldr	w11, [sp, #2304]
	strh	w8, [sp, #4164]
	ldrh	w8, [x21, #4]
	ldr	w17, [sp, #2736]
	str	w10, [sp, #244]                 ; 4-byte Folded Spill
	add	x10, sp, #59
	ldr	w0, [sp, #2740]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2280]
	ldrh	w9, [x22, #4]
	strh	w8, [sp, #4160]
	ldrh	w8, [x12]
	ldr	x4, [sp, #2792]
	str	x10, [sp, #1336]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2288]
	ldr	x5, [sp, #2800]
	strh	w8, [sp, #4152]
	ldr	w8, [x22]
	ldrh	w28, [sp, #2830]
	str	x10, [sp, #1328]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2296]
	ldrh	w21, [sp, #2926]
	strh	w9, [sp, #4148]
	ldrb	w9, [x7, #2]
	ldrh	w25, [sp, #3022]
	str	x10, [sp, #1320]                ; 8-byte Folded Spill
	add	x10, sp, #47
	ldr	w6, [sp, #3028]
	str	w8, [sp, #4144]
	ldrh	w8, [x7]
	ldr	x7, [sp, #2312]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #664]                 ; 8-byte Folded Reload
	strh	w8, [sp, #4140]
	ldr	w8, [x10]
	ldrh	w9, [x10, #4]
	add	x10, sp, #35
	str	w11, [sp, #264]                 ; 4-byte Folded Spill
	ldr	w11, [sp, #2308]
	str	w8, [sp, #4132]
	ldrh	w8, [x26]
	strh	w9, [sp, #4136]
	ldrb	w9, [x26, #2]
	strh	w8, [sp, #4128]
	ldr	w8, [x24]
	strb	w9, [x10, #4095]
	add	x10, sp, #23
	ldrh	w9, [x24, #4]
	str	w8, [sp, #4120]
	ldrh	w8, [x13]
	strh	w9, [sp, #4124]
	ldrb	w9, [x13, #2]
	strh	w8, [sp, #4116]
	ldr	w8, [x27]
	strb	w9, [x10, #4095]
	add	x10, sp, #11
	ldrh	w9, [x27, #4]
	str	w8, [sp, #4108]
	ldrh	w8, [x30]
	strh	w9, [sp, #4112]
	ldrb	w9, [x30, #2]
	strh	w8, [sp, #4104]
	ldr	w8, [x16]
	strb	w9, [x10, #4095]
	ldrh	w9, [x16, #4]
	ldr	w10, [sp, #2372]
	str	w8, [sp, #4096]
	ldrh	w8, [x1]
	ldr	w16, [sp, #2728]
	strh	w9, [sp, #4100]
	ldrb	w9, [x1, #2]
	ldr	x1, [sp, #2760]
	strh	w8, [sp, #4092]
	ldr	w8, [x2]
	strb	w9, [sp, #4094]
	ldrh	w9, [x2, #4]
	ldr	x2, [sp, #2768]
	str	w8, [sp, #4084]
	ldrh	w8, [x3]
	strh	w9, [sp, #4088]
	ldrb	w9, [x3, #2]
	ldr	x3, [sp, #2776]
	strh	w8, [sp, #4080]
	ldr	x8, [sp, #2408]
	strb	w9, [sp, #4082]
	ldrh	w9, [x14, #4]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2416]
	strh	w9, [sp, #4076]
	ldr	w9, [sp, #2468]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2424]
	str	w11, [sp, #240]                 ; 4-byte Folded Spill
	ldr	x11, [sp, #2320]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2432]
	str	x11, [sp, #1312]                ; 8-byte Folded Spill
	ldr	x11, [sp, #2328]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2436]
	str	x11, [sp, #1304]                ; 8-byte Folded Spill
	ldrb	w11, [sp, #2336]
	str	w8, [sp, #1208]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2440]
	str	w11, [sp, #388]                 ; 4-byte Folded Spill
	ldr	w11, [sp, #2340]
	str	w8, [sp, #1212]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2444]
	str	w11, [sp, #1300]                ; 4-byte Folded Spill
	ldr	w11, [sp, #2344]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2445]
	str	w11, [sp, #1288]                ; 4-byte Folded Spill
	ldrb	w11, [sp, #2348]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2446]
	str	w11, [sp, #384]                 ; 4-byte Folded Spill
	ldrb	w11, [sp, #2349]
	str	w8, [sp, #176]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2448]
	str	w11, [sp, #380]                 ; 4-byte Folded Spill
	ldrh	w11, [sp, #2350]
	str	w8, [sp, #1200]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2452]
	str	w11, [sp, #192]                 ; 4-byte Folded Spill
	ldr	w11, [sp, #2352]
	str	w8, [sp, #1204]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2456]
	str	w11, [sp, #1280]                ; 4-byte Folded Spill
	ldr	w11, [sp, #2356]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2457]
	str	w11, [sp, #1276]                ; 4-byte Folded Spill
	ldrb	w11, [sp, #2360]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2464]
	str	w11, [sp, #360]                 ; 4-byte Folded Spill
	ldrb	w11, [sp, #2361]
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2472]
	str	w11, [sp, #356]                 ; 4-byte Folded Spill
	ldr	w11, [sp, #2368]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2480]
	str	w11, [sp, #1440]                ; 4-byte Folded Spill
	ldr	x11, [sp, #2376]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2488]
	str	x11, [sp, #1256]                ; 8-byte Folded Spill
	ldr	x11, [sp, #2384]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2500]
	str	x11, [sp, #1264]                ; 8-byte Folded Spill
	ldr	x11, [sp, #2392]
	stp	w9, w8, [sp, #224]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2504]
	ldr	w9, [sp, #2564]
	str	x11, [sp, #1248]                ; 8-byte Folded Spill
	ldr	w11, [sp, #2400]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2512]
	str	w11, [sp, #280]                 ; 4-byte Folded Spill
	ldr	w11, [sp, #2404]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2520]
	stp	w11, w10, [sp, #232]            ; 8-byte Folded Spill
	ldr	w11, [sp, #2496]
	str	x8, [sp, #1072]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2528]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2532]
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2536]
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2540]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2541]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2542]
	str	w8, [sp, #184]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2544]
	str	w8, [sp, #1104]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2548]
	str	w8, [sp, #1108]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2552]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2553]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2560]
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2568]
	str	x8, [sp, #1032]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2576]
	str	x8, [sp, #1040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2584]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2592]
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2596]
	stp	w9, w8, [sp, #216]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2600]
	ldr	w9, [sp, #2852]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2608]
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2616]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2720]
	str	w8, [sp, #920]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2732]
	str	w8, [sp, #912]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2733]
	str	w8, [sp, #916]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2734]
	str	w8, [sp, #172]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2744]
	str	w8, [sp, #904]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2745]
	str	w8, [sp, #908]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2752]
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2756]
	str	w8, [sp, #828]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2784]
	str	w8, [sp, #888]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2788]
	str	w8, [sp, #824]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #2808]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2816]
	str	w8, [sp, #900]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2820]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2824]
	str	w8, [sp, #932]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2828]
	str	w8, [sp, #896]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2829]
	str	w8, [sp, #892]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2832]
	str	w8, [sp, #928]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2836]
	str	w8, [sp, #924]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2840]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2841]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2848]
	str	w8, [sp, #1360]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2856]
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2864]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2872]
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2880]
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2884]
	stp	w9, w8, [sp, #200]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2888]
	ldr	w9, [sp, #2948]
	str	x8, [sp, #392]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2896]
	str	x8, [sp, #760]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2904]
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2912]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2916]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2920]
	str	w8, [sp, #1008]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2924]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2925]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2928]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2932]
	str	w8, [sp, #1244]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2936]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2937]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2944]
	str	w8, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2952]
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2960]
	str	x8, [sp, #1160]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2968]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2976]
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2980]
	stp	w9, w8, [sp, #208]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2984]
	ldrb	w9, [sp, #3032]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2992]
	str	w9, [sp, #372]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #3033]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3000]
	str	w9, [sp, #376]                  ; 4-byte Folded Spill
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3008]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3012]
	str	w8, [sp, #1216]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3016]
	str	w8, [sp, #1228]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3020]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3021]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3024]
	str	w8, [sp, #1232]                 ; 4-byte Folded Spill
	ldr	w8, [x14]
	str	w8, [sp, #4072]
	ldr	w8, [sp, #1392]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_344
LBB15_47:                               ; %b14.i.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB15_98 Depth 2
	str	w0, [sp, #864]                  ; 4-byte Folded Spill
	ldr	x0, [sp, #680]                  ; 8-byte Folded Reload
	str	x1, [sp, #856]                  ; 8-byte Folded Spill
	mov	w1, #1000                       ; =0x3e8
	stp	w11, w6, [sp, #248]             ; 8-byte Folded Spill
	str	x7, [sp, #256]                  ; 8-byte Folded Spill
	str	x5, [sp, #832]                  ; 8-byte Folded Spill
	str	x4, [sp, #880]                  ; 8-byte Folded Spill
	str	x3, [sp, #840]                  ; 8-byte Folded Spill
	str	x2, [sp, #848]                  ; 8-byte Folded Spill
	str	w17, [sp, #868]                 ; 4-byte Folded Spill
	str	w16, [sp, #872]                 ; 4-byte Folded Spill
	str	w15, [sp, #876]                 ; 4-byte Folded Spill
	bl	_liza_rt_reactor_poll
	lsr	x8, x0, #32
	cbnz	x8, LBB15_49
; %bb.48:                               ; %b1.i.i95.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	w13, [sp, #948]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #964]                 ; 4-byte Folded Reload
	mov	w9, wzr
	ldr	w0, [sp, #816]                  ; 4-byte Folded Reload
	ldr	w15, [sp, #192]                 ; 4-byte Folded Reload
	ldr	w16, [sp, #176]                 ; 4-byte Folded Reload
	ldr	w17, [sp, #184]                 ; 4-byte Folded Reload
	cmp	w9, #1
	b.eq	LBB15_63
	b	LBB15_64
LBB15_49:                               ; %v8_ok.i.i77.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	sub	w9, w8, #1
	ldr	w13, [sp, #948]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #964]                 ; 4-byte Folded Reload
	ldr	w0, [sp, #816]                  ; 4-byte Folded Reload
	ldr	w15, [sp, #192]                 ; 4-byte Folded Reload
	cmp	w9, #11
	ldr	w16, [sp, #176]                 ; 4-byte Folded Reload
	ldr	w17, [sp, #184]                 ; 4-byte Folded Reload
	b.hi	LBB15_61
; %bb.50:                               ; %v8_ok.i.i77.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
Lloh82:
	adrp	x12, lJTI15_2@PAGE
Lloh83:
	add	x12, x12, lJTI15_2@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB15_51
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_51:                               ; %b4.i.i.i93.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB15_62
LBB15_52:                               ; %b34.i.i.i88.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #11                         ; =0xb
	b	LBB15_62
LBB15_53:                               ; %b13.i.i.i90.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB15_62
LBB15_54:                               ; %b16.i.i.i89.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB15_62
LBB15_55:                               ; %b10.i.i.i91.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #3                          ; =0x3
	b	LBB15_62
LBB15_56:                               ; %b7.i.i.i92.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB15_62
LBB15_57:                               ; %b22.i.i.i87.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB15_62
LBB15_58:                               ; %b25.i.i.i86.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB15_62
LBB15_59:                               ; %b31.i.i.i80.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #10                         ; =0xa
	b	LBB15_62
LBB15_60:                               ; %b28.i.i.i85.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB15_62
LBB15_61:                               ; %b36.i.i.i94.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #6                          ; =0x6
LBB15_62:                               ; %liza___liza_reactor_error.exit.i.i81.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB15_64
LBB15_63:                               ; %b17.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w9, #1                          ; =0x1
	mov	w10, #3                         ; =0x3
	mov	w26, wzr
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB15_65
LBB15_64:                               ;   in Loop: Header=BB15_47 Depth=1
	mov	w26, #1                         ; =0x1
	mov	w10, w19
LBB15_65:                               ; %b22_to_b23.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	add	x9, sp, #35
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldrh	w8, [sp, #4128]
	ldrb	w9, [x9, #4095]
	str	w10, [sp, #692]                 ; 4-byte Folded Spill
	add	x3, sp, #1, lsl #12             ; =4096
	cmp	w12, #1
	ldr	w12, [sp, #1376]                ; 4-byte Folded Reload
	ldr	w10, [sp, #4120]
	strb	w9, [sp, #4006]
	ldrh	w9, [sp, #4116]
	add	x6, sp, #1, lsl #12             ; =4096
	ldrh	w11, [sp, #4124]
	strh	w8, [sp, #4004]
	mov	w8, #8                          ; =0x8
	csinc	w8, w8, wzr, ne
	cmp	w12, #1
	strh	w9, [sp, #4052]
	ldrh	w9, [sp, #4112]
	str	w10, [sp, #4056]
	csel	w8, wzr, w8, eq
	strh	w11, [sp, #4060]
	add	x10, sp, #23
	ldr	w11, [sp, #1352]                ; 4-byte Folded Reload
	ldrb	w10, [x10, #4095]
	cmp	w8, #8
	strh	w9, [sp, #4048]
	add	x9, sp, #11
	ccmp	w11, #1, #0, eq
	mov	w11, #2                         ; =0x2
	ldrb	w9, [x9, #4095]
	strb	w10, [sp, #4054]
	ldr	w10, [sp, #4108]
	csel	w8, w11, w8, eq
	ldr	w11, [sp, #1344]                ; 4-byte Folded Reload
	add	x27, sp, #1, lsl #12            ; =4096
	cmp	w8, #8
	strb	w9, [sp, #4042]
	ldr	w9, [sp, #4096]
	str	w10, [sp, #4044]
	ldrh	w10, [sp, #4104]
	ccmp	w11, #1, #0, eq
	mov	w11, #3                         ; =0x3
	str	w9, [sp, #4032]
	ldrh	w9, [sp, #4092]
	csel	w8, w11, w8, eq
	strh	w10, [sp, #4040]
	ldrh	w10, [sp, #4100]
	cmp	w8, #8
	mov	w11, #4                         ; =0x4
	strh	w9, [sp, #4028]
	ccmp	w13, #1, #0, eq
	ldr	w9, [sp, #4084]
	strh	w10, [sp, #4036]
	ldrb	w10, [sp, #4094]
	csel	w8, w11, w8, eq
	mov	w11, #5                         ; =0x5
	cmp	w8, #8
	str	w9, [sp, #4020]
	ldrb	w9, [sp, #4082]
	strb	w10, [sp, #4030]
	ldrh	w10, [sp, #4088]
	ccmp	w14, #1, #0, eq
	csel	w8, w11, w8, eq
	strb	w9, [sp, #4018]
	ldr	w9, [sp, #1360]                 ; 4-byte Folded Reload
	strh	w10, [sp, #4024]
	ldrh	w10, [sp, #4080]
	cmp	w8, #8
	ccmp	w9, #1, #0, eq
	ldrh	w9, [sp, #4076]
	add	x20, sp, #1, lsl #12            ; =4096
	strh	w10, [sp, #4016]
	mov	w10, #6                         ; =0x6
	add	x30, sp, #1, lsl #12            ; =4096
	csel	w8, w10, w8, eq
	strh	w9, [sp, #4012]
	ldr	w9, [sp, #1388]                 ; 4-byte Folded Reload
	cmp	w8, #8
	ldr	w10, [sp, #4072]
	add	x7, sp, #1, lsl #12             ; =4096
	ccmp	w9, #1, #0, eq
	mov	w9, #7                          ; =0x7
	add	x11, sp, #1, lsl #12            ; =4096
	csel	w19, w9, w8, eq
	ldr	w8, [sp, #172]                  ; 4-byte Folded Reload
	str	w10, [sp, #4008]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	strh	w8, [sp, #4050]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x1, sp, #4092
	strh	w15, [sp, #4070]
	add	x15, sp, #4072
	add	x2, sp, #1, lsl #12             ; =4096
	strh	w16, [sp, #4068]
	add	x16, sp, #4080
	add	x3, x3, #8
	strh	w17, [sp, #4066]
	add	x17, sp, #4084
	add	x6, x6, #12
	add	x27, x27, #20
	add	x20, x20, #24
	add	x30, x30, #32
	add	x8, x8, #36
	add	x7, x7, #44
	add	x9, x9, #48
	add	x10, x10, #56
	add	x11, x11, #60
	add	x12, x12, #68
	strh	w0, [sp, #4064]
	strh	w28, [sp, #4038]
	strh	w21, [sp, #4026]
	strh	w25, [sp, #4014]
	str	w26, [sp, #1392]                ; 4-byte Folded Spill
	cbz	w26, LBB15_72
; %bb.66:                               ; %b22_to_b23.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	cmp	w19, #7
	b.hi	LBB15_72
; %bb.67:                               ; %b22_to_b23.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	w22, [sp, #404]                 ; 4-byte Folded Reload
	ldr	w0, [sp, #164]                  ; 4-byte Folded Reload
	and	w22, w22, w0
	tbnz	w22, #0, LBB15_71
; %bb.68:                               ; %b42.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	add	x1, sp, #1, lsl #12             ; =4096
	ldr	x0, [sp, #680]                  ; 8-byte Folded Reload
	add	x1, x1, #200
	bl	_liza_rt_reactor_accept
	cmp	w0, #12
	b.hi	LBB15_83
; %bb.69:                               ; %b42.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, w0
Lloh84:
	adrp	x11, lJTI15_3@PAGE
Lloh85:
	add	x11, x11, lJTI15_3@PAGEOFF
	adr	x9, LBB15_70
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	mov	w27, wzr
	br	x9
LBB15_70:                               ; %b1.i119.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	x24, [sp, #4296]
	ldr	x26, [sp, #4304]
	mov	w8, wzr
	ldr	x9, [sp, #4312]
	mov	w27, wzr
	b	LBB15_85
LBB15_71:                               ;   in Loop: Header=BB15_47 Depth=1
	add	x13, sp, #4038
	ldr	x0, [sp, #656]                  ; 8-byte Folded Reload
	ldr	x22, [sp, #584]                 ; 8-byte Folded Reload
	str	x13, [sp, #176]                 ; 8-byte Folded Spill
	add	x13, sp, #4026
	ldr	x25, [sp, #952]                 ; 8-byte Folded Reload
	str	x13, [sp, #184]                 ; 8-byte Folded Spill
	add	x13, sp, #4014
	add	x4, sp, #4050
	add	x26, sp, #4066
	add	x5, sp, #4068
	add	x28, sp, #4070
	str	x13, [sp, #192]                 ; 8-byte Folded Spill
	add	x13, sp, #4064
	b	LBB15_96
LBB15_72:                               ;   in Loop: Header=BB15_47 Depth=1
	add	x13, sp, #4014
	ldr	x0, [sp, #656]                  ; 8-byte Folded Reload
	ldr	x25, [sp, #952]                 ; 8-byte Folded Reload
	str	x13, [sp, #192]                 ; 8-byte Folded Spill
	add	x13, sp, #4038
	add	x4, sp, #4050
	str	x13, [sp, #176]                 ; 8-byte Folded Spill
	add	x13, sp, #4026
	add	x26, sp, #4066
	str	x13, [sp, #184]                 ; 8-byte Folded Spill
	add	x5, sp, #4068
	add	x28, sp, #4070
	add	x13, sp, #4064
	b	LBB15_96
LBB15_73:                               ; %b31.i.i106.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #10                        ; =0xa
	b	LBB15_84
LBB15_74:                               ; %b4.i.i118.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #1                         ; =0x1
	b	LBB15_84
LBB15_75:                               ; %b13.i.i115.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #4                         ; =0x4
	b	LBB15_84
LBB15_76:                               ; %b34.i.i113.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #11                        ; =0xb
	b	LBB15_84
LBB15_77:                               ; %b16.i.i114.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #5                         ; =0x5
	b	LBB15_84
LBB15_78:                               ; %b22.i.i112.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #7                         ; =0x7
	b	LBB15_84
LBB15_79:                               ; %b7.i.i117.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #2                         ; =0x2
	b	LBB15_84
LBB15_80:                               ; %b10.i.i116.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #3                         ; =0x3
	b	LBB15_84
LBB15_81:                               ; %b28.i.i110.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #9                         ; =0x9
	b	LBB15_84
LBB15_82:                               ; %b25.i.i111.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #8                         ; =0x8
	b	LBB15_84
LBB15_83:                               ; %b36.i.i120.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w27, #6                         ; =0x6
LBB15_84:                               ; %liza___liza_reactor_error.exit.i107.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	x24, xzr
	mov	x26, xzr
	mov	x9, xzr
	mov	w8, #1                          ; =0x1
LBB15_85:                               ; %liza_net.reactor_accept.exit.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	w20, [sp, #1412]                ; 4-byte Folded Reload
	ldr	w22, [sp, #812]                 ; 4-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB15_88
; %bb.86:                               ; %b45.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w0, #1                          ; =0x1
	add	x11, sp, #1, lsl #12            ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	lsl	w25, w0, w27
	mov	w0, #3827                       ; =0xef3
	add	x16, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x21, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	tst	w25, w0
	ldr	x0, [sp, #656]                  ; 8-byte Folded Reload
	add	x5, sp, #4072
	add	x28, sp, #4080
	add	x7, sp, #4084
	add	x30, sp, #4026
	add	x8, sp, #4092
	add	x12, sp, #1, lsl #12            ; =4096
	add	x9, sp, #4038
	add	x11, x11, #8
	add	x10, x10, #12
	add	x14, sp, #4050
	add	x16, x16, #20
	add	x15, x15, #24
	add	x17, sp, #4064
	add	x1, x1, #32
	add	x2, x2, #36
	add	x3, sp, #4066
	add	x6, x6, #44
	add	x19, x19, #48
	add	x20, sp, #4068
	add	x21, x21, #56
	add	x22, x22, #60
	add	x23, sp, #4070
	add	x24, x24, #68
	b.eq	LBB15_342
; %bb.87:                               ;   in Loop: Header=BB15_47 Depth=1
	mov	w25, #3                         ; =0x3
	add	x13, sp, #4014
	str	wzr, [sp, #1392]                ; 4-byte Folded Spill
	str	w25, [sp, #692]                 ; 4-byte Folded Spill
	str	x13, [sp, #816]                 ; 8-byte Folded Spill
	b	LBB15_95
LBB15_88:                               ; %b49.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	add	x2, sp, #1, lsl #12             ; =4096
	ldr	x0, [sp, #680]                  ; 8-byte Folded Reload
	mov	w1, #9003                       ; =0x232b
	add	x2, x2, #200
	str	x9, [sp, #1392]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_connect
	cmp	w0, #12
	b.hi	LBB15_90
; %bb.89:                               ; %b49.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, w0
Lloh86:
	adrp	x11, lJTI15_4@PAGE
Lloh87:
	add	x11, x11, lJTI15_4@PAGEOFF
	adr	x9, LBB15_90
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB15_90:                               ; %liza___liza_reactor_error.exit.i134.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	mov	x10, xzr
	mov	x9, xzr
	mov	x8, xzr
	mov	w11, #1                         ; =0x1
LBB15_91:                               ; %liza_net.reactor_connect.exit.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	w23, [sp, #692]                 ; 4-byte Folded Reload
	ldr	x13, [sp, #800]                 ; 8-byte Folded Reload
	cmp	w11, #1
	ldr	x14, [sp, #792]                 ; 8-byte Folded Reload
	ldr	w15, [sp, #1368]                ; 4-byte Folded Reload
	ldr	w16, [sp, #788]                 ; 4-byte Folded Reload
	ldr	w6, [sp, #784]                  ; 4-byte Folded Reload
	ldr	w7, [sp, #780]                  ; 4-byte Folded Reload
	ldr	w27, [sp, #808]                 ; 4-byte Folded Reload
	b.ne	LBB15_93
; %bb.92:                               ; %b51.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	x0, [sp, #680]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #1392]                 ; 8-byte Folded Reload
	mov	x1, x24
	mov	x2, x26
	bl	_liza_rt_reactor_disconnect
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	ldr	w6, [sp, #400]                  ; 4-byte Folded Reload
	mov	w9, #3                          ; =0x3
	ldp	w26, w19, [sp, #172]            ; 8-byte Folded Reload
	cmp	w8, #0
	add	x13, sp, #1, lsl #12            ; =4096
	add	x14, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x17, sp, #1, lsl #12            ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	ldr	w30, [sp, #816]                 ; 4-byte Folded Reload
	ldr	w7, [sp, #192]                  ; 4-byte Folded Reload
	ldr	w24, [sp, #184]                 ; 4-byte Folded Reload
	add	x8, sp, #4080
	add	x10, sp, #4084
	add	x11, sp, #4092
	add	x12, sp, #1, lsl #12            ; =4096
	csel	w23, w9, w23, ne
	add	x13, x13, #8
	add	x14, x14, #12
	add	x15, x15, #20
	add	x16, x16, #24
	add	x17, x17, #32
	add	x0, x0, #36
	add	x1, x1, #44
	add	x2, x2, #48
	add	x3, x3, #56
	add	x4, x4, #60
	add	x5, x5, #68
	add	x9, sp, #4072
	str	w6, [sp, #1392]                 ; 4-byte Folded Spill
	b	LBB15_94
LBB15_93:                               ; %v101_ok.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	w11, [sp, #1376]                ; 4-byte Folded Reload
	ldr	x5, [sp, #136]                  ; 8-byte Folded Reload
	mov	w21, #96                        ; =0x60
	ldr	x4, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #112]                  ; 8-byte Folded Reload
	str	w11, [sp, #3232]
	ldrh	w11, [sp, #4164]
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	ldr	x17, [sp, #88]                  ; 8-byte Folded Reload
	strb	w16, [sp, #3596]
	strh	w11, [x5]
	ldr	w11, [sp, #1300]                ; 4-byte Folded Reload
	ldr	x16, [sp, #80]                  ; 8-byte Folded Reload
	str	w15, [sp, #3592]
	ldr	x15, [sp, #72]                  ; 8-byte Folded Reload
	ldr	w12, [sp, #244]                 ; 4-byte Folded Reload
	str	w11, [sp, #3300]
	ldr	w11, [sp, #1288]                ; 4-byte Folded Reload
	ldr	x23, [sp, #24]                  ; 8-byte Folded Reload
	str	x14, [sp, #3672]
	ldr	x14, [sp, #64]                  ; 8-byte Folded Reload
	str	w11, [sp, #3304]
	ldr	w11, [sp, #384]                 ; 4-byte Folded Reload
	str	w12, [sp, #3236]
	ldr	x12, [sp, #1336]                ; 8-byte Folded Reload
	strb	w11, [sp, #3308]
	ldr	w11, [sp, #380]                 ; 4-byte Folded Reload
	str	x12, [sp, #3240]
	ldr	x12, [sp, #1328]                ; 8-byte Folded Reload
	strb	w11, [sp, #3309]
	ldr	w11, [sp, #192]                 ; 4-byte Folded Reload
	strb	w6, [sp, #3597]
	ldr	x6, [sp, #56]                   ; 8-byte Folded Reload
	strh	w11, [sp, #3310]
	ldr	w11, [sp, #1280]                ; 4-byte Folded Reload
	str	x12, [sp, #3248]
	ldr	x12, [sp, #1320]                ; 8-byte Folded Reload
	str	w11, [sp, #3312]
	ldr	w11, [sp, #1276]                ; 4-byte Folded Reload
	str	x12, [sp, #3256]
	ldr	w12, [sp, #264]                 ; 4-byte Folded Reload
	str	w11, [sp, #3316]
	ldr	w11, [sp, #360]                 ; 4-byte Folded Reload
	str	w12, [sp, #3264]
	ldr	w12, [sp, #240]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3320]
	ldr	w11, [sp, #4156]
	str	w12, [sp, #3268]
	ldr	x12, [sp, #256]                 ; 8-byte Folded Reload
	str	w11, [x4]
	ldr	w11, [sp, #1440]                ; 4-byte Folded Reload
	str	x12, [sp, #3272]
	ldr	x12, [sp, #1312]                ; 8-byte Folded Reload
	str	w11, [sp, #3328]
	ldr	w11, [sp, #236]                 ; 4-byte Folded Reload
	str	x12, [sp, #3280]
	ldr	x12, [sp, #1304]                ; 8-byte Folded Reload
	str	w11, [sp, #3332]
	ldr	x11, [sp, #1256]                ; 8-byte Folded Reload
	str	x12, [sp, #3288]
	ldr	w12, [sp, #388]                 ; 4-byte Folded Reload
	str	x11, [sp, #3336]
	ldr	x11, [sp, #1264]                ; 8-byte Folded Reload
	strb	w12, [sp, #3296]
	add	x12, sp, #71
	str	x11, [sp, #3344]
	ldr	x11, [sp, #1248]                ; 8-byte Folded Reload
	ldrb	w12, [x12, #4095]
	strb	w7, [sp, #3609]
	ldr	x7, [sp, #48]                   ; 8-byte Folded Reload
	str	x11, [sp, #3352]
	ldr	w11, [sp, #280]                 ; 4-byte Folded Reload
	strb	w12, [x5, #2]
	ldr	w12, [sp, #356]                 ; 4-byte Folded Reload
	str	w11, [sp, #3360]
	ldr	w11, [sp, #232]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3321]
	ldrh	w12, [sp, #4160]
	str	w11, [sp, #3364]
	ldr	x11, [sp, #1176]                ; 8-byte Folded Reload
	strh	w12, [x4, #4]
	ldr	w12, [sp, #296]                 ; 4-byte Folded Reload
	str	x11, [sp, #3368]
	ldr	x11, [sp, #1184]                ; 8-byte Folded Reload
	strb	w12, [sp, #3392]
	ldrh	w12, [sp, #4152]
	str	x11, [sp, #3376]
	ldr	x11, [sp, #1144]                ; 8-byte Folded Reload
	strh	w12, [x3]
	ldr	w12, [sp, #316]                 ; 4-byte Folded Reload
	str	x11, [sp, #3384]
	add	x11, sp, #59
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3417]
	ldr	w12, [sp, #4144]
	str	w20, [sp, #3604]
	ldr	x20, [sp, #40]                  ; 8-byte Folded Reload
	strb	w11, [x3, #2]
	ldr	w11, [sp, #1208]                ; 4-byte Folded Reload
	str	w12, [x2]
	ldr	w12, [sp, #288]                 ; 4-byte Folded Reload
	str	w11, [sp, #3396]
	ldr	w11, [sp, #1212]                ; 4-byte Folded Reload
	strb	w12, [sp, #3488]
	ldrh	w12, [sp, #4140]
	str	w11, [sp, #3400]
	ldr	w11, [sp, #312]                 ; 4-byte Folded Reload
	strh	w12, [x1]
	ldr	w12, [sp, #308]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3404]
	ldr	w11, [sp, #320]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3513]
	ldr	w12, [sp, #4132]
	strb	w11, [sp, #3405]
	ldr	w11, [sp, #176]                 ; 4-byte Folded Reload
	str	w12, [x0]
	ldr	w12, [sp, #168]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3406]
	ldr	w11, [sp, #1200]                ; 4-byte Folded Reload
	strb	w12, [sp, #3584]
	ldrh	w12, [sp, #4004]
	str	w11, [sp, #3408]
	ldr	w11, [sp, #1204]                ; 4-byte Folded Reload
	strh	w12, [x17]
	ldr	w12, [sp, #4056]
	str	w11, [sp, #3412]
	ldr	w11, [sp, #300]                 ; 4-byte Folded Reload
	str	w12, [x16]
	ldr	w12, [sp, #920]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3416]
	ldrh	w11, [sp, #4148]
	strb	w12, [sp, #3680]
	ldrh	w12, [sp, #4052]
	strh	w11, [x2, #4]
	ldr	w11, [sp, #1352]                ; 4-byte Folded Reload
	strh	w12, [x15]
	ldr	w12, [sp, #916]                 ; 4-byte Folded Reload
	str	w11, [sp, #3424]
	ldr	w11, [sp, #224]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3693]
	ldr	w12, [sp, #908]                 ; 4-byte Folded Reload
	str	w11, [sp, #3428]
	ldr	x11, [sp, #1080]                ; 8-byte Folded Reload
	str	w22, [sp, #3648]
	ldr	x22, [sp, #32]                  ; 8-byte Folded Reload
	str	x11, [sp, #3432]
	ldr	x11, [sp, #1088]                ; 8-byte Folded Reload
	strb	w12, [sp, #3705]
	ldr	w12, [sp, #4044]
	str	x11, [sp, #3440]
	ldr	x11, [sp, #1096]                ; 8-byte Folded Reload
	str	w12, [x14]
	ldr	w12, [sp, #900]                 ; 4-byte Folded Reload
	str	x11, [sp, #3448]
	ldr	w11, [sp, #248]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3776]
	ldrh	w12, [sp, #4040]
	str	w11, [sp, #3456]
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
	strh	w12, [x6]
	ldr	w12, [sp, #892]                 ; 4-byte Folded Reload
	str	w11, [sp, #3460]
	ldr	x11, [sp, #1056]                ; 8-byte Folded Reload
	strb	w12, [sp, #3789]
	ldr	w12, [sp, #328]                 ; 4-byte Folded Reload
	str	x11, [sp, #3464]
	ldr	x11, [sp, #1064]                ; 8-byte Folded Reload
	strb	w12, [sp, #3801]
	ldr	w12, [sp, #4032]
	str	x11, [sp, #3472]
	ldr	x11, [sp, #1072]                ; 8-byte Folded Reload
	str	w12, [x7]
	ldr	w12, [sp, #332]                 ; 4-byte Folded Reload
	str	x11, [sp, #3480]
	add	x11, sp, #47
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3872]
	ldrh	w12, [sp, #4028]
	str	x13, [sp, #3664]
	ldr	w13, [sp, #348]                 ; 4-byte Folded Reload
	strb	w11, [x1, #2]
	ldr	w11, [sp, #1112]                ; 4-byte Folded Reload
	strh	w12, [x20]
	ldr	w12, [sp, #340]                 ; 4-byte Folded Reload
	str	w11, [sp, #3492]
	ldr	w11, [sp, #1116]                ; 4-byte Folded Reload
	strb	w12, [sp, #3885]
	ldr	w12, [sp, #344]                 ; 4-byte Folded Reload
	str	w11, [sp, #3496]
	ldr	w11, [sp, #292]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3896]
	ldr	w12, [sp, #4020]
	strb	w11, [sp, #3500]
	ldr	w11, [sp, #304]                 ; 4-byte Folded Reload
	str	w12, [x22]
	ldr	x12, [sp, #1192]                ; 8-byte Folded Reload
	strb	w11, [sp, #3501]
	ldr	w11, [sp, #184]                 ; 4-byte Folded Reload
	str	x12, [sp, #3960]
	ldrh	w12, [sp, #4016]
	strh	w11, [sp, #3502]
	ldr	w11, [sp, #1104]                ; 4-byte Folded Reload
	strb	w13, [sp, #3897]
	ldr	w13, [sp, #352]                 ; 4-byte Folded Reload
	str	w11, [sp, #3504]
	ldr	w11, [sp, #1108]                ; 4-byte Folded Reload
	strh	w12, [x23]
	ldr	w12, [sp, #364]                 ; 4-byte Folded Reload
	str	w11, [sp, #3508]
	ldr	w11, [sp, #284]                 ; 4-byte Folded Reload
	strb	w13, [sp, #3968]
	ldr	w13, [sp, #376]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3512]
	ldrh	w11, [sp, #4136]
	strb	w12, [sp, #3980]
	ldr	w12, [sp, #368]                 ; 4-byte Folded Reload
	strh	w11, [x0, #4]
	ldr	w11, [sp, #1344]                ; 4-byte Folded Reload
	strb	w13, [sp, #3993]
	add	x13, sp, #3232
	umaddl	x13, w19, w21, x13
	str	w11, [sp, #3520]
	ldr	w11, [sp, #216]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3981]
	ldr	w12, [sp, #372]                 ; 4-byte Folded Reload
	ldr	x19, [sp, #16]                  ; 8-byte Folded Reload
	str	w11, [sp, #3524]
	ldr	x11, [sp, #1032]                ; 8-byte Folded Reload
	strb	w12, [sp, #3992]
	ldr	w12, [sp, #4008]
	str	x11, [sp, #3528]
	ldr	x11, [sp, #1040]                ; 8-byte Folded Reload
	strb	w27, [sp, #3608]
	str	x11, [sp, #3536]
	ldr	x11, [sp, #1048]                ; 8-byte Folded Reload
	str	w12, [x19]
	mov	x12, x7
	str	x11, [sp, #3544]
	ldr	w11, [sp, #276]                 ; 4-byte Folded Reload
	str	w11, [sp, #3552]
	ldr	w11, [sp, #220]                 ; 4-byte Folded Reload
	str	w11, [sp, #3556]
	ldr	x11, [sp, #1016]                ; 8-byte Folded Reload
	str	x11, [sp, #3560]
	ldr	x11, [sp, #1024]                ; 8-byte Folded Reload
	str	x11, [sp, #3568]
	ldr	x11, [sp, #1120]                ; 8-byte Folded Reload
	str	x11, [sp, #3576]
	ldrb	w11, [sp, #4006]
	strb	w11, [x17, #2]
	ldr	w11, [sp, #1404]                ; 4-byte Folded Reload
	str	w11, [sp, #3588]
	ldr	w11, [sp, #816]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3598]
	ldr	w11, [sp, #1408]                ; 4-byte Folded Reload
	str	w11, [sp, #3600]
	ldrh	w11, [sp, #4060]
	strh	w11, [x16, #4]
	ldr	w11, [sp, #948]                 ; 4-byte Folded Reload
	str	w11, [sp, #3616]
	ldr	w11, [sp, #776]                 ; 4-byte Folded Reload
	str	w11, [sp, #3620]
	ldr	x11, [sp, #952]                 ; 8-byte Folded Reload
	str	x11, [sp, #3624]
	ldr	x11, [sp, #1432]                ; 8-byte Folded Reload
	str	x11, [sp, #3632]
	ldr	x11, [sp, #1424]                ; 8-byte Folded Reload
	str	x11, [sp, #3640]
	ldr	w11, [sp, #772]                 ; 4-byte Folded Reload
	str	w11, [sp, #3652]
	ldr	x11, [sp, #1416]                ; 8-byte Folded Reload
	str	x11, [sp, #3656]
	ldrb	w11, [sp, #4054]
	strb	w11, [x15, #2]
	ldr	w11, [sp, #876]                 ; 4-byte Folded Reload
	str	w11, [sp, #3684]
	ldr	w11, [sp, #872]                 ; 4-byte Folded Reload
	str	w11, [sp, #3688]
	ldr	w11, [sp, #912]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3692]
	ldrh	w11, [sp, #4050]
	strh	w11, [sp, #3694]
	ldr	w11, [sp, #868]                 ; 4-byte Folded Reload
	str	w11, [sp, #3696]
	ldr	w11, [sp, #864]                 ; 4-byte Folded Reload
	str	w11, [sp, #3700]
	ldr	w11, [sp, #904]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3704]
	ldrh	w11, [sp, #4048]
	strh	w11, [x14, #4]
	ldr	w11, [sp, #964]                 ; 4-byte Folded Reload
	str	w11, [sp, #3712]
	ldr	w11, [sp, #828]                 ; 4-byte Folded Reload
	str	w11, [sp, #3716]
	ldr	x11, [sp, #856]                 ; 8-byte Folded Reload
	str	x11, [sp, #3720]
	ldr	x11, [sp, #848]                 ; 8-byte Folded Reload
	str	x11, [sp, #3728]
	ldr	x11, [sp, #840]                 ; 8-byte Folded Reload
	str	x11, [sp, #3736]
	ldr	w11, [sp, #888]                 ; 4-byte Folded Reload
	str	w11, [sp, #3744]
	ldr	w11, [sp, #824]                 ; 4-byte Folded Reload
	str	w11, [sp, #3748]
	ldr	x11, [sp, #880]                 ; 8-byte Folded Reload
	str	x11, [sp, #3752]
	ldr	x11, [sp, #832]                 ; 8-byte Folded Reload
	str	x11, [sp, #3760]
	ldr	x11, [sp, #936]                 ; 8-byte Folded Reload
	str	x11, [sp, #3768]
	ldrb	w11, [sp, #4042]
	strb	w11, [x6, #2]
	ldr	w11, [sp, #944]                 ; 4-byte Folded Reload
	str	w11, [sp, #3780]
	ldr	w11, [sp, #932]                 ; 4-byte Folded Reload
	str	w11, [sp, #3784]
	ldr	w11, [sp, #896]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3788]
	ldrh	w11, [sp, #4038]
	strh	w11, [sp, #3790]
	ldr	w11, [sp, #928]                 ; 4-byte Folded Reload
	str	w11, [sp, #3792]
	ldr	w11, [sp, #924]                 ; 4-byte Folded Reload
	str	w11, [sp, #3796]
	ldr	w11, [sp, #324]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3800]
	ldrh	w11, [sp, #4036]
	strh	w11, [x7, #4]
	ldr	w11, [sp, #1360]                ; 4-byte Folded Reload
	str	w11, [sp, #3808]
	ldr	w11, [sp, #200]                 ; 4-byte Folded Reload
	str	w11, [sp, #3812]
	ldr	x11, [sp, #976]                 ; 8-byte Folded Reload
	str	x11, [sp, #3816]
	ldr	x11, [sp, #984]                 ; 8-byte Folded Reload
	str	x11, [sp, #3824]
	ldr	x11, [sp, #992]                 ; 8-byte Folded Reload
	str	x11, [sp, #3832]
	ldr	w11, [sp, #268]                 ; 4-byte Folded Reload
	str	w11, [sp, #3840]
	ldr	w11, [sp, #204]                 ; 4-byte Folded Reload
	str	w11, [sp, #3844]
	ldr	x11, [sp, #392]                 ; 8-byte Folded Reload
	str	x11, [sp, #3848]
	ldr	x11, [sp, #760]                 ; 8-byte Folded Reload
	str	x11, [sp, #3856]
	ldr	x11, [sp, #968]                 ; 8-byte Folded Reload
	str	x11, [sp, #3864]
	ldrb	w11, [sp, #4030]
	strb	w11, [x20, #2]
	ldr	w11, [sp, #1000]                ; 4-byte Folded Reload
	str	w11, [sp, #3876]
	ldr	w11, [sp, #1008]                ; 4-byte Folded Reload
	str	w11, [sp, #3880]
	ldr	w11, [sp, #336]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3884]
	ldrh	w11, [sp, #4026]
	strh	w11, [sp, #3886]
	ldr	w11, [sp, #1240]                ; 4-byte Folded Reload
	str	w11, [sp, #3888]
	ldr	w11, [sp, #1244]                ; 4-byte Folded Reload
	str	w11, [sp, #3892]
	ldrh	w11, [sp, #4024]
	strh	w11, [x22, #4]
	ldr	w11, [sp, #1388]                ; 4-byte Folded Reload
	str	w11, [sp, #3904]
	ldr	w11, [sp, #208]                 ; 4-byte Folded Reload
	str	w11, [sp, #3908]
	ldr	x11, [sp, #1152]                ; 8-byte Folded Reload
	str	x11, [sp, #3912]
	ldr	x11, [sp, #1160]                ; 8-byte Folded Reload
	str	x11, [sp, #3920]
	ldr	x11, [sp, #1168]                ; 8-byte Folded Reload
	str	x11, [sp, #3928]
	ldr	w11, [sp, #272]                 ; 4-byte Folded Reload
	str	w11, [sp, #3936]
	ldr	w11, [sp, #212]                 ; 4-byte Folded Reload
	strb	wzr, [x13, #64]
	str	w11, [sp, #3940]
	ldr	x11, [sp, #1128]                ; 8-byte Folded Reload
	str	x11, [sp, #3944]
	ldr	x11, [sp, #1136]                ; 8-byte Folded Reload
	str	x11, [sp, #3952]
	ldrb	w11, [sp, #4018]
	strb	w11, [x23, #2]
	ldr	w11, [sp, #1216]                ; 4-byte Folded Reload
	str	wzr, [x13]
	str	w11, [sp, #3972]
	ldr	w11, [sp, #1228]                ; 4-byte Folded Reload
	str	wzr, [x13, #32]
	str	w11, [sp, #3976]
	ldrh	w11, [sp, #4014]
	strh	wzr, [x13, #76]
	strh	w11, [sp, #3982]
	ldr	w11, [sp, #1232]                ; 4-byte Folded Reload
	stur	xzr, [x13, #68]
	str	w11, [sp, #3984]
	ldr	w11, [sp, #252]                 ; 4-byte Folded Reload
	str	w11, [sp, #3988]
	ldrh	w11, [sp, #4012]
	stp	x10, x9, [x13, #40]
	ldr	w10, [sp, #3232]
	strh	w11, [x19, #4]
	ldr	x11, [sp, #1392]                ; 8-byte Folded Reload
	str	x8, [x13, #56]
	ldr	w8, [sp, #3264]
	str	w10, [sp, #1376]                ; 4-byte Folded Spill
	ldr	w10, [sp, #3236]
	str	w8, [sp, #264]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3268]
	stp	x24, x26, [x13, #8]
	stp	w8, w10, [sp, #240]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3272]
	ldr	x9, [sp, #3240]
	str	x11, [x13, #24]
	ldrh	w10, [sp, #3310]
	ldrh	w11, [sp, #3406]
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3280]
	ldrh	w24, [sp, #3502]
	strh	wzr, [x13, #88]
	ldrh	w30, [sp, #3598]
	ldrh	w26, [sp, #3694]
	str	x8, [sp, #1312]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3288]
	ldrb	w27, [sp, #3608]
	str	xzr, [x13, #80]
	ldrh	w28, [sp, #3790]
	ldrh	w21, [sp, #3886]
	str	x8, [sp, #1304]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3296]
	ldrh	w25, [sp, #3982]
	str	x9, [sp, #1336]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #3248]
	mov	x13, x6
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3300]
	mov	w7, w10
	str	x9, [sp, #1328]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #3256]
	mov	x10, x22
	str	w8, [sp, #1300]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3304]
	str	x9, [sp, #1320]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #3332]
	str	w8, [sp, #1288]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3308]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3309]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3312]
	str	w8, [sp, #1280]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3316]
	str	w8, [sp, #1276]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3320]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3321]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3328]
	str	w8, [sp, #1440]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3336]
	str	x8, [sp, #1256]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3344]
	str	x8, [sp, #1264]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3352]
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3360]
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3364]
	stp	w8, w9, [sp, #232]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3368]
	ldr	w9, [sp, #3428]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3376]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3384]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3392]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3396]
	str	w8, [sp, #1208]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3400]
	str	w8, [sp, #1212]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3404]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3405]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3408]
	str	w8, [sp, #1200]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #1204]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3416]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3417]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3424]
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3432]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3440]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3448]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3456]
	str	w8, [sp, #248]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3460]
	stp	w9, w8, [sp, #224]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3464]
	ldr	w9, [sp, #3524]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3472]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3480]
	str	x8, [sp, #1072]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3488]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3492]
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3496]
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3500]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3501]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3504]
	str	w8, [sp, #1104]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3508]
	str	w8, [sp, #1108]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3512]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3513]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3520]
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3528]
	str	x8, [sp, #1032]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3536]
	str	x8, [sp, #1040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3544]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3552]
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3556]
	stp	w9, w8, [sp, #216]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3560]
	ldr	w9, [sp, #3812]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3568]
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3576]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3584]
	str	w8, [sp, #168]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3588]
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3592]
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3596]
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3597]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3600]
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3604]
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3609]
	str	w8, [sp, #780]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3616]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3620]
	str	w8, [sp, #776]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3624]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3632]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3640]
	str	x8, [sp, #1424]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3648]
	str	w8, [sp, #812]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3652]
	str	w8, [sp, #772]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3656]
	str	x8, [sp, #1416]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3664]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3672]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3680]
	str	w8, [sp, #920]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3684]
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3688]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3692]
	str	w8, [sp, #912]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3693]
	str	w8, [sp, #916]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3696]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3700]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3704]
	str	w8, [sp, #904]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3705]
	str	w8, [sp, #908]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3712]
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3716]
	str	w8, [sp, #828]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3720]
	str	x8, [sp, #856]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3728]
	str	x8, [sp, #848]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3736]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3744]
	str	w8, [sp, #888]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3748]
	str	w8, [sp, #824]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3752]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3760]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3768]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3776]
	str	w8, [sp, #900]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3780]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3784]
	str	w8, [sp, #932]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3788]
	str	w8, [sp, #896]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3789]
	str	w8, [sp, #892]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3792]
	str	w8, [sp, #928]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3796]
	str	w8, [sp, #924]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3800]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3801]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3808]
	str	w8, [sp, #1360]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3816]
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3824]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3832]
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3840]
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3844]
	stp	w9, w8, [sp, #200]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3848]
	ldr	w9, [sp, #3908]
	str	x8, [sp, #392]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3856]
	str	x8, [sp, #760]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3864]
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3872]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3876]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3880]
	str	w8, [sp, #1008]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3884]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3885]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3888]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3892]
	str	w8, [sp, #1244]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3896]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3897]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3904]
	str	w8, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3912]
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3920]
	str	x8, [sp, #1160]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3928]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3936]
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3940]
	stp	w9, w8, [sp, #208]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3944]
	mov	x9, x19
	mov	w19, w11
	mov	x11, x20
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3952]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3960]
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3968]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3972]
	str	w8, [sp, #1216]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3976]
	str	w8, [sp, #1228]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3980]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3981]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3984]
	str	w8, [sp, #1232]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3988]
	str	w8, [sp, #252]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3992]
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3993]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	mov	x8, x23
	ldr	w23, [sp, #692]                 ; 4-byte Folded Reload
LBB15_94:                               ; %b56_to_b57.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldrh	w6, [x5]
	ldrb	w5, [x5, #2]
	add	x20, sp, #3214
	strh	w7, [sp, #3226]
	ldr	w7, [x4]
	ldrh	w22, [x9, #4]
	strb	w5, [sp, #3230]
	ldrh	w5, [x3]
	ldrb	w3, [x3, #2]
	strh	w24, [sp, #3202]
	ldr	w24, [x9]
	add	x9, sp, #3166
	strb	w3, [sp, #3218]
	ldr	w3, [x2]
	ldrh	w2, [x2, #4]
	ldrh	w4, [x4, #4]
	str	w23, [sp, #692]                 ; 4-byte Folded Spill
	add	x23, sp, #3226
	str	w3, [sp, #3208]
	ldrb	w3, [x1, #2]
	ldrh	w1, [x1]
	strh	w2, [sp, #3212]
	ldrh	w2, [x8]
	strh	w1, [sp, #3204]
	ldrh	w1, [x0, #4]
	ldr	w0, [x0]
	strh	w6, [sp, #3228]
	add	x6, sp, #3204
	strh	w1, [sp, #3200]
	ldrb	w1, [x17, #2]
	ldrh	w17, [x17]
	str	w0, [sp, #3196]
	ldr	x0, [sp, #656]                  ; 8-byte Folded Reload
	strh	w17, [sp, #3192]
	ldrh	w17, [x16, #4]
	ldr	w16, [x16]
	str	w7, [sp, #3220]
	add	x7, sp, #3148
	strh	w17, [sp, #3188]
	ldrb	w17, [x15, #2]
	ldrh	w15, [x15]
	str	w16, [sp, #3184]
	ldrh	w16, [x14, #4]
	ldr	w14, [x14]
	strh	w15, [sp, #3180]
	ldrh	w15, [x13]
	ldrb	w13, [x13, #2]
	str	w14, [sp, #3172]
	mov	w14, #1                         ; =0x1
	strb	w17, [sp, #3182]
	ldrb	w17, [x8, #2]
	add	x8, sp, #3156
	strh	w16, [sp, #3176]
	ldr	w16, [x12]
	ldrh	w12, [x12, #4]
	str	w14, [sp, #164]                 ; 4-byte Folded Spill
	ldrh	w14, [x11]
	ldrb	w11, [x11, #2]
	strh	w15, [sp, #3168]
	ldr	w15, [x10]
	ldrh	w10, [x10, #4]
	strh	w5, [sp, #3216]
	add	x5, sp, #3136
	strh	w19, [sp, #3214]
	add	x19, sp, #3208
	strb	w3, [sp, #3206]
	add	x3, sp, #3202
	strb	w1, [sp, #3194]
	add	x1, sp, #3192
	strh	w30, [sp, #3190]
	add	x30, sp, #3154
	strb	w13, [sp, #3170]
	add	x13, sp, #3142
	strh	w28, [sp, #3166]
	add	x28, sp, #3144
	strh	w12, [sp, #3164]
	add	x12, sp, #3160
	str	w16, [sp, #3160]
	add	x16, sp, #3180
	strb	w11, [sp, #3158]
	add	x11, sp, #3168
	strh	w14, [sp, #3156]
	add	x14, sp, #3178
	strh	w21, [sp, #3154]
	add	x21, sp, #3216
	strh	w10, [sp, #3152]
	add	x10, sp, #3172
	str	w15, [sp, #3148]
	add	x15, sp, #3184
	strb	w17, [sp, #3146]
	add	x17, sp, #3190
	strh	w2, [sp, #3144]
	add	x2, sp, #3196
	strh	w22, [sp, #3140]
	add	x22, sp, #3220
	str	w24, [sp, #3136]
	add	x24, sp, #3228
	str	w27, [sp, #808]                 ; 4-byte Folded Spill
	strh	w4, [sp, #3224]
	strh	w26, [sp, #3178]
	str	x13, [sp, #816]                 ; 8-byte Folded Spill
	strh	w25, [sp, #3142]
LBB15_95:                               ; %b57_to_b58.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldrh	w20, [x20]
	ldrh	w9, [x9]
	add	x13, sp, #3046
	ldrh	w3, [x3]
	ldrh	w23, [x23]
	add	x4, sp, #3082
	strh	w20, [sp, #3118]
	ldrh	w20, [x6]
	add	x27, sp, #3084
	ldrb	w6, [x6, #2]
	strh	w9, [sp, #3070]
	add	x26, sp, #3106
	ldr	w9, [x12]
	strh	w3, [sp, #3106]
	ldrb	w3, [x1, #2]
	strb	w6, [sp, #3110]
	ldrh	w6, [x2, #4]
	ldr	w2, [x2]
	str	w9, [sp, #3064]
	ldrh	w9, [x30]
	add	x30, sp, #3096
	str	w2, [sp, #3100]
	ldrh	w2, [x16]
	ldrh	w1, [x1]
	strh	w9, [sp, #3058]
	ldr	w9, [x7]
	ldrh	w25, [x24]
	strh	w2, [sp, #3084]
	ldrh	w2, [x10, #4]
	ldr	w10, [x10]
	strh	w23, [sp, #3130]
	ldrh	w23, [x21]
	ldrb	w21, [x21, #2]
	str	w10, [sp, #3076]
	ldrh	w10, [x11]
	ldrh	w14, [x14]
	ldrh	w17, [x17]
	strh	w1, [sp, #3096]
	ldrh	w1, [x15, #4]
	strh	w10, [sp, #3072]
	ldrh	w10, [x12, #4]
	ldrb	w24, [x24, #2]
	str	w9, [sp, #3052]
	ldr	x9, [sp, #816]                  ; 8-byte Folded Reload
	strh	w10, [sp, #3068]
	ldrb	w10, [x8, #2]
	ldrh	w8, [x8]
	strh	w25, [sp, #3132]
	ldr	w25, [x22]
	ldrh	w22, [x22, #4]
	strb	w10, [sp, #3062]
	ldrh	w10, [x7, #4]
	add	x7, sp, #3108
	strb	w21, [sp, #3122]
	ldr	w21, [x19]
	ldrh	w19, [x19, #4]
	strh	w10, [sp, #3056]
	ldrb	w10, [x28, #2]
	ldrh	w12, [x9]
	add	x9, sp, #3112
	str	x13, [sp, #192]                 ; 8-byte Folded Spill
	add	x13, sp, #3058
	strh	w14, [sp, #3082]
	ldrb	w14, [x11, #2]
	add	x11, sp, #3070
	strh	w17, [sp, #3094]
	ldr	w17, [x15]
	add	x15, sp, #3040
	strh	w1, [sp, #3092]
	ldrb	w1, [x16, #2]
	add	x16, sp, #3048
	stp	x11, x13, [sp, #176]            ; 16-byte Folded Spill
	add	x13, sp, #3094
	ldrh	w11, [x28]
	add	x28, sp, #3130
	strb	w10, [sp, #3050]
	mov	x10, x5
	strb	w24, [sp, #3134]
	ldr	x24, [sp, #576]                 ; 8-byte Folded Reload
	str	w25, [sp, #3124]
	ldr	x25, [sp, #952]                 ; 8-byte Folded Reload
	strh	w22, [sp, #3128]
	ldr	x22, [sp, #584]                 ; 8-byte Folded Reload
	str	w21, [sp, #3112]
	ldr	w21, [x10]
	add	x10, sp, #3120
	strh	w19, [sp, #3116]
	ldrh	w19, [x5, #4]
	add	x5, sp, #3118
	strh	w20, [sp, #3108]
	add	x20, sp, #3088
	strh	w6, [sp, #3104]
	add	x6, sp, #3076
	strb	w3, [sp, #3098]
	add	x3, sp, #3072
	str	w17, [sp, #3088]
	add	x17, sp, #3052
	strb	w1, [sp, #3086]
	add	x1, sp, #3060
	strh	w2, [sp, #3080]
	add	x2, sp, #3064
	strh	w8, [sp, #3060]
	add	x8, sp, #3100
	strh	w11, [sp, #3048]
	add	x11, sp, #3124
	strh	w12, [sp, #3046]
	add	x12, sp, #3132
	strh	w23, [sp, #3120]
	strb	w14, [sp, #3074]
	strh	w19, [sp, #3044]
	str	w21, [sp, #3040]
LBB15_96:                               ; %b58_to_b59.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	w19, [sp, #1376]                ; 4-byte Folded Reload
	ldr	x21, [sp, #648]                 ; 8-byte Folded Reload
	mov	x23, x0
	ldr	x14, [sp, #736]                 ; 8-byte Folded Reload
	str	x25, [sp, #952]                 ; 8-byte Folded Spill
	str	w19, [sp, #2272]
	ldrh	w19, [x12]
	ldrb	w12, [x12, #2]
	str	x25, [sp, #2664]
	ldr	x25, [sp, #1416]                ; 8-byte Folded Reload
	strh	w19, [x0]
	ldr	w19, [x11]
	ldrh	w11, [x11, #4]
	strb	w12, [x0, #2]
	ldrb	w12, [x10, #2]
	ldrh	w10, [x10]
	strh	w11, [x21, #4]
	ldr	x11, [sp, #640]                 ; 8-byte Folded Reload
	str	w19, [x21]
	ldr	x19, [sp, #1424]                ; 8-byte Folded Reload
	strb	w12, [x11, #2]
	mov	x12, x11
	ldr	w11, [x9]
	ldrh	w9, [x9, #4]
	strh	w10, [x12]
	ldrh	w10, [x7]
	str	w11, [x22]
	ldr	x11, [sp, #672]                 ; 8-byte Folded Reload
	strh	w9, [x22, #4]
	ldrb	w9, [x7, #2]
	ldr	x7, [sp, #632]                  ; 8-byte Folded Reload
	str	x19, [sp, #2680]
	strh	w10, [x7]
	ldr	w10, [x8]
	ldrh	w8, [x8, #4]
	strb	w9, [x7, #2]
	ldr	x9, [sp, #664]                  ; 8-byte Folded Reload
	str	x25, [sp, #2696]
	str	w10, [x9]
	mov	x10, x9
	ldrb	w9, [x30, #2]
	strh	w8, [x10, #4]
	ldrh	w8, [x30]
	ldr	x30, [sp, #744]                 ; 8-byte Folded Reload
	strb	w9, [x11, #2]
	ldrh	w9, [x20, #4]
	strh	w8, [x11]
	ldr	w8, [x20]
	ldr	x11, [sp, #752]                 ; 8-byte Folded Reload
	strh	w9, [x24, #4]
	ldrb	w9, [x27, #2]
	ldr	w20, [sp, #1412]                ; 4-byte Folded Reload
	str	w8, [x24]
	ldrh	w8, [x27]
	strb	w9, [sp, #2270]
	ldrh	w9, [x6, #4]
	strh	w8, [sp, #2268]
	ldr	w8, [x6]
	strh	w9, [sp, #2264]
	ldrb	w9, [x3, #2]
	str	w8, [sp, #2260]
	ldrh	w8, [x3]
	ldr	x3, [sp, #592]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2258]
	ldrh	w9, [x2, #4]
	strh	w8, [sp, #2256]
	ldr	w8, [x2]
	ldr	x2, [sp, #600]                  ; 8-byte Folded Reload
	strh	w9, [sp, #2252]
	ldrb	w9, [x1, #2]
	str	w8, [sp, #2248]
	ldrh	w8, [x1]
	ldr	x1, [sp, #608]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2246]
	ldrh	w9, [x17, #4]
	strh	w8, [sp, #2244]
	ldr	w8, [x17]
	strh	w9, [sp, #2240]
	ldrb	w9, [x16, #2]
	str	w8, [sp, #2236]
	ldrh	w8, [x16]
	ldr	x16, [sp, #616]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2234]
	ldrh	w9, [x15, #4]
	strh	w8, [sp, #2232]
	ldr	w8, [x15]
	ldr	x15, [sp, #1432]                ; 8-byte Folded Reload
	strh	w9, [sp, #2228]
	ldr	w9, [sp, #380]                  ; 4-byte Folded Reload
	str	w8, [sp, #2224]
	ldr	w8, [sp, #244]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2349]
	ldr	w9, [sp, #320]                  ; 4-byte Folded Reload
	str	w8, [sp, #2276]
	ldr	x8, [sp, #1336]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2445]
	ldr	w9, [sp, #304]                  ; 4-byte Folded Reload
	str	x8, [sp, #2280]
	ldr	x8, [sp, #1328]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2541]
	ldr	x9, [sp, #1120]                 ; 8-byte Folded Reload
	str	x8, [sp, #2288]
	ldr	x8, [sp, #1320]                 ; 8-byte Folded Reload
	str	x9, [sp, #2616]
	ldrh	w9, [x27]
	str	x8, [sp, #2296]
	ldr	w8, [sp, #264]                  ; 4-byte Folded Reload
	strh	w9, [x11]
	ldrh	w9, [sp, #2264]
	str	w8, [sp, #2304]
	ldr	w8, [sp, #240]                  ; 4-byte Folded Reload
	str	w20, [sp, #2644]
	str	w8, [sp, #2308]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	x15, [sp, #2672]
	str	x8, [sp, #2312]
	ldr	x8, [sp, #1312]                 ; 8-byte Folded Reload
	str	x8, [sp, #2320]
	ldr	x8, [sp, #1304]                 ; 8-byte Folded Reload
	str	x8, [sp, #2328]
	ldr	w8, [sp, #388]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2336]
	ldr	w8, [sp, #1300]                 ; 4-byte Folded Reload
	str	w8, [sp, #2340]
	ldr	w8, [sp, #1288]                 ; 4-byte Folded Reload
	str	w8, [sp, #2344]
	ldr	w8, [sp, #384]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2348]
	ldrh	w8, [x28]
	strh	w8, [sp, #2350]
	ldr	w8, [sp, #1280]                 ; 4-byte Folded Reload
	str	w8, [sp, #2352]
	ldr	w8, [sp, #1276]                 ; 4-byte Folded Reload
	str	w8, [sp, #2356]
	ldr	w8, [sp, #360]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2360]
	ldr	w8, [sp, #356]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2361]
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	str	w8, [sp, #2368]
	ldr	w8, [sp, #236]                  ; 4-byte Folded Reload
	str	w8, [sp, #2372]
	ldr	x8, [sp, #1256]                 ; 8-byte Folded Reload
	str	x8, [sp, #2376]
	ldr	x8, [sp, #1264]                 ; 8-byte Folded Reload
	str	x8, [sp, #2384]
	ldr	x8, [sp, #1248]                 ; 8-byte Folded Reload
	str	x8, [sp, #2392]
	ldr	w8, [sp, #280]                  ; 4-byte Folded Reload
	str	w8, [sp, #2400]
	ldr	w8, [sp, #232]                  ; 4-byte Folded Reload
	str	w8, [sp, #2404]
	ldr	x8, [sp, #1176]                 ; 8-byte Folded Reload
	str	x8, [sp, #2408]
	ldr	x8, [sp, #1184]                 ; 8-byte Folded Reload
	str	x8, [sp, #2416]
	ldr	x8, [sp, #1144]                 ; 8-byte Folded Reload
	str	x8, [sp, #2424]
	ldr	w8, [sp, #296]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2432]
	ldr	w8, [sp, #1208]                 ; 4-byte Folded Reload
	str	w8, [sp, #2436]
	ldr	w8, [sp, #1212]                 ; 4-byte Folded Reload
	str	w8, [sp, #2440]
	ldr	w8, [sp, #312]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2444]
	ldrh	w8, [x5]
	strh	w8, [sp, #2446]
	ldr	w8, [sp, #1200]                 ; 4-byte Folded Reload
	str	w8, [sp, #2448]
	ldr	w8, [sp, #1204]                 ; 4-byte Folded Reload
	str	w8, [sp, #2452]
	ldr	w8, [sp, #300]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2456]
	ldr	w8, [sp, #316]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2457]
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	str	w8, [sp, #2464]
	ldr	w8, [sp, #224]                  ; 4-byte Folded Reload
	str	w8, [sp, #2468]
	ldr	x8, [sp, #1080]                 ; 8-byte Folded Reload
	str	x8, [sp, #2472]
	ldr	x8, [sp, #1088]                 ; 8-byte Folded Reload
	str	x8, [sp, #2480]
	ldr	x8, [sp, #1096]                 ; 8-byte Folded Reload
	str	x8, [sp, #2488]
	ldr	w8, [sp, #248]                  ; 4-byte Folded Reload
	str	w8, [sp, #2496]
	ldr	w8, [sp, #228]                  ; 4-byte Folded Reload
	str	w8, [sp, #2500]
	ldr	x8, [sp, #1056]                 ; 8-byte Folded Reload
	str	x8, [sp, #2504]
	ldr	x8, [sp, #1064]                 ; 8-byte Folded Reload
	str	x8, [sp, #2512]
	ldr	x8, [sp, #1072]                 ; 8-byte Folded Reload
	str	x8, [sp, #2520]
	ldr	w8, [sp, #288]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2528]
	ldr	w8, [sp, #1112]                 ; 4-byte Folded Reload
	str	w8, [sp, #2532]
	ldr	w8, [sp, #1116]                 ; 4-byte Folded Reload
	str	w8, [sp, #2536]
	ldr	w8, [sp, #292]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2540]
	ldrh	w8, [x26]
	strh	w8, [sp, #2542]
	ldr	w8, [sp, #1104]                 ; 4-byte Folded Reload
	str	w8, [sp, #2544]
	ldr	w8, [sp, #1108]                 ; 4-byte Folded Reload
	str	w8, [sp, #2548]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2552]
	ldr	w8, [sp, #308]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2553]
	ldr	w8, [sp, #1344]                 ; 4-byte Folded Reload
	str	w8, [sp, #2560]
	ldr	w8, [sp, #216]                  ; 4-byte Folded Reload
	str	w8, [sp, #2564]
	ldr	x8, [sp, #1032]                 ; 8-byte Folded Reload
	str	x8, [sp, #2568]
	ldr	x8, [sp, #1040]                 ; 8-byte Folded Reload
	str	x8, [sp, #2576]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	str	x8, [sp, #2584]
	ldr	w8, [sp, #276]                  ; 4-byte Folded Reload
	str	w8, [sp, #2592]
	ldr	w8, [sp, #220]                  ; 4-byte Folded Reload
	str	w8, [sp, #2596]
	ldr	x8, [sp, #1016]                 ; 8-byte Folded Reload
	str	x8, [sp, #2600]
	ldr	x8, [sp, #1024]                 ; 8-byte Folded Reload
	str	x8, [sp, #2608]
	ldrb	w8, [x27, #2]
	ldr	x27, [sp, #624]                 ; 8-byte Folded Reload
	strb	w8, [x11, #2]
	ldr	w8, [sp, #2260]
	ldr	w11, [sp, #1408]                ; 4-byte Folded Reload
	strh	w9, [x27, #4]
	ldrb	w9, [sp, #2258]
	str	w8, [x27]
	ldrh	w8, [sp, #2256]
	strb	w9, [x30, #2]
	ldr	w9, [sp, #328]                  ; 4-byte Folded Reload
	strh	w8, [x30]
	ldr	w8, [sp, #324]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2841]
	ldrh	w9, [sp, #2252]
	strb	w8, [sp, #2840]
	ldr	w8, [sp, #2248]
	strh	w9, [x16, #4]
	ldr	w9, [sp, #332]                  ; 4-byte Folded Reload
	str	w8, [x16]
	ldr	w8, [sp, #1360]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2912]
	ldrh	w9, [sp, #2244]
	str	w8, [sp, #2848]
	ldr	w8, [sp, #200]                  ; 4-byte Folded Reload
	strh	w9, [x1]
	ldrh	w9, [x13]
	ldrh	w13, [x4]
	str	w8, [sp, #2852]
	ldr	x8, [sp, #976]                  ; 8-byte Folded Reload
	str	w9, [sp, #816]                  ; 4-byte Folded Spill
	str	x8, [sp, #2856]
	ldr	x8, [sp, #984]                  ; 8-byte Folded Reload
	strh	w9, [sp, #2638]
	ldr	w9, [sp, #336]                  ; 4-byte Folded Reload
	str	x8, [sp, #2864]
	ldr	x8, [sp, #992]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2924]
	ldr	w9, [sp, #340]                  ; 4-byte Folded Reload
	str	x8, [sp, #2872]
	ldr	w8, [sp, #268]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2925]
	ldr	w9, [sp, #348]                  ; 4-byte Folded Reload
	str	w8, [sp, #2880]
	ldr	w8, [sp, #204]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2937]
	ldr	w9, [sp, #2236]
	str	w8, [sp, #2884]
	ldr	x8, [sp, #392]                  ; 8-byte Folded Reload
	str	w9, [x2]
	ldr	w9, [sp, #352]                  ; 4-byte Folded Reload
	str	x8, [sp, #2888]
	ldr	x8, [sp, #760]                  ; 8-byte Folded Reload
	strb	w9, [sp, #3008]
	ldrh	w9, [sp, #2232]
	str	x8, [sp, #2896]
	ldr	x8, [sp, #968]                  ; 8-byte Folded Reload
	strh	w9, [x3]
	ldr	w9, [sp, #364]                  ; 4-byte Folded Reload
	str	x8, [sp, #2904]
	ldrb	w8, [sp, #2246]
	strb	w9, [sp, #3020]
	ldr	w9, [sp, #368]                  ; 4-byte Folded Reload
	strb	w8, [x1, #2]
	ldr	w8, [sp, #1000]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3021]
	ldr	w9, [sp, #376]                  ; 4-byte Folded Reload
	str	w8, [sp, #2916]
	ldr	w8, [sp, #1008]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3033]
	ldr	w9, [sp, #2224]
	str	w8, [sp, #2920]
	ldr	w8, [sp, #168]                  ; 4-byte Folded Reload
	str	w11, [sp, #2640]
	strb	w8, [sp, #2624]
	ldr	w8, [sp, #1404]                 ; 4-byte Folded Reload
	strh	w13, [sp, #2734]
	str	w8, [sp, #2628]
	ldr	w8, [sp, #1368]                 ; 4-byte Folded Reload
	str	w9, [x14]
	str	w8, [sp, #2632]
	ldr	w8, [sp, #788]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2636]
	ldr	w8, [sp, #784]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2637]
	ldr	w8, [sp, #808]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2648]
	ldr	w8, [sp, #780]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2649]
	ldr	w8, [sp, #948]                  ; 4-byte Folded Reload
	str	w8, [sp, #2656]
	ldr	w8, [sp, #776]                  ; 4-byte Folded Reload
	str	w8, [sp, #2660]
	ldr	w8, [sp, #812]                  ; 4-byte Folded Reload
	str	w8, [sp, #2688]
	ldr	w8, [sp, #772]                  ; 4-byte Folded Reload
	str	w8, [sp, #2692]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	str	x8, [sp, #2704]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	str	x8, [sp, #2712]
	ldr	w8, [sp, #920]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2720]
	ldr	w8, [sp, #876]                  ; 4-byte Folded Reload
	str	w8, [sp, #2724]
	ldr	w8, [sp, #872]                  ; 4-byte Folded Reload
	str	w8, [sp, #2728]
	ldr	w8, [sp, #912]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2732]
	ldr	w8, [sp, #916]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2733]
	ldr	w8, [sp, #868]                  ; 4-byte Folded Reload
	str	w8, [sp, #2736]
	ldr	w8, [sp, #864]                  ; 4-byte Folded Reload
	str	w8, [sp, #2740]
	ldr	w8, [sp, #904]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2744]
	ldr	w8, [sp, #908]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2745]
	ldr	w8, [sp, #964]                  ; 4-byte Folded Reload
	str	w8, [sp, #2752]
	ldr	w8, [sp, #828]                  ; 4-byte Folded Reload
	str	w8, [sp, #2756]
	ldr	x8, [sp, #856]                  ; 8-byte Folded Reload
	str	x8, [sp, #2760]
	ldr	x8, [sp, #848]                  ; 8-byte Folded Reload
	str	x8, [sp, #2768]
	ldr	x8, [sp, #840]                  ; 8-byte Folded Reload
	str	x8, [sp, #2776]
	ldr	w8, [sp, #888]                  ; 4-byte Folded Reload
	str	w8, [sp, #2784]
	ldr	w8, [sp, #824]                  ; 4-byte Folded Reload
	str	w8, [sp, #2788]
	ldr	x8, [sp, #880]                  ; 8-byte Folded Reload
	str	x8, [sp, #2792]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	str	x8, [sp, #2800]
	ldr	x8, [sp, #936]                  ; 8-byte Folded Reload
	str	x8, [sp, #2808]
	ldr	w8, [sp, #900]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2816]
	ldr	w8, [sp, #944]                  ; 4-byte Folded Reload
	str	w8, [sp, #2820]
	ldr	w8, [sp, #932]                  ; 4-byte Folded Reload
	str	w8, [sp, #2824]
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	ldrh	w0, [x8]
	ldr	w8, [sp, #896]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2828]
	ldr	w8, [sp, #892]                  ; 4-byte Folded Reload
	strh	w0, [sp, #2830]
	strb	w8, [sp, #2829]
	ldr	w8, [sp, #928]                  ; 4-byte Folded Reload
	str	w8, [sp, #2832]
	ldr	w8, [sp, #924]                  ; 4-byte Folded Reload
	str	w8, [sp, #2836]
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	ldrh	w8, [x8]
	strh	w8, [sp, #2926]
	ldr	w8, [sp, #1240]                 ; 4-byte Folded Reload
	str	w8, [sp, #2928]
	ldr	w8, [sp, #1244]                 ; 4-byte Folded Reload
	str	w8, [sp, #2932]
	ldr	w8, [sp, #344]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2936]
	ldrh	w8, [sp, #2240]
	strh	w8, [x2, #4]
	ldr	w8, [sp, #1388]                 ; 4-byte Folded Reload
	str	w8, [sp, #2944]
	ldr	w8, [sp, #208]                  ; 4-byte Folded Reload
	str	w8, [sp, #2948]
	ldr	x8, [sp, #1152]                 ; 8-byte Folded Reload
	str	x8, [sp, #2952]
	ldr	x8, [sp, #1160]                 ; 8-byte Folded Reload
	str	x8, [sp, #2960]
	ldr	x8, [sp, #1168]                 ; 8-byte Folded Reload
	str	x8, [sp, #2968]
	ldr	w8, [sp, #272]                  ; 4-byte Folded Reload
	str	w8, [sp, #2976]
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	str	w8, [sp, #2980]
	ldr	x8, [sp, #1128]                 ; 8-byte Folded Reload
	str	x8, [sp, #2984]
	ldr	x8, [sp, #1136]                 ; 8-byte Folded Reload
	str	x8, [sp, #2992]
	ldr	x8, [sp, #1192]                 ; 8-byte Folded Reload
	str	x8, [sp, #3000]
	ldrb	w8, [sp, #2234]
	strb	w8, [x3, #2]
	ldr	w8, [sp, #1216]                 ; 4-byte Folded Reload
	str	w8, [sp, #3012]
	ldr	w8, [sp, #1228]                 ; 4-byte Folded Reload
	str	w8, [sp, #3016]
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	ldrh	w8, [x8]
	strh	w8, [sp, #3022]
	ldr	w8, [sp, #1232]                 ; 4-byte Folded Reload
	str	w8, [sp, #3024]
	ldr	w8, [sp, #252]                  ; 4-byte Folded Reload
	str	w8, [sp, #3028]
	ldr	w8, [sp, #372]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3032]
	ldrh	w8, [sp, #2228]
	strh	w8, [x14, #4]
	ldr	w8, [sp, #1392]                 ; 4-byte Folded Reload
	cbz	w8, LBB15_45
; %bb.97:                               ; %v132_ok.i.i.preheader
                                        ;   in Loop: Header=BB15_47 Depth=1
	str	w13, [sp, #760]                 ; 4-byte Folded Spill
	ldr	x13, [sp, #672]                 ; 8-byte Folded Reload
	ldr	x9, [sp, #728]                  ; 8-byte Folded Reload
	ldr	x17, [sp, #720]                 ; 8-byte Folded Reload
	mov	x26, xzr
	ldr	x4, [sp, #712]                  ; 8-byte Folded Reload
	ldr	x5, [sp, #704]                  ; 8-byte Folded Reload
	str	xzr, [sp, #1440]                ; 8-byte Folded Spill
	str	wzr, [sp, #1388]                ; 4-byte Folded Spill
LBB15_98:                               ; %v132_ok.i.i
                                        ;   Parent Loop BB15_47 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	x19, [sp, #1424]                ; 8-byte Folded Spill
	ldr	x19, [sp, #1440]                ; 8-byte Folded Reload
	add	x8, sp, #2272
	str	x25, [sp, #1416]                ; 8-byte Folded Spill
	add	x8, x8, x19
	str	x15, [sp, #1432]                ; 8-byte Folded Spill
	ldr	w25, [x8]
	str	x26, [sp, #1376]                ; 8-byte Folded Spill
	cmp	w25, #1
	b.ne	LBB15_100
; %bb.99:                               ; %b66_to_b274.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #2276]
	ldr	x15, [sp, #2296]
	mov	x25, x23
	ldr	d1, [sp, #2304]
	ldr	x19, [sp, #696]                 ; 8-byte Folded Reload
	mov	x28, x16
	str	w8, [sp, #1360]                 ; 4-byte Folded Spill
	add	x8, sp, #2272
	ldr	x30, [sp, #752]                 ; 8-byte Folded Reload
	ldur	q0, [x8, #8]
	str	x15, [sp, #1352]                ; 8-byte Folded Spill
	add	x16, sp, #2272
	str	d1, [sp, #1368]                 ; 8-byte Folded Spill
	ldur	q1, [x8, #40]
	mov	x26, x28
	ldr	x15, [sp, #2328]
	ldur	d2, [x8, #68]
	ldur	q5, [x8, #104]
	ldur	q7, [x8, #136]
	ldur	d16, [x8, #164]
	ldur	q19, [x8, #200]
	ldur	q21, [x8, #232]
	ldr	x8, [sp, #2520]
	str	x15, [sp, #1344]                ; 8-byte Folded Spill
	ldrb	w15, [sp, #2336]
	ldr	d22, [x19]
	ldur	q25, [x19, #36]
	str	x8, [sp, #1216]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2528]
	ldur	q27, [x19, #68]
	str	w15, [sp, #1336]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2348]
	ldr	d8, [x19, #384]
	str	w8, [sp, #1228]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2540]
	ldr	d14, [x19, #480]
	str	w15, [sp, #1328]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2349]
	ldr	x6, [sp, #744]                  ; 8-byte Folded Reload
	str	w8, [sp, #1212]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2541]
	ldr	d3, [sp, #2352]
	str	w15, [sp, #1320]                ; 4-byte Folded Spill
	ldrh	w15, [sp, #2350]
	ldr	d4, [sp, #2368]
	str	w8, [sp, #1208]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2542]
	ldr	d6, [sp, #2400]
	str	w15, [sp, #1312]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2360]
	ldr	d17, [sp, #2448]
	str	w8, [sp, #1204]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2552]
	ldr	d18, [sp, #2464]
	str	w15, [sp, #1304]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2361]
	ldr	d20, [sp, #2496]
	str	w8, [sp, #1192]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2553]
	ldr	d23, [sp, #2544]
	str	w15, [sp, #1300]                ; 4-byte Folded Spill
	ldr	x15, [sp, #2392]
	ldr	d24, [sp, #2560]
	str	w8, [sp, #1200]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2584]
	ldr	d26, [sp, #2592]
	str	x15, [sp, #1288]                ; 8-byte Folded Spill
	ldr	x15, [sp, #2424]
	ldr	d28, [sp, #2848]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	ldr	q29, [x9]
	mov	x9, x6
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	add	x8, sp, #2272
	str	x15, [sp, #1280]                ; 8-byte Folded Spill
	ldrb	w15, [sp, #2432]
	ldr	d30, [sp, #2880]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	mov	x8, x23
	mov	x23, x19
	mov	x19, x13
	str	x13, [sp, #1008]                ; 8-byte Folded Spill
	ldrb	w13, [sp, #2912]
	str	w15, [sp, #1276]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2444]
	ldr	q31, [x17]
	mov	x17, x21
	str	w11, [sp, #1408]                ; 4-byte Folded Spill
	mov	x11, x14
	ldr	x14, [sp, #2616]
	str	w13, [sp, #1080]                ; 4-byte Folded Spill
	ldrb	w13, [sp, #2924]
	str	w15, [sp, #1264]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2445]
	ldr	d9, [sp, #2928]
	str	w20, [sp, #1412]                ; 4-byte Folded Spill
	mov	x20, x8
	ldrb	w8, [sp, #3008]
	str	x14, [sp, #1160]                ; 8-byte Folded Spill
	ldrb	w14, [sp, #2624]
	ldr	d10, [sp, #2944]
	str	w13, [sp, #1048]                ; 4-byte Folded Spill
	ldrb	w13, [sp, #2925]
	ldr	q11, [x4]
	mov	x4, x10
	str	w15, [sp, #1256]                ; 4-byte Folded Spill
	ldrh	w15, [sp, #2446]
	str	w14, [sp, #1168]                ; 4-byte Folded Spill
	ldr	w14, [sp, #2628]
	ldr	d12, [sp, #2976]
	str	w13, [sp, #1056]                ; 4-byte Folded Spill
	ldrh	w13, [sp, #2926]
	ldr	q13, [x5]
	str	w8, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3020]
	ldr	d15, [sp, #3024]
	str	w15, [sp, #1248]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2456]
	ldr	x5, [sp, #880]                  ; 8-byte Folded Reload
	str	w14, [sp, #1404]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2840]
	str	w13, [sp, #1096]                ; 4-byte Folded Spill
	ldrb	w13, [sp, #2936]
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3021]
	str	w15, [sp, #1244]                ; 4-byte Folded Spill
	ldrb	w15, [sp, #2457]
	str	w14, [sp, #1032]                ; 4-byte Folded Spill
	ldrb	w14, [sp, #2841]
	str	w13, [sp, #1040]                ; 4-byte Folded Spill
	ldrb	w13, [sp, #2937]
	str	w8, [sp, #1108]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #3022]
	str	w15, [sp, #1240]                ; 4-byte Folded Spill
	ldr	x15, [sp, #2488]
	str	w14, [sp, #1088]                ; 4-byte Folded Spill
	ldr	x14, [sp, #2872]
	str	w13, [sp, #1064]                ; 4-byte Folded Spill
	ldr	x13, [sp, #2968]
	str	w8, [sp, #1072]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3032]
	str	x15, [sp, #1232]                ; 8-byte Folded Spill
	ldr	w15, [sp, #2632]
	str	x14, [sp, #1128]                ; 8-byte Folded Spill
	ldr	x14, [sp, #2904]
	str	x13, [sp, #1144]                ; 8-byte Folded Spill
	ldr	x13, [sp, #3000]
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3033]
	str	x21, [sp, #976]                 ; 8-byte Folded Spill
	mov	x21, x27
	str	x12, [sp, #968]                 ; 8-byte Folded Spill
	str	x22, [sp, #992]                 ; 8-byte Folded Spill
	str	x14, [sp, #1136]                ; 8-byte Folded Spill
	mov	x14, x30
	str	x7, [sp, #984]                  ; 8-byte Folded Spill
	str	x10, [sp, #1000]                ; 8-byte Folded Spill
	mov	x10, x2
	str	x24, [sp, #1016]                ; 8-byte Folded Spill
	str	x13, [sp, #1152]                ; 8-byte Folded Spill
	mov	x13, x1
	str	w8, [sp, #1120]                 ; 4-byte Folded Spill
	mov	x8, x3
	str	w0, [sp, #1024]                 ; 4-byte Folded Spill
	mov	w0, w15
	b	LBB15_126
LBB15_100:                              ; %b67.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldp	w11, w10, [x8, #68]
	ldp	x1, x20, [x8, #8]
	ldr	w9, [x8, #32]
	ldp	x22, x19, [x8, #40]
	ldr	x3, [x8, #24]
	cmp	w9, #1
	str	w10, [sp, #1432]                ; 4-byte Folded Spill
	ldrb	w10, [x8, #77]
	ldr	x24, [x8, #56]
	ldrb	w21, [x8, #64]
	ldrb	w26, [x8, #76]
	str	w10, [sp, #1424]                ; 4-byte Folded Spill
	ldr	w10, [x8, #80]
	ldrb	w28, [x8, #88]
	ldr	x0, [sp, #680]                  ; 8-byte Folded Reload
	str	w9, [sp, #1352]                 ; 4-byte Folded Spill
	str	w10, [sp, #1408]                ; 4-byte Folded Spill
	ldr	w10, [x8, #84]
	ldrb	w8, [x8, #89]
	str	w10, [sp, #1416]                ; 4-byte Folded Spill
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	b.ne	LBB15_102
; %bb.101:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #3                          ; =0x3
	str	w26, [sp, #1404]                ; 4-byte Folded Spill
	ldr	w26, [sp, #1352]                ; 4-byte Folded Reload
	str	wzr, [sp, #1392]                ; 4-byte Folded Spill
	mov	x27, x3
	mov	x23, x19
	str	w8, [sp, #692]                  ; 4-byte Folded Spill
	mov	w19, w21
	str	w11, [sp, #1368]                ; 4-byte Folded Spill
	str	w28, [sp, #1312]                ; 4-byte Folded Spill
	mov	x28, x1
	b	LBB15_125
LBB15_102:                              ; %b70.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	x2, x20
	str	w25, [sp, #1304]                ; 4-byte Folded Spill
	mov	x23, x22
	mov	w25, w11
	mov	x27, x0
	str	x20, [sp, #1344]                ; 8-byte Folded Spill
	str	x3, [sp, #1392]                 ; 8-byte Folded Spill
	mov	x22, x1
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	str	x22, [sp, #1336]                ; 8-byte Folded Spill
	str	x24, [sp, #1360]                ; 8-byte Folded Spill
	cbnz	x8, LBB15_104
; %bb.103:                              ; %b1.i.i199.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	x20, x0
	mov	w24, wzr
	b	LBB15_107
LBB15_104:                              ; %v8_ok.i.i181.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB15_106
; %bb.105:                              ; %v8_ok.i.i181.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh88:
	adrp	x11, lJTI15_5@PAGE
Lloh89:
	add	x11, x11, lJTI15_5@PAGEOFF
	adr	x9, LBB15_106
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB15_106:                              ; %liza___liza_reactor_error.exit.i.i185.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w20, wzr
	mov	w24, #1                         ; =0x1
LBB15_107:                              ; %liza_net.reactor_ready.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w24, #1
	mov	w8, #3                          ; =0x3
	ldr	x3, [sp, #1360]                 ; 8-byte Folded Reload
	csel	w8, wzr, w8, ne
	mov	x0, x27
	mov	x1, x23
	mov	x2, x19
	mov	x22, x23
	str	w8, [sp, #1320]                 ; 4-byte Folded Spill
	mov	x23, x19
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	cbz	x8, LBB15_111
; %bb.108:                              ; %v8_ok.i.i207.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB15_110
; %bb.109:                              ; %v8_ok.i.i207.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh90:
	adrp	x11, lJTI15_6@PAGE
Lloh91:
	add	x11, x11, lJTI15_6@PAGEOFF
	adr	x9, LBB15_110
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB15_110:                              ; %liza___liza_reactor_error.exit.i.i211.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB15_111:                              ; %liza_net.reactor_ready.exit228.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w8, #1
	b.ne	LBB15_115
LBB15_112:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w26, #3                         ; =0x3
LBB15_113:                              ; %b259.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1344]                 ; 8-byte Folded Reload
	mov	x0, x27
	ldr	x3, [sp, #1392]                 ; 8-byte Folded Reload
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB15_117
; %bb.114:                              ; %b1.i.i891.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x3, [sp, #1360]                 ; 8-byte Folded Reload
	mov	w20, wzr
	b	LBB15_120
LBB15_115:                              ; %b78.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w24, #1
	str	x0, [sp, #1368]                 ; 8-byte Folded Spill
	cset	w8, eq
	str	w26, [sp, #1404]                ; 4-byte Folded Spill
	orr	w8, w8, w21
	tbz	w8, #0, LBB15_128
; %bb.116:                              ; %b91.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w15, [sp, #1432]                ; 4-byte Folded Reload
	mov	w11, w25
	ldr	w25, [sp, #1424]                ; 4-byte Folded Reload
	cmp	w24, #1
	mov	w19, w28
	str	w21, [sp, #1328]                ; 4-byte Folded Spill
	b.eq	LBB15_112
	b	LBB15_147
LBB15_117:                              ; %v8_ok.i.i873.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w8, w8, #1
	ldr	x3, [sp, #1360]                 ; 8-byte Folded Reload
	cmp	w8, #11
	b.hi	LBB15_119
; %bb.118:                              ; %v8_ok.i.i873.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh92:
	adrp	x11, lJTI15_14@PAGE
Lloh93:
	add	x11, x11, lJTI15_14@PAGEOFF
	adr	x9, LBB15_119
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB15_119:                              ; %liza___liza_reactor_error.exit.i.i877.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w20, #1                         ; =0x1
LBB15_120:                              ; %liza_net.reactor_disconnect.exit894.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	x0, x27
	mov	x1, x22
	mov	x2, x23
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbz	x8, LBB15_124
; %bb.121:                              ; %v8_ok.i.i900.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB15_123
; %bb.122:                              ; %v8_ok.i.i900.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh94:
	adrp	x11, lJTI15_15@PAGE
Lloh95:
	add	x11, x11, lJTI15_15@PAGEOFF
	adr	x9, LBB15_123
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB15_123:                              ; %liza___liza_reactor_error.exit.i.i904.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
LBB15_124:                              ; %liza_net.reactor_disconnect.exit921.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	orr	w8, w8, w20
	ldr	w9, [sp, #404]                  ; 4-byte Folded Reload
	mov	x28, xzr
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	mov	x27, xzr
	csel	w8, w26, w8, eq
	cmp	w9, #0
	ldr	w9, [sp, #692]                  ; 4-byte Folded Reload
	mov	x22, xzr
	mov	x23, xzr
	mov	x24, xzr
	csel	w9, w8, w9, ne
	ldr	w8, [sp, #400]                  ; 4-byte Folded Reload
	mov	w19, wzr
	mov	x20, xzr
	mov	w25, #1                         ; =0x1
	mov	w26, #1                         ; =0x1
	str	wzr, [sp, #1368]                ; 4-byte Folded Spill
	str	wzr, [sp, #1432]                ; 4-byte Folded Spill
	str	wzr, [sp, #1404]                ; 4-byte Folded Spill
	str	wzr, [sp, #1424]                ; 4-byte Folded Spill
	str	xzr, [sp, #1408]                ; 8-byte Folded Spill
	str	wzr, [sp, #1416]                ; 4-byte Folded Spill
	str	wzr, [sp, #1312]                ; 4-byte Folded Spill
	str	w9, [sp, #692]                  ; 4-byte Folded Spill
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
LBB15_125:                              ; %v554_ok.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	add	x0, sp, #1456
	add	x1, sp, #2272
	mov	w2, #768                        ; =0x300
	add	x21, sp, #1456
	bl	_memcpy
	ldr	x8, [sp, #1440]                 ; 8-byte Folded Reload
	add	x9, sp, #1456
	ldr	x11, [sp, #448]                 ; 8-byte Folded Reload
	str	x9, [sp, #1176]                 ; 8-byte Folded Spill
	and	w9, w19, #0x1
	ldr	x17, [sp, #648]                 ; 8-byte Folded Reload
	add	x8, x21, x8
	ldr	x12, [sp, #640]                 ; 8-byte Folded Reload
	ldr	x7, [sp, #632]                  ; 8-byte Folded Reload
	str	w25, [x8]
	ldr	x25, [sp, #568]                 ; 8-byte Folded Reload
	add	x16, sp, #2272
	stp	x28, x20, [x8, #8]
	ldr	w10, [sp, #1460]
	ldr	x20, [sp, #656]                 ; 8-byte Folded Reload
	str	x27, [x8, #24]
	ldr	x4, [sp, #664]                  ; 8-byte Folded Reload
	ldr	x19, [sp, #672]                 ; 8-byte Folded Reload
	strb	w9, [x8, #64]
	add	x9, sp, #1209
	ldr	x30, [sp, #752]                 ; 8-byte Folded Reload
	ldur	q0, [x9, #255]
	ldr	x9, [sp, #1480]
	str	w10, [sp, #1360]                ; 4-byte Folded Spill
	ldr	w10, [sp, #1368]                ; 4-byte Folded Reload
	str	w26, [x8, #32]
	ldr	x27, [sp, #624]                 ; 8-byte Folded Reload
	str	x9, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #1432]                 ; 4-byte Folded Reload
	ldr	d1, [sp, #1488]
	stp	x22, x23, [x8, #40]
	ldr	x23, [sp, #696]                 ; 8-byte Folded Reload
	ldr	x22, [sp, #584]                 ; 8-byte Folded Reload
	stp	w10, w9, [x8, #68]
	add	x10, sp, #1241
	ldr	w9, [sp, #1404]                 ; 4-byte Folded Reload
	str	x24, [x8, #56]
	ldr	x24, [sp, #576]                 ; 8-byte Folded Reload
	ldr	x6, [sp, #744]                  ; 8-byte Folded Reload
	and	w9, w9, #0x1
	str	d1, [sp, #1368]                 ; 8-byte Folded Spill
	ldur	q1, [x10, #255]
	strb	w9, [x8, #76]
	ldr	w9, [sp, #1424]                 ; 4-byte Folded Reload
	ldr	x10, [sp, #1512]
	ldr	x28, [sp, #616]                 ; 8-byte Folded Reload
	ldr	x1, [sp, #608]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #600]                  ; 8-byte Folded Reload
	and	w9, w9, #0x1
	str	x10, [sp, #1344]                ; 8-byte Folded Spill
	ldrb	w10, [sp, #1520]
	strb	w9, [x8, #77]
	add	x9, sp, #1269
	ldr	x3, [sp, #592]                  ; 8-byte Folded Reload
	ldur	d2, [x9, #255]
	ldrb	w9, [sp, #1532]
	str	w10, [sp, #1336]                ; 4-byte Folded Spill
	ldr	w10, [sp, #1408]                ; 4-byte Folded Reload
	ldp	x13, x26, [sp, #472]            ; 16-byte Folded Reload
	str	w9, [sp, #1328]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1533]
	str	w9, [sp, #1320]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1416]                 ; 4-byte Folded Reload
	stp	w10, w9, [x8, #80]
	ldr	w9, [sp, #1312]                 ; 4-byte Folded Reload
	ldrh	w10, [sp, #1534]
	ldr	d3, [sp, #1536]
	and	w9, w9, #0x1
	str	w10, [sp, #1312]                ; 4-byte Folded Spill
	strb	w9, [x8, #88]
	ldr	w9, [sp, #1412]                 ; 4-byte Folded Reload
	ldrb	w10, [sp, #1544]
	and	w9, w9, #0x1
	strb	w9, [x8, #89]
	ldrb	w8, [sp, #1545]
	ldr	x9, [sp, #1608]
	str	w10, [sp, #1304]                ; 4-byte Folded Spill
	ldr	d4, [sp, #1552]
	ldr	d6, [sp, #1584]
	ldr	d17, [sp, #1632]
	str	w8, [sp, #1300]                 ; 4-byte Folded Spill
	add	x8, sp, #1305
	ldr	d18, [sp, #1648]
	ldur	q5, [x8, #255]
	ldr	x8, [sp, #1576]
	str	x9, [sp, #1280]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1616]
	ldr	d20, [sp, #1680]
	ldr	d23, [sp, #1728]
	str	x8, [sp, #1288]                 ; 8-byte Folded Spill
	add	x8, sp, #1456
	ldr	d24, [sp, #1744]
	ldur	q7, [x8, #136]
	ldur	d16, [x8, #164]
	ldur	q19, [x8, #200]
	ldur	q21, [x8, #232]
	ldr	x8, [sp, #1704]
	str	w9, [sp, #1276]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1628]
	ldr	d26, [sp, #1776]
	ldr	w0, [sp, #1816]
	str	x8, [sp, #1216]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1712]
	ldr	d28, [sp, #2032]
	str	w9, [sp, #1264]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1629]
	ldr	d30, [sp, #2064]
	str	w8, [sp, #1228]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #440]                  ; 8-byte Folded Reload
	ldr	d9, [sp, #2112]
	str	w9, [sp, #1256]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1630]
	ldr	d10, [sp, #2128]
	ldr	d22, [x8]
	ldur	q25, [x8, #36]
	ldur	q27, [x8, #68]
	ldr	d8, [x8, #384]
	ldr	d14, [x8, #480]
	ldrb	w8, [sp, #1821]
	str	w9, [sp, #1248]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1640]
	ldr	d12, [sp, #2160]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #1822]
	ldr	x5, [sp, #1976]
	str	w9, [sp, #1244]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1641]
	ldr	d15, [sp, #2208]
	str	w8, [sp, #816]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1824]
	str	w9, [sp, #1240]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1672]
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1828]
	str	x9, [sp, #1232]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1724]
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1832]
	str	w9, [sp, #1212]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1725]
	str	w8, [sp, #808]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1833]
	str	w9, [sp, #1208]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1726]
	str	w8, [sp, #780]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1840]
	str	w9, [sp, #1204]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1736]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1844]
	str	w9, [sp, #1192]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1737]
	str	w8, [sp, #776]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1848]
	str	w9, [sp, #1200]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1768]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1856]
	str	x9, [sp, #1184]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #1800]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1864]
	str	x9, [sp, #1160]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1808]
	str	x8, [sp, #1424]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #1872]
	str	w9, [sp, #1168]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1812]
	str	w8, [sp, #812]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1876]
	str	w9, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1820]
	str	w8, [sp, #772]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1880]
	str	w9, [sp, #788]                  ; 4-byte Folded Spill
	ldp	x9, x10, [sp, #424]             ; 16-byte Folded Reload
	str	x8, [sp, #1416]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1888]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1896]
	ldr	q29, [x10]
	ldr	q31, [x9]
	ldp	x9, x10, [sp, #408]             ; 16-byte Folded Reload
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #1904]
	str	w8, [sp, #920]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1908]
	ldr	q11, [x10]
	ldr	q13, [x9]
	ldp	x9, x21, [sp, #488]             ; 16-byte Folded Reload
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1912]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1916]
	str	w8, [sp, #912]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1917]
	str	w8, [sp, #916]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #1918]
	str	w8, [sp, #760]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1920]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1924]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1928]
	str	w8, [sp, #904]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1929]
	str	w8, [sp, #908]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1936]
	str	w8, [sp, #964]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1940]
	str	w8, [sp, #828]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1944]
	str	x8, [sp, #856]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1952]
	str	x8, [sp, #848]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1960]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #1968]
	str	w8, [sp, #888]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1972]
	str	w8, [sp, #824]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1984]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1992]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2000]
	str	w8, [sp, #900]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2004]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2008]
	str	w8, [sp, #932]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2012]
	str	w8, [sp, #896]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #560]                  ; 8-byte Folded Reload
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #552]                  ; 8-byte Folded Reload
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #544]                  ; 8-byte Folded Reload
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2013]
	str	w8, [sp, #892]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2014]
	str	w8, [sp, #1024]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2016]
	str	w8, [sp, #928]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2020]
	str	w8, [sp, #924]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2024]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2025]
	str	w8, [sp, #1088]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2056]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2088]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #528]                  ; 8-byte Folded Reload
	str	x8, [sp, #1000]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #520]                  ; 8-byte Folded Reload
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldp	x14, x8, [sp, #504]             ; 16-byte Folded Reload
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2096]
	str	w8, [sp, #1080]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2108]
	str	w8, [sp, #1048]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2109]
	str	w8, [sp, #1056]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2110]
	str	w8, [sp, #1096]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2120]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2121]
	str	w8, [sp, #1064]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2152]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2184]
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2192]
	str	w8, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2204]
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2205]
	str	w8, [sp, #1108]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2206]
	str	w8, [sp, #1072]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2216]
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2217]
	str	w8, [sp, #1120]                 ; 4-byte Folded Spill
	ldp	x8, x10, [sp, #456]             ; 16-byte Folded Reload
LBB15_126:                              ; %b274_to_b59.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldrh	w15, [x14]
	ldrb	w14, [x14, #2]
	stur	q0, [x16, #8]
	ldr	d0, [sp, #1368]                 ; 8-byte Folded Reload
	str	w0, [sp, #1368]                 ; 4-byte Folded Spill
	strh	w15, [sp, #2268]
	ldr	w15, [x21]
	strb	w14, [sp, #2270]
	ldrh	w14, [x21, #4]
	mov	x21, x17
	str	w15, [sp, #2260]
	ldrh	w15, [x9]
	ldrb	w9, [x9, #2]
	strh	w14, [sp, #2264]
	ldrh	w14, [x26, #4]
	strb	w9, [sp, #2258]
	ldr	w9, [x26]
	ldr	x26, [sp, #1376]                ; 8-byte Folded Reload
	strh	w14, [sp, #2252]
	ldrb	w14, [x13, #2]
	cmp	x26, #6
	str	w9, [sp, #2248]
	ldrh	w9, [x13]
	ldr	w13, [x10]
	strh	w15, [sp, #2256]
	ldr	x15, [sp, #1432]                ; 8-byte Folded Reload
	strh	w9, [sp, #2244]
	ldrh	w9, [x10, #4]
	ldrh	w10, [x8]
	ldrb	w8, [x8, #2]
	str	w13, [sp, #2236]
	mov	x13, x19
	strh	w9, [sp, #2240]
	ldr	w9, [x11]
	strb	w8, [sp, #2234]
	ldrh	w8, [x11, #4]
	ldr	w11, [sp, #1408]                ; 4-byte Folded Reload
	str	w9, [sp, #2224]
	ldr	x9, [sp, #1176]                 ; 8-byte Folded Reload
	strh	w8, [sp, #2228]
	ldr	w8, [sp, #1360]                 ; 4-byte Folded Reload
	ldr	w9, [x9]
	strh	w10, [sp, #2232]
	ldr	x10, [sp, #976]                 ; 8-byte Folded Reload
	str	w8, [sp, #2276]
	ldr	x8, [sp, #1352]                 ; 8-byte Folded Reload
	str	w9, [sp, #2272]
	ldr	w9, [sp, #1336]                 ; 4-byte Folded Reload
	str	x8, [sp, #2296]
	ldr	x8, [sp, #1344]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2336]
	ldrh	w9, [x25]
	str	x8, [sp, #2328]
	ldrb	w8, [x25, #2]
	ldr	x25, [sp, #1424]                ; 8-byte Folded Reload
	strh	w9, [x20]
	ldr	w9, [sp, #1300]                 ; 4-byte Folded Reload
	strb	w8, [x20, #2]
	ldr	w8, [sp, #1328]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2361]
	ldr	w9, [x10]
	strb	w8, [sp, #2348]
	ldr	w8, [sp, #1320]                 ; 4-byte Folded Reload
	strb	w14, [sp, #2246]
	ldr	x14, [sp, #736]                 ; 8-byte Folded Reload
	strb	w8, [sp, #2349]
	ldr	w8, [sp, #1312]                 ; 4-byte Folded Reload
	str	w0, [sp, #2632]
	strh	w8, [sp, #2350]
	ldr	w8, [sp, #1304]                 ; 4-byte Folded Reload
	str	x5, [sp, #880]                  ; 8-byte Folded Spill
	strb	w8, [sp, #2360]
	ldrh	w8, [x10, #4]
	ldr	x10, [sp, #968]                 ; 8-byte Folded Reload
	str	w9, [x17]
	ldr	w9, [sp, #1276]                 ; 4-byte Folded Reload
	strh	w8, [x17, #4]
	ldr	x8, [sp, #1288]                 ; 8-byte Folded Reload
	ldr	x17, [sp, #720]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2432]
	ldrh	w9, [x10]
	str	x8, [sp, #2392]
	ldr	x8, [sp, #1280]                 ; 8-byte Folded Reload
	str	x5, [sp, #2792]
	ldr	x5, [sp, #704]                  ; 8-byte Folded Reload
	str	x8, [sp, #2424]
	ldrb	w8, [x10, #2]
	ldr	x10, [sp, #992]                 ; 8-byte Folded Reload
	strh	w9, [x12]
	ldr	w9, [sp, #1240]                 ; 4-byte Folded Reload
	strb	w8, [x12, #2]
	ldr	w8, [sp, #1264]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2457]
	ldr	w9, [x10]
	strb	w8, [sp, #2444]
	ldr	w8, [sp, #1256]                 ; 4-byte Folded Reload
	stur	q1, [x16, #40]
	strb	w8, [sp, #2445]
	ldr	w8, [sp, #1248]                 ; 4-byte Folded Reload
	stur	d2, [x16, #68]
	strh	w8, [sp, #2446]
	ldr	w8, [sp, #1244]                 ; 4-byte Folded Reload
	stur	q5, [x16, #104]
	strb	w8, [sp, #2456]
	ldrh	w8, [x10, #4]
	ldr	x10, [sp, #984]                 ; 8-byte Folded Reload
	str	w9, [x22]
	ldr	w9, [sp, #1228]                 ; 4-byte Folded Reload
	strh	w8, [x22, #4]
	ldr	x8, [sp, #1232]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2528]
	ldrh	w9, [x10]
	str	x8, [sp, #2488]
	ldr	x8, [sp, #1216]                 ; 8-byte Folded Reload
	stur	q7, [x16, #136]
	str	x8, [sp, #2520]
	ldrb	w8, [x10, #2]
	ldr	x10, [sp, #1000]                ; 8-byte Folded Reload
	strh	w9, [x7]
	ldr	w9, [sp, #1200]                 ; 4-byte Folded Reload
	strb	w8, [x7, #2]
	ldr	w8, [sp, #1212]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2553]
	ldr	w9, [x10]
	strb	w8, [sp, #2540]
	ldr	w8, [sp, #1208]                 ; 4-byte Folded Reload
	stur	d16, [x16, #164]
	strb	w8, [sp, #2541]
	ldr	w8, [sp, #1204]                 ; 4-byte Folded Reload
	stur	q19, [x16, #200]
	strh	w8, [sp, #2542]
	ldr	w8, [sp, #1192]                 ; 4-byte Folded Reload
	stur	q21, [x16, #232]
	mov	x16, x28
	strb	w8, [sp, #2552]
	ldrh	w8, [x10, #4]
	ldr	x10, [sp, #1008]                ; 8-byte Folded Reload
	str	w9, [x4]
	ldr	w9, [sp, #1168]                 ; 4-byte Folded Reload
	strh	w8, [x4, #4]
	ldr	x8, [sp, #1184]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2624]
	ldrh	w9, [x10]
	str	x8, [sp, #2584]
	ldr	x8, [sp, #1160]                 ; 8-byte Folded Reload
	str	d22, [x23]
	str	x8, [sp, #2616]
	ldrb	w8, [x10, #2]
	ldr	x10, [sp, #1016]                ; 8-byte Folded Reload
	strh	w9, [x19]
	ldr	w9, [x10]
	strb	w8, [x19, #2]
	ldrh	w8, [x10, #4]
	stur	q25, [x23, #36]
	str	w9, [x24]
	ldrh	w9, [sp, #2268]
	strh	w8, [x24, #4]
	ldrb	w8, [sp, #2270]
	strh	w9, [x30]
	ldr	w9, [sp, #2260]
	strb	w8, [x30, #2]
	ldrh	w8, [sp, #2264]
	ldr	x30, [sp, #1416]                ; 8-byte Folded Reload
	str	w9, [x27]
	ldrh	w9, [sp, #2256]
	strh	w8, [x27, #4]
	ldrb	w8, [sp, #2258]
	strh	w9, [x6]
	ldr	w9, [sp, #1088]                 ; 4-byte Folded Reload
	strb	w8, [x6, #2]
	ldr	w8, [sp, #1032]                 ; 4-byte Folded Reload
	ldr	x6, [sp, #712]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2841]
	ldr	w9, [sp, #2248]
	strb	w8, [sp, #2840]
	ldrh	w8, [sp, #2252]
	str	w9, [x28]
	ldr	w9, [sp, #1080]                 ; 4-byte Folded Reload
	strh	w8, [x28, #4]
	ldr	x8, [sp, #1128]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2912]
	ldrh	w9, [sp, #2244]
	str	x8, [sp, #2872]
	ldr	x8, [sp, #1136]                 ; 8-byte Folded Reload
	strh	w9, [x1]
	ldr	w9, [sp, #1064]                 ; 4-byte Folded Reload
	str	x8, [sp, #2904]
	ldrb	w8, [sp, #2246]
	strb	w9, [sp, #2937]
	ldr	w9, [sp, #2236]
	strb	w8, [x1, #2]
	ldr	w8, [sp, #1048]                 ; 4-byte Folded Reload
	str	w9, [x2]
	ldr	w9, [sp, #1104]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2924]
	ldr	w8, [sp, #1056]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3008]
	ldrh	w9, [sp, #2232]
	strb	w8, [sp, #2925]
	ldr	w8, [sp, #1096]                 ; 4-byte Folded Reload
	strh	w9, [x3]
	ldr	w9, [sp, #1120]                 ; 4-byte Folded Reload
	strh	w8, [sp, #2926]
	ldr	w8, [sp, #1040]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3033]
	ldr	w9, [sp, #2224]
	strb	w8, [sp, #2936]
	ldrh	w8, [sp, #2240]
	str	w9, [x14]
	ldr	w9, [sp, #808]                  ; 4-byte Folded Reload
	strh	w8, [x2, #4]
	ldr	x8, [sp, #1144]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2648]
	ldr	w9, [sp, #780]                  ; 4-byte Folded Reload
	str	x8, [sp, #2968]
	ldr	x8, [sp, #1152]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2649]
	ldr	w9, [sp, #948]                  ; 4-byte Folded Reload
	str	x8, [sp, #3000]
	ldrb	w8, [sp, #2234]
	str	w9, [sp, #2656]
	ldr	w9, [sp, #776]                  ; 4-byte Folded Reload
	strb	w8, [x3, #2]
	ldr	w8, [sp, #1116]                 ; 4-byte Folded Reload
	str	w9, [sp, #2660]
	ldr	x9, [sp, #952]                  ; 8-byte Folded Reload
	strb	w8, [sp, #3020]
	ldr	w8, [sp, #1108]                 ; 4-byte Folded Reload
	str	x9, [sp, #2664]
	ldr	w9, [sp, #812]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3021]
	ldr	w8, [sp, #1072]                 ; 4-byte Folded Reload
	str	w9, [sp, #2688]
	ldr	w9, [sp, #772]                  ; 4-byte Folded Reload
	strh	w8, [sp, #3022]
	ldr	w8, [sp, #1112]                 ; 4-byte Folded Reload
	str	w9, [sp, #2692]
	ldr	x9, [sp, #800]                  ; 8-byte Folded Reload
	strb	w8, [sp, #3032]
	ldrh	w8, [sp, #2228]
	str	x9, [sp, #2704]
	ldr	x9, [sp, #792]                  ; 8-byte Folded Reload
	strh	w8, [x14, #4]
	ldr	w8, [sp, #1404]                 ; 4-byte Folded Reload
	str	x9, [sp, #2712]
	ldr	w9, [sp, #920]                  ; 4-byte Folded Reload
	str	w8, [sp, #2628]
	ldr	w8, [sp, #788]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2720]
	ldr	w9, [sp, #876]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2636]
	ldr	w8, [sp, #784]                  ; 4-byte Folded Reload
	str	w9, [sp, #2724]
	ldr	w9, [sp, #872]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2637]
	ldr	w8, [sp, #816]                  ; 4-byte Folded Reload
	str	w9, [sp, #2728]
	ldr	w9, [sp, #912]                  ; 4-byte Folded Reload
	strh	w8, [sp, #2638]
	ldr	w8, [sp, #1412]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2732]
	ldr	w9, [sp, #916]                  ; 4-byte Folded Reload
	stur	q27, [x23, #68]
	strb	w9, [sp, #2733]
	ldr	w9, [sp, #760]                  ; 4-byte Folded Reload
	str	d8, [x23, #384]
	strh	w9, [sp, #2734]
	ldr	w9, [sp, #868]                  ; 4-byte Folded Reload
	str	d14, [x23, #480]
	mov	x23, x20
	str	w9, [sp, #2736]
	ldr	w9, [sp, #864]                  ; 4-byte Folded Reload
	str	d0, [sp, #2304]
	str	w9, [sp, #2740]
	ldr	w9, [sp, #904]                  ; 4-byte Folded Reload
	str	d3, [sp, #2352]
	strb	w9, [sp, #2744]
	ldr	w9, [sp, #908]                  ; 4-byte Folded Reload
	str	d4, [sp, #2368]
	strb	w9, [sp, #2745]
	ldr	w9, [sp, #964]                  ; 4-byte Folded Reload
	str	d6, [sp, #2400]
	str	w9, [sp, #2752]
	ldr	w9, [sp, #828]                  ; 4-byte Folded Reload
	str	d17, [sp, #2448]
	str	w9, [sp, #2756]
	ldr	x9, [sp, #856]                  ; 8-byte Folded Reload
	str	d18, [sp, #2464]
	str	x9, [sp, #2760]
	ldr	x9, [sp, #848]                  ; 8-byte Folded Reload
	str	d20, [sp, #2496]
	str	x9, [sp, #2768]
	ldr	x9, [sp, #840]                  ; 8-byte Folded Reload
	str	d23, [sp, #2544]
	str	x9, [sp, #2776]
	ldr	w9, [sp, #888]                  ; 4-byte Folded Reload
	str	d24, [sp, #2560]
	str	w9, [sp, #2784]
	ldr	w9, [sp, #824]                  ; 4-byte Folded Reload
	str	d26, [sp, #2592]
	str	w9, [sp, #2788]
	ldr	x9, [sp, #832]                  ; 8-byte Folded Reload
	str	w11, [sp, #2640]
	str	x9, [sp, #2800]
	ldr	x9, [sp, #936]                  ; 8-byte Folded Reload
	str	w8, [sp, #2644]
	str	x9, [sp, #2808]
	ldr	w9, [sp, #900]                  ; 4-byte Folded Reload
	str	x15, [sp, #2672]
	strb	w9, [sp, #2816]
	ldr	w9, [sp, #944]                  ; 4-byte Folded Reload
	str	x25, [sp, #2680]
	str	w9, [sp, #2820]
	ldr	w9, [sp, #932]                  ; 4-byte Folded Reload
	str	x30, [sp, #2696]
	str	w9, [sp, #2824]
	ldr	w9, [sp, #896]                  ; 4-byte Folded Reload
	str	d28, [sp, #2848]
	strb	w9, [sp, #2828]
	ldr	w9, [sp, #892]                  ; 4-byte Folded Reload
	str	d30, [sp, #2880]
	strb	w9, [sp, #2829]
	ldr	w9, [sp, #1024]                 ; 4-byte Folded Reload
	str	q31, [x17]
	mov	w0, w9
	strh	w9, [sp, #2830]
	ldr	w9, [sp, #928]                  ; 4-byte Folded Reload
	str	d9, [sp, #2928]
	str	w9, [sp, #2832]
	ldr	w9, [sp, #924]                  ; 4-byte Folded Reload
	str	d10, [sp, #2944]
	str	w9, [sp, #2836]
	ldr	x9, [sp, #728]                  ; 8-byte Folded Reload
	str	q11, [x6]
	str	q29, [x9]
	str	d12, [sp, #2976]
	str	q13, [x5]
	str	d15, [sp, #3024]
	b.hi	LBB15_341
; %bb.127:                              ; %b274_to_b59.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x28, [sp, #1440]                ; 8-byte Folded Reload
	mov	x19, x25
	mov	x25, x30
	ldr	w30, [sp, #1388]                ; 4-byte Folded Reload
	mov	x10, x4
	mov	x4, x6
	add	x28, x28, #96
	mov	w20, w8
	add	x26, x26, #1
	str	x28, [sp, #1440]                ; 8-byte Folded Spill
	ldr	w28, [sp, #1392]                ; 4-byte Folded Reload
	add	w30, w30, #1, lsl #12           ; =4096
	str	w30, [sp, #1388]                ; 4-byte Folded Spill
	tbnz	w28, #0, LBB15_98
	b	LBB15_341
LBB15_128:                              ; %b82.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x3, [sp, #1360]                 ; 8-byte Folded Reload
	mov	x0, x27
	mov	x1, x22
	mov	x2, x23
	bl	_liza_rt_reactor_finish_connect
	lsr	x8, x0, #32
	cbnz	x8, LBB15_130
; %bb.129:                              ; %b1.i247.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	x0, #1
	mov	w10, wzr
	cset	w9, eq
	b	LBB15_144
LBB15_130:                              ; %v10_ok.i.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB15_142
; %bb.131:                              ; %v10_ok.i.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh96:
	adrp	x12, lJTI15_7@PAGE
Lloh97:
	add	x12, x12, lJTI15_7@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB15_132
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_132:                              ; %b4.i.i245.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB15_143
LBB15_133:                              ; %b34.i.i240.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB15_143
LBB15_134:                              ; %b13.i.i242.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB15_143
LBB15_135:                              ; %b16.i.i241.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB15_143
LBB15_136:                              ; %b10.i.i243.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB15_143
LBB15_137:                              ; %b7.i.i244.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB15_143
LBB15_138:                              ; %b22.i.i239.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB15_143
LBB15_139:                              ; %b25.i.i238.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB15_143
LBB15_140:                              ; %b31.i.i233.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB15_143
LBB15_141:                              ; %b28.i.i237.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB15_143
LBB15_142:                              ; %b36.i.i246.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #6                          ; =0x6
LBB15_143:                              ; %liza___liza_reactor_error.exit.i234.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	mov	w10, #1                         ; =0x1
LBB15_144:                              ; %liza_net.reactor_finish_connect.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w15, [sp, #1432]                ; 4-byte Folded Reload
	mov	w19, w28
	cmp	w10, #1
	mov	w11, w25
	b.ne	LBB15_146
; %bb.145:                              ; %b85.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w25, [sp, #1424]                ; 4-byte Folded Reload
	mov	w26, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	str	w21, [sp, #1328]                ; 4-byte Folded Spill
	tst	w8, w9
	b.ne	LBB15_113
	b	LBB15_147
LBB15_146:                              ; %b89.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w25, [sp, #1424]                ; 4-byte Folded Reload
	and	w8, w9, #0x1
	str	w8, [sp, #1328]                 ; 4-byte Folded Spill
LBB15_147:                              ; %b95.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	b.hi	LBB15_151
; %bb.148:                              ; %b95.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, #2048
	b.hi	LBB15_151
; %bb.149:                              ; %b4.i.i257.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	ldr	w26, [sp, #1404]                ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w25, #0, LBB15_160
; %bb.150:                              ; %b4.i.i257.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	and	w8, w26, w8
	cbnz	w8, LBB15_160
LBB15_151:                              ; %b114.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1328]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_199
; %bb.152:                              ; %b118.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	b.hi	LBB15_199
; %bb.153:                              ; %b118.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, #2048
	b.hi	LBB15_199
; %bb.154:                              ; %b118.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	tbnz	w25, #0, LBB15_199
; %bb.155:                              ; %b118.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, w11
	b.eq	LBB15_199
; %bb.156:                              ; %v253_ok.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1388]                 ; 4-byte Folded Reload
	adds	w6, w8, w11
	b.hs	LBB15_346
; %bb.157:                              ; %b3.i325.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x3, [sp, #1360]                 ; 8-byte Folded Reload
	subs	w20, w15, w11
	b.lo	LBB15_346
; %bb.158:                              ; %liza_relay.direction.queued.exit330.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	mov	x0, x27
	mov	x1, x22
	mov	x2, x23
	mov	w5, #32768                      ; =0x8000
	mov	w7, w20
	mov	w21, w15
	mov	w26, w11
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1404]                ; 4-byte Folded Reload
	cbnz	x8, LBB15_166
; %bb.159:                              ; %b1.i.i354.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	b	LBB15_188
LBB15_160:                              ; %liza_relay.direction.readable.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, #2048
	b.eq	LBB15_151
; %bb.161:                              ; %liza_relay.direction.readable.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	eor	w8, w26, #0x1
	tbz	w8, #0, LBB15_151
; %bb.162:                              ; %liza_relay.direction.readable.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w24, #1
	b.eq	LBB15_151
; %bb.163:                              ; %liza_relay.direction.readable.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #5                          ; =0x5
	and	w8, w20, w8
	cbz	w8, LBB15_151
; %bb.164:                              ; %b4.i.i266.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #2048                       ; =0x800
	mov	w20, w19
	tst	w26, #0x1
	sub	w19, w8, w15
	ldr	w8, [sp, #1388]                 ; 4-byte Folded Reload
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1344]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1392]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	csel	w7, wzr, w19, ne
	add	w6, w15, w8
	mov	x0, x27
	mov	w5, #32768                      ; =0x8000
	mov	w28, w25
	mov	w21, w11
	str	w15, [sp, #1432]                ; 4-byte Folded Spill
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB15_169
; %bb.165:                              ; %b104.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w15, [sp, #1432]                ; 4-byte Folded Reload
	mov	w26, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w19, w20
	mov	w11, w21
	mov	w25, w28
	tst	w8, w9
	b.ne	LBB15_113
	b	LBB15_151
LBB15_166:                              ; %v8_ok.i.i336.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB15_186
; %bb.167:                              ; %v8_ok.i.i336.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh98:
	adrp	x12, lJTI15_8@PAGE
Lloh99:
	add	x12, x12, lJTI15_8@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB15_168
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_168:                              ; %b4.i.i.i352.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB15_187
LBB15_169:                              ; %b1.i295.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	mov	w1, wzr
	orr	w8, w28, w26
	mov	w9, #1                          ; =0x1
	tbnz	w8, #0, LBB15_173
; %bb.170:                              ; %b1.i295.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w12, [sp, #1328]                ; 4-byte Folded Reload
	cmp	w19, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w19, w20
	b.lo	LBB15_175
; %bb.171:                              ; %b12.i.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	cbz	w0, LBB15_174
; %bb.172:                              ; %v26_ok.i.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	mov	w1, w21
	add	w8, w8, w0
	b	LBB15_175
LBB15_173:                              ;   in Loop: Header=BB15_98 Depth=2
	ldr	w12, [sp, #1328]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w19, w20
	b	LBB15_175
LBB15_174:                              ; %b13.i.i21.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	mov	w1, w21
LBB15_175:                              ; %liza_relay.direction.read.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w9, #1
	b.eq	LBB15_112
; %bb.176:                              ; %b111.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	and	w9, w11, #0x1
	and	w25, w10, #0x1
	and	w12, w12, #0x1
	and	w19, w19, #0x1
	and	w13, w13, #0x1
	mov	w11, w1
	mov	w15, w8
	str	w9, [sp, #1404]                 ; 4-byte Folded Spill
	str	w12, [sp, #1328]                ; 4-byte Folded Spill
	str	w13, [sp, #1412]                ; 4-byte Folded Spill
	b	LBB15_151
LBB15_177:                              ; %b34.i.i.i347.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB15_187
LBB15_178:                              ; %b13.i.i.i349.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB15_187
LBB15_179:                              ; %b16.i.i.i348.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB15_187
LBB15_180:                              ; %b10.i.i.i350.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB15_187
LBB15_181:                              ; %b7.i.i.i351.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB15_187
LBB15_182:                              ; %b22.i.i.i346.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB15_187
LBB15_183:                              ; %b25.i.i.i345.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB15_187
LBB15_184:                              ; %b31.i.i.i339.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB15_187
LBB15_185:                              ; %b28.i.i.i344.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB15_187
LBB15_186:                              ; %b36.i.i.i353.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #6                          ; =0x6
LBB15_187:                              ; %liza___liza_reactor_error.exit.i.i340.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB15_188:                              ; %liza_net.reactor_write.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w15, w21
	cmp	w9, #1
	mov	w11, w26
	b.ne	LBB15_190
; %bb.189:                              ; %b124.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w26, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB15_113
	b	LBB15_199
LBB15_190:                              ; %b4.i.i368.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cbz	w0, LBB15_192
; %bb.191:                              ; %liza_relay.direction.queued.exit.i.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w0, w20
	b.ls	LBB15_193
LBB15_192:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w11, wzr
	mov	w15, wzr
	mov	w14, wzr
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB15_112
	b	LBB15_198
LBB15_193:                              ; %b9.i.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	adds	w11, w11, w0
	b.hs	LBB15_346
; %bb.194:                              ; %v13_ok.i.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	b.ne	LBB15_196
; %bb.195:                              ; %b10.i.i19.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	mov	w11, wzr
	mov	w15, wzr
	b	LBB15_197
LBB15_196:                              ; %b12.i374.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
LBB15_197:                              ; %liza_relay.direction.write.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB15_112
LBB15_198:                              ; %b131.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	and	w25, w8, #0x1
	ldr	w8, [sp, #1412]                 ; 4-byte Folded Reload
	and	w14, w14, #0x1
	and	w13, w13, #0x1
	and	w19, w19, #0x1
	str	w14, [sp, #1404]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w13, [sp, #1328]                ; 4-byte Folded Spill
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
LBB15_199:                              ; %b134.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1328]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_224
; %bb.200:                              ; %b138.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	b.hi	LBB15_224
; %bb.201:                              ; %b138.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, #2048
	b.hi	LBB15_224
; %bb.202:                              ; %b4.i.i385.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	tbnz	w25, #0, LBB15_224
; %bb.203:                              ; %b4.i.i385.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1404]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_224
; %bb.204:                              ; %b4.i.i385.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	b.ne	LBB15_224
; %bb.205:                              ; %b141.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x3, [sp, #1360]                 ; 8-byte Folded Reload
	mov	x0, x27
	mov	x1, x22
	mov	x2, x23
	mov	w21, w11
	mov	w20, w15
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB15_207
; %bb.206:                              ; %b1.i.i414.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	b	LBB15_221
LBB15_207:                              ; %v8_ok.i.i396.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB15_219
; %bb.208:                              ; %v8_ok.i.i396.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh100:
	adrp	x12, lJTI15_9@PAGE
Lloh101:
	add	x12, x12, lJTI15_9@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB15_209
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_209:                              ; %b4.i.i.i412.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB15_220
LBB15_210:                              ; %b34.i.i.i407.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB15_220
LBB15_211:                              ; %b13.i.i.i409.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB15_220
LBB15_212:                              ; %b16.i.i.i408.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB15_220
LBB15_213:                              ; %b10.i.i.i410.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB15_220
LBB15_214:                              ; %b7.i.i.i411.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB15_220
LBB15_215:                              ; %b22.i.i.i406.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB15_220
LBB15_216:                              ; %b25.i.i.i405.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB15_220
LBB15_217:                              ; %b31.i.i.i399.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB15_220
LBB15_218:                              ; %b28.i.i.i404.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB15_220
LBB15_219:                              ; %b36.i.i.i413.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #6                          ; =0x6
LBB15_220:                              ; %liza___liza_reactor_error.exit.i.i400.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
LBB15_221:                              ; %liza_net.reactor_shutdown_write.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w10, [sp, #1328]                ; 4-byte Folded Reload
	mov	w15, w20
	cmp	w9, #1
	mov	w11, w21
	b.ne	LBB15_223
; %bb.222:                              ; %b144.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w26, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB15_113
	b	LBB15_224
LBB15_223:                              ; %b151.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1412]                 ; 4-byte Folded Reload
	and	w10, w10, #0x1
	and	w19, w19, #0x1
	mov	w15, w11
	mov	w25, #1                         ; =0x1
	str	w10, [sp, #1328]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
LBB15_224:                              ; %b154.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1328]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_229
; %bb.225:                              ; %b158.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1408]                 ; 4-byte Folded Reload
	ldr	w26, [sp, #1416]                ; 4-byte Folded Reload
	cmp	w8, w26
	b.hi	LBB15_229
; %bb.226:                              ; %b158.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w26, #2048
	b.hi	LBB15_229
; %bb.227:                              ; %b4.i.i435.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w8, w26
	ldr	w9, [sp, #1412]                 ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w9, #0, LBB15_255
; %bb.228:                              ; %b4.i.i435.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	and	w8, w19, w8
	cbnz	w8, LBB15_255
LBB15_229:                              ; %b177.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1328]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_239
; %bb.230:                              ; %b181.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	str	w19, [sp, #1312]                ; 4-byte Folded Spill
	ldr	w19, [sp, #1408]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	cmp	w19, w8
	b.hi	LBB15_238
; %bb.231:                              ; %b181.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w8, #2048
	b.hi	LBB15_238
; %bb.232:                              ; %b181.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w9, [sp, #1412]                 ; 4-byte Folded Reload
	tbnz	w9, #0, LBB15_238
; %bb.233:                              ; %b181.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w8, w19
	b.eq	LBB15_238
; %bb.234:                              ; %v393_ok.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1388]                 ; 4-byte Folded Reload
	add	w8, w8, #2048
	adds	w6, w8, w19
	b.hs	LBB15_346
; %bb.235:                              ; %b3.i550.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	subs	w20, w8, w19
	b.lo	LBB15_346
; %bb.236:                              ; %liza_relay.direction.queued.exit555.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x2, [sp, #1344]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1392]                 ; 8-byte Folded Reload
	mov	x0, x27
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	mov	w5, #32768                      ; =0x8000
	mov	w7, w20
	mov	w28, w25
	mov	w21, w11
	mov	w26, w15
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1328]                ; 4-byte Folded Reload
	cbnz	x8, LBB15_260
; %bb.237:                              ; %b1.i.i581.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	b	LBB15_311
LBB15_238:                              ;   in Loop: Header=BB15_98 Depth=2
	ldr	w19, [sp, #1312]                ; 4-byte Folded Reload
LBB15_239:                              ; %b197.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1328]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_248
; %bb.240:                              ; %b201.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w20, w19
	ldr	w19, [sp, #1408]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	cmp	w19, w8
	b.hi	LBB15_247
; %bb.241:                              ; %b201.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w8, #2048
	b.hi	LBB15_247
; %bb.242:                              ; %b4.i.i644.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w9, [sp, #1412]                 ; 4-byte Folded Reload
	tbnz	w9, #0, LBB15_247
; %bb.243:                              ; %b4.i.i644.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	tbz	w20, #0, LBB15_247
; %bb.244:                              ; %b4.i.i644.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w19, w8
	b.ne	LBB15_247
; %bb.245:                              ; %b204.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1344]                 ; 8-byte Folded Reload
	mov	x0, x27
	ldr	x3, [sp, #1392]                 ; 8-byte Folded Reload
	mov	w28, w25
	str	w11, [sp, #1368]                ; 4-byte Folded Spill
	mov	w21, w15
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB15_274
; %bb.246:                              ; %b1.i.i678.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	b	LBB15_338
LBB15_247:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w19, w20
LBB15_248:                              ; %b217.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	tbz	w25, #0, LBB15_250
; %bb.249:                              ; %b217.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w26, [sp, #1320]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1412]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB15_113
LBB15_250:                              ; %b227.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	mov	w8, #2049                       ; =0x801
	ccmp	w15, w8, #2, ls
	cset	w8, lo
	cmp	w8, #1
	b.ne	LBB15_254
; %bb.251:                              ; %b4.i.i713.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w11, w15
	ldr	w14, [sp, #1404]                ; 4-byte Folded Reload
	cset	w9, eq
	tbz	w25, #0, LBB15_263
; %bb.252:                              ; %b4.i.i713.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	and	w9, w14, w9
	cbnz	w9, LBB15_263
; %bb.253:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w4, wzr
	b	LBB15_264
LBB15_254:                              ;   in Loop: Header=BB15_98 Depth=2
	ldr	w12, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1408]                ; 4-byte Folded Reload
	mov	w4, wzr
	ldr	w14, [sp, #1404]                ; 4-byte Folded Reload
	b	LBB15_265
LBB15_255:                              ; %liza_relay.direction.readable.exit445.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w26, #2048
	b.eq	LBB15_229
; %bb.256:                              ; %liza_relay.direction.readable.exit445.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	eor	w8, w19, #0x1
	tbz	w8, #0, LBB15_229
; %bb.257:                              ; %liza_relay.direction.readable.exit445.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x9, [sp, #1368]                 ; 8-byte Folded Reload
	mov	w8, #5                          ; =0x5
	and	w8, w9, w8
	cbz	w8, LBB15_229
; %bb.258:                              ; %b4.i.i452.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #2048                       ; =0x800
	mov	w20, w19
	ldr	x3, [sp, #1360]                 ; 8-byte Folded Reload
	sub	w19, w8, w26
	ldr	w8, [sp, #1388]                 ; 4-byte Folded Reload
	tst	w20, #0x1
	ldr	x4, [sp, #152]                  ; 8-byte Folded Reload
	csel	w7, wzr, w19, ne
	mov	x0, x27
	add	w8, w26, w8
	mov	x1, x22
	mov	x2, x23
	add	w6, w8, #2048
	mov	w5, #32768                      ; =0x8000
	mov	w28, w25
	str	w11, [sp, #1368]                ; 4-byte Folded Spill
	mov	w21, w15
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB15_296
; %bb.259:                              ; %b167.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	mov	w26, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w19, w20
	mov	w15, w21
	mov	w25, w28
	tst	w8, w9
	b.ne	LBB15_113
	b	LBB15_229
LBB15_260:                              ; %v8_ok.i.i563.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB15_309
; %bb.261:                              ; %v8_ok.i.i563.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh102:
	adrp	x12, lJTI15_10@PAGE
Lloh103:
	add	x12, x12, lJTI15_10@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB15_262
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_262:                              ; %b4.i.i.i579.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB15_310
LBB15_263:                              ; %b1.i720.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, #2048
	eor	w10, w14, #0x1
	cset	w9, ne
	and	w4, w9, w10
LBB15_264:                              ; %liza_relay.direction.readable.exit723.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w12, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1408]                ; 4-byte Folded Reload
LBB15_265:                              ; %liza_relay.direction.readable.exit723.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w26, [sp, #1416]                ; 4-byte Folded Reload
	str	w15, [sp, #1432]                ; 4-byte Folded Spill
	str	w25, [sp, #1424]                ; 4-byte Folded Spill
	cmp	w13, w26
	str	w14, [sp, #1404]                ; 4-byte Folded Spill
	b.hi	LBB15_270
; %bb.266:                              ; %liza_relay.direction.readable.exit723.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w26, #2048
	b.hi	LBB15_270
; %bb.267:                              ; %b4.i.i730.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w26, w13
	ldr	w9, [sp, #1412]                 ; 4-byte Folded Reload
	mov	w28, w11
	cset	w10, ne
	orr	w11, w4, #0x2
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	eor	w9, w9, #0x1
	orr	w10, w10, w19
	ldr	x24, [sp, #1360]                ; 8-byte Folded Reload
	and	w10, w9, w10
	tst	w10, #0x1
	csel	w4, w11, w4, ne
	tbz	w12, #0, LBB15_273
; %bb.268:                              ; %b4.i.i767.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w26, w13
	mov	w11, w28
	cset	w10, eq
	and	w10, w19, w10
	orr	w9, w9, w10
	tbz	w9, #0, LBB15_277
; %bb.269:                              ; %b1.i774.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w26, #2048
	eor	w10, w19, #0x1
	cset	w9, ne
	and	w20, w9, w10
	b	LBB15_278
LBB15_270:                              ; %b237.thread.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x1, [sp, #1336]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #1360]                ; 8-byte Folded Reload
	tbz	w12, #0, LBB15_272
; %bb.271:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w20, wzr
	cbz	w8, LBB15_284
	b	LBB15_279
LBB15_272:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w28, w11
LBB15_273:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w20, #2                         ; =0x2
	b	LBB15_285
LBB15_274:                              ; %v8_ok.i.i660.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB15_336
; %bb.275:                              ; %v8_ok.i.i660.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh104:
	adrp	x12, lJTI15_11@PAGE
Lloh105:
	add	x12, x12, lJTI15_11@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB15_276
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_276:                              ; %b4.i.i.i676.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB15_337
LBB15_277:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w20, wzr
LBB15_278:                              ; %liza_relay.direction.readable.exit777.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w25, [sp, #1424]                ; 4-byte Folded Reload
	cbz	w8, LBB15_284
LBB15_279:                              ; %b4.i.i784.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, w11
	cset	w8, ne
	bic	w8, w8, w25
	tbnz	w8, #0, LBB15_283
; %bb.280:                              ; %b4.i.i804.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	tbnz	w25, #0, LBB15_284
; %bb.281:                              ; %b4.i.i804.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1404]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB15_284
; %bb.282:                              ; %b4.i.i804.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w15, w11
	b.ne	LBB15_284
LBB15_283:                              ; %b246.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w28, w11
	orr	w20, w20, #0x2
	b	LBB15_285
LBB15_284:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w28, w11
LBB15_285:                              ; %b249.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x2, [sp, #1344]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1392]                 ; 8-byte Folded Reload
	mov	x0, x27
	mov	x21, x1
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	str	w19, [sp, #1312]                ; 4-byte Folded Spill
	cbnz	x8, LBB15_287
; %bb.286:                              ; %b1.i.i838.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w19, wzr
	b	LBB15_290
LBB15_287:                              ; %v8_ok.i.i820.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB15_289
; %bb.288:                              ; %v8_ok.i.i820.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh106:
	adrp	x11, lJTI15_12@PAGE
Lloh107:
	add	x11, x11, lJTI15_12@PAGEOFF
	adr	x9, LBB15_289
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB15_289:                              ; %liza___liza_reactor_error.exit.i.i824.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w19, #1                         ; =0x1
LBB15_290:                              ; %liza_net.reactor_interest.exit.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	x0, x27
	mov	x1, x22
	mov	x2, x23
	mov	x3, x24
	mov	w4, w20
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbnz	x8, LBB15_292
; %bb.291:                              ; %b1.i.i864.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	x12, [sp, #1392]                ; 8-byte Folded Reload
	orr	w8, w8, w19
	cbnz	w8, LBB15_112
	b	LBB15_295
LBB15_292:                              ; %v8_ok.i.i846.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	sub	w8, w8, #1
	ldr	x12, [sp, #1392]                ; 8-byte Folded Reload
	cmp	w8, #11
	b.hi	LBB15_294
; %bb.293:                              ; %v8_ok.i.i846.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
Lloh108:
	adrp	x11, lJTI15_13@PAGE
Lloh109:
	add	x11, x11, lJTI15_13@PAGEOFF
	adr	x9, LBB15_294
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB15_294:                              ; %liza___liza_reactor_error.exit.i.i850.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
	orr	w8, w8, w19
	cbnz	w8, LBB15_112
LBB15_295:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #1                          ; =0x1
	ldr	x20, [sp, #1344]                ; 8-byte Folded Reload
	ldr	w19, [sp, #1328]                ; 4-byte Folded Reload
	str	w26, [sp, #1416]                ; 4-byte Folded Spill
	ldr	w26, [sp, #1352]                ; 4-byte Folded Reload
	mov	x27, x12
	ldr	w25, [sp, #1304]                ; 4-byte Folded Reload
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	str	w28, [sp, #1368]                ; 4-byte Folded Spill
	mov	x28, x21
	b	LBB15_125
LBB15_296:                              ; %b1.i496.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w8, [sp, #1412]                 ; 4-byte Folded Reload
	mov	w1, wzr
	mov	w9, #1                          ; =0x1
	orr	w8, w8, w20
	tbnz	w8, #0, LBB15_323
; %bb.297:                              ; %b1.i496.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w12, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1404]                ; 4-byte Folded Reload
	cmp	w19, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
	b.lo	LBB15_325
; %bb.298:                              ; %b12.i502.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	cbz	w0, LBB15_324
; %bb.299:                              ; %v26_ok.i504.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w1, [sp, #1408]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w26, w0
	b	LBB15_325
LBB15_300:                              ; %b34.i.i.i574.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB15_310
LBB15_301:                              ; %b13.i.i.i576.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB15_310
LBB15_302:                              ; %b16.i.i.i575.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB15_310
LBB15_303:                              ; %b10.i.i.i577.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB15_310
LBB15_304:                              ; %b7.i.i.i578.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB15_310
LBB15_305:                              ; %b22.i.i.i573.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB15_310
LBB15_306:                              ; %b25.i.i.i572.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB15_310
LBB15_307:                              ; %b31.i.i.i566.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB15_310
LBB15_308:                              ; %b28.i.i.i571.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB15_310
LBB15_309:                              ; %b36.i.i.i580.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #6                          ; =0x6
LBB15_310:                              ; %liza___liza_reactor_error.exit.i.i567.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB15_311:                              ; %liza_net.reactor_write.exit584.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w15, w26
	cmp	w9, #1
	b.ne	LBB15_313
; %bb.312:                              ; %b187.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w19, [sp, #1312]                ; 4-byte Folded Reload
	mov	w26, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w11, w21
	mov	w25, w28
	tst	w8, w9
	b.ne	LBB15_113
	b	LBB15_239
LBB15_313:                              ; %b4.i.i596.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w10, [sp, #1404]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1416]                ; 4-byte Folded Reload
	cbz	w0, LBB15_315
; %bb.314:                              ; %liza_relay.direction.queued.exit.i611.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w0, w20
	b.ls	LBB15_316
LBB15_315:                              ;   in Loop: Header=BB15_98 Depth=2
	mov	w19, wzr
	mov	w11, wzr
	str	wzr, [sp, #1312]                ; 4-byte Folded Spill
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	b	LBB15_321
LBB15_316:                              ; %b9.i614.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	adds	w19, w19, w0
	b.hs	LBB15_346
; %bb.317:                              ; %v13_ok.i618.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w19, w11
	b.ne	LBB15_319
; %bb.318:                              ; %b10.i626.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
	mov	w19, wzr
	mov	w11, wzr
	b	LBB15_320
LBB15_319:                              ; %b12.i620.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, wzr
LBB15_320:                              ; %liza_relay.direction.write.exit636.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, wzr
LBB15_321:                              ; %liza_relay.direction.write.exit636.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w9, #1
	b.eq	LBB15_112
; %bb.322:                              ; %b194.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	str	w19, [sp, #1408]                ; 4-byte Folded Spill
	ldr	w19, [sp, #1312]                ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w11, [sp, #1416]                ; 4-byte Folded Spill
	and	w13, w13, #0x1
	and	w10, w10, #0x1
	and	w19, w19, #0x1
	and	w25, w28, #0x1
	mov	w11, w21
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	str	w13, [sp, #1328]                ; 4-byte Folded Spill
	str	w10, [sp, #1404]                ; 4-byte Folded Spill
	b	LBB15_239
LBB15_323:                              ;   in Loop: Header=BB15_98 Depth=2
	ldr	w12, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1404]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
	b	LBB15_325
LBB15_324:                              ; %b13.i511.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w1, [sp, #1408]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	mov	w8, w26
LBB15_325:                              ; %liza_relay.direction.read.exit517.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	cmp	w9, #1
	b.eq	LBB15_112
; %bb.326:                              ; %b174.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	and	w19, w11, #0x1
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	and	w9, w10, #0x1
	and	w12, w12, #0x1
	and	w13, w13, #0x1
	and	w25, w28, #0x1
	str	w9, [sp, #1412]                 ; 4-byte Folded Spill
	str	w12, [sp, #1328]                ; 4-byte Folded Spill
	str	w13, [sp, #1404]                ; 4-byte Folded Spill
	str	w1, [sp, #1408]                 ; 4-byte Folded Spill
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	b	LBB15_229
LBB15_327:                              ; %b34.i.i.i671.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB15_337
LBB15_328:                              ; %b13.i.i.i673.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB15_337
LBB15_329:                              ; %b16.i.i.i672.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB15_337
LBB15_330:                              ; %b10.i.i.i674.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB15_337
LBB15_331:                              ; %b7.i.i.i675.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB15_337
LBB15_332:                              ; %b22.i.i.i670.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB15_337
LBB15_333:                              ; %b25.i.i.i669.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB15_337
LBB15_334:                              ; %b31.i.i.i663.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB15_337
LBB15_335:                              ; %b28.i.i.i668.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB15_337
LBB15_336:                              ; %b36.i.i.i677.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w8, #6                          ; =0x6
LBB15_337:                              ; %liza___liza_reactor_error.exit.i.i664.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
LBB15_338:                              ; %liza_net.reactor_shutdown_write.exit681.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	ldr	w10, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1404]                ; 4-byte Folded Reload
	mov	w15, w21
	cmp	w9, #1
	b.ne	LBB15_340
; %bb.339:                              ; %b207.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	mov	w26, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w19, w20
	mov	w25, w28
	tst	w8, w9
	b.ne	LBB15_113
	b	LBB15_248
LBB15_340:                              ; %b214.i.i
                                        ;   in Loop: Header=BB15_98 Depth=2
	and	w11, w11, #0x1
	and	w10, w10, #0x1
	and	w25, w28, #0x1
	str	w11, [sp, #1404]                ; 4-byte Folded Spill
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	mov	w8, #1                          ; =0x1
	str	w19, [sp, #1416]                ; 4-byte Folded Spill
	mov	w19, #1                         ; =0x1
	str	w10, [sp, #1328]                ; 4-byte Folded Spill
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	b	LBB15_248
LBB15_341:                              ; %b61_to_b13.i.i.loopexit
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldrb	w8, [sp, #2624]
	ldr	x30, [sp, #744]                 ; 8-byte Folded Reload
	mov	x26, x13
	str	w8, [sp, #168]                  ; 4-byte Folded Spill
	b	LBB15_46
LBB15_342:                              ;   in Loop: Header=BB15_47 Depth=1
	mov	w8, #1                          ; =0x1
	add	x11, sp, #1, lsl #12            ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	add	x8, sp, #4014
	add	x16, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x21, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	add	x8, sp, #4092
	add	x11, x11, #8
	add	x10, x10, #12
	add	x16, x16, #20
	add	x15, x15, #24
	add	x1, x1, #32
	add	x2, x2, #36
	add	x6, x6, #44
	add	x19, x19, #48
	add	x21, x21, #56
	add	x22, x22, #60
	add	x24, x24, #68
	b	LBB15_95
LBB15_343:                              ; %b1.i147.i.i
                                        ;   in Loop: Header=BB15_47 Depth=1
	ldr	x10, [sp, #4296]
	ldr	x9, [sp, #4304]
	mov	w11, wzr
	ldr	x8, [sp, #4312]
	b	LBB15_91
LBB15_344:                              ; %liza_liza_proxy.exchange.exit.i
	ldr	x0, [sp, #680]                  ; 8-byte Folded Reload
	bl	_liza_rt_reactor_close
	cmp	w0, #0
	ldr	x0, [sp, #144]                  ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	csel	w19, w20, w8, eq
	bl	_liza_rt_region_close
	mov	w0, w19
	b	LBB15_20
LBB15_345:                              ; %b1.i.i49.i.i
	mov	w19, wzr
	b	LBB15_35
LBB15_346:                              ; %v256_trap.i.i
	brk	#0x1
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpAdd	Lloh66, Lloh67
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpAdd	Lloh70, Lloh71
	.loh AdrpAdd	Lloh72, Lloh73
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpAdd	Lloh76, Lloh77
	.loh AdrpAdd	Lloh78, Lloh79
	.loh AdrpAdd	Lloh80, Lloh81
	.loh AdrpAdd	Lloh82, Lloh83
	.loh AdrpAdd	Lloh84, Lloh85
	.loh AdrpAdd	Lloh86, Lloh87
	.loh AdrpAdd	Lloh88, Lloh89
	.loh AdrpAdd	Lloh90, Lloh91
	.loh AdrpAdd	Lloh92, Lloh93
	.loh AdrpAdd	Lloh94, Lloh95
	.loh AdrpAdd	Lloh96, Lloh97
	.loh AdrpAdd	Lloh98, Lloh99
	.loh AdrpAdd	Lloh100, Lloh101
	.loh AdrpAdd	Lloh102, Lloh103
	.loh AdrpAdd	Lloh104, Lloh105
	.loh AdrpAdd	Lloh106, Lloh107
	.loh AdrpAdd	Lloh108, Lloh109
	.cfi_endproc
	.section	__TEXT,__const
lJTI15_0:
	.byte	(LBB15_14-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
lJTI15_1:
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
	.byte	(LBB15_24-LBB15_24)>>2
lJTI15_2:
	.byte	(LBB15_62-LBB15_51)>>2
	.byte	(LBB15_51-LBB15_51)>>2
	.byte	(LBB15_56-LBB15_51)>>2
	.byte	(LBB15_55-LBB15_51)>>2
	.byte	(LBB15_53-LBB15_51)>>2
	.byte	(LBB15_54-LBB15_51)>>2
	.byte	(LBB15_61-LBB15_51)>>2
	.byte	(LBB15_57-LBB15_51)>>2
	.byte	(LBB15_58-LBB15_51)>>2
	.byte	(LBB15_60-LBB15_51)>>2
	.byte	(LBB15_59-LBB15_51)>>2
	.byte	(LBB15_52-LBB15_51)>>2
lJTI15_3:
	.byte	(LBB15_70-LBB15_70)>>2
	.byte	(LBB15_84-LBB15_70)>>2
	.byte	(LBB15_74-LBB15_70)>>2
	.byte	(LBB15_79-LBB15_70)>>2
	.byte	(LBB15_80-LBB15_70)>>2
	.byte	(LBB15_75-LBB15_70)>>2
	.byte	(LBB15_77-LBB15_70)>>2
	.byte	(LBB15_83-LBB15_70)>>2
	.byte	(LBB15_78-LBB15_70)>>2
	.byte	(LBB15_82-LBB15_70)>>2
	.byte	(LBB15_81-LBB15_70)>>2
	.byte	(LBB15_73-LBB15_70)>>2
	.byte	(LBB15_76-LBB15_70)>>2
	.p2align	1, 0x0
lJTI15_4:
	.short	(LBB15_343-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
	.short	(LBB15_90-LBB15_90)>>2
lJTI15_5:
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
	.byte	(LBB15_106-LBB15_106)>>2
lJTI15_6:
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
	.byte	(LBB15_110-LBB15_110)>>2
lJTI15_7:
	.byte	(LBB15_143-LBB15_132)>>2
	.byte	(LBB15_132-LBB15_132)>>2
	.byte	(LBB15_137-LBB15_132)>>2
	.byte	(LBB15_136-LBB15_132)>>2
	.byte	(LBB15_134-LBB15_132)>>2
	.byte	(LBB15_135-LBB15_132)>>2
	.byte	(LBB15_142-LBB15_132)>>2
	.byte	(LBB15_138-LBB15_132)>>2
	.byte	(LBB15_139-LBB15_132)>>2
	.byte	(LBB15_141-LBB15_132)>>2
	.byte	(LBB15_140-LBB15_132)>>2
	.byte	(LBB15_133-LBB15_132)>>2
lJTI15_8:
	.byte	(LBB15_187-LBB15_168)>>2
	.byte	(LBB15_168-LBB15_168)>>2
	.byte	(LBB15_181-LBB15_168)>>2
	.byte	(LBB15_180-LBB15_168)>>2
	.byte	(LBB15_178-LBB15_168)>>2
	.byte	(LBB15_179-LBB15_168)>>2
	.byte	(LBB15_186-LBB15_168)>>2
	.byte	(LBB15_182-LBB15_168)>>2
	.byte	(LBB15_183-LBB15_168)>>2
	.byte	(LBB15_185-LBB15_168)>>2
	.byte	(LBB15_184-LBB15_168)>>2
	.byte	(LBB15_177-LBB15_168)>>2
lJTI15_9:
	.byte	(LBB15_220-LBB15_209)>>2
	.byte	(LBB15_209-LBB15_209)>>2
	.byte	(LBB15_214-LBB15_209)>>2
	.byte	(LBB15_213-LBB15_209)>>2
	.byte	(LBB15_211-LBB15_209)>>2
	.byte	(LBB15_212-LBB15_209)>>2
	.byte	(LBB15_219-LBB15_209)>>2
	.byte	(LBB15_215-LBB15_209)>>2
	.byte	(LBB15_216-LBB15_209)>>2
	.byte	(LBB15_218-LBB15_209)>>2
	.byte	(LBB15_217-LBB15_209)>>2
	.byte	(LBB15_210-LBB15_209)>>2
lJTI15_10:
	.byte	(LBB15_310-LBB15_262)>>2
	.byte	(LBB15_262-LBB15_262)>>2
	.byte	(LBB15_304-LBB15_262)>>2
	.byte	(LBB15_303-LBB15_262)>>2
	.byte	(LBB15_301-LBB15_262)>>2
	.byte	(LBB15_302-LBB15_262)>>2
	.byte	(LBB15_309-LBB15_262)>>2
	.byte	(LBB15_305-LBB15_262)>>2
	.byte	(LBB15_306-LBB15_262)>>2
	.byte	(LBB15_308-LBB15_262)>>2
	.byte	(LBB15_307-LBB15_262)>>2
	.byte	(LBB15_300-LBB15_262)>>2
lJTI15_11:
	.byte	(LBB15_337-LBB15_276)>>2
	.byte	(LBB15_276-LBB15_276)>>2
	.byte	(LBB15_331-LBB15_276)>>2
	.byte	(LBB15_330-LBB15_276)>>2
	.byte	(LBB15_328-LBB15_276)>>2
	.byte	(LBB15_329-LBB15_276)>>2
	.byte	(LBB15_336-LBB15_276)>>2
	.byte	(LBB15_332-LBB15_276)>>2
	.byte	(LBB15_333-LBB15_276)>>2
	.byte	(LBB15_335-LBB15_276)>>2
	.byte	(LBB15_334-LBB15_276)>>2
	.byte	(LBB15_327-LBB15_276)>>2
lJTI15_12:
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
	.byte	(LBB15_289-LBB15_289)>>2
lJTI15_13:
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
	.byte	(LBB15_294-LBB15_294)>>2
lJTI15_14:
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
	.byte	(LBB15_119-LBB15_119)>>2
lJTI15_15:
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
	.byte	(LBB15_123-LBB15_123)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza___liza_decode             ; -- Begin function liza___liza_decode
	.p2align	2
_liza___liza_decode:                    ; @liza___liza_decode
; %bb.0:                                ; %b0
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB16_5
; %bb.1:                                ; %b0
	cbz	w8, LBB16_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB16_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB16_11
; %bb.4:                                ; %b7
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ret
LBB16_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB16_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB16_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB16_11
; %bb.8:                                ; %b16
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB16_9:                                ; %b1
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ret
LBB16_10:                               ; %b10
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	mov	w0, #1                          ; =0x1
	ret
LBB16_11:                               ; %b18
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	mov	w0, #1                          ; =0x1
	ret
LBB16_12:                               ; %b4
	mov	x1, xzr
	mov	w2, wzr
	mov	w0, #1                          ; =0x1
	ret
LBB16_13:                               ; %b13
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_console.write             ; -- Begin function liza_console.write
	.p2align	2
_liza_console.write:                    ; @liza_console.write
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_write_text
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB17_5
; %bb.1:                                ; %b0
	cbz	w8, LBB17_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB17_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB17_11
; %bb.4:                                ; %b7.i
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB17_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB17_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB17_11
; %bb.8:                                ; %b16.i
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	b	LBB17_14
LBB17_9:                                ; %b1.i
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_10:                               ; %b10.i
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	b	LBB17_14
LBB17_11:                               ; %b18.i
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	b	LBB17_14
LBB17_12:                               ; %b4.i
	mov	x1, xzr
	mov	w2, wzr
	b	LBB17_14
LBB17_13:                               ; %b13.i
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
LBB17_14:                               ; %liza___liza_decode.exit
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_console.print_u64         ; -- Begin function liza_console.print_u64
	.p2align	2
_liza_console.print_u64:                ; @liza_console.print_u64
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_print_u64
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB18_5
; %bb.1:                                ; %b0
	cbz	w8, LBB18_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB18_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB18_11
; %bb.4:                                ; %b7.i
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB18_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB18_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB18_11
; %bb.8:                                ; %b16.i
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	b	LBB18_14
LBB18_9:                                ; %b1.i
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_10:                               ; %b10.i
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	b	LBB18_14
LBB18_11:                               ; %b18.i
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	b	LBB18_14
LBB18_12:                               ; %b4.i
	mov	x1, xzr
	mov	w2, wzr
	b	LBB18_14
LBB18_13:                               ; %b13.i
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
LBB18_14:                               ; %liza___liza_decode.exit
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_console.err               ; -- Begin function liza_console.err
	.p2align	2
_liza_console.err:                      ; @liza_console.err
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_err_text
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB19_5
; %bb.1:                                ; %b0
	cbz	w8, LBB19_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB19_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB19_11
; %bb.4:                                ; %b7.i
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB19_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB19_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB19_11
; %bb.8:                                ; %b16.i
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	b	LBB19_14
LBB19_9:                                ; %b1.i
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_10:                               ; %b10.i
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	b	LBB19_14
LBB19_11:                               ; %b18.i
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	b	LBB19_14
LBB19_12:                               ; %b4.i
	mov	x1, xzr
	mov	w2, wzr
	b	LBB19_14
LBB19_13:                               ; %b13.i
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
LBB19_14:                               ; %liza___liza_decode.exit
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_cli.count                 ; -- Begin function liza_cli.count
	.p2align	2
_liza_cli.count:                        ; @liza_cli.count
	.cfi_startproc
; %bb.0:                                ; %b0
	b	_liza_rt_cli_count
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_cli.arg                   ; -- Begin function liza_cli.arg
	.p2align	2
_liza_cli.arg:                          ; @liza_cli.arg
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w19, w0
	bl	_liza_rt_cli_count
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	cmp	w19, w0
	csel	w1, w19, wzr, lo
	cset	w0, hs
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_cli.equals                ; -- Begin function liza_cli.equals
	.p2align	2
_liza_cli.equals:                       ; @liza_cli.equals
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_cli_equals
	cmp	w0, #0
	cset	w0, ne
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza___liza_reactor_error      ; -- Begin function liza___liza_reactor_error
	.p2align	2
_liza___liza_reactor_error:             ; @liza___liza_reactor_error
; %bb.0:                                ; %b0
	sub	w8, w0, #1
	cmp	w8, #11
	b.hi	LBB23_13
; %bb.1:                                ; %b0
Lloh110:
	adrp	x9, lJTI23_0@PAGE
Lloh111:
	add	x9, x9, lJTI23_0@PAGEOFF
	mov	w0, wzr
	adr	x10, LBB23_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB23_2:                                ; %b4
	mov	w0, #1                          ; =0x1
	ret
LBB23_3:                                ; %b34
	mov	w0, #11                         ; =0xb
	ret
LBB23_4:                                ; %b13
	mov	w0, #4                          ; =0x4
	ret
LBB23_5:                                ; %b16
	mov	w0, #5                          ; =0x5
	ret
LBB23_6:                                ; %b10
	mov	w0, #3                          ; =0x3
	ret
LBB23_7:                                ; %b7
	mov	w0, #2                          ; =0x2
	ret
LBB23_8:                                ; %b22
	mov	w0, #7                          ; =0x7
	ret
LBB23_9:                                ; %b25
	mov	w0, #8                          ; =0x8
	ret
LBB23_10:                               ; %b31
	mov	w0, #10                         ; =0xa
LBB23_11:                               ; %common.ret
	ret
LBB23_12:                               ; %b28
	mov	w0, #9                          ; =0x9
	ret
LBB23_13:                               ; %b36
	mov	w0, #6                          ; =0x6
	ret
	.loh AdrpAdd	Lloh110, Lloh111
	.section	__TEXT,__const
lJTI23_0:
	.byte	(LBB23_11-LBB23_2)>>2
	.byte	(LBB23_2-LBB23_2)>>2
	.byte	(LBB23_7-LBB23_2)>>2
	.byte	(LBB23_6-LBB23_2)>>2
	.byte	(LBB23_4-LBB23_2)>>2
	.byte	(LBB23_5-LBB23_2)>>2
	.byte	(LBB23_13-LBB23_2)>>2
	.byte	(LBB23_8-LBB23_2)>>2
	.byte	(LBB23_9-LBB23_2)>>2
	.byte	(LBB23_12-LBB23_2)>>2
	.byte	(LBB23_10-LBB23_2)>>2
	.byte	(LBB23_3-LBB23_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza___liza_reactor_status     ; -- Begin function liza___liza_reactor_status
	.p2align	2
_liza___liza_reactor_status:            ; @liza___liza_reactor_status
; %bb.0:                                ; %b0
	lsr	x8, x0, #32
	cbnz	x8, LBB24_2
; %bb.1:                                ; %b1
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ret
LBB24_2:                                ; %v8_ok
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB24_14
; %bb.3:                                ; %v8_ok
Lloh112:
	adrp	x9, lJTI24_0@PAGE
Lloh113:
	add	x9, x9, lJTI24_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB24_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB24_4:                                ; %b4.i
	mov	w2, #1                          ; =0x1
	b	LBB24_15
LBB24_5:                                ; %b34.i
	mov	w2, #11                         ; =0xb
	b	LBB24_15
LBB24_6:                                ; %b13.i
	mov	w2, #4                          ; =0x4
	b	LBB24_15
LBB24_7:                                ; %b16.i
	mov	w2, #5                          ; =0x5
	b	LBB24_15
LBB24_8:                                ; %b10.i
	mov	w2, #3                          ; =0x3
	b	LBB24_15
LBB24_9:                                ; %b7.i
	mov	w2, #2                          ; =0x2
	b	LBB24_15
LBB24_10:                               ; %b22.i
	mov	w2, #7                          ; =0x7
	b	LBB24_15
LBB24_11:                               ; %b25.i
	mov	w2, #8                          ; =0x8
	b	LBB24_15
LBB24_12:                               ; %b31.i
	mov	w2, #10                         ; =0xa
	b	LBB24_15
LBB24_13:                               ; %b28.i
	mov	w2, #9                          ; =0x9
	b	LBB24_15
LBB24_14:                               ; %b36.i
	mov	w2, #6                          ; =0x6
LBB24_15:                               ; %liza___liza_reactor_error.exit
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ret
	.loh AdrpAdd	Lloh112, Lloh113
	.section	__TEXT,__const
lJTI24_0:
	.byte	(LBB24_15-LBB24_4)>>2
	.byte	(LBB24_4-LBB24_4)>>2
	.byte	(LBB24_9-LBB24_4)>>2
	.byte	(LBB24_8-LBB24_4)>>2
	.byte	(LBB24_6-LBB24_4)>>2
	.byte	(LBB24_7-LBB24_4)>>2
	.byte	(LBB24_14-LBB24_4)>>2
	.byte	(LBB24_10-LBB24_4)>>2
	.byte	(LBB24_11-LBB24_4)>>2
	.byte	(LBB24_13-LBB24_4)>>2
	.byte	(LBB24_12-LBB24_4)>>2
	.byte	(LBB24_5-LBB24_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_create        ; -- Begin function liza_net.reactor_create
	.p2align	2
_liza_net.reactor_create:               ; @liza_net.reactor_create
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x2, sp, #8
	bl	_liza_rt_reactor_create
	cmp	w0, #12
	b.hi	LBB25_13
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh114:
	adrp	x9, lJTI25_0@PAGE
Lloh115:
	add	x9, x9, lJTI25_0@PAGEOFF
	adr	x10, LBB25_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	mov	w2, wzr
	br	x10
LBB25_2:                                ; %b1
	ldr	x1, [sp, #8]
	mov	w0, wzr
	mov	w2, wzr
	b	LBB25_15
LBB25_3:                                ; %b31.i
	mov	w2, #10                         ; =0xa
	b	LBB25_14
LBB25_4:                                ; %b4.i
	mov	w2, #1                          ; =0x1
	b	LBB25_14
LBB25_5:                                ; %b13.i
	mov	w2, #4                          ; =0x4
	b	LBB25_14
LBB25_6:                                ; %b34.i
	mov	w2, #11                         ; =0xb
	b	LBB25_14
LBB25_7:                                ; %b16.i
	mov	w2, #5                          ; =0x5
	b	LBB25_14
LBB25_8:                                ; %b22.i
	mov	w2, #7                          ; =0x7
	b	LBB25_14
LBB25_9:                                ; %b7.i
	mov	w2, #2                          ; =0x2
	b	LBB25_14
LBB25_10:                               ; %b10.i
	mov	w2, #3                          ; =0x3
	b	LBB25_14
LBB25_11:                               ; %b28.i
	mov	w2, #9                          ; =0x9
	b	LBB25_14
LBB25_12:                               ; %b25.i
	mov	w2, #8                          ; =0x8
	b	LBB25_14
LBB25_13:                               ; %b36.i
	mov	w2, #6                          ; =0x6
LBB25_14:                               ; %liza___liza_reactor_error.exit
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
LBB25_15:                               ; %common.ret
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh114, Lloh115
	.cfi_endproc
	.section	__TEXT,__const
lJTI25_0:
	.byte	(LBB25_2-LBB25_2)>>2
	.byte	(LBB25_14-LBB25_2)>>2
	.byte	(LBB25_4-LBB25_2)>>2
	.byte	(LBB25_9-LBB25_2)>>2
	.byte	(LBB25_10-LBB25_2)>>2
	.byte	(LBB25_5-LBB25_2)>>2
	.byte	(LBB25_7-LBB25_2)>>2
	.byte	(LBB25_13-LBB25_2)>>2
	.byte	(LBB25_8-LBB25_2)>>2
	.byte	(LBB25_12-LBB25_2)>>2
	.byte	(LBB25_11-LBB25_2)>>2
	.byte	(LBB25_3-LBB25_2)>>2
	.byte	(LBB25_6-LBB25_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_accept        ; -- Begin function liza_net.reactor_accept
	.p2align	2
_liza_net.reactor_accept:               ; @liza_net.reactor_accept
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x1, sp, #8
	bl	_liza_rt_reactor_accept
	cmp	w0, #12
	b.hi	LBB26_13
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh116:
	adrp	x9, lJTI26_0@PAGE
Lloh117:
	add	x9, x9, lJTI26_0@PAGEOFF
	adr	x10, LBB26_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	mov	w4, wzr
	br	x10
LBB26_2:                                ; %b1
	ldp	x1, x2, [sp, #8]
	mov	w0, wzr
	ldr	x3, [sp, #24]
	mov	w4, wzr
	b	LBB26_15
LBB26_3:                                ; %b31.i
	mov	w4, #10                         ; =0xa
	b	LBB26_14
LBB26_4:                                ; %b4.i
	mov	w4, #1                          ; =0x1
	b	LBB26_14
LBB26_5:                                ; %b13.i
	mov	w4, #4                          ; =0x4
	b	LBB26_14
LBB26_6:                                ; %b34.i
	mov	w4, #11                         ; =0xb
	b	LBB26_14
LBB26_7:                                ; %b16.i
	mov	w4, #5                          ; =0x5
	b	LBB26_14
LBB26_8:                                ; %b22.i
	mov	w4, #7                          ; =0x7
	b	LBB26_14
LBB26_9:                                ; %b7.i
	mov	w4, #2                          ; =0x2
	b	LBB26_14
LBB26_10:                               ; %b10.i
	mov	w4, #3                          ; =0x3
	b	LBB26_14
LBB26_11:                               ; %b28.i
	mov	w4, #9                          ; =0x9
	b	LBB26_14
LBB26_12:                               ; %b25.i
	mov	w4, #8                          ; =0x8
	b	LBB26_14
LBB26_13:                               ; %b36.i
	mov	w4, #6                          ; =0x6
LBB26_14:                               ; %liza___liza_reactor_error.exit
	mov	x1, xzr
	mov	x2, xzr
	mov	x3, xzr
	mov	w0, #1                          ; =0x1
LBB26_15:                               ; %common.ret
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh116, Lloh117
	.cfi_endproc
	.section	__TEXT,__const
lJTI26_0:
	.byte	(LBB26_2-LBB26_2)>>2
	.byte	(LBB26_14-LBB26_2)>>2
	.byte	(LBB26_4-LBB26_2)>>2
	.byte	(LBB26_9-LBB26_2)>>2
	.byte	(LBB26_10-LBB26_2)>>2
	.byte	(LBB26_5-LBB26_2)>>2
	.byte	(LBB26_7-LBB26_2)>>2
	.byte	(LBB26_13-LBB26_2)>>2
	.byte	(LBB26_8-LBB26_2)>>2
	.byte	(LBB26_12-LBB26_2)>>2
	.byte	(LBB26_11-LBB26_2)>>2
	.byte	(LBB26_3-LBB26_2)>>2
	.byte	(LBB26_6-LBB26_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_close         ; -- Begin function liza_net.reactor_close
	.p2align	2
_liza_net.reactor_close:                ; @liza_net.reactor_close
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_close
	cmp	w0, #12
	b.hi	LBB27_12
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh118:
	adrp	x10, lJTI27_0@PAGE
Lloh119:
	add	x10, x10, lJTI27_0@PAGEOFF
	mov	w8, w8
	mov	w0, wzr
	mov	w1, wzr
	adr	x11, LBB27_2
	ldrb	w12, [x10, x8]
	add	x11, x11, x12, lsl #2
	mov	w2, wzr
	mov	w9, wzr
	br	x11
LBB27_2:                                ; %b4.i
	mov	w9, #1                          ; =0x1
	b	LBB27_13
LBB27_3:                                ; %b31.i
	mov	w9, #10                         ; =0xa
	b	LBB27_13
LBB27_4:                                ; %b13.i
	mov	w9, #4                          ; =0x4
	b	LBB27_13
LBB27_5:                                ; %b34.i
	mov	w9, #11                         ; =0xb
	b	LBB27_13
LBB27_6:                                ; %b16.i
	mov	w9, #5                          ; =0x5
	b	LBB27_13
LBB27_7:                                ; %b22.i
	mov	w9, #7                          ; =0x7
	b	LBB27_13
LBB27_8:                                ; %b7.i
	mov	w9, #2                          ; =0x2
	b	LBB27_13
LBB27_9:                                ; %b10.i
	mov	w9, #3                          ; =0x3
	b	LBB27_13
LBB27_10:                               ; %b28.i
	mov	w9, #9                          ; =0x9
	b	LBB27_13
LBB27_11:                               ; %b25.i
	mov	w9, #8                          ; =0x8
	b	LBB27_13
LBB27_12:                               ; %b36.i
	mov	w9, #6                          ; =0x6
LBB27_13:                               ; %liza___liza_reactor_error.exit
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
	mov	w2, w9
LBB27_14:                               ; %common.ret
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh118, Lloh119
	.cfi_endproc
	.section	__TEXT,__const
lJTI27_0:
	.byte	(LBB27_14-LBB27_2)>>2
	.byte	(LBB27_13-LBB27_2)>>2
	.byte	(LBB27_2-LBB27_2)>>2
	.byte	(LBB27_8-LBB27_2)>>2
	.byte	(LBB27_9-LBB27_2)>>2
	.byte	(LBB27_4-LBB27_2)>>2
	.byte	(LBB27_6-LBB27_2)>>2
	.byte	(LBB27_12-LBB27_2)>>2
	.byte	(LBB27_7-LBB27_2)>>2
	.byte	(LBB27_11-LBB27_2)>>2
	.byte	(LBB27_10-LBB27_2)>>2
	.byte	(LBB27_3-LBB27_2)>>2
	.byte	(LBB27_5-LBB27_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_port          ; -- Begin function liza_net.reactor_port
	.p2align	2
_liza_net.reactor_port:                 ; @liza_net.reactor_port
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_port
	lsr	x8, x0, #32
	cbnz	x8, LBB28_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB28_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB28_14
; %bb.3:                                ; %v8_ok.i
Lloh120:
	adrp	x9, lJTI28_0@PAGE
Lloh121:
	add	x9, x9, lJTI28_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB28_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB28_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB28_15
LBB28_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB28_15
LBB28_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB28_15
LBB28_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB28_15
LBB28_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB28_15
LBB28_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB28_15
LBB28_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB28_15
LBB28_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB28_15
LBB28_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB28_15
LBB28_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB28_15
LBB28_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB28_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh120, Lloh121
	.cfi_endproc
	.section	__TEXT,__const
lJTI28_0:
	.byte	(LBB28_15-LBB28_4)>>2
	.byte	(LBB28_4-LBB28_4)>>2
	.byte	(LBB28_9-LBB28_4)>>2
	.byte	(LBB28_8-LBB28_4)>>2
	.byte	(LBB28_6-LBB28_4)>>2
	.byte	(LBB28_7-LBB28_4)>>2
	.byte	(LBB28_14-LBB28_4)>>2
	.byte	(LBB28_10-LBB28_4)>>2
	.byte	(LBB28_11-LBB28_4)>>2
	.byte	(LBB28_13-LBB28_4)>>2
	.byte	(LBB28_12-LBB28_4)>>2
	.byte	(LBB28_5-LBB28_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_poll          ; -- Begin function liza_net.reactor_poll
	.p2align	2
_liza_net.reactor_poll:                 ; @liza_net.reactor_poll
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_poll
	lsr	x8, x0, #32
	cbnz	x8, LBB29_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB29_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB29_14
; %bb.3:                                ; %v8_ok.i
Lloh122:
	adrp	x9, lJTI29_0@PAGE
Lloh123:
	add	x9, x9, lJTI29_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB29_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB29_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB29_15
LBB29_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB29_15
LBB29_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB29_15
LBB29_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB29_15
LBB29_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB29_15
LBB29_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB29_15
LBB29_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB29_15
LBB29_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB29_15
LBB29_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB29_15
LBB29_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB29_15
LBB29_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB29_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh122, Lloh123
	.cfi_endproc
	.section	__TEXT,__const
lJTI29_0:
	.byte	(LBB29_15-LBB29_4)>>2
	.byte	(LBB29_4-LBB29_4)>>2
	.byte	(LBB29_9-LBB29_4)>>2
	.byte	(LBB29_8-LBB29_4)>>2
	.byte	(LBB29_6-LBB29_4)>>2
	.byte	(LBB29_7-LBB29_4)>>2
	.byte	(LBB29_14-LBB29_4)>>2
	.byte	(LBB29_10-LBB29_4)>>2
	.byte	(LBB29_11-LBB29_4)>>2
	.byte	(LBB29_13-LBB29_4)>>2
	.byte	(LBB29_12-LBB29_4)>>2
	.byte	(LBB29_5-LBB29_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_interest      ; -- Begin function liza_net.reactor_interest
	.p2align	2
_liza_net.reactor_interest:             ; @liza_net.reactor_interest
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbnz	x8, LBB30_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB30_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB30_14
; %bb.3:                                ; %v8_ok.i
Lloh124:
	adrp	x9, lJTI30_0@PAGE
Lloh125:
	add	x9, x9, lJTI30_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB30_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB30_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB30_15
LBB30_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB30_15
LBB30_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB30_15
LBB30_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB30_15
LBB30_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB30_15
LBB30_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB30_15
LBB30_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB30_15
LBB30_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB30_15
LBB30_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB30_15
LBB30_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB30_15
LBB30_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB30_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh124, Lloh125
	.cfi_endproc
	.section	__TEXT,__const
lJTI30_0:
	.byte	(LBB30_15-LBB30_4)>>2
	.byte	(LBB30_4-LBB30_4)>>2
	.byte	(LBB30_9-LBB30_4)>>2
	.byte	(LBB30_8-LBB30_4)>>2
	.byte	(LBB30_6-LBB30_4)>>2
	.byte	(LBB30_7-LBB30_4)>>2
	.byte	(LBB30_14-LBB30_4)>>2
	.byte	(LBB30_10-LBB30_4)>>2
	.byte	(LBB30_11-LBB30_4)>>2
	.byte	(LBB30_13-LBB30_4)>>2
	.byte	(LBB30_12-LBB30_4)>>2
	.byte	(LBB30_5-LBB30_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_ready         ; -- Begin function liza_net.reactor_ready
	.p2align	2
_liza_net.reactor_ready:                ; @liza_net.reactor_ready
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	cbnz	x8, LBB31_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB31_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB31_14
; %bb.3:                                ; %v8_ok.i
Lloh126:
	adrp	x9, lJTI31_0@PAGE
Lloh127:
	add	x9, x9, lJTI31_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB31_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB31_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB31_15
LBB31_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB31_15
LBB31_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB31_15
LBB31_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB31_15
LBB31_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB31_15
LBB31_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB31_15
LBB31_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB31_15
LBB31_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB31_15
LBB31_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB31_15
LBB31_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB31_15
LBB31_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB31_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh126, Lloh127
	.cfi_endproc
	.section	__TEXT,__const
lJTI31_0:
	.byte	(LBB31_15-LBB31_4)>>2
	.byte	(LBB31_4-LBB31_4)>>2
	.byte	(LBB31_9-LBB31_4)>>2
	.byte	(LBB31_8-LBB31_4)>>2
	.byte	(LBB31_6-LBB31_4)>>2
	.byte	(LBB31_7-LBB31_4)>>2
	.byte	(LBB31_14-LBB31_4)>>2
	.byte	(LBB31_10-LBB31_4)>>2
	.byte	(LBB31_11-LBB31_4)>>2
	.byte	(LBB31_13-LBB31_4)>>2
	.byte	(LBB31_12-LBB31_4)>>2
	.byte	(LBB31_5-LBB31_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_disconnect    ; -- Begin function liza_net.reactor_disconnect
	.p2align	2
_liza_net.reactor_disconnect:           ; @liza_net.reactor_disconnect
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB32_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB32_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB32_14
; %bb.3:                                ; %v8_ok.i
Lloh128:
	adrp	x9, lJTI32_0@PAGE
Lloh129:
	add	x9, x9, lJTI32_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB32_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB32_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB32_15
LBB32_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB32_15
LBB32_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB32_15
LBB32_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB32_15
LBB32_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB32_15
LBB32_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB32_15
LBB32_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB32_15
LBB32_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB32_15
LBB32_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB32_15
LBB32_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB32_15
LBB32_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB32_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh128, Lloh129
	.cfi_endproc
	.section	__TEXT,__const
lJTI32_0:
	.byte	(LBB32_15-LBB32_4)>>2
	.byte	(LBB32_4-LBB32_4)>>2
	.byte	(LBB32_9-LBB32_4)>>2
	.byte	(LBB32_8-LBB32_4)>>2
	.byte	(LBB32_6-LBB32_4)>>2
	.byte	(LBB32_7-LBB32_4)>>2
	.byte	(LBB32_14-LBB32_4)>>2
	.byte	(LBB32_10-LBB32_4)>>2
	.byte	(LBB32_11-LBB32_4)>>2
	.byte	(LBB32_13-LBB32_4)>>2
	.byte	(LBB32_12-LBB32_4)>>2
	.byte	(LBB32_5-LBB32_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_write         ; -- Begin function liza_net.reactor_write
	.p2align	2
_liza_net.reactor_write:                ; @liza_net.reactor_write
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	cbnz	x8, LBB33_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB33_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB33_14
; %bb.3:                                ; %v8_ok.i
Lloh130:
	adrp	x9, lJTI33_0@PAGE
Lloh131:
	add	x9, x9, lJTI33_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB33_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB33_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB33_15
LBB33_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB33_15
LBB33_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB33_15
LBB33_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB33_15
LBB33_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB33_15
LBB33_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB33_15
LBB33_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB33_15
LBB33_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB33_15
LBB33_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB33_15
LBB33_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB33_15
LBB33_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB33_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh130, Lloh131
	.cfi_endproc
	.section	__TEXT,__const
lJTI33_0:
	.byte	(LBB33_15-LBB33_4)>>2
	.byte	(LBB33_4-LBB33_4)>>2
	.byte	(LBB33_9-LBB33_4)>>2
	.byte	(LBB33_8-LBB33_4)>>2
	.byte	(LBB33_6-LBB33_4)>>2
	.byte	(LBB33_7-LBB33_4)>>2
	.byte	(LBB33_14-LBB33_4)>>2
	.byte	(LBB33_10-LBB33_4)>>2
	.byte	(LBB33_11-LBB33_4)>>2
	.byte	(LBB33_13-LBB33_4)>>2
	.byte	(LBB33_12-LBB33_4)>>2
	.byte	(LBB33_5-LBB33_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_connect       ; -- Begin function liza_net.reactor_connect
	.p2align	2
_liza_net.reactor_connect:              ; @liza_net.reactor_connect
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x2, sp, #8
	bl	_liza_rt_reactor_connect
	cmp	w0, #12
	b.hi	LBB34_13
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh132:
	adrp	x9, lJTI34_0@PAGE
Lloh133:
	add	x9, x9, lJTI34_0@PAGEOFF
	adr	x10, LBB34_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	mov	w4, wzr
	br	x10
LBB34_2:                                ; %b1
	ldp	x1, x2, [sp, #8]
	mov	w0, wzr
	ldr	x3, [sp, #24]
	mov	w4, wzr
	b	LBB34_15
LBB34_3:                                ; %b31.i
	mov	w4, #10                         ; =0xa
	b	LBB34_14
LBB34_4:                                ; %b4.i
	mov	w4, #1                          ; =0x1
	b	LBB34_14
LBB34_5:                                ; %b13.i
	mov	w4, #4                          ; =0x4
	b	LBB34_14
LBB34_6:                                ; %b34.i
	mov	w4, #11                         ; =0xb
	b	LBB34_14
LBB34_7:                                ; %b16.i
	mov	w4, #5                          ; =0x5
	b	LBB34_14
LBB34_8:                                ; %b22.i
	mov	w4, #7                          ; =0x7
	b	LBB34_14
LBB34_9:                                ; %b7.i
	mov	w4, #2                          ; =0x2
	b	LBB34_14
LBB34_10:                               ; %b10.i
	mov	w4, #3                          ; =0x3
	b	LBB34_14
LBB34_11:                               ; %b28.i
	mov	w4, #9                          ; =0x9
	b	LBB34_14
LBB34_12:                               ; %b25.i
	mov	w4, #8                          ; =0x8
	b	LBB34_14
LBB34_13:                               ; %b36.i
	mov	w4, #6                          ; =0x6
LBB34_14:                               ; %liza___liza_reactor_error.exit
	mov	x1, xzr
	mov	x2, xzr
	mov	x3, xzr
	mov	w0, #1                          ; =0x1
LBB34_15:                               ; %common.ret
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh132, Lloh133
	.cfi_endproc
	.section	__TEXT,__const
lJTI34_0:
	.byte	(LBB34_2-LBB34_2)>>2
	.byte	(LBB34_14-LBB34_2)>>2
	.byte	(LBB34_4-LBB34_2)>>2
	.byte	(LBB34_9-LBB34_2)>>2
	.byte	(LBB34_10-LBB34_2)>>2
	.byte	(LBB34_5-LBB34_2)>>2
	.byte	(LBB34_7-LBB34_2)>>2
	.byte	(LBB34_13-LBB34_2)>>2
	.byte	(LBB34_8-LBB34_2)>>2
	.byte	(LBB34_12-LBB34_2)>>2
	.byte	(LBB34_11-LBB34_2)>>2
	.byte	(LBB34_3-LBB34_2)>>2
	.byte	(LBB34_6-LBB34_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_finish_connect ; -- Begin function liza_net.reactor_finish_connect
	.p2align	2
_liza_net.reactor_finish_connect:       ; @liza_net.reactor_finish_connect
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_finish_connect
	lsr	x9, x0, #32
	cbnz	x9, LBB35_2
; %bb.1:                                ; %b1
	mov	x8, x0
	mov	w0, wzr
	mov	w2, wzr
	cmp	x8, #1
	cset	w8, eq
	b	LBB35_16
LBB35_2:                                ; %v10_ok
	sub	w8, w9, #1
	cmp	w8, #11
	b.hi	LBB35_14
; %bb.3:                                ; %v10_ok
Lloh134:
	adrp	x9, lJTI35_0@PAGE
Lloh135:
	add	x9, x9, lJTI35_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB35_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB35_4:                                ; %b4.i
	mov	w2, #1                          ; =0x1
	b	LBB35_15
LBB35_5:                                ; %b34.i
	mov	w2, #11                         ; =0xb
	b	LBB35_15
LBB35_6:                                ; %b13.i
	mov	w2, #4                          ; =0x4
	b	LBB35_15
LBB35_7:                                ; %b16.i
	mov	w2, #5                          ; =0x5
	b	LBB35_15
LBB35_8:                                ; %b10.i
	mov	w2, #3                          ; =0x3
	b	LBB35_15
LBB35_9:                                ; %b7.i
	mov	w2, #2                          ; =0x2
	b	LBB35_15
LBB35_10:                               ; %b22.i
	mov	w2, #7                          ; =0x7
	b	LBB35_15
LBB35_11:                               ; %b25.i
	mov	w2, #8                          ; =0x8
	b	LBB35_15
LBB35_12:                               ; %b31.i
	mov	w2, #10                         ; =0xa
	b	LBB35_15
LBB35_13:                               ; %b28.i
	mov	w2, #9                          ; =0x9
	b	LBB35_15
LBB35_14:                               ; %b36.i
	mov	w2, #6                          ; =0x6
LBB35_15:                               ; %liza___liza_reactor_error.exit
	mov	w8, wzr
	mov	w0, #1                          ; =0x1
LBB35_16:                               ; %common.ret
	and	w1, w8, #0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh134, Lloh135
	.cfi_endproc
	.section	__TEXT,__const
lJTI35_0:
	.byte	(LBB35_15-LBB35_4)>>2
	.byte	(LBB35_4-LBB35_4)>>2
	.byte	(LBB35_9-LBB35_4)>>2
	.byte	(LBB35_8-LBB35_4)>>2
	.byte	(LBB35_6-LBB35_4)>>2
	.byte	(LBB35_7-LBB35_4)>>2
	.byte	(LBB35_14-LBB35_4)>>2
	.byte	(LBB35_10-LBB35_4)>>2
	.byte	(LBB35_11-LBB35_4)>>2
	.byte	(LBB35_13-LBB35_4)>>2
	.byte	(LBB35_12-LBB35_4)>>2
	.byte	(LBB35_5-LBB35_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_shutdown_write ; -- Begin function liza_net.reactor_shutdown_write
	.p2align	2
_liza_net.reactor_shutdown_write:       ; @liza_net.reactor_shutdown_write
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB36_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB36_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB36_14
; %bb.3:                                ; %v8_ok.i
Lloh136:
	adrp	x9, lJTI36_0@PAGE
Lloh137:
	add	x9, x9, lJTI36_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB36_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB36_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB36_15
LBB36_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB36_15
LBB36_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB36_15
LBB36_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB36_15
LBB36_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB36_15
LBB36_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB36_15
LBB36_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB36_15
LBB36_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB36_15
LBB36_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB36_15
LBB36_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB36_15
LBB36_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB36_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh136, Lloh137
	.cfi_endproc
	.section	__TEXT,__const
lJTI36_0:
	.byte	(LBB36_15-LBB36_4)>>2
	.byte	(LBB36_4-LBB36_4)>>2
	.byte	(LBB36_9-LBB36_4)>>2
	.byte	(LBB36_8-LBB36_4)>>2
	.byte	(LBB36_6-LBB36_4)>>2
	.byte	(LBB36_7-LBB36_4)>>2
	.byte	(LBB36_14-LBB36_4)>>2
	.byte	(LBB36_10-LBB36_4)>>2
	.byte	(LBB36_11-LBB36_4)>>2
	.byte	(LBB36_13-LBB36_4)>>2
	.byte	(LBB36_12-LBB36_4)>>2
	.byte	(LBB36_5-LBB36_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #240
	.cfi_def_cfa_offset 4496
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	bl	_liza_rt_cli_init
	bl	_liza_rt_cli_count
	cmp	w0, #1
	b.ne	LBB37_6
; %bb.1:
	str	wzr, [sp, #420]                 ; 4-byte Folded Spill
	mov	w0, #9004                       ; =0x232c
LBB37_2:                                ; %b16.i
	add	x2, sp, #3248
	mov	w1, #16                         ; =0x10
	bl	_liza_rt_reactor_create
	cmp	w0, #12
	b.hi	LBB37_4
; %bb.3:                                ; %b16.i
	mov	w8, w0
Lloh138:
	adrp	x9, lJTI37_0@PAGE
Lloh139:
	add	x9, x9, lJTI37_0@PAGEOFF
	adr	x10, LBB37_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_4:                                ; %liza___liza_reactor_error.exit.i.i
	mov	x19, xzr
	mov	w8, #1                          ; =0x1
	cmp	w8, #1
	b.ne	LBB37_15
LBB37_5:                                ; %b18.i
Lloh140:
	adrp	x0, l_text.main.v37@PAGE
Lloh141:
	add	x0, x0, l_text.main.v37@PAGEOFF
	mov	w1, #31                         ; =0x1f
	bl	_liza_rt_err_text
	b	LBB37_19
LBB37_6:                                ; %b1.i
	bl	_liza_rt_cli_count
	cmp	w0, #2
	b.ne	LBB37_9
; %bb.7:                                ; %b5.i
	bl	_liza_rt_cli_count
	cmp	w0, #2
	b.hs	LBB37_11
; %bb.8:
	mov	w0, #2                          ; =0x2
	b	LBB37_20
LBB37_9:                                ; %b3.i
Lloh142:
	adrp	x0, l_text.main.v9@PAGE
Lloh143:
	add	x0, x0, l_text.main.v9@PAGEOFF
LBB37_10:                               ; %liza_main.exit
	mov	w1, #41                         ; =0x29
	bl	_liza_rt_err_text
	mov	w0, #2                          ; =0x2
	b	LBB37_20
LBB37_11:                               ; %b8.i
Lloh144:
	adrp	x1, l_text.main.v17@PAGE
Lloh145:
	add	x1, x1, l_text.main.v17@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_liza_rt_cli_equals
	cbnz	w0, LBB37_13
; %bb.12:                               ; %b9.i
Lloh146:
	adrp	x1, l_text.main.v21@PAGE
Lloh147:
	add	x1, x1, l_text.main.v21@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #11                         ; =0xb
	bl	_liza_rt_cli_equals
	cbz	w0, LBB37_30
LBB37_13:                               ; %b14.i
Lloh148:
	adrp	x1, l_text.main.v28@PAGE
Lloh149:
	add	x1, x1, l_text.main.v28@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_liza_rt_cli_equals
	mov	w8, w0
	mov	w0, wzr
	cmp	w8, #0
	cset	w8, ne
	str	w8, [sp, #420]                  ; 4-byte Folded Spill
	b	LBB37_2
LBB37_14:                               ; %b1.i.i
	ldr	x19, [sp, #3248]
	mov	w8, wzr
	cmp	w8, #1
	b.eq	LBB37_5
LBB37_15:                               ; %b19.i
	add	x1, sp, #1468
	mov	w0, #32768                      ; =0x8000
	bl	_liza_rt_region_create
	ldr	w8, [sp, #1468]
	cbnz	w8, LBB37_18
; %bb.16:                               ; %b3.i.i
	add	x4, sp, #1464
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	w3, #32768                      ; =0x8000
	str	x0, [sp, #152]                  ; 8-byte Folded Spill
	bl	_liza_rt_region_alloc
	ldr	w8, [sp, #1464]
	cbz	w8, LBB37_21
; %bb.17:                               ; %b5.i.i
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	bl	_liza_rt_region_close
LBB37_18:                               ; %b2.i.i
	mov	x0, x19
	bl	_liza_rt_reactor_close
LBB37_19:                               ; %liza_main.exit
	mov	w0, #3                          ; =0x3
LBB37_20:                               ; %liza_main.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #240
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB37_21:                               ; %v10_body.preheader.i.i
	mov	w1, #32768                      ; =0x8000
	mov	x20, x0
	bl	_bzero
	add	x8, sp, #209
	mov	x0, x19
	strb	wzr, [x8, #4095]
	add	x8, sp, #205
	strb	wzr, [x8, #4095]
	add	x8, sp, #204
	strb	wzr, [x8, #4095]
	add	x8, sp, #201
	strb	wzr, [x8, #4095]
	add	x8, sp, #200
	strb	wzr, [x8, #4095]
	add	x8, sp, #193
	strb	wzr, [x8, #4095]
	add	x8, sp, #189
	strb	wzr, [x8, #4095]
	add	x8, sp, #188
	strb	wzr, [x8, #4095]
	add	x8, sp, #185
	strb	wzr, [x8, #4095]
	add	x8, sp, #184
	strb	wzr, [x8, #4095]
	add	x8, sp, #177
	strb	wzr, [x8, #4095]
	add	x8, sp, #173
	strb	wzr, [x8, #4095]
	add	x8, sp, #172
	strb	wzr, [x8, #4095]
	add	x8, sp, #169
	strb	wzr, [x8, #4095]
	add	x8, sp, #168
	strb	wzr, [x8, #4095]
	add	x8, sp, #161
	strb	wzr, [x8, #4095]
	add	x8, sp, #157
	strb	wzr, [x8, #4095]
	add	x8, sp, #156
	strb	wzr, [x8, #4095]
	add	x8, sp, #153
	strb	wzr, [x8, #4095]
	add	x8, sp, #152
	strb	wzr, [x8, #4095]
	add	x8, sp, #145
	strb	wzr, [x8, #4095]
	add	x8, sp, #141
	strb	wzr, [x8, #4095]
	add	x8, sp, #140
	strb	wzr, [x8, #4095]
	add	x8, sp, #137
	strb	wzr, [x8, #4095]
	add	x8, sp, #136
	strb	wzr, [x8, #4095]
	add	x8, sp, #129
	strb	wzr, [x8, #4095]
	add	x8, sp, #125
	strb	wzr, [x8, #4095]
	add	x8, sp, #124
	strb	wzr, [x8, #4095]
	add	x8, sp, #121
	strb	wzr, [x8, #4095]
	add	x8, sp, #120
	strb	wzr, [x8, #4095]
	add	x8, sp, #113
	strb	wzr, [x8, #4095]
	add	x8, sp, #109
	strb	wzr, [x8, #4095]
	add	x8, sp, #108
	strb	wzr, [x8, #4095]
	add	x8, sp, #105
	strb	wzr, [x8, #4095]
	add	x8, sp, #104
	strb	wzr, [x8, #4095]
	add	x8, sp, #97
	strb	wzr, [x8, #4095]
	add	x8, sp, #93
	strb	wzr, [x8, #4095]
	add	x8, sp, #92
	strb	wzr, [x8, #4095]
	add	x8, sp, #89
	strb	wzr, [x8, #4095]
	add	x8, sp, #88
	strb	wzr, [x8, #4095]
	bl	_liza_rt_reactor_port
	lsr	x8, x0, #32
	str	x19, [sp, #688]                 ; 8-byte Folded Spill
	str	x20, [sp, #160]                 ; 8-byte Folded Spill
	cbz	x8, LBB37_25
; %bb.22:                               ; %v8_ok.i.i.i.i.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB37_24
; %bb.23:                               ; %v8_ok.i.i.i.i.i
Lloh150:
	adrp	x9, lJTI37_1@PAGE
Lloh151:
	add	x9, x9, lJTI37_1@PAGEOFF
	adr	x10, LBB37_24
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_24:                               ; %liza___liza_reactor_error.exit.i.i.i.i.i
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB37_25:                               ; %liza_net.reactor_port.exit.i.i.i
	cmp	w8, #1
	mov	w9, #3                          ; =0x3
	b.eq	LBB37_344
; %bb.26:                               ; %v12_ok.i.i.i
	mov	w0, w0
	bl	_liza_rt_print_u64
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB37_31
; %bb.27:                               ; %v12_ok.i.i.i
	cbz	w8, LBB37_345
; %bb.28:                               ; %v12_ok.i.i.i
	cmp	w8, #1
	b.eq	LBB37_34
; %bb.29:                               ; %v12_ok.i.i.i
	cmp	w8, #2
	b	LBB37_34
LBB37_30:                               ; %b12.i
Lloh152:
	adrp	x0, l_text.main.v25@PAGE
Lloh153:
	add	x0, x0, l_text.main.v25@PAGEOFF
	b	LBB37_10
LBB37_31:                               ; %v12_ok.i.i.i
	cmp	w8, #3
	b.eq	LBB37_34
; %bb.32:                               ; %v12_ok.i.i.i
	cmp	w8, #4
	b.eq	LBB37_34
; %bb.33:                               ; %v12_ok.i.i.i
	cmp	w8, #5
LBB37_34:                               ; %b18.i.i.i.i.i
	mov	w19, #1                         ; =0x1
LBB37_35:                               ; %liza_console.print_u64.exit.i.i.i
Lloh154:
	adrp	x0, l_text.liza_proxy.exchange.v21@PAGE
Lloh155:
	add	x0, x0, l_text.liza_proxy.exchange.v21@PAGEOFF
	mov	w1, #1                          ; =0x1
	bl	_liza_rt_write_text
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB37_39
; %bb.36:                               ; %liza_console.print_u64.exit.i.i.i
	cbz	w8, LBB37_43
; %bb.37:                               ; %liza_console.print_u64.exit.i.i.i
	cmp	w8, #1
	b.eq	LBB37_43
; %bb.38:                               ; %liza_console.print_u64.exit.i.i.i
	cmp	w8, #2
	b	LBB37_42
LBB37_39:                               ; %liza_console.print_u64.exit.i.i.i
	cmp	w8, #3
	b.eq	LBB37_42
; %bb.40:                               ; %liza_console.print_u64.exit.i.i.i
	cmp	w8, #4
	b.eq	LBB37_42
; %bb.41:                               ; %liza_console.print_u64.exit.i.i.i
	cmp	w8, #5
LBB37_42:                               ; %b13.i.i58.i.i.i
	mov	w8, #1                          ; =0x1
LBB37_43:                               ; %b12_to_b13.i.i.i
	orr	w8, w8, w19
	mov	w9, #3                          ; =0x3
	cbnz	w8, LBB37_344
; %bb.44:                               ; %b14.lr.ph.i.i.i
	add	x8, sp, #1472
	mov	x0, xzr
	mov	x15, xzr
	add	x9, x8, #65
	add	x10, x8, #474
	mov	x17, xzr
	str	x9, [sp, #584]                  ; 8-byte Folded Spill
	add	x9, x8, #90
	mov	w23, wzr
	str	x9, [sp, #576]                  ; 8-byte Folded Spill
	add	x9, x8, #161
	mov	x26, xzr
	str	x9, [sp, #568]                  ; 8-byte Folded Spill
	add	x9, x8, #186
	mov	x27, xzr
	str	x9, [sp, #560]                  ; 8-byte Folded Spill
	add	x9, x8, #257
	mov	x24, xzr
	str	x9, [sp, #552]                  ; 8-byte Folded Spill
	add	x9, x8, #282
	mov	x7, xzr
	str	x9, [sp, #544]                  ; 8-byte Folded Spill
	add	x9, x8, #353
	mov	w11, wzr
	str	x9, [sp, #536]                  ; 8-byte Folded Spill
	add	x9, x8, #378
	mov	w12, wzr
	str	x9, [sp, #528]                  ; 8-byte Folded Spill
	add	x9, x8, #449
	mov	w3, wzr
	str	x9, [sp, #520]                  ; 8-byte Folded Spill
	add	x9, x8, #545
	mov	w4, wzr
	stp	x9, x10, [sp, #504]             ; 16-byte Folded Spill
	add	x10, x8, #570
	add	x9, x8, #641
	stp	x9, x10, [sp, #488]             ; 16-byte Folded Spill
	add	x10, x8, #666
	add	x9, x8, #737
	add	x8, x8, #762
	stp	x9, x10, [sp, #472]             ; 16-byte Folded Spill
	add	x9, sp, #2288
	str	x8, [sp, #464]                  ; 8-byte Folded Spill
	add	x8, sp, #1472
	add	x20, x9, #260
	add	x9, x8, #260
	add	x8, sp, #88
	add	x10, sp, #3248
	ldrb	w8, [x8, #4095]
	mov	w5, wzr
	add	x16, x20, #356
	add	x1, x20, #420
	add	x28, x20, #452
	mov	w22, #1                         ; =0x1
	str	w8, [sp, #976]                  ; 4-byte Folded Spill
	add	x8, sp, #89
                                        ; implicit-def: $w19
                                        ; implicit-def: $w25
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1264]                ; 8-byte Folded Spill
	str	xzr, [sp, #1272]                ; 8-byte Folded Spill
	str	w8, [sp, #968]                  ; 4-byte Folded Spill
	add	x8, sp, #92
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1208]                ; 8-byte Folded Spill
	str	xzr, [sp, #1248]                ; 8-byte Folded Spill
	str	w8, [sp, #412]                  ; 4-byte Folded Spill
	add	x8, sp, #93
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1240]                ; 8-byte Folded Spill
	str	wzr, [sp, #1164]                ; 4-byte Folded Spill
	str	w8, [sp, #408]                  ; 4-byte Folded Spill
	add	x8, sp, #97
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1152]                ; 4-byte Folded Spill
	str	wzr, [sp, #1176]                ; 4-byte Folded Spill
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	add	x8, sp, #104
	ldrb	w21, [x8, #4095]
	add	x8, sp, #105
	str	wzr, [sp, #1168]                ; 4-byte Folded Spill
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1120]                ; 8-byte Folded Spill
	str	xzr, [sp, #1112]                ; 8-byte Folded Spill
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	add	x8, sp, #108
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1104]                ; 8-byte Folded Spill
	str	xzr, [sp, #1144]                ; 8-byte Folded Spill
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	add	x8, sp, #109
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1136]                ; 8-byte Folded Spill
	str	xzr, [sp, #1128]                ; 8-byte Folded Spill
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	add	x8, sp, #113
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1420]                ; 4-byte Folded Spill
	str	wzr, [sp, #1412]                ; 4-byte Folded Spill
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	add	x8, sp, #120
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1452]                ; 4-byte Folded Spill
	str	xzr, [sp, #1184]                ; 8-byte Folded Spill
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	add	x8, sp, #121
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1072]                ; 8-byte Folded Spill
	str	xzr, [sp, #1064]                ; 8-byte Folded Spill
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	add	x8, sp, #124
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1096]                ; 8-byte Folded Spill
	str	xzr, [sp, #1088]                ; 8-byte Folded Spill
	str	w8, [sp, #836]                  ; 4-byte Folded Spill
	add	x8, sp, #125
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1080]                ; 8-byte Folded Spill
	str	xzr, [sp, #936]                 ; 8-byte Folded Spill
	str	w8, [sp, #840]                  ; 4-byte Folded Spill
	add	x8, sp, #129
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #944]                 ; 8-byte Folded Spill
	str	xzr, [sp, #800]                 ; 8-byte Folded Spill
	str	w8, [sp, #844]                  ; 4-byte Folded Spill
	add	x8, sp, #136
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #808]                 ; 8-byte Folded Spill
	str	xzr, [sp, #960]                 ; 8-byte Folded Spill
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	add	x8, sp, #137
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #868]                 ; 4-byte Folded Spill
	str	xzr, [sp, #872]                 ; 8-byte Folded Spill
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	add	x8, sp, #140
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #892]                 ; 4-byte Folded Spill
	str	xzr, [sp, #880]                 ; 8-byte Folded Spill
	str	w8, [sp, #860]                  ; 4-byte Folded Spill
	add	x8, sp, #141
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #896]                 ; 8-byte Folded Spill
	str	xzr, [sp, #904]                 ; 8-byte Folded Spill
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	add	x8, sp, #145
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #912]                 ; 8-byte Folded Spill
	str	xzr, [sp, #920]                 ; 8-byte Folded Spill
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	add	x8, sp, #152
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #928]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1344]                ; 8-byte Folded Spill
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	add	x8, sp, #153
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1336]                ; 8-byte Folded Spill
	str	xzr, [sp, #1328]                ; 8-byte Folded Spill
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	add	x8, sp, #156
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1320]                ; 8-byte Folded Spill
	str	xzr, [sp, #1312]                ; 8-byte Folded Spill
	str	w8, [sp, #792]                  ; 4-byte Folded Spill
	add	x8, sp, #157
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1304]                ; 8-byte Folded Spill
	str	wzr, [sp, #1296]                ; 4-byte Folded Spill
	str	w8, [sp, #796]                  ; 4-byte Folded Spill
	add	x8, sp, #161
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1056]                ; 8-byte Folded Spill
	str	xzr, [sp, #1024]                ; 8-byte Folded Spill
	str	w8, [sp, #1400]                 ; 4-byte Folded Spill
	add	x8, sp, #168
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1016]                ; 8-byte Folded Spill
	str	xzr, [sp, #1008]                ; 8-byte Folded Spill
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	add	x8, sp, #169
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1048]                ; 8-byte Folded Spill
	str	xzr, [sp, #1040]                ; 8-byte Folded Spill
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	add	x8, sp, #172
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1032]                ; 8-byte Folded Spill
	str	wzr, [sp, #1288]                ; 4-byte Folded Spill
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	add	x8, sp, #173
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1280]                ; 8-byte Folded Spill
	str	xzr, [sp, #1256]                ; 8-byte Folded Spill
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	add	x8, sp, #177
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1200]                ; 8-byte Folded Spill
	str	xzr, [sp, #1192]                ; 8-byte Folded Spill
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	add	x8, sp, #184
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1232]                ; 8-byte Folded Spill
	str	xzr, [sp, #1224]                ; 8-byte Folded Spill
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	add	x8, sp, #185
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1216]                ; 8-byte Folded Spill
	str	wzr, [sp, #168]                 ; 4-byte Folded Spill
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	add	x8, sp, #188
	ldrb	w8, [x8, #4095]
	str	x9, [sp, #456]                  ; 8-byte Folded Spill
	str	x20, [sp, #704]                 ; 8-byte Folded Spill
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	add	x8, sp, #189
	ldrb	w8, [x8, #4095]
	str	x16, [sp, #728]                 ; 8-byte Folded Spill
	str	x1, [sp, #720]                  ; 8-byte Folded Spill
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	add	x8, sp, #193
	ldrb	w8, [x8, #4095]
	str	x28, [sp, #712]                 ; 8-byte Folded Spill
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	add	x8, sp, #200
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	add	x8, sp, #201
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	add	x8, sp, #204
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #984]                  ; 4-byte Folded Spill
	add	x8, sp, #205
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #992]                  ; 4-byte Folded Spill
	add	x8, sp, #209
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #420]                  ; 4-byte Folded Reload
	eor	w8, w8, #0x1
	str	w8, [sp, #416]                  ; 4-byte Folded Spill
	add	x8, x10, #65
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
	add	x8, x10, #90
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	add	x8, x10, #161
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
	add	x8, x10, #186
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	add	x8, x10, #257
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	add	x8, x10, #282
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	add	x8, x10, #353
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	add	x8, x10, #378
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	add	x8, x10, #449
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	add	x8, x10, #474
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	add	x8, x10, #545
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	add	x8, x10, #570
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
	add	x8, x10, #641
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x8, x10, #666
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	add	x8, x10, #737
	add	x10, x10, #762
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	add	x8, sp, #2288
	str	x10, [sp, #16]                  ; 8-byte Folded Spill
	add	x10, x8, #65
	add	x13, x8, #282
	str	x10, [sp, #752]                 ; 8-byte Folded Spill
	add	x10, x8, #90
	add	x6, x8, #378
	str	x10, [sp, #664]                 ; 8-byte Folded Spill
	add	x10, x8, #161
	str	x10, [sp, #656]                 ; 8-byte Folded Spill
	add	x10, x8, #186
	str	x10, [sp, #648]                 ; 8-byte Folded Spill
	add	x10, x8, #257
	str	x10, [sp, #760]                 ; 8-byte Folded Spill
	add	x10, x8, #353
	str	x10, [sp, #768]                 ; 8-byte Folded Spill
	add	x10, x8, #449
	str	x10, [sp, #744]                 ; 8-byte Folded Spill
	add	x10, x8, #474
	str	x10, [sp, #640]                 ; 8-byte Folded Spill
	add	x10, x8, #545
	str	x10, [sp, #632]                 ; 8-byte Folded Spill
	add	x10, x8, #570
	str	x10, [sp, #624]                 ; 8-byte Folded Spill
	add	x10, x20, #324
	str	x10, [sp, #736]                 ; 8-byte Folded Spill
	add	x10, x8, #641
	str	x10, [sp, #616]                 ; 8-byte Folded Spill
	add	x10, x8, #666
	str	x10, [sp, #608]                 ; 8-byte Folded Spill
	add	x10, x8, #737
	add	x8, x8, #762
	str	x10, [sp, #600]                 ; 8-byte Folded Spill
	add	x10, x9, #324
	str	x8, [sp, #592]                  ; 8-byte Folded Spill
	add	x8, x9, #356
	stp	x8, x10, [sp, #440]             ; 16-byte Folded Spill
	add	x10, x9, #420
	add	x8, x9, #452
	stp	x8, x10, [sp, #424]             ; 16-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w10, #1                         ; =0x1
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x13, [sp, #680]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x6, [sp, #672]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #832]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1396]                 ; 4-byte Folded Spill
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	str	w8, [sp, #952]                  ; 4-byte Folded Spill
	str	w8, [sp, #956]                  ; 4-byte Folded Spill
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	str	w8, [sp, #1456]                 ; 4-byte Folded Spill
	str	w8, [sp, #1360]                 ; 4-byte Folded Spill
	b	LBB37_47
LBB37_45:                               ;   in Loop: Header=BB37_47 Depth=1
	ldr	x13, [sp, #680]                 ; 8-byte Folded Reload
	ldr	x6, [sp, #672]                  ; 8-byte Folded Reload
	mov	w20, wzr
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
LBB37_46:                               ; %b61_to_b13.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	x9, [sp, #752]                  ; 8-byte Folded Reload
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	add	x14, sp, #87
	str	w10, [sp, #1420]                ; 4-byte Folded Spill
	ldr	w10, [x21]
	ldr	x7, [sp, #2296]
	ldrh	w8, [x9]
	ldrb	w9, [x9, #2]
	str	w10, [sp, #4172]
	ldr	w10, [sp, #2288]
	strh	w8, [sp, #4180]
	ldrh	w8, [x21, #4]
	ldrb	w21, [sp, #2953]
	strb	w9, [x14, #4095]
	ldrb	w9, [x19, #2]
	ldr	x14, [sp, #768]                 ; 8-byte Folded Reload
	strh	w8, [sp, #4176]
	ldrh	w8, [x19]
	ldr	x19, [sp, #760]                 ; 8-byte Folded Reload
	str	w10, [sp, #1360]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2292]
	strh	w8, [sp, #4168]
	ldr	w8, [x25]
	str	w10, [sp, #252]                 ; 4-byte Folded Spill
	add	x10, sp, #75
	str	w8, [sp, #4160]
	ldrh	w8, [x19]
	strb	w9, [x10, #4095]
	ldrh	w9, [x25, #4]
	ldr	x10, [sp, #2304]
	strh	w8, [sp, #4156]
	ldr	w8, [x13]
	ldrh	w25, [sp, #2558]
	strh	w9, [sp, #4164]
	ldrb	w9, [x19, #2]
	ldr	x19, [sp, #744]                 ; 8-byte Folded Reload
	str	w8, [sp, #4148]
	ldrh	w8, [x14]
	str	x10, [sp, #1344]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2312]
	strh	w8, [sp, #4144]
	ldr	w8, [x6]
	str	x10, [sp, #1336]                ; 8-byte Folded Spill
	add	x10, sp, #63
	str	w8, [sp, #4136]
	ldrh	w8, [x19]
	strb	w9, [x10, #4095]
	ldr	w10, [sp, #2320]
	ldrh	w9, [x13, #4]
	strh	w8, [sp, #4132]
	ldr	w8, [x11]
	str	w10, [sp, #380]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2324]
	str	w8, [sp, #4124]
	ldrh	w8, [x12]
	str	w10, [sp, #248]                 ; 4-byte Folded Spill
	ldr	x10, [sp, #2328]
	strh	w8, [sp, #4120]
	ldr	w8, [x15]
	str	x10, [sp, #1328]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2336]
	str	w8, [sp, #4112]
	ldrh	w8, [x17]
	str	x10, [sp, #1320]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2344]
	strh	w8, [sp, #4108]
	ldr	w8, [x0]
	strh	w9, [sp, #4152]
	ldrb	w9, [x14, #2]
	str	w8, [sp, #4100]
	ldrh	w8, [x3]
	str	x10, [sp, #1312]                ; 8-byte Folded Spill
	add	x10, sp, #51
	strh	w8, [sp, #4096]
	ldr	x8, [sp, #2424]
	strb	w9, [x10, #4095]
	ldrb	w10, [sp, #2352]
	ldrh	w9, [x6, #4]
	str	x8, [sp, #1240]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2432]
	str	w10, [sp, #1000]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2356]
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2440]
	str	w10, [sp, #1308]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2360]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2448]
	str	w10, [sp, #1304]                ; 4-byte Folded Spill
	ldrb	w10, [sp, #2364]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2452]
	strh	w9, [sp, #4140]
	ldrb	w9, [x19, #2]
	ldrh	w19, [sp, #2750]
	str	w8, [sp, #1272]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2456]
	str	w10, [sp, #992]                 ; 4-byte Folded Spill
	add	x10, sp, #39
	str	w8, [sp, #1276]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2460]
	strb	w9, [x10, #4095]
	ldrb	w10, [sp, #2365]
	ldrh	w9, [x11, #4]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2461]
	ldr	w11, [sp, #2368]
	str	w10, [sp, #984]                 ; 4-byte Folded Spill
	ldrh	w10, [sp, #2366]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2462]
	strh	w9, [sp, #4128]
	ldrb	w9, [x12, #2]
	ldr	w12, [sp, #2372]
	str	w10, [sp, #200]                 ; 4-byte Folded Spill
	add	x10, sp, #27
	str	w8, [sp, #180]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2464]
	strb	w9, [x10, #4095]
	ldrb	w10, [sp, #2376]
	ldrh	w9, [x15, #4]
	str	w8, [sp, #1264]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2468]
	ldr	x15, [sp, #2400]
	str	w10, [sp, #404]                 ; 4-byte Folded Spill
	ldrb	w10, [sp, #2377]
	str	w8, [sp, #1268]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2472]
	str	w10, [sp, #400]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2384]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2473]
	str	w10, [sp, #1456]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2388]
	strh	w9, [sp, #4116]
	ldrb	w9, [x17, #2]
	ldr	x17, [sp, #2392]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2480]
	str	w10, [sp, #244]                 ; 4-byte Folded Spill
	add	x10, sp, #15
	strb	w9, [x10, #4095]
	add	x10, sp, #3
	ldrh	w9, [x0, #4]
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2488]
	ldr	x0, [sp, #2408]
	strh	w9, [sp, #4104]
	ldrb	w9, [x3, #2]
	ldr	w3, [sp, #2948]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2496]
	strb	w9, [x10, #4095]
	ldrh	w9, [x4, #4]
	ldr	w10, [sp, #2416]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2504]
	strh	w9, [sp, #4092]
	ldr	w9, [sp, #2484]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2516]
	str	w10, [sp, #324]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2420]
	stp	w9, w8, [sp, #232]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2520]
	ldr	w9, [sp, #2580]
	str	w10, [sp, #240]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2512]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2528]
	str	x8, [sp, #1112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2536]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2544]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2548]
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2552]
	str	w8, [sp, #1176]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2556]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2557]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2560]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2564]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2568]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2569]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2576]
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2584]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2592]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2600]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2608]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2612]
	stp	w9, w8, [sp, #224]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2616]
	ldr	w9, [sp, #2868]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2624]
	str	x8, [sp, #1072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2632]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2736]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2740]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2744]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2748]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2749]
	str	w8, [sp, #860]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2752]
	str	w8, [sp, #940]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2756]
	str	w8, [sp, #936]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2760]
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2761]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2768]
	str	w8, [sp, #952]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2772]
	str	w8, [sp, #828]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #2776]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2784]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2792]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2800]
	str	w8, [sp, #832]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2804]
	str	w8, [sp, #824]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #2808]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2816]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2824]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2832]
	str	w8, [sp, #844]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2836]
	str	w8, [sp, #892]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2840]
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2844]
	str	w8, [sp, #840]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2845]
	str	w8, [sp, #836]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2846]
	str	w8, [sp, #192]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2848]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2852]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2856]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2857]
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2864]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2872]
	str	x8, [sp, #1032]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2880]
	str	x8, [sp, #1040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2888]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2896]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2900]
	stp	w9, w8, [sp, #208]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2904]
	ldr	w9, [sp, #2964]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2912]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2920]
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2928]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2932]
	str	w8, [sp, #1056]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2936]
	str	w8, [sp, #1060]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2940]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2941]
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2942]
	str	w8, [sp, #188]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2944]
	str	w8, [sp, #1296]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2952]
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2960]
	str	w8, [sp, #1396]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2968]
	str	x8, [sp, #1216]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2976]
	str	x8, [sp, #1224]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2984]
	str	x8, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2992]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2996]
	stp	w9, w8, [sp, #216]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3000]
	ldrb	w9, [sp, #3048]
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3008]
	str	w9, [sp, #968]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #3049]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3016]
	str	w9, [sp, #976]                  ; 4-byte Folded Spill
	ldr	w9, [sp, #700]                  ; 4-byte Folded Reload
	str	x8, [sp, #1256]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3024]
	mov	w5, w9
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3028]
	str	w8, [sp, #1280]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3032]
	str	w8, [sp, #1284]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3036]
	str	w8, [sp, #408]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3037]
	str	w8, [sp, #412]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #3038]
	str	w8, [sp, #184]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3040]
	str	w8, [sp, #1288]                 ; 4-byte Folded Spill
	ldr	w8, [x4]
	ldr	w4, [sp, #3044]
	str	w8, [sp, #4088]
	tbz	w20, #0, LBB37_344
LBB37_47:                               ; %b14.i.i.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB37_100 Depth 2
	stp	x0, x17, [sp, #272]             ; 16-byte Folded Spill
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	mov	w1, #1000                       ; =0x3e8
	mov	w20, w5
	str	w10, [sp, #256]                 ; 4-byte Folded Spill
	str	w4, [sp, #264]                  ; 4-byte Folded Spill
	str	w3, [sp, #268]                  ; 4-byte Folded Spill
	str	x15, [sp, #288]                 ; 8-byte Folded Spill
	str	w12, [sp, #296]                 ; 4-byte Folded Spill
	str	w11, [sp, #300]                 ; 4-byte Folded Spill
	str	x7, [sp, #304]                  ; 8-byte Folded Spill
	str	w22, [sp, #1416]                ; 4-byte Folded Spill
	str	x26, [sp, #1424]                ; 8-byte Folded Spill
	str	x27, [sp, #1432]                ; 8-byte Folded Spill
	str	x24, [sp, #1440]                ; 8-byte Folded Spill
	str	w23, [sp, #1448]                ; 4-byte Folded Spill
	bl	_liza_rt_reactor_poll
	lsr	x8, x0, #32
	cbnz	x8, LBB37_49
; %bb.48:                               ; %b1.i.i95.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldp	w4, w0, [sp, #188]              ; 8-byte Folded Reload
	ldr	w17, [sp, #956]                 ; 4-byte Folded Reload
	ldr	w13, [sp, #952]                 ; 4-byte Folded Reload
	mov	w9, wzr
	ldr	w15, [sp, #1456]                ; 4-byte Folded Reload
	ldr	w14, [sp, #816]                 ; 4-byte Folded Reload
	ldr	w16, [sp, #200]                 ; 4-byte Folded Reload
	ldr	w5, [sp, #184]                  ; 4-byte Folded Reload
	ldr	x1, [sp, #960]                  ; 8-byte Folded Reload
	b	LBB37_63
LBB37_49:                               ; %v8_ok.i.i77.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldp	w4, w0, [sp, #188]              ; 8-byte Folded Reload
	sub	w9, w8, #1
	ldr	w17, [sp, #956]                 ; 4-byte Folded Reload
	ldr	w13, [sp, #952]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #1456]                ; 4-byte Folded Reload
	ldr	w14, [sp, #816]                 ; 4-byte Folded Reload
	cmp	w9, #11
	ldr	w16, [sp, #200]                 ; 4-byte Folded Reload
	ldr	w5, [sp, #184]                  ; 4-byte Folded Reload
	ldr	x1, [sp, #960]                  ; 8-byte Folded Reload
	b.hi	LBB37_61
; %bb.50:                               ; %v8_ok.i.i77.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
Lloh156:
	adrp	x12, lJTI37_2@PAGE
Lloh157:
	add	x12, x12, lJTI37_2@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB37_51
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_51:                               ; %b4.i.i.i93.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB37_62
LBB37_52:                               ; %b34.i.i.i88.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #11                         ; =0xb
	b	LBB37_62
LBB37_53:                               ; %b13.i.i.i90.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB37_62
LBB37_54:                               ; %b16.i.i.i89.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #5                          ; =0x5
	b	LBB37_62
LBB37_55:                               ; %b10.i.i.i91.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #3                          ; =0x3
	b	LBB37_62
LBB37_56:                               ; %b7.i.i.i92.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #2                          ; =0x2
	b	LBB37_62
LBB37_57:                               ; %b22.i.i.i87.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #7                          ; =0x7
	b	LBB37_62
LBB37_58:                               ; %b25.i.i.i86.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #8                          ; =0x8
	b	LBB37_62
LBB37_59:                               ; %b31.i.i.i80.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #10                         ; =0xa
	b	LBB37_62
LBB37_60:                               ; %b28.i.i.i85.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB37_62
LBB37_61:                               ; %b36.i.i.i94.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #6                          ; =0x6
LBB37_62:                               ; %liza___liza_reactor_error.exit.i.i81.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w9, #1                          ; =0x1
LBB37_63:                               ; %liza_net.reactor_poll.exit.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	cmp	w9, #1
	str	x1, [sp, #960]                  ; 8-byte Folded Spill
	str	w21, [sp, #260]                 ; 4-byte Folded Spill
	b.ne	LBB37_65
; %bb.64:                               ; %b17.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w9, #1                          ; =0x1
	ldr	w24, [sp, #1360]                ; 4-byte Folded Reload
	ldr	x27, [sp, #768]                 ; 8-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w10, #3                         ; =0x3
	mov	w26, wzr
	tst	w8, w9
	b.ne	LBB37_67
	b	LBB37_66
LBB37_65:                               ;   in Loop: Header=BB37_47 Depth=1
	ldr	w24, [sp, #1360]                ; 4-byte Folded Reload
	ldr	x27, [sp, #768]                 ; 8-byte Folded Reload
LBB37_66:                               ; %b22_to_b23.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #1                         ; =0x1
	mov	w10, w20
LBB37_67:                               ; %b22_to_b23.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	add	x9, sp, #51
	ldrh	w8, [sp, #4144]
	str	w10, [sp, #700]                 ; 4-byte Folded Spill
	ldrb	w9, [x9, #4095]
	ldr	w10, [sp, #4136]
	cmp	w15, #1
	ldrh	w11, [sp, #4140]
	strh	w8, [sp, #4020]
	mov	w8, #8                          ; =0x8
	strb	w9, [sp, #4022]
	ldrh	w9, [sp, #4132]
	csinc	w8, w8, wzr, ne
	cmp	w24, #1
	str	w10, [sp, #4072]
	add	x10, sp, #39
	strh	w9, [sp, #4068]
	ldrh	w9, [sp, #4128]
	csel	w8, wzr, w8, eq
	strh	w11, [sp, #4076]
	ldrb	w10, [x10, #4095]
	ldr	w11, [sp, #1380]                ; 4-byte Folded Reload
	strh	w9, [sp, #4064]
	add	x9, sp, #27
	cmp	w8, #8
	ldrb	w9, [x9, #4095]
	ccmp	w11, #1, #0, eq
	strb	w10, [sp, #4070]
	ldr	w10, [sp, #4124]
	mov	w11, #2                         ; =0x2
	str	w17, [sp, #956]                 ; 4-byte Folded Spill
	csel	w8, w11, w8, eq
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	strb	w9, [sp, #4058]
	ldr	w9, [sp, #4112]
	cmp	w8, #8
	str	w10, [sp, #4060]
	ldrh	w10, [sp, #4120]
	ccmp	w11, #1, #0, eq
	mov	w11, #3                         ; =0x3
	str	w9, [sp, #4048]
	ldrh	w9, [sp, #4108]
	csel	w8, w11, w8, eq
	strh	w10, [sp, #4056]
	ldrh	w10, [sp, #4116]
	cmp	w8, #8
	strh	w9, [sp, #4044]
	ldr	w9, [sp, #4100]
	ccmp	w17, #1, #0, eq
	strh	w10, [sp, #4052]
	add	x10, sp, #15
	mov	w11, #4                         ; =0x4
	ldrb	w10, [x10, #4095]
	csel	w8, w11, w8, eq
	str	w9, [sp, #4036]
	add	x9, sp, #3
	cmp	w8, #8
	mov	w11, #5                         ; =0x5
	ldrb	w9, [x9, #4095]
	strb	w10, [sp, #4046]
	ldrh	w10, [sp, #4104]
	ccmp	w13, #1, #0, eq
	ldr	w21, [sp, #180]                 ; 4-byte Folded Reload
	add	x17, sp, #1, lsl #12            ; =4096
	csel	w8, w11, w8, eq
	strb	w9, [sp, #4034]
	ldr	w9, [sp, #1384]                 ; 4-byte Folded Reload
	strh	w10, [sp, #4040]
	ldrh	w10, [sp, #4096]
	cmp	w8, #8
	ccmp	w9, #1, #0, eq
	ldrh	w9, [sp, #4092]
	strh	w14, [sp, #4080]
	strh	w10, [sp, #4032]
	mov	w10, #6                         ; =0x6
	add	x1, sp, #1, lsl #12             ; =4096
	csel	w8, w10, w8, eq
	strh	w9, [sp, #4028]
	ldr	w9, [sp, #1396]                 ; 4-byte Folded Reload
	ldr	w10, [sp, #4088]
	cmp	w8, #8
	add	x2, sp, #1, lsl #12             ; =4096
	ccmp	w9, #1, #0, eq
	mov	w9, #7                          ; =0x7
	add	x3, sp, #1, lsl #12             ; =4096
	str	w10, [sp, #4024]
	csel	w28, w9, w8, eq
	add	x6, sp, #1, lsl #12             ; =4096
	add	x14, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x30, sp, #1, lsl #12            ; =4096
	add	x8, sp, #1, lsl #12             ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	add	x9, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	str	w15, [sp, #1456]                ; 4-byte Folded Spill
	add	x15, sp, #4088
	add	x17, x17, #4
	strh	w16, [sp, #4086]
	add	x16, sp, #1, lsl #12            ; =4096
	add	x1, x1, #12
	add	x2, x2, #16
	add	x3, x3, #24
	add	x6, x6, #28
	add	x14, x14, #36
	add	x20, x20, #40
	add	x30, x30, #48
	add	x8, x8, #52
	add	x7, x7, #60
	add	x9, x9, #64
	add	x22, sp, #4084
	add	x10, x10, #72
	add	x11, x11, #76
	add	x12, x12, #84
	strh	w21, [sp, #4084]
	strh	w25, [sp, #4082]
	strh	w19, [sp, #4066]
	strh	w0, [sp, #4054]
	strh	w4, [sp, #4042]
	strh	w5, [sp, #4030]
	str	w26, [sp, #1352]                ; 4-byte Folded Spill
	cbz	w26, LBB37_74
; %bb.68:                               ; %b22_to_b23.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	cmp	w28, #7
	b.hi	LBB37_74
; %bb.69:                               ; %b22_to_b23.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	w22, [sp, #420]                 ; 4-byte Folded Reload
	ldr	w27, [sp, #168]                 ; 4-byte Folded Reload
	ldr	x26, [sp, #760]                 ; 8-byte Folded Reload
	and	w22, w22, w27
	tbnz	w22, #0, LBB37_73
; %bb.70:                               ; %b42.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	add	x1, sp, #1, lsl #12             ; =4096
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	add	x1, x1, #216
	bl	_liza_rt_reactor_accept
	cmp	w0, #12
	b.hi	LBB37_85
; %bb.71:                               ; %b42.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, w0
Lloh158:
	adrp	x11, lJTI37_3@PAGE
Lloh159:
	add	x11, x11, lJTI37_3@PAGEOFF
	adr	x9, LBB37_72
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	mov	w26, wzr
	br	x9
LBB37_72:                               ; %b1.i119.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	x9, [sp, #4312]
	ldr	x10, [sp, #4320]
	mov	w8, wzr
	ldr	x11, [sp, #4328]
	mov	w26, wzr
	b	LBB37_87
LBB37_73:                               ;   in Loop: Header=BB37_47 Depth=1
	ldr	x27, [sp, #768]                 ; 8-byte Folded Reload
	add	x13, sp, #4042
	add	x19, sp, #4030
	str	x13, [sp, #192]                 ; 8-byte Folded Spill
	add	x4, sp, #4054
	add	x5, sp, #4080
	add	x23, sp, #4086
	add	x0, sp, #4082
	add	x13, sp, #4066
	str	x19, [sp, #200]                 ; 8-byte Folded Spill
	add	x22, sp, #4084
	b	LBB37_98
LBB37_74:                               ;   in Loop: Header=BB37_47 Depth=1
	ldr	x26, [sp, #760]                 ; 8-byte Folded Reload
	add	x13, sp, #4042
	add	x19, sp, #4030
	str	x13, [sp, #192]                 ; 8-byte Folded Spill
	add	x4, sp, #4054
	add	x5, sp, #4080
	add	x23, sp, #4086
	add	x0, sp, #4082
	add	x13, sp, #4066
	str	x19, [sp, #200]                 ; 8-byte Folded Spill
	b	LBB37_98
LBB37_75:                               ; %b31.i.i106.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #10                        ; =0xa
	b	LBB37_86
LBB37_76:                               ; %b4.i.i118.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #1                         ; =0x1
	b	LBB37_86
LBB37_77:                               ; %b13.i.i115.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #4                         ; =0x4
	b	LBB37_86
LBB37_78:                               ; %b34.i.i113.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #11                        ; =0xb
	b	LBB37_86
LBB37_79:                               ; %b16.i.i114.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #5                         ; =0x5
	b	LBB37_86
LBB37_80:                               ; %b22.i.i112.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #7                         ; =0x7
	b	LBB37_86
LBB37_81:                               ; %b7.i.i117.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #2                         ; =0x2
	b	LBB37_86
LBB37_82:                               ; %b10.i.i116.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #3                         ; =0x3
	b	LBB37_86
LBB37_83:                               ; %b28.i.i110.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #9                         ; =0x9
	b	LBB37_86
LBB37_84:                               ; %b25.i.i111.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #8                         ; =0x8
	b	LBB37_86
LBB37_85:                               ; %b36.i.i120.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w26, #6                         ; =0x6
LBB37_86:                               ; %liza___liza_reactor_error.exit.i107.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	x9, xzr
	mov	x10, xzr
	mov	x11, xzr
	mov	w8, #1                          ; =0x1
LBB37_87:                               ; %liza_net.reactor_accept.exit.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	x20, [sp, #960]                 ; 8-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB37_90
; %bb.88:                               ; %b45.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w25, #1                         ; =0x1
	add	x27, sp, #1, lsl #12            ; =4096
	add	x8, sp, #1, lsl #12             ; =4096
	lsl	w25, w25, w26
	add	x12, sp, #1, lsl #12            ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x30, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	mov	w26, #3827                      ; =0xef3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x27, x27, #4
	add	x0, sp, #4042
	add	x8, x8, #12
	add	x12, x12, #16
	add	x9, sp, #4054
	add	x11, x11, #24
	add	x10, x10, #28
	add	x14, sp, #4066
	add	x16, x16, #36
	add	x15, x15, #40
	add	x17, sp, #4080
	add	x1, x1, #48
	add	x2, x2, #52
	add	x3, sp, #4082
	add	x6, x6, #60
	add	x19, x19, #64
	add	x20, sp, #4084
	add	x30, x30, #72
	add	x22, x22, #76
	add	x23, sp, #4086
	add	x24, x24, #84
	tst	w25, w26
	str	wzr, [sp, #1352]                ; 4-byte Folded Spill
	b.eq	LBB37_342
; %bb.89:                               ;   in Loop: Header=BB37_47 Depth=1
	mov	w25, #3                         ; =0x3
	add	x13, sp, #4030
	add	x26, sp, #4088
	str	w25, [sp, #700]                 ; 4-byte Folded Spill
	str	x13, [sp, #816]                 ; 8-byte Folded Spill
	b	LBB37_97
LBB37_90:                               ; %b49.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	add	x2, sp, #1, lsl #12             ; =4096
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	mov	w1, #9003                       ; =0x232b
	add	x2, x2, #216
	str	x11, [sp, #144]                 ; 8-byte Folded Spill
	str	x10, [sp, #168]                 ; 8-byte Folded Spill
	str	x9, [sp, #1352]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_connect
	cmp	w0, #12
	b.hi	LBB37_92
; %bb.91:                               ; %b49.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, w0
Lloh160:
	adrp	x11, lJTI37_4@PAGE
Lloh161:
	add	x11, x11, lJTI37_4@PAGEOFF
	adr	x9, LBB37_92
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB37_92:                               ; %liza___liza_reactor_error.exit.i134.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	mov	x10, xzr
	mov	x9, xzr
	mov	x8, xzr
	mov	w11, #1                         ; =0x1
LBB37_93:                               ; %liza_net.reactor_connect.exit.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	w13, [sp, #1448]                ; 4-byte Folded Reload
	ldr	x14, [sp, #1440]                ; 8-byte Folded Reload
	cmp	w11, #1
	ldr	x15, [sp, #1432]                ; 8-byte Folded Reload
	ldr	x6, [sp, #1424]                 ; 8-byte Folded Reload
	ldr	x7, [sp, #808]                  ; 8-byte Folded Reload
	ldr	x22, [sp, #800]                 ; 8-byte Folded Reload
	ldr	w16, [sp, #796]                 ; 4-byte Folded Reload
	ldr	w23, [sp, #792]                 ; 4-byte Folded Reload
	ldr	w24, [sp, #788]                 ; 4-byte Folded Reload
	ldr	w27, [sp, #784]                 ; 4-byte Folded Reload
	ldr	w30, [sp, #780]                 ; 4-byte Folded Reload
	ldr	w26, [sp, #776]                 ; 4-byte Folded Reload
	b.ne	LBB37_95
; %bb.94:                               ; %b51.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #1352]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #168]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #144]                  ; 8-byte Folded Reload
	bl	_liza_rt_reactor_disconnect
	ldr	w8, [sp, #420]                  ; 4-byte Folded Reload
	ldr	w13, [sp, #700]                 ; 4-byte Folded Reload
	mov	w9, #3                          ; =0x3
	ldr	w6, [sp, #416]                  ; 4-byte Folded Reload
	mov	w20, w25
	add	x10, sp, #1, lsl #12            ; =4096
	cmp	w8, #0
	add	x11, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	csel	w13, w9, w13, ne
	add	x14, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	ldp	w25, w30, [sp, #188]            ; 8-byte Folded Reload
	str	w13, [sp, #700]                 ; 4-byte Folded Spill
	add	x13, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x17, sp, #1, lsl #12            ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	ldr	w24, [sp, #816]                 ; 4-byte Folded Reload
	ldr	w27, [sp, #200]                 ; 4-byte Folded Reload
	ldr	w28, [sp, #184]                 ; 4-byte Folded Reload
	add	x8, sp, #1, lsl #12             ; =4096
	add	x10, x10, #4
	add	x11, x11, #12
	add	x12, x12, #16
	add	x13, x13, #24
	add	x14, x14, #28
	add	x15, x15, #36
	add	x16, x16, #40
	add	x17, x17, #48
	add	x0, x0, #52
	add	x1, x1, #60
	add	x2, x2, #64
	add	x3, x3, #72
	add	x4, x4, #76
	add	x5, x5, #84
	add	x9, sp, #4088
	str	w6, [sp, #1352]                 ; 4-byte Folded Spill
	mov	w26, w19
	b	LBB37_96
LBB37_95:                               ; %v101_ok.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	w11, [sp, #1360]                ; 4-byte Folded Reload
	ldr	x5, [sp, #136]                  ; 8-byte Folded Reload
	ldr	x4, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #120]                  ; 8-byte Folded Reload
	ldr	x2, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
	str	w11, [sp, #3248]
	ldrh	w11, [sp, #4180]
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	ldr	x17, [sp, #88]                  ; 8-byte Folded Reload
	strb	w16, [sp, #3612]
	ldr	x16, [sp, #80]                  ; 8-byte Folded Reload
	strh	w11, [x5]
	ldr	w11, [sp, #1308]                ; 4-byte Folded Reload
	ldr	w12, [sp, #252]                 ; 4-byte Folded Reload
	str	x15, [sp, #3648]
	ldr	x15, [sp, #72]                  ; 8-byte Folded Reload
	ldr	x19, [sp, #16]                  ; 8-byte Folded Reload
	str	w11, [sp, #3316]
	ldr	w11, [sp, #1304]                ; 4-byte Folded Reload
	str	x14, [sp, #3640]
	ldr	x14, [sp, #64]                  ; 8-byte Folded Reload
	str	w11, [sp, #3320]
	ldr	w11, [sp, #992]                 ; 4-byte Folded Reload
	str	w12, [sp, #3252]
	ldr	x12, [sp, #304]                 ; 8-byte Folded Reload
	strb	w11, [sp, #3324]
	ldr	w11, [sp, #984]                 ; 4-byte Folded Reload
	str	x12, [sp, #3256]
	ldr	x12, [sp, #1344]                ; 8-byte Folded Reload
	strb	w11, [sp, #3325]
	ldr	w11, [sp, #200]                 ; 4-byte Folded Reload
	str	x6, [sp, #3656]
	ldr	x6, [sp, #56]                   ; 8-byte Folded Reload
	strh	w11, [sp, #3326]
	ldr	w11, [sp, #300]                 ; 4-byte Folded Reload
	str	x12, [sp, #3264]
	ldr	x12, [sp, #1336]                ; 8-byte Folded Reload
	str	w11, [sp, #3328]
	ldr	w11, [sp, #296]                 ; 4-byte Folded Reload
	str	x12, [sp, #3272]
	ldr	w12, [sp, #380]                 ; 4-byte Folded Reload
	str	w11, [sp, #3332]
	ldr	w11, [sp, #404]                 ; 4-byte Folded Reload
	str	w12, [sp, #3280]
	ldr	w12, [sp, #248]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3336]
	ldr	w11, [sp, #4172]
	str	w12, [sp, #3284]
	ldr	x12, [sp, #1328]                ; 8-byte Folded Reload
	str	w11, [x4]
	ldr	w11, [sp, #1456]                ; 4-byte Folded Reload
	str	x12, [sp, #3288]
	ldr	x12, [sp, #1320]                ; 8-byte Folded Reload
	str	w11, [sp, #3344]
	ldr	w11, [sp, #244]                 ; 4-byte Folded Reload
	str	x12, [sp, #3296]
	ldr	x12, [sp, #1312]                ; 8-byte Folded Reload
	str	w11, [sp, #3348]
	ldr	x11, [sp, #280]                 ; 8-byte Folded Reload
	str	x12, [sp, #3304]
	ldr	w12, [sp, #1000]                ; 4-byte Folded Reload
	str	x11, [sp, #3352]
	ldr	x11, [sp, #288]                 ; 8-byte Folded Reload
	strb	w12, [sp, #3312]
	add	x12, sp, #87
	str	x11, [sp, #3360]
	ldr	x11, [sp, #272]                 ; 8-byte Folded Reload
	ldrb	w12, [x12, #4095]
	str	x7, [sp, #3680]
	ldr	x7, [sp, #48]                   ; 8-byte Folded Reload
	str	x11, [sp, #3368]
	ldr	w11, [sp, #324]                 ; 4-byte Folded Reload
	strb	w12, [x5, #2]
	ldr	w12, [sp, #400]                 ; 4-byte Folded Reload
	str	w11, [sp, #3376]
	ldr	w11, [sp, #240]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3337]
	ldrh	w12, [sp, #4176]
	str	w11, [sp, #3380]
	ldr	x11, [sp, #1240]                ; 8-byte Folded Reload
	strh	w12, [x4, #4]
	ldr	w12, [sp, #340]                 ; 4-byte Folded Reload
	str	x11, [sp, #3384]
	ldr	x11, [sp, #1248]                ; 8-byte Folded Reload
	strb	w12, [sp, #3408]
	ldrh	w12, [sp, #4168]
	str	x11, [sp, #3392]
	ldr	x11, [sp, #1208]                ; 8-byte Folded Reload
	strh	w12, [x3]
	ldr	w12, [sp, #360]                 ; 4-byte Folded Reload
	str	x11, [sp, #3400]
	add	x11, sp, #75
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3433]
	ldr	w12, [sp, #4160]
	str	x20, [sp, #3672]
	ldr	x20, [sp, #40]                  ; 8-byte Folded Reload
	strb	w11, [x3, #2]
	ldr	w11, [sp, #1272]                ; 4-byte Folded Reload
	str	w12, [x2]
	ldr	w12, [sp, #332]                 ; 4-byte Folded Reload
	str	w11, [sp, #3412]
	ldr	w11, [sp, #1276]                ; 4-byte Folded Reload
	strb	w12, [sp, #3504]
	ldrh	w12, [sp, #4156]
	str	w11, [sp, #3416]
	ldr	w11, [sp, #356]                 ; 4-byte Folded Reload
	strh	w12, [x1]
	ldr	w12, [sp, #352]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3420]
	ldr	w11, [sp, #364]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3529]
	ldr	w12, [sp, #4148]
	strb	w11, [sp, #3421]
	ldr	w11, [sp, #1264]                ; 4-byte Folded Reload
	str	w12, [x0]
	ldr	w12, [sp, #1400]                ; 4-byte Folded Reload
	str	w11, [sp, #3424]
	ldr	w11, [sp, #1268]                ; 4-byte Folded Reload
	strb	w12, [sp, #3600]
	ldrh	w12, [sp, #4020]
	str	w11, [sp, #3428]
	ldr	w11, [sp, #344]                 ; 4-byte Folded Reload
	strh	w12, [x17]
	ldr	w12, [sp, #4072]
	strb	w11, [sp, #3432]
	ldrh	w11, [sp, #4164]
	str	w12, [x16]
	ldr	w12, [sp, #864]                 ; 4-byte Folded Reload
	strh	w11, [x2, #4]
	ldr	w11, [sp, #1380]                ; 4-byte Folded Reload
	strb	w12, [sp, #3696]
	ldrh	w12, [sp, #4068]
	str	w11, [sp, #3440]
	ldr	w11, [sp, #232]                 ; 4-byte Folded Reload
	strh	w12, [x15]
	ldr	w12, [sp, #860]                 ; 4-byte Folded Reload
	str	w11, [sp, #3444]
	ldr	x11, [sp, #1128]                ; 8-byte Folded Reload
	strb	w12, [sp, #3709]
	ldr	w12, [sp, #852]                 ; 4-byte Folded Reload
	str	x11, [sp, #3448]
	ldr	x11, [sp, #1136]                ; 8-byte Folded Reload
	str	x22, [sp, #3688]
	ldr	x22, [sp, #32]                  ; 8-byte Folded Reload
	str	x11, [sp, #3456]
	ldr	x11, [sp, #1144]                ; 8-byte Folded Reload
	strb	w12, [sp, #3721]
	ldr	w12, [sp, #4060]
	str	x11, [sp, #3464]
	ldr	w11, [sp, #256]                 ; 4-byte Folded Reload
	str	w12, [x14]
	ldr	w12, [sp, #844]                 ; 4-byte Folded Reload
	str	w11, [sp, #3472]
	ldr	w11, [sp, #236]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3792]
	ldrh	w12, [sp, #4056]
	str	w11, [sp, #3476]
	ldr	x11, [sp, #1104]                ; 8-byte Folded Reload
	strh	w12, [x6]
	ldr	w12, [sp, #836]                 ; 4-byte Folded Reload
	str	x11, [sp, #3480]
	ldr	x11, [sp, #1112]                ; 8-byte Folded Reload
	strb	w12, [sp, #3805]
	ldr	w12, [sp, #372]                 ; 4-byte Folded Reload
	str	x11, [sp, #3488]
	ldr	x11, [sp, #1120]                ; 8-byte Folded Reload
	strb	w12, [sp, #3817]
	ldr	w12, [sp, #4048]
	str	x11, [sp, #3496]
	add	x11, sp, #63
	ldrb	w11, [x11, #4095]
	str	w12, [x7]
	ldr	w12, [sp, #376]                 ; 4-byte Folded Reload
	strb	w23, [sp, #3613]
	ldr	x23, [sp, #24]                  ; 8-byte Folded Reload
	strb	w11, [x1, #2]
	ldr	w11, [sp, #1168]                ; 4-byte Folded Reload
	strb	w12, [sp, #3888]
	ldrh	w12, [sp, #4044]
	str	w11, [sp, #3508]
	ldr	w11, [sp, #1176]                ; 4-byte Folded Reload
	strh	w12, [x20]
	ldr	w12, [sp, #388]                 ; 4-byte Folded Reload
	str	w11, [sp, #3512]
	ldr	w11, [sp, #336]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3901]
	ldr	w12, [sp, #392]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3516]
	ldr	w11, [sp, #348]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3912]
	ldr	w12, [sp, #4036]
	strb	w11, [sp, #3517]
	ldr	w11, [sp, #1152]                ; 4-byte Folded Reload
	str	w12, [x22]
	ldr	x12, [sp, #1256]                ; 8-byte Folded Reload
	str	w11, [sp, #3520]
	ldr	w11, [sp, #1164]                ; 4-byte Folded Reload
	str	w13, [sp, #3620]
	ldr	w13, [sp, #260]                 ; 4-byte Folded Reload
	str	w11, [sp, #3524]
	ldr	w11, [sp, #328]                 ; 4-byte Folded Reload
	str	x12, [sp, #3976]
	ldrh	w12, [sp, #4032]
	strb	w11, [sp, #3528]
	ldrh	w11, [sp, #4152]
	strb	w13, [sp, #3913]
	ldr	w13, [sp, #396]                 ; 4-byte Folded Reload
	strh	w11, [x0, #4]
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	strh	w12, [x23]
	ldr	w12, [sp, #408]                 ; 4-byte Folded Reload
	str	w11, [sp, #3536]
	ldr	w11, [sp, #224]                 ; 4-byte Folded Reload
	strb	w13, [sp, #3984]
	ldr	w13, [sp, #976]                 ; 4-byte Folded Reload
	str	w11, [sp, #3540]
	ldr	x11, [sp, #1080]                ; 8-byte Folded Reload
	strb	w12, [sp, #3996]
	ldr	w12, [sp, #412]                 ; 4-byte Folded Reload
	str	x11, [sp, #3544]
	ldr	x11, [sp, #1088]                ; 8-byte Folded Reload
	strh	w21, [sp, #3422]
	mov	w21, #96                        ; =0x60
	str	x11, [sp, #3552]
	ldr	x11, [sp, #1096]                ; 8-byte Folded Reload
	strb	w13, [sp, #4009]
	add	x13, sp, #3248
	umaddl	x13, w28, w21, x13
	str	x11, [sp, #3560]
	ldr	w11, [sp, #320]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3997]
	ldr	w12, [sp, #968]                 ; 4-byte Folded Reload
	str	w11, [sp, #3568]
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
	strb	w12, [sp, #4008]
	ldr	w12, [sp, #4024]
	str	w11, [sp, #3572]
	ldr	x11, [sp, #1064]                ; 8-byte Folded Reload
	strh	w25, [sp, #3518]
	str	x11, [sp, #3576]
	ldr	x11, [sp, #1072]                ; 8-byte Folded Reload
	strb	w27, [sp, #3624]
	str	x11, [sp, #3584]
	ldr	x11, [sp, #1184]                ; 8-byte Folded Reload
	strb	w24, [sp, #3625]
	str	x11, [sp, #3592]
	ldrb	w11, [sp, #4022]
	str	w12, [x19]
	mov	x12, x7
	strb	w11, [x17, #2]
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	str	w30, [sp, #3636]
	str	w11, [sp, #3604]
	ldr	w11, [sp, #1412]                ; 4-byte Folded Reload
	str	w26, [sp, #3668]
	str	w11, [sp, #3608]
	ldr	w11, [sp, #816]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3614]
	ldr	w11, [sp, #1420]                ; 4-byte Folded Reload
	str	w11, [sp, #3616]
	ldrh	w11, [sp, #4076]
	strh	w11, [x16, #4]
	ldr	w11, [sp, #956]                 ; 4-byte Folded Reload
	str	w11, [sp, #3632]
	ldr	w11, [sp, #1416]                ; 4-byte Folded Reload
	str	w11, [sp, #3664]
	ldrb	w11, [sp, #4070]
	strb	w11, [x15, #2]
	ldr	w11, [sp, #948]                 ; 4-byte Folded Reload
	str	w11, [sp, #3700]
	ldr	w11, [sp, #944]                 ; 4-byte Folded Reload
	str	w11, [sp, #3704]
	ldr	w11, [sp, #856]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3708]
	ldrh	w11, [sp, #4066]
	strh	w11, [sp, #3710]
	ldr	w11, [sp, #940]                 ; 4-byte Folded Reload
	str	w11, [sp, #3712]
	ldr	w11, [sp, #936]                 ; 4-byte Folded Reload
	str	w11, [sp, #3716]
	ldr	w11, [sp, #848]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3720]
	ldrh	w11, [sp, #4064]
	strh	w11, [x14, #4]
	ldr	w11, [sp, #952]                 ; 4-byte Folded Reload
	str	w11, [sp, #3728]
	ldr	w11, [sp, #828]                 ; 4-byte Folded Reload
	str	w11, [sp, #3732]
	ldr	x11, [sp, #928]                 ; 8-byte Folded Reload
	str	x11, [sp, #3736]
	ldr	x11, [sp, #920]                 ; 8-byte Folded Reload
	str	x11, [sp, #3744]
	ldr	x11, [sp, #912]                 ; 8-byte Folded Reload
	str	x11, [sp, #3752]
	ldr	w11, [sp, #832]                 ; 4-byte Folded Reload
	str	w11, [sp, #3760]
	ldr	w11, [sp, #824]                 ; 4-byte Folded Reload
	str	w11, [sp, #3764]
	ldr	x11, [sp, #904]                 ; 8-byte Folded Reload
	str	x11, [sp, #3768]
	ldr	x11, [sp, #896]                 ; 8-byte Folded Reload
	str	x11, [sp, #3776]
	ldr	x11, [sp, #880]                 ; 8-byte Folded Reload
	str	x11, [sp, #3784]
	ldrb	w11, [sp, #4058]
	strb	w11, [x6, #2]
	ldr	w11, [sp, #892]                 ; 4-byte Folded Reload
	str	w11, [sp, #3796]
	ldr	w11, [sp, #876]                 ; 4-byte Folded Reload
	str	w11, [sp, #3800]
	ldr	w11, [sp, #840]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3804]
	ldrh	w11, [sp, #4054]
	strh	w11, [sp, #3806]
	ldr	w11, [sp, #872]                 ; 4-byte Folded Reload
	str	w11, [sp, #3808]
	ldr	w11, [sp, #868]                 ; 4-byte Folded Reload
	str	w11, [sp, #3812]
	ldr	w11, [sp, #368]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3816]
	ldrh	w11, [sp, #4052]
	strh	w11, [x7, #4]
	ldr	w11, [sp, #1384]                ; 4-byte Folded Reload
	str	w11, [sp, #3824]
	ldr	w11, [sp, #208]                 ; 4-byte Folded Reload
	str	w11, [sp, #3828]
	ldr	x11, [sp, #1032]                ; 8-byte Folded Reload
	str	x11, [sp, #3832]
	ldr	x11, [sp, #1040]                ; 8-byte Folded Reload
	str	x11, [sp, #3840]
	ldr	x11, [sp, #1048]                ; 8-byte Folded Reload
	str	x11, [sp, #3848]
	ldr	w11, [sp, #312]                 ; 4-byte Folded Reload
	str	w11, [sp, #3856]
	ldr	w11, [sp, #212]                 ; 4-byte Folded Reload
	str	w11, [sp, #3860]
	ldr	x11, [sp, #1008]                ; 8-byte Folded Reload
	str	x11, [sp, #3864]
	ldr	x11, [sp, #1016]                ; 8-byte Folded Reload
	str	x11, [sp, #3872]
	ldr	x11, [sp, #1024]                ; 8-byte Folded Reload
	str	x11, [sp, #3880]
	ldrb	w11, [sp, #4046]
	strb	w11, [x20, #2]
	ldr	w11, [sp, #1056]                ; 4-byte Folded Reload
	str	w11, [sp, #3892]
	ldr	w11, [sp, #1060]                ; 4-byte Folded Reload
	str	w11, [sp, #3896]
	ldr	w11, [sp, #384]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3900]
	ldrh	w11, [sp, #4042]
	strh	w11, [sp, #3902]
	ldr	w11, [sp, #1296]                ; 4-byte Folded Reload
	str	w11, [sp, #3904]
	ldr	w11, [sp, #268]                 ; 4-byte Folded Reload
	str	w11, [sp, #3908]
	ldrh	w11, [sp, #4040]
	strh	w11, [x22, #4]
	ldr	w11, [sp, #1396]                ; 4-byte Folded Reload
	str	w11, [sp, #3920]
	ldr	w11, [sp, #216]                 ; 4-byte Folded Reload
	str	w11, [sp, #3924]
	ldr	x11, [sp, #1216]                ; 8-byte Folded Reload
	str	x11, [sp, #3928]
	ldr	x11, [sp, #1224]                ; 8-byte Folded Reload
	str	x11, [sp, #3936]
	ldr	x11, [sp, #1232]                ; 8-byte Folded Reload
	str	x11, [sp, #3944]
	ldr	w11, [sp, #316]                 ; 4-byte Folded Reload
	str	w11, [sp, #3952]
	ldr	w11, [sp, #220]                 ; 4-byte Folded Reload
	strb	wzr, [x13, #64]
	str	w11, [sp, #3956]
	ldr	x11, [sp, #1192]                ; 8-byte Folded Reload
	str	x11, [sp, #3960]
	ldr	x11, [sp, #1200]                ; 8-byte Folded Reload
	str	x11, [sp, #3968]
	ldrb	w11, [sp, #4034]
	strb	w11, [x23, #2]
	ldr	w11, [sp, #1280]                ; 4-byte Folded Reload
	str	wzr, [x13]
	str	w11, [sp, #3988]
	ldr	w11, [sp, #1284]                ; 4-byte Folded Reload
	str	wzr, [x13, #32]
	str	w11, [sp, #3992]
	ldrh	w11, [sp, #4030]
	strh	wzr, [x13, #76]
	strh	w11, [sp, #3998]
	ldr	w11, [sp, #1288]                ; 4-byte Folded Reload
	stur	xzr, [x13, #68]
	str	w11, [sp, #4000]
	ldr	w11, [sp, #264]                 ; 4-byte Folded Reload
	str	w11, [sp, #4004]
	ldrh	w11, [sp, #4028]
	stp	x10, x9, [x13, #40]
	ldr	w10, [sp, #3248]
	strh	w11, [x19, #4]
	ldr	x11, [sp, #1352]                ; 8-byte Folded Reload
	str	x8, [x13, #56]
	ldr	w8, [sp, #3280]
	str	w10, [sp, #1360]                ; 4-byte Folded Spill
	ldr	w10, [sp, #3252]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3284]
	str	x11, [x13, #8]
	ldr	x11, [sp, #168]                 ; 8-byte Folded Reload
	stp	w8, w10, [sp, #248]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3288]
	ldr	x9, [sp, #3256]
	str	x11, [x13, #16]
	ldr	x11, [sp, #144]                 ; 8-byte Folded Reload
	ldr	x10, [sp, #3352]
	str	x8, [sp, #1328]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3296]
	ldrh	w27, [sp, #3326]
	str	x11, [x13, #24]
	ldrh	w21, [sp, #3422]
	ldrh	w24, [sp, #3614]
	str	x8, [sp, #1320]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3304]
	ldrh	w26, [sp, #3710]
	strh	wzr, [x13, #88]
	ldrh	w30, [sp, #3806]
	ldrh	w25, [sp, #3902]
	str	x8, [sp, #1312]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3312]
	ldrh	w28, [sp, #3998]
	str	xzr, [x13, #80]
	mov	x13, x6
	mov	x11, x20
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3316]
	str	x9, [sp, #304]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #3264]
	str	w8, [sp, #1308]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3320]
	str	x9, [sp, #1344]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #3272]
	str	w8, [sp, #1304]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3324]
	str	x9, [sp, #1336]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #3348]
	str	w8, [sp, #992]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3325]
	str	w8, [sp, #984]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3328]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3332]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3336]
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3337]
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3344]
	str	w8, [sp, #1456]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3360]
	stp	x10, x8, [sp, #280]             ; 16-byte Folded Spill
	ldr	x8, [sp, #3368]
	ldrh	w10, [sp, #3518]
	str	x8, [sp, #272]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3376]
	mov	w20, w10
	mov	x10, x22
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3380]
	stp	w8, w9, [sp, #240]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3384]
	ldr	w9, [sp, #3444]
	str	x8, [sp, #1240]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3392]
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3400]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3408]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3412]
	str	w8, [sp, #1272]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3416]
	str	w8, [sp, #1276]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3420]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3421]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3424]
	str	w8, [sp, #1264]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3428]
	str	w8, [sp, #1268]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3432]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3433]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3440]
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3448]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3456]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3464]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3472]
	str	w8, [sp, #256]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3476]
	stp	w9, w8, [sp, #232]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3480]
	ldr	w9, [sp, #3540]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3488]
	str	x8, [sp, #1112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3496]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3504]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3508]
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3512]
	str	w8, [sp, #1176]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3516]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3517]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3520]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3524]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3528]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3529]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3536]
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3544]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3552]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3560]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3568]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3572]
	stp	w9, w8, [sp, #224]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3576]
	ldr	w9, [sp, #3828]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3584]
	str	x8, [sp, #1072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3592]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3600]
	str	w8, [sp, #1400]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3604]
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3608]
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3612]
	str	w8, [sp, #796]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3613]
	str	w8, [sp, #792]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3616]
	str	w8, [sp, #1420]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3620]
	str	w8, [sp, #1448]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3624]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3625]
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3632]
	str	w8, [sp, #956]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3636]
	str	w8, [sp, #780]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3640]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3648]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3656]
	str	x8, [sp, #1424]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3664]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3668]
	str	w8, [sp, #776]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3672]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3680]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3688]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3696]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3700]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3704]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3708]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3709]
	str	w8, [sp, #860]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3712]
	str	w8, [sp, #940]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3716]
	str	w8, [sp, #936]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3720]
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3721]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3728]
	str	w8, [sp, #952]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3732]
	str	w8, [sp, #828]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3736]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3744]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3752]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3760]
	str	w8, [sp, #832]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3764]
	str	w8, [sp, #824]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3768]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3776]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3784]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3792]
	str	w8, [sp, #844]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3796]
	str	w8, [sp, #892]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3800]
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3804]
	str	w8, [sp, #840]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3805]
	str	w8, [sp, #836]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3808]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3812]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3816]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3817]
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3824]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3832]
	str	x8, [sp, #1032]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3840]
	str	x8, [sp, #1040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3848]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3856]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3860]
	stp	w9, w8, [sp, #208]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3864]
	ldr	w9, [sp, #3924]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3872]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3880]
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3888]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3892]
	str	w8, [sp, #1056]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3896]
	str	w8, [sp, #1060]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3900]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3901]
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3904]
	str	w8, [sp, #1296]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3908]
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3912]
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3913]
	str	w8, [sp, #260]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3920]
	str	w8, [sp, #1396]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3928]
	str	x8, [sp, #1216]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3936]
	str	x8, [sp, #1224]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3944]
	str	x8, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3952]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3956]
	stp	w9, w8, [sp, #216]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3960]
	mov	x9, x19
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3968]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3976]
	str	x8, [sp, #1256]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3984]
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3988]
	str	w8, [sp, #1280]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3992]
	str	w8, [sp, #1284]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3996]
	str	w8, [sp, #408]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3997]
	str	w8, [sp, #412]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4000]
	str	w8, [sp, #1288]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4004]
	str	w8, [sp, #264]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #4008]
	str	w8, [sp, #968]                  ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #4009]
	str	w8, [sp, #976]                  ; 4-byte Folded Spill
	mov	x8, x23
LBB37_96:                               ; %b56_to_b57.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldrh	w6, [x5]
	ldrb	w5, [x5, #2]
	add	x19, sp, #3224
	ldr	w7, [x4]
	strh	w24, [sp, #3206]
	add	x23, sp, #3242
	strb	w5, [sp, #3246]
	ldrh	w5, [x3]
	ldrb	w3, [x3, #2]
	ldr	w24, [x9]
	ldrh	w22, [x9, #4]
	add	x9, sp, #3182
	strb	w3, [sp, #3234]
	ldr	w3, [x2]
	ldrh	w2, [x2, #4]
	ldrh	w4, [x4, #4]
	strh	w27, [sp, #3242]
	add	x27, sp, #3164
	str	w3, [sp, #3224]
	ldrb	w3, [x1, #2]
	ldrh	w1, [x1]
	strh	w2, [sp, #3228]
	ldrh	w2, [x8]
	strh	w1, [sp, #3220]
	ldrh	w1, [x0, #4]
	ldr	w0, [x0]
	strh	w6, [sp, #3244]
	add	x6, sp, #3220
	strh	w1, [sp, #3216]
	ldrb	w1, [x17, #2]
	ldrh	w17, [x17]
	str	w7, [sp, #3236]
	add	x7, sp, #3160
	strh	w17, [sp, #3208]
	ldrh	w17, [x16, #4]
	ldr	w16, [x16]
	strb	w3, [sp, #3222]
	add	x3, sp, #3218
	strh	w17, [sp, #3204]
	ldrb	w17, [x15, #2]
	ldrh	w15, [x15]
	str	w16, [sp, #3200]
	ldrh	w16, [x14, #4]
	ldr	w14, [x14]
	strh	w15, [sp, #3196]
	ldrh	w15, [x13]
	ldrb	w13, [x13, #2]
	str	w14, [sp, #3188]
	mov	w14, #1                         ; =0x1
	strb	w17, [sp, #3198]
	ldrb	w17, [x8, #2]
	add	x8, sp, #3172
	strh	w16, [sp, #3192]
	ldr	w16, [x12]
	ldrh	w12, [x12, #4]
	str	w14, [sp, #168]                 ; 4-byte Folded Spill
	ldrh	w14, [x11]
	ldrb	w11, [x11, #2]
	strh	w15, [sp, #3184]
	ldr	w15, [x10]
	ldrh	w10, [x10, #4]
	strh	w20, [sp, #3218]
	add	x20, sp, #3230
	str	w0, [sp, #3212]
	add	x0, sp, #3170
	strb	w1, [sp, #3210]
	add	x1, sp, #3208
	strh	w26, [sp, #3194]
	add	x26, sp, #3152
	strb	w13, [sp, #3186]
	add	x13, sp, #3158
	strh	w30, [sp, #3182]
	add	x30, sp, #3232
	strh	w12, [sp, #3180]
	add	x12, sp, #3176
	str	w16, [sp, #3176]
	add	x16, sp, #3196
	strb	w11, [sp, #3174]
	add	x11, sp, #3184
	strh	w14, [sp, #3172]
	add	x14, sp, #3194
	strh	w10, [sp, #3168]
	add	x10, sp, #3188
	str	w15, [sp, #3164]
	add	x15, sp, #3200
	strb	w17, [sp, #3162]
	add	x17, sp, #3206
	strh	w2, [sp, #3160]
	add	x2, sp, #3212
	strh	w22, [sp, #3156]
	add	x22, sp, #3236
	str	w24, [sp, #3152]
	add	x24, sp, #3244
	strh	w4, [sp, #3240]
	strh	w5, [sp, #3232]
	strh	w21, [sp, #3230]
	str	x13, [sp, #816]                 ; 8-byte Folded Spill
	strh	w25, [sp, #3170]
	strh	w28, [sp, #3158]
LBB37_97:                               ; %b57_to_b58.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldrh	w20, [x20]
	ldrh	w9, [x9]
	add	x13, sp, #3062
	ldrh	w3, [x3]
	ldrb	w21, [x30, #2]
	add	x4, sp, #3086
	strh	w20, [sp, #3134]
	ldrh	w20, [x6]
	add	x5, sp, #3110
	ldrb	w6, [x6, #2]
	strh	w9, [sp, #3086]
	ldr	w9, [x12]
	strh	w3, [sp, #3122]
	ldrb	w3, [x1, #2]
	ldrh	w1, [x1]
	strb	w6, [sp, #3126]
	ldrh	w6, [x2, #4]
	ldr	w2, [x2]
	str	w9, [sp, #3080]
	ldrh	w9, [x0]
	add	x0, sp, #3122
	str	w2, [sp, #3116]
	ldrh	w2, [x16]
	ldrh	w25, [x24]
	strh	w9, [sp, #3074]
	ldr	w9, [x27]
	ldrh	w23, [x23]
	strh	w2, [sp, #3100]
	ldrh	w2, [x10, #4]
	ldr	w10, [x10]
	ldrh	w17, [x17]
	strh	w1, [sp, #3112]
	ldrh	w1, [x15, #4]
	str	w10, [sp, #3092]
	ldrh	w10, [x11]
	ldrh	w14, [x14]
	str	w9, [sp, #3068]
	ldr	x9, [sp, #816]                  ; 8-byte Folded Reload
	ldrb	w24, [x24, #2]
	strh	w10, [sp, #3088]
	ldrh	w10, [x12, #4]
	strb	w21, [sp, #3138]
	ldr	w21, [x19]
	ldrh	w19, [x19, #4]
	strh	w10, [sp, #3084]
	ldrb	w10, [x8, #2]
	ldrh	w8, [x8]
	strh	w25, [sp, #3148]
	ldr	w25, [x22]
	ldrh	w22, [x22, #4]
	strb	w10, [sp, #3078]
	ldrh	w10, [x27, #4]
	ldrh	w12, [x9]
	add	x9, sp, #3128
	strh	w23, [sp, #3146]
	ldrh	w23, [x30]
	add	x30, sp, #3112
	strh	w17, [sp, #3110]
	ldr	w17, [x15]
	add	x15, sp, #3056
	strh	w1, [sp, #3108]
	ldrb	w1, [x16, #2]
	add	x16, sp, #3064
	strh	w14, [sp, #3098]
	ldrb	w14, [x11, #2]
	strh	w10, [sp, #3072]
	ldrb	w10, [x7, #2]
	ldrh	w11, [x7]
	add	x7, sp, #3124
	strb	w24, [sp, #3150]
	ldr	x27, [sp, #768]                 ; 8-byte Folded Reload
	str	w21, [sp, #3128]
	ldr	w21, [x26]
	ldr	w24, [sp, #1360]                ; 4-byte Folded Reload
	strh	w19, [sp, #3132]
	ldrh	w19, [x26, #4]
	ldr	x26, [sp, #760]                 ; 8-byte Folded Reload
	str	x13, [sp, #200]                 ; 8-byte Folded Spill
	add	x13, sp, #3074
	strh	w22, [sp, #3144]
	add	x22, sp, #3134
	strh	w23, [sp, #3136]
	add	x23, sp, #3146
	strh	w20, [sp, #3124]
	add	x20, sp, #3104
	strh	w6, [sp, #3120]
	add	x6, sp, #3092
	strb	w3, [sp, #3114]
	add	x3, sp, #3088
	str	w17, [sp, #3104]
	add	x17, sp, #3068
	strb	w1, [sp, #3102]
	add	x1, sp, #3076
	str	x13, [sp, #192]                 ; 8-byte Folded Spill
	add	x13, sp, #3098
	strh	w2, [sp, #3096]
	add	x2, sp, #3080
	strb	w14, [sp, #3090]
	add	x14, sp, #3100
	strh	w8, [sp, #3076]
	add	x8, sp, #3116
	strb	w10, [sp, #3066]
	add	x10, sp, #3136
	strh	w11, [sp, #3064]
	add	x11, sp, #3140
	strh	w12, [sp, #3062]
	add	x12, sp, #3148
	str	w25, [sp, #3140]
	strh	w19, [sp, #3060]
	str	w21, [sp, #3056]
LBB37_98:                               ; %b58_to_b59.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldrh	w19, [x12]
	ldrb	w12, [x12, #2]
	ldr	x21, [sp, #752]                 ; 8-byte Folded Reload
	ldr	x25, [sp, #648]                 ; 8-byte Folded Reload
	str	w24, [sp, #2288]
	ldr	x24, [sp, #1440]                ; 8-byte Folded Reload
	strh	w19, [x21]
	ldr	w19, [x11]
	ldrh	w11, [x11, #4]
	strb	w12, [x21, #2]
	ldr	x21, [sp, #664]                 ; 8-byte Folded Reload
	ldrb	w12, [x10, #2]
	ldrh	w10, [x10]
	str	x24, [sp, #2680]
	str	w19, [x21]
	ldr	x19, [sp, #656]                 ; 8-byte Folded Reload
	strh	w11, [x21, #4]
	ldr	w11, [x9]
	ldrh	w9, [x9, #4]
	strh	w10, [x19]
	ldrh	w10, [x7]
	str	w11, [x25]
	ldr	x11, [sp, #680]                 ; 8-byte Folded Reload
	strh	w10, [x26]
	ldr	w10, [x8]
	ldrh	w8, [x8, #4]
	strh	w9, [x25, #4]
	ldrb	w9, [x7, #2]
	strh	w8, [x11, #4]
	ldrh	w8, [x30]
	str	w10, [x11]
	ldr	x10, [sp, #672]                 ; 8-byte Folded Reload
	ldr	x11, [sp, #640]                 ; 8-byte Folded Reload
	strh	w8, [x27]
	ldr	w8, [x20]
	strb	w9, [x26, #2]
	ldrb	w9, [x30, #2]
	ldrh	w30, [x4]
	str	w8, [x10]
	ldrh	w8, [x14]
	ldr	x4, [sp, #592]                  ; 8-byte Folded Reload
	strb	w9, [x27, #2]
	ldrh	w9, [x20, #4]
	ldr	x27, [sp, #1432]                ; 8-byte Folded Reload
	strh	w8, [sp, #2284]
	ldr	w8, [x6]
	ldr	x26, [sp, #1424]                ; 8-byte Folded Reload
	strh	w9, [x10, #4]
	ldrb	w9, [x14, #2]
	ldr	x10, [sp, #744]                 ; 8-byte Folded Reload
	str	w8, [sp, #2276]
	ldrh	w8, [x3]
	strb	w9, [sp, #2286]
	ldrh	w9, [x6, #4]
	strh	w8, [sp, #2272]
	ldr	w8, [x2]
	strh	w9, [sp, #2280]
	ldrb	w9, [x3, #2]
	ldr	x3, [sp, #600]                  ; 8-byte Folded Reload
	str	w8, [sp, #2264]
	ldrh	w8, [x1]
	strb	w9, [sp, #2274]
	ldrh	w9, [x2, #4]
	strh	w8, [sp, #2260]
	ldr	w8, [x17]
	strh	w9, [sp, #2268]
	ldrb	w9, [x1, #2]
	str	w8, [sp, #2252]
	ldrh	w8, [x16]
	strb	w9, [sp, #2262]
	ldrh	w9, [x17, #4]
	ldr	x17, [sp, #616]                 ; 8-byte Folded Reload
	strh	w8, [sp, #2248]
	ldr	w8, [x15]
	strh	w9, [sp, #2256]
	ldrb	w9, [x16, #2]
	str	w8, [sp, #2240]
	ldr	w8, [sp, #252]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2250]
	ldrh	w9, [x15, #4]
	ldr	x15, [sp, #624]                 ; 8-byte Folded Reload
	str	w8, [sp, #2292]
	ldr	x8, [sp, #304]                  ; 8-byte Folded Reload
	strh	w9, [sp, #2244]
	ldr	w9, [sp, #984]                  ; 4-byte Folded Reload
	str	x8, [sp, #2296]
	ldr	x8, [sp, #1344]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2365]
	str	x8, [sp, #2304]
	ldr	x8, [sp, #1336]                 ; 8-byte Folded Reload
	strb	w12, [x19, #2]
	ldr	x12, [sp, #632]                 ; 8-byte Folded Reload
	str	x8, [sp, #2312]
	ldr	w8, [sp, #380]                  ; 4-byte Folded Reload
	str	x27, [sp, #2688]
	str	w8, [sp, #2320]
	ldr	w8, [sp, #248]                  ; 4-byte Folded Reload
	str	x26, [sp, #2696]
	str	w8, [sp, #2324]
	ldr	x8, [sp, #1328]                 ; 8-byte Folded Reload
	strh	w30, [sp, #2846]
	str	x8, [sp, #2328]
	ldr	x8, [sp, #1320]                 ; 8-byte Folded Reload
	str	x8, [sp, #2336]
	ldr	x8, [sp, #1312]                 ; 8-byte Folded Reload
	str	x8, [sp, #2344]
	ldr	w8, [sp, #1000]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2352]
	ldr	w8, [sp, #1308]                 ; 4-byte Folded Reload
	str	w8, [sp, #2356]
	ldr	w8, [sp, #1304]                 ; 4-byte Folded Reload
	str	w8, [sp, #2360]
	ldr	w8, [sp, #992]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2364]
	ldrh	w8, [x23]
	ldr	w23, [sp, #1448]                ; 4-byte Folded Reload
	strh	w8, [sp, #2366]
	ldr	w8, [sp, #300]                  ; 4-byte Folded Reload
	str	w23, [sp, #2660]
	str	w8, [sp, #2368]
	ldr	w8, [sp, #296]                  ; 4-byte Folded Reload
	str	w8, [sp, #2372]
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2376]
	ldr	w8, [sp, #400]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2377]
	ldr	w8, [sp, #1456]                 ; 4-byte Folded Reload
	str	w8, [sp, #2384]
	ldr	w8, [sp, #244]                  ; 4-byte Folded Reload
	str	w8, [sp, #2388]
	ldp	x9, x8, [sp, #280]              ; 16-byte Folded Reload
	str	x8, [sp, #2400]
	ldr	x8, [sp, #272]                  ; 8-byte Folded Reload
	str	x9, [sp, #2392]
	ldr	w9, [sp, #364]                  ; 4-byte Folded Reload
	str	x8, [sp, #2408]
	ldr	w8, [sp, #324]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2461]
	ldr	w9, [sp, #348]                  ; 4-byte Folded Reload
	str	w8, [sp, #2416]
	ldr	w8, [sp, #240]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2557]
	ldr	x9, [sp, #1184]                 ; 8-byte Folded Reload
	str	w8, [sp, #2420]
	ldr	x8, [sp, #1240]                 ; 8-byte Folded Reload
	str	x9, [sp, #2632]
	ldrh	w9, [x14]
	str	x8, [sp, #2424]
	ldr	x8, [sp, #1248]                 ; 8-byte Folded Reload
	strh	w9, [x10]
	ldrh	w9, [sp, #2280]
	str	x8, [sp, #2432]
	ldr	x8, [sp, #1208]                 ; 8-byte Folded Reload
	strh	w9, [x11, #4]
	ldrb	w9, [sp, #2274]
	str	x8, [sp, #2440]
	ldr	w8, [sp, #340]                  ; 4-byte Folded Reload
	strb	w9, [x12, #2]
	ldr	w9, [sp, #372]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2448]
	ldr	w8, [sp, #1272]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2857]
	ldrh	w9, [sp, #2268]
	str	w8, [sp, #2452]
	ldr	w8, [sp, #1276]                 ; 4-byte Folded Reload
	strh	w9, [x15, #4]
	ldr	w9, [sp, #376]                  ; 4-byte Folded Reload
	str	w8, [sp, #2456]
	ldr	w8, [sp, #356]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2928]
	ldrh	w9, [sp, #2260]
	strb	w8, [sp, #2460]
	ldrh	w8, [x22]
	ldr	w22, [sp, #1416]                ; 4-byte Folded Reload
	strh	w9, [x17]
	ldrh	w9, [x5]
	strh	w8, [sp, #2462]
	ldr	w8, [sp, #1264]                 ; 4-byte Folded Reload
	str	w9, [sp, #816]                  ; 4-byte Folded Spill
	str	w8, [sp, #2464]
	ldr	w8, [sp, #1268]                 ; 4-byte Folded Reload
	strh	w9, [sp, #2654]
	ldr	w9, [sp, #384]                  ; 4-byte Folded Reload
	str	w8, [sp, #2468]
	ldr	w8, [sp, #344]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2940]
	ldr	w9, [sp, #388]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2472]
	ldr	w8, [sp, #360]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2941]
	ldr	w9, [sp, #260]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2473]
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2953]
	ldr	w9, [sp, #2252]
	str	w8, [sp, #2480]
	ldr	w8, [sp, #232]                  ; 4-byte Folded Reload
	str	w22, [sp, #2704]
	str	w8, [sp, #2484]
	ldr	x8, [sp, #1128]                 ; 8-byte Folded Reload
	str	x8, [sp, #2488]
	ldr	x8, [sp, #1136]                 ; 8-byte Folded Reload
	str	x8, [sp, #2496]
	ldr	x8, [sp, #1144]                 ; 8-byte Folded Reload
	str	x8, [sp, #2504]
	ldr	w8, [sp, #256]                  ; 4-byte Folded Reload
	str	w8, [sp, #2512]
	ldr	w8, [sp, #236]                  ; 4-byte Folded Reload
	str	w8, [sp, #2516]
	ldr	x8, [sp, #1104]                 ; 8-byte Folded Reload
	str	x8, [sp, #2520]
	ldr	x8, [sp, #1112]                 ; 8-byte Folded Reload
	str	x8, [sp, #2528]
	ldr	x8, [sp, #1120]                 ; 8-byte Folded Reload
	str	x8, [sp, #2536]
	ldr	w8, [sp, #332]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2544]
	ldr	w8, [sp, #1168]                 ; 4-byte Folded Reload
	str	w8, [sp, #2548]
	ldr	w8, [sp, #1176]                 ; 4-byte Folded Reload
	str	w8, [sp, #2552]
	ldr	w8, [sp, #336]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2556]
	ldrh	w8, [x0]
	ldr	x0, [sp, #608]                  ; 8-byte Folded Reload
	strh	w8, [sp, #2558]
	ldr	w8, [sp, #1152]                 ; 4-byte Folded Reload
	str	w9, [x0]
	ldr	w9, [sp, #396]                  ; 4-byte Folded Reload
	str	w8, [sp, #2560]
	ldr	w8, [sp, #1164]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3024]
	ldrh	w9, [sp, #2248]
	str	w8, [sp, #2564]
	ldr	w8, [sp, #328]                  ; 4-byte Folded Reload
	strh	w9, [x3]
	ldr	w9, [sp, #408]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2568]
	ldr	w8, [sp, #352]                  ; 4-byte Folded Reload
	strb	w9, [sp, #3036]
	ldr	w9, [sp, #412]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2569]
	ldr	w8, [sp, #1368]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3037]
	ldr	w9, [sp, #976]                  ; 4-byte Folded Reload
	str	w8, [sp, #2576]
	ldr	w8, [sp, #224]                  ; 4-byte Folded Reload
	strb	w9, [sp, #3049]
	ldr	w9, [sp, #2240]
	str	w8, [sp, #2580]
	ldr	x8, [sp, #1080]                 ; 8-byte Folded Reload
	str	w9, [x4]
	str	x8, [sp, #2584]
	ldr	x8, [sp, #1088]                 ; 8-byte Folded Reload
	str	x8, [sp, #2592]
	ldr	x8, [sp, #1096]                 ; 8-byte Folded Reload
	str	x8, [sp, #2600]
	ldr	w8, [sp, #320]                  ; 4-byte Folded Reload
	str	w8, [sp, #2608]
	ldr	w8, [sp, #228]                  ; 4-byte Folded Reload
	str	w8, [sp, #2612]
	ldr	x8, [sp, #1064]                 ; 8-byte Folded Reload
	str	x8, [sp, #2616]
	ldr	x8, [sp, #1072]                 ; 8-byte Folded Reload
	str	x8, [sp, #2624]
	ldrb	w8, [x14, #2]
	ldrh	w14, [x13]
	strb	w8, [x10, #2]
	ldr	w8, [sp, #2276]
	ldr	w10, [sp, #1420]                ; 4-byte Folded Reload
	strh	w14, [sp, #2750]
	str	w8, [x11]
	ldrh	w8, [sp, #2272]
	str	w10, [sp, #2656]
	strh	w8, [x12]
	ldr	w8, [sp, #368]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2856]
	ldr	w8, [sp, #2264]
	str	w8, [x15]
	ldr	w8, [sp, #1384]                 ; 4-byte Folded Reload
	str	w8, [sp, #2864]
	ldr	w8, [sp, #208]                  ; 4-byte Folded Reload
	str	w8, [sp, #2868]
	ldr	x8, [sp, #1032]                 ; 8-byte Folded Reload
	str	x8, [sp, #2872]
	ldr	x8, [sp, #1040]                 ; 8-byte Folded Reload
	str	x8, [sp, #2880]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	str	x8, [sp, #2888]
	ldr	w8, [sp, #312]                  ; 4-byte Folded Reload
	str	w8, [sp, #2896]
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	str	w8, [sp, #2900]
	ldr	x8, [sp, #1008]                 ; 8-byte Folded Reload
	str	x8, [sp, #2904]
	ldr	x8, [sp, #1016]                 ; 8-byte Folded Reload
	str	x8, [sp, #2912]
	ldr	x8, [sp, #1024]                 ; 8-byte Folded Reload
	str	x8, [sp, #2920]
	ldrb	w8, [sp, #2262]
	strb	w8, [x17, #2]
	ldr	w8, [sp, #1056]                 ; 4-byte Folded Reload
	str	w8, [sp, #2932]
	ldr	w8, [sp, #1060]                 ; 4-byte Folded Reload
	str	w8, [sp, #2936]
	ldr	w8, [sp, #1400]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2640]
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
	str	w8, [sp, #2644]
	ldr	w8, [sp, #1412]                 ; 4-byte Folded Reload
	str	w8, [sp, #2648]
	ldr	w8, [sp, #796]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2652]
	ldr	w8, [sp, #792]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2653]
	ldr	w8, [sp, #784]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2664]
	ldr	w8, [sp, #788]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2665]
	ldr	w8, [sp, #956]                  ; 4-byte Folded Reload
	str	w8, [sp, #2672]
	ldr	w8, [sp, #780]                  ; 4-byte Folded Reload
	str	w8, [sp, #2676]
	ldr	w8, [sp, #776]                  ; 4-byte Folded Reload
	str	w8, [sp, #2708]
	ldr	x8, [sp, #960]                  ; 8-byte Folded Reload
	str	x8, [sp, #2712]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	str	x8, [sp, #2720]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	str	x8, [sp, #2728]
	ldr	w8, [sp, #864]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2736]
	ldr	w8, [sp, #948]                  ; 4-byte Folded Reload
	str	w8, [sp, #2740]
	ldr	w8, [sp, #944]                  ; 4-byte Folded Reload
	str	w8, [sp, #2744]
	ldr	w8, [sp, #856]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2748]
	ldr	w8, [sp, #860]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2749]
	ldr	w8, [sp, #940]                  ; 4-byte Folded Reload
	str	w8, [sp, #2752]
	ldr	w8, [sp, #936]                  ; 4-byte Folded Reload
	str	w8, [sp, #2756]
	ldr	w8, [sp, #848]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2760]
	ldr	w8, [sp, #852]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2761]
	ldr	w8, [sp, #952]                  ; 4-byte Folded Reload
	str	w8, [sp, #2768]
	ldr	w8, [sp, #828]                  ; 4-byte Folded Reload
	str	w8, [sp, #2772]
	ldr	x8, [sp, #928]                  ; 8-byte Folded Reload
	str	x8, [sp, #2776]
	ldr	x8, [sp, #920]                  ; 8-byte Folded Reload
	str	x8, [sp, #2784]
	ldr	x8, [sp, #912]                  ; 8-byte Folded Reload
	str	x8, [sp, #2792]
	ldr	w8, [sp, #832]                  ; 4-byte Folded Reload
	str	w8, [sp, #2800]
	ldr	w8, [sp, #824]                  ; 4-byte Folded Reload
	str	w8, [sp, #2804]
	ldr	x8, [sp, #904]                  ; 8-byte Folded Reload
	str	x8, [sp, #2808]
	ldr	x8, [sp, #896]                  ; 8-byte Folded Reload
	str	x8, [sp, #2816]
	ldr	x8, [sp, #880]                  ; 8-byte Folded Reload
	str	x8, [sp, #2824]
	ldr	w8, [sp, #844]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2832]
	ldr	w8, [sp, #892]                  ; 4-byte Folded Reload
	str	w8, [sp, #2836]
	ldr	w8, [sp, #876]                  ; 4-byte Folded Reload
	str	w8, [sp, #2840]
	ldr	w8, [sp, #840]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2844]
	ldr	w8, [sp, #836]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2845]
	ldr	w8, [sp, #872]                  ; 4-byte Folded Reload
	str	w8, [sp, #2848]
	ldr	w8, [sp, #868]                  ; 4-byte Folded Reload
	str	w8, [sp, #2852]
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	ldrh	w8, [x8]
	strh	w8, [sp, #2942]
	ldr	w8, [sp, #1296]                 ; 4-byte Folded Reload
	str	w8, [sp, #2944]
	ldr	w8, [sp, #268]                  ; 4-byte Folded Reload
	str	w8, [sp, #2948]
	ldr	w8, [sp, #392]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2952]
	ldrh	w8, [sp, #2256]
	strh	w8, [x0, #4]
	ldr	w8, [sp, #1396]                 ; 4-byte Folded Reload
	str	w8, [sp, #2960]
	ldr	w8, [sp, #216]                  ; 4-byte Folded Reload
	str	w8, [sp, #2964]
	ldr	x8, [sp, #1216]                 ; 8-byte Folded Reload
	str	x8, [sp, #2968]
	ldr	x8, [sp, #1224]                 ; 8-byte Folded Reload
	str	x8, [sp, #2976]
	ldr	x8, [sp, #1232]                 ; 8-byte Folded Reload
	str	x8, [sp, #2984]
	ldr	w8, [sp, #316]                  ; 4-byte Folded Reload
	str	w8, [sp, #2992]
	ldr	w8, [sp, #220]                  ; 4-byte Folded Reload
	str	w8, [sp, #2996]
	ldr	x8, [sp, #1192]                 ; 8-byte Folded Reload
	str	x8, [sp, #3000]
	ldr	x8, [sp, #1200]                 ; 8-byte Folded Reload
	str	x8, [sp, #3008]
	ldr	x8, [sp, #1256]                 ; 8-byte Folded Reload
	str	x8, [sp, #3016]
	ldrb	w8, [sp, #2250]
	strb	w8, [x3, #2]
	ldr	w8, [sp, #1280]                 ; 4-byte Folded Reload
	str	w8, [sp, #3028]
	ldr	w8, [sp, #1284]                 ; 4-byte Folded Reload
	str	w8, [sp, #3032]
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	ldrh	w8, [x8]
	strh	w8, [sp, #3038]
	ldr	w8, [sp, #1288]                 ; 4-byte Folded Reload
	str	w8, [sp, #3040]
	ldr	w8, [sp, #264]                  ; 4-byte Folded Reload
	str	w8, [sp, #3044]
	ldr	w8, [sp, #968]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3048]
	ldrh	w8, [sp, #2244]
	strh	w8, [x4, #4]
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	cbz	w8, LBB37_45
; %bb.99:                               ; %v132_ok.i.i.i.preheader
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	x13, [sp, #680]                 ; 8-byte Folded Reload
	ldr	x6, [sp, #672]                  ; 8-byte Folded Reload
	mov	x7, xzr
	ldr	x9, [sp, #736]                  ; 8-byte Folded Reload
	ldr	x16, [sp, #728]                 ; 8-byte Folded Reload
	ldr	x1, [sp, #720]                  ; 8-byte Folded Reload
	ldr	x28, [sp, #712]                 ; 8-byte Folded Reload
	str	wzr, [sp, #1396]                ; 4-byte Folded Spill
	str	xzr, [sp, #1384]                ; 8-byte Folded Spill
LBB37_100:                              ; %v132_ok.i.i.i
                                        ;   Parent Loop BB37_47 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, sp, #2288
	str	x7, [sp, #1456]                 ; 8-byte Folded Spill
	add	x8, x8, x7
	ldr	w20, [x8]
	cmp	w20, #1
	b.ne	LBB37_102
; %bb.101:                              ; %b66_to_b274.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #2292]
	ldr	d1, [sp, #2320]
	mov	x7, x15
	ldr	x5, [sp, #2312]
	ldr	q29, [x9]
	mov	x2, x4
	str	w8, [sp, #1360]                 ; 4-byte Folded Spill
	add	x8, sp, #2288
	ldrb	w9, [sp, #3024]
	ldur	q0, [x8, #8]
	str	d1, [sp, #1368]                 ; 8-byte Folded Spill
	add	x15, sp, #2288
	ldur	q1, [x8, #40]
	ldur	d2, [x8, #68]
	ldur	q5, [x8, #104]
	ldur	q7, [x8, #136]
	ldur	d16, [x8, #164]
	ldur	q19, [x8, #200]
	ldur	q21, [x8, #232]
	ldr	x8, [sp, #2536]
	str	x5, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	x5, [sp, #2344]
	str	w9, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #3036]
	str	x8, [sp, #1240]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2544]
	ldr	d3, [sp, #2368]
	str	x5, [sp, #1344]                 ; 8-byte Folded Spill
	ldrb	w5, [sp, #2352]
	ldr	d4, [sp, #2384]
	str	w8, [sp, #1248]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2556]
	ldr	d6, [sp, #2416]
	str	w5, [sp, #1336]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2364]
	ldr	d17, [sp, #2464]
	str	w8, [sp, #1232]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2557]
	ldr	d18, [sp, #2480]
	str	w5, [sp, #1328]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2365]
	ldr	d20, [sp, #2512]
	str	w8, [sp, #1024]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2558]
	ldr	d23, [sp, #2560]
	str	w5, [sp, #1320]                 ; 4-byte Folded Spill
	ldrh	w5, [sp, #2366]
	ldr	d24, [sp, #2576]
	str	w8, [sp, #1200]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2568]
	ldr	d26, [sp, #2608]
	str	w5, [sp, #1312]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2376]
	ldr	d28, [sp, #2864]
	str	w8, [sp, #1216]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2569]
	ldr	d30, [sp, #2896]
	str	w5, [sp, #1308]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2377]
	ldr	q31, [x16]
	mov	x16, x13
	str	w8, [sp, #1224]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2600]
	str	w5, [sp, #1304]                 ; 4-byte Folded Spill
	ldr	x5, [sp, #2408]
	ldr	d9, [sp, #2944]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	ldr	d10, [sp, #2960]
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	add	x8, sp, #2288
	ldr	q11, [x1]
	mov	x1, x25
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2632]
	str	x5, [sp, #1296]                 ; 8-byte Folded Spill
	ldr	x5, [sp, #2440]
	ldr	d12, [sp, #2992]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2640]
	ldr	q13, [x28]
	mov	x28, x3
	str	x5, [sp, #1288]                 ; 8-byte Folded Spill
	ldrb	w5, [sp, #2448]
	str	w8, [sp, #1400]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2644]
	ldr	d15, [sp, #3040]
	str	w5, [sp, #1284]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2460]
	str	w8, [sp, #1452]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2648]
	str	w5, [sp, #1280]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2461]
	str	w8, [sp, #1412]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2856]
	str	w5, [sp, #1276]                 ; 4-byte Folded Spill
	ldrh	w5, [sp, #2462]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2857]
	str	w5, [sp, #1272]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2472]
	str	w8, [sp, #1096]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2888]
	str	w9, [sp, #1128]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #3037]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2920]
	str	w5, [sp, #1268]                 ; 4-byte Folded Spill
	ldrb	w5, [sp, #2473]
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2928]
	str	w9, [sp, #1112]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #3038]
	str	w8, [sp, #1080]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2940]
	str	w5, [sp, #1264]                 ; 4-byte Folded Spill
	ldr	x5, [sp, #2504]
	str	w8, [sp, #1056]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2941]
	str	w9, [sp, #1072]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #3048]
	str	w8, [sp, #1060]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2942]
	str	w23, [sp, #1448]                ; 4-byte Folded Spill
	ldr	x23, [sp, #704]                 ; 8-byte Folded Reload
	str	w8, [sp, #1048]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2952]
	str	x5, [sp, #1256]                 ; 8-byte Folded Spill
	ldr	x5, [sp, #752]                  ; 8-byte Folded Reload
	ldr	d22, [x23]
	str	w8, [sp, #1088]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2953]
	ldur	q25, [x23, #36]
	mov	x20, x5
	str	x26, [sp, #1424]                ; 8-byte Folded Spill
	ldr	x26, [sp, #744]                 ; 8-byte Folded Reload
	str	w8, [sp, #1064]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2984]
	ldur	q27, [x23, #68]
	str	x24, [sp, #1440]                ; 8-byte Folded Spill
	ldr	x24, [sp, #760]                 ; 8-byte Folded Reload
	ldr	d8, [x23, #384]
	str	w22, [sp, #1416]                ; 4-byte Folded Spill
	ldr	x22, [sp, #768]                 ; 8-byte Folded Reload
	ldr	d14, [x23, #480]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3016]
	str	w9, [sp, #1120]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #3049]
	str	w30, [sp, #1032]                ; 4-byte Folded Spill
	ldr	w30, [sp, #1412]                ; 4-byte Folded Reload
	str	x27, [sp, #1432]                ; 8-byte Folded Spill
	mov	x27, x21
	str	x21, [sp, #968]                 ; 8-byte Folded Spill
	mov	x21, x11
	str	x19, [sp, #976]                 ; 8-byte Folded Spill
	str	x25, [sp, #984]                 ; 8-byte Folded Spill
	mov	x25, x7
	str	x24, [sp, #992]                 ; 8-byte Folded Spill
	str	x13, [sp, #1000]                ; 8-byte Folded Spill
	mov	x13, x26
	str	x22, [sp, #1008]                ; 8-byte Folded Spill
	str	x6, [sp, #1016]                 ; 8-byte Folded Spill
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	mov	x8, x12
	str	w9, [sp, #1136]                 ; 4-byte Folded Spill
	mov	x9, x0
	str	w10, [sp, #1420]                ; 4-byte Folded Spill
	mov	x10, x17
	str	w14, [sp, #1164]                ; 4-byte Folded Spill
	b	LBB37_339
LBB37_102:                              ; %b67.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldp	w26, w9, [x8, #68]
	ldp	x27, x2, [x8, #8]
	ldr	w10, [x8, #32]
	ldp	x22, x24, [x8, #40]
	ldr	x28, [x8, #24]
	cmp	w10, #1
	str	w9, [sp, #1440]                 ; 4-byte Folded Spill
	ldrb	w9, [x8, #76]
	ldr	x11, [x8, #56]
	ldrb	w21, [x8, #64]
	ldrb	w19, [x8, #88]
	str	w9, [sp, #1452]                 ; 4-byte Folded Spill
	ldrb	w9, [x8, #77]
	ldr	x25, [sp, #688]                 ; 8-byte Folded Reload
	str	w19, [sp, #1416]                ; 4-byte Folded Spill
	str	w9, [sp, #1448]                 ; 4-byte Folded Spill
	ldr	w9, [x8, #80]
	str	w9, [sp, #1432]                 ; 4-byte Folded Spill
	ldr	w9, [x8, #84]
	ldrb	w8, [x8, #89]
	str	w9, [sp, #1424]                 ; 4-byte Folded Spill
	str	w8, [sp, #1420]                 ; 4-byte Folded Spill
	b.ne	LBB37_104
; %bb.103:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #3                          ; =0x3
	str	wzr, [sp, #1380]                ; 4-byte Folded Spill
	mov	x23, x22
	str	w8, [sp, #700]                  ; 4-byte Folded Spill
	mov	x22, x2
	mov	w25, w10
	str	w26, [sp, #1412]                ; 4-byte Folded Spill
	mov	w26, w21
	mov	x21, x11
	b	LBB37_338
LBB37_104:                              ; %b70.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	x0, x25
	mov	x1, x27
	mov	x3, x28
	str	x11, [sp, #1400]                ; 8-byte Folded Spill
	mov	w23, w10
	str	w20, [sp, #1352]                ; 4-byte Folded Spill
	str	x27, [sp, #1360]                ; 8-byte Folded Spill
	mov	x27, x2
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	str	w21, [sp, #1368]                ; 4-byte Folded Spill
	cbnz	x8, LBB37_106
; %bb.105:                              ; %b1.i.i199.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	x20, x0
	mov	w21, wzr
	b	LBB37_109
LBB37_106:                              ; %v8_ok.i.i181.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB37_108
; %bb.107:                              ; %v8_ok.i.i181.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh162:
	adrp	x11, lJTI37_5@PAGE
Lloh163:
	add	x11, x11, lJTI37_5@PAGEOFF
	adr	x9, LBB37_108
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB37_108:                              ; %liza___liza_reactor_error.exit.i.i185.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w20, wzr
	mov	w21, #1                         ; =0x1
LBB37_109:                              ; %liza_net.reactor_ready.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w21, #1
	mov	w8, #3                          ; =0x3
	ldr	x3, [sp, #1400]                 ; 8-byte Folded Reload
	csel	w8, wzr, w8, ne
	mov	x0, x25
	mov	x1, x22
	mov	x2, x24
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	cbnz	x8, LBB37_112
; %bb.110:                              ; %b1.i.i225.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	x2, x27
	cmp	w8, #1
	b.ne	LBB37_115
LBB37_111:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w19, #3                         ; =0x3
	mov	x23, x24
	b	LBB37_326
LBB37_112:                              ; %v8_ok.i.i207.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w8, w8, #1
	mov	x2, x27
	cmp	w8, #11
	b.hi	LBB37_114
; %bb.113:                              ; %v8_ok.i.i207.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh164:
	adrp	x11, lJTI37_6@PAGE
Lloh165:
	add	x11, x11, lJTI37_6@PAGEOFF
	adr	x9, LBB37_114
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB37_114:                              ; %liza___liza_reactor_error.exit.i.i211.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
	cmp	w8, #1
	b.eq	LBB37_111
LBB37_115:                              ; %b78.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w21, #1
	ldr	w9, [sp, #1368]                 ; 4-byte Folded Reload
	str	x0, [sp, #1336]                 ; 8-byte Folded Spill
	cset	w8, eq
	str	w23, [sp, #1344]                ; 4-byte Folded Spill
	orr	w8, w8, w9
	tbz	w8, #0, LBB37_118
; %bb.116:                              ; %b91.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w13, w26
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w27, [sp, #1424]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1448]                ; 4-byte Folded Reload
	cmp	w21, #1
	mov	x23, x24
	b.ne	LBB37_137
LBB37_117:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w19, #3                         ; =0x3
	b	LBB37_326
LBB37_118:                              ; %b82.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x3, [sp, #1400]                 ; 8-byte Folded Reload
	mov	x0, x25
	mov	x1, x22
	mov	x2, x24
	bl	_liza_rt_reactor_finish_connect
	lsr	x8, x0, #32
	cbnz	x8, LBB37_120
; %bb.119:                              ; %b1.i247.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	x0, #1
	mov	w10, wzr
	cset	w9, eq
	b	LBB37_134
LBB37_120:                              ; %v10_ok.i.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB37_132
; %bb.121:                              ; %v10_ok.i.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh166:
	adrp	x12, lJTI37_7@PAGE
Lloh167:
	add	x12, x12, lJTI37_7@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB37_122
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_122:                              ; %b4.i.i245.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB37_133
LBB37_123:                              ; %b34.i.i240.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB37_133
LBB37_124:                              ; %b13.i.i242.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB37_133
LBB37_125:                              ; %b16.i.i241.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB37_133
LBB37_126:                              ; %b10.i.i243.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB37_133
LBB37_127:                              ; %b7.i.i244.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB37_133
LBB37_128:                              ; %b22.i.i239.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB37_133
LBB37_129:                              ; %b25.i.i238.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB37_133
LBB37_130:                              ; %b31.i.i233.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB37_133
LBB37_131:                              ; %b28.i.i237.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB37_133
LBB37_132:                              ; %b36.i.i246.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #6                          ; =0x6
LBB37_133:                              ; %liza___liza_reactor_error.exit.i234.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	mov	w10, #1                         ; =0x1
LBB37_134:                              ; %liza_net.reactor_finish_connect.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w13, w26
	ldr	w14, [sp, #1448]                ; 4-byte Folded Reload
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	cmp	w10, #1
	mov	x2, x27
	b.ne	LBB37_136
; %bb.135:                              ; %b85.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	ldr	w27, [sp, #1424]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w19, #3                         ; =0x3
	mov	x23, x24
	tst	w8, w9
	b.ne	LBB37_326
	b	LBB37_137
LBB37_136:                              ; %b89.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	ldr	w27, [sp, #1424]                ; 4-byte Folded Reload
	and	w8, w9, #0x1
	mov	x23, x24
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
LBB37_137:                              ; %b95.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w13, w26
	b.hi	LBB37_141
; %bb.138:                              ; %b95.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, #2048
	b.hi	LBB37_141
; %bb.139:                              ; %b4.i.i257.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w13, w26
	cset	w8, eq
	tbz	w14, #0, LBB37_150
; %bb.140:                              ; %b4.i.i257.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	and	w8, w11, w8
	cbnz	w8, LBB37_150
LBB37_141:                              ; %b114.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w19, [sp, #1368]                ; 4-byte Folded Reload
	tbz	w19, #0, LBB37_190
; %bb.142:                              ; %b118.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w13, w26
	b.hi	LBB37_190
; %bb.143:                              ; %b118.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, #2048
	b.hi	LBB37_190
; %bb.144:                              ; %b118.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	tbnz	w14, #0, LBB37_190
; %bb.145:                              ; %b118.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, w13
	b.eq	LBB37_190
; %bb.146:                              ; %v253_ok.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1396]                 ; 4-byte Folded Reload
	str	x28, [sp, #1424]                ; 8-byte Folded Spill
	adds	w6, w8, w13
	b.hs	LBB37_346
; %bb.147:                              ; %b3.i325.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	subs	w20, w26, w13
	str	w11, [sp, #1452]                ; 4-byte Folded Spill
	str	w13, [sp, #1412]                ; 4-byte Folded Spill
	b.lo	LBB37_346
; %bb.148:                              ; %liza_relay.direction.queued.exit330.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x3, [sp, #1400]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #160]                  ; 8-byte Folded Reload
	mov	w28, w27
	mov	x27, x2
	mov	x0, x25
	mov	x1, x22
	mov	x2, x23
	mov	w5, #32768                      ; =0x8000
	mov	w7, w20
	mov	w21, w14
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	cbnz	x8, LBB37_156
; %bb.149:                              ; %b1.i.i354.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	b	LBB37_178
LBB37_150:                              ; %liza_relay.direction.readable.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, #2048
	b.eq	LBB37_141
; %bb.151:                              ; %liza_relay.direction.readable.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	eor	w8, w11, #0x1
	tbz	w8, #0, LBB37_141
; %bb.152:                              ; %liza_relay.direction.readable.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w21, #1
	b.eq	LBB37_141
; %bb.153:                              ; %liza_relay.direction.readable.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #5                          ; =0x5
	and	w8, w20, w8
	cbz	w8, LBB37_141
; %bb.154:                              ; %b4.i.i266.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #2048                       ; =0x800
	tst	w11, #0x1
	ldr	x1, [sp, #1360]                 ; 8-byte Folded Reload
	sub	w19, w8, w26
	ldr	w8, [sp, #1396]                 ; 4-byte Folded Reload
	ldr	x4, [sp, #160]                  ; 8-byte Folded Reload
	csel	w7, wzr, w19, ne
	mov	x0, x25
	mov	x3, x28
	add	w6, w26, w8
	mov	w5, #32768                      ; =0x8000
	mov	w21, w14
	str	w13, [sp, #1412]                ; 4-byte Folded Spill
	mov	w20, w11
	str	x2, [sp, #1328]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB37_159
; %bb.155:                              ; %b104.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	ldr	x2, [sp, #1328]                 ; 8-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w19, #3                         ; =0x3
	mov	w14, w21
	mov	w11, w20
	tst	w8, w9
	b.ne	LBB37_326
	b	LBB37_141
LBB37_156:                              ; %v8_ok.i.i336.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB37_176
; %bb.157:                              ; %v8_ok.i.i336.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh168:
	adrp	x12, lJTI37_8@PAGE
Lloh169:
	add	x12, x12, lJTI37_8@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB37_158
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_158:                              ; %b4.i.i.i352.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB37_177
LBB37_159:                              ; %b1.i295.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w1, wzr
	orr	w8, w21, w20
	mov	w9, #1                          ; =0x1
	tbnz	w8, #0, LBB37_163
; %bb.160:                              ; %b1.i295.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w12, [sp, #1368]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1420]                ; 4-byte Folded Reload
	cmp	w19, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	b.lo	LBB37_165
; %bb.161:                              ; %b12.i.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	cbz	w0, LBB37_164
; %bb.162:                              ; %v26_ok.i.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w1, [sp, #1412]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w26, w0
	b	LBB37_165
LBB37_163:                              ;   in Loop: Header=BB37_100 Depth=2
	ldr	w12, [sp, #1368]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1420]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	b	LBB37_165
LBB37_164:                              ; %b13.i.i21.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w1, [sp, #1412]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	mov	w8, w26
LBB37_165:                              ; %liza_relay.direction.read.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w9, #1
	b.eq	LBB37_325
; %bb.166:                              ; %b111.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w9, [sp, #1416]                 ; 4-byte Folded Reload
	and	w13, w13, #0x1
	ldr	x2, [sp, #1328]                 ; 8-byte Folded Reload
	and	w11, w11, #0x1
	and	w14, w10, #0x1
	and	w12, w12, #0x1
	and	w9, w9, #0x1
	str	w13, [sp, #1420]                ; 4-byte Folded Spill
	mov	w13, w1
	mov	w26, w8
	str	w12, [sp, #1368]                ; 4-byte Folded Spill
	str	w9, [sp, #1416]                 ; 4-byte Folded Spill
	b	LBB37_141
LBB37_167:                              ; %b34.i.i.i347.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB37_177
LBB37_168:                              ; %b13.i.i.i349.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB37_177
LBB37_169:                              ; %b16.i.i.i348.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB37_177
LBB37_170:                              ; %b10.i.i.i350.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB37_177
LBB37_171:                              ; %b7.i.i.i351.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB37_177
LBB37_172:                              ; %b22.i.i.i346.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB37_177
LBB37_173:                              ; %b25.i.i.i345.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB37_177
LBB37_174:                              ; %b31.i.i.i339.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB37_177
LBB37_175:                              ; %b28.i.i.i344.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB37_177
LBB37_176:                              ; %b36.i.i.i353.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #6                          ; =0x6
LBB37_177:                              ; %liza___liza_reactor_error.exit.i.i340.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB37_178:                              ; %liza_net.reactor_write.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w14, w21
	cmp	w9, #1
	mov	x2, x27
	b.ne	LBB37_180
; %bb.179:                              ; %b124.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w27, w28
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	mov	w19, #3                         ; =0x3
	tst	w8, w9
	b.ne	LBB37_326
	b	LBB37_190
LBB37_180:                              ; %b4.i.i368.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w27, w28
	cbz	w0, LBB37_183
; %bb.181:                              ; %liza_relay.direction.queued.exit.i.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	cmp	w0, w20
	b.ls	LBB37_185
; %bb.182:                              ;   in Loop: Header=BB37_100 Depth=2
	ldr	w10, [sp, #1416]                ; 4-byte Folded Reload
	b	LBB37_184
LBB37_183:                              ;   in Loop: Header=BB37_100 Depth=2
	ldr	w10, [sp, #1416]                ; 4-byte Folded Reload
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
LBB37_184:                              ; %liza_relay.direction.write.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w13, wzr
	mov	w26, wzr
	mov	w11, wzr
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB37_117
	b	LBB37_189
LBB37_185:                              ; %b9.i.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w1, [sp, #1412]                 ; 4-byte Folded Reload
	adds	w13, w1, w0
	b.hs	LBB37_346
; %bb.186:                              ; %v13_ok.i.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w10, [sp, #1416]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	cmp	w13, w26
	mov	w9, wzr
	b.ne	LBB37_188
; %bb.187:                              ; %b10.i.i19.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w13, wzr
	mov	w26, wzr
LBB37_188:                              ; %liza_relay.direction.write.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB37_117
LBB37_189:                              ; %b131.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	and	w14, w8, #0x1
	ldr	w8, [sp, #1420]                 ; 4-byte Folded Reload
	and	w11, w11, #0x1
	and	w19, w19, #0x1
	and	w10, w10, #0x1
	and	w8, w8, #0x1
	str	w19, [sp, #1368]                ; 4-byte Folded Spill
	str	w10, [sp, #1416]                ; 4-byte Folded Spill
	str	w8, [sp, #1420]                 ; 4-byte Folded Spill
LBB37_190:                              ; %b134.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w19, [sp, #1368]                ; 4-byte Folded Reload
	tbz	w19, #0, LBB37_215
; %bb.191:                              ; %b138.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w13, w26
	b.hi	LBB37_215
; %bb.192:                              ; %b138.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, #2048
	b.hi	LBB37_215
; %bb.193:                              ; %b4.i.i385.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	tbnz	w14, #0, LBB37_215
; %bb.194:                              ; %b4.i.i385.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	tbz	w11, #0, LBB37_215
; %bb.195:                              ; %b4.i.i385.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w13, w26
	b.ne	LBB37_215
; %bb.196:                              ; %b141.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x3, [sp, #1400]                 ; 8-byte Folded Reload
	str	x2, [sp, #1328]                 ; 8-byte Folded Spill
	mov	x0, x25
	mov	x1, x22
	mov	x2, x23
	str	w11, [sp, #1452]                ; 4-byte Folded Spill
	mov	w21, w14
	mov	w20, w13
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB37_198
; %bb.197:                              ; %b1.i.i414.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	b	LBB37_212
LBB37_198:                              ; %v8_ok.i.i396.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB37_210
; %bb.199:                              ; %v8_ok.i.i396.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh170:
	adrp	x12, lJTI37_9@PAGE
Lloh171:
	add	x12, x12, lJTI37_9@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB37_200
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_200:                              ; %b4.i.i.i412.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB37_211
LBB37_201:                              ; %b34.i.i.i407.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB37_211
LBB37_202:                              ; %b13.i.i.i409.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB37_211
LBB37_203:                              ; %b16.i.i.i408.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB37_211
LBB37_204:                              ; %b10.i.i.i410.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB37_211
LBB37_205:                              ; %b7.i.i.i411.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB37_211
LBB37_206:                              ; %b22.i.i.i406.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB37_211
LBB37_207:                              ; %b25.i.i.i405.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB37_211
LBB37_208:                              ; %b31.i.i.i399.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB37_211
LBB37_209:                              ; %b28.i.i.i404.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB37_211
LBB37_210:                              ; %b36.i.i.i413.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #6                          ; =0x6
LBB37_211:                              ; %liza___liza_reactor_error.exit.i.i400.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
LBB37_212:                              ; %liza_net.reactor_shutdown_write.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	ldr	x2, [sp, #1328]                 ; 8-byte Folded Reload
	mov	w13, w20
	mov	w14, w21
	cmp	w9, #1
	b.ne	LBB37_214
; %bb.213:                              ; %b144.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w19, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB37_326
	b	LBB37_215
LBB37_214:                              ; %b151.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	and	w19, w19, #0x1
	mov	w11, #1                         ; =0x1
	mov	w26, w13
	mov	w14, #1                         ; =0x1
	str	w19, [sp, #1368]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1420]                 ; 4-byte Folded Reload
	and	w8, w8, #0x1
	str	w8, [sp, #1420]                 ; 4-byte Folded Spill
LBB37_215:                              ; %b154.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w20, [sp, #1368]                ; 4-byte Folded Reload
	tbz	w20, #0, LBB37_220
; %bb.216:                              ; %b158.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	cmp	w8, w27
	b.hi	LBB37_220
; %bb.217:                              ; %b158.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w27, #2048
	b.hi	LBB37_220
; %bb.218:                              ; %b4.i.i435.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	ldr	w9, [sp, #1416]                 ; 4-byte Folded Reload
	ldr	w10, [sp, #1420]                ; 4-byte Folded Reload
	cmp	w8, w27
	cset	w8, eq
	tbz	w10, #0, LBB37_229
; %bb.219:                              ; %b4.i.i435.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	and	w8, w9, w8
	cbnz	w8, LBB37_229
LBB37_220:                              ; %b177.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w19, [sp, #1368]                ; 4-byte Folded Reload
	tbz	w19, #0, LBB37_263
; %bb.221:                              ; %b181.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	cmp	w8, w27
	b.hi	LBB37_263
; %bb.222:                              ; %b181.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w27, #2048
	b.hi	LBB37_263
; %bb.223:                              ; %b181.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1420]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB37_263
; %bb.224:                              ; %b181.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w9, [sp, #1432]                 ; 4-byte Folded Reload
	cmp	w27, w9
	b.eq	LBB37_263
; %bb.225:                              ; %v393_ok.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1396]                 ; 4-byte Folded Reload
	str	x28, [sp, #1424]                ; 8-byte Folded Spill
	add	w8, w8, #2048
	adds	w6, w8, w9
	b.hs	LBB37_346
; %bb.226:                              ; %b3.i550.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w28, w27
	subs	w20, w27, w9
	str	w11, [sp, #1452]                ; 4-byte Folded Spill
	str	w13, [sp, #1412]                ; 4-byte Folded Spill
	b.lo	LBB37_346
; %bb.227:                              ; %liza_relay.direction.queued.exit555.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x1, [sp, #1360]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1424]                 ; 8-byte Folded Reload
	mov	x0, x25
	ldr	x4, [sp, #160]                  ; 8-byte Folded Reload
	mov	w5, #32768                      ; =0x8000
	mov	w7, w20
	mov	w21, w14
	mov	w27, w26
	mov	x26, x2
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	cbnz	x8, LBB37_234
; %bb.228:                              ; %b1.i.i581.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	b	LBB37_252
LBB37_229:                              ; %liza_relay.direction.readable.exit445.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w27, #2048
	b.eq	LBB37_220
; %bb.230:                              ; %liza_relay.direction.readable.exit445.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	eor	w8, w9, #0x1
	tbz	w8, #0, LBB37_220
; %bb.231:                              ; %liza_relay.direction.readable.exit445.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x9, [sp, #1336]                 ; 8-byte Folded Reload
	mov	w8, #5                          ; =0x5
	and	w8, w9, w8
	cbz	w8, LBB37_220
; %bb.232:                              ; %b4.i.i452.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #2048                       ; =0x800
	mov	w9, w27
	ldr	x3, [sp, #1400]                 ; 8-byte Folded Reload
	sub	w19, w8, w27
	ldr	w27, [sp, #1416]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1396]                 ; 4-byte Folded Reload
	ldr	x4, [sp, #160]                  ; 8-byte Folded Reload
	mov	x1, x22
	mov	x22, x2
	tst	w27, #0x1
	add	w8, w9, w8
	mov	x0, x25
	csel	w7, wzr, w19, ne
	add	w6, w8, #2048
	mov	x2, x23
	mov	w5, #32768                      ; =0x8000
	str	w14, [sp, #1448]                ; 4-byte Folded Spill
	mov	w21, w11
	str	x28, [sp, #1424]                ; 8-byte Folded Spill
	mov	w28, w9
	mov	x23, x1
	str	w26, [sp, #1440]                ; 4-byte Folded Spill
	mov	x24, x2
	str	w13, [sp, #1412]                ; 4-byte Folded Spill
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB37_237
; %bb.233:                              ; %b167.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1448]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	mov	w27, w28
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	mov	w19, #3                         ; =0x3
	mov	x2, x22
	mov	w11, w21
	tst	w8, w9
	mov	x22, x23
	mov	x23, x24
	b.ne	LBB37_326
	b	LBB37_220
LBB37_234:                              ; %v8_ok.i.i563.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB37_250
; %bb.235:                              ; %v8_ok.i.i563.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh172:
	adrp	x12, lJTI37_10@PAGE
Lloh173:
	add	x12, x12, lJTI37_10@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB37_236
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_236:                              ; %b4.i.i.i579.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB37_251
LBB37_237:                              ; %b1.i496.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1420]                 ; 4-byte Folded Reload
	mov	w1, wzr
	mov	w9, #1                          ; =0x1
	orr	w8, w8, w27
	tbnz	w8, #0, LBB37_274
; %bb.238:                              ; %b1.i496.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1448]                ; 4-byte Folded Reload
	cmp	w19, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	x2, x22
	mov	x22, x23
	mov	x23, x24
	b.lo	LBB37_276
; %bb.239:                              ; %b12.i502.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	cbz	w0, LBB37_275
; %bb.240:                              ; %v26_ok.i504.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w1, [sp, #1432]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w28, w0
	b	LBB37_276
LBB37_241:                              ; %b34.i.i.i574.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB37_251
LBB37_242:                              ; %b13.i.i.i576.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB37_251
LBB37_243:                              ; %b16.i.i.i575.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB37_251
LBB37_244:                              ; %b10.i.i.i577.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB37_251
LBB37_245:                              ; %b7.i.i.i578.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB37_251
LBB37_246:                              ; %b22.i.i.i573.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB37_251
LBB37_247:                              ; %b25.i.i.i572.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB37_251
LBB37_248:                              ; %b31.i.i.i566.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB37_251
LBB37_249:                              ; %b28.i.i.i571.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB37_251
LBB37_250:                              ; %b36.i.i.i580.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #6                          ; =0x6
LBB37_251:                              ; %liza___liza_reactor_error.exit.i.i567.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB37_252:                              ; %liza_net.reactor_write.exit584.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w14, w21
	cmp	w9, #1
	mov	x2, x26
	b.ne	LBB37_254
; %bb.253:                              ; %b187.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w26, w27
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w27, w28
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	mov	w19, #3                         ; =0x3
	tst	w8, w9
	b.ne	LBB37_326
	b	LBB37_263
LBB37_254:                              ; %b4.i.i596.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w26, w27
	cbz	w0, LBB37_256
; %bb.255:                              ; %liza_relay.direction.queued.exit.i611.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w0, w20
	b.ls	LBB37_257
LBB37_256:                              ;   in Loop: Header=BB37_100 Depth=2
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	mov	w27, wzr
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	str	wzr, [sp, #1432]                ; 4-byte Folded Spill
	mov	w8, wzr
	str	wzr, [sp, #1416]                ; 4-byte Folded Spill
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB37_117
	b	LBB37_262
LBB37_257:                              ; %b9.i614.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	adds	w8, w8, w0
	b.hs	LBB37_346
; %bb.258:                              ; %v13_ok.i618.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	cmp	w8, w28
	str	w8, [sp, #1432]                 ; 4-byte Folded Spill
	b.ne	LBB37_260
; %bb.259:                              ; %b10.i626.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	str	wzr, [sp, #1432]                ; 4-byte Folded Spill
	mov	w27, wzr
	b	LBB37_261
LBB37_260:                              ; %b12.i620.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w27, w28
	mov	w9, wzr
LBB37_261:                              ; %liza_relay.direction.write.exit636.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB37_117
LBB37_262:                              ; %b194.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w9, [sp, #1416]                 ; 4-byte Folded Reload
	and	w8, w8, #0x1
	and	w19, w19, #0x1
	and	w11, w11, #0x1
	and	w14, w14, #0x1
	str	w8, [sp, #1420]                 ; 4-byte Folded Spill
	and	w9, w9, #0x1
	str	w19, [sp, #1368]                ; 4-byte Folded Spill
	str	w9, [sp, #1416]                 ; 4-byte Folded Spill
LBB37_263:                              ; %b197.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w19, [sp, #1368]                ; 4-byte Folded Reload
	tbz	w19, #0, LBB37_293
; %bb.264:                              ; %b201.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	cmp	w8, w27
	b.hi	LBB37_293
; %bb.265:                              ; %b201.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w27, #2048
	b.hi	LBB37_293
; %bb.266:                              ; %b4.i.i644.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1420]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB37_293
; %bb.267:                              ; %b4.i.i644.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB37_293
; %bb.268:                              ; %b4.i.i644.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	cmp	w8, w27
	b.ne	LBB37_293
; %bb.269:                              ; %b204.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x1, [sp, #1360]                 ; 8-byte Folded Reload
	mov	x0, x25
	mov	x3, x28
	str	w11, [sp, #1452]                ; 4-byte Folded Spill
	mov	w21, w14
	mov	w20, w13
	str	x2, [sp, #1328]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB37_271
; %bb.270:                              ; %b1.i.i678.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, wzr
	b	LBB37_290
LBB37_271:                              ; %v8_ok.i.i660.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB37_288
; %bb.272:                              ; %v8_ok.i.i660.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh174:
	adrp	x12, lJTI37_11@PAGE
Lloh175:
	add	x12, x12, lJTI37_11@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB37_273
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB37_273:                              ; %b4.i.i.i676.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB37_289
LBB37_274:                              ;   in Loop: Header=BB37_100 Depth=2
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1448]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	x2, x22
	mov	x22, x23
	mov	x23, x24
	b	LBB37_276
LBB37_275:                              ; %b13.i511.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w1, [sp, #1432]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	mov	w8, w28
LBB37_276:                              ; %liza_relay.direction.read.exit517.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w9, #1
	b.ne	LBB37_278
; %bb.277:                              ;   in Loop: Header=BB37_100 Depth=2
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	mov	w19, #3                         ; =0x3
	b	LBB37_326
LBB37_278:                              ; %b174.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	and	w9, w11, #0x1
	ldr	w13, [sp, #1412]                ; 4-byte Folded Reload
	ldr	x28, [sp, #1424]                ; 8-byte Folded Reload
	str	w9, [sp, #1416]                 ; 4-byte Folded Spill
	and	w9, w10, #0x1
	and	w20, w20, #0x1
	and	w11, w21, #0x1
	and	w14, w14, #0x1
	mov	w27, w8
	str	w9, [sp, #1420]                 ; 4-byte Folded Spill
	str	w20, [sp, #1368]                ; 4-byte Folded Spill
	str	w1, [sp, #1432]                 ; 4-byte Folded Spill
	b	LBB37_220
LBB37_279:                              ; %b34.i.i.i671.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB37_289
LBB37_280:                              ; %b13.i.i.i673.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB37_289
LBB37_281:                              ; %b16.i.i.i672.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB37_289
LBB37_282:                              ; %b10.i.i.i674.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB37_289
LBB37_283:                              ; %b7.i.i.i675.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB37_289
LBB37_284:                              ; %b22.i.i.i670.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB37_289
LBB37_285:                              ; %b25.i.i.i669.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB37_289
LBB37_286:                              ; %b31.i.i.i663.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB37_289
LBB37_287:                              ; %b28.i.i.i668.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB37_289
LBB37_288:                              ; %b36.i.i.i677.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #6                          ; =0x6
LBB37_289:                              ; %liza___liza_reactor_error.exit.i.i664.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
LBB37_290:                              ; %liza_net.reactor_shutdown_write.exit681.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w11, [sp, #1452]                ; 4-byte Folded Reload
	ldr	x2, [sp, #1328]                 ; 8-byte Folded Reload
	mov	w13, w20
	mov	w14, w21
	cmp	w9, #1
	b.ne	LBB37_292
; %bb.291:                              ; %b207.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w19, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB37_326
	b	LBB37_293
LBB37_292:                              ; %b214.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w27, [sp, #1432]                ; 4-byte Folded Reload
	and	w19, w19, #0x1
	and	w11, w11, #0x1
	and	w14, w14, #0x1
	mov	w8, #1                          ; =0x1
	str	w19, [sp, #1368]                ; 4-byte Folded Spill
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	str	w8, [sp, #1420]                 ; 4-byte Folded Spill
LBB37_293:                              ; %b217.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	tbz	w14, #0, LBB37_295
; %bb.294:                              ; %b217.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w19, [sp, #1380]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1420]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB37_326
LBB37_295:                              ; %b227.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w13, w26
	mov	w8, #2049                       ; =0x801
	ccmp	w26, w8, #2, ls
	cset	w8, lo
	cmp	w8, #1
	b.ne	LBB37_298
; %bb.296:                              ; %b4.i.i713.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w13, w26
	cset	w9, eq
	tbz	w14, #0, LBB37_299
; %bb.297:                              ; %b4.i.i713.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	and	w9, w11, w9
	cbnz	w9, LBB37_299
LBB37_298:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w4, wzr
	b	LBB37_300
LBB37_299:                              ; %b1.i720.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, #2048
	eor	w10, w11, #0x1
	cset	w9, ne
	and	w4, w9, w10
LBB37_300:                              ; %liza_relay.direction.readable.exit723.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w9, [sp, #1432]                 ; 4-byte Folded Reload
	ldr	w24, [sp, #1416]                ; 4-byte Folded Reload
	mov	w21, w11
	str	w26, [sp, #1440]                ; 4-byte Folded Spill
	cmp	w9, w27
	str	w14, [sp, #1448]                ; 4-byte Folded Spill
	b.hi	LBB37_305
; %bb.301:                              ; %liza_relay.direction.readable.exit723.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w27, #2048
	b.hi	LBB37_305
; %bb.302:                              ; %b4.i.i730.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w12, [sp, #1432]                ; 4-byte Folded Reload
	ldr	w9, [sp, #1420]                 ; 4-byte Folded Reload
	orr	w11, w4, #0x2
	cmp	w27, w12
	eor	w9, w9, #0x1
	cset	w10, ne
	orr	w10, w10, w24
	and	w10, w9, w10
	tst	w10, #0x1
	ldr	w10, [sp, #1368]                ; 4-byte Folded Reload
	csel	w4, w11, w4, ne
	tbz	w10, #0, LBB37_312
; %bb.303:                              ; %b4.i.i767.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w27, w12
	cset	w10, eq
	and	w10, w24, w10
	orr	w9, w9, w10
	tbz	w9, #0, LBB37_306
; %bb.304:                              ; %b1.i774.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w27, #2048
	eor	w10, w24, #0x1
	cset	w9, ne
	and	w20, w9, w10
	cbnz	w8, LBB37_307
	b	LBB37_313
LBB37_305:                              ; %b237.thread.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w9, [sp, #1368]                 ; 4-byte Folded Reload
	tbz	w9, #0, LBB37_312
LBB37_306:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w20, wzr
	cbz	w8, LBB37_313
LBB37_307:                              ; %b4.i.i784.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, w13
	cset	w8, ne
	bic	w8, w8, w14
	tbnz	w8, #0, LBB37_311
; %bb.308:                              ; %b4.i.i804.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	tbnz	w14, #0, LBB37_313
; %bb.309:                              ; %b4.i.i804.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	tbz	w21, #0, LBB37_313
; %bb.310:                              ; %b4.i.i804.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	cmp	w26, w13
	b.ne	LBB37_313
LBB37_311:                              ; %b246.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w26, w13
	orr	w20, w20, #0x2
	b	LBB37_314
LBB37_312:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w26, w13
	mov	w20, #2                         ; =0x2
	b	LBB37_314
LBB37_313:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w26, w13
LBB37_314:                              ; %b249.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x1, [sp, #1360]                 ; 8-byte Folded Reload
	mov	x0, x25
	mov	x3, x28
	str	x2, [sp, #1328]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbnz	x8, LBB37_316
; %bb.315:                              ; %b1.i.i838.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w19, wzr
	b	LBB37_319
LBB37_316:                              ; %v8_ok.i.i820.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB37_318
; %bb.317:                              ; %v8_ok.i.i820.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh176:
	adrp	x11, lJTI37_12@PAGE
Lloh177:
	add	x11, x11, lJTI37_12@PAGEOFF
	adr	x9, LBB37_318
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB37_318:                              ; %liza___liza_reactor_error.exit.i.i824.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w19, #1                         ; =0x1
LBB37_319:                              ; %liza_net.reactor_interest.exit.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x3, [sp, #1400]                 ; 8-byte Folded Reload
	mov	x0, x25
	mov	x1, x22
	mov	x2, x23
	mov	w4, w20
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbnz	x8, LBB37_322
; %bb.320:                              ; %b1.i.i864.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w20, [sp, #1352]                ; 4-byte Folded Reload
	orr	w8, w8, w19
	cbnz	w8, LBB37_325
LBB37_321:                              ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
	ldr	w25, [sp, #1344]                ; 4-byte Folded Reload
	str	w26, [sp, #1412]                ; 4-byte Folded Spill
	str	w21, [sp, #1452]                ; 4-byte Folded Spill
	ldr	x21, [sp, #1400]                ; 8-byte Folded Reload
	ldr	w26, [sp, #1368]                ; 4-byte Folded Reload
	str	w27, [sp, #1424]                ; 4-byte Folded Spill
	ldr	x27, [sp, #1360]                ; 8-byte Folded Reload
	str	w24, [sp, #1416]                ; 4-byte Folded Spill
	mov	x24, x23
	mov	x23, x22
	ldr	x22, [sp, #1328]                ; 8-byte Folded Reload
	b	LBB37_337
LBB37_322:                              ; %v8_ok.i.i846.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w8, w8, #1
	ldr	w20, [sp, #1352]                ; 4-byte Folded Reload
	cmp	w8, #11
	b.hi	LBB37_324
; %bb.323:                              ; %v8_ok.i.i846.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh178:
	adrp	x11, lJTI37_13@PAGE
Lloh179:
	add	x11, x11, lJTI37_13@PAGEOFF
	adr	x9, LBB37_324
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB37_324:                              ; %liza___liza_reactor_error.exit.i.i850.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
	orr	w8, w8, w19
	cbz	w8, LBB37_321
LBB37_325:                              ;   in Loop: Header=BB37_100 Depth=2
	ldr	x2, [sp, #1328]                 ; 8-byte Folded Reload
	mov	w19, #3                         ; =0x3
LBB37_326:                              ; %b259.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x1, [sp, #1360]                 ; 8-byte Folded Reload
	mov	x0, x25
	mov	x3, x28
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB37_328
; %bb.327:                              ; %b1.i.i891.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w20, wzr
	b	LBB37_331
LBB37_328:                              ; %v8_ok.i.i873.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB37_330
; %bb.329:                              ; %v8_ok.i.i873.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh180:
	adrp	x11, lJTI37_14@PAGE
Lloh181:
	add	x11, x11, lJTI37_14@PAGEOFF
	adr	x9, LBB37_330
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB37_330:                              ; %liza___liza_reactor_error.exit.i.i877.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w20, #1                         ; =0x1
LBB37_331:                              ; %liza_net.reactor_disconnect.exit894.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	x3, [sp, #1400]                 ; 8-byte Folded Reload
	mov	x0, x25
	mov	x1, x22
	mov	x2, x23
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB37_333
; %bb.332:                              ; %b1.i.i918.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w12, [sp, #700]                 ; 4-byte Folded Reload
	b	LBB37_336
LBB37_333:                              ; %v8_ok.i.i900.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	sub	w8, w8, #1
	ldr	w12, [sp, #700]                 ; 4-byte Folded Reload
	cmp	w8, #11
	b.hi	LBB37_335
; %bb.334:                              ; %v8_ok.i.i900.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
Lloh182:
	adrp	x11, lJTI37_15@PAGE
Lloh183:
	add	x11, x11, lJTI37_15@PAGEOFF
	adr	x9, LBB37_335
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB37_335:                              ; %liza___liza_reactor_error.exit.i.i904.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	mov	w8, #1                          ; =0x1
LBB37_336:                              ; %liza_net.reactor_disconnect.exit921.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	orr	w8, w8, w20
	ldr	w9, [sp, #420]                  ; 4-byte Folded Reload
	mov	x27, xzr
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	mov	x22, xzr
	csel	w8, w19, w8, eq
	cmp	w9, #0
	mov	x28, xzr
	csel	w12, w8, w12, ne
	ldr	w8, [sp, #416]                  ; 4-byte Folded Reload
	mov	x23, xzr
	mov	x24, xzr
	mov	x21, xzr
	mov	w26, wzr
	mov	w20, #1                         ; =0x1
	mov	w25, #1                         ; =0x1
	str	wzr, [sp, #1412]                ; 4-byte Folded Spill
	str	wzr, [sp, #1440]                ; 4-byte Folded Spill
	str	xzr, [sp, #1448]                ; 8-byte Folded Spill
	str	wzr, [sp, #1432]                ; 4-byte Folded Spill
	str	wzr, [sp, #1424]                ; 4-byte Folded Spill
	str	xzr, [sp, #1416]                ; 8-byte Folded Spill
	str	w12, [sp, #700]                 ; 4-byte Folded Spill
LBB37_337:                              ; %v554_ok.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
LBB37_338:                              ; %v554_ok.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	add	x0, sp, #1472
	add	x1, sp, #2288
	mov	w2, #768                        ; =0x300
	add	x19, sp, #1472
	bl	_memcpy
	ldr	x8, [sp, #1456]                 ; 8-byte Folded Reload
	add	x9, sp, #1472
	ldr	x2, [sp, #464]                  ; 8-byte Folded Reload
	str	x9, [sp, #1192]                 ; 8-byte Folded Spill
	and	w9, w26, #0x1
	ldr	x13, [sp, #520]                 ; 8-byte Folded Reload
	add	x8, x19, x8
	ldr	x5, [sp, #752]                  ; 8-byte Folded Reload
	ldr	x19, [sp, #656]                 ; 8-byte Folded Reload
	str	w20, [x8]
	ldr	x20, [sp, #584]                 ; 8-byte Folded Reload
	add	x15, sp, #2288
	stp	x27, x22, [x8, #8]
	ldr	w10, [sp, #1476]
	ldr	x27, [sp, #664]                 ; 8-byte Folded Reload
	str	x28, [x8, #24]
	ldr	x1, [sp, #648]                  ; 8-byte Folded Reload
	ldr	x16, [sp, #680]                 ; 8-byte Folded Reload
	strb	w9, [x8, #64]
	add	x9, sp, #1225
	ldr	x22, [sp, #768]                 ; 8-byte Folded Reload
	ldur	q0, [x9, #255]
	ldr	x9, [sp, #1496]
	str	w10, [sp, #1360]                ; 4-byte Folded Spill
	ldr	w10, [sp, #1412]                ; 4-byte Folded Reload
	str	w25, [x8, #32]
	ldr	x6, [sp, #672]                  ; 8-byte Folded Reload
	str	x9, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #1440]                 ; 4-byte Folded Reload
	ldr	d1, [sp, #1504]
	stp	x23, x24, [x8, #40]
	ldr	x23, [sp, #704]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #760]                 ; 8-byte Folded Reload
	stp	w10, w9, [x8, #68]
	add	x10, sp, #1257
	ldr	w9, [sp, #1452]                 ; 4-byte Folded Reload
	str	x21, [x8, #56]
	ldr	x26, [sp, #744]                 ; 8-byte Folded Reload
	ldr	x11, [sp, #640]                 ; 8-byte Folded Reload
	and	w9, w9, #0x1
	str	d1, [sp, #1368]                 ; 8-byte Folded Spill
	ldur	q1, [x10, #255]
	strb	w9, [x8, #76]
	ldr	w9, [sp, #1448]                 ; 4-byte Folded Reload
	ldr	x10, [sp, #1528]
	ldr	x12, [sp, #632]                 ; 8-byte Folded Reload
	ldr	x7, [sp, #624]                  ; 8-byte Folded Reload
	ldr	x17, [sp, #616]                 ; 8-byte Folded Reload
	and	w9, w9, #0x1
	str	x10, [sp, #1344]                ; 8-byte Folded Spill
	ldrb	w10, [sp, #1536]
	strb	w9, [x8, #77]
	add	x9, sp, #1285
	ldr	x0, [sp, #608]                  ; 8-byte Folded Reload
	ldur	d2, [x9, #255]
	ldrb	w9, [sp, #1548]
	str	w10, [sp, #1336]                ; 4-byte Folded Spill
	ldr	w10, [sp, #1432]                ; 4-byte Folded Reload
	ldr	x3, [sp, #600]                  ; 8-byte Folded Reload
	ldr	x4, [sp, #592]                  ; 8-byte Folded Reload
	str	w9, [sp, #1328]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1549]
	str	w9, [sp, #1320]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1424]                 ; 4-byte Folded Reload
	stp	w10, w9, [x8, #80]
	ldr	w9, [sp, #1416]                 ; 4-byte Folded Reload
	ldrh	w10, [sp, #1550]
	ldr	d3, [sp, #1552]
	and	w9, w9, #0x1
	str	w10, [sp, #1312]                ; 4-byte Folded Spill
	strb	w9, [x8, #88]
	ldr	w9, [sp, #1420]                 ; 4-byte Folded Reload
	ldrb	w10, [sp, #1560]
	and	w9, w9, #0x1
	strb	w9, [x8, #89]
	ldrb	w8, [sp, #1561]
	ldr	x9, [sp, #1624]
	str	w10, [sp, #1308]                ; 4-byte Folded Spill
	ldr	d4, [sp, #1568]
	ldr	d6, [sp, #1600]
	ldr	d17, [sp, #1648]
	str	w8, [sp, #1304]                 ; 4-byte Folded Spill
	add	x8, sp, #1321
	ldr	d18, [sp, #1664]
	ldur	q5, [x8, #255]
	ldr	x8, [sp, #1592]
	str	x9, [sp, #1288]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1632]
	ldr	d20, [sp, #1696]
	ldr	d23, [sp, #1744]
	str	x8, [sp, #1296]                 ; 8-byte Folded Spill
	add	x8, sp, #1472
	ldr	d24, [sp, #1760]
	ldur	q7, [x8, #136]
	ldur	d16, [x8, #164]
	ldur	q19, [x8, #200]
	ldur	q21, [x8, #232]
	ldr	x8, [sp, #1720]
	str	w9, [sp, #1284]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1644]
	ldr	d26, [sp, #1792]
	ldr	w30, [sp, #1832]
	str	x8, [sp, #1240]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1728]
	ldr	d28, [sp, #2048]
	str	w9, [sp, #1280]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1645]
	ldr	d30, [sp, #2080]
	str	w8, [sp, #1248]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #456]                  ; 8-byte Folded Reload
	ldr	d9, [sp, #2128]
	str	w9, [sp, #1276]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1646]
	ldr	d10, [sp, #2144]
	ldr	d22, [x8]
	ldur	q25, [x8, #36]
	ldur	q27, [x8, #68]
	ldr	d8, [x8, #384]
	ldr	d14, [x8, #480]
	ldrb	w8, [sp, #1837]
	str	w9, [sp, #1272]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1656]
	ldr	d12, [sp, #2176]
	str	w8, [sp, #792]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #1838]
	ldr	d15, [sp, #2224]
	str	w9, [sp, #1268]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1657]
	str	w8, [sp, #816]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1840]
	str	w9, [sp, #1264]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1688]
	str	w8, [sp, #1420]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1844]
	str	x9, [sp, #1256]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1740]
	str	w8, [sp, #1448]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1848]
	str	w9, [sp, #1232]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1741]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1849]
	str	w9, [sp, #1024]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1742]
	str	w8, [sp, #788]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1856]
	str	w9, [sp, #1200]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1752]
	str	w8, [sp, #956]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1860]
	str	w9, [sp, #1216]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1753]
	str	w8, [sp, #780]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1864]
	str	w9, [sp, #1224]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1784]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1872]
	str	x9, [sp, #1208]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #1816]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1880]
	str	x9, [sp, #1184]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1824]
	str	x8, [sp, #1424]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #1888]
	str	w9, [sp, #1400]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1828]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1892]
	str	w9, [sp, #1452]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1836]
	str	w8, [sp, #776]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1896]
	str	w9, [sp, #796]                  ; 4-byte Folded Spill
	ldp	x9, x10, [sp, #440]             ; 16-byte Folded Reload
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1904]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1912]
	ldr	q29, [x10]
	ldr	q31, [x9]
	ldp	x9, x10, [sp, #424]             ; 16-byte Folded Reload
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #1920]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1924]
	ldr	q13, [x9]
	ldrb	w9, [sp, #2208]
	ldr	q11, [x10]
	str	w8, [sp, #948]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1928]
	str	w9, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2220]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1932]
	str	w9, [sp, #1128]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2221]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1933]
	str	w9, [sp, #1112]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #2222]
	str	w8, [sp, #860]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #1934]
	str	w9, [sp, #1072]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2232]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1936]
	str	w9, [sp, #1120]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2233]
	str	w8, [sp, #940]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1940]
	str	w9, [sp, #1136]                 ; 4-byte Folded Spill
	ldp	x10, x25, [sp, #488]            ; 16-byte Folded Reload
	str	w8, [sp, #936]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1944]
	ldp	x28, x9, [sp, #472]             ; 16-byte Folded Reload
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #1945]
	str	w8, [sp, #852]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1952]
	str	w8, [sp, #952]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1956]
	str	w8, [sp, #828]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1960]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1968]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #1976]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #1984]
	str	w8, [sp, #832]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #1988]
	str	w8, [sp, #824]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #1992]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2000]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2008]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2016]
	str	w8, [sp, #844]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2020]
	str	w8, [sp, #892]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2024]
	str	w8, [sp, #876]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2028]
	str	w8, [sp, #840]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #576]                  ; 8-byte Folded Reload
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #568]                  ; 8-byte Folded Reload
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #560]                  ; 8-byte Folded Reload
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2029]
	str	w8, [sp, #836]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2030]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2032]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2036]
	str	w8, [sp, #868]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2040]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2041]
	str	w8, [sp, #1096]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2072]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2104]
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #552]                  ; 8-byte Folded Reload
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #544]                  ; 8-byte Folded Reload
	str	x8, [sp, #1000]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #528]                  ; 8-byte Folded Reload
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2112]
	str	w8, [sp, #1080]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2124]
	str	w8, [sp, #1056]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2125]
	str	w8, [sp, #1060]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2126]
	str	w8, [sp, #1048]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2136]
	str	w8, [sp, #1088]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2137]
	str	w8, [sp, #1064]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2168]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2200]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldp	x8, x21, [sp, #504]             ; 16-byte Folded Reload
LBB37_339:                              ; %b274_to_b59.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldrh	w14, [x13]
	ldrb	w13, [x13, #2]
	str	w30, [sp, #1412]                ; 4-byte Folded Spill
	str	w30, [sp, #2648]
	strh	w14, [sp, #2284]
	ldr	w14, [x21]
	strb	w13, [sp, #2286]
	ldrh	w13, [x21, #4]
	mov	x21, x27
	str	w14, [sp, #2276]
	ldrh	w14, [x8]
	ldrb	w8, [x8, #2]
	strh	w13, [sp, #2280]
	ldrh	w13, [x25, #4]
	strb	w8, [sp, #2274]
	ldr	w8, [x25]
	mov	x25, x1
	strh	w13, [sp, #2268]
	ldrb	w13, [x10, #2]
	str	w8, [sp, #2264]
	ldrh	w8, [x10]
	ldr	w10, [x9]
	strh	w14, [sp, #2272]
	strh	w8, [sp, #2260]
	ldrh	w8, [x9, #4]
	ldrh	w9, [x28]
	str	w10, [sp, #2252]
	ldr	x10, [sp, #976]                 ; 8-byte Folded Reload
	strh	w8, [sp, #2256]
	ldrb	w8, [x28, #2]
	ldr	x28, [sp, #712]                 ; 8-byte Folded Reload
	strh	w9, [sp, #2248]
	ldr	w9, [x2]
	strb	w8, [sp, #2250]
	ldrh	w8, [x2, #4]
	ldr	x2, [sp, #968]                  ; 8-byte Folded Reload
	str	w9, [sp, #2240]
	ldr	x9, [sp, #1192]                 ; 8-byte Folded Reload
	strh	w8, [sp, #2244]
	ldr	w8, [sp, #1360]                 ; 4-byte Folded Reload
	ldr	w9, [x9]
	strb	w13, [sp, #2262]
	mov	x13, x16
	str	w8, [sp, #2292]
	ldr	x8, [sp, #1352]                 ; 8-byte Folded Reload
	str	w9, [sp, #2288]
	ldr	w9, [sp, #1336]                 ; 4-byte Folded Reload
	str	x8, [sp, #2312]
	ldr	x8, [sp, #1344]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2352]
	ldrh	w9, [x20]
	str	x8, [sp, #2344]
	ldrb	w8, [x20, #2]
	ldr	x20, [sp, #1384]                ; 8-byte Folded Reload
	strh	w9, [x5]
	ldr	w9, [sp, #1304]                 ; 4-byte Folded Reload
	cmp	x20, #6
	strb	w8, [x5, #2]
	ldr	w8, [sp, #1328]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2377]
	ldr	w9, [x2]
	strb	w8, [sp, #2364]
	ldr	w8, [sp, #1320]                 ; 4-byte Folded Reload
	stur	q0, [x15, #8]
	ldr	d0, [sp, #1368]                 ; 8-byte Folded Reload
	strb	w8, [sp, #2365]
	ldr	w8, [sp, #1312]                 ; 4-byte Folded Reload
	stur	q1, [x15, #40]
	strh	w8, [sp, #2366]
	ldr	w8, [sp, #1308]                 ; 4-byte Folded Reload
	stur	d2, [x15, #68]
	strb	w8, [sp, #2376]
	ldrh	w8, [x2, #4]
	ldr	x2, [sp, #984]                  ; 8-byte Folded Reload
	str	w9, [x27]
	ldr	w9, [sp, #1284]                 ; 4-byte Folded Reload
	strh	w8, [x27, #4]
	ldr	x8, [sp, #1296]                 ; 8-byte Folded Reload
	ldr	x27, [sp, #1432]                ; 8-byte Folded Reload
	strb	w9, [sp, #2448]
	ldrh	w9, [x10]
	str	x8, [sp, #2408]
	ldr	x8, [sp, #1288]                 ; 8-byte Folded Reload
	stur	q5, [x15, #104]
	str	x8, [sp, #2440]
	ldrb	w8, [x10, #2]
	ldr	x10, [sp, #992]                 ; 8-byte Folded Reload
	strh	w9, [x19]
	ldr	w9, [sp, #1264]                 ; 4-byte Folded Reload
	strb	w8, [x19, #2]
	ldr	w8, [sp, #1280]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2473]
	ldr	w9, [x2]
	strb	w8, [sp, #2460]
	ldr	w8, [sp, #1276]                 ; 4-byte Folded Reload
	stur	q7, [x15, #136]
	strb	w8, [sp, #2461]
	ldr	w8, [sp, #1272]                 ; 4-byte Folded Reload
	stur	d16, [x15, #164]
	strh	w8, [sp, #2462]
	ldr	w8, [sp, #1268]                 ; 4-byte Folded Reload
	stur	q19, [x15, #200]
	strb	w8, [sp, #2472]
	ldrh	w8, [x2, #4]
	ldr	x2, [sp, #1000]                 ; 8-byte Folded Reload
	str	w9, [x1]
	ldr	w9, [sp, #1248]                 ; 4-byte Folded Reload
	strh	w8, [x1, #4]
	ldr	x8, [sp, #1256]                 ; 8-byte Folded Reload
	ldr	x1, [sp, #720]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2544]
	ldrh	w9, [x10]
	str	x8, [sp, #2504]
	ldr	x8, [sp, #1240]                 ; 8-byte Folded Reload
	stur	q21, [x15, #232]
	mov	x15, x7
	str	x8, [sp, #2536]
	ldrb	w8, [x10, #2]
	ldr	w10, [sp, #1420]                ; 4-byte Folded Reload
	strh	w9, [x24]
	ldr	w9, [sp, #1224]                 ; 4-byte Folded Reload
	strb	w8, [x24, #2]
	ldr	w8, [sp, #1232]                 ; 4-byte Folded Reload
	ldr	x24, [sp, #1440]                ; 8-byte Folded Reload
	strb	w9, [sp, #2569]
	ldr	w9, [x2]
	strb	w8, [sp, #2556]
	ldr	w8, [sp, #1024]                 ; 4-byte Folded Reload
	str	d22, [x23]
	strb	w8, [sp, #2557]
	ldr	w8, [sp, #1200]                 ; 4-byte Folded Reload
	stur	q25, [x23, #36]
	strh	w8, [sp, #2558]
	ldr	w8, [sp, #1216]                 ; 4-byte Folded Reload
	stur	q27, [x23, #68]
	strb	w8, [sp, #2568]
	ldrh	w8, [x2, #4]
	ldr	x2, [sp, #1008]                 ; 8-byte Folded Reload
	str	w9, [x16]
	ldr	x9, [sp, #1184]                 ; 8-byte Folded Reload
	strh	w8, [x16, #4]
	ldr	x8, [sp, #1208]                 ; 8-byte Folded Reload
	ldr	x16, [sp, #728]                 ; 8-byte Folded Reload
	str	x9, [sp, #2632]
	ldrh	w9, [x2]
	str	x8, [sp, #2600]
	ldrb	w8, [x2, #2]
	ldr	x2, [sp, #1016]                 ; 8-byte Folded Reload
	strh	w9, [x22]
	ldr	w9, [x2]
	strb	w8, [x22, #2]
	ldrh	w8, [x2, #4]
	ldr	w22, [sp, #1448]                ; 4-byte Folded Reload
	str	d8, [x23, #384]
	str	w9, [x6]
	ldrh	w9, [sp, #2284]
	strh	w8, [x6, #4]
	ldrb	w8, [sp, #2286]
	strh	w9, [x26]
	ldr	w9, [sp, #2276]
	strb	w8, [x26, #2]
	ldrh	w8, [sp, #2280]
	ldr	x26, [sp, #1424]                ; 8-byte Folded Reload
	str	w9, [x11]
	ldrh	w9, [sp, #2272]
	strh	w8, [x11, #4]
	ldrb	w8, [sp, #2274]
	strh	w9, [x12]
	ldr	w9, [sp, #1096]                 ; 4-byte Folded Reload
	strb	w8, [x12, #2]
	ldr	w8, [sp, #1040]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2857]
	ldr	w9, [sp, #2264]
	strb	w8, [sp, #2856]
	ldrh	w8, [sp, #2268]
	str	w9, [x7]
	ldr	w9, [sp, #1080]                 ; 4-byte Folded Reload
	strh	w8, [x7, #4]
	ldr	x8, [sp, #1144]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2928]
	ldrh	w9, [sp, #2260]
	str	x8, [sp, #2888]
	ldr	x8, [sp, #1152]                 ; 8-byte Folded Reload
	strh	w9, [x17]
	ldr	w9, [sp, #1064]                 ; 4-byte Folded Reload
	str	x8, [sp, #2920]
	ldrb	w8, [sp, #2262]
	strb	w9, [sp, #2953]
	ldr	w9, [sp, #2252]
	strb	w8, [x17, #2]
	ldr	w8, [sp, #1056]                 ; 4-byte Folded Reload
	str	w9, [x0]
	ldr	w9, [sp, #1104]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2940]
	ldr	w8, [sp, #1060]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3024]
	ldrh	w9, [sp, #2248]
	strb	w8, [sp, #2941]
	ldr	w8, [sp, #1048]                 ; 4-byte Folded Reload
	strh	w9, [x3]
	ldr	w9, [sp, #1136]                 ; 4-byte Folded Reload
	strh	w8, [sp, #2942]
	ldr	w8, [sp, #1088]                 ; 4-byte Folded Reload
	strb	w9, [sp, #3049]
	ldr	w9, [sp, #2240]
	strb	w8, [sp, #2952]
	ldrh	w8, [sp, #2256]
	str	w9, [x4]
	ldr	w9, [sp, #796]                  ; 4-byte Folded Reload
	strh	w8, [x0, #4]
	ldr	x8, [sp, #1168]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2652]
	ldr	w9, [sp, #792]                  ; 4-byte Folded Reload
	str	x8, [sp, #2984]
	ldr	x8, [sp, #1176]                 ; 8-byte Folded Reload
	strb	w9, [sp, #2653]
	ldr	w9, [sp, #816]                  ; 4-byte Folded Reload
	str	x8, [sp, #3016]
	ldrb	w8, [sp, #2250]
	strh	w9, [sp, #2654]
	ldr	w9, [sp, #784]                  ; 4-byte Folded Reload
	strb	w8, [x3, #2]
	ldr	w8, [sp, #1128]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2664]
	ldr	w9, [sp, #788]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3036]
	ldr	w8, [sp, #1112]                 ; 4-byte Folded Reload
	strb	w9, [sp, #2665]
	ldr	w9, [sp, #956]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3037]
	ldr	w8, [sp, #1072]                 ; 4-byte Folded Reload
	str	w9, [sp, #2672]
	ldr	w9, [sp, #780]                  ; 4-byte Folded Reload
	strh	w8, [sp, #3038]
	ldr	w8, [sp, #1120]                 ; 4-byte Folded Reload
	str	w9, [sp, #2676]
	ldr	w9, [sp, #1416]                 ; 4-byte Folded Reload
	strb	w8, [sp, #3048]
	ldrh	w8, [sp, #2244]
	mov	w5, w9
	str	w9, [sp, #2704]
	ldr	w9, [sp, #776]                  ; 4-byte Folded Reload
	strh	w8, [x4, #4]
	ldr	w8, [sp, #1400]                 ; 4-byte Folded Reload
	str	w9, [sp, #2708]
	ldr	x9, [sp, #960]                  ; 8-byte Folded Reload
	strb	w8, [sp, #2640]
	ldr	w8, [sp, #1452]                 ; 4-byte Folded Reload
	str	x9, [sp, #2712]
	ldr	x9, [sp, #808]                  ; 8-byte Folded Reload
	str	d14, [x23, #480]
	mov	w23, w22
	str	x9, [sp, #2720]
	ldr	x9, [sp, #800]                  ; 8-byte Folded Reload
	str	d0, [sp, #2320]
	str	x9, [sp, #2728]
	ldr	w9, [sp, #864]                  ; 4-byte Folded Reload
	str	d3, [sp, #2368]
	strb	w9, [sp, #2736]
	ldr	w9, [sp, #948]                  ; 4-byte Folded Reload
	str	d4, [sp, #2384]
	str	w9, [sp, #2740]
	ldr	w9, [sp, #944]                  ; 4-byte Folded Reload
	str	d6, [sp, #2416]
	str	w9, [sp, #2744]
	ldr	w9, [sp, #856]                  ; 4-byte Folded Reload
	str	d17, [sp, #2464]
	strb	w9, [sp, #2748]
	ldr	w9, [sp, #860]                  ; 4-byte Folded Reload
	str	d18, [sp, #2480]
	strb	w9, [sp, #2749]
	ldr	w9, [sp, #1164]                 ; 4-byte Folded Reload
	str	d20, [sp, #2512]
	mov	w14, w9
	strh	w9, [sp, #2750]
	ldr	w9, [sp, #940]                  ; 4-byte Folded Reload
	str	d23, [sp, #2560]
	str	w9, [sp, #2752]
	ldr	w9, [sp, #936]                  ; 4-byte Folded Reload
	str	d24, [sp, #2576]
	str	w9, [sp, #2756]
	ldr	w9, [sp, #848]                  ; 4-byte Folded Reload
	str	d26, [sp, #2608]
	strb	w9, [sp, #2760]
	ldr	w9, [sp, #852]                  ; 4-byte Folded Reload
	str	w8, [sp, #2644]
	strb	w9, [sp, #2761]
	ldr	w9, [sp, #952]                  ; 4-byte Folded Reload
	str	w10, [sp, #2656]
	str	w9, [sp, #2768]
	ldr	w9, [sp, #828]                  ; 4-byte Folded Reload
	str	w22, [sp, #2660]
	str	w9, [sp, #2772]
	ldr	x9, [sp, #928]                  ; 8-byte Folded Reload
	str	x24, [sp, #2680]
	str	x9, [sp, #2776]
	ldr	x9, [sp, #920]                  ; 8-byte Folded Reload
	str	x27, [sp, #2688]
	str	x9, [sp, #2784]
	ldr	x9, [sp, #912]                  ; 8-byte Folded Reload
	str	x26, [sp, #2696]
	str	x9, [sp, #2792]
	ldr	w9, [sp, #832]                  ; 4-byte Folded Reload
	str	d28, [sp, #2864]
	str	w9, [sp, #2800]
	ldr	w9, [sp, #824]                  ; 4-byte Folded Reload
	str	d30, [sp, #2896]
	str	w9, [sp, #2804]
	ldr	x9, [sp, #904]                  ; 8-byte Folded Reload
	str	q31, [x16]
	str	x9, [sp, #2808]
	ldr	x9, [sp, #896]                  ; 8-byte Folded Reload
	str	d9, [sp, #2944]
	str	x9, [sp, #2816]
	ldr	x9, [sp, #880]                  ; 8-byte Folded Reload
	str	d10, [sp, #2960]
	str	x9, [sp, #2824]
	ldr	w9, [sp, #844]                  ; 4-byte Folded Reload
	str	q11, [x1]
	strb	w9, [sp, #2832]
	ldr	w9, [sp, #892]                  ; 4-byte Folded Reload
	str	d12, [sp, #2992]
	str	w9, [sp, #2836]
	ldr	w9, [sp, #876]                  ; 4-byte Folded Reload
	str	q13, [x28]
	str	w9, [sp, #2840]
	ldr	w9, [sp, #840]                  ; 4-byte Folded Reload
	str	d15, [sp, #3040]
	strb	w9, [sp, #2844]
	ldr	w9, [sp, #836]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2845]
	ldr	w9, [sp, #1032]                 ; 4-byte Folded Reload
	mov	w30, w9
	strh	w9, [sp, #2846]
	ldr	w9, [sp, #872]                  ; 4-byte Folded Reload
	str	w9, [sp, #2848]
	ldr	w9, [sp, #868]                  ; 4-byte Folded Reload
	str	w9, [sp, #2852]
	ldr	x9, [sp, #736]                  ; 8-byte Folded Reload
	str	q29, [x9]
	b.hi	LBB37_341
; %bb.340:                              ; %b274_to_b59.i.i.i
                                        ;   in Loop: Header=BB37_100 Depth=2
	ldr	w7, [sp, #1396]                 ; 4-byte Folded Reload
	add	x20, x20, #1
	mov	w22, w5
	str	x20, [sp, #1384]                ; 8-byte Folded Spill
	ldr	w20, [sp, #1380]                ; 4-byte Folded Reload
	add	w7, w7, #1, lsl #12             ; =4096
	str	w7, [sp, #1396]                 ; 4-byte Folded Spill
	ldr	x7, [sp, #1456]                 ; 8-byte Folded Reload
	add	x7, x7, #96
	tbnz	w20, #0, LBB37_100
	b	LBB37_46
LBB37_341:                              ;   in Loop: Header=BB37_47 Depth=1
	ldr	w20, [sp, #1380]                ; 4-byte Folded Reload
	mov	w22, w5
	b	LBB37_46
LBB37_342:                              ;   in Loop: Header=BB37_47 Depth=1
	mov	w8, #1                          ; =0x1
	add	x27, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	add	x8, sp, #4030
	add	x11, sp, #1, lsl #12            ; =4096
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x30, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x26, sp, #4088
	add	x27, x27, #4
	add	x8, x8, #12
	add	x12, x12, #16
	add	x11, x11, #24
	add	x10, x10, #28
	add	x16, x16, #36
	add	x15, x15, #40
	add	x1, x1, #48
	add	x2, x2, #52
	add	x6, x6, #60
	add	x19, x19, #64
	add	x30, x30, #72
	add	x22, x22, #76
	add	x24, x24, #84
	b	LBB37_97
LBB37_343:                              ; %b1.i147.i.i.i
                                        ;   in Loop: Header=BB37_47 Depth=1
	ldr	x10, [sp, #4312]
	ldr	x9, [sp, #4320]
	mov	w11, wzr
	ldr	x8, [sp, #4328]
	b	LBB37_93
LBB37_344:                              ; %liza_liza_proxy.exchange.exit.i.i
	ldr	x0, [sp, #688]                  ; 8-byte Folded Reload
	mov	w19, w9
	bl	_liza_rt_reactor_close
	cmp	w0, #0
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	mov	w8, #3                          ; =0x3
	csel	w19, w19, w8, eq
	bl	_liza_rt_region_close
	mov	w0, w19
	b	LBB37_20
LBB37_345:                              ; %b1.i.i49.i.i.i
	mov	w19, wzr
	b	LBB37_35
LBB37_346:                              ; %v256_trap.i.i.i
	brk	#0x1
	.loh AdrpAdd	Lloh138, Lloh139
	.loh AdrpAdd	Lloh140, Lloh141
	.loh AdrpAdd	Lloh142, Lloh143
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.loh AdrpAdd	Lloh152, Lloh153
	.loh AdrpAdd	Lloh154, Lloh155
	.loh AdrpAdd	Lloh156, Lloh157
	.loh AdrpAdd	Lloh158, Lloh159
	.loh AdrpAdd	Lloh160, Lloh161
	.loh AdrpAdd	Lloh162, Lloh163
	.loh AdrpAdd	Lloh164, Lloh165
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpAdd	Lloh168, Lloh169
	.loh AdrpAdd	Lloh170, Lloh171
	.loh AdrpAdd	Lloh172, Lloh173
	.loh AdrpAdd	Lloh174, Lloh175
	.loh AdrpAdd	Lloh176, Lloh177
	.loh AdrpAdd	Lloh178, Lloh179
	.loh AdrpAdd	Lloh180, Lloh181
	.loh AdrpAdd	Lloh182, Lloh183
	.cfi_endproc
	.section	__TEXT,__const
lJTI37_0:
	.byte	(LBB37_14-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
	.byte	(LBB37_4-LBB37_4)>>2
lJTI37_1:
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
	.byte	(LBB37_24-LBB37_24)>>2
lJTI37_2:
	.byte	(LBB37_62-LBB37_51)>>2
	.byte	(LBB37_51-LBB37_51)>>2
	.byte	(LBB37_56-LBB37_51)>>2
	.byte	(LBB37_55-LBB37_51)>>2
	.byte	(LBB37_53-LBB37_51)>>2
	.byte	(LBB37_54-LBB37_51)>>2
	.byte	(LBB37_61-LBB37_51)>>2
	.byte	(LBB37_57-LBB37_51)>>2
	.byte	(LBB37_58-LBB37_51)>>2
	.byte	(LBB37_60-LBB37_51)>>2
	.byte	(LBB37_59-LBB37_51)>>2
	.byte	(LBB37_52-LBB37_51)>>2
lJTI37_3:
	.byte	(LBB37_72-LBB37_72)>>2
	.byte	(LBB37_86-LBB37_72)>>2
	.byte	(LBB37_76-LBB37_72)>>2
	.byte	(LBB37_81-LBB37_72)>>2
	.byte	(LBB37_82-LBB37_72)>>2
	.byte	(LBB37_77-LBB37_72)>>2
	.byte	(LBB37_79-LBB37_72)>>2
	.byte	(LBB37_85-LBB37_72)>>2
	.byte	(LBB37_80-LBB37_72)>>2
	.byte	(LBB37_84-LBB37_72)>>2
	.byte	(LBB37_83-LBB37_72)>>2
	.byte	(LBB37_75-LBB37_72)>>2
	.byte	(LBB37_78-LBB37_72)>>2
	.p2align	1, 0x0
lJTI37_4:
	.short	(LBB37_343-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
	.short	(LBB37_92-LBB37_92)>>2
lJTI37_5:
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
	.byte	(LBB37_108-LBB37_108)>>2
lJTI37_6:
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
	.byte	(LBB37_114-LBB37_114)>>2
lJTI37_7:
	.byte	(LBB37_133-LBB37_122)>>2
	.byte	(LBB37_122-LBB37_122)>>2
	.byte	(LBB37_127-LBB37_122)>>2
	.byte	(LBB37_126-LBB37_122)>>2
	.byte	(LBB37_124-LBB37_122)>>2
	.byte	(LBB37_125-LBB37_122)>>2
	.byte	(LBB37_132-LBB37_122)>>2
	.byte	(LBB37_128-LBB37_122)>>2
	.byte	(LBB37_129-LBB37_122)>>2
	.byte	(LBB37_131-LBB37_122)>>2
	.byte	(LBB37_130-LBB37_122)>>2
	.byte	(LBB37_123-LBB37_122)>>2
lJTI37_8:
	.byte	(LBB37_177-LBB37_158)>>2
	.byte	(LBB37_158-LBB37_158)>>2
	.byte	(LBB37_171-LBB37_158)>>2
	.byte	(LBB37_170-LBB37_158)>>2
	.byte	(LBB37_168-LBB37_158)>>2
	.byte	(LBB37_169-LBB37_158)>>2
	.byte	(LBB37_176-LBB37_158)>>2
	.byte	(LBB37_172-LBB37_158)>>2
	.byte	(LBB37_173-LBB37_158)>>2
	.byte	(LBB37_175-LBB37_158)>>2
	.byte	(LBB37_174-LBB37_158)>>2
	.byte	(LBB37_167-LBB37_158)>>2
lJTI37_9:
	.byte	(LBB37_211-LBB37_200)>>2
	.byte	(LBB37_200-LBB37_200)>>2
	.byte	(LBB37_205-LBB37_200)>>2
	.byte	(LBB37_204-LBB37_200)>>2
	.byte	(LBB37_202-LBB37_200)>>2
	.byte	(LBB37_203-LBB37_200)>>2
	.byte	(LBB37_210-LBB37_200)>>2
	.byte	(LBB37_206-LBB37_200)>>2
	.byte	(LBB37_207-LBB37_200)>>2
	.byte	(LBB37_209-LBB37_200)>>2
	.byte	(LBB37_208-LBB37_200)>>2
	.byte	(LBB37_201-LBB37_200)>>2
lJTI37_10:
	.byte	(LBB37_251-LBB37_236)>>2
	.byte	(LBB37_236-LBB37_236)>>2
	.byte	(LBB37_245-LBB37_236)>>2
	.byte	(LBB37_244-LBB37_236)>>2
	.byte	(LBB37_242-LBB37_236)>>2
	.byte	(LBB37_243-LBB37_236)>>2
	.byte	(LBB37_250-LBB37_236)>>2
	.byte	(LBB37_246-LBB37_236)>>2
	.byte	(LBB37_247-LBB37_236)>>2
	.byte	(LBB37_249-LBB37_236)>>2
	.byte	(LBB37_248-LBB37_236)>>2
	.byte	(LBB37_241-LBB37_236)>>2
lJTI37_11:
	.byte	(LBB37_289-LBB37_273)>>2
	.byte	(LBB37_273-LBB37_273)>>2
	.byte	(LBB37_283-LBB37_273)>>2
	.byte	(LBB37_282-LBB37_273)>>2
	.byte	(LBB37_280-LBB37_273)>>2
	.byte	(LBB37_281-LBB37_273)>>2
	.byte	(LBB37_288-LBB37_273)>>2
	.byte	(LBB37_284-LBB37_273)>>2
	.byte	(LBB37_285-LBB37_273)>>2
	.byte	(LBB37_287-LBB37_273)>>2
	.byte	(LBB37_286-LBB37_273)>>2
	.byte	(LBB37_279-LBB37_273)>>2
lJTI37_12:
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
	.byte	(LBB37_318-LBB37_318)>>2
lJTI37_13:
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
	.byte	(LBB37_324-LBB37_324)>>2
lJTI37_14:
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
	.byte	(LBB37_330-LBB37_330)>>2
lJTI37_15:
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
	.byte	(LBB37_335-LBB37_335)>>2
                                        ; -- End function
l_text.liza_proxy.exchange.v21:         ; @text.liza_proxy.exchange.v21
	.byte	10

	.p2align	4, 0x0                          ; @text.main.v9
l_text.main.v9:
	.ascii	"Usage: liza-proxy [--once | --ephemeral]\n"

l_text.main.v17:                        ; @text.main.v17
	.ascii	"--once"

l_text.main.v21:                        ; @text.main.v21
	.ascii	"--ephemeral"

	.p2align	4, 0x0                          ; @text.main.v25
l_text.main.v25:
	.ascii	"Usage: liza-proxy [--once | --ephemeral]\n"

l_text.main.v28:                        ; @text.main.v28
	.ascii	"--once"

	.p2align	4, 0x0                          ; @text.main.v37
l_text.main.v37:
	.ascii	"Cannot create loopback reactor\n"

.subsections_via_symbols
