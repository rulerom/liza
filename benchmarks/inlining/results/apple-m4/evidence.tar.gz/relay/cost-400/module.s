	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza___liza_write_text         ; -- Begin function liza___liza_write_text
	.p2align	2
_liza___liza_write_text:                ; @liza___liza_write_text
	.cfi_startproc
; %bb.0:
	b	_liza_rt_write_text
	.cfi_endproc
                                        ; -- End function
	.globl	_liza___liza_print_u64          ; -- Begin function liza___liza_print_u64
	.p2align	2
_liza___liza_print_u64:                 ; @liza___liza_print_u64
	.cfi_startproc
; %bb.0:
	b	_liza_rt_print_u64
	.cfi_endproc
                                        ; -- End function
	.globl	_liza___liza_err_text           ; -- Begin function liza___liza_err_text
	.p2align	2
_liza___liza_err_text:                  ; @liza___liza_err_text
	.cfi_startproc
; %bb.0:
	b	_liza_rt_err_text
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_relay.direction.empty     ; -- Begin function liza_relay.direction.empty
	.p2align	2
_liza_relay.direction.empty:            ; @liza_relay.direction.empty
; %bb.0:                                ; %b0
	mov	w0, wzr
	mov	w1, wzr
	mov	w2, wzr
	mov	w3, wzr
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.valid     ; -- Begin function liza_relay.direction.valid
	.p2align	2
_liza_relay.direction.valid:            ; @liza_relay.direction.valid
; %bb.0:                                ; %b0
	mov	w8, w0
	cmp	w0, w1
	mov	w0, wzr
	b.hi	LBB4_4
; %bb.1:                                ; %b0
	cmp	w1, #2048
	b.hi	LBB4_4
; %bb.2:                                ; %b4
	tbz	w3, #0, LBB4_5
; %bb.3:                                ; %b6
	cmp	w8, w1
	cset	w8, eq
	and	w0, w2, w8
LBB4_4:                                 ; %b12
	ret
LBB4_5:
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.readable  ; -- Begin function liza_relay.direction.readable
	.p2align	2
_liza_relay.direction.readable:         ; @liza_relay.direction.readable
; %bb.0:                                ; %b0
	mov	w8, w0
	cmp	w0, w1
	mov	w0, wzr
	b.hi	LBB5_6
; %bb.1:                                ; %b0
	cmp	w1, #2048
	b.hi	LBB5_6
; %bb.2:                                ; %b4.i
	cmp	w8, w1
	cset	w8, eq
	tbz	w3, #0, LBB5_5
; %bb.3:                                ; %b4.i
	and	w8, w2, w8
	cbnz	w8, LBB5_5
; %bb.4:
	mov	w0, wzr
	ret
LBB5_5:                                 ; %b1
	mov	w8, #2048                       ; =0x800
	tst	w2, #0x1
	sub	w8, w8, w1
	csel	w0, wzr, w8, ne
LBB5_6:                                 ; %common.ret
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.queued    ; -- Begin function liza_relay.direction.queued
	.p2align	2
_liza_relay.direction.queued:           ; @liza_relay.direction.queued
; %bb.0:                                ; %b0
	cmp	w0, w1
	mov	w8, wzr
	b.hi	LBB6_6
; %bb.1:                                ; %b0
	cmp	w1, #2048
	b.hi	LBB6_6
; %bb.2:                                ; %b4.i
	cmp	w0, w1
	cset	w8, eq
	tbz	w3, #0, LBB6_5
; %bb.3:                                ; %b4.i
	and	w8, w2, w8
	tbnz	w8, #0, LBB6_5
; %bb.4:
	mov	w8, wzr
	mov	w0, w8
	ret
LBB6_5:                                 ; %b3
	subs	w8, w1, w0
	b.lo	LBB6_7
LBB6_6:                                 ; %common.ret
	mov	w0, w8
	ret
LBB6_7:                                 ; %v5_trap
	brk	#0x1
                                        ; -- End function
	.globl	_liza_relay.direction.read      ; -- Begin function liza_relay.direction.read
	.p2align	2
_liza_relay.direction.read:             ; @liza_relay.direction.read
; %bb.0:                                ; %b0
	mov	w9, w1
	mov	w8, w0
	mov	w1, wzr
	cmp	w0, w9
	mov	w0, #1                          ; =0x1
	b.hi	LBB7_9
; %bb.1:                                ; %b0
	mov	w10, w2
	cmp	w9, #2048
	mov	w2, w1
	mov	w11, w1
	mov	w12, w1
	mov	w5, w1
	b.hi	LBB7_10
; %bb.2:                                ; %b4.i
	cmp	w8, w9
	cset	w11, eq
	tbz	w3, #0, LBB7_5
; %bb.3:                                ; %b4.i
	and	w11, w10, w11
	cbnz	w11, LBB7_5
; %bb.4:
	mov	w1, wzr
	mov	w2, wzr
	mov	w12, wzr
	mov	w5, wzr
	b	LBB7_10
LBB7_5:                                 ; %b1
	mov	w11, #2048                      ; =0x800
	orr	w10, w3, w10
	mov	w1, wzr
	subs	w11, w11, w9
	cset	w12, eq
	orr	w10, w10, w12
	tbnz	w10, #0, LBB7_9
; %bb.6:                                ; %b1
	cmp	w4, w11
	mov	w2, w1
	mov	w11, w1
	mov	w12, w1
	mov	w5, w1
	b.hi	LBB7_10
; %bb.7:                                ; %b12
	mov	w0, wzr
	cbz	w4, LBB7_11
; %bb.8:                                ; %v26_ok
	mov	w11, wzr
	mov	w12, wzr
	mov	w5, wzr
	add	w2, w9, w4
	mov	w1, w8
	b	LBB7_10
LBB7_9:
	mov	w2, w1
	mov	w11, w1
	mov	w12, w1
	mov	w5, w1
LBB7_10:                                ; %common.ret
	and	w3, w11, #0x1
	and	w4, w12, #0x1
	ret
LBB7_11:                                ; %b13
	mov	w12, wzr
	mov	w5, wzr
	mov	w11, #1                         ; =0x1
	mov	w1, w8
	mov	w2, w9
	b	LBB7_10
                                        ; -- End function
	.globl	_liza_relay.direction.write     ; -- Begin function liza_relay.direction.write
	.p2align	2
_liza_relay.direction.write:            ; @liza_relay.direction.write
; %bb.0:                                ; %b0
	mov	w8, w1
	mov	w9, w0
	mov	w1, wzr
	cmp	w0, w8
	mov	w0, #1                          ; =0x1
	b.hi	LBB8_4
; %bb.1:                                ; %b0
	cmp	w8, #2048
	mov	w6, w1
	mov	w10, w1
	mov	w11, w1
	mov	w5, w1
	b.hi	LBB8_19
; %bb.2:                                ; %b4.i
	tbz	w3, #0, LBB8_5
; %bb.3:                                ; %b6.i
	cmp	w9, w8
	cset	w10, eq
	and	w10, w2, w10
	mov	w1, wzr
	cbnz	w10, LBB8_6
LBB8_4:
	mov	w6, w1
	mov	w10, w1
	mov	w11, w1
	mov	w5, w1
	b	LBB8_19
LBB8_5:
	mov	w10, #1                         ; =0x1
	mov	w1, wzr
	cbz	w10, LBB8_4
LBB8_6:                                 ; %liza_relay.direction.valid.exit
	mov	w6, w1
	mov	w10, w1
	mov	w11, w1
	mov	w5, w1
	cbz	w4, LBB8_19
; %bb.7:                                ; %b4.i.i
	cmp	w9, w8
	cset	w10, eq
	tbz	w3, #0, LBB8_10
; %bb.8:                                ; %b4.i.i
	and	w10, w2, w10
	cbnz	w10, LBB8_10
; %bb.9:
	mov	w1, wzr
	mov	w6, wzr
	b	LBB8_13
LBB8_10:                                ; %b3.i
	subs	w10, w8, w9
	b.lo	LBB8_20
; %bb.11:                               ; %liza_relay.direction.queued.exit
	cmp	w4, w10
	b.ls	LBB8_14
; %bb.12:
	mov	w1, wzr
	mov	w6, wzr
	mov	w10, wzr
LBB8_13:                                ; %common.ret
	mov	w11, wzr
	mov	w5, wzr
	b	LBB8_19
LBB8_14:                                ; %b9
	adds	w1, w9, w4
	b.hs	LBB8_20
; %bb.15:                               ; %v13_ok
	cmp	w1, w8
	b.ne	LBB8_17
; %bb.16:                               ; %b10
	mov	w0, wzr
	mov	w1, wzr
	mov	w6, wzr
	mov	w5, wzr
	b	LBB8_18
LBB8_17:                                ; %b12
	mov	w0, wzr
	mov	w5, wzr
	mov	w6, w8
LBB8_18:                                ; %common.ret
	mov	w10, w2
	mov	w11, w3
LBB8_19:                                ; %common.ret
	and	w3, w10, #0x1
	and	w4, w11, #0x1
	mov	w2, w6
	ret
LBB8_20:                                ; %v5_trap.i
	brk	#0x1
                                        ; -- End function
	.globl	_liza_relay.direction.needs_fin ; -- Begin function liza_relay.direction.needs_fin
	.p2align	2
_liza_relay.direction.needs_fin:        ; @liza_relay.direction.needs_fin
; %bb.0:                                ; %b0
	cmp	w0, w1
	eor	w8, w3, #0x1
	cset	w9, ls
	cset	w10, eq
	cmp	w1, #2049
	csel	w9, wzr, w9, hs
	and	w10, w2, w10
	and	w9, w9, w10
	and	w0, w9, w8
	ret
                                        ; -- End function
	.globl	_liza_relay.direction.shutdown  ; -- Begin function liza_relay.direction.shutdown
	.p2align	2
_liza_relay.direction.shutdown:         ; @liza_relay.direction.shutdown
; %bb.0:                                ; %b0
	mov	w9, w1
	mov	w8, w0
	mov	w1, wzr
	cmp	w0, w9
	mov	w0, #1                          ; =0x1
	b.hi	LBB10_6
; %bb.1:                                ; %b0
	cmp	w9, #2048
	mov	w10, w1
	mov	w5, w1
	b.hi	LBB10_7
; %bb.2:                                ; %b4.i.i
	mov	w1, wzr
	tbnz	w3, #0, LBB10_6
; %bb.3:                                ; %b4.i.i
	tbz	w2, #0, LBB10_6
; %bb.4:                                ; %b4.i.i
	cmp	w8, w9
	mov	w10, w1
	mov	w5, w1
	b.ne	LBB10_7
; %bb.5:                                ; %b3
	mov	w0, wzr
	mov	w5, wzr
	mov	w10, #1                         ; =0x1
	mov	w1, w8
	b	LBB10_7
LBB10_6:
	mov	w10, w1
	mov	w5, w1
LBB10_7:                                ; %common.ret
	and	w3, w10, #0x1
	and	w4, w10, #0x1
	mov	w2, w1
	ret
                                        ; -- End function
	.globl	_liza_liza_proxy.empty_pair     ; -- Begin function liza_liza_proxy.empty_pair
	.p2align	2
_liza_liza_proxy.empty_pair:            ; @liza_liza_proxy.empty_pair
; %bb.0:                                ; %b0
	movi.2d	v0, #0000000000000000
	mov	w9, #1                          ; =0x1
	strh	wzr, [x8, #88]
	str	xzr, [x8, #80]
	strh	wzr, [x8, #76]
	stur	xzr, [x8, #68]
	strb	wzr, [x8, #64]
	str	xzr, [x8, #56]
	stur	q0, [x8, #40]
	str	w9, [x8, #32]
	str	xzr, [x8, #24]
	stur	q0, [x8, #8]
	str	w9, [x8]
	ret
                                        ; -- End function
	.globl	_liza_liza_proxy.retry          ; -- Begin function liza_liza_proxy.retry
	.p2align	2
_liza_liza_proxy.retry:                 ; @liza_liza_proxy.retry
; %bb.0:                                ; %b0
	mov	w8, #268                        ; =0x10c
	lsr	w8, w8, w0
	and	w0, w8, #0x1
	ret
                                        ; -- End function
	.globl	_liza_liza_proxy.exchange       ; -- Begin function liza_liza_proxy.exchange
	.p2align	2
_liza_liza_proxy.exchange:              ; @liza_liza_proxy.exchange
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #464
	.cfi_def_cfa_offset 4720
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	add	x8, sp, #433
	str	w4, [sp, #412]                  ; 4-byte Folded Spill
	mov	x20, x0
	strb	wzr, [x8, #4095]
	add	x8, sp, #429
	strb	wzr, [x8, #4095]
	add	x8, sp, #428
	strb	wzr, [x8, #4095]
	add	x8, sp, #425
	strb	wzr, [x8, #4095]
	add	x8, sp, #424
	strb	wzr, [x8, #4095]
	add	x8, sp, #417
	strb	wzr, [x8, #4095]
	add	x8, sp, #413
	strb	wzr, [x8, #4095]
	add	x8, sp, #412
	strb	wzr, [x8, #4095]
	add	x8, sp, #409
	strb	wzr, [x8, #4095]
	add	x8, sp, #408
	strb	wzr, [x8, #4095]
	add	x8, sp, #401
	strb	wzr, [x8, #4095]
	add	x8, sp, #397
	strb	wzr, [x8, #4095]
	add	x8, sp, #396
	strb	wzr, [x8, #4095]
	add	x8, sp, #393
	strb	wzr, [x8, #4095]
	add	x8, sp, #392
	strb	wzr, [x8, #4095]
	add	x8, sp, #385
	strb	wzr, [x8, #4095]
	add	x8, sp, #381
	strb	wzr, [x8, #4095]
	add	x8, sp, #380
	strb	wzr, [x8, #4095]
	add	x8, sp, #377
	strb	wzr, [x8, #4095]
	add	x8, sp, #376
	strb	wzr, [x8, #4095]
	add	x8, sp, #369
	strb	wzr, [x8, #4095]
	add	x8, sp, #365
	strb	wzr, [x8, #4095]
	add	x8, sp, #364
	strb	wzr, [x8, #4095]
	add	x8, sp, #361
	strb	wzr, [x8, #4095]
	add	x8, sp, #360
	strb	wzr, [x8, #4095]
	add	x8, sp, #353
	strb	wzr, [x8, #4095]
	add	x8, sp, #349
	strb	wzr, [x8, #4095]
	add	x8, sp, #348
	strb	wzr, [x8, #4095]
	add	x8, sp, #345
	strb	wzr, [x8, #4095]
	add	x8, sp, #344
	strb	wzr, [x8, #4095]
	add	x8, sp, #337
	strb	wzr, [x8, #4095]
	add	x8, sp, #333
	strb	wzr, [x8, #4095]
	add	x8, sp, #332
	strb	wzr, [x8, #4095]
	add	x8, sp, #329
	strb	wzr, [x8, #4095]
	add	x8, sp, #328
	strb	wzr, [x8, #4095]
	add	x8, sp, #321
	strb	wzr, [x8, #4095]
	add	x8, sp, #317
	strb	wzr, [x8, #4095]
	add	x8, sp, #316
	strb	wzr, [x8, #4095]
	add	x8, sp, #313
	strb	wzr, [x8, #4095]
	add	x8, sp, #312
	str	w3, [sp, #140]                  ; 4-byte Folded Spill
	str	w2, [sp, #152]                  ; 4-byte Folded Spill
	str	x1, [sp, #144]                  ; 8-byte Folded Spill
	strb	wzr, [x8, #4095]
	bl	_liza_rt_reactor_port
	lsr	x8, x0, #32
	cbz	x8, LBB13_4
; %bb.1:                                ; %v8_ok.i.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_3
; %bb.2:                                ; %v8_ok.i.i
Lloh0:
	adrp	x9, lJTI13_0@PAGE
Lloh1:
	add	x9, x9, lJTI13_0@PAGEOFF
	adr	x10, LBB13_3
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_3:                                ; %liza___liza_reactor_error.exit.i.i
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB13_4:                                ; %liza_net.reactor_port.exit
	cmp	w8, #1
	b.ne	LBB13_6
; %bb.5:
	mov	w8, wzr
	mov	w21, #3                         ; =0x3
	str	x20, [sp, #720]                 ; 8-byte Folded Spill
	cbnz	w8, LBB13_23
	b	LBB13_318
LBB13_6:                                ; %v12_ok
	mov	w0, w0
	bl	_liza_rt_print_u64
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB13_10
; %bb.7:                                ; %v12_ok
	cbz	w8, LBB13_319
; %bb.8:                                ; %v12_ok
	cmp	w8, #1
	b.eq	LBB13_13
; %bb.9:                                ; %v12_ok
	cmp	w8, #2
	b	LBB13_13
LBB13_10:                               ; %v12_ok
	cmp	w8, #3
	b.eq	LBB13_13
; %bb.11:                               ; %v12_ok
	cmp	w8, #4
	b.eq	LBB13_13
; %bb.12:                               ; %v12_ok
	cmp	w8, #5
LBB13_13:                               ; %b18.i.i
	mov	w19, #1                         ; =0x1
LBB13_14:                               ; %liza_console.print_u64.exit
Lloh2:
	adrp	x0, l_text.liza_proxy.exchange.v21@PAGE
Lloh3:
	add	x0, x0, l_text.liza_proxy.exchange.v21@PAGEOFF
	mov	w1, #1                          ; =0x1
	bl	_liza_rt_write_text
	lsr	x8, x0, #32
	cmp	w8, #2
	b.gt	LBB13_18
; %bb.15:                               ; %liza_console.print_u64.exit
	cbz	w8, LBB13_22
; %bb.16:                               ; %liza_console.print_u64.exit
	cmp	w8, #1
	b.eq	LBB13_22
; %bb.17:                               ; %liza_console.print_u64.exit
	cmp	w8, #2
	b	LBB13_21
LBB13_18:                               ; %liza_console.print_u64.exit
	cmp	w8, #3
	b.eq	LBB13_21
; %bb.19:                               ; %liza_console.print_u64.exit
	cmp	w8, #4
	b.eq	LBB13_21
; %bb.20:                               ; %liza_console.print_u64.exit
	cmp	w8, #5
LBB13_21:                               ; %b18.i.i72
	mov	w8, #1                          ; =0x1
LBB13_22:                               ; %liza_console.write.exit
	orr	w8, w8, w19
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	cset	w8, eq
	csel	w21, wzr, w9, eq
	str	x20, [sp, #720]                 ; 8-byte Folded Spill
	cbz	w8, LBB13_318
LBB13_23:                               ; %b14.lr.ph
	add	x8, sp, #1600
	mov	w7, wzr
	str	w21, [sp, #1320]                ; 4-byte Folded Spill
	add	x9, x8, #65
	add	x10, x8, #474
	str	wzr, [sp, #1152]                ; 4-byte Folded Spill
	str	x9, [sp, #584]                  ; 8-byte Folded Spill
	add	x9, x8, #90
                                        ; implicit-def: $w20
                                        ; implicit-def: $w23
                                        ; implicit-def: $w28
                                        ; implicit-def: $w26
                                        ; implicit-def: $w27
                                        ; implicit-def: $w25
                                        ; implicit-def: $w22
                                        ; implicit-def: $w24
	str	x9, [sp, #576]                  ; 8-byte Folded Spill
	add	x9, x8, #161
	str	x9, [sp, #568]                  ; 8-byte Folded Spill
	add	x9, x8, #186
	str	x9, [sp, #560]                  ; 8-byte Folded Spill
	add	x9, x8, #257
	str	x9, [sp, #552]                  ; 8-byte Folded Spill
	add	x9, x8, #282
	str	x9, [sp, #544]                  ; 8-byte Folded Spill
	add	x9, x8, #353
	str	x9, [sp, #536]                  ; 8-byte Folded Spill
	add	x9, x8, #378
	str	x9, [sp, #528]                  ; 8-byte Folded Spill
	add	x9, x8, #449
	str	x9, [sp, #520]                  ; 8-byte Folded Spill
	add	x9, x8, #545
	stp	x9, x10, [sp, #504]             ; 16-byte Folded Spill
	add	x10, x8, #570
	add	x9, x8, #641
	stp	x9, x10, [sp, #488]             ; 16-byte Folded Spill
	add	x10, x8, #666
	add	x9, x8, #737
	add	x8, x8, #762
	stp	x9, x10, [sp, #472]             ; 16-byte Folded Spill
	add	x10, sp, #3472
	str	x8, [sp, #464]                  ; 8-byte Folded Spill
	add	x8, sp, #2416
	add	x11, x10, #65
	add	x4, x8, #260
	add	x8, sp, #312
	add	x9, sp, #1600
	ldrb	w8, [x8, #4095]
	add	x9, x9, #260
	add	x12, x4, #324
	str	x9, [sp, #456]                  ; 8-byte Folded Spill
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
	add	x8, sp, #313
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1144]                ; 8-byte Folded Spill
	str	wzr, [sp, #1136]                ; 4-byte Folded Spill
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	add	x8, sp, #316
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #984]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1016]                ; 8-byte Folded Spill
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	add	x8, sp, #317
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1008]                ; 8-byte Folded Spill
	str	xzr, [sp, #1192]                ; 8-byte Folded Spill
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	add	x8, sp, #321
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1208]                ; 8-byte Folded Spill
	str	xzr, [sp, #1200]                ; 8-byte Folded Spill
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	add	x8, sp, #328
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1132]                ; 4-byte Folded Spill
	str	wzr, [sp, #1120]                ; 4-byte Folded Spill
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	add	x8, sp, #329
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1112]                ; 8-byte Folded Spill
	str	xzr, [sp, #952]                 ; 8-byte Folded Spill
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	add	x8, sp, #332
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #944]                 ; 8-byte Folded Spill
	str	xzr, [sp, #936]                 ; 8-byte Folded Spill
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	add	x8, sp, #333
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #976]                 ; 8-byte Folded Spill
	str	xzr, [sp, #968]                 ; 8-byte Folded Spill
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	add	x8, sp, #337
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #960]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1464]                ; 8-byte Folded Spill
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	add	x8, sp, #344
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1080]                ; 4-byte Folded Spill
	str	wzr, [sp, #1076]                ; 4-byte Folded Spill
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	add	x8, sp, #345
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #904]                 ; 8-byte Folded Spill
	str	xzr, [sp, #896]                 ; 8-byte Folded Spill
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	add	x8, sp, #348
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #888]                 ; 8-byte Folded Spill
	str	xzr, [sp, #928]                 ; 8-byte Folded Spill
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	add	x8, sp, #349
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #920]                 ; 8-byte Folded Spill
	str	xzr, [sp, #912]                 ; 8-byte Folded Spill
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	add	x8, sp, #353
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1184]                ; 8-byte Folded Spill
	str	wzr, [sp, #1176]                ; 4-byte Folded Spill
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	add	x8, sp, #360
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1480]                ; 8-byte Folded Spill
	str	xzr, [sp, #1472]                ; 8-byte Folded Spill
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	add	x8, sp, #361
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1432]                ; 8-byte Folded Spill
	str	xzr, [sp, #1440]                ; 8-byte Folded Spill
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	add	x8, sp, #364
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1448]                ; 8-byte Folded Spill
	str	xzr, [sp, #1456]                ; 8-byte Folded Spill
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	add	x8, sp, #365
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1168]                ; 4-byte Folded Spill
	str	xzr, [sp, #1160]                ; 8-byte Folded Spill
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	add	x8, sp, #369
	ldrb	w13, [x8, #4095]
	add	x8, sp, #376
	str	wzr, [sp, #1156]                ; 4-byte Folded Spill
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1064]                ; 8-byte Folded Spill
	str	xzr, [sp, #1056]                ; 8-byte Folded Spill
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	add	x8, sp, #377
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1048]                ; 8-byte Folded Spill
	str	xzr, [sp, #1104]                ; 8-byte Folded Spill
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	add	x8, sp, #380
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1096]                ; 8-byte Folded Spill
	str	xzr, [sp, #1088]                ; 8-byte Folded Spill
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	add	x8, sp, #381
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #240]                 ; 8-byte Folded Spill
	str	xzr, [sp, #1296]                ; 8-byte Folded Spill
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	add	x8, sp, #385
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1288]                ; 8-byte Folded Spill
	str	xzr, [sp, #1280]                ; 8-byte Folded Spill
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	add	x8, sp, #392
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1272]                ; 8-byte Folded Spill
	str	xzr, [sp, #1248]                ; 8-byte Folded Spill
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	add	x8, sp, #393
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1240]                ; 4-byte Folded Spill
	str	wzr, [sp, #1232]                ; 4-byte Folded Spill
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	add	x8, sp, #396
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #1224]                ; 4-byte Folded Spill
	str	wzr, [sp, #1220]                ; 4-byte Folded Spill
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	add	x8, sp, #397
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1040]                ; 8-byte Folded Spill
	str	xzr, [sp, #1032]                ; 8-byte Folded Spill
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	add	x8, sp, #401
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #848]                 ; 8-byte Folded Spill
	str	xzr, [sp, #840]                 ; 8-byte Folded Spill
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	add	x8, sp, #408
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #832]                 ; 8-byte Folded Spill
	str	xzr, [sp, #880]                 ; 8-byte Folded Spill
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	add	x8, sp, #409
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #872]                 ; 8-byte Folded Spill
	str	xzr, [sp, #864]                 ; 8-byte Folded Spill
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	add	x8, sp, #412
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #1000]                ; 8-byte Folded Spill
	str	wzr, [sp, #1028]                ; 4-byte Folded Spill
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	add	x8, sp, #413
	ldrb	w8, [x8, #4095]
	str	wzr, [sp, #996]                 ; 4-byte Folded Spill
	str	xzr, [sp, #856]                 ; 8-byte Folded Spill
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	add	x8, sp, #417
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #800]                 ; 8-byte Folded Spill
	str	xzr, [sp, #792]                 ; 8-byte Folded Spill
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	add	x8, sp, #424
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #824]                 ; 8-byte Folded Spill
	str	xzr, [sp, #816]                 ; 8-byte Folded Spill
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	add	x8, sp, #425
	ldrb	w8, [x8, #4095]
	str	xzr, [sp, #808]                 ; 8-byte Folded Spill
	str	wzr, [sp, #156]                 ; 4-byte Folded Spill
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	add	x8, sp, #428
	ldrb	w8, [x8, #4095]
	str	x4, [sp, #592]                  ; 8-byte Folded Spill
	str	x12, [sp, #736]                 ; 8-byte Folded Spill
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	add	x8, sp, #429
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	add	x8, sp, #433
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #412]                  ; 4-byte Folded Reload
	eor	w8, w8, #0x1
	str	w8, [sp, #408]                  ; 4-byte Folded Spill
	add	x8, x10, #90
	stp	x8, x11, [sp, #112]             ; 16-byte Folded Spill
	add	x8, x10, #186
	add	x11, x10, #161
	str	x8, [sp, #128]                  ; 8-byte Folded Spill
	add	x8, x10, #257
	stp	x8, x11, [sp, #96]              ; 16-byte Folded Spill
	add	x11, x10, #282
	add	x8, x10, #353
	stp	x8, x11, [sp, #80]              ; 16-byte Folded Spill
	add	x11, x10, #378
	add	x8, x10, #449
	stp	x8, x11, [sp, #64]              ; 16-byte Folded Spill
	add	x11, x10, #474
	add	x8, x10, #545
	stp	x8, x11, [sp, #48]              ; 16-byte Folded Spill
	add	x11, x10, #570
	add	x8, x10, #641
	stp	x8, x11, [sp, #32]              ; 16-byte Folded Spill
	add	x11, x10, #666
	add	x8, x10, #737
	stp	x8, x11, [sp, #16]              ; 16-byte Folded Spill
	add	x8, sp, #2416
	add	x10, x10, #762
	str	x10, [sp, #8]                   ; 8-byte Folded Spill
	add	x10, x8, #449
	add	x19, x8, #65
	str	x10, [sp, #640]                 ; 8-byte Folded Spill
	add	x10, x8, #474
	add	x1, x8, #90
	str	x10, [sp, #632]                 ; 8-byte Folded Spill
	add	x10, x8, #545
	add	x2, x8, #161
	str	x10, [sp, #624]                 ; 8-byte Folded Spill
	add	x10, x8, #570
	add	x17, x8, #186
	str	x10, [sp, #712]                 ; 8-byte Folded Spill
	add	x10, x4, #356
	add	x16, x8, #257
	str	x10, [sp, #776]                 ; 8-byte Folded Spill
	add	x10, x4, #420
	add	x3, x8, #282
	str	x10, [sp, #768]                 ; 8-byte Folded Spill
	add	x10, x4, #452
	add	x0, x8, #353
	str	x10, [sp, #760]                 ; 8-byte Folded Spill
	add	x10, x8, #737
	add	x6, x8, #378
	add	x14, x8, #641
	add	x15, x8, #666
	str	x10, [sp, #600]                 ; 8-byte Folded Spill
	add	x30, x8, #762
	add	x10, x9, #260
	add	x8, x9, #324
	stp	x8, x10, [sp, #440]             ; 16-byte Folded Spill
	add	x10, x9, #356
	add	x8, x9, #420
	stp	x8, x10, [sp, #424]             ; 16-byte Folded Spill
	add	x8, x9, #452
	mov	w9, #1                          ; =0x1
	str	x8, [sp, #416]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	add	x11, x4, #260
	mov	w10, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
	str	x19, [sp, #696]                 ; 8-byte Folded Spill
	str	w8, [sp, #264]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x1, [sp, #688]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x2, [sp, #680]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x17, [sp, #672]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x16, [sp, #664]                 ; 8-byte Folded Spill
	str	w8, [sp, #260]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x3, [sp, #656]                  ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x0, [sp, #752]                  ; 8-byte Folded Spill
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x6, [sp, #648]                  ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x11, [sp, #744]                 ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x14, [sp, #616]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	x15, [sp, #608]                 ; 8-byte Folded Spill
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	str	x30, [sp, #704]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	stp	w8, w9, [sp, #252]              ; 8-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #248]                  ; 4-byte Folded Spill
                                        ; implicit-def: $w8
                                        ; kill: killed $w8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	str	w8, [sp, #1492]                 ; 4-byte Folded Spill
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	str	w8, [sp, #1496]                 ; 4-byte Folded Spill
	str	w8, [sp, #1328]                 ; 4-byte Folded Spill
	b	LBB13_26
LBB13_24:                               ; %b58_to_b59.b61_to_b13_crit_edge
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldrb	w9, [sp, #2792]
	ldrb	w8, [sp, #2780]
	mov	w5, wzr
	ldr	w10, [sp, #2788]
	ldr	x19, [sp, #2808]
	ldr	x24, [sp, #2816]
	str	w9, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2793]
	ldr	x25, [sp, #2824]
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2781]
	ldr	x13, [sp, #2840]
	str	w9, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2800]
	ldr	x27, [sp, #2848]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2784]
	ldr	x28, [sp, #2856]
	str	w9, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2804]
	str	w9, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2832]
	str	w9, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2836]
	str	w9, [sp, #1384]                 ; 4-byte Folded Spill
LBB13_25:                               ; %b61_to_b13
                                        ;   in Loop: Header=BB13_26 Depth=1
	str	w10, [sp, #1464]                ; 4-byte Folded Spill
	ldr	w10, [x1]
	ldrb	w9, [x0, #2]
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	add	x11, sp, #311
	ldrh	w8, [x0]
	str	w10, [sp, #4396]
	ldr	w10, [sp, #2416]
	ldr	x0, [sp, #752]                  ; 8-byte Folded Reload
	strh	w8, [sp, #4404]
	ldrh	w8, [x1, #4]
	ldrh	w26, [sp, #2878]
	str	w10, [sp, #1328]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2420]
	strb	w9, [x11, #4095]
	ldrb	w9, [x2, #2]
	strh	w8, [sp, #4400]
	ldrh	w8, [x2]
	str	w10, [sp, #224]                 ; 4-byte Folded Spill
	add	x10, sp, #299
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2424]
	ldrh	w9, [x17, #4]
	strh	w8, [sp, #4392]
	ldr	w8, [x17]
	str	x10, [sp, #240]                 ; 8-byte Folded Spill
	ldr	x10, [sp, #2432]
	str	w8, [sp, #4384]
	ldrh	w8, [x3]
	str	x10, [sp, #1296]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2440]
	strh	w8, [sp, #4380]
	ldr	w8, [x16]
	str	x10, [sp, #1288]                ; 8-byte Folded Spill
	ldr	w10, [sp, #2448]
	str	w8, [sp, #4372]
	ldrh	w8, [x0]
	str	w10, [sp, #312]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2452]
	strh	w8, [sp, #4368]
	ldr	w8, [x6]
	strh	w9, [sp, #4388]
	ldrb	w9, [x3, #2]
	str	w10, [sp, #220]                 ; 4-byte Folded Spill
	add	x10, sp, #287
	str	w8, [sp, #4360]
	ldrh	w8, [x21]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2456]
	ldrh	w9, [x16, #4]
	strh	w8, [sp, #4356]
	ldr	w8, [x20]
	str	x10, [sp, #1280]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2464]
	str	w8, [sp, #4348]
	ldrh	w8, [x23]
	str	x10, [sp, #1272]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2472]
	strh	w8, [sp, #4344]
	ldr	w8, [x22]
	str	x10, [sp, #1248]                ; 8-byte Folded Spill
	ldrb	w10, [sp, #2480]
	strh	w9, [sp, #4376]
	ldrb	w9, [x0, #2]
	str	w8, [sp, #4336]
	ldrh	w8, [x14]
	str	w10, [sp, #784]                 ; 4-byte Folded Spill
	add	x10, sp, #275
	strb	w9, [x10, #4095]
	ldr	w10, [sp, #2484]
	ldrh	w9, [x6, #4]
	strh	w8, [sp, #4332]
	ldr	w8, [x15]
	str	w10, [sp, #1240]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2488]
	str	w8, [sp, #4324]
	ldrh	w8, [x7]
	str	w10, [sp, #1232]                ; 4-byte Folded Spill
	ldrb	w10, [sp, #2492]
	strh	w8, [sp, #4320]
	ldr	x8, [sp, #2552]
	str	w10, [sp, #400]                 ; 4-byte Folded Spill
	ldrb	w10, [sp, #2493]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2560]
	strh	w9, [sp, #4364]
	ldrb	w9, [x21, #2]
	ldr	w21, [sp, #732]                 ; 4-byte Folded Reload
	str	w10, [sp, #404]                 ; 4-byte Folded Spill
	add	x10, sp, #263
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2568]
	strb	w9, [x10, #4095]
	ldr	w10, [sp, #2496]
	ldrh	w9, [x20, #4]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2576]
	ldrh	w20, [sp, #3166]
	str	w10, [sp, #1224]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2500]
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2580]
	str	w10, [sp, #1220]                ; 4-byte Folded Spill
	ldrb	w10, [sp, #2504]
	strh	w9, [sp, #4352]
	ldrb	w9, [x23, #2]
	ldrh	w23, [sp, #3070]
	str	w8, [sp, #1136]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2584]
	str	w10, [sp, #396]                 ; 4-byte Folded Spill
	add	x10, sp, #251
	strb	w9, [x10, #4095]
	ldrb	w10, [sp, #2505]
	ldrh	w9, [x22, #4]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2588]
	ldrh	w22, [sp, #2590]
	str	w10, [sp, #392]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2512]
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2589]
	str	w10, [sp, #1496]                ; 4-byte Folded Spill
	ldr	w10, [sp, #2516]
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2592]
	strh	w9, [sp, #4340]
	ldrb	w9, [x14, #2]
	str	w10, [sp, #216]                 ; 4-byte Folded Spill
	add	x10, sp, #239
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2596]
	strb	w9, [x10, #4095]
	ldr	x10, [sp, #2520]
	ldrh	w9, [x15, #4]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2600]
	str	x10, [sp, #1200]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2528]
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2601]
	str	x10, [sp, #1208]                ; 8-byte Folded Spill
	ldr	x10, [sp, #2536]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2608]
	str	x10, [sp, #1192]                ; 8-byte Folded Spill
	ldr	w10, [sp, #2544]
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2616]
	str	w10, [sp, #264]                 ; 4-byte Folded Spill
	ldr	w10, [sp, #2548]
	strh	w9, [sp, #4328]
	ldrb	w9, [x7, #2]
	ldr	w7, [sp, #2884]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2624]
	str	w10, [sp, #212]                 ; 4-byte Folded Spill
	add	x10, sp, #227
	strb	w9, [x10, #4095]
	ldrh	w9, [x30, #4]
	ldr	w10, [sp, #2640]
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2632]
	strh	w9, [sp, #4316]
	ldr	w9, [sp, #2612]
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2644]
	str	x28, [sp, #1480]                ; 8-byte Folded Spill
	ldrh	w28, [sp, #2974]
	stp	w9, w8, [sp, #204]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2648]
	ldr	w9, [sp, #2708]
	str	x27, [sp, #1472]                ; 8-byte Folded Spill
	ldrh	w27, [sp, #2782]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2656]
	str	x13, [sp, #1432]                ; 8-byte Folded Spill
	ldrb	w13, [sp, #2864]
	str	x8, [sp, #944]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2664]
	str	x25, [sp, #1440]                ; 8-byte Folded Spill
	ldrh	w25, [sp, #2686]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2672]
	str	x24, [sp, #1448]                ; 8-byte Folded Spill
	ldrh	w24, [sp, #2494]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2676]
	str	x19, [sp, #1456]                ; 8-byte Folded Spill
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2680]
	str	w21, [sp, #1320]                ; 4-byte Folded Spill
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2684]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2685]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2688]
	str	w8, [sp, #1120]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2692]
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2696]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2697]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2704]
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2712]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2720]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2728]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #2736]
	str	w8, [sp, #260]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2740]
	stp	w9, w8, [sp, #196]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2744]
	ldr	w9, [sp, #2900]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2752]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #2760]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2768]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2772]
	str	w8, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2776]
	str	w8, [sp, #1080]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2868]
	str	w8, [sp, #1176]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2872]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2876]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2877]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2880]
	str	w8, [sp, #1188]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2888]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2889]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2896]
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2904]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2912]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2920]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2928]
	str	w8, [sp, #256]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2932]
	stp	w9, w8, [sp, #188]              ; 8-byte Folded Spill
	ldr	x8, [sp, #2936]
	ldr	w9, [sp, #2996]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2944]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2952]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2960]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2964]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2968]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2972]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2973]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2976]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2980]
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2984]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2985]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #2992]
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3000]
	str	x8, [sp, #864]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3008]
	str	x8, [sp, #872]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3016]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3024]
	str	w8, [sp, #252]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3028]
	stp	w9, w8, [sp, #180]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3032]
	ldr	w9, [sp, #3092]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3040]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3048]
	str	x8, [sp, #848]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3056]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3060]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3064]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3068]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3069]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3072]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3076]
	str	w8, [sp, #1044]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3080]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3081]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3088]
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3096]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3104]
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3112]
	str	x8, [sp, #824]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3120]
	str	w8, [sp, #248]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3124]
	stp	w9, w8, [sp, #172]              ; 8-byte Folded Spill
	ldr	x8, [sp, #3128]
	ldr	w9, [sp, #3172]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3136]
	str	w9, [sp, #1004]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #3176]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3144]
	str	w9, [sp, #384]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #3177]
	str	x8, [sp, #856]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3152]
	str	w9, [sp, #388]                  ; 4-byte Folded Spill
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3156]
	str	w8, [sp, #996]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3160]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3164]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3165]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3168]
	str	w8, [sp, #1028]                 ; 4-byte Folded Spill
	ldr	w8, [x30]
	str	w8, [sp, #4312]
	tbz	w5, #0, LBB13_318
LBB13_26:                               ; %b14
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_80 Depth 2
	ldr	x0, [sp, #720]                  ; 8-byte Folded Reload
	mov	w1, #1000                       ; =0x3e8
	stp	w10, w13, [sp, #228]            ; 8-byte Folded Spill
	str	w7, [sp, #236]                  ; 4-byte Folded Spill
	bl	_liza_rt_reactor_poll
	lsr	x8, x0, #32
	cbnz	x8, LBB13_28
; %bb.27:                               ; %b1.i.i95
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, wzr
	b	LBB13_42
LBB13_28:                               ; %v8_ok.i.i77
                                        ;   in Loop: Header=BB13_26 Depth=1
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_40
; %bb.29:                               ; %v8_ok.i.i77
                                        ;   in Loop: Header=BB13_26 Depth=1
Lloh4:
	adrp	x12, lJTI13_1@PAGE
Lloh5:
	add	x12, x12, lJTI13_1@PAGEOFF
	mov	w9, wzr
	adr	x10, LBB13_30
	ldrb	w11, [x12, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_30:                               ; %b4.i.i.i93
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #1                          ; =0x1
	b	LBB13_41
LBB13_31:                               ; %b34.i.i.i88
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #11                         ; =0xb
	b	LBB13_41
LBB13_32:                               ; %b13.i.i.i90
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #4                          ; =0x4
	b	LBB13_41
LBB13_33:                               ; %b16.i.i.i89
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #5                          ; =0x5
	b	LBB13_41
LBB13_34:                               ; %b10.i.i.i91
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #3                          ; =0x3
	b	LBB13_41
LBB13_35:                               ; %b7.i.i.i92
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #2                          ; =0x2
	b	LBB13_41
LBB13_36:                               ; %b22.i.i.i87
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #7                          ; =0x7
	b	LBB13_41
LBB13_37:                               ; %b25.i.i.i86
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #8                          ; =0x8
	b	LBB13_41
LBB13_38:                               ; %b31.i.i.i80
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #10                         ; =0xa
	b	LBB13_41
LBB13_39:                               ; %b28.i.i.i85
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #9                          ; =0x9
	b	LBB13_41
LBB13_40:                               ; %b36.i.i.i94
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #6                          ; =0x6
LBB13_41:                               ; %liza___liza_reactor_error.exit.i.i81
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, #1                          ; =0x1
LBB13_42:                               ; %liza_net.reactor_poll.exit
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB13_45
; %bb.43:                               ; %b17
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w10, #1                         ; =0x1
	ldr	w8, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w11, #3                         ; =0x3
	lsl	w9, w10, w9
	mov	w10, #3827                      ; =0xef3
	mov	w14, wzr
	tst	w9, w10
	b.ne	LBB13_47
; %bb.44:                               ;   in Loop: Header=BB13_26 Depth=1
	ldr	w11, [sp, #1320]                ; 4-byte Folded Reload
	b	LBB13_46
LBB13_45:                               ;   in Loop: Header=BB13_26 Depth=1
	ldr	w11, [sp, #1320]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1492]                 ; 4-byte Folded Reload
LBB13_46:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w14, #1                         ; =0x1
LBB13_47:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w13, [sp, #1496]                ; 4-byte Folded Reload
	ldrh	w9, [sp, #4368]
	add	x10, sp, #275
	str	w11, [sp, #732]                 ; 4-byte Folded Spill
	ldrb	w10, [x10, #4095]
	add	x15, sp, #1, lsl #12            ; =4096
	cmp	w13, #1
	ldr	w13, [sp, #1328]                ; 4-byte Folded Reload
	ldr	w11, [sp, #4360]
	ldrh	w12, [sp, #4364]
	strh	w9, [sp, #4244]
	mov	w9, #8                          ; =0x8
	csinc	w9, w9, wzr, ne
	cmp	w13, #1
	add	x13, sp, #151
	strb	w10, [x13, #4095]
	ldrh	w10, [sp, #4356]
	csel	w9, wzr, w9, eq
	str	w11, [sp, #4296]
	add	x11, sp, #263
	cmp	w9, #8
	strh	w12, [sp, #4300]
	ldr	w12, [sp, #1344]                ; 4-byte Folded Reload
	ldrb	w11, [x11, #4095]
	strh	w10, [sp, #4292]
	ldrh	w10, [sp, #4352]
	add	x17, sp, #1, lsl #12            ; =4096
	ccmp	w12, #1, #0, eq
	add	x12, sp, #199
	strh	w24, [sp, #4310]
	strb	w11, [x12, #4095]
	mov	w12, #2                         ; =0x2
	ldr	w11, [sp, #4348]
	csel	w9, w12, w9, eq
	strh	w10, [sp, #4288]
	add	x10, sp, #251
	ldr	w12, [sp, #1352]                ; 4-byte Folded Reload
	ldrb	w10, [x10, #4095]
	cmp	w9, #8
	str	w11, [sp, #4284]
	ldrh	w11, [sp, #4344]
	add	x0, sp, #1, lsl #12             ; =4096
	ccmp	w12, #1, #0, eq
	add	x12, sp, #187
	strh	w22, [sp, #4308]
	strb	w10, [x12, #4095]
	mov	w12, #3                         ; =0x3
	ldr	w10, [sp, #4336]
	csel	w9, w12, w9, eq
	strh	w11, [sp, #4280]
	ldrh	w11, [sp, #4340]
	cmp	w9, #8
	str	w10, [sp, #4272]
	ldrh	w10, [sp, #4332]
	ccmp	w8, #1, #0, eq
	add	x8, sp, #239
	strh	w11, [sp, #4276]
	ldrb	w11, [x8, #4095]
	mov	w12, #4                         ; =0x4
	add	x8, sp, #175
	csel	w9, w12, w9, eq
	strh	w10, [sp, #4268]
	ldr	w10, [sp, #4324]
	strb	w11, [x8, #4095]
	ldr	w8, [sp, #1364]                 ; 4-byte Folded Reload
	cmp	w9, #8
	ldrh	w11, [sp, #4328]
	str	w10, [sp, #4260]
	mov	w12, #5                         ; =0x5
	ccmp	w8, #1, #0, eq
	add	x8, sp, #227
	strh	w25, [sp, #4306]
	ldrb	w10, [x8, #4095]
	add	x8, sp, #163
	csel	w9, w12, w9, eq
	strh	w11, [sp, #4264]
	ldrh	w11, [sp, #4320]
	cmp	w9, #8
	strb	w10, [x8, #4095]
	ldr	w8, [sp, #1368]                 ; 4-byte Folded Reload
	ldrh	w10, [sp, #4316]
	strh	w11, [sp, #4256]
	mov	w11, #6                         ; =0x6
	add	x1, sp, #1, lsl #12             ; =4096
	ccmp	w8, #1, #0, eq
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	strh	w10, [sp, #4252]
	csel	w9, w11, w9, eq
	ldr	w11, [sp, #4312]
	mov	w10, #7                         ; =0x7
	cmp	w9, #8
	strh	w27, [sp, #4304]
	add	x2, sp, #1, lsl #12             ; =4096
	ccmp	w8, #1, #0, eq
	strh	w26, [sp, #4290]
	add	x4, sp, #1, lsl #12             ; =4096
	strh	w28, [sp, #4278]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	strh	w23, [sp, #4266]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x13, sp, #1, lsl #12            ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	add	x26, sp, #1, lsl #12            ; =4096
	add	x27, sp, #1, lsl #12            ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x28, sp, #1, lsl #12            ; =4096
	csel	w21, w10, w9, eq
	add	x15, x15, #216
	add	x17, x17, #224
	add	x0, x0, #228
	add	x1, x1, #236
	add	x2, x2, #240
	add	x4, x4, #248
	add	x5, x5, #252
	add	x6, x6, #260
	add	x19, x19, #264
	add	x22, x22, #208
	add	x23, x23, #272
	add	x24, x24, #276
	add	x13, x13, #210
	add	x7, x7, #284
	add	x25, x25, #288
	add	x16, x16, #212
	add	x26, x26, #296
	add	x27, x27, #300
	add	x3, x3, #214
	add	x28, x28, #308
	str	w11, [sp, #4248]
	strh	w20, [sp, #4254]
	str	w14, [sp, #1320]                ; 4-byte Folded Spill
	cbz	w14, LBB13_54
; %bb.48:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x9, [sp, #712]                  ; 8-byte Folded Reload
	cmp	w21, #7
	b.hi	LBB13_53
; %bb.49:                               ; %b22_to_b23
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w20, [sp, #412]                 ; 4-byte Folded Reload
	ldr	w8, [sp, #156]                  ; 4-byte Folded Reload
	and	w20, w20, w8
	tbnz	w20, #0, LBB13_53
; %bb.50:                               ; %b42
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x19, [sp, #720]                 ; 8-byte Folded Reload
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #440
	mov	x0, x19
	bl	_liza_rt_reactor_accept
	cmp	w0, #12
	b.hi	LBB13_65
; %bb.51:                               ; %b42
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, w0
Lloh6:
	adrp	x11, lJTI13_2@PAGE
Lloh7:
	add	x11, x11, lJTI13_2@PAGEOFF
	adr	x9, LBB13_52
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	mov	w27, wzr
	br	x9
LBB13_52:                               ; %b1.i119
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x20, [sp, #4536]
	ldr	x22, [sp, #4544]
	mov	w8, wzr
	ldr	x23, [sp, #4552]
	mov	w27, wzr
	b	LBB13_67
LBB13_53:                               ;   in Loop: Header=BB13_26 Depth=1
	add	x14, sp, #1, lsl #12            ; =4096
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	add	x10, sp, #1, lsl #12            ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x14, x14, #158
	add	x10, x10, #170
	add	x11, x11, #182
	add	x12, x12, #194
	str	x14, [sp, #160]                 ; 8-byte Folded Spill
	b	LBB13_78
LBB13_54:                               ;   in Loop: Header=BB13_26 Depth=1
	add	x8, sp, #1, lsl #12             ; =4096
	ldr	x9, [sp, #712]                  ; 8-byte Folded Reload
	add	x10, sp, #1, lsl #12            ; =4096
	add	x8, x8, #158
	add	x11, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	add	x10, x10, #170
	add	x11, x11, #182
	add	x12, x12, #194
	b	LBB13_78
LBB13_55:                               ; %b31.i.i106
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #10                        ; =0xa
	b	LBB13_66
LBB13_56:                               ; %b4.i.i118
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #1                         ; =0x1
	b	LBB13_66
LBB13_57:                               ; %b13.i.i115
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #4                         ; =0x4
	b	LBB13_66
LBB13_58:                               ; %b34.i.i113
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #11                        ; =0xb
	b	LBB13_66
LBB13_59:                               ; %b16.i.i114
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #5                         ; =0x5
	b	LBB13_66
LBB13_60:                               ; %b22.i.i112
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #7                         ; =0x7
	b	LBB13_66
LBB13_61:                               ; %b7.i.i117
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #2                         ; =0x2
	b	LBB13_66
LBB13_62:                               ; %b10.i.i116
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #3                         ; =0x3
	b	LBB13_66
LBB13_63:                               ; %b28.i.i110
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #9                         ; =0x9
	b	LBB13_66
LBB13_64:                               ; %b25.i.i111
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #8                         ; =0x8
	b	LBB13_66
LBB13_65:                               ; %b36.i.i120
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w27, #6                         ; =0x6
LBB13_66:                               ; %liza___liza_reactor_error.exit.i107
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	x20, xzr
	mov	x22, xzr
	mov	x23, xzr
	mov	w8, #1                          ; =0x1
LBB13_67:                               ; %liza_net.reactor_accept.exit
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x28, [sp, #1480]                ; 8-byte Folded Reload
	cmp	w8, #1
	b.ne	LBB13_70
; %bb.68:                               ; %b45
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w21, #1                         ; =0x1
	add	x3, sp, #1, lsl #12             ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	lsl	w21, w21, w27
	add	x7, sp, #1, lsl #12             ; =4096
	add	x14, sp, #1, lsl #12            ; =4096
	add	x13, sp, #1, lsl #12            ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x17, sp, #1, lsl #12            ; =4096
	add	x9, sp, #1, lsl #12             ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x26, sp, #1, lsl #12            ; =4096
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	mov	w27, #3827                      ; =0xef3
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	add	x3, x3, #216
	add	x16, x16, #158
	add	x7, x7, #224
	add	x14, x14, #228
	add	x13, x13, #170
	add	x19, x19, #236
	add	x12, x12, #240
	add	x4, x4, #182
	add	x11, x11, #248
	add	x1, x1, #252
	add	x10, x10, #194
	add	x17, x17, #260
	add	x9, x9, #264
	add	x15, x15, #208
	add	x0, x0, #272
	add	x2, x2, #276
	add	x5, x5, #210
	add	x6, x6, #284
	add	x23, x23, #288
	add	x24, x24, #212
	add	x22, x22, #296
	add	x25, x25, #300
	add	x20, x20, #214
	add	x26, x26, #308
	tst	w21, w27
	b.eq	LBB13_316
; %bb.69:                               ;   in Loop: Header=BB13_26 Depth=1
	mov	w21, #3                         ; =0x3
	str	wzr, [sp, #1320]                ; 4-byte Folded Spill
	str	w21, [sp, #732]                 ; 4-byte Folded Spill
	b	LBB13_77
LBB13_70:                               ; %b49
                                        ;   in Loop: Header=BB13_26 Depth=1
	add	x2, sp, #1, lsl #12             ; =4096
	ldr	w1, [sp, #140]                  ; 4-byte Folded Reload
	mov	x0, x19
	add	x2, x2, #440
	bl	_liza_rt_reactor_connect
	cmp	w0, #12
	b.hi	LBB13_72
; %bb.71:                               ; %b49
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, w0
Lloh8:
	adrp	x11, lJTI13_3@PAGE
Lloh9:
	add	x11, x11, lJTI13_3@PAGEOFF
	adr	x9, LBB13_72
	ldrh	w10, [x11, x8, lsl #1]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_72:                               ; %liza___liza_reactor_error.exit.i134
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	x10, xzr
	mov	x9, xzr
	mov	x8, xzr
	mov	w11, #1                         ; =0x1
LBB13_73:                               ; %liza_net.reactor_connect.exit
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x27, [sp, #1472]                ; 8-byte Folded Reload
	ldr	w13, [sp, #1428]                ; 4-byte Folded Reload
	cmp	w11, #1
	ldr	w14, [sp, #1416]                ; 4-byte Folded Reload
	ldr	w15, [sp, #1408]                ; 4-byte Folded Reload
	ldr	w16, [sp, #1404]                ; 4-byte Folded Reload
	ldr	w17, [sp, #1388]                ; 4-byte Folded Reload
	ldr	w0, [sp, #1392]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1384]                 ; 4-byte Folded Reload
	b.ne	LBB13_75
; %bb.74:                               ; %b51
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	x0, x19
	mov	x1, x20
	mov	x2, x22
	mov	x3, x23
	bl	_liza_rt_reactor_disconnect
	ldr	w8, [sp, #412]                  ; 4-byte Folded Reload
	ldr	w13, [sp, #732]                 ; 4-byte Folded Reload
	add	x17, sp, #1, lsl #12            ; =4096
	ldrh	w9, [sp, #4310]
	ldrh	w10, [sp, #4308]
	add	x0, sp, #1, lsl #12             ; =4096
	tst	w8, #0x1
	mov	w8, #3                          ; =0x3
	ldrh	w11, [sp, #4306]
	csel	w13, w8, w13, ne
	ldr	w8, [sp, #408]                  ; 4-byte Folded Reload
	ldrh	w12, [sp, #4304]
	str	w13, [sp, #732]                 ; 4-byte Folded Spill
	ldrh	w14, [sp, #4290]
	ldrh	w13, [sp, #4278]
	ldrh	w15, [sp, #4266]
	add	x16, sp, #1, lsl #12            ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x3, sp, #1, lsl #12             ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x7, sp, #1, lsl #12             ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	ldrh	w6, [sp, #4254]
	add	x26, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x17, x17, #224
	add	x0, x0, #228
	add	x16, x16, #236
	add	x2, x2, #240
	add	x3, x3, #248
	add	x4, x4, #252
	add	x5, x5, #260
	add	x7, x7, #264
	add	x19, x19, #272
	add	x20, x20, #276
	add	x22, x22, #284
	add	x23, x23, #288
	add	x24, x24, #296
	add	x25, x25, #300
	add	x26, x26, #308
	add	x1, x1, #216
	str	w8, [sp, #1320]                 ; 4-byte Folded Spill
	b	LBB13_76
LBB13_75:                               ; %v101_ok
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w11, [sp, #1328]                ; 4-byte Folded Reload
	ldr	x26, [sp, #120]                 ; 8-byte Folded Reload
	mov	x30, x22
	ldr	x25, [sp, #112]                 ; 8-byte Folded Reload
	ldr	x24, [sp, #104]                 ; 8-byte Folded Reload
	mov	x6, x20
	str	w11, [sp, #3472]
	ldrh	w11, [sp, #4404]
	ldr	x2, [sp, #128]                  ; 8-byte Folded Reload
	ldr	x22, [sp, #96]                  ; 8-byte Folded Reload
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
	ldr	x5, [sp, #64]                   ; 8-byte Folded Reload
	strh	w11, [x26]
	ldr	w11, [sp, #1240]                ; 4-byte Folded Reload
	ldr	w12, [sp, #224]                 ; 4-byte Folded Reload
	ldr	x4, [sp, #56]                   ; 8-byte Folded Reload
	ldr	x3, [sp, #48]                   ; 8-byte Folded Reload
	strb	w16, [sp, #3848]
	str	w11, [sp, #3540]
	ldr	w11, [sp, #1232]                ; 4-byte Folded Reload
	ldr	x16, [sp, #32]                  ; 8-byte Folded Reload
	str	w12, [sp, #3476]
	ldr	x12, [sp, #240]                 ; 8-byte Folded Reload
	str	w11, [sp, #3544]
	ldr	w11, [sp, #400]                 ; 4-byte Folded Reload
	str	x12, [sp, #3480]
	ldr	x12, [sp, #1296]                ; 8-byte Folded Reload
	strb	w11, [sp, #3548]
	ldrh	w11, [sp, #4310]
	str	x12, [sp, #3488]
	ldr	x12, [sp, #1288]                ; 8-byte Folded Reload
	strh	w11, [sp, #3550]
	ldr	w11, [sp, #1224]                ; 4-byte Folded Reload
	str	x12, [sp, #3496]
	ldr	w12, [sp, #312]                 ; 4-byte Folded Reload
	str	w11, [sp, #3552]
	ldr	w11, [sp, #1220]                ; 4-byte Folded Reload
	str	w12, [sp, #3504]
	ldr	w12, [sp, #220]                 ; 4-byte Folded Reload
	str	w11, [sp, #3556]
	ldr	w11, [sp, #396]                 ; 4-byte Folded Reload
	str	w12, [sp, #3508]
	ldr	x12, [sp, #1280]                ; 8-byte Folded Reload
	strb	w11, [sp, #3560]
	ldr	w11, [sp, #4396]
	str	x12, [sp, #3512]
	ldr	x12, [sp, #1272]                ; 8-byte Folded Reload
	str	w11, [x25]
	ldr	w11, [sp, #1496]                ; 4-byte Folded Reload
	str	x12, [sp, #3520]
	ldr	x12, [sp, #1248]                ; 8-byte Folded Reload
	str	w11, [sp, #3568]
	ldr	w11, [sp, #216]                 ; 4-byte Folded Reload
	str	x12, [sp, #3528]
	ldr	w12, [sp, #784]                 ; 4-byte Folded Reload
	str	w11, [sp, #3572]
	ldr	x11, [sp, #1200]                ; 8-byte Folded Reload
	strb	w12, [sp, #3536]
	add	x12, sp, #311
	str	x11, [sp, #3576]
	ldr	x11, [sp, #1208]                ; 8-byte Folded Reload
	ldrb	w12, [x12, #4095]
	strb	w13, [sp, #3836]
	add	x13, sp, #17
	str	x11, [sp, #3584]
	ldr	x11, [sp, #1192]                ; 8-byte Folded Reload
	strb	w12, [x26, #2]
	ldr	w12, [sp, #404]                 ; 4-byte Folded Reload
	str	x11, [sp, #3592]
	ldr	w11, [sp, #264]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3549]
	ldr	w12, [sp, #392]                 ; 4-byte Folded Reload
	str	w11, [sp, #3600]
	ldr	w11, [sp, #212]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3561]
	ldrh	w12, [sp, #4400]
	str	w11, [sp, #3604]
	ldr	x11, [sp, #1008]                ; 8-byte Folded Reload
	strh	w12, [x25, #4]
	ldr	w12, [sp, #268]                 ; 4-byte Folded Reload
	str	x11, [sp, #3608]
	ldr	x11, [sp, #1016]                ; 8-byte Folded Reload
	strb	w12, [sp, #3632]
	ldrh	w12, [sp, #4392]
	str	x11, [sp, #3616]
	ldr	x11, [sp, #984]                 ; 8-byte Folded Reload
	strh	w12, [x24]
	ldr	w12, [sp, #280]                 ; 4-byte Folded Reload
	str	x11, [sp, #3624]
	add	x11, sp, #299
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3645]
	ldr	w12, [sp, #284]                 ; 4-byte Folded Reload
	str	w0, [sp, #3888]
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	strb	w11, [x24, #2]
	ldr	w11, [sp, #1136]                ; 4-byte Folded Reload
	strb	w12, [sp, #3657]
	ldr	w12, [sp, #4384]
	str	w11, [sp, #3636]
	ldr	w11, [sp, #1144]                ; 4-byte Folded Reload
	str	w12, [x2]
	ldr	w12, [sp, #288]                 ; 4-byte Folded Reload
	str	w11, [sp, #3640]
	ldr	w11, [sp, #272]                 ; 4-byte Folded Reload
	strb	w12, [sp, #3728]
	ldrh	w12, [sp, #4380]
	strb	w11, [sp, #3644]
	ldrh	w11, [sp, #4308]
	strh	w12, [x22]
	ldr	w12, [sp, #300]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3646]
	ldr	w11, [sp, #1148]                ; 4-byte Folded Reload
	strb	w12, [sp, #3741]
	ldr	w12, [sp, #304]                 ; 4-byte Folded Reload
	str	w11, [sp, #3648]
	ldr	w11, [sp, #1152]                ; 4-byte Folded Reload
	strb	w12, [sp, #3753]
	ldr	w12, [sp, #4372]
	str	w11, [sp, #3652]
	ldr	w11, [sp, #276]                 ; 4-byte Folded Reload
	str	w12, [x20]
	ldr	w12, [sp, #308]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3656]
	ldrh	w11, [sp, #4388]
	strb	w12, [sp, #3824]
	ldrh	w12, [sp, #4244]
	strh	w11, [x2, #4]
	ldr	w11, [sp, #1344]                ; 4-byte Folded Reload
	ldr	x2, [sp, #40]                   ; 8-byte Folded Reload
	strb	w14, [sp, #3837]
	add	x14, sp, #42
	str	w11, [sp, #3664]
	ldr	w11, [sp, #204]                 ; 4-byte Folded Reload
	str	w17, [sp, #3860]
	ldr	x17, [sp, #16]                  ; 8-byte Folded Reload
	str	w11, [sp, #3668]
	ldr	x11, [sp, #960]                 ; 8-byte Folded Reload
	str	w1, [sp, #3892]
	ldr	x1, [sp, #8]                    ; 8-byte Folded Reload
	str	x11, [sp, #3672]
	ldr	x11, [sp, #968]                 ; 8-byte Folded Reload
	strb	w15, [sp, #3849]
	ldp	x7, x19, [sp, #72]              ; 16-byte Folded Reload
	str	x11, [sp, #3680]
	ldr	x11, [sp, #976]                 ; 8-byte Folded Reload
	str	x27, [sp, #3904]
	str	x11, [sp, #3688]
	ldr	w11, [sp, #228]                 ; 4-byte Folded Reload
	strh	w12, [x19]
	ldr	w12, [sp, #4296]
	str	w11, [sp, #3696]
	ldr	w11, [sp, #208]                 ; 4-byte Folded Reload
	str	w12, [x7]
	ldr	w12, [sp, #232]                 ; 4-byte Folded Reload
	str	w11, [sp, #3700]
	ldr	x11, [sp, #936]                 ; 8-byte Folded Reload
	strb	w12, [sp, #3920]
	ldrh	w12, [sp, #4292]
	str	x11, [sp, #3704]
	ldr	x11, [sp, #944]                 ; 8-byte Folded Reload
	strh	w12, [x5]
	ldr	w12, [sp, #324]                 ; 4-byte Folded Reload
	str	x11, [sp, #3712]
	ldr	x11, [sp, #952]                 ; 8-byte Folded Reload
	strb	w12, [sp, #3933]
	ldr	w12, [sp, #328]                 ; 4-byte Folded Reload
	str	x11, [sp, #3720]
	add	x11, sp, #287
	ldrb	w11, [x11, #4095]
	strb	w12, [sp, #3945]
	ldr	w12, [sp, #4284]
	str	x28, [sp, #3912]
	strb	w11, [x22, #2]
	ldr	w11, [sp, #1112]                ; 4-byte Folded Reload
	str	w12, [x4]
	ldr	w12, [sp, #332]                 ; 4-byte Folded Reload
	str	w11, [sp, #3732]
	ldr	w11, [sp, #1116]                ; 4-byte Folded Reload
	strb	w12, [sp, #4016]
	ldrh	w12, [sp, #4280]
	str	w11, [sp, #3736]
	ldr	w11, [sp, #292]                 ; 4-byte Folded Reload
	strh	w12, [x3]
	ldr	w12, [sp, #344]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3740]
	ldrh	w11, [sp, #4306]
	strb	w12, [sp, #4029]
	ldr	w12, [sp, #348]                 ; 4-byte Folded Reload
	strh	w11, [sp, #3742]
	ldr	w11, [sp, #1120]                ; 4-byte Folded Reload
	strb	w12, [sp, #4041]
	ldr	w12, [sp, #4272]
	str	w11, [sp, #3744]
	ldr	w11, [sp, #1132]                ; 4-byte Folded Reload
	str	w12, [x2]
	ldr	w12, [sp, #352]                 ; 4-byte Folded Reload
	str	w11, [sp, #3748]
	ldr	w11, [sp, #296]                 ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	add	x13, sp, #30
	ldrh	w12, [sp, #4268]
	strb	w11, [sp, #3752]
	ldrh	w11, [sp, #4376]
	strh	w12, [x16]
	add	x12, sp, #29
	strh	w11, [x20, #4]
	ldr	w11, [sp, #1352]                ; 4-byte Folded Reload
	str	w11, [sp, #3760]
	ldr	w11, [sp, #196]                 ; 4-byte Folded Reload
	str	w11, [sp, #3764]
	ldr	x11, [sp, #912]                 ; 8-byte Folded Reload
	str	x11, [sp, #3768]
	ldr	x11, [sp, #920]                 ; 8-byte Folded Reload
	str	x11, [sp, #3776]
	ldr	x11, [sp, #928]                 ; 8-byte Folded Reload
	str	x11, [sp, #3784]
	ldr	w11, [sp, #260]                 ; 4-byte Folded Reload
	str	w11, [sp, #3792]
	ldr	w11, [sp, #200]                 ; 4-byte Folded Reload
	str	w11, [sp, #3796]
	ldr	x11, [sp, #888]                 ; 8-byte Folded Reload
	str	x11, [sp, #3800]
	ldr	x11, [sp, #896]                 ; 8-byte Folded Reload
	str	x11, [sp, #3808]
	ldr	x11, [sp, #904]                 ; 8-byte Folded Reload
	str	x11, [sp, #3816]
	add	x11, sp, #151
	ldrb	w11, [x11, #4095]
	strb	w11, [x19, #2]
	ldr	w11, [sp, #1076]                ; 4-byte Folded Reload
	str	w11, [sp, #3828]
	ldr	w11, [sp, #1080]                ; 4-byte Folded Reload
	str	w11, [sp, #3832]
	ldrh	w11, [sp, #4304]
	strh	w11, [sp, #3838]
	ldr	w11, [sp, #1468]                ; 4-byte Folded Reload
	str	w11, [sp, #3840]
	ldr	w11, [sp, #1464]                ; 4-byte Folded Reload
	str	w11, [sp, #3844]
	ldrh	w11, [sp, #4300]
	strh	w11, [x7, #4]
	ldr	w11, [sp, #1492]                ; 4-byte Folded Reload
	str	w11, [sp, #3856]
	ldr	x11, [sp, #1456]                ; 8-byte Folded Reload
	str	x11, [sp, #3864]
	ldr	x11, [sp, #1448]                ; 8-byte Folded Reload
	str	x11, [sp, #3872]
	ldr	x11, [sp, #1440]                ; 8-byte Folded Reload
	str	x11, [sp, #3880]
	ldr	x11, [sp, #1432]                ; 8-byte Folded Reload
	str	x11, [sp, #3896]
	add	x11, sp, #199
	ldrb	w11, [x11, #4095]
	strb	w11, [x5, #2]
	ldr	w11, [sp, #1176]                ; 4-byte Folded Reload
	str	w11, [sp, #3924]
	ldr	w11, [sp, #1184]                ; 4-byte Folded Reload
	str	w11, [sp, #3928]
	ldr	w11, [sp, #316]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3932]
	ldrh	w11, [sp, #4290]
	strh	w11, [sp, #3934]
	ldr	w11, [sp, #1188]                ; 4-byte Folded Reload
	str	w11, [sp, #3936]
	ldr	w11, [sp, #236]                 ; 4-byte Folded Reload
	str	w11, [sp, #3940]
	ldr	w11, [sp, #320]                 ; 4-byte Folded Reload
	strb	w11, [sp, #3944]
	ldrh	w11, [sp, #4288]
	strh	w11, [x4, #4]
	ldr	w11, [sp, #1364]                ; 4-byte Folded Reload
	str	w11, [sp, #3952]
	ldr	w11, [sp, #188]                 ; 4-byte Folded Reload
	str	w11, [sp, #3956]
	ldr	x11, [sp, #1088]                ; 8-byte Folded Reload
	str	x11, [sp, #3960]
	ldr	x11, [sp, #1096]                ; 8-byte Folded Reload
	str	x11, [sp, #3968]
	ldr	x11, [sp, #1104]                ; 8-byte Folded Reload
	str	x11, [sp, #3976]
	ldr	w11, [sp, #256]                 ; 4-byte Folded Reload
	str	w11, [sp, #3984]
	ldr	w11, [sp, #192]                 ; 4-byte Folded Reload
	str	w11, [sp, #3988]
	ldr	x11, [sp, #1048]                ; 8-byte Folded Reload
	str	x11, [sp, #3992]
	ldr	x11, [sp, #1056]                ; 8-byte Folded Reload
	str	x11, [sp, #4000]
	ldr	x11, [sp, #1064]                ; 8-byte Folded Reload
	str	x11, [sp, #4008]
	add	x11, sp, #187
	ldrb	w11, [x11, #4095]
	strb	w11, [x3, #2]
	ldr	w11, [sp, #1156]                ; 4-byte Folded Reload
	str	w11, [sp, #4020]
	ldr	w11, [sp, #1160]                ; 4-byte Folded Reload
	str	w11, [sp, #4024]
	ldr	w11, [sp, #336]                 ; 4-byte Folded Reload
	strb	w11, [sp, #4028]
	ldrh	w11, [sp, #4278]
	strh	w11, [sp, #4030]
	ldr	w11, [sp, #1164]                ; 4-byte Folded Reload
	str	w11, [sp, #4032]
	ldr	w11, [sp, #1168]                ; 4-byte Folded Reload
	str	w11, [sp, #4036]
	ldr	w11, [sp, #340]                 ; 4-byte Folded Reload
	strb	w11, [sp, #4040]
	ldrh	w11, [sp, #4276]
	strh	w11, [x2, #4]
	ldr	w11, [sp, #1368]                ; 4-byte Folded Reload
	str	w11, [sp, #4048]
	ldr	w11, [sp, #180]                 ; 4-byte Folded Reload
	str	w11, [sp, #4052]
	ldr	x11, [sp, #864]                 ; 8-byte Folded Reload
	str	x11, [sp, #4056]
	ldr	x11, [sp, #872]                 ; 8-byte Folded Reload
	str	x11, [sp, #4064]
	ldr	x11, [sp, #880]                 ; 8-byte Folded Reload
	str	x11, [sp, #4072]
	ldr	w11, [sp, #252]                 ; 4-byte Folded Reload
	str	w11, [sp, #4080]
	ldr	w11, [sp, #184]                 ; 4-byte Folded Reload
	str	w11, [sp, #4084]
	ldr	x11, [sp, #832]                 ; 8-byte Folded Reload
	str	x11, [sp, #4088]
	ldr	x11, [sp, #840]                 ; 8-byte Folded Reload
	str	x11, [sp, #4096]
	ldr	x11, [sp, #848]                 ; 8-byte Folded Reload
	str	x11, [sp, #4104]
	add	x11, sp, #175
	ldrb	w11, [x11, #4095]
	strb	w11, [x16, #2]
	ldr	w11, [sp, #1032]                ; 4-byte Folded Reload
	str	w11, [sp, #4116]
	ldr	w11, [sp, #1036]                ; 4-byte Folded Reload
	str	w11, [sp, #4120]
	ldr	w11, [sp, #356]                 ; 4-byte Folded Reload
	strb	w11, [x12, #4095]
	ldrh	w11, [sp, #4266]
	ldr	w12, [sp, #360]                 ; 4-byte Folded Reload
	strh	w11, [sp, #4126]
	ldr	w11, [sp, #1040]                ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #364]                 ; 4-byte Folded Reload
	add	x13, sp, #41
	str	w11, [sp, #4128]
	ldr	w11, [sp, #1044]                ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #4260]
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	str	w11, [sp, #4132]
	ldrh	w11, [sp, #4264]
	str	w12, [x0]
	ldr	x12, [sp, #856]                 ; 8-byte Folded Reload
	strh	w11, [x0, #4]
	ldr	w11, [sp, #1380]                ; 4-byte Folded Reload
	str	x12, [sp, #4200]
	ldrh	w12, [sp, #4256]
	str	w11, [sp, #4144]
	ldr	w11, [sp, #172]                 ; 4-byte Folded Reload
	strb	w13, [x14, #4095]
	ldr	w13, [sp, #372]                 ; 4-byte Folded Reload
	add	x14, sp, #113
	str	w11, [sp, #4148]
	ldr	x11, [sp, #808]                 ; 8-byte Folded Reload
	strh	w12, [x17]
	ldr	w12, [sp, #376]                 ; 4-byte Folded Reload
	str	x11, [sp, #4152]
	ldr	x11, [sp, #816]                 ; 8-byte Folded Reload
	strb	w13, [x14, #4095]
	add	x13, sp, #125
	add	x14, sp, #138
	str	x11, [sp, #4160]
	ldr	x11, [sp, #824]                 ; 8-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #380]                 ; 4-byte Folded Reload
	add	x13, sp, #126
	str	x11, [sp, #4168]
	ldr	w11, [sp, #248]                 ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w12, [sp, #384]                 ; 4-byte Folded Reload
	add	x13, sp, #137
	str	w11, [sp, #4176]
	ldr	w11, [sp, #176]                 ; 4-byte Folded Reload
	strb	w12, [x13, #4095]
	ldr	w13, [sp, #388]                 ; 4-byte Folded Reload
	ldr	w12, [sp, #4248]
	str	w11, [sp, #4180]
	ldr	x11, [sp, #792]                 ; 8-byte Folded Reload
	strb	w13, [x14, #4095]
	add	x13, sp, #3472
	mov	w14, #96                        ; =0x60
	str	x11, [sp, #4184]
	ldr	x11, [sp, #800]                 ; 8-byte Folded Reload
	umaddl	x13, w21, w14, x13
	str	w12, [x1]
	str	x11, [sp, #4192]
	add	x11, sp, #163
	ldrb	w11, [x11, #4095]
	strb	wzr, [x13, #64]
	strb	w11, [x17, #2]
	ldr	w11, [sp, #996]                 ; 4-byte Folded Reload
	str	wzr, [x13]
	str	w11, [sp, #4212]
	ldr	w11, [sp, #1000]                ; 4-byte Folded Reload
	str	wzr, [x13, #32]
	str	w11, [sp, #4216]
	ldrh	w11, [sp, #4254]
	strh	wzr, [x13, #76]
	strh	w11, [sp, #4222]
	ldr	w11, [sp, #1028]                ; 4-byte Folded Reload
	stur	xzr, [x13, #68]
	str	w11, [sp, #4224]
	ldr	w11, [sp, #1004]                ; 4-byte Folded Reload
	str	w11, [sp, #4228]
	ldrh	w11, [sp, #4252]
	stp	x10, x9, [x13, #40]
	ldr	w10, [sp, #3472]
	strh	w11, [x1, #4]
	ldr	w11, [sp, #3668]
	str	x8, [x13, #56]
	ldr	w8, [sp, #3504]
	str	w10, [sp, #1328]                ; 4-byte Folded Spill
	ldr	w10, [sp, #3476]
	str	w8, [sp, #312]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3508]
	stp	x6, x30, [x13, #8]
	stp	w8, w10, [sp, #220]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3512]
	ldr	w10, [sp, #3572]
	str	x23, [x13, #24]
	ldr	x9, [sp, #3480]
	ldrh	w12, [sp, #3838]
	str	x8, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3520]
	ldrh	w14, [sp, #3934]
	strh	wzr, [x13, #88]
	ldrh	w15, [sp, #4126]
	ldrh	w6, [sp, #4222]
	str	x8, [sp, #1272]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3528]
	ldr	x28, [sp, #3912]
	str	xzr, [x13, #80]
	ldrh	w13, [sp, #4030]
	ldr	x23, [sp, #128]                 ; 8-byte Folded Reload
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3536]
	ldr	x27, [sp, #3904]
	str	x9, [sp, #240]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #3488]
	str	w8, [sp, #784]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3540]
	str	x9, [sp, #1296]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #3496]
	str	w8, [sp, #1240]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3544]
	str	x9, [sp, #1288]                 ; 8-byte Folded Spill
	ldrh	w9, [sp, #3550]
	str	w8, [sp, #1232]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3548]
	str	w8, [sp, #400]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3549]
	str	w8, [sp, #404]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3552]
	str	w8, [sp, #1224]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3556]
	str	w8, [sp, #1220]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3560]
	str	w8, [sp, #396]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3561]
	str	w8, [sp, #392]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3568]
	str	w8, [sp, #1496]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3576]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3584]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3592]
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3600]
	str	w8, [sp, #264]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3604]
	stp	w8, w10, [sp, #212]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3608]
	ldrh	w10, [sp, #3646]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3616]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3624]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3632]
	str	w8, [sp, #268]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3636]
	str	w8, [sp, #1136]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3640]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3644]
	str	w8, [sp, #272]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3645]
	str	w8, [sp, #280]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3648]
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3652]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3656]
	str	w8, [sp, #276]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3657]
	str	w8, [sp, #284]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3664]
	str	w8, [sp, #1344]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3672]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3680]
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3688]
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3696]
	str	w8, [sp, #228]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3700]
	stp	w11, w8, [sp, #204]             ; 8-byte Folded Spill
	ldr	x8, [sp, #3704]
	ldrh	w11, [sp, #3742]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3712]
	str	x8, [sp, #944]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3720]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3728]
	str	w8, [sp, #288]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3732]
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3736]
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3740]
	str	w8, [sp, #292]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3741]
	str	w8, [sp, #300]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3744]
	str	w8, [sp, #1120]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3748]
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3752]
	str	w8, [sp, #296]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3753]
	str	w8, [sp, #304]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3760]
	str	w8, [sp, #1352]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3764]
	str	w8, [sp, #196]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3768]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3776]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3784]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #3792]
	str	w8, [sp, #260]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3796]
	str	w8, [sp, #200]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3800]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3808]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3816]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3824]
	str	w8, [sp, #308]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3828]
	str	w8, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3832]
	str	w8, [sp, #1080]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3836]
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3837]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3840]
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3844]
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3848]
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3849]
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3856]
	str	w8, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3860]
	str	w8, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3864]
	str	x8, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3872]
	str	x8, [sp, #1448]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3880]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3888]
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3892]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3896]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #3920]
	str	w8, [sp, #232]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3924]
	str	w8, [sp, #1176]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3928]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #3932]
	str	w8, [sp, #316]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3933]
	str	w8, [sp, #324]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3936]
	str	w8, [sp, #1188]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3940]
	str	w8, [sp, #236]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3944]
	str	w8, [sp, #320]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3945]
	str	w8, [sp, #328]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3952]
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #3956]
	str	w8, [sp, #188]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3960]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3968]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3976]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #3984]
	str	w8, [sp, #256]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #3988]
	str	w8, [sp, #192]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3992]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4000]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4008]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #4016]
	str	w8, [sp, #332]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4020]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4024]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #4028]
	str	w8, [sp, #336]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #4029]
	str	w8, [sp, #344]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4032]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4036]
	str	w8, [sp, #1168]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #4040]
	str	w8, [sp, #340]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #4041]
	str	w8, [sp, #348]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4048]
	str	w8, [sp, #1368]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4052]
	str	w8, [sp, #180]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4056]
	str	x8, [sp, #864]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4064]
	str	x8, [sp, #872]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4072]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #4080]
	str	w8, [sp, #252]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4084]
	str	w8, [sp, #184]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4088]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4096]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4104]
	str	x8, [sp, #848]                  ; 8-byte Folded Spill
	add	x8, sp, #17
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4116]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4120]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	add	x8, sp, #29
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #356]                  ; 4-byte Folded Spill
	add	x8, sp, #30
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #360]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4128]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4132]
	str	w8, [sp, #1044]                 ; 4-byte Folded Spill
	add	x8, sp, #41
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #364]                  ; 4-byte Folded Spill
	add	x8, sp, #42
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #368]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4144]
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4148]
	str	w8, [sp, #172]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4152]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4160]
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4168]
	str	x8, [sp, #824]                  ; 8-byte Folded Spill
	ldr	w8, [sp, #4176]
	str	w8, [sp, #248]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4180]
	str	w8, [sp, #176]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #4184]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4192]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #4200]
	str	x8, [sp, #856]                  ; 8-byte Folded Spill
	add	x8, sp, #113
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #372]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4212]
	str	w8, [sp, #996]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4216]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	add	x8, sp, #125
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #376]                  ; 4-byte Folded Spill
	add	x8, sp, #126
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #380]                  ; 4-byte Folded Spill
	ldr	w8, [sp, #4224]
	str	w8, [sp, #1028]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #4228]
	str	w8, [sp, #1004]                 ; 4-byte Folded Spill
	add	x8, sp, #137
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #384]                  ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1320]                 ; 4-byte Folded Spill
	add	x8, sp, #138
	ldrb	w8, [x8, #4095]
	str	w8, [sp, #388]                  ; 4-byte Folded Spill
LBB13_76:                               ; %b56_to_b57
                                        ;   in Loop: Header=BB13_26 Depth=1
	strh	w9, [sp, #3466]
	ldr	w9, [x25]
	ldrh	w21, [x26]
	strh	w10, [sp, #3454]
	ldrh	w10, [x23, #4]
	ldrb	w26, [x26, #2]
	str	w9, [sp, #3460]
	ldrh	w9, [x24]
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	strh	w10, [sp, #3452]
	ldrh	w10, [x22]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	strh	w9, [sp, #3456]
	ldr	w9, [x23]
	add	x23, sp, #3448
	strh	w10, [sp, #3444]
	ldr	w10, [x20]
	str	w9, [sp, #3448]
	ldrb	w9, [x22, #2]
	ldrh	w22, [x1, #4]
	str	w10, [sp, #3436]
	ldrh	w10, [x19]
	strb	w9, [sp, #3446]
	ldrh	w9, [x20, #4]
	ldrb	w20, [x17, #2]
	strh	w10, [sp, #3432]
	ldr	w10, [x7]
	strh	w9, [sp, #3440]
	ldrb	w9, [x19, #2]
	add	x19, sp, #3396
	str	w10, [sp, #3424]
	ldrh	w10, [x5]
	strb	w9, [sp, #3434]
	ldrh	w9, [x7, #4]
	add	x7, sp, #3384
	strh	w21, [sp, #3468]
	ldrh	w21, [x25, #4]
	add	x25, sp, #3460
	strh	w9, [sp, #3428]
	ldrb	w9, [x5, #2]
	ldrh	w5, [x17]
	add	x17, sp, #3420
	strh	w10, [sp, #3420]
	ldr	w10, [x4]
	strh	w12, [sp, #3430]
	ldrb	w12, [x3, #2]
	strb	w9, [sp, #3422]
	ldrh	w9, [x4, #4]
	add	x4, sp, #3406
	strh	w21, [sp, #3464]
	ldrb	w21, [x24, #2]
	add	x24, sp, #3454
	str	w10, [sp, #3412]
	mov	w10, #1                         ; =0x1
	strh	w11, [sp, #3442]
	ldrh	w11, [x3]
	add	x3, sp, #3376
	strh	w14, [sp, #3418]
	ldrh	w14, [x2, #4]
	strh	w9, [sp, #3416]
	ldr	w9, [x2]
	ldr	w2, [x0]
	str	w10, [sp, #156]                 ; 4-byte Folded Spill
	ldrh	w10, [x16]
	ldrh	w0, [x0, #4]
	strb	w12, [sp, #3410]
	ldrb	w12, [x16, #2]
	add	x16, sp, #3382
	strb	w21, [sp, #3458]
	ldr	w21, [x1]
	add	x1, sp, #3412
	strb	w26, [sp, #3470]
	add	x26, sp, #3468
	strh	w11, [sp, #3408]
	add	x11, sp, #3408
	strh	w13, [sp, #3406]
	add	x13, sp, #3394
	strh	w14, [sp, #3404]
	add	x14, sp, #3388
	str	w9, [sp, #3400]
	add	x9, sp, #3424
	strb	w12, [sp, #3398]
	add	x12, sp, #3400
	strh	w10, [sp, #3396]
	add	x10, sp, #3418
	strh	w15, [sp, #3394]
	add	x15, sp, #3430
	strh	w0, [sp, #3392]
	add	x0, sp, #3432
	str	w2, [sp, #3388]
	add	x2, sp, #3436
	strb	w20, [sp, #3386]
	add	x20, sp, #3466
	strh	w5, [sp, #3384]
	add	x5, sp, #3442
	strh	w6, [sp, #3382]
	add	x6, sp, #3444
	strh	w22, [sp, #3380]
	add	x22, sp, #3456
	str	x28, [sp, #1480]                ; 8-byte Folded Spill
	str	x27, [sp, #1472]                ; 8-byte Folded Spill
	str	w21, [sp, #3376]
LBB13_77:                               ; %b57_to_b58
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldrh	w20, [x20]
	ldrh	w21, [x26]
	add	x27, sp, #3364
	ldrh	w5, [x5]
	ldrb	w26, [x26, #2]
	add	x28, sp, #3372
	strh	w20, [sp, #3370]
	ldrh	w20, [x25, #4]
	ldrh	w15, [x15]
	strh	w21, [sp, #3372]
	ldr	w21, [x25]
	add	x25, sp, #3352
	strh	w20, [sp, #3368]
	ldrb	w20, [x22, #2]
	str	w21, [sp, #3364]
	ldrh	w21, [x22]
	ldrh	w22, [x24]
	add	x24, sp, #3340
	strb	w20, [sp, #3362]
	ldr	w20, [x23]
	strh	w21, [sp, #3360]
	ldrh	w21, [x23, #4]
	add	x23, sp, #3336
	str	w20, [sp, #3352]
	ldrh	w20, [x6]
	ldrb	w6, [x6, #2]
	strh	w5, [sp, #3346]
	ldrb	w5, [x0, #2]
	ldrh	w0, [x0]
	strh	w20, [sp, #3348]
	ldrh	w20, [x4]
	add	x4, sp, #3312
	strb	w6, [sp, #3350]
	ldrh	w6, [x2, #4]
	ldr	w2, [x2]
	strh	w20, [sp, #3310]
	ldr	w20, [x12]
	strh	w21, [sp, #3356]
	ldrb	w21, [x19, #2]
	str	w20, [sp, #3304]
	ldrh	w20, [x19]
	add	x19, sp, #3328
	str	w2, [sp, #3340]
	ldr	w2, [x9]
	strb	w5, [sp, #3338]
	ldrh	w5, [x10]
	add	x10, sp, #3298
	strb	w21, [sp, #3302]
	ldr	w21, [x14]
	strh	w20, [sp, #3300]
	ldrh	w20, [x14, #4]
	strh	w22, [sp, #3358]
	ldrh	w22, [x13]
	add	x13, sp, #3346
	strh	w6, [sp, #3344]
	ldrb	w6, [x11, #2]
	strh	w0, [sp, #3336]
	ldrh	w0, [x9, #4]
	add	x9, sp, #3286
	str	w2, [sp, #3328]
	ldrh	w2, [x17]
	strh	w5, [sp, #3322]
	ldr	w5, [x1]
	strh	w20, [sp, #3296]
	ldrb	w20, [x7, #2]
	str	w21, [sp, #3292]
	ldrh	w21, [x7]
	add	x7, sp, #3348
	strh	w0, [sp, #3332]
	ldrb	w0, [x17, #2]
	add	x17, sp, #3288
	strh	w2, [sp, #3324]
	ldrh	w2, [x1, #4]
	add	x1, sp, #3300
	str	w5, [sp, #3316]
	ldrh	w5, [x11]
	add	x11, sp, #3310
	strb	w6, [sp, #3314]
	ldrh	w6, [x12, #4]
	add	x12, sp, #3322
	strh	w22, [sp, #3298]
	ldrh	w22, [x16]
	add	x16, sp, #3358
	str	x9, [sp, #160]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #712]                  ; 8-byte Folded Reload
	strb	w20, [sp, #3290]
	ldrh	w20, [x3, #4]
	strh	w21, [sp, #3288]
	ldr	w21, [x3]
	add	x3, sp, #3370
	strb	w26, [sp, #3374]
	add	x26, sp, #3360
	strh	w15, [sp, #3334]
	add	x15, sp, #3280
	strb	w0, [sp, #3326]
	add	x0, sp, #3292
	strh	w2, [sp, #3320]
	add	x2, sp, #3304
	strh	w5, [sp, #3312]
	add	x5, sp, #3316
	strh	w6, [sp, #3308]
	add	x6, sp, #3324
	strh	w22, [sp, #3286]
	add	x22, sp, #3334
	strh	w20, [sp, #3284]
	str	w21, [sp, #3280]
LBB13_78:                               ; %b58_to_b59
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	w20, [sp, #1328]                ; 4-byte Folded Reload
	str	x8, [sp, #2424]
	ldr	x8, [sp, #1296]                 ; 8-byte Folded Reload
	ldrb	w21, [x28, #2]
	ldrh	w14, [x13]
	ldrh	w12, [x12]
	str	w20, [sp, #2416]
	ldrh	w20, [x28]
	ldrh	w11, [x11]
	str	x8, [sp, #2432]
	ldr	x8, [sp, #1288]                 ; 8-byte Folded Reload
	ldrh	w13, [x22]
	mov	x22, x9
	strh	w20, [sp, #3276]
	ldr	w20, [x27]
	str	x8, [sp, #2440]
	ldr	w8, [sp, #312]                  ; 4-byte Folded Reload
	ldrh	w10, [x10]
	str	w20, [sp, #3268]
	ldrb	w20, [x26, #2]
	str	w8, [sp, #2448]
	ldr	w8, [sp, #220]                  ; 4-byte Folded Reload
	strb	w20, [sp, #3266]
	ldr	w20, [x25]
	str	w8, [sp, #2452]
	ldr	x8, [sp, #1280]                 ; 8-byte Folded Reload
	str	w20, [sp, #3256]
	ldrh	w20, [x7]
	ldrb	w7, [x7, #2]
	str	x8, [sp, #2456]
	ldr	x8, [sp, #1272]                 ; 8-byte Folded Reload
	strb	w7, [sp, #3254]
	ldrh	w7, [x24, #4]
	strh	w20, [sp, #3252]
	ldr	w20, [x24]
	strh	w7, [sp, #3248]
	ldrh	w7, [x23]
	str	w20, [sp, #3244]
	ldrb	w20, [x23, #2]
	ldr	x23, [sp, #624]                 ; 8-byte Folded Reload
	strh	w7, [sp, #3240]
	ldr	w7, [x19]
	strb	w20, [sp, #3242]
	ldrh	w20, [x19, #4]
	ldrb	w19, [x6, #2]
	str	w7, [sp, #3232]
	ldrh	w7, [x5, #4]
	ldr	w5, [x5]
	ldrh	w6, [x6]
	strb	w19, [sp, #3230]
	str	w5, [sp, #3220]
	ldrh	w5, [x2, #4]
	ldr	w2, [x2]
	strh	w6, [sp, #3228]
	ldrb	w6, [x4, #2]
	ldrh	w4, [x4]
	str	w2, [sp, #3208]
	ldrh	w2, [x0, #4]
	ldr	w0, [x0]
	strh	w4, [sp, #3216]
	ldrb	w4, [x1, #2]
	ldrh	w1, [x1]
	str	w0, [sp, #3196]
	ldrh	w0, [x15, #4]
	ldr	w15, [x15]
	strh	w1, [sp, #3204]
	ldrb	w1, [x17, #2]
	ldrh	w17, [x17]
	str	w15, [sp, #3184]
	ldrh	w15, [sp, #3228]
	strh	w17, [sp, #3192]
	ldrb	w17, [sp, #3230]
	strh	w15, [sp, #2412]
	ldr	w15, [sp, #3220]
	strh	w7, [sp, #3224]
	ldr	x7, [sp, #600]                  ; 8-byte Folded Reload
	strb	w17, [sp, #2414]
	ldrh	w17, [sp, #3224]
	str	w15, [sp, #2404]
	ldrh	w15, [sp, #3216]
	strb	w6, [sp, #3218]
	ldr	x6, [sp, #648]                  ; 8-byte Folded Reload
	strh	w17, [sp, #2408]
	ldrb	w17, [sp, #3218]
	strh	w15, [sp, #2400]
	ldr	w15, [sp, #3208]
	strh	w5, [sp, #3212]
	strb	w17, [sp, #2402]
	ldrh	w17, [sp, #3212]
	str	w15, [sp, #2392]
	ldrh	w15, [sp, #3204]
	strb	w4, [sp, #3206]
	strh	w17, [sp, #2396]
	ldrb	w17, [sp, #3206]
	strh	w15, [sp, #2388]
	ldr	w15, [sp, #3196]
	strh	w2, [sp, #3200]
	strb	w17, [sp, #2390]
	ldrh	w17, [sp, #3200]
	str	w15, [sp, #2380]
	ldrh	w15, [sp, #3192]
	strb	w1, [sp, #3194]
	strh	w17, [sp, #2384]
	ldrb	w17, [sp, #3194]
	strh	w15, [sp, #2376]
	ldr	w15, [sp, #3184]
	str	x8, [sp, #2464]
	ldr	x8, [sp, #1248]                 ; 8-byte Folded Reload
	strh	w0, [sp, #3188]
	strb	w17, [sp, #2378]
	ldrh	w17, [sp, #3188]
	str	w15, [sp, #2368]
	ldr	w15, [sp, #224]                 ; 4-byte Folded Reload
	str	x8, [sp, #2472]
	ldr	w8, [sp, #784]                  ; 4-byte Folded Reload
	strb	w21, [sp, #3278]
	ldrh	w21, [x27, #4]
	strh	w17, [sp, #2372]
	ldrh	w17, [sp, #3276]
	str	w15, [sp, #2420]
	ldrb	w15, [sp, #3278]
	strb	w8, [sp, #2480]
	ldr	x8, [sp, #696]                  ; 8-byte Folded Reload
	strh	w21, [sp, #3272]
	ldrh	w21, [x26]
	mov	x0, x8
	strb	w15, [x8, #2]
	ldrh	w15, [x3]
	strh	w17, [x8]
	ldr	w8, [sp, #1240]                 ; 4-byte Folded Reload
	ldr	w17, [sp, #3268]
	strh	w15, [sp, #2494]
	ldrh	w15, [sp, #3272]
	str	w8, [sp, #2484]
	ldr	w8, [sp, #1232]                 ; 4-byte Folded Reload
	strh	w21, [sp, #3264]
	ldrh	w21, [x25, #4]
	str	w8, [sp, #2488]
	ldr	w8, [sp, #400]                  ; 4-byte Folded Reload
	strh	w21, [sp, #3260]
	ldr	x21, [sp, #640]                 ; 8-byte Folded Reload
	strb	w8, [sp, #2492]
	ldr	w8, [sp, #404]                  ; 4-byte Folded Reload
	strh	w14, [sp, #2686]
	ldrh	w14, [sp, #3248]
	strb	w8, [sp, #2493]
	ldr	w8, [sp, #1224]                 ; 4-byte Folded Reload
	strh	w20, [sp, #3236]
	ldr	x20, [sp, #632]                 ; 8-byte Folded Reload
	str	w8, [sp, #2496]
	ldr	w8, [sp, #1220]                 ; 4-byte Folded Reload
	strh	w12, [sp, #2878]
	ldrh	w12, [sp, #2408]
	str	w8, [sp, #2500]
	ldr	w8, [sp, #396]                  ; 4-byte Folded Reload
	strh	w12, [x20, #4]
	ldrb	w12, [sp, #2402]
	strb	w8, [sp, #2504]
	ldr	w8, [sp, #392]                  ; 4-byte Folded Reload
	strb	w12, [x23, #2]
	ldr	w12, [sp, #2392]
	strb	w8, [sp, #2505]
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	strh	w11, [sp, #2974]
	ldrh	w11, [sp, #2396]
	mov	x1, x8
	strh	w15, [x8, #4]
	ldrb	w15, [sp, #3266]
	str	w17, [x8]
	ldr	w8, [sp, #1496]                 ; 4-byte Folded Reload
	ldrh	w17, [sp, #3264]
	strh	w11, [x9, #4]
	ldrb	w11, [sp, #2390]
	str	w8, [sp, #2512]
	ldr	w8, [sp, #216]                  ; 4-byte Folded Reload
	str	w12, [x9]
	ldrh	w12, [sp, #2388]
	str	w8, [sp, #2516]
	ldr	x8, [sp, #1200]                 ; 8-byte Folded Reload
	strh	w13, [sp, #2782]
	ldrh	w13, [sp, #3236]
	str	x8, [sp, #2520]
	ldr	x8, [sp, #1208]                 ; 8-byte Folded Reload
	strh	w13, [x6, #4]
	ldrb	w13, [sp, #2414]
	str	x8, [sp, #2528]
	ldr	x8, [sp, #1192]                 ; 8-byte Folded Reload
	strh	w10, [sp, #3070]
	ldrh	w10, [sp, #2384]
	str	x8, [sp, #2536]
	ldr	w8, [sp, #264]                  ; 4-byte Folded Reload
	strb	w13, [x21, #2]
	ldr	w13, [sp, #2404]
	str	w8, [sp, #2544]
	ldr	w8, [sp, #212]                  ; 4-byte Folded Reload
	str	w13, [x20]
	ldrh	w13, [sp, #2400]
	str	w8, [sp, #2548]
	ldr	x8, [sp, #1008]                 ; 8-byte Folded Reload
	strh	w13, [x23]
	str	x8, [sp, #2552]
	ldr	x8, [sp, #1016]                 ; 8-byte Folded Reload
	str	x8, [sp, #2560]
	ldr	x8, [sp, #984]                  ; 8-byte Folded Reload
	str	x8, [sp, #2568]
	ldr	w8, [sp, #268]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2576]
	ldr	x8, [sp, #680]                  ; 8-byte Folded Reload
	mov	x2, x8
	strb	w15, [x8, #2]
	ldrh	w15, [x16]
	strh	w17, [x8]
	ldr	w8, [sp, #1136]                 ; 4-byte Folded Reload
	ldr	w16, [sp, #3256]
	strh	w15, [sp, #2590]
	ldrh	w15, [sp, #3260]
	ldr	x17, [sp, #672]                 ; 8-byte Folded Reload
	str	w8, [sp, #2580]
	ldr	w8, [sp, #1144]                 ; 4-byte Folded Reload
	strh	w15, [x17, #4]
	ldrb	w15, [sp, #3254]
	str	w8, [sp, #2584]
	ldr	w8, [sp, #272]                  ; 4-byte Folded Reload
	str	w16, [x17]
	ldrh	w16, [sp, #3252]
	strb	w8, [sp, #2588]
	ldr	w8, [sp, #280]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2589]
	ldr	w8, [sp, #1148]                 ; 4-byte Folded Reload
	str	w8, [sp, #2592]
	ldr	w8, [sp, #1152]                 ; 4-byte Folded Reload
	str	w8, [sp, #2596]
	ldr	w8, [sp, #276]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2600]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2601]
	ldr	w8, [sp, #1344]                 ; 4-byte Folded Reload
	str	w8, [sp, #2608]
	ldr	w8, [sp, #204]                  ; 4-byte Folded Reload
	str	w8, [sp, #2612]
	ldr	x8, [sp, #960]                  ; 8-byte Folded Reload
	str	x8, [sp, #2616]
	ldr	x8, [sp, #968]                  ; 8-byte Folded Reload
	str	x8, [sp, #2624]
	ldr	x8, [sp, #976]                  ; 8-byte Folded Reload
	str	x8, [sp, #2632]
	ldr	w8, [sp, #228]                  ; 4-byte Folded Reload
	str	w8, [sp, #2640]
	ldr	w8, [sp, #208]                  ; 4-byte Folded Reload
	str	w8, [sp, #2644]
	ldr	x8, [sp, #936]                  ; 8-byte Folded Reload
	str	x8, [sp, #2648]
	ldr	x8, [sp, #944]                  ; 8-byte Folded Reload
	str	x8, [sp, #2656]
	ldr	x8, [sp, #952]                  ; 8-byte Folded Reload
	str	x8, [sp, #2664]
	ldr	w8, [sp, #288]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2672]
	ldr	x8, [sp, #664]                  ; 8-byte Folded Reload
	strb	w15, [x8, #2]
	mov	x3, x8
	ldr	w15, [sp, #3244]
	strh	w16, [x8]
	ldr	w8, [sp, #1112]                 ; 4-byte Folded Reload
	str	w8, [sp, #2676]
	ldr	w8, [sp, #1116]                 ; 4-byte Folded Reload
	str	w8, [sp, #2680]
	ldr	w8, [sp, #292]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2684]
	ldr	w8, [sp, #300]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2685]
	ldr	w8, [sp, #1120]                 ; 4-byte Folded Reload
	str	w8, [sp, #2688]
	ldr	w8, [sp, #1132]                 ; 4-byte Folded Reload
	str	w8, [sp, #2692]
	ldr	w8, [sp, #296]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2696]
	ldr	w8, [sp, #304]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2697]
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	strh	w14, [x8, #4]
	mov	x16, x8
	ldrb	w14, [sp, #3242]
	str	w15, [x8]
	ldr	w8, [sp, #1352]                 ; 4-byte Folded Reload
	ldrh	w15, [sp, #3240]
	str	w8, [sp, #2704]
	ldr	w8, [sp, #196]                  ; 4-byte Folded Reload
	str	w8, [sp, #2708]
	ldr	x8, [sp, #912]                  ; 8-byte Folded Reload
	str	x8, [sp, #2712]
	ldr	x8, [sp, #920]                  ; 8-byte Folded Reload
	str	x8, [sp, #2720]
	ldr	x8, [sp, #928]                  ; 8-byte Folded Reload
	str	x8, [sp, #2728]
	ldr	w8, [sp, #260]                  ; 4-byte Folded Reload
	str	w8, [sp, #2736]
	ldr	w8, [sp, #200]                  ; 4-byte Folded Reload
	str	w8, [sp, #2740]
	ldr	x8, [sp, #888]                  ; 8-byte Folded Reload
	str	x8, [sp, #2744]
	ldr	x8, [sp, #896]                  ; 8-byte Folded Reload
	str	x8, [sp, #2752]
	ldr	x8, [sp, #904]                  ; 8-byte Folded Reload
	str	x8, [sp, #2760]
	ldr	w8, [sp, #308]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2768]
	ldr	x8, [sp, #752]                  ; 8-byte Folded Reload
	strb	w14, [x8, #2]
	ldr	w14, [sp, #3232]
	strh	w15, [x8]
	ldr	w8, [sp, #1076]                 ; 4-byte Folded Reload
	ldr	x15, [sp, #608]                 ; 8-byte Folded Reload
	str	w14, [x6]
	ldrh	w14, [sp, #2412]
	str	w8, [sp, #2772]
	ldr	w8, [sp, #1080]                 ; 4-byte Folded Reload
	strh	w14, [x21]
	ldr	x14, [sp, #616]                 ; 8-byte Folded Reload
	str	w8, [sp, #2776]
	ldr	w8, [sp, #1428]                 ; 4-byte Folded Reload
	strb	w11, [x14, #2]
	ldr	w11, [sp, #2380]
	strb	w8, [sp, #2780]
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	strh	w10, [x15, #4]
	ldrb	w10, [sp, #2378]
	strb	w8, [sp, #2781]
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	str	w11, [x15]
	ldrh	w11, [sp, #2376]
	str	w8, [sp, #2784]
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	strb	w10, [x7, #2]
	ldr	w10, [sp, #2368]
	str	w8, [sp, #2788]
	ldr	w8, [sp, #1404]                 ; 4-byte Folded Reload
	strh	w12, [x14]
	strb	w8, [sp, #2792]
	ldr	w8, [sp, #1408]                 ; 4-byte Folded Reload
	strh	w11, [x7]
	strb	w8, [sp, #2793]
	ldr	w8, [sp, #1492]                 ; 4-byte Folded Reload
	str	w10, [x30]
	str	w8, [sp, #2800]
	ldr	w8, [sp, #1388]                 ; 4-byte Folded Reload
	str	w8, [sp, #2804]
	ldr	x8, [sp, #1456]                 ; 8-byte Folded Reload
	str	x8, [sp, #2808]
	ldr	x8, [sp, #1448]                 ; 8-byte Folded Reload
	str	x8, [sp, #2816]
	ldr	x8, [sp, #1440]                 ; 8-byte Folded Reload
	str	x8, [sp, #2824]
	ldr	w8, [sp, #1392]                 ; 4-byte Folded Reload
	str	w8, [sp, #2832]
	ldr	w8, [sp, #1384]                 ; 4-byte Folded Reload
	str	w8, [sp, #2836]
	ldr	x8, [sp, #1432]                 ; 8-byte Folded Reload
	str	x8, [sp, #2840]
	ldr	x8, [sp, #1472]                 ; 8-byte Folded Reload
	str	x8, [sp, #2848]
	ldr	x8, [sp, #1480]                 ; 8-byte Folded Reload
	str	x8, [sp, #2856]
	ldr	w8, [sp, #232]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2864]
	ldr	w8, [sp, #1176]                 ; 4-byte Folded Reload
	str	w8, [sp, #2868]
	ldr	w8, [sp, #1184]                 ; 4-byte Folded Reload
	str	w8, [sp, #2872]
	ldr	w8, [sp, #316]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2876]
	ldr	w8, [sp, #324]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2877]
	ldr	w8, [sp, #1188]                 ; 4-byte Folded Reload
	str	w8, [sp, #2880]
	ldr	w8, [sp, #236]                  ; 4-byte Folded Reload
	str	w8, [sp, #2884]
	ldr	w8, [sp, #320]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2888]
	ldr	w8, [sp, #328]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2889]
	ldr	w8, [sp, #1364]                 ; 4-byte Folded Reload
	str	w8, [sp, #2896]
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	str	w8, [sp, #2900]
	ldr	x8, [sp, #1088]                 ; 8-byte Folded Reload
	str	x8, [sp, #2904]
	ldr	x8, [sp, #1096]                 ; 8-byte Folded Reload
	str	x8, [sp, #2912]
	ldr	x8, [sp, #1104]                 ; 8-byte Folded Reload
	str	x8, [sp, #2920]
	ldr	w8, [sp, #256]                  ; 4-byte Folded Reload
	str	w8, [sp, #2928]
	ldr	w8, [sp, #192]                  ; 4-byte Folded Reload
	str	w8, [sp, #2932]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	str	x8, [sp, #2936]
	ldr	x8, [sp, #1056]                 ; 8-byte Folded Reload
	str	x8, [sp, #2944]
	ldr	x8, [sp, #1064]                 ; 8-byte Folded Reload
	str	x8, [sp, #2952]
	ldr	w8, [sp, #332]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2960]
	ldr	w8, [sp, #1156]                 ; 4-byte Folded Reload
	str	w8, [sp, #2964]
	ldr	w8, [sp, #1160]                 ; 4-byte Folded Reload
	str	w8, [sp, #2968]
	ldr	w8, [sp, #336]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2972]
	ldr	w8, [sp, #344]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2973]
	ldr	w8, [sp, #1164]                 ; 4-byte Folded Reload
	str	w8, [sp, #2976]
	ldr	w8, [sp, #1168]                 ; 4-byte Folded Reload
	str	w8, [sp, #2980]
	ldr	w8, [sp, #340]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2984]
	ldr	w8, [sp, #348]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2985]
	ldr	w8, [sp, #1368]                 ; 4-byte Folded Reload
	str	w8, [sp, #2992]
	ldr	w8, [sp, #180]                  ; 4-byte Folded Reload
	str	w8, [sp, #2996]
	ldr	x8, [sp, #864]                  ; 8-byte Folded Reload
	str	x8, [sp, #3000]
	ldr	x8, [sp, #872]                  ; 8-byte Folded Reload
	str	x8, [sp, #3008]
	ldr	x8, [sp, #880]                  ; 8-byte Folded Reload
	str	x8, [sp, #3016]
	ldr	w8, [sp, #252]                  ; 4-byte Folded Reload
	str	w8, [sp, #3024]
	ldr	w8, [sp, #184]                  ; 4-byte Folded Reload
	str	w8, [sp, #3028]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	str	x8, [sp, #3032]
	ldr	x8, [sp, #840]                  ; 8-byte Folded Reload
	str	x8, [sp, #3040]
	ldr	x8, [sp, #848]                  ; 8-byte Folded Reload
	str	x8, [sp, #3048]
	ldr	w8, [sp, #352]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3056]
	ldr	w8, [sp, #1032]                 ; 4-byte Folded Reload
	str	w8, [sp, #3060]
	ldr	w8, [sp, #1036]                 ; 4-byte Folded Reload
	str	w8, [sp, #3064]
	ldr	w8, [sp, #356]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3068]
	ldr	w8, [sp, #360]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3069]
	ldr	w8, [sp, #1040]                 ; 4-byte Folded Reload
	str	w8, [sp, #3072]
	ldr	w8, [sp, #1044]                 ; 4-byte Folded Reload
	str	w8, [sp, #3076]
	ldr	w8, [sp, #364]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3080]
	ldr	w8, [sp, #368]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3081]
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	str	w8, [sp, #3088]
	ldr	w8, [sp, #172]                  ; 4-byte Folded Reload
	str	w8, [sp, #3092]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	str	x8, [sp, #3096]
	ldr	x8, [sp, #816]                  ; 8-byte Folded Reload
	str	x8, [sp, #3104]
	ldr	x8, [sp, #824]                  ; 8-byte Folded Reload
	str	x8, [sp, #3112]
	ldr	w8, [sp, #248]                  ; 4-byte Folded Reload
	str	w8, [sp, #3120]
	ldr	w8, [sp, #176]                  ; 4-byte Folded Reload
	str	w8, [sp, #3124]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	str	x8, [sp, #3128]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	str	x8, [sp, #3136]
	ldr	x8, [sp, #856]                  ; 8-byte Folded Reload
	str	x8, [sp, #3144]
	ldr	w8, [sp, #372]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3152]
	ldr	w8, [sp, #996]                  ; 4-byte Folded Reload
	str	w8, [sp, #3156]
	ldr	w8, [sp, #1000]                 ; 4-byte Folded Reload
	str	w8, [sp, #3160]
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldrh	w9, [x8]
	ldr	w8, [sp, #376]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3164]
	ldr	w8, [sp, #380]                  ; 4-byte Folded Reload
	strh	w9, [sp, #3166]
	ldrh	w9, [sp, #2372]
	strb	w8, [sp, #3165]
	ldr	w8, [sp, #1028]                 ; 4-byte Folded Reload
	strh	w9, [x30, #4]
	str	w8, [sp, #3168]
	ldr	w8, [sp, #1004]                 ; 4-byte Folded Reload
	str	w8, [sp, #3172]
	ldr	w8, [sp, #384]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3176]
	ldr	w8, [sp, #388]                  ; 4-byte Folded Reload
	strb	w8, [sp, #3177]
	ldr	w8, [sp, #1320]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_24
; %bb.79:                               ; %v132_ok.preheader
                                        ;   in Loop: Header=BB13_26 Depth=1
	mov	w8, #2048                       ; =0x800
	ldr	x4, [sp, #592]                  ; 8-byte Folded Reload
	ldr	x11, [sp, #744]                 ; 8-byte Folded Reload
	ldr	x12, [sp, #736]                 ; 8-byte Folded Reload
	mov	x26, xzr
	str	xzr, [sp, #1368]                ; 8-byte Folded Spill
	str	w8, [sp, #1380]                 ; 4-byte Folded Spill
	add	x9, sp, #2416
LBB13_80:                               ; %v132_ok
                                        ;   Parent Loop BB13_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, sp, #2416
	str	x26, [sp, #1496]                ; 8-byte Folded Spill
	add	x8, x8, x26
	ldr	w27, [x8]
	cmp	w27, #1
	b.ne	LBB13_82
; %bb.81:                               ; %b66_to_b274
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x8, [sp, #2440]
	ldr	d0, [sp, #2592]
	mov	x19, x7
	ldur	q17, [x9, #8]
	ldur	q30, [x9, #40]
	add	x26, sp, #2416
	str	x8, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2472]
	mov	x10, x2
	str	d0, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #2608]
	add	x7, sp, #2416
	str	x8, [sp, #1224]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2480]
	mov	x25, x6
	str	d0, [sp, #1344]                 ; 8-byte Folded Spill
	ldur	q0, [x9, #200]
	mov	x24, x21
	str	w8, [sp, #1220]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2492]
	mov	x28, x20
	str	q0, [sp, #1328]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #2640]
	mov	x13, x14
	str	w8, [sp, #1208]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2493]
	mov	x27, x19
	str	d0, [sp, #1320]                 ; 8-byte Folded Spill
	ldur	q0, [x9, #232]
	ldur	d31, [x9, #68]
	str	w8, [sp, #1200]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2494]
	ldur	q10, [x9, #104]
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	ldr	d0, [x4]
	ldur	q12, [x9, #136]
	str	w8, [sp, #1192]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2504]
	ldur	d13, [x9, #164]
	str	d0, [sp, #1288]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #2688]
	ldr	x9, [sp, #768]                  ; 8-byte Folded Reload
	str	w8, [sp, #1188]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2505]
	ldr	x5, [sp, #752]                  ; 8-byte Folded Reload
	str	d0, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #2704]
	ldr	q4, [x9]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2536]
	ldr	x9, [sp, #760]                  ; 8-byte Folded Reload
	str	d0, [sp, #1272]                 ; 8-byte Folded Spill
	ldur	q0, [x4, #36]
	ldr	d14, [sp, #2448]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2568]
	ldr	d8, [sp, #2496]
	str	q0, [sp, #1248]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #2736]
	ldr	d9, [sp, #2512]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2576]
	ldr	d11, [sp, #2544]
	str	d0, [sp, #1240]                 ; 8-byte Folded Spill
	ldur	q18, [x4, #68]
	ldr	d19, [x4, #96]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2588]
	ldr	d20, [x4, #192]
	ldr	d21, [sp, #2880]
	ldr	d22, [sp, #2896]
	ldur	q23, [x4, #228]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2589]
	ldr	d24, [sp, #2928]
	ldr	q25, [x11]
	mov	x11, x1
	ldr	d26, [x4, #288]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2590]
	ldr	d27, [sp, #2976]
	ldr	d28, [sp, #2992]
	ldr	q29, [x12]
	mov	x12, x0
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2600]
	ldr	d15, [sp, #3024]
	ldr	d1, [x4, #384]
	ldr	d2, [sp, #3072]
	ldr	d3, [sp, #3088]
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2601]
	ldr	d5, [sp, #3120]
	ldr	q6, [x9]
	mov	x9, x15
	ldr	d7, [x4, #480]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2632]
	ldr	d16, [sp, #3168]
	str	x30, [sp, #832]                 ; 8-byte Folded Spill
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2664]
	str	x17, [sp, #792]                 ; 8-byte Folded Spill
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2672]
	str	x3, [sp, #800]                  ; 8-byte Folded Spill
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2684]
	str	x16, [sp, #816]                 ; 8-byte Folded Spill
	str	w8, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2685]
	str	x5, [sp, #824]                  ; 8-byte Folded Spill
	str	w8, [sp, #1112]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2686]
	str	x23, [sp, #784]                 ; 8-byte Folded Spill
	str	w8, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2696]
	str	x22, [sp, #808]                 ; 8-byte Folded Spill
	str	w8, [sp, #1088]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2697]
	str	w8, [sp, #1096]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2728]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2760]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2768]
	str	w8, [sp, #1064]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2780]
	str	w8, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2781]
	str	w8, [sp, #1416]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2782]
	str	w8, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2784]
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2788]
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2792]
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2793]
	str	w8, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2800]
	str	w8, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2804]
	str	w8, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2808]
	str	x8, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2816]
	str	x8, [sp, #1448]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2824]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	w8, [sp, #2832]
	str	w8, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #2836]
	str	w8, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2840]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2848]
	str	x8, [sp, #1472]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #2856]
	str	x8, [sp, #1480]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #2864]
	str	w8, [sp, #1016]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2876]
	str	w8, [sp, #1040]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2877]
	str	w8, [sp, #1036]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #2878]
	str	w8, [sp, #1032]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2888]
	str	w8, [sp, #1028]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2889]
	str	w8, [sp, #1044]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2920]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #2952]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #2960]
	str	w8, [sp, #968]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2972]
	str	w8, [sp, #1000]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #2973]
	str	w8, [sp, #996]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #2974]
	str	w8, [sp, #984]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2984]
	str	w8, [sp, #976]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #2985]
	str	w8, [sp, #1004]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #3016]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #3048]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3056]
	str	w8, [sp, #848]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3068]
	str	w8, [sp, #872]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3069]
	str	w8, [sp, #880]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #3070]
	str	w8, [sp, #904]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3080]
	str	w8, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3081]
	str	w8, [sp, #888]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #3112]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #3144]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldrb	w8, [sp, #3152]
	str	w8, [sp, #912]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3164]
	str	w8, [sp, #936]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3165]
	str	w8, [sp, #920]                  ; 4-byte Folded Spill
	ldrh	w8, [sp, #3166]
	str	w8, [sp, #928]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3176]
	str	w8, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w8, [sp, #3177]
	str	w8, [sp, #944]                  ; 4-byte Folded Spill
	ldr	x8, [sp, #776]                  ; 8-byte Folded Reload
	ldr	q0, [x8]
	b	LBB13_108
LBB13_82:                               ; %b67
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldrb	w10, [x8, #64]
	ldp	x23, x26, [x8, #8]
	ldr	w9, [x8, #32]
	ldr	x11, [x8, #24]
	ldr	x19, [x8, #56]
	str	w10, [sp, #1440]                ; 4-byte Folded Spill
	ldr	w10, [x8, #68]
	ldrb	w22, [x8, #88]
	cmp	w9, #1
	ldr	x0, [sp, #720]                  ; 8-byte Folded Reload
	str	w9, [sp, #1428]                 ; 4-byte Folded Spill
	str	w10, [sp, #1492]                ; 4-byte Folded Spill
	ldr	w10, [x8, #72]
	ldp	x20, x25, [x8, #40]
	str	w10, [sp, #1480]                ; 4-byte Folded Spill
	ldrb	w10, [x8, #76]
	str	w10, [sp, #1456]                ; 4-byte Folded Spill
	ldrb	w10, [x8, #77]
	str	w10, [sp, #1472]                ; 4-byte Folded Spill
	ldp	w10, w21, [x8, #80]
	ldrb	w8, [x8, #89]
	str	w10, [sp, #1448]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	str	w21, [sp, #1468]                ; 4-byte Folded Spill
	b.ne	LBB13_84
; %bb.83:                               ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	str	w22, [sp, #1432]                ; 4-byte Folded Spill
	ldr	w22, [sp, #1428]                ; 4-byte Folded Reload
	mov	x28, x26
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	str	wzr, [sp, #1364]                ; 4-byte Folded Spill
	str	w8, [sp, #732]                  ; 4-byte Folded Spill
	mov	x24, x20
	mov	x20, x11
	b	LBB13_107
LBB13_84:                               ; %b70
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x1, x23
	mov	x2, x26
	mov	x3, x11
	mov	x24, x25
	mov	x25, x19
	mov	x28, x0
	str	x23, [sp, #1408]                ; 8-byte Folded Spill
	mov	x19, x11
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	str	x19, [sp, #1416]                ; 8-byte Folded Spill
	cbnz	x8, LBB13_86
; %bb.85:                               ; %b1.i.i199
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x23, x0
	mov	w21, wzr
	b	LBB13_89
LBB13_86:                               ; %v8_ok.i.i181
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_88
; %bb.87:                               ; %v8_ok.i.i181
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh10:
	adrp	x11, lJTI13_4@PAGE
Lloh11:
	add	x11, x11, lJTI13_4@PAGEOFF
	adr	x9, LBB13_88
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_88:                               ; %liza___liza_reactor_error.exit.i.i185
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w23, wzr
	mov	w21, #1                         ; =0x1
LBB13_89:                               ; %liza_net.reactor_ready.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x19, x25
	cmp	w21, #1
	mov	w8, #3                          ; =0x3
	csel	w8, wzr, w8, ne
	mov	x0, x28
	mov	x1, x20
	mov	x2, x24
	mov	x3, x19
	str	w8, [sp, #1404]                 ; 4-byte Folded Spill
	mov	x25, x24
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	cbz	x8, LBB13_93
; %bb.90:                               ; %v8_ok.i.i207
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_92
; %bb.91:                               ; %v8_ok.i.i207
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh12:
	adrp	x11, lJTI13_5@PAGE
Lloh13:
	add	x11, x11, lJTI13_5@PAGEOFF
	adr	x9, LBB13_92
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_92:                               ; %liza___liza_reactor_error.exit.i.i211
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w0, wzr
	mov	w8, #1                          ; =0x1
LBB13_93:                               ; %liza_net.reactor_ready.exit228
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x24, x20
	cmp	w8, #1
	b.ne	LBB13_97
LBB13_94:                               ;   in Loop: Header=BB13_80 Depth=2
	mov	w22, #3                         ; =0x3
LBB13_95:                               ; %b259
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x2, x26
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB13_99
; %bb.96:                               ; %b1.i.i891
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w27, wzr
	b	LBB13_102
LBB13_97:                               ; %b78
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #1
	ldr	w9, [sp, #1440]                 ; 4-byte Folded Reload
	str	x0, [sp, #1392]                 ; 8-byte Folded Spill
	cset	w8, eq
	str	w22, [sp, #1432]                ; 4-byte Folded Spill
	orr	w8, w8, w9
	tbz	w8, #0, LBB13_110
; %bb.98:                               ; %b91
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	cmp	w21, #1
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	b.eq	LBB13_94
	b	LBB13_129
LBB13_99:                               ; %v8_ok.i.i873
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_101
; %bb.100:                              ; %v8_ok.i.i873
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh14:
	adrp	x11, lJTI13_13@PAGE
Lloh15:
	add	x11, x11, lJTI13_13@PAGEOFF
	adr	x9, LBB13_101
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_101:                              ; %liza___liza_reactor_error.exit.i.i877
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w27, #1                         ; =0x1
LBB13_102:                              ; %liza_net.reactor_disconnect.exit894
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbz	x8, LBB13_106
; %bb.103:                              ; %v8_ok.i.i900
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_105
; %bb.104:                              ; %v8_ok.i.i900
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh16:
	adrp	x11, lJTI13_14@PAGE
Lloh17:
	add	x11, x11, lJTI13_14@PAGEOFF
	adr	x9, LBB13_105
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_105:                              ; %liza___liza_reactor_error.exit.i.i904
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
LBB13_106:                              ; %liza_net.reactor_disconnect.exit921
                                        ;   in Loop: Header=BB13_80 Depth=2
	orr	w8, w8, w27
	ldr	w9, [sp, #412]                  ; 4-byte Folded Reload
	mov	x23, xzr
	cmp	w8, #0
	mov	w8, #3                          ; =0x3
	mov	x28, xzr
	csel	w8, w22, w8, eq
	tst	w9, #0x1
	ldr	w9, [sp, #732]                  ; 4-byte Folded Reload
	mov	x20, xzr
	mov	x24, xzr
	mov	x25, xzr
	csel	w9, w8, w9, ne
	ldr	w8, [sp, #408]                  ; 4-byte Folded Reload
	mov	x19, xzr
	mov	w26, wzr
	mov	w27, #1                         ; =0x1
	mov	w22, #1                         ; =0x1
	str	wzr, [sp, #1492]                ; 4-byte Folded Spill
	str	wzr, [sp, #1480]                ; 4-byte Folded Spill
	str	wzr, [sp, #1456]                ; 4-byte Folded Spill
	str	wzr, [sp, #1472]                ; 4-byte Folded Spill
	str	wzr, [sp, #1448]                ; 4-byte Folded Spill
	str	xzr, [sp, #1464]                ; 8-byte Folded Spill
	str	wzr, [sp, #1432]                ; 4-byte Folded Spill
	str	w9, [sp, #732]                  ; 4-byte Folded Spill
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
LBB13_107:                              ; %v554_ok
                                        ;   in Loop: Header=BB13_80 Depth=2
	add	x0, sp, #1600
	add	x1, sp, #2416
	mov	w2, #768                        ; =0x300
	add	x21, sp, #1600
	bl	_memcpy
	ldr	x8, [sp, #1496]                 ; 8-byte Folded Reload
	and	w9, w26, #0x1
	ldr	w10, [sp, #1492]                ; 4-byte Folded Reload
	ldr	x12, [sp, #584]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #592]                  ; 8-byte Folded Reload
	add	x26, sp, #1600
	add	x8, x21, x8
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #688]                  ; 8-byte Folded Reload
	str	w27, [x8]
	ldr	x2, [sp, #680]                  ; 8-byte Folded Reload
	add	x7, sp, #2416
	stp	x23, x28, [x8, #8]
	ldr	x17, [sp, #672]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #664]                  ; 8-byte Folded Reload
	str	x20, [x8, #24]
	ldr	x16, [sp, #656]                 ; 8-byte Folded Reload
	ldr	x5, [sp, #752]                  ; 8-byte Folded Reload
	strb	w9, [x8, #64]
	add	x9, sp, #1353
	ldr	x6, [sp, #648]                  ; 8-byte Folded Reload
	ldur	q17, [x9, #255]
	ldr	x9, [sp, #1624]
	str	w22, [x8, #32]
	stp	x24, x25, [x8, #40]
	ldr	d14, [sp, #1632]
	ldr	x25, [sp, #528]                 ; 8-byte Folded Reload
	str	x9, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #1480]                 ; 4-byte Folded Reload
	ldr	x24, [sp, #520]                 ; 8-byte Folded Reload
	str	x19, [x8, #56]
	ldr	x21, [sp, #640]                 ; 8-byte Folded Reload
	ldr	x20, [sp, #632]                 ; 8-byte Folded Reload
	stp	w10, w9, [x8, #68]
	add	x10, sp, #1600
	ldr	w9, [sp, #1456]                 ; 4-byte Folded Reload
	ldr	x11, [sp, #1656]
	ldur	q30, [x10, #40]
	ldur	d31, [x10, #68]
	and	w9, w9, #0x1
	ldr	x23, [sp, #624]                 ; 8-byte Folded Reload
	ldr	x22, [sp, #712]                 ; 8-byte Folded Reload
	strb	w9, [x8, #76]
	ldr	w9, [sp, #1472]                 ; 4-byte Folded Reload
	ldr	x14, [sp, #616]                 ; 8-byte Folded Reload
	str	x11, [sp, #1224]                ; 8-byte Folded Spill
	ldrb	w11, [sp, #1664]
	ldr	x15, [sp, #608]                 ; 8-byte Folded Reload
	and	w9, w9, #0x1
	ldr	x19, [sp, #600]                 ; 8-byte Folded Reload
	ldr	x30, [sp, #704]                 ; 8-byte Folded Reload
	strb	w9, [x8, #77]
	ldrb	w9, [sp, #1676]
	str	w11, [sp, #1220]                ; 4-byte Folded Spill
	ldr	w11, [sp, #1448]                ; 4-byte Folded Reload
	str	w9, [sp, #1208]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1677]
	str	w9, [sp, #1200]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	stp	w11, w9, [x8, #80]
	ldr	w9, [sp, #1432]                 ; 4-byte Folded Reload
	ldrh	w11, [sp, #1678]
	ldr	d8, [sp, #1680]
	and	w9, w9, #0x1
	str	w11, [sp, #1192]                ; 4-byte Folded Spill
	strb	w9, [x8, #88]
	ldr	w9, [sp, #1464]                 ; 4-byte Folded Reload
	ldrb	w11, [sp, #1688]
	and	w9, w9, #0x1
	strb	w9, [x8, #89]
	ldrb	w9, [sp, #1868]
	ldr	d0, [sp, #1776]
	ldur	q10, [x10, #104]
	ldur	q12, [x10, #136]
	ldur	d13, [x10, #164]
	ldrb	w8, [sp, #1689]
	str	w9, [sp, #1116]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1869]
	ldr	d9, [sp, #1696]
	str	d0, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #1792]
	ldr	d11, [sp, #1728]
	str	w9, [sp, #1112]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1870]
	ldr	d21, [sp, #2064]
	str	d0, [sp, #1344]                 ; 8-byte Folded Spill
	ldur	q0, [x10, #200]
	ldr	d22, [sp, #2080]
	str	w9, [sp, #1104]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1880]
	ldr	d24, [sp, #2112]
	str	q0, [sp, #1328]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #1824]
	ldr	d27, [sp, #2160]
	str	w9, [sp, #1088]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1881]
	ldr	d28, [sp, #2176]
	str	d0, [sp, #1320]                 ; 8-byte Folded Spill
	ldur	q0, [x10, #232]
	ldr	d15, [sp, #2208]
	str	w9, [sp, #1096]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1912]
	ldr	d2, [sp, #2256]
	str	w8, [sp, #1184]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #1720]
	ldr	d3, [sp, #2272]
	str	x9, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #1944]
	ldr	d5, [sp, #2304]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1752]
	ldr	d16, [sp, #2352]
	str	x9, [sp, #1056]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #1952]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1760]
	str	w9, [sp, #1064]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1964]
	str	w8, [sp, #1164]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1772]
	str	w9, [sp, #1428]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1965]
	str	w8, [sp, #1160]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1773]
	str	w9, [sp, #1416]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #1966]
	str	w8, [sp, #1156]                 ; 4-byte Folded Spill
	ldrh	w8, [sp, #1774]
	str	w9, [sp, #1076]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1968]
	str	w8, [sp, #1152]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1784]
	str	w9, [sp, #1468]                 ; 4-byte Folded Spill
	ldp	x9, x10, [sp, #440]             ; 16-byte Folded Reload
	str	w8, [sp, #1148]                 ; 4-byte Folded Spill
	ldrb	w8, [sp, #1785]
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	ldr	q29, [x9]
	ldr	w9, [sp, #1972]
	str	w8, [sp, #1144]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #1816]
	str	w11, [sp, #1188]                ; 4-byte Folded Spill
	ldr	q25, [x10]
	str	w9, [sp, #1464]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1976]
	ldr	x11, [sp, #576]                 ; 8-byte Folded Reload
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #1848]
	ldr	x10, [sp, #568]                 ; 8-byte Folded Reload
	str	w9, [sp, #1404]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #1977]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldrb	w8, [sp, #1856]
	str	w9, [sp, #1408]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1984]
	str	w8, [sp, #1132]                 ; 4-byte Folded Spill
	ldr	x8, [sp, #456]                  ; 8-byte Folded Reload
	str	w9, [sp, #1492]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #1988]
	ldr	d0, [x8]
	ldur	q18, [x8, #68]
	ldr	d19, [x8, #96]
	str	w9, [sp, #1388]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #1992]
	ldr	d20, [x8, #192]
	str	d0, [sp, #1288]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #1872]
	ldur	q23, [x8, #228]
	str	x9, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2000]
	ldr	d26, [x8, #288]
	str	d0, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	d0, [sp, #1888]
	ldr	d1, [x8, #384]
	str	x9, [sp, #1448]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2008]
	ldr	d7, [x8, #480]
	str	d0, [sp, #1272]                 ; 8-byte Folded Spill
	ldur	q0, [x8, #36]
	str	x9, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	w9, [sp, #2016]
	str	q0, [sp, #1248]                 ; 16-byte Folded Spill
	ldr	d0, [sp, #1920]
	str	w9, [sp, #1392]                 ; 4-byte Folded Spill
	ldr	w9, [sp, #2020]
	str	d0, [sp, #1240]                 ; 8-byte Folded Spill
	str	w9, [sp, #1384]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #2024]
	str	x9, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2032]
	str	x9, [sp, #1472]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2040]
	str	x9, [sp, #1480]                 ; 8-byte Folded Spill
	ldrb	w9, [sp, #2048]
	str	w9, [sp, #1016]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2060]
	str	w9, [sp, #1040]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2061]
	str	w9, [sp, #1036]                 ; 4-byte Folded Spill
	ldrh	w9, [sp, #2062]
	str	w9, [sp, #1032]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2072]
	str	w9, [sp, #1028]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2073]
	str	w9, [sp, #1044]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #2104]
	str	x9, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #2136]
	str	x9, [sp, #960]                  ; 8-byte Folded Spill
	ldrb	w9, [sp, #2144]
	str	w9, [sp, #968]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2156]
	str	w9, [sp, #1000]                 ; 4-byte Folded Spill
	ldrb	w9, [sp, #2157]
	str	w9, [sp, #996]                  ; 4-byte Folded Spill
	ldrh	w9, [sp, #2158]
	str	w9, [sp, #984]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2168]
	str	w9, [sp, #976]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2169]
	str	w9, [sp, #1004]                 ; 4-byte Folded Spill
	ldr	x9, [sp, #2200]
	str	x9, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x9, [sp, #464]                  ; 8-byte Folded Reload
	str	x9, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #2232]
	str	x9, [sp, #840]                  ; 8-byte Folded Spill
	ldrb	w9, [sp, #2240]
	str	w9, [sp, #848]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2252]
	str	w9, [sp, #872]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2253]
	str	w9, [sp, #880]                  ; 4-byte Folded Spill
	ldrh	w9, [sp, #2254]
	str	w9, [sp, #904]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2264]
	str	w9, [sp, #856]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2265]
	str	w9, [sp, #888]                  ; 4-byte Folded Spill
	ldr	x9, [sp, #2296]
	str	x9, [sp, #952]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #560]                  ; 8-byte Folded Reload
	str	x9, [sp, #792]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #552]                  ; 8-byte Folded Reload
	str	x9, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #544]                  ; 8-byte Folded Reload
	str	x9, [sp, #816]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #536]                  ; 8-byte Folded Reload
	str	x9, [sp, #824]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #2328]
	str	x9, [sp, #896]                  ; 8-byte Folded Spill
	ldrb	w9, [sp, #2336]
	str	w9, [sp, #912]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2348]
	str	w9, [sp, #936]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2349]
	str	w9, [sp, #920]                  ; 4-byte Folded Spill
	ldrh	w9, [sp, #2350]
	str	w9, [sp, #928]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2360]
	str	w9, [sp, #864]                  ; 4-byte Folded Spill
	ldrb	w9, [sp, #2361]
	str	w9, [sp, #944]                  ; 4-byte Folded Spill
	ldp	x9, x28, [sp, #504]             ; 16-byte Folded Reload
	str	x9, [sp, #784]                  ; 8-byte Folded Spill
	ldp	x13, x9, [sp, #488]             ; 16-byte Folded Reload
	str	x9, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #432]                  ; 8-byte Folded Reload
	ldr	q0, [x9]
	ldr	x9, [sp, #424]                  ; 8-byte Folded Reload
	ldr	q4, [x9]
	ldr	x9, [sp, #416]                  ; 8-byte Folded Reload
	ldr	q6, [x9]
	ldp	x27, x9, [sp, #472]             ; 16-byte Folded Reload
LBB13_108:                              ; %b274_to_b59
                                        ;   in Loop: Header=BB13_80 Depth=2
	stur	q17, [x7, #8]
	ldr	d17, [x26]
	ldrh	w26, [x12]
	ldrb	w12, [x12, #2]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	stur	q30, [x7, #40]
	strh	w26, [sp, #1596]
	ldr	w26, [x11]
	ldrh	w11, [x11, #4]
	strb	w12, [sp, #1598]
	ldrh	w12, [x10]
	ldrb	w10, [x10, #2]
	strh	w11, [sp, #1592]
	ldrh	w11, [x8, #4]
	strb	w10, [sp, #1586]
	ldr	w10, [x8]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	strh	w11, [sp, #1580]
	ldrb	w11, [x8, #2]
	str	w10, [sp, #1576]
	ldrh	w10, [x8]
	ldr	x8, [sp, #816]                  ; 8-byte Folded Reload
	str	w26, [sp, #1588]
	ldr	x26, [sp, #1368]                ; 8-byte Folded Reload
	strb	w11, [sp, #1574]
	cmp	x26, #6
	ldrh	w11, [x8, #4]
	strh	w10, [sp, #1572]
	ldr	w10, [x8]
	ldr	x8, [sp, #824]                  ; 8-byte Folded Reload
	strh	w12, [sp, #1584]
	strh	w11, [sp, #1568]
	ldr	x12, [sp, #736]                 ; 8-byte Folded Reload
	ldrb	w11, [x8, #2]
	str	w10, [sp, #1564]
	ldrh	w10, [x8]
	ldr	x8, [sp, #784]                  ; 8-byte Folded Reload
	str	d17, [sp, #2416]
	ldr	d17, [sp, #1352]                ; 8-byte Folded Reload
	strb	w11, [sp, #1562]
	ldrh	w11, [x25, #4]
	strh	w10, [sp, #1560]
	ldr	w10, [x25]
	ldr	x25, [sp, #1440]                ; 8-byte Folded Reload
	strh	w11, [sp, #1556]
	ldrb	w11, [x24, #2]
	str	w10, [sp, #1552]
	ldrh	w10, [x24]
	ldr	x24, [sp, #1448]                ; 8-byte Folded Reload
	strb	w11, [sp, #1550]
	ldrh	w11, [x28, #4]
	strh	w10, [sp, #1548]
	ldr	w10, [x28]
	ldr	x28, [sp, #1480]                ; 8-byte Folded Reload
	strh	w11, [sp, #1544]
	ldrb	w11, [x8, #2]
	str	w10, [sp, #1540]
	ldrh	w10, [x8]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	strb	w11, [sp, #1538]
	ldrh	w11, [x8, #4]
	strh	w10, [sp, #1536]
	ldr	w10, [x8]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	str	d17, [sp, #2592]
	ldr	d17, [sp, #1344]                ; 8-byte Folded Reload
	strh	w11, [sp, #1532]
	ldrb	w11, [x13, #2]
	str	w10, [sp, #1528]
	ldrh	w10, [x13]
	ldr	x13, [sp, #1456]                ; 8-byte Folded Reload
	strb	w11, [sp, #1526]
	ldrh	w11, [x9, #4]
	strh	w10, [sp, #1524]
	ldr	w10, [x9]
	ldr	w9, [x8]
	strh	w11, [sp, #1520]
	ldrb	w11, [x27, #2]
	str	w9, [sp, #1504]
	ldrh	w9, [sp, #1548]
	strb	w11, [sp, #1514]
	ldrh	w11, [x8, #4]
	ldr	x8, [sp, #1232]                 ; 8-byte Folded Reload
	strh	w9, [sp, #2412]
	ldr	w9, [sp, #1540]
	str	x8, [sp, #2440]
	ldr	x8, [sp, #1224]                 ; 8-byte Folded Reload
	str	w9, [sp, #2404]
	ldrh	w9, [sp, #1536]
	str	x8, [sp, #2472]
	ldr	w8, [sp, #1220]                 ; 4-byte Folded Reload
	strh	w9, [sp, #2400]
	ldr	w9, [sp, #1528]
	strb	w8, [sp, #2480]
	ldr	w8, [sp, #1208]                 ; 4-byte Folded Reload
	str	w9, [sp, #2392]
	ldrh	w9, [sp, #1524]
	strb	w8, [sp, #2492]
	ldr	w8, [sp, #1200]                 ; 4-byte Folded Reload
	str	w10, [sp, #1516]
	ldrh	w10, [x27]
	ldr	x27, [sp, #1472]                ; 8-byte Folded Reload
	strb	w8, [sp, #2493]
	ldr	w8, [sp, #1192]                 ; 4-byte Folded Reload
	strh	w9, [sp, #2388]
	ldr	w9, [sp, #1516]
	strh	w8, [sp, #2494]
	ldr	w8, [sp, #1188]                 ; 4-byte Folded Reload
	strh	w10, [sp, #1512]
	ldrb	w10, [sp, #1550]
	strb	w8, [sp, #2504]
	ldr	w8, [sp, #1184]                 ; 4-byte Folded Reload
	str	w9, [sp, #2380]
	ldrh	w9, [sp, #1512]
	strb	w8, [sp, #2505]
	ldr	x8, [sp, #1176]                 ; 8-byte Folded Reload
	strh	w9, [sp, #2376]
	ldr	w9, [sp, #1504]
	str	x8, [sp, #2536]
	ldr	x8, [sp, #1168]                 ; 8-byte Folded Reload
	str	w9, [sp, #2368]
	ldrb	w9, [sp, #1598]
	str	x8, [sp, #2568]
	ldr	w8, [sp, #1164]                 ; 4-byte Folded Reload
	strb	w9, [x0, #2]
	ldrh	w9, [sp, #1592]
	strb	w8, [sp, #2576]
	ldr	w8, [sp, #1160]                 ; 4-byte Folded Reload
	strh	w9, [x1, #4]
	ldrb	w9, [sp, #1586]
	strb	w8, [sp, #2588]
	ldr	w8, [sp, #1156]                 ; 4-byte Folded Reload
	strb	w9, [x2, #2]
	ldrh	w9, [sp, #1580]
	strb	w8, [sp, #2589]
	ldr	w8, [sp, #1152]                 ; 4-byte Folded Reload
	strb	w10, [sp, #2414]
	ldrh	w10, [sp, #1544]
	strh	w8, [sp, #2590]
	ldr	w8, [sp, #1148]                 ; 4-byte Folded Reload
	strh	w9, [x17, #4]
	ldrb	w9, [sp, #1574]
	strb	w8, [sp, #2600]
	ldr	w8, [sp, #1144]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2408]
	ldrb	w10, [sp, #1538]
	strb	w8, [sp, #2601]
	ldr	x8, [sp, #1136]                 ; 8-byte Folded Reload
	strb	w9, [x3, #2]
	ldrh	w9, [sp, #1568]
	str	x8, [sp, #2632]
	ldr	x8, [sp, #1120]                 ; 8-byte Folded Reload
	strb	w10, [sp, #2402]
	ldrh	w10, [sp, #1532]
	str	x8, [sp, #2664]
	ldr	w8, [sp, #1132]                 ; 4-byte Folded Reload
	strh	w9, [x16, #4]
	ldrb	w9, [sp, #1562]
	strb	w8, [sp, #2672]
	ldr	w8, [sp, #1116]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2396]
	ldrb	w10, [sp, #1526]
	strb	w8, [sp, #2684]
	ldr	w8, [sp, #1112]                 ; 4-byte Folded Reload
	strb	w9, [x5, #2]
	ldrh	w9, [sp, #1556]
	strb	w8, [sp, #2685]
	ldr	w8, [sp, #1104]                 ; 4-byte Folded Reload
	strb	w10, [sp, #2390]
	ldrh	w10, [sp, #1520]
	strh	w8, [sp, #2686]
	ldr	w8, [sp, #1088]                 ; 4-byte Folded Reload
	strh	w9, [x6, #4]
	ldrb	w9, [sp, #2414]
	strb	w8, [sp, #2696]
	ldr	w8, [sp, #1096]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2384]
	ldrb	w10, [sp, #1514]
	strb	w8, [sp, #2697]
	ldr	x8, [sp, #1080]                 ; 8-byte Folded Reload
	strh	w11, [sp, #1508]
	ldr	x11, [sp, #744]                 ; 8-byte Folded Reload
	str	x8, [sp, #2728]
	ldr	x8, [sp, #1056]                 ; 8-byte Folded Reload
	strb	w9, [x21, #2]
	ldrh	w9, [sp, #2408]
	str	x8, [sp, #2760]
	ldr	w8, [sp, #1064]                 ; 4-byte Folded Reload
	strb	w10, [sp, #2378]
	ldrh	w10, [sp, #1508]
	strb	w8, [sp, #2768]
	ldr	w8, [sp, #1076]                 ; 4-byte Folded Reload
	strh	w9, [x20, #4]
	ldrb	w9, [sp, #2402]
	strh	w8, [sp, #2782]
	ldr	w8, [sp, #1016]                 ; 4-byte Folded Reload
	strh	w10, [sp, #2372]
	ldrh	w10, [sp, #1596]
	strb	w8, [sp, #2864]
	ldr	w8, [sp, #1040]                 ; 4-byte Folded Reload
	strb	w9, [x23, #2]
	ldrh	w9, [sp, #2396]
	strb	w8, [sp, #2876]
	ldr	w8, [sp, #1036]                 ; 4-byte Folded Reload
	strh	w10, [x0]
	ldr	w10, [sp, #1588]
	strb	w8, [sp, #2877]
	ldr	w8, [sp, #1032]                 ; 4-byte Folded Reload
	strh	w9, [x22, #4]
	ldrb	w9, [sp, #2390]
	strh	w8, [sp, #2878]
	ldr	w8, [sp, #1028]                 ; 4-byte Folded Reload
	str	w10, [x1]
	ldrh	w10, [sp, #1584]
	strb	w8, [sp, #2888]
	ldr	w8, [sp, #1044]                 ; 4-byte Folded Reload
	strb	w9, [x14, #2]
	ldrh	w9, [sp, #2384]
	strb	w8, [sp, #2889]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	strh	w10, [x2]
	ldr	w10, [sp, #1576]
	str	x8, [sp, #2920]
	ldr	x8, [sp, #960]                  ; 8-byte Folded Reload
	strh	w9, [x15, #4]
	ldrb	w9, [sp, #2378]
	str	x8, [sp, #2952]
	ldr	w8, [sp, #968]                  ; 4-byte Folded Reload
	str	w10, [x17]
	ldrh	w10, [sp, #1572]
	strb	w8, [sp, #2960]
	ldr	w8, [sp, #1000]                 ; 4-byte Folded Reload
	strb	w9, [x19, #2]
	ldr	w9, [sp, #944]                  ; 4-byte Folded Reload
	strb	w8, [sp, #2972]
	ldr	w8, [sp, #996]                  ; 4-byte Folded Reload
	strh	w10, [x3]
	ldr	w10, [sp, #1564]
	strb	w8, [sp, #2973]
	ldr	w8, [sp, #984]                  ; 4-byte Folded Reload
	strb	w9, [sp, #3177]
	ldr	w9, [sp, #2368]
	strh	w8, [sp, #2974]
	ldr	w8, [sp, #976]                  ; 4-byte Folded Reload
	str	w10, [x16]
	ldrh	w10, [sp, #1560]
	strb	w8, [sp, #2984]
	ldr	w8, [sp, #1004]                 ; 4-byte Folded Reload
	str	w9, [x30]
	ldr	w9, [sp, #1404]                 ; 4-byte Folded Reload
	strb	w8, [sp, #2985]
	ldr	x8, [sp, #1008]                 ; 8-byte Folded Reload
	strh	w10, [x5]
	ldr	w10, [sp, #1552]
	ldr	x5, [sp, #1432]                 ; 8-byte Folded Reload
	str	x8, [sp, #3016]
	ldr	x8, [sp, #840]                  ; 8-byte Folded Reload
	strb	w9, [sp, #2792]
	ldr	w9, [sp, #1408]                 ; 4-byte Folded Reload
	str	x8, [sp, #3048]
	ldr	w8, [sp, #848]                  ; 4-byte Folded Reload
	str	w10, [x6]
	ldrh	w10, [sp, #2412]
	strb	w8, [sp, #3056]
	ldr	w8, [sp, #872]                  ; 4-byte Folded Reload
	str	d17, [sp, #2608]
	ldr	q17, [sp, #1328]                ; 16-byte Folded Reload
	strb	w8, [sp, #3068]
	ldr	w8, [sp, #880]                  ; 4-byte Folded Reload
	strb	w9, [sp, #2793]
	ldr	w9, [sp, #1492]                 ; 4-byte Folded Reload
	strb	w8, [sp, #3069]
	ldr	w8, [sp, #904]                  ; 4-byte Folded Reload
	strh	w10, [x21]
	ldr	w10, [sp, #2404]
	strh	w8, [sp, #3070]
	ldr	w8, [sp, #856]                  ; 4-byte Folded Reload
	stur	q17, [x7, #200]
	ldr	d17, [sp, #1320]                ; 8-byte Folded Reload
	strb	w8, [sp, #3080]
	ldr	w8, [sp, #888]                  ; 4-byte Folded Reload
	str	w9, [sp, #2800]
	ldr	w9, [sp, #1388]                 ; 4-byte Folded Reload
	strb	w8, [sp, #3081]
	ldr	x8, [sp, #952]                  ; 8-byte Folded Reload
	str	w10, [x20]
	ldrh	w10, [sp, #2400]
	str	x8, [sp, #3112]
	ldr	x8, [sp, #896]                  ; 8-byte Folded Reload
	str	d17, [sp, #2640]
	ldr	q17, [sp, #1296]                ; 16-byte Folded Reload
	str	x8, [sp, #3144]
	ldr	w8, [sp, #912]                  ; 4-byte Folded Reload
	str	w9, [sp, #2804]
	ldr	w9, [sp, #1392]                 ; 4-byte Folded Reload
	strb	w8, [sp, #3152]
	ldr	w8, [sp, #936]                  ; 4-byte Folded Reload
	strh	w10, [x23]
	ldr	w10, [sp, #2392]
	strb	w8, [sp, #3164]
	ldr	w8, [sp, #920]                  ; 4-byte Folded Reload
	stur	q17, [x7, #232]
	ldr	d17, [sp, #1288]                ; 8-byte Folded Reload
	strb	w8, [sp, #3165]
	ldr	w8, [sp, #928]                  ; 4-byte Folded Reload
	str	w9, [sp, #2832]
	ldr	w9, [sp, #1384]                 ; 4-byte Folded Reload
	strh	w8, [sp, #3166]
	ldr	w8, [sp, #864]                  ; 4-byte Folded Reload
	str	w10, [x22]
	ldrh	w10, [sp, #2388]
	strb	w8, [sp, #3176]
	ldrh	w8, [sp, #2372]
	str	d17, [x4]
	ldr	d17, [sp, #1280]                ; 8-byte Folded Reload
	str	w9, [sp, #2836]
	ldr	x9, [sp, #776]                  ; 8-byte Folded Reload
	strh	w10, [x14]
	ldr	w10, [sp, #2380]
	strh	w8, [x30, #4]
	ldr	w8, [sp, #1428]                 ; 4-byte Folded Reload
	str	d17, [sp, #2688]
	ldr	d17, [sp, #1272]                ; 8-byte Folded Reload
	str	q0, [x9]
	ldr	x9, [sp, #768]                  ; 8-byte Folded Reload
	str	w10, [x15]
	ldrh	w10, [sp, #2376]
	str	d17, [sp, #2704]
	ldr	q17, [sp, #1248]                ; 16-byte Folded Reload
	strb	w8, [sp, #2780]
	ldr	w8, [sp, #1416]                 ; 4-byte Folded Reload
	str	q4, [x9]
	ldr	x9, [sp, #760]                  ; 8-byte Folded Reload
	strh	w10, [x19]
	ldr	w10, [sp, #1464]                ; 4-byte Folded Reload
	stur	q17, [x4, #36]
	ldr	d17, [sp, #1240]                ; 8-byte Folded Reload
	strb	w8, [sp, #2781]
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	stur	d31, [x7, #68]
	stur	q10, [x7, #104]
	stur	q12, [x7, #136]
	stur	d13, [x7, #164]
	mov	x7, x19
	mov	x19, x13
	str	x13, [sp, #2808]
	mov	x13, x5
	str	q6, [x9]
	add	x9, sp, #2416
	str	d14, [sp, #2448]
	str	d8, [sp, #2496]
	str	d9, [sp, #2512]
	str	d11, [sp, #2544]
	str	d17, [sp, #2736]
	stur	q18, [x4, #68]
	str	d19, [x4, #96]
	str	w8, [sp, #2784]
	str	w10, [sp, #2788]
	str	x24, [sp, #2816]
	str	x25, [sp, #2824]
	str	x5, [sp, #2840]
	str	x27, [sp, #2848]
	str	x28, [sp, #2856]
	str	d20, [x4, #192]
	str	d21, [sp, #2880]
	str	d22, [sp, #2896]
	stur	q23, [x4, #228]
	str	d24, [sp, #2928]
	str	q25, [x11]
	str	d26, [x4, #288]
	str	d27, [sp, #2976]
	str	d28, [sp, #2992]
	str	q29, [x12]
	str	d15, [sp, #3024]
	str	d1, [x4, #384]
	str	d2, [sp, #3072]
	str	d3, [sp, #3088]
	str	d5, [sp, #3120]
	str	d7, [x4, #480]
	str	d16, [sp, #3168]
	b.hi	LBB13_315
; %bb.109:                              ; %b274_to_b59
                                        ;   in Loop: Header=BB13_80 Depth=2
	add	x26, x26, #1
	ldr	w5, [sp, #1364]                 ; 4-byte Folded Reload
	str	x26, [sp, #1368]                ; 8-byte Folded Spill
	ldr	w26, [sp, #1380]                ; 4-byte Folded Reload
	add	w26, w26, #1, lsl #12           ; =4096
	str	w26, [sp, #1380]                ; 4-byte Folded Spill
	ldr	x26, [sp, #1496]                ; 8-byte Folded Reload
	add	x26, x26, #96
	tbnz	w5, #0, LBB13_80
	b	LBB13_25
LBB13_110:                              ; %b82
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	bl	_liza_rt_reactor_finish_connect
	lsr	x8, x0, #32
	cbnz	x8, LBB13_112
; %bb.111:                              ; %b1.i247
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	x0, #1
	mov	w10, wzr
	cset	w9, eq
	b	LBB13_126
LBB13_112:                              ; %v10_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_124
; %bb.113:                              ; %v10_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh18:
	adrp	x12, lJTI13_6@PAGE
Lloh19:
	add	x12, x12, lJTI13_6@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_114
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_114:                              ; %b4.i.i245
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_125
LBB13_115:                              ; %b34.i.i240
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_125
LBB13_116:                              ; %b13.i.i242
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_125
LBB13_117:                              ; %b16.i.i241
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_125
LBB13_118:                              ; %b10.i.i243
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_125
LBB13_119:                              ; %b7.i.i244
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_125
LBB13_120:                              ; %b22.i.i239
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_125
LBB13_121:                              ; %b25.i.i238
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_125
LBB13_122:                              ; %b31.i.i233
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_125
LBB13_123:                              ; %b28.i.i237
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_125
LBB13_124:                              ; %b36.i.i246
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_125:                              ; %liza___liza_reactor_error.exit.i234
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	mov	w10, #1                         ; =0x1
LBB13_126:                              ; %liza_net.reactor_finish_connect.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	cmp	w10, #1
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	b.ne	LBB13_128
; %bb.127:                              ; %b85
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_129
LBB13_128:                              ; %b89
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w8, w9, #0x1
	str	w8, [sp, #1440]                 ; 4-byte Folded Spill
LBB13_129:                              ; %b95
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.hi	LBB13_133
; %bb.130:                              ; %b95
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.hi	LBB13_133
; %bb.131:                              ; %b4.i.i257
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	ldr	w22, [sp, #1456]                ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w16, #0, LBB13_142
; %bb.132:                              ; %b4.i.i257
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w8, w22, w8
	cbnz	w8, LBB13_142
LBB13_133:                              ; %b114
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_172
; %bb.134:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.hi	LBB13_172
; %bb.135:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.hi	LBB13_172
; %bb.136:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbnz	w16, #0, LBB13_172
; %bb.137:                              ; %b118
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, w1
	b.eq	LBB13_172
; %bb.138:                              ; %v253_ok
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	sub	w8, w8, #2048
	adds	w6, w8, w1
	b.hs	LBB13_320
; %bb.139:                              ; %b3.i325
                                        ;   in Loop: Header=BB13_80 Depth=2
	subs	w23, w15, w1
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	b.lo	LBB13_320
; %bb.140:                              ; %liza_relay.direction.queued.exit330
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	mov	w7, w23
	mov	w21, w16
	mov	w22, w15
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1456]                ; 4-byte Folded Reload
	cbnz	x8, LBB13_148
; %bb.141:                              ; %b1.i.i354
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_170
LBB13_142:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.eq	LBB13_133
; %bb.143:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	eor	w8, w22, #0x1
	tbz	w8, #0, LBB13_133
; %bb.144:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #1
	b.eq	LBB13_133
; %bb.145:                              ; %liza_relay.direction.readable.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	and	w8, w23, w8
	cbz	w8, LBB13_133
; %bb.146:                              ; %b4.i.i266
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	mov	w9, #2048                       ; =0x800
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	sub	w20, w9, w15
	tst	w22, #0x1
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	add	w8, w15, w8
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	sub	w6, w8, #2048
	csel	w7, wzr, w20, ne
	mov	x0, x28
	mov	x2, x26
	mov	w21, w16
	str	w15, [sp, #1480]                ; 4-byte Folded Spill
	mov	x23, x26
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB13_151
; %bb.147:                              ; %b104
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w22, #3                         ; =0x3
	mov	w16, w21
	mov	x26, x23
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_133
LBB13_148:                              ; %v8_ok.i.i336
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_168
; %bb.149:                              ; %v8_ok.i.i336
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh20:
	adrp	x12, lJTI13_7@PAGE
Lloh21:
	add	x12, x12, lJTI13_7@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_150
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_150:                              ; %b4.i.i.i352
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_169
LBB13_151:                              ; %b1.i295
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w14, [sp, #1464]                ; 4-byte Folded Reload
	mov	w1, wzr
	orr	w8, w21, w22
	mov	w9, #1                          ; =0x1
	tbnz	w8, #0, LBB13_155
; %bb.152:                              ; %b1.i295
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1432]                ; 4-byte Folded Reload
	cmp	w20, w0
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	x26, x23
	b.lo	LBB13_156
; %bb.153:                              ; %b12.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	cbz	w0, LBB13_158
; %bb.154:                              ; %v26_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1480]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w8, w0
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_157
LBB13_155:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1432]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	x26, x23
LBB13_156:                              ; %liza_relay.direction.read.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #1
	b.eq	LBB13_94
LBB13_157:                              ; %b111
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w9, w11, #0x1
	and	w16, w10, #0x1
	and	w12, w12, #0x1
	and	w13, w13, #0x1
	and	w14, w14, #0x1
	mov	w15, w8
	str	w9, [sp, #1456]                 ; 4-byte Folded Spill
	str	w12, [sp, #1440]                ; 4-byte Folded Spill
	str	w13, [sp, #1432]                ; 4-byte Folded Spill
	str	w14, [sp, #1464]                ; 4-byte Folded Spill
	b	LBB13_133
LBB13_158:                              ; %b13.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w8, [sp, #1480]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_157
LBB13_159:                              ; %b34.i.i.i347
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_169
LBB13_160:                              ; %b13.i.i.i349
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_169
LBB13_161:                              ; %b16.i.i.i348
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_169
LBB13_162:                              ; %b10.i.i.i350
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_169
LBB13_163:                              ; %b7.i.i.i351
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_169
LBB13_164:                              ; %b22.i.i.i346
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_169
LBB13_165:                              ; %b25.i.i.i345
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_169
LBB13_166:                              ; %b31.i.i.i339
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_169
LBB13_167:                              ; %b28.i.i.i344
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_169
LBB13_168:                              ; %b36.i.i.i353
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_169:                              ; %liza___liza_reactor_error.exit.i.i340
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB13_170:                              ; %liza_net.reactor_write.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w15, w22
	mov	w16, w21
	cmp	w9, #1
	b.ne	LBB13_180
; %bb.171:                              ; %b124
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
LBB13_172:                              ; %b134
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_205
LBB13_173:                              ; %b138
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.hi	LBB13_205
; %bb.174:                              ; %b138
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	b.hi	LBB13_205
; %bb.175:                              ; %b4.i.i385
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbnz	w16, #0, LBB13_205
; %bb.176:                              ; %b4.i.i385
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1456]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_205
; %bb.177:                              ; %b4.i.i385
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.ne	LBB13_205
; %bb.178:                              ; %b141
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, w1
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	mov	w23, w16
	mov	w22, w15
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB13_183
; %bb.179:                              ; %b1.i.i414
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_203
LBB13_180:                              ; %b4.i.i368
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1432]                ; 4-byte Folded Reload
	cbz	w0, LBB13_182
; %bb.181:                              ; %b3.i.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w0, w23
	b.ls	LBB13_186
LBB13_182:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w1, wzr
	mov	w15, wzr
	mov	w14, wzr
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_191
LBB13_183:                              ; %v8_ok.i.i396
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_201
; %bb.184:                              ; %v8_ok.i.i396
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh22:
	adrp	x12, lJTI13_8@PAGE
Lloh23:
	add	x12, x12, lJTI13_8@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_185
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_185:                              ; %b4.i.i.i412
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_202
LBB13_186:                              ; %b9.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	adds	w1, w1, w0
	b.hs	LBB13_320
; %bb.187:                              ; %v13_ok.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	b.ne	LBB13_189
; %bb.188:                              ; %b10.i
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	mov	w1, wzr
	mov	w15, wzr
	b	LBB13_190
LBB13_189:                              ; %b12.i374
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
LBB13_190:                              ; %liza_relay.direction.write.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB13_94
LBB13_191:                              ; %b131
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w16, w8, #0x1
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	and	w14, w14, #0x1
	and	w13, w13, #0x1
	and	w10, w10, #0x1
	str	w14, [sp, #1456]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w13, [sp, #1440]                ; 4-byte Folded Spill
	str	w10, [sp, #1432]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_173
	b	LBB13_205
LBB13_192:                              ; %b34.i.i.i407
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_202
LBB13_193:                              ; %b13.i.i.i409
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_202
LBB13_194:                              ; %b16.i.i.i408
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_202
LBB13_195:                              ; %b10.i.i.i410
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_202
LBB13_196:                              ; %b7.i.i.i411
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_202
LBB13_197:                              ; %b22.i.i.i406
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_202
LBB13_198:                              ; %b25.i.i.i405
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_202
LBB13_199:                              ; %b31.i.i.i399
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_202
LBB13_200:                              ; %b28.i.i.i404
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_202
LBB13_201:                              ; %b36.i.i.i413
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_202:                              ; %liza___liza_reactor_error.exit.i.i400
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
LBB13_203:                              ; %liza_net.reactor_shutdown_write.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1432]                ; 4-byte Folded Reload
	mov	w1, w20
	mov	w15, w22
	mov	w16, w23
	cmp	w9, #1
	b.ne	LBB13_215
; %bb.204:                              ; %b144
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
LBB13_205:                              ; %b154
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_216
LBB13_206:                              ; %b158
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1448]                 ; 4-byte Folded Reload
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	cmp	w8, w9
	b.hi	LBB13_216
; %bb.207:                              ; %b158
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #2048
	b.hi	LBB13_216
; %bb.208:                              ; %b4.i.i435
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w8, w9
	ldr	w22, [sp, #1432]                ; 4-byte Folded Reload
	ldr	w10, [sp, #1464]                ; 4-byte Folded Reload
	cset	w8, eq
	tbz	w10, #0, LBB13_210
; %bb.209:                              ; %b4.i.i435
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w8, w22, w8
	cbz	w8, LBB13_216
LBB13_210:                              ; %liza_relay.direction.readable.exit445
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #2048
	b.eq	LBB13_216
; %bb.211:                              ; %liza_relay.direction.readable.exit445
                                        ;   in Loop: Header=BB13_80 Depth=2
	eor	w8, w22, #0x1
	tbz	w8, #0, LBB13_216
; %bb.212:                              ; %liza_relay.direction.readable.exit445
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x9, [sp, #1392]                 ; 8-byte Folded Reload
	mov	w8, #5                          ; =0x5
	and	w8, w9, w8
	cbz	w8, LBB13_216
; %bb.213:                              ; %b4.i.i452
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	mov	w8, #2048                       ; =0x800
	tst	w22, #0x1
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	sub	w20, w8, w9
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	mov	x0, x28
	csel	w7, wzr, w20, ne
	mov	x1, x24
	mov	x2, x25
	add	w6, w9, w8
	mov	x3, x19
	str	w16, [sp, #1472]                ; 4-byte Folded Spill
	mov	w21, w15
	bl	_liza_rt_reactor_read
	lsr	x8, x0, #32
	cbz	x8, LBB13_228
; %bb.214:                              ; %b167
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #7654                       ; =0x1de6
	mov	w22, #3                         ; =0x3
	mov	w15, w21
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_216
LBB13_215:                              ; %b151
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	and	w10, w10, #0x1
	and	w11, w11, #0x1
	mov	w15, w1
	mov	w16, #1                         ; =0x1
	str	w10, [sp, #1440]                ; 4-byte Folded Spill
	and	w8, w8, #0x1
	str	w11, [sp, #1432]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #1456]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_206
LBB13_216:                              ; %b177
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_254
LBB13_217:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w20, [sp, #1448]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	str	x26, [sp, #1392]                ; 8-byte Folded Spill
	cmp	w20, w8
	b.hi	LBB13_253
; %bb.218:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w8, #2048
	b.hi	LBB13_253
; %bb.219:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w9, [sp, #1464]                 ; 4-byte Folded Reload
	tbnz	w9, #0, LBB13_253
; %bb.220:                              ; %b181
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w8, w20
	b.eq	LBB13_253
; %bb.221:                              ; %v393_ok
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1380]                 ; 4-byte Folded Reload
	adds	w6, w8, w20
	b.hs	LBB13_320
; %bb.222:                              ; %b3.i550
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	subs	w23, w8, w20
	b.lo	LBB13_320
; %bb.223:                              ; %liza_relay.direction.queued.exit555
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	ldr	x2, [sp, #1392]                 ; 8-byte Folded Reload
	mov	x0, x28
	ldr	x4, [sp, #144]                  ; 8-byte Folded Reload
	ldr	w5, [sp, #152]                  ; 4-byte Folded Reload
	mov	w7, w23
	mov	w21, w16
	mov	w22, w15
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	ldr	w13, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w14, [sp, #1432]                ; 4-byte Folded Reload
	cbnz	x8, LBB13_225
; %bb.224:                              ; %b1.i.i581
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_243
LBB13_225:                              ; %v8_ok.i.i563
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_241
; %bb.226:                              ; %v8_ok.i.i563
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh24:
	adrp	x12, lJTI13_9@PAGE
Lloh25:
	add	x12, x12, lJTI13_9@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_227
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_227:                              ; %b4.i.i.i579
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_242
LBB13_228:                              ; %b1.i496
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	mov	w1, wzr
	mov	w9, #1                          ; =0x1
	orr	w8, w8, w22
	tbnz	w8, #0, LBB13_265
; %bb.229:                              ; %b1.i496
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1456]                ; 4-byte Folded Reload
	cmp	w20, w0
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	mov	w8, w1
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
	b.lo	LBB13_266
; %bb.230:                              ; %b12.i502
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	cbz	w0, LBB13_268
; %bb.231:                              ; %v26_ok.i504
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1448]                 ; 4-byte Folded Reload
	mov	w11, wzr
	mov	w10, wzr
	add	w8, w8, w0
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_267
LBB13_232:                              ; %b34.i.i.i574
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_242
LBB13_233:                              ; %b13.i.i.i576
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_242
LBB13_234:                              ; %b16.i.i.i575
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_242
LBB13_235:                              ; %b10.i.i.i577
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_242
LBB13_236:                              ; %b7.i.i.i578
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_242
LBB13_237:                              ; %b22.i.i.i573
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_242
LBB13_238:                              ; %b25.i.i.i572
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_242
LBB13_239:                              ; %b31.i.i.i566
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_242
LBB13_240:                              ; %b28.i.i.i571
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_242
LBB13_241:                              ; %b36.i.i.i580
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_242:                              ; %liza___liza_reactor_error.exit.i.i567
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w0, wzr
	mov	w9, #1                          ; =0x1
LBB13_243:                              ; %liza_net.reactor_write.exit584
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w15, w22
	mov	w16, w21
	cmp	w9, #1
	b.ne	LBB13_245
; %bb.244:                              ; %b187
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	ldr	x26, [sp, #1392]                ; 8-byte Folded Reload
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	mov	w22, #3                         ; =0x3
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_254
LBB13_245:                              ; %b4.i.i596
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1456]                ; 4-byte Folded Reload
	cbz	w0, LBB13_247
; %bb.246:                              ; %b3.i.i608
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w0, w23
	b.ls	LBB13_248
LBB13_247:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w20, wzr
	str	wzr, [sp, #1468]                ; 4-byte Folded Spill
	mov	w14, wzr
	mov	w8, wzr
	mov	w9, #1                          ; =0x1
	cmp	w9, #1
	b.ne	LBB13_252
	b	LBB13_313
LBB13_248:                              ; %b9.i614
                                        ;   in Loop: Header=BB13_80 Depth=2
	adds	w20, w20, w0
	b.hs	LBB13_320
; %bb.249:                              ; %v13_ok.i618
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	mov	w9, wzr
	cmp	w20, w8
	b.ne	LBB13_251
; %bb.250:                              ; %b10.i626
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, wzr
	str	wzr, [sp, #1468]                ; 4-byte Folded Spill
LBB13_251:                              ; %liza_relay.direction.write.exit636
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, wzr
	cmp	w9, #1
	b.eq	LBB13_313
LBB13_252:                              ; %b194
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w14, w14, #0x1
	and	w8, w8, #0x1
	and	w13, w13, #0x1
	and	w10, w10, #0x1
	and	w16, w16, #0x1
	str	w20, [sp, #1448]                ; 4-byte Folded Spill
	str	w14, [sp, #1432]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
	str	w13, [sp, #1440]                ; 4-byte Folded Spill
	str	w10, [sp, #1456]                ; 4-byte Folded Spill
LBB13_253:                              ; %b197
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x26, [sp, #1392]                ; 8-byte Folded Reload
LBB13_254:                              ; %b197
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_283
; %bb.255:                              ; %b201
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w20, [sp, #1448]                ; 4-byte Folded Reload
	ldr	w9, [sp, #1468]                 ; 4-byte Folded Reload
	cmp	w20, w9
	b.hi	LBB13_283
; %bb.256:                              ; %b201
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #2048
	b.hi	LBB13_283
; %bb.257:                              ; %b4.i.i644
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_283
; %bb.258:                              ; %b4.i.i644
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1432]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_283
; %bb.259:                              ; %b4.i.i644
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w20, w9
	b.ne	LBB13_283
; %bb.260:                              ; %b204
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w21, w1
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x2, x26
	mov	w22, w16
	str	w15, [sp, #1480]                ; 4-byte Folded Spill
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB13_262
; %bb.261:                              ; %b1.i.i678
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, wzr
	b	LBB13_280
LBB13_262:                              ; %v8_ok.i.i660
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w9, w8, #1
	cmp	w9, #11
	b.hi	LBB13_278
; %bb.263:                              ; %v8_ok.i.i660
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh26:
	adrp	x12, lJTI13_10@PAGE
Lloh27:
	add	x12, x12, lJTI13_10@PAGEOFF
	mov	w8, wzr
	adr	x10, LBB13_264
	ldrb	w11, [x12, x9]
	add	x10, x10, x11, lsl #2
	br	x10
LBB13_264:                              ; %b4.i.i.i676
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB13_279
LBB13_265:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w13, [sp, #1456]                ; 4-byte Folded Reload
	mov	w8, w1
	ldr	w16, [sp, #1472]                ; 4-byte Folded Reload
	mov	w11, w1
	mov	w10, w1
	mov	w15, w21
LBB13_266:                              ; %liza_relay.direction.read.exit517
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w9, #1
	b.eq	LBB13_94
LBB13_267:                              ; %b174
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w9, w11, #0x1
	str	w1, [sp, #1448]                 ; 4-byte Folded Spill
	ldr	w1, [sp, #1492]                 ; 4-byte Folded Reload
	str	w9, [sp, #1432]                 ; 4-byte Folded Spill
	and	w9, w10, #0x1
	and	w12, w12, #0x1
	and	w13, w13, #0x1
	and	w16, w16, #0x1
	str	w9, [sp, #1464]                 ; 4-byte Folded Spill
	str	w12, [sp, #1440]                ; 4-byte Folded Spill
	str	w13, [sp, #1456]                ; 4-byte Folded Spill
	str	w8, [sp, #1468]                 ; 4-byte Folded Spill
	ldr	w8, [sp, #1440]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_217
	b	LBB13_254
LBB13_268:                              ; %b13.i511
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w1, [sp, #1448]                 ; 4-byte Folded Reload
	ldr	w8, [sp, #1468]                 ; 4-byte Folded Reload
	mov	w10, wzr
	mov	w11, #1                         ; =0x1
	cmp	w9, #1
	b.eq	LBB13_94
	b	LBB13_267
LBB13_269:                              ; %b34.i.i.i671
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #11                         ; =0xb
	b	LBB13_279
LBB13_270:                              ; %b13.i.i.i673
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #4                          ; =0x4
	b	LBB13_279
LBB13_271:                              ; %b16.i.i.i672
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #5                          ; =0x5
	b	LBB13_279
LBB13_272:                              ; %b10.i.i.i674
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #3                          ; =0x3
	b	LBB13_279
LBB13_273:                              ; %b7.i.i.i675
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB13_279
LBB13_274:                              ; %b22.i.i.i670
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #7                          ; =0x7
	b	LBB13_279
LBB13_275:                              ; %b25.i.i.i669
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #8                          ; =0x8
	b	LBB13_279
LBB13_276:                              ; %b31.i.i.i663
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #10                         ; =0xa
	b	LBB13_279
LBB13_277:                              ; %b28.i.i.i668
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #9                          ; =0x9
	b	LBB13_279
LBB13_278:                              ; %b36.i.i.i677
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #6                          ; =0x6
LBB13_279:                              ; %liza___liza_reactor_error.exit.i.i664
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
LBB13_280:                              ; %liza_net.reactor_shutdown_write.exit681
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w10, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w11, [sp, #1456]                ; 4-byte Folded Reload
	mov	w1, w21
	ldr	w15, [sp, #1480]                ; 4-byte Folded Reload
	mov	w16, w22
	cmp	w9, #1
	b.ne	LBB13_282
; %bb.281:                              ; %b207
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w9, #1                          ; =0x1
	mov	w22, #3                         ; =0x3
	lsl	w8, w9, w8
	mov	w9, #3827                       ; =0xef3
	tst	w8, w9
	b.ne	LBB13_95
	b	LBB13_283
LBB13_282:                              ; %b214
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w10, w10, #0x1
	and	w11, w11, #0x1
	and	w16, w16, #0x1
	mov	w8, #1                          ; =0x1
	str	w10, [sp, #1440]                ; 4-byte Folded Spill
	str	w11, [sp, #1456]                ; 4-byte Folded Spill
	str	w8, [sp, #1432]                 ; 4-byte Folded Spill
	str	w20, [sp, #1468]                ; 4-byte Folded Spill
	str	w8, [sp, #1464]                 ; 4-byte Folded Spill
LBB13_283:                              ; %b217
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbz	w16, #0, LBB13_285
; %bb.284:                              ; %b217
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w22, [sp, #1404]                ; 4-byte Folded Reload
	ldr	w8, [sp, #1464]                 ; 4-byte Folded Reload
	tbnz	w8, #0, LBB13_95
LBB13_285:                              ; %b227
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	mov	w8, #2049                       ; =0x801
	ccmp	w15, w8, #2, ls
	cset	w8, lo
	cmp	w8, #1
	b.ne	LBB13_288
; %bb.286:                              ; %b4.i.i713
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w1, w15
	ldr	w10, [sp, #1456]                ; 4-byte Folded Reload
	cset	w9, eq
	tbz	w16, #0, LBB13_289
; %bb.287:                              ; %b4.i.i713
                                        ;   in Loop: Header=BB13_80 Depth=2
	and	w9, w10, w9
	cbnz	w9, LBB13_289
LBB13_288:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w4, wzr
	b	LBB13_290
LBB13_289:                              ; %b1.i720
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, #2048
	eor	w10, w10, #0x1
	cset	w9, ne
	and	w4, w9, w10
LBB13_290:                              ; %liza_relay.direction.readable.exit723
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w13, [sp, #1448]                ; 4-byte Folded Reload
	ldr	w21, [sp, #1468]                ; 4-byte Folded Reload
	ldr	w12, [sp, #1440]                ; 4-byte Folded Reload
	ldr	w22, [sp, #1432]                ; 4-byte Folded Reload
	str	w1, [sp, #1492]                 ; 4-byte Folded Spill
	cmp	w13, w21
	str	w15, [sp, #1480]                ; 4-byte Folded Spill
	str	w16, [sp, #1472]                ; 4-byte Folded Spill
	b.hi	LBB13_295
; %bb.291:                              ; %liza_relay.direction.readable.exit723
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #2048
	b.hi	LBB13_295
; %bb.292:                              ; %b4.i.i730
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, w13
	ldr	w9, [sp, #1464]                 ; 4-byte Folded Reload
	orr	w11, w4, #0x2
	cset	w10, ne
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	eor	w9, w9, #0x1
	orr	w10, w10, w22
	and	w10, w9, w10
	tst	w10, #0x1
	csel	w4, w11, w4, ne
	tbz	w12, #0, LBB13_302
; %bb.293:                              ; %b4.i.i767
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, w13
	cset	w10, eq
	and	w10, w22, w10
	orr	w9, w9, w10
	tbz	w9, #0, LBB13_296
; %bb.294:                              ; %b1.i774
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w21, #2048
	eor	w10, w22, #0x1
	cset	w9, ne
	and	w23, w9, w10
	cbnz	w8, LBB13_297
	b	LBB13_303
LBB13_295:                              ; %b237.thread
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x3, [sp, #1416]                 ; 8-byte Folded Reload
	tbz	w12, #0, LBB13_302
LBB13_296:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w23, wzr
	cbz	w8, LBB13_303
LBB13_297:                              ; %b4.i.i784
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, w1
	cset	w8, ne
	bic	w8, w8, w16
	tbnz	w8, #0, LBB13_301
; %bb.298:                              ; %b4.i.i804
                                        ;   in Loop: Header=BB13_80 Depth=2
	tbnz	w16, #0, LBB13_303
; %bb.299:                              ; %b4.i.i804
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	w8, [sp, #1456]                 ; 4-byte Folded Reload
	tbz	w8, #0, LBB13_303
; %bb.300:                              ; %b4.i.i804
                                        ;   in Loop: Header=BB13_80 Depth=2
	cmp	w15, w1
	b.ne	LBB13_303
LBB13_301:                              ; %b246
                                        ;   in Loop: Header=BB13_80 Depth=2
	orr	w23, w23, #0x2
	b	LBB13_303
LBB13_302:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w23, #2                         ; =0x2
LBB13_303:                              ; %b249
                                        ;   in Loop: Header=BB13_80 Depth=2
	ldr	x1, [sp, #1408]                 ; 8-byte Folded Reload
	mov	x0, x28
	mov	x2, x26
	str	x3, [sp, #1416]                 ; 8-byte Folded Spill
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	str	x26, [sp, #1392]                ; 8-byte Folded Spill
	cbnz	x8, LBB13_305
; %bb.304:                              ; %b1.i.i838
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, wzr
	b	LBB13_308
LBB13_305:                              ; %v8_ok.i.i820
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_307
; %bb.306:                              ; %v8_ok.i.i820
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh28:
	adrp	x11, lJTI13_11@PAGE
Lloh29:
	add	x11, x11, lJTI13_11@PAGEOFF
	adr	x9, LBB13_307
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_307:                              ; %liza___liza_reactor_error.exit.i.i824
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w20, #1                         ; =0x1
LBB13_308:                              ; %liza_net.reactor_interest.exit
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	x0, x28
	mov	x1, x24
	mov	x2, x25
	mov	x3, x19
	mov	w4, w23
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbz	x8, LBB13_312
; %bb.309:                              ; %v8_ok.i.i846
                                        ;   in Loop: Header=BB13_80 Depth=2
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB13_311
; %bb.310:                              ; %v8_ok.i.i846
                                        ;   in Loop: Header=BB13_80 Depth=2
Lloh30:
	adrp	x11, lJTI13_12@PAGE
Lloh31:
	add	x11, x11, lJTI13_12@PAGEOFF
	adr	x9, LBB13_311
	ldrb	w10, [x11, x8]
	add	x9, x9, x10, lsl #2
	br	x9
LBB13_311:                              ; %liza___liza_reactor_error.exit.i.i850
                                        ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
LBB13_312:                              ; %b258
                                        ;   in Loop: Header=BB13_80 Depth=2
	orr	w8, w8, w20
	cbz	w8, LBB13_314
LBB13_313:                              ;   in Loop: Header=BB13_80 Depth=2
	ldr	x26, [sp, #1392]                ; 8-byte Folded Reload
	b	LBB13_94
LBB13_314:                              ;   in Loop: Header=BB13_80 Depth=2
	mov	w8, #1                          ; =0x1
	ldr	x23, [sp, #1408]                ; 8-byte Folded Reload
	ldr	w26, [sp, #1440]                ; 4-byte Folded Reload
	str	w22, [sp, #1432]                ; 4-byte Folded Spill
	ldr	w22, [sp, #1428]                ; 4-byte Folded Reload
	ldr	x28, [sp, #1392]                ; 8-byte Folded Reload
	ldr	x20, [sp, #1416]                ; 8-byte Folded Reload
	str	w8, [sp, #1364]                 ; 4-byte Folded Spill
	str	w21, [sp, #1468]                ; 4-byte Folded Spill
	b	LBB13_107
LBB13_315:                              ;   in Loop: Header=BB13_26 Depth=1
	ldr	w5, [sp, #1364]                 ; 4-byte Folded Reload
	b	LBB13_25
LBB13_316:                              ;   in Loop: Header=BB13_26 Depth=1
	mov	w9, #1                          ; =0x1
	add	x3, sp, #1, lsl #12             ; =4096
	add	x16, sp, #1, lsl #12            ; =4096
	str	w9, [sp, #1320]                 ; 4-byte Folded Spill
	add	x7, sp, #1, lsl #12             ; =4096
	add	x14, sp, #1, lsl #12            ; =4096
	add	x13, sp, #1, lsl #12            ; =4096
	add	x19, sp, #1, lsl #12            ; =4096
	add	x12, sp, #1, lsl #12            ; =4096
	add	x4, sp, #1, lsl #12             ; =4096
	add	x11, sp, #1, lsl #12            ; =4096
	add	x1, sp, #1, lsl #12             ; =4096
	add	x10, sp, #1, lsl #12            ; =4096
	add	x17, sp, #1, lsl #12            ; =4096
	add	x9, sp, #1, lsl #12             ; =4096
	add	x15, sp, #1, lsl #12            ; =4096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x2, sp, #1, lsl #12             ; =4096
	add	x5, sp, #1, lsl #12             ; =4096
	add	x6, sp, #1, lsl #12             ; =4096
	add	x23, sp, #1, lsl #12            ; =4096
	add	x24, sp, #1, lsl #12            ; =4096
	add	x22, sp, #1, lsl #12            ; =4096
	add	x25, sp, #1, lsl #12            ; =4096
	add	x20, sp, #1, lsl #12            ; =4096
	add	x26, sp, #1, lsl #12            ; =4096
	add	x3, x3, #216
	add	x16, x16, #158
	add	x7, x7, #224
	add	x14, x14, #228
	add	x13, x13, #170
	add	x19, x19, #236
	add	x12, x12, #240
	add	x4, x4, #182
	add	x11, x11, #248
	add	x1, x1, #252
	add	x10, x10, #194
	add	x17, x17, #260
	add	x9, x9, #264
	add	x15, x15, #208
	add	x0, x0, #272
	add	x2, x2, #276
	add	x5, x5, #210
	add	x6, x6, #284
	add	x23, x23, #288
	add	x24, x24, #212
	add	x22, x22, #296
	add	x25, x25, #300
	add	x20, x20, #214
	add	x26, x26, #308
	b	LBB13_77
LBB13_317:                              ; %b1.i147
                                        ;   in Loop: Header=BB13_26 Depth=1
	ldr	x10, [sp, #4536]
	ldr	x9, [sp, #4544]
	mov	w11, wzr
	ldr	x8, [sp, #4552]
	b	LBB13_73
LBB13_318:                              ; %b15
	ldr	x0, [sp, #720]                  ; 8-byte Folded Reload
	bl	_liza_rt_reactor_close
	mov	w8, #3                          ; =0x3
	cmp	w0, #0
	csel	w0, w21, w8, eq
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #464
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB13_319:                              ; %b1.i.i49
	mov	w19, wzr
	b	LBB13_14
LBB13_320:                              ; %v256_trap
	brk	#0x1
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh16, Lloh17
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.loh AdrpAdd	Lloh30, Lloh31
	.cfi_endproc
	.section	__TEXT,__const
lJTI13_0:
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
	.byte	(LBB13_3-LBB13_3)>>2
lJTI13_1:
	.byte	(LBB13_41-LBB13_30)>>2
	.byte	(LBB13_30-LBB13_30)>>2
	.byte	(LBB13_35-LBB13_30)>>2
	.byte	(LBB13_34-LBB13_30)>>2
	.byte	(LBB13_32-LBB13_30)>>2
	.byte	(LBB13_33-LBB13_30)>>2
	.byte	(LBB13_40-LBB13_30)>>2
	.byte	(LBB13_36-LBB13_30)>>2
	.byte	(LBB13_37-LBB13_30)>>2
	.byte	(LBB13_39-LBB13_30)>>2
	.byte	(LBB13_38-LBB13_30)>>2
	.byte	(LBB13_31-LBB13_30)>>2
lJTI13_2:
	.byte	(LBB13_52-LBB13_52)>>2
	.byte	(LBB13_66-LBB13_52)>>2
	.byte	(LBB13_56-LBB13_52)>>2
	.byte	(LBB13_61-LBB13_52)>>2
	.byte	(LBB13_62-LBB13_52)>>2
	.byte	(LBB13_57-LBB13_52)>>2
	.byte	(LBB13_59-LBB13_52)>>2
	.byte	(LBB13_65-LBB13_52)>>2
	.byte	(LBB13_60-LBB13_52)>>2
	.byte	(LBB13_64-LBB13_52)>>2
	.byte	(LBB13_63-LBB13_52)>>2
	.byte	(LBB13_55-LBB13_52)>>2
	.byte	(LBB13_58-LBB13_52)>>2
	.p2align	1, 0x0
lJTI13_3:
	.short	(LBB13_317-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
	.short	(LBB13_72-LBB13_72)>>2
lJTI13_4:
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
	.byte	(LBB13_88-LBB13_88)>>2
lJTI13_5:
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
	.byte	(LBB13_92-LBB13_92)>>2
lJTI13_6:
	.byte	(LBB13_125-LBB13_114)>>2
	.byte	(LBB13_114-LBB13_114)>>2
	.byte	(LBB13_119-LBB13_114)>>2
	.byte	(LBB13_118-LBB13_114)>>2
	.byte	(LBB13_116-LBB13_114)>>2
	.byte	(LBB13_117-LBB13_114)>>2
	.byte	(LBB13_124-LBB13_114)>>2
	.byte	(LBB13_120-LBB13_114)>>2
	.byte	(LBB13_121-LBB13_114)>>2
	.byte	(LBB13_123-LBB13_114)>>2
	.byte	(LBB13_122-LBB13_114)>>2
	.byte	(LBB13_115-LBB13_114)>>2
lJTI13_7:
	.byte	(LBB13_169-LBB13_150)>>2
	.byte	(LBB13_150-LBB13_150)>>2
	.byte	(LBB13_163-LBB13_150)>>2
	.byte	(LBB13_162-LBB13_150)>>2
	.byte	(LBB13_160-LBB13_150)>>2
	.byte	(LBB13_161-LBB13_150)>>2
	.byte	(LBB13_168-LBB13_150)>>2
	.byte	(LBB13_164-LBB13_150)>>2
	.byte	(LBB13_165-LBB13_150)>>2
	.byte	(LBB13_167-LBB13_150)>>2
	.byte	(LBB13_166-LBB13_150)>>2
	.byte	(LBB13_159-LBB13_150)>>2
lJTI13_8:
	.byte	(LBB13_202-LBB13_185)>>2
	.byte	(LBB13_185-LBB13_185)>>2
	.byte	(LBB13_196-LBB13_185)>>2
	.byte	(LBB13_195-LBB13_185)>>2
	.byte	(LBB13_193-LBB13_185)>>2
	.byte	(LBB13_194-LBB13_185)>>2
	.byte	(LBB13_201-LBB13_185)>>2
	.byte	(LBB13_197-LBB13_185)>>2
	.byte	(LBB13_198-LBB13_185)>>2
	.byte	(LBB13_200-LBB13_185)>>2
	.byte	(LBB13_199-LBB13_185)>>2
	.byte	(LBB13_192-LBB13_185)>>2
lJTI13_9:
	.byte	(LBB13_242-LBB13_227)>>2
	.byte	(LBB13_227-LBB13_227)>>2
	.byte	(LBB13_236-LBB13_227)>>2
	.byte	(LBB13_235-LBB13_227)>>2
	.byte	(LBB13_233-LBB13_227)>>2
	.byte	(LBB13_234-LBB13_227)>>2
	.byte	(LBB13_241-LBB13_227)>>2
	.byte	(LBB13_237-LBB13_227)>>2
	.byte	(LBB13_238-LBB13_227)>>2
	.byte	(LBB13_240-LBB13_227)>>2
	.byte	(LBB13_239-LBB13_227)>>2
	.byte	(LBB13_232-LBB13_227)>>2
lJTI13_10:
	.byte	(LBB13_279-LBB13_264)>>2
	.byte	(LBB13_264-LBB13_264)>>2
	.byte	(LBB13_273-LBB13_264)>>2
	.byte	(LBB13_272-LBB13_264)>>2
	.byte	(LBB13_270-LBB13_264)>>2
	.byte	(LBB13_271-LBB13_264)>>2
	.byte	(LBB13_278-LBB13_264)>>2
	.byte	(LBB13_274-LBB13_264)>>2
	.byte	(LBB13_275-LBB13_264)>>2
	.byte	(LBB13_277-LBB13_264)>>2
	.byte	(LBB13_276-LBB13_264)>>2
	.byte	(LBB13_269-LBB13_264)>>2
lJTI13_11:
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
	.byte	(LBB13_307-LBB13_307)>>2
lJTI13_12:
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
	.byte	(LBB13_311-LBB13_311)>>2
lJTI13_13:
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
	.byte	(LBB13_101-LBB13_101)>>2
lJTI13_14:
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
	.byte	(LBB13_105-LBB13_105)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_liza_proxy.serve          ; -- Begin function liza_liza_proxy.serve
	.p2align	2
_liza_liza_proxy.serve:                 ; @liza_liza_proxy.serve
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	w20, w1
	mov	x19, x0
	add	x1, sp, #12
	mov	w0, #32768                      ; =0x8000
	mov	w21, w2
	bl	_liza_rt_region_create
	ldr	w8, [sp, #12]
	cbnz	w8, LBB14_3
; %bb.1:                                ; %b3
	add	x4, sp, #8
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	w3, #32768                      ; =0x8000
	mov	x22, x0
	bl	_liza_rt_region_alloc
	ldr	w8, [sp, #8]
	cbz	w8, LBB14_5
; %bb.2:                                ; %b5
	mov	x0, x22
	bl	_liza_rt_region_close
LBB14_3:                                ; %b2
	mov	x0, x19
	bl	_liza_rt_reactor_close
	mov	w0, #3                          ; =0x3
LBB14_4:                                ; %common.ret
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB14_5:                                ; %v10_body.preheader
	mov	w1, #32768                      ; =0x8000
	mov	x23, x0
	bl	_bzero
	and	w4, w21, #0x1
	mov	x0, x19
	mov	x1, x23
	mov	w2, #32768                      ; =0x8000
	mov	w3, w20
	bl	_liza_liza_proxy.exchange
	mov	w19, w0
	mov	x0, x22
	bl	_liza_rt_region_close
	mov	w0, w19
	b	LBB14_4
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_main                      ; -- Begin function liza_main
	.p2align	2
_liza_main:                             ; @liza_main
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	bl	_liza_rt_cli_count
	cmp	w0, #1
	b.ne	LBB15_6
; %bb.1:
	mov	w19, wzr
	mov	w0, #9004                       ; =0x232c
LBB15_2:                                ; %b16
	mov	x2, sp
	mov	w1, #16                         ; =0x10
	bl	_liza_rt_reactor_create
	cmp	w0, #12
	b.hi	LBB15_4
; %bb.3:                                ; %b16
	mov	w8, w0
Lloh32:
	adrp	x9, lJTI15_0@PAGE
Lloh33:
	add	x9, x9, lJTI15_0@PAGEOFF
	adr	x10, LBB15_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB15_4:                                ; %liza___liza_reactor_error.exit.i
	mov	x20, xzr
	mov	w8, #1                          ; =0x1
	cmp	w8, #1
	b.ne	LBB15_15
LBB15_5:                                ; %b18
Lloh34:
	adrp	x0, l_text.main.v37@PAGE
Lloh35:
	add	x0, x0, l_text.main.v37@PAGEOFF
	mov	w1, #31                         ; =0x1f
	bl	_liza_rt_err_text
	b	LBB15_19
LBB15_6:                                ; %b1
	bl	_liza_rt_cli_count
	cmp	w0, #2
	b.ne	LBB15_9
; %bb.7:                                ; %b5
	bl	_liza_rt_cli_count
	cmp	w0, #2
	b.hs	LBB15_11
; %bb.8:
	mov	w0, #2                          ; =0x2
	b	LBB15_20
LBB15_9:                                ; %b3
Lloh36:
	adrp	x0, l_text.main.v9@PAGE
Lloh37:
	add	x0, x0, l_text.main.v9@PAGEOFF
LBB15_10:                               ; %common.ret
	mov	w1, #41                         ; =0x29
	bl	_liza_rt_err_text
	mov	w0, #2                          ; =0x2
	b	LBB15_20
LBB15_11:                               ; %b8
Lloh38:
	adrp	x1, l_text.main.v17@PAGE
Lloh39:
	add	x1, x1, l_text.main.v17@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_liza_rt_cli_equals
	cbnz	w0, LBB15_13
; %bb.12:                               ; %b9
Lloh40:
	adrp	x1, l_text.main.v21@PAGE
Lloh41:
	add	x1, x1, l_text.main.v21@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #11                         ; =0xb
	bl	_liza_rt_cli_equals
	cbz	w0, LBB15_22
LBB15_13:                               ; %b14
Lloh42:
	adrp	x1, l_text.main.v28@PAGE
Lloh43:
	add	x1, x1, l_text.main.v28@PAGEOFF
	mov	w0, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_liza_rt_cli_equals
	mov	w8, w0
	mov	w0, wzr
	cmp	w8, #0
	cset	w19, ne
	b	LBB15_2
LBB15_14:                               ; %b1.i
	ldr	x20, [sp]
	mov	w8, wzr
	cmp	w8, #1
	b.eq	LBB15_5
LBB15_15:                               ; %b19
	mov	x1, sp
	mov	w0, #32768                      ; =0x8000
	bl	_liza_rt_region_create
	ldr	w8, [sp]
	cbnz	w8, LBB15_18
; %bb.16:                               ; %b3.i
	add	x4, sp, #12
	mov	w1, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	mov	w3, #32768                      ; =0x8000
	mov	x21, x0
	bl	_liza_rt_region_alloc
	ldr	w8, [sp, #12]
	cbz	w8, LBB15_21
; %bb.17:                               ; %b5.i
	mov	x0, x21
	bl	_liza_rt_region_close
LBB15_18:                               ; %b2.i
	mov	x0, x20
	bl	_liza_rt_reactor_close
LBB15_19:                               ; %common.ret
	mov	w0, #3                          ; =0x3
LBB15_20:                               ; %common.ret
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB15_21:                               ; %v10_body.preheader.i
	mov	w1, #32768                      ; =0x8000
	mov	x22, x0
	bl	_bzero
	mov	x0, x20
	mov	x1, x22
	mov	w2, #32768                      ; =0x8000
	mov	w3, #9003                       ; =0x232b
	mov	w4, w19
	bl	_liza_liza_proxy.exchange
	mov	w19, w0
	mov	x0, x21
	bl	_liza_rt_region_close
	mov	w0, w19
	b	LBB15_20
LBB15_22:                               ; %b12
Lloh44:
	adrp	x0, l_text.main.v25@PAGE
Lloh45:
	add	x0, x0, l_text.main.v25@PAGEOFF
	b	LBB15_10
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.cfi_endproc
	.section	__TEXT,__const
lJTI15_0:
	.byte	(LBB15_14-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
	.byte	(LBB15_4-LBB15_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza___liza_decode             ; -- Begin function liza___liza_decode
	.p2align	2
_liza___liza_decode:                    ; @liza___liza_decode
; %bb.0:                                ; %b0
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB16_5
; %bb.1:                                ; %b0
	cbz	w8, LBB16_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB16_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB16_11
; %bb.4:                                ; %b7
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ret
LBB16_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB16_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB16_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB16_11
; %bb.8:                                ; %b16
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB16_9:                                ; %b1
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ret
LBB16_10:                               ; %b10
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	mov	w0, #1                          ; =0x1
	ret
LBB16_11:                               ; %b18
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	mov	w0, #1                          ; =0x1
	ret
LBB16_12:                               ; %b4
	mov	x1, xzr
	mov	w2, wzr
	mov	w0, #1                          ; =0x1
	ret
LBB16_13:                               ; %b13
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_liza_console.write             ; -- Begin function liza_console.write
	.p2align	2
_liza_console.write:                    ; @liza_console.write
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_write_text
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB17_5
; %bb.1:                                ; %b0
	cbz	w8, LBB17_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB17_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB17_11
; %bb.4:                                ; %b7.i
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB17_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB17_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB17_11
; %bb.8:                                ; %b16.i
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	b	LBB17_14
LBB17_9:                                ; %b1.i
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_10:                               ; %b10.i
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	b	LBB17_14
LBB17_11:                               ; %b18.i
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	b	LBB17_14
LBB17_12:                               ; %b4.i
	mov	x1, xzr
	mov	w2, wzr
	b	LBB17_14
LBB17_13:                               ; %b13.i
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
LBB17_14:                               ; %liza___liza_decode.exit
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_console.print_u64         ; -- Begin function liza_console.print_u64
	.p2align	2
_liza_console.print_u64:                ; @liza_console.print_u64
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_print_u64
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB18_5
; %bb.1:                                ; %b0
	cbz	w8, LBB18_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB18_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB18_11
; %bb.4:                                ; %b7.i
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB18_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB18_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB18_11
; %bb.8:                                ; %b16.i
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	b	LBB18_14
LBB18_9:                                ; %b1.i
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_10:                               ; %b10.i
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	b	LBB18_14
LBB18_11:                               ; %b18.i
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	b	LBB18_14
LBB18_12:                               ; %b4.i
	mov	x1, xzr
	mov	w2, wzr
	b	LBB18_14
LBB18_13:                               ; %b13.i
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
LBB18_14:                               ; %liza___liza_decode.exit
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_console.err               ; -- Begin function liza_console.err
	.p2align	2
_liza_console.err:                      ; @liza_console.err
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_err_text
	lsr	x8, x0, #32
	mov	w3, w0
	cmp	w8, #2
	b.gt	LBB19_5
; %bb.1:                                ; %b0
	cbz	w8, LBB19_9
; %bb.2:                                ; %b0
	cmp	w8, #1
	b.eq	LBB19_12
; %bb.3:                                ; %b0
	cmp	w8, #2
	b.ne	LBB19_11
; %bb.4:                                ; %b7.i
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
	mov	w2, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_5:                                ; %b0
	cmp	w8, #3
	b.eq	LBB19_10
; %bb.6:                                ; %b0
	cmp	w8, #4
	b.eq	LBB19_13
; %bb.7:                                ; %b0
	cmp	w8, #5
	b.ne	LBB19_11
; %bb.8:                                ; %b16.i
	mov	x1, xzr
	mov	w2, #4                          ; =0x4
	b	LBB19_14
LBB19_9:                                ; %b1.i
	mov	w0, wzr
	mov	w2, wzr
	mov	x1, x3
	mov	x3, xzr
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_10:                               ; %b10.i
	mov	x1, xzr
	mov	w2, #2                          ; =0x2
	b	LBB19_14
LBB19_11:                               ; %b18.i
	mov	x1, xzr
	mov	w2, #5                          ; =0x5
	b	LBB19_14
LBB19_12:                               ; %b4.i
	mov	x1, xzr
	mov	w2, wzr
	b	LBB19_14
LBB19_13:                               ; %b13.i
	mov	x1, xzr
	mov	w2, #3                          ; =0x3
LBB19_14:                               ; %liza___liza_decode.exit
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_cli.count                 ; -- Begin function liza_cli.count
	.p2align	2
_liza_cli.count:                        ; @liza_cli.count
	.cfi_startproc
; %bb.0:                                ; %b0
	b	_liza_rt_cli_count
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_cli.arg                   ; -- Begin function liza_cli.arg
	.p2align	2
_liza_cli.arg:                          ; @liza_cli.arg
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w19, w0
	bl	_liza_rt_cli_count
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	cmp	w19, w0
	csel	w1, w19, wzr, lo
	cset	w0, hs
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza_cli.equals                ; -- Begin function liza_cli.equals
	.p2align	2
_liza_cli.equals:                       ; @liza_cli.equals
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_cli_equals
	cmp	w0, #0
	cset	w0, ne
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_liza___liza_reactor_error      ; -- Begin function liza___liza_reactor_error
	.p2align	2
_liza___liza_reactor_error:             ; @liza___liza_reactor_error
; %bb.0:                                ; %b0
	sub	w8, w0, #1
	cmp	w8, #11
	b.hi	LBB23_13
; %bb.1:                                ; %b0
Lloh46:
	adrp	x9, lJTI23_0@PAGE
Lloh47:
	add	x9, x9, lJTI23_0@PAGEOFF
	mov	w0, wzr
	adr	x10, LBB23_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB23_2:                                ; %b4
	mov	w0, #1                          ; =0x1
	ret
LBB23_3:                                ; %b34
	mov	w0, #11                         ; =0xb
	ret
LBB23_4:                                ; %b13
	mov	w0, #4                          ; =0x4
	ret
LBB23_5:                                ; %b16
	mov	w0, #5                          ; =0x5
	ret
LBB23_6:                                ; %b10
	mov	w0, #3                          ; =0x3
	ret
LBB23_7:                                ; %b7
	mov	w0, #2                          ; =0x2
	ret
LBB23_8:                                ; %b22
	mov	w0, #7                          ; =0x7
	ret
LBB23_9:                                ; %b25
	mov	w0, #8                          ; =0x8
	ret
LBB23_10:                               ; %b31
	mov	w0, #10                         ; =0xa
LBB23_11:                               ; %common.ret
	ret
LBB23_12:                               ; %b28
	mov	w0, #9                          ; =0x9
	ret
LBB23_13:                               ; %b36
	mov	w0, #6                          ; =0x6
	ret
	.loh AdrpAdd	Lloh46, Lloh47
	.section	__TEXT,__const
lJTI23_0:
	.byte	(LBB23_11-LBB23_2)>>2
	.byte	(LBB23_2-LBB23_2)>>2
	.byte	(LBB23_7-LBB23_2)>>2
	.byte	(LBB23_6-LBB23_2)>>2
	.byte	(LBB23_4-LBB23_2)>>2
	.byte	(LBB23_5-LBB23_2)>>2
	.byte	(LBB23_13-LBB23_2)>>2
	.byte	(LBB23_8-LBB23_2)>>2
	.byte	(LBB23_9-LBB23_2)>>2
	.byte	(LBB23_12-LBB23_2)>>2
	.byte	(LBB23_10-LBB23_2)>>2
	.byte	(LBB23_3-LBB23_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza___liza_reactor_status     ; -- Begin function liza___liza_reactor_status
	.p2align	2
_liza___liza_reactor_status:            ; @liza___liza_reactor_status
; %bb.0:                                ; %b0
	lsr	x8, x0, #32
	cbnz	x8, LBB24_2
; %bb.1:                                ; %b1
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ret
LBB24_2:                                ; %v8_ok
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB24_14
; %bb.3:                                ; %v8_ok
Lloh48:
	adrp	x9, lJTI24_0@PAGE
Lloh49:
	add	x9, x9, lJTI24_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB24_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB24_4:                                ; %b4.i
	mov	w2, #1                          ; =0x1
	b	LBB24_15
LBB24_5:                                ; %b34.i
	mov	w2, #11                         ; =0xb
	b	LBB24_15
LBB24_6:                                ; %b13.i
	mov	w2, #4                          ; =0x4
	b	LBB24_15
LBB24_7:                                ; %b16.i
	mov	w2, #5                          ; =0x5
	b	LBB24_15
LBB24_8:                                ; %b10.i
	mov	w2, #3                          ; =0x3
	b	LBB24_15
LBB24_9:                                ; %b7.i
	mov	w2, #2                          ; =0x2
	b	LBB24_15
LBB24_10:                               ; %b22.i
	mov	w2, #7                          ; =0x7
	b	LBB24_15
LBB24_11:                               ; %b25.i
	mov	w2, #8                          ; =0x8
	b	LBB24_15
LBB24_12:                               ; %b31.i
	mov	w2, #10                         ; =0xa
	b	LBB24_15
LBB24_13:                               ; %b28.i
	mov	w2, #9                          ; =0x9
	b	LBB24_15
LBB24_14:                               ; %b36.i
	mov	w2, #6                          ; =0x6
LBB24_15:                               ; %liza___liza_reactor_error.exit
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ret
	.loh AdrpAdd	Lloh48, Lloh49
	.section	__TEXT,__const
lJTI24_0:
	.byte	(LBB24_15-LBB24_4)>>2
	.byte	(LBB24_4-LBB24_4)>>2
	.byte	(LBB24_9-LBB24_4)>>2
	.byte	(LBB24_8-LBB24_4)>>2
	.byte	(LBB24_6-LBB24_4)>>2
	.byte	(LBB24_7-LBB24_4)>>2
	.byte	(LBB24_14-LBB24_4)>>2
	.byte	(LBB24_10-LBB24_4)>>2
	.byte	(LBB24_11-LBB24_4)>>2
	.byte	(LBB24_13-LBB24_4)>>2
	.byte	(LBB24_12-LBB24_4)>>2
	.byte	(LBB24_5-LBB24_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_create        ; -- Begin function liza_net.reactor_create
	.p2align	2
_liza_net.reactor_create:               ; @liza_net.reactor_create
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x2, sp, #8
	bl	_liza_rt_reactor_create
	cmp	w0, #12
	b.hi	LBB25_13
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh50:
	adrp	x9, lJTI25_0@PAGE
Lloh51:
	add	x9, x9, lJTI25_0@PAGEOFF
	adr	x10, LBB25_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	mov	w2, wzr
	br	x10
LBB25_2:                                ; %b1
	ldr	x1, [sp, #8]
	mov	w0, wzr
	mov	w2, wzr
	b	LBB25_15
LBB25_3:                                ; %b31.i
	mov	w2, #10                         ; =0xa
	b	LBB25_14
LBB25_4:                                ; %b4.i
	mov	w2, #1                          ; =0x1
	b	LBB25_14
LBB25_5:                                ; %b13.i
	mov	w2, #4                          ; =0x4
	b	LBB25_14
LBB25_6:                                ; %b34.i
	mov	w2, #11                         ; =0xb
	b	LBB25_14
LBB25_7:                                ; %b16.i
	mov	w2, #5                          ; =0x5
	b	LBB25_14
LBB25_8:                                ; %b22.i
	mov	w2, #7                          ; =0x7
	b	LBB25_14
LBB25_9:                                ; %b7.i
	mov	w2, #2                          ; =0x2
	b	LBB25_14
LBB25_10:                               ; %b10.i
	mov	w2, #3                          ; =0x3
	b	LBB25_14
LBB25_11:                               ; %b28.i
	mov	w2, #9                          ; =0x9
	b	LBB25_14
LBB25_12:                               ; %b25.i
	mov	w2, #8                          ; =0x8
	b	LBB25_14
LBB25_13:                               ; %b36.i
	mov	w2, #6                          ; =0x6
LBB25_14:                               ; %liza___liza_reactor_error.exit
	mov	x1, xzr
	mov	w0, #1                          ; =0x1
LBB25_15:                               ; %common.ret
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh50, Lloh51
	.cfi_endproc
	.section	__TEXT,__const
lJTI25_0:
	.byte	(LBB25_2-LBB25_2)>>2
	.byte	(LBB25_14-LBB25_2)>>2
	.byte	(LBB25_4-LBB25_2)>>2
	.byte	(LBB25_9-LBB25_2)>>2
	.byte	(LBB25_10-LBB25_2)>>2
	.byte	(LBB25_5-LBB25_2)>>2
	.byte	(LBB25_7-LBB25_2)>>2
	.byte	(LBB25_13-LBB25_2)>>2
	.byte	(LBB25_8-LBB25_2)>>2
	.byte	(LBB25_12-LBB25_2)>>2
	.byte	(LBB25_11-LBB25_2)>>2
	.byte	(LBB25_3-LBB25_2)>>2
	.byte	(LBB25_6-LBB25_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_accept        ; -- Begin function liza_net.reactor_accept
	.p2align	2
_liza_net.reactor_accept:               ; @liza_net.reactor_accept
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x1, sp, #8
	bl	_liza_rt_reactor_accept
	cmp	w0, #12
	b.hi	LBB26_13
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh52:
	adrp	x9, lJTI26_0@PAGE
Lloh53:
	add	x9, x9, lJTI26_0@PAGEOFF
	adr	x10, LBB26_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	mov	w4, wzr
	br	x10
LBB26_2:                                ; %b1
	ldp	x1, x2, [sp, #8]
	mov	w0, wzr
	ldr	x3, [sp, #24]
	mov	w4, wzr
	b	LBB26_15
LBB26_3:                                ; %b31.i
	mov	w4, #10                         ; =0xa
	b	LBB26_14
LBB26_4:                                ; %b4.i
	mov	w4, #1                          ; =0x1
	b	LBB26_14
LBB26_5:                                ; %b13.i
	mov	w4, #4                          ; =0x4
	b	LBB26_14
LBB26_6:                                ; %b34.i
	mov	w4, #11                         ; =0xb
	b	LBB26_14
LBB26_7:                                ; %b16.i
	mov	w4, #5                          ; =0x5
	b	LBB26_14
LBB26_8:                                ; %b22.i
	mov	w4, #7                          ; =0x7
	b	LBB26_14
LBB26_9:                                ; %b7.i
	mov	w4, #2                          ; =0x2
	b	LBB26_14
LBB26_10:                               ; %b10.i
	mov	w4, #3                          ; =0x3
	b	LBB26_14
LBB26_11:                               ; %b28.i
	mov	w4, #9                          ; =0x9
	b	LBB26_14
LBB26_12:                               ; %b25.i
	mov	w4, #8                          ; =0x8
	b	LBB26_14
LBB26_13:                               ; %b36.i
	mov	w4, #6                          ; =0x6
LBB26_14:                               ; %liza___liza_reactor_error.exit
	mov	x1, xzr
	mov	x2, xzr
	mov	x3, xzr
	mov	w0, #1                          ; =0x1
LBB26_15:                               ; %common.ret
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh52, Lloh53
	.cfi_endproc
	.section	__TEXT,__const
lJTI26_0:
	.byte	(LBB26_2-LBB26_2)>>2
	.byte	(LBB26_14-LBB26_2)>>2
	.byte	(LBB26_4-LBB26_2)>>2
	.byte	(LBB26_9-LBB26_2)>>2
	.byte	(LBB26_10-LBB26_2)>>2
	.byte	(LBB26_5-LBB26_2)>>2
	.byte	(LBB26_7-LBB26_2)>>2
	.byte	(LBB26_13-LBB26_2)>>2
	.byte	(LBB26_8-LBB26_2)>>2
	.byte	(LBB26_12-LBB26_2)>>2
	.byte	(LBB26_11-LBB26_2)>>2
	.byte	(LBB26_3-LBB26_2)>>2
	.byte	(LBB26_6-LBB26_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_close         ; -- Begin function liza_net.reactor_close
	.p2align	2
_liza_net.reactor_close:                ; @liza_net.reactor_close
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_close
	cmp	w0, #12
	b.hi	LBB27_12
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh54:
	adrp	x10, lJTI27_0@PAGE
Lloh55:
	add	x10, x10, lJTI27_0@PAGEOFF
	mov	w8, w8
	mov	w0, wzr
	mov	w1, wzr
	adr	x11, LBB27_2
	ldrb	w12, [x10, x8]
	add	x11, x11, x12, lsl #2
	mov	w2, wzr
	mov	w9, wzr
	br	x11
LBB27_2:                                ; %b4.i
	mov	w9, #1                          ; =0x1
	b	LBB27_13
LBB27_3:                                ; %b31.i
	mov	w9, #10                         ; =0xa
	b	LBB27_13
LBB27_4:                                ; %b13.i
	mov	w9, #4                          ; =0x4
	b	LBB27_13
LBB27_5:                                ; %b34.i
	mov	w9, #11                         ; =0xb
	b	LBB27_13
LBB27_6:                                ; %b16.i
	mov	w9, #5                          ; =0x5
	b	LBB27_13
LBB27_7:                                ; %b22.i
	mov	w9, #7                          ; =0x7
	b	LBB27_13
LBB27_8:                                ; %b7.i
	mov	w9, #2                          ; =0x2
	b	LBB27_13
LBB27_9:                                ; %b10.i
	mov	w9, #3                          ; =0x3
	b	LBB27_13
LBB27_10:                               ; %b28.i
	mov	w9, #9                          ; =0x9
	b	LBB27_13
LBB27_11:                               ; %b25.i
	mov	w9, #8                          ; =0x8
	b	LBB27_13
LBB27_12:                               ; %b36.i
	mov	w9, #6                          ; =0x6
LBB27_13:                               ; %liza___liza_reactor_error.exit
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
	mov	w2, w9
LBB27_14:                               ; %common.ret
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh54, Lloh55
	.cfi_endproc
	.section	__TEXT,__const
lJTI27_0:
	.byte	(LBB27_14-LBB27_2)>>2
	.byte	(LBB27_13-LBB27_2)>>2
	.byte	(LBB27_2-LBB27_2)>>2
	.byte	(LBB27_8-LBB27_2)>>2
	.byte	(LBB27_9-LBB27_2)>>2
	.byte	(LBB27_4-LBB27_2)>>2
	.byte	(LBB27_6-LBB27_2)>>2
	.byte	(LBB27_12-LBB27_2)>>2
	.byte	(LBB27_7-LBB27_2)>>2
	.byte	(LBB27_11-LBB27_2)>>2
	.byte	(LBB27_10-LBB27_2)>>2
	.byte	(LBB27_3-LBB27_2)>>2
	.byte	(LBB27_5-LBB27_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_port          ; -- Begin function liza_net.reactor_port
	.p2align	2
_liza_net.reactor_port:                 ; @liza_net.reactor_port
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_port
	lsr	x8, x0, #32
	cbnz	x8, LBB28_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB28_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB28_14
; %bb.3:                                ; %v8_ok.i
Lloh56:
	adrp	x9, lJTI28_0@PAGE
Lloh57:
	add	x9, x9, lJTI28_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB28_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB28_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB28_15
LBB28_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB28_15
LBB28_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB28_15
LBB28_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB28_15
LBB28_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB28_15
LBB28_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB28_15
LBB28_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB28_15
LBB28_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB28_15
LBB28_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB28_15
LBB28_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB28_15
LBB28_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB28_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh56, Lloh57
	.cfi_endproc
	.section	__TEXT,__const
lJTI28_0:
	.byte	(LBB28_15-LBB28_4)>>2
	.byte	(LBB28_4-LBB28_4)>>2
	.byte	(LBB28_9-LBB28_4)>>2
	.byte	(LBB28_8-LBB28_4)>>2
	.byte	(LBB28_6-LBB28_4)>>2
	.byte	(LBB28_7-LBB28_4)>>2
	.byte	(LBB28_14-LBB28_4)>>2
	.byte	(LBB28_10-LBB28_4)>>2
	.byte	(LBB28_11-LBB28_4)>>2
	.byte	(LBB28_13-LBB28_4)>>2
	.byte	(LBB28_12-LBB28_4)>>2
	.byte	(LBB28_5-LBB28_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_poll          ; -- Begin function liza_net.reactor_poll
	.p2align	2
_liza_net.reactor_poll:                 ; @liza_net.reactor_poll
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_poll
	lsr	x8, x0, #32
	cbnz	x8, LBB29_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB29_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB29_14
; %bb.3:                                ; %v8_ok.i
Lloh58:
	adrp	x9, lJTI29_0@PAGE
Lloh59:
	add	x9, x9, lJTI29_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB29_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB29_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB29_15
LBB29_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB29_15
LBB29_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB29_15
LBB29_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB29_15
LBB29_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB29_15
LBB29_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB29_15
LBB29_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB29_15
LBB29_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB29_15
LBB29_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB29_15
LBB29_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB29_15
LBB29_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB29_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh58, Lloh59
	.cfi_endproc
	.section	__TEXT,__const
lJTI29_0:
	.byte	(LBB29_15-LBB29_4)>>2
	.byte	(LBB29_4-LBB29_4)>>2
	.byte	(LBB29_9-LBB29_4)>>2
	.byte	(LBB29_8-LBB29_4)>>2
	.byte	(LBB29_6-LBB29_4)>>2
	.byte	(LBB29_7-LBB29_4)>>2
	.byte	(LBB29_14-LBB29_4)>>2
	.byte	(LBB29_10-LBB29_4)>>2
	.byte	(LBB29_11-LBB29_4)>>2
	.byte	(LBB29_13-LBB29_4)>>2
	.byte	(LBB29_12-LBB29_4)>>2
	.byte	(LBB29_5-LBB29_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_interest      ; -- Begin function liza_net.reactor_interest
	.p2align	2
_liza_net.reactor_interest:             ; @liza_net.reactor_interest
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_interest
	lsr	x8, x0, #32
	cbnz	x8, LBB30_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB30_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB30_14
; %bb.3:                                ; %v8_ok.i
Lloh60:
	adrp	x9, lJTI30_0@PAGE
Lloh61:
	add	x9, x9, lJTI30_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB30_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB30_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB30_15
LBB30_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB30_15
LBB30_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB30_15
LBB30_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB30_15
LBB30_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB30_15
LBB30_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB30_15
LBB30_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB30_15
LBB30_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB30_15
LBB30_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB30_15
LBB30_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB30_15
LBB30_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB30_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh60, Lloh61
	.cfi_endproc
	.section	__TEXT,__const
lJTI30_0:
	.byte	(LBB30_15-LBB30_4)>>2
	.byte	(LBB30_4-LBB30_4)>>2
	.byte	(LBB30_9-LBB30_4)>>2
	.byte	(LBB30_8-LBB30_4)>>2
	.byte	(LBB30_6-LBB30_4)>>2
	.byte	(LBB30_7-LBB30_4)>>2
	.byte	(LBB30_14-LBB30_4)>>2
	.byte	(LBB30_10-LBB30_4)>>2
	.byte	(LBB30_11-LBB30_4)>>2
	.byte	(LBB30_13-LBB30_4)>>2
	.byte	(LBB30_12-LBB30_4)>>2
	.byte	(LBB30_5-LBB30_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_ready         ; -- Begin function liza_net.reactor_ready
	.p2align	2
_liza_net.reactor_ready:                ; @liza_net.reactor_ready
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_ready
	lsr	x8, x0, #32
	cbnz	x8, LBB31_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB31_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB31_14
; %bb.3:                                ; %v8_ok.i
Lloh62:
	adrp	x9, lJTI31_0@PAGE
Lloh63:
	add	x9, x9, lJTI31_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB31_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB31_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB31_15
LBB31_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB31_15
LBB31_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB31_15
LBB31_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB31_15
LBB31_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB31_15
LBB31_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB31_15
LBB31_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB31_15
LBB31_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB31_15
LBB31_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB31_15
LBB31_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB31_15
LBB31_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB31_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh62, Lloh63
	.cfi_endproc
	.section	__TEXT,__const
lJTI31_0:
	.byte	(LBB31_15-LBB31_4)>>2
	.byte	(LBB31_4-LBB31_4)>>2
	.byte	(LBB31_9-LBB31_4)>>2
	.byte	(LBB31_8-LBB31_4)>>2
	.byte	(LBB31_6-LBB31_4)>>2
	.byte	(LBB31_7-LBB31_4)>>2
	.byte	(LBB31_14-LBB31_4)>>2
	.byte	(LBB31_10-LBB31_4)>>2
	.byte	(LBB31_11-LBB31_4)>>2
	.byte	(LBB31_13-LBB31_4)>>2
	.byte	(LBB31_12-LBB31_4)>>2
	.byte	(LBB31_5-LBB31_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_disconnect    ; -- Begin function liza_net.reactor_disconnect
	.p2align	2
_liza_net.reactor_disconnect:           ; @liza_net.reactor_disconnect
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_disconnect
	lsr	x8, x0, #32
	cbnz	x8, LBB32_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB32_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB32_14
; %bb.3:                                ; %v8_ok.i
Lloh64:
	adrp	x9, lJTI32_0@PAGE
Lloh65:
	add	x9, x9, lJTI32_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB32_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB32_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB32_15
LBB32_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB32_15
LBB32_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB32_15
LBB32_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB32_15
LBB32_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB32_15
LBB32_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB32_15
LBB32_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB32_15
LBB32_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB32_15
LBB32_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB32_15
LBB32_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB32_15
LBB32_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB32_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh64, Lloh65
	.cfi_endproc
	.section	__TEXT,__const
lJTI32_0:
	.byte	(LBB32_15-LBB32_4)>>2
	.byte	(LBB32_4-LBB32_4)>>2
	.byte	(LBB32_9-LBB32_4)>>2
	.byte	(LBB32_8-LBB32_4)>>2
	.byte	(LBB32_6-LBB32_4)>>2
	.byte	(LBB32_7-LBB32_4)>>2
	.byte	(LBB32_14-LBB32_4)>>2
	.byte	(LBB32_10-LBB32_4)>>2
	.byte	(LBB32_11-LBB32_4)>>2
	.byte	(LBB32_13-LBB32_4)>>2
	.byte	(LBB32_12-LBB32_4)>>2
	.byte	(LBB32_5-LBB32_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_write         ; -- Begin function liza_net.reactor_write
	.p2align	2
_liza_net.reactor_write:                ; @liza_net.reactor_write
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_write
	lsr	x8, x0, #32
	cbnz	x8, LBB33_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB33_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB33_14
; %bb.3:                                ; %v8_ok.i
Lloh66:
	adrp	x9, lJTI33_0@PAGE
Lloh67:
	add	x9, x9, lJTI33_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB33_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB33_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB33_15
LBB33_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB33_15
LBB33_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB33_15
LBB33_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB33_15
LBB33_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB33_15
LBB33_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB33_15
LBB33_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB33_15
LBB33_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB33_15
LBB33_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB33_15
LBB33_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB33_15
LBB33_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB33_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh66, Lloh67
	.cfi_endproc
	.section	__TEXT,__const
lJTI33_0:
	.byte	(LBB33_15-LBB33_4)>>2
	.byte	(LBB33_4-LBB33_4)>>2
	.byte	(LBB33_9-LBB33_4)>>2
	.byte	(LBB33_8-LBB33_4)>>2
	.byte	(LBB33_6-LBB33_4)>>2
	.byte	(LBB33_7-LBB33_4)>>2
	.byte	(LBB33_14-LBB33_4)>>2
	.byte	(LBB33_10-LBB33_4)>>2
	.byte	(LBB33_11-LBB33_4)>>2
	.byte	(LBB33_13-LBB33_4)>>2
	.byte	(LBB33_12-LBB33_4)>>2
	.byte	(LBB33_5-LBB33_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_connect       ; -- Begin function liza_net.reactor_connect
	.p2align	2
_liza_net.reactor_connect:              ; @liza_net.reactor_connect
	.cfi_startproc
; %bb.0:                                ; %b0
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x2, sp, #8
	bl	_liza_rt_reactor_connect
	cmp	w0, #12
	b.hi	LBB34_13
; %bb.1:                                ; %b0
	mov	w8, w0
Lloh68:
	adrp	x9, lJTI34_0@PAGE
Lloh69:
	add	x9, x9, lJTI34_0@PAGEOFF
	adr	x10, LBB34_2
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	mov	w4, wzr
	br	x10
LBB34_2:                                ; %b1
	ldp	x1, x2, [sp, #8]
	mov	w0, wzr
	ldr	x3, [sp, #24]
	mov	w4, wzr
	b	LBB34_15
LBB34_3:                                ; %b31.i
	mov	w4, #10                         ; =0xa
	b	LBB34_14
LBB34_4:                                ; %b4.i
	mov	w4, #1                          ; =0x1
	b	LBB34_14
LBB34_5:                                ; %b13.i
	mov	w4, #4                          ; =0x4
	b	LBB34_14
LBB34_6:                                ; %b34.i
	mov	w4, #11                         ; =0xb
	b	LBB34_14
LBB34_7:                                ; %b16.i
	mov	w4, #5                          ; =0x5
	b	LBB34_14
LBB34_8:                                ; %b22.i
	mov	w4, #7                          ; =0x7
	b	LBB34_14
LBB34_9:                                ; %b7.i
	mov	w4, #2                          ; =0x2
	b	LBB34_14
LBB34_10:                               ; %b10.i
	mov	w4, #3                          ; =0x3
	b	LBB34_14
LBB34_11:                               ; %b28.i
	mov	w4, #9                          ; =0x9
	b	LBB34_14
LBB34_12:                               ; %b25.i
	mov	w4, #8                          ; =0x8
	b	LBB34_14
LBB34_13:                               ; %b36.i
	mov	w4, #6                          ; =0x6
LBB34_14:                               ; %liza___liza_reactor_error.exit
	mov	x1, xzr
	mov	x2, xzr
	mov	x3, xzr
	mov	w0, #1                          ; =0x1
LBB34_15:                               ; %common.ret
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.loh AdrpAdd	Lloh68, Lloh69
	.cfi_endproc
	.section	__TEXT,__const
lJTI34_0:
	.byte	(LBB34_2-LBB34_2)>>2
	.byte	(LBB34_14-LBB34_2)>>2
	.byte	(LBB34_4-LBB34_2)>>2
	.byte	(LBB34_9-LBB34_2)>>2
	.byte	(LBB34_10-LBB34_2)>>2
	.byte	(LBB34_5-LBB34_2)>>2
	.byte	(LBB34_7-LBB34_2)>>2
	.byte	(LBB34_13-LBB34_2)>>2
	.byte	(LBB34_8-LBB34_2)>>2
	.byte	(LBB34_12-LBB34_2)>>2
	.byte	(LBB34_11-LBB34_2)>>2
	.byte	(LBB34_3-LBB34_2)>>2
	.byte	(LBB34_6-LBB34_2)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_finish_connect ; -- Begin function liza_net.reactor_finish_connect
	.p2align	2
_liza_net.reactor_finish_connect:       ; @liza_net.reactor_finish_connect
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_finish_connect
	lsr	x9, x0, #32
	cbnz	x9, LBB35_2
; %bb.1:                                ; %b1
	mov	x8, x0
	mov	w0, wzr
	mov	w2, wzr
	cmp	x8, #1
	cset	w8, eq
	b	LBB35_16
LBB35_2:                                ; %v10_ok
	sub	w8, w9, #1
	cmp	w8, #11
	b.hi	LBB35_14
; %bb.3:                                ; %v10_ok
Lloh70:
	adrp	x9, lJTI35_0@PAGE
Lloh71:
	add	x9, x9, lJTI35_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB35_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB35_4:                                ; %b4.i
	mov	w2, #1                          ; =0x1
	b	LBB35_15
LBB35_5:                                ; %b34.i
	mov	w2, #11                         ; =0xb
	b	LBB35_15
LBB35_6:                                ; %b13.i
	mov	w2, #4                          ; =0x4
	b	LBB35_15
LBB35_7:                                ; %b16.i
	mov	w2, #5                          ; =0x5
	b	LBB35_15
LBB35_8:                                ; %b10.i
	mov	w2, #3                          ; =0x3
	b	LBB35_15
LBB35_9:                                ; %b7.i
	mov	w2, #2                          ; =0x2
	b	LBB35_15
LBB35_10:                               ; %b22.i
	mov	w2, #7                          ; =0x7
	b	LBB35_15
LBB35_11:                               ; %b25.i
	mov	w2, #8                          ; =0x8
	b	LBB35_15
LBB35_12:                               ; %b31.i
	mov	w2, #10                         ; =0xa
	b	LBB35_15
LBB35_13:                               ; %b28.i
	mov	w2, #9                          ; =0x9
	b	LBB35_15
LBB35_14:                               ; %b36.i
	mov	w2, #6                          ; =0x6
LBB35_15:                               ; %liza___liza_reactor_error.exit
	mov	w8, wzr
	mov	w0, #1                          ; =0x1
LBB35_16:                               ; %common.ret
	and	w1, w8, #0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh70, Lloh71
	.cfi_endproc
	.section	__TEXT,__const
lJTI35_0:
	.byte	(LBB35_15-LBB35_4)>>2
	.byte	(LBB35_4-LBB35_4)>>2
	.byte	(LBB35_9-LBB35_4)>>2
	.byte	(LBB35_8-LBB35_4)>>2
	.byte	(LBB35_6-LBB35_4)>>2
	.byte	(LBB35_7-LBB35_4)>>2
	.byte	(LBB35_14-LBB35_4)>>2
	.byte	(LBB35_10-LBB35_4)>>2
	.byte	(LBB35_11-LBB35_4)>>2
	.byte	(LBB35_13-LBB35_4)>>2
	.byte	(LBB35_12-LBB35_4)>>2
	.byte	(LBB35_5-LBB35_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_liza_net.reactor_shutdown_write ; -- Begin function liza_net.reactor_shutdown_write
	.p2align	2
_liza_net.reactor_shutdown_write:       ; @liza_net.reactor_shutdown_write
	.cfi_startproc
; %bb.0:                                ; %b0
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_reactor_shutdown_write
	lsr	x8, x0, #32
	cbnz	x8, LBB36_2
; %bb.1:                                ; %b1.i
	mov	x1, x0
	mov	w0, wzr
	mov	w2, wzr
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB36_2:                                ; %v8_ok.i
	sub	w8, w8, #1
	cmp	w8, #11
	b.hi	LBB36_14
; %bb.3:                                ; %v8_ok.i
Lloh72:
	adrp	x9, lJTI36_0@PAGE
Lloh73:
	add	x9, x9, lJTI36_0@PAGEOFF
	mov	w2, wzr
	adr	x10, LBB36_4
	ldrb	w11, [x9, x8]
	add	x10, x10, x11, lsl #2
	br	x10
LBB36_4:                                ; %b4.i.i
	mov	w2, #1                          ; =0x1
	b	LBB36_15
LBB36_5:                                ; %b34.i.i
	mov	w2, #11                         ; =0xb
	b	LBB36_15
LBB36_6:                                ; %b13.i.i
	mov	w2, #4                          ; =0x4
	b	LBB36_15
LBB36_7:                                ; %b16.i.i
	mov	w2, #5                          ; =0x5
	b	LBB36_15
LBB36_8:                                ; %b10.i.i
	mov	w2, #3                          ; =0x3
	b	LBB36_15
LBB36_9:                                ; %b7.i.i
	mov	w2, #2                          ; =0x2
	b	LBB36_15
LBB36_10:                               ; %b22.i.i
	mov	w2, #7                          ; =0x7
	b	LBB36_15
LBB36_11:                               ; %b25.i.i
	mov	w2, #8                          ; =0x8
	b	LBB36_15
LBB36_12:                               ; %b31.i.i
	mov	w2, #10                         ; =0xa
	b	LBB36_15
LBB36_13:                               ; %b28.i.i
	mov	w2, #9                          ; =0x9
	b	LBB36_15
LBB36_14:                               ; %b36.i.i
	mov	w2, #6                          ; =0x6
LBB36_15:                               ; %liza___liza_reactor_error.exit.i
	mov	w1, wzr
	mov	w0, #1                          ; =0x1
                                        ; kill: def $w1 killed $w1 killed $x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh72, Lloh73
	.cfi_endproc
	.section	__TEXT,__const
lJTI36_0:
	.byte	(LBB36_15-LBB36_4)>>2
	.byte	(LBB36_4-LBB36_4)>>2
	.byte	(LBB36_9-LBB36_4)>>2
	.byte	(LBB36_8-LBB36_4)>>2
	.byte	(LBB36_6-LBB36_4)>>2
	.byte	(LBB36_7-LBB36_4)>>2
	.byte	(LBB36_14-LBB36_4)>>2
	.byte	(LBB36_10-LBB36_4)>>2
	.byte	(LBB36_11-LBB36_4)>>2
	.byte	(LBB36_13-LBB36_4)>>2
	.byte	(LBB36_12-LBB36_4)>>2
	.byte	(LBB36_5-LBB36_4)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_liza_rt_cli_init
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_liza_main
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
l_text.liza_proxy.exchange.v21:         ; @text.liza_proxy.exchange.v21
	.byte	10

	.p2align	4, 0x0                          ; @text.main.v9
l_text.main.v9:
	.ascii	"Usage: liza-proxy [--once | --ephemeral]\n"

l_text.main.v17:                        ; @text.main.v17
	.ascii	"--once"

l_text.main.v21:                        ; @text.main.v21
	.ascii	"--ephemeral"

	.p2align	4, 0x0                          ; @text.main.v25
l_text.main.v25:
	.ascii	"Usage: liza-proxy [--once | --ephemeral]\n"

l_text.main.v28:                        ; @text.main.v28
	.ascii	"--once"

	.p2align	4, 0x0                          ; @text.main.v37
l_text.main.v37:
	.ascii	"Cannot create loopback reactor\n"

.subsections_via_symbols
