; ModuleID = '/private/tmp/liza-m0-measured/M0/module.ll'
source_filename = "/private/tmp/liza-m0-measured/M0/module.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

%variant.5 = type { i32, i64, %struct.JsonError }
%struct.JsonError = type { %variant.1, i64 }
%variant.1 = type { i32, [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8], [0 x i8] }
%struct.JsonState = type { %struct.Utf8StreamState, i64, [64 x i8], i32, i1, i32, i1, i32, i32, i32, i32, i64, i64, i32, i64 }
%struct.Utf8StreamState = type { i64, i64, i64, i32, i8, i8, i32, i64 }
%struct.Utf8StreamError = type { %variant.0, i64 }
%variant.0 = type { i32, [0 x i8], [0 x i8] }
%variant.3 = type { i32, %struct.Utf8StreamError, [0 x i8] }
%variant.2 = type { i32, i64, %struct.Utf8StreamError }
%variant.4 = type { i32, %struct.JsonError, [0 x i8] }

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i32 0, 9) i32 @liza_status(ptr readonly captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v0 = tail call %variant.5 @liza_json.finish(ptr %p0)
  %v1 = extractvalue %variant.5 %v0, 0
  %switch = icmp eq i32 %v1, 0
  %v4 = extractvalue %variant.5 %v0, 2
  %v5 = extractvalue %struct.JsonError %v4, 0
  %v6 = extractvalue %variant.1 %v5, 0
  %switch.offset = add nsw i32 %v6, 1
  %common.ret.op = select i1 %switch, i32 0, i32 %switch.offset
  ret i32 %common.ret.op
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @liza_value(ptr readonly captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v0 = tail call %variant.5 @liza_json.finish(ptr %p0)
  %v1 = extractvalue %variant.5 %v0, 0
  %switch = icmp eq i32 %v1, 0
  %v2 = extractvalue %variant.5 %v0, 1
  %v3 = extractvalue %variant.5 %v0, 2
  %v4 = extractvalue %struct.JsonError %v3, 1
  %common.ret.op = select i1 %switch, i64 %v2, i64 %v4
  ret i64 %common.ret.op
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define range(i32 0, 2) i32 @liza_pending(ptr readonly captures(none) %p0) local_unnamed_addr #3 {
b0:
  %v0_ptr.i = getelementptr i8, ptr %p0, i64 168
  %v0.i = load i32, ptr %v0_ptr.i, align 4
  %v2.i.not = icmp ne i32 %v0.i, 0
  %spec.select = zext i1 %v2.i.not to i32
  ret i32 %spec.select
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define void @liza_start(ptr writeonly sret(%struct.JsonState) captures(none) initializes((0, 30), (32, 125), (128, 172), (176, 184)) %return_storage) local_unnamed_addr #4 {
b0:
  %v16_mem.sroa.75.sroa.0.i = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0.i = alloca i8, align 4
  %v0_mem.sroa.5 = alloca [88 x i8], align 4
  %v0_mem.sroa.9 = alloca [39 x i8], align 1
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  store i1 false, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  store i1 false, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %v0_mem.sroa.5.4.sroa_idx = getelementptr inbounds nuw i8, ptr %v0_mem.sroa.5, i64 4
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(84) %v0_mem.sroa.5.4.sroa_idx, i8 0, i64 84, i1 false)
  %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i = load i8, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i = load i8, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %v0_mem.sroa.9.3.sroa_idx = getelementptr inbounds nuw i8, ptr %v0_mem.sroa.9, i64 3
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 1 dereferenceable(36) %v0_mem.sroa.9.3.sroa_idx, i8 0, i64 36, i1 false)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %return_storage, i8 0, i64 28, i1 false)
  %v0_mem.sroa.2.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 28
  store i8 -128, ptr %v0_mem.sroa.2.0.return_storage.sroa_idx, align 4
  %v0_mem.sroa.3.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 29
  store i8 -65, ptr %v0_mem.sroa.3.0.return_storage.sroa_idx, align 1
  %v0_mem.sroa.41.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 32
  store i32 0, ptr %v0_mem.sroa.41.0.return_storage.sroa_idx, align 8
  %v0_mem.sroa.5.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 36
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 4 dereferenceable(88) %v0_mem.sroa.5.0.return_storage.sroa_idx, ptr noundef nonnull align 4 dereferenceable(88) %v0_mem.sroa.5, i64 88, i1 false)
  %v0_mem.sroa.6.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  store i8 %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i, ptr %v0_mem.sroa.6.0.return_storage.sroa_idx, align 4
  %v0_mem.sroa.72.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 128
  store i32 0, ptr %v0_mem.sroa.72.0.return_storage.sroa_idx, align 8
  %v0_mem.sroa.8.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 132
  store i8 %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i, ptr %v0_mem.sroa.8.0.return_storage.sroa_idx, align 4
  %v0_mem.sroa.9.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 133
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(39) %v0_mem.sroa.9.0.return_storage.sroa_idx, ptr noundef nonnull align 1 dereferenceable(39) %v0_mem.sroa.9, i64 39, i1 false)
  %v0_mem.sroa.103.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 176
  store i64 0, ptr %v0_mem.sroa.103.0.return_storage.sroa_idx, align 8
  ret void
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write)
define i32 @liza_feed(ptr %p0, { ptr, i32 } %p1) local_unnamed_addr #5 {
b0:
  %v0.i = getelementptr i8, ptr %p0, i64 168
  %v1.i = load i32, ptr %v0.i, align 4
  %v3.not.i = icmp eq i32 %v1.i, 0
  br i1 %v3.not.i, label %b4.preheader.i, label %liza_json.feed_mut.exit

b4.preheader.i:                                   ; preds = %b0
  %v8.i = extractvalue { ptr, i32 } %p1, 1
  %v99.not.i = icmp eq i32 %v8.i, 0
  br i1 %v99.not.i, label %liza_json.feed_mut.exit, label %v10_ok.lr.ph.i

v10_ok.lr.ph.i:                                   ; preds = %b4.preheader.i
  %v10_base.i = extractvalue { ptr, i32 } %p1, 0
  %v42.i = getelementptr i8, ptr %p0, i64 48
  %wide.trip.count.i = zext i32 %v8.i to i64
  br label %v10_ok.i

v10_ok.i:                                         ; preds = %v46_ok.i, %v10_ok.lr.ph.i
  %indvars.iv.i = phi i64 [ 0, %v10_ok.lr.ph.i ], [ %indvars.iv.next.i, %v46_ok.i ]
  %v10_ptr.i = getelementptr i8, ptr %v10_base.i, i64 %indvars.iv.i
  %v10.i = load i8, ptr %v10_ptr.i, align 1
  %v13.i = load %struct.Utf8StreamState, ptr %p0, align 8
  %v14.i = tail call %struct.Utf8StreamState @liza_utf8_stream.feed_byte(%struct.Utf8StreamState %v13.i, i8 %v10.i)
  store %struct.Utf8StreamState %v14.i, ptr %p0, align 8
  %v0.i.i = extractvalue %struct.Utf8StreamState %v14.i, 6
  switch i32 %v0.i.i, label %liza_utf8_stream.status.exit.i [
    i32 1, label %b1.i.i
    i32 2, label %b4.i.i
  ]

b1.i.i:                                           ; preds = %v10_ok.i
  %v4.i.i = extractvalue %struct.Utf8StreamState %v14.i, 7
  %v5.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i.i, 1
  %v6.i.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5.i.i, 1
  br label %liza_utf8_stream.status.exit.i

b4.i.i:                                           ; preds = %v10_ok.i
  %v11.i.i = extractvalue %struct.Utf8StreamState %v14.i, 7
  %v12.i.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i.i, 1
  %v13.i.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12.i.i, 1
  br label %liza_utf8_stream.status.exit.i

liza_utf8_stream.status.exit.i:                   ; preds = %b4.i.i, %b1.i.i, %v10_ok.i
  %common.ret.op.i.i = phi %variant.3 [ %v6.i.i, %b1.i.i ], [ %v13.i.i, %b4.i.i ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %v10_ok.i ]
  %v19.i = extractvalue %variant.3 %common.ret.op.i.i, 0
  %switch.i = icmp eq i32 %v19.i, 1
  br i1 %switch.i, label %b13.i, label %b9.i

b9.i:                                             ; preds = %liza_utf8_stream.status.exit.i
  %v20.i = extractvalue %variant.3 %common.ret.op.i.i, 1
  %v21.i = extractvalue %struct.Utf8StreamError %v20.i, 0
  %v22.i = extractvalue %variant.0 %v21.i, 0
  %switch1.i = icmp eq i32 %v22.i, 0
  %..i = select i1 %switch1.i, i32 5, i32 8
  %v29.i = extractvalue %struct.Utf8StreamError %v20.i, 1
  store i32 %..i, ptr %v0.i, align 4
  %v2.i4.i = getelementptr i8, ptr %p0, i64 176
  store i64 %v29.i, ptr %v2.i4.i, align 8
  br label %liza_json.feed_mut.exit

b13.i:                                            ; preds = %liza_utf8_stream.status.exit.i
  %v34.i = tail call i32 @liza___liza_json_mut_step(i8 %v10.i, ptr nonnull %p0)
  %v37.i = load i32, ptr %v0.i, align 4
  %v39.not.i = icmp eq i32 %v37.i, 0
  br i1 %v39.not.i, label %b16.i, label %liza_json.feed_mut.exit

b16.i:                                            ; preds = %b13.i
  %v44.i = load i64, ptr %v42.i, align 8
  %v46_pair.i = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v44.i, i64 1)
  %v46_overflow.i = extractvalue { i64, i1 } %v46_pair.i, 1
  br i1 %v46_overflow.i, label %v46_trap.i, label %v46_ok.i

v46_trap.i:                                       ; preds = %b16.i
  tail call void @llvm.trap()
  unreachable

v46_ok.i:                                         ; preds = %b16.i
  %v46.i = extractvalue { i64, i1 } %v46_pair.i, 0
  store i64 %v46.i, ptr %v42.i, align 8
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1
  %exitcond.not.i = icmp eq i64 %indvars.iv.next.i, %wide.trip.count.i
  br i1 %exitcond.not.i, label %liza_json.feed_mut.exit, label %v10_ok.i

liza_json.feed_mut.exit:                          ; preds = %b13.i, %v46_ok.i, %b0, %b4.preheader.i, %b9.i
  %common.ret.op.i = phi i32 [ %v1.i, %b0 ], [ 0, %b4.preheader.i ], [ %..i, %b9.i ], [ %v37.i, %b13.i ], [ 0, %v46_ok.i ]
  ret i32 %common.ret.op.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @liza_main() local_unnamed_addr #6 {
b0:
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %struct.Utf8StreamState @liza_utf8_stream.create() local_unnamed_addr #6 {
b0:
  ret %struct.Utf8StreamState { i64 0, i64 0, i64 0, i32 0, i8 -128, i8 -65, i32 0, i64 0 }
}

; Function Attrs: nounwind memory(inaccessiblemem: write)
define %struct.Utf8StreamState @liza_utf8_stream.feed_byte(%struct.Utf8StreamState %p0, i8 %p1) local_unnamed_addr #7 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  %v2.not = icmp eq i32 %v0, 0
  br i1 %v2.not, label %b3, label %common.ret

common.ret:                                       ; preds = %b0, %v145_ok, %b53, %b48, %b34, %b11, %b4
  %common.ret.op = phi %struct.Utf8StreamState [ %v11, %b4 ], [ %v28, %b11 ], [ %v96, %b34 ], [ %v111, %b48 ], [ %v134, %b53 ], [ %v146, %v145_ok ], [ %p0, %b0 ]
  ret %struct.Utf8StreamState %common.ret.op

b3:                                               ; preds = %b0
  %v3 = extractvalue %struct.Utf8StreamState %p0, 0
  %v5 = icmp eq i64 %v3, -1
  br i1 %v5, label %b4, label %b6

b4:                                               ; preds = %b3
  %v8 = insertvalue %struct.Utf8StreamState %p0, i32 2, 6
  %v11 = insertvalue %struct.Utf8StreamState %v8, i64 -1, 7
  br label %common.ret

b6:                                               ; preds = %b3
  %v12 = extractvalue %struct.Utf8StreamState %p0, 3
  %v14 = icmp eq i32 %v12, 0
  br i1 %v14, label %b7, label %b8

b7:                                               ; preds = %b6
  %v17 = insertvalue %struct.Utf8StreamState %p0, i64 %v3, 2
  %v19 = icmp sgt i8 %p1, -1
  br i1 %v19, label %b9, label %b10

b8:                                               ; preds = %b6
  %v100 = extractvalue %struct.Utf8StreamState %p0, 4
  %v101 = icmp ult i8 %p1, %v100
  %v103 = extractvalue %struct.Utf8StreamState %p0, 5
  %v104 = icmp ugt i8 %p1, %v103
  %v105 = select i1 %v101, i1 true, i1 %v104
  br i1 %v105, label %b48, label %v115_ok

b9:                                               ; preds = %b7
  %v20 = extractvalue %struct.Utf8StreamState %p0, 1
  %v22 = icmp eq i64 %v20, -1
  br i1 %v22, label %b11, label %v32_ok

b10:                                              ; preds = %b7
  %v36 = insertvalue %struct.Utf8StreamState %v17, i8 -128, 4
  %v39 = insertvalue %struct.Utf8StreamState %v36, i8 -65, 5
  %0 = add nsw i8 %p1, 62
  %v45 = icmp ult i8 %0, 30
  br i1 %v45, label %b17, label %b18

b11:                                              ; preds = %b9
  %v25 = insertvalue %struct.Utf8StreamState %v17, i32 2, 6
  %v28 = insertvalue %struct.Utf8StreamState %v25, i64 %v3, 7
  br label %common.ret

v32_ok:                                           ; preds = %b9
  %v32 = add nuw i64 %v20, 1
  %v33 = insertvalue %struct.Utf8StreamState %v17, i64 %v32, 1
  br label %b57

b17:                                              ; preds = %b10
  %v48 = insertvalue %struct.Utf8StreamState %v39, i32 1, 3
  br label %b57

b18:                                              ; preds = %b10
  %1 = and i8 %p1, -16
  %v54 = icmp eq i8 %1, -32
  br i1 %v54, label %b22, label %b23

b22:                                              ; preds = %b18
  %v57 = insertvalue %struct.Utf8StreamState %v39, i32 2, 3
  %v59 = icmp eq i8 %p1, -32
  %v62 = insertvalue %struct.Utf8StreamState %v57, i8 -96, 4
  %spec.select = select i1 %v59, %struct.Utf8StreamState %v62, %struct.Utf8StreamState %v57
  %v65 = icmp eq i8 %p1, -19
  %v68 = insertvalue %struct.Utf8StreamState %spec.select, i8 -97, 5
  %spec.select2 = select i1 %v65, %struct.Utf8StreamState %v68, %struct.Utf8StreamState %spec.select
  br label %b57

b23:                                              ; preds = %b18
  %2 = add nsw i8 %p1, 16
  %v75 = icmp ult i8 %2, 5
  br i1 %v75, label %b33, label %b34

b33:                                              ; preds = %b23
  %v78 = insertvalue %struct.Utf8StreamState %v39, i32 3, 3
  %v80 = icmp eq i8 %p1, -16
  %v83 = insertvalue %struct.Utf8StreamState %v78, i8 -112, 4
  %spec.select1 = select i1 %v80, %struct.Utf8StreamState %v83, %struct.Utf8StreamState %v78
  %v86 = icmp eq i8 %p1, -12
  %v89 = insertvalue %struct.Utf8StreamState %spec.select1, i8 -113, 5
  %spec.select3 = select i1 %v86, %struct.Utf8StreamState %v89, %struct.Utf8StreamState %spec.select1
  br label %b57

b34:                                              ; preds = %b23
  %v93 = insertvalue %struct.Utf8StreamState %v39, i32 1, 6
  %v96 = insertvalue %struct.Utf8StreamState %v93, i64 %v3, 7
  br label %common.ret

b48:                                              ; preds = %b8
  %v108 = insertvalue %struct.Utf8StreamState %p0, i32 1, 6
  %v110 = extractvalue %struct.Utf8StreamState %p0, 2
  %v111 = insertvalue %struct.Utf8StreamState %v108, i64 %v110, 7
  br label %common.ret

v115_ok:                                          ; preds = %b8
  %v115 = add i32 %v12, -1
  %v116 = insertvalue %struct.Utf8StreamState %p0, i32 %v115, 3
  %v119 = insertvalue %struct.Utf8StreamState %v116, i8 -128, 4
  %v122 = insertvalue %struct.Utf8StreamState %v119, i8 -65, 5
  %v125 = icmp eq i32 %v115, 0
  br i1 %v125, label %b51, label %b57

b51:                                              ; preds = %v115_ok
  %v126 = extractvalue %struct.Utf8StreamState %p0, 1
  %v128 = icmp eq i64 %v126, -1
  br i1 %v128, label %b53, label %v138_ok

b53:                                              ; preds = %b51
  %v131 = insertvalue %struct.Utf8StreamState %v122, i32 2, 6
  %v134 = insertvalue %struct.Utf8StreamState %v131, i64 %v3, 7
  br label %common.ret

v138_ok:                                          ; preds = %b51
  %v138 = add nuw i64 %v126, 1
  %v139 = insertvalue %struct.Utf8StreamState %v122, i64 %v138, 1
  br label %b57

b57:                                              ; preds = %b33, %b22, %v138_ok, %v115_ok, %v32_ok, %b17
  %v141 = phi %struct.Utf8StreamState [ %v33, %v32_ok ], [ %v48, %b17 ], [ %v139, %v138_ok ], [ %v122, %v115_ok ], [ %spec.select2, %b22 ], [ %spec.select3, %b33 ]
  %v143 = extractvalue %struct.Utf8StreamState %v141, 0
  %v145_pair = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v143, i64 1)
  %v145_overflow = extractvalue { i64, i1 } %v145_pair, 1
  br i1 %v145_overflow, label %v145_trap, label %v145_ok

v145_trap:                                        ; preds = %b57
  tail call void @llvm.trap()
  unreachable

v145_ok:                                          ; preds = %b57
  %v145 = extractvalue { i64, i1 } %v145_pair, 0
  %v146 = insertvalue %struct.Utf8StreamState %v141, i64 %v145, 0
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.2 @liza_utf8_stream.finish(%struct.Utf8StreamState %p0) local_unnamed_addr #6 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  switch i32 %v0, label %b6 [
    i32 1, label %b1
    i32 2, label %b4
  ]

common.ret:                                       ; preds = %b9, %b7, %b4, %b1
  %common.ret.op = phi %variant.2 [ %v6, %b1 ], [ %v13, %b4 ], [ %v20, %b7 ], [ %v22, %b9 ]
  ret %variant.2 %common.ret.op

b1:                                               ; preds = %b0
  %v4 = extractvalue %struct.Utf8StreamState %p0, 7
  %v5 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4, 1
  %v6 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5, 2
  br label %common.ret

b4:                                               ; preds = %b0
  %v11 = extractvalue %struct.Utf8StreamState %p0, 7
  %v12 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11, 1
  %v13 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12, 2
  br label %common.ret

b6:                                               ; preds = %b0
  %v14 = extractvalue %struct.Utf8StreamState %p0, 3
  %v16.not = icmp eq i32 %v14, 0
  br i1 %v16.not, label %b9, label %b7

b7:                                               ; preds = %b6
  %v18 = extractvalue %struct.Utf8StreamState %p0, 2
  %v19 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18, 1
  %v20 = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19, 2
  br label %common.ret

b9:                                               ; preds = %b6
  %v21 = extractvalue %struct.Utf8StreamState %p0, 1
  %v22 = insertvalue %variant.2 zeroinitializer, i64 %v21, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define %variant.3 @liza_utf8_stream.status(%struct.Utf8StreamState %p0) local_unnamed_addr #6 {
b0:
  %v0 = extractvalue %struct.Utf8StreamState %p0, 6
  switch i32 %v0, label %common.ret [
    i32 1, label %b1
    i32 2, label %b4
  ]

common.ret:                                       ; preds = %b0, %b4, %b1
  %common.ret.op = phi %variant.3 [ %v6, %b1 ], [ %v13, %b4 ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  ret %variant.3 %common.ret.op

b1:                                               ; preds = %b0
  %v4 = extractvalue %struct.Utf8StreamState %p0, 7
  %v5 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4, 1
  %v6 = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5, 1
  br label %common.ret

b4:                                               ; preds = %b0
  %v11 = extractvalue %struct.Utf8StreamState %p0, 7
  %v12 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11, 1
  %v13 = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12, 1
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @liza_json.create(ptr writeonly sret(%struct.JsonState) captures(none) initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %return_storage) local_unnamed_addr #8 {
b0:
  %v16_mem.sroa.75.sroa.0 = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0 = alloca i8, align 4
  store i1 false, ptr %v16_mem.sroa.75.sroa.0, align 4
  store i1 false, ptr %v16_mem.sroa.77.sroa.0, align 4
  %v16_mem.sroa.5.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 28
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %return_storage, i8 0, i64 28, i1 false)
  store i8 -128, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.6.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 29
  store i8 -65, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx, align 1
  %v16_mem.sroa.71.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 32
  store i32 0, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx, align 8
  %v16_mem.sroa.82.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 40
  %v16_mem.sroa.75.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %v16_mem.sroa.82.0.return_storage.sroa_idx, i8 0, i64 84, i1 false)
  %v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0. = load i8, ptr %v16_mem.sroa.75.sroa.0, align 4
  store i8 %v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0., ptr %v16_mem.sroa.75.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.764.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 128
  store i32 0, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx, align 8
  %v16_mem.sroa.77.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 132
  %v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0. = load i8, ptr %v16_mem.sroa.77.sroa.0, align 4
  store i8 %v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0., ptr %v16_mem.sroa.77.0.return_storage.sroa_idx, align 4
  %v16_mem.sroa.785.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 136
  %v16_mem.sroa.857.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 176
  store i64 0, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %v16_mem.sroa.785.0.return_storage.sroa_idx, i8 0, i64 36, i1 false)
  ret void
}

; Function Attrs: nounwind memory(readwrite, inaccessiblemem: write)
define void @liza___liza_json_done(ptr writeonly sret(%struct.JsonState) captures(none) %return_storage, ptr readonly %p0) local_unnamed_addr #9 {
b0:
  %v5_mem.sroa.67.sroa.0 = alloca i8, align 4
  %v22_scratch = alloca [64 x i8], align 1
  %v27_scratch = alloca [64 x i8], align 1
  %v29_mem.sroa.0 = alloca { %struct.Utf8StreamState, i64 }, align 8
  %v29_mem.sroa.131.sroa.4 = alloca [59 x i8], align 1
  %v30_mem.sroa.0 = alloca { %struct.Utf8StreamState, i64 }, align 8
  %v30_mem.sroa.131.sroa.5 = alloca [59 x i8], align 1
  %v14_storage = alloca [64 x i8], align 1
  %v9_storage = alloca [64 x i8], align 1
  %v0_ptr = getelementptr i8, ptr %p0, i64 120
  %v0 = load i32, ptr %v0_ptr, align 4
  %v2 = icmp eq i32 %v0, 0
  br i1 %v2, label %b1, label %b2

b1:                                               ; preds = %b0
  %v5_mem.sroa.2.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 56
  %0 = load <16 x i8>, ptr %v5_mem.sroa.2.0.p0.sroa_idx, align 1
  %v5_mem.sroa.18.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 72
  %1 = load <16 x i8>, ptr %v5_mem.sroa.18.0.p0.sroa_idx, align 1
  %v5_mem.sroa.34.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 88
  %2 = load <16 x i8>, ptr %v5_mem.sroa.34.0.p0.sroa_idx, align 1
  %v5_mem.sroa.50.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 104
  %3 = load <16 x i8>, ptr %v5_mem.sroa.50.0.p0.sroa_idx, align 1
  %v5_mem.sroa.68.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 125
  store i1 true, ptr %v5_mem.sroa.67.sroa.0, align 4
  %v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0. = load i8, ptr %v5_mem.sroa.67.sroa.0, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v8_pair = add i32 %v0, -1
  %v9_ptr = getelementptr i8, ptr %p0, i64 56
  %v9.unpack = load i8, ptr %v9_ptr, align 1
  %v9.elt257 = getelementptr i8, ptr %p0, i64 57
  %v9.unpack258 = load i8, ptr %v9.elt257, align 1
  %v9.elt259 = getelementptr i8, ptr %p0, i64 58
  %v9.unpack260 = load i8, ptr %v9.elt259, align 1
  %v9.elt261 = getelementptr i8, ptr %p0, i64 59
  %v9.unpack262 = load i8, ptr %v9.elt261, align 1
  %v9.elt263 = getelementptr i8, ptr %p0, i64 60
  %v9.unpack264 = load i8, ptr %v9.elt263, align 1
  %v9.elt265 = getelementptr i8, ptr %p0, i64 61
  %v9.unpack266 = load i8, ptr %v9.elt265, align 1
  %v9.elt267 = getelementptr i8, ptr %p0, i64 62
  %v9.unpack268 = load i8, ptr %v9.elt267, align 1
  %v9.elt269 = getelementptr i8, ptr %p0, i64 63
  %v9.unpack270 = load i8, ptr %v9.elt269, align 1
  %v9.elt271 = getelementptr i8, ptr %p0, i64 64
  %v9.unpack272 = load i8, ptr %v9.elt271, align 1
  %v9.elt273 = getelementptr i8, ptr %p0, i64 65
  %v9.unpack274 = load i8, ptr %v9.elt273, align 1
  %v9.elt275 = getelementptr i8, ptr %p0, i64 66
  %v9.unpack276 = load i8, ptr %v9.elt275, align 1
  %v9.elt277 = getelementptr i8, ptr %p0, i64 67
  %v9.unpack278 = load i8, ptr %v9.elt277, align 1
  %v9.elt279 = getelementptr i8, ptr %p0, i64 68
  %v9.unpack280 = load i8, ptr %v9.elt279, align 1
  %v9.elt281 = getelementptr i8, ptr %p0, i64 69
  %v9.unpack282 = load i8, ptr %v9.elt281, align 1
  %v9.elt283 = getelementptr i8, ptr %p0, i64 70
  %v9.unpack284 = load i8, ptr %v9.elt283, align 1
  %v9.elt285 = getelementptr i8, ptr %p0, i64 71
  %v9.unpack286 = load i8, ptr %v9.elt285, align 1
  %v9.elt287 = getelementptr i8, ptr %p0, i64 72
  %v9.unpack288 = load i8, ptr %v9.elt287, align 1
  %v9.elt289 = getelementptr i8, ptr %p0, i64 73
  %v9.unpack290 = load i8, ptr %v9.elt289, align 1
  %v9.elt291 = getelementptr i8, ptr %p0, i64 74
  %v9.unpack292 = load i8, ptr %v9.elt291, align 1
  %v9.elt293 = getelementptr i8, ptr %p0, i64 75
  %v9.unpack294 = load i8, ptr %v9.elt293, align 1
  %v9.elt295 = getelementptr i8, ptr %p0, i64 76
  %v9.unpack296 = load i8, ptr %v9.elt295, align 1
  %v9.elt297 = getelementptr i8, ptr %p0, i64 77
  %v9.unpack298 = load i8, ptr %v9.elt297, align 1
  %v9.elt299 = getelementptr i8, ptr %p0, i64 78
  %v9.unpack300 = load i8, ptr %v9.elt299, align 1
  %v9.elt301 = getelementptr i8, ptr %p0, i64 79
  %v9.unpack302 = load i8, ptr %v9.elt301, align 1
  %v9.elt303 = getelementptr i8, ptr %p0, i64 80
  %v9.unpack304 = load i8, ptr %v9.elt303, align 1
  %v9.elt305 = getelementptr i8, ptr %p0, i64 81
  %v9.unpack306 = load i8, ptr %v9.elt305, align 1
  %v9.elt307 = getelementptr i8, ptr %p0, i64 82
  %v9.unpack308 = load i8, ptr %v9.elt307, align 1
  %v9.elt309 = getelementptr i8, ptr %p0, i64 83
  %v9.unpack310 = load i8, ptr %v9.elt309, align 1
  %v9.elt311 = getelementptr i8, ptr %p0, i64 84
  %v9.unpack312 = load i8, ptr %v9.elt311, align 1
  %v9.elt313 = getelementptr i8, ptr %p0, i64 85
  %v9.unpack314 = load i8, ptr %v9.elt313, align 1
  %v9.elt315 = getelementptr i8, ptr %p0, i64 86
  %v9.unpack316 = load i8, ptr %v9.elt315, align 1
  %v9.elt317 = getelementptr i8, ptr %p0, i64 87
  %v9.unpack318 = load i8, ptr %v9.elt317, align 1
  %v9.elt319 = getelementptr i8, ptr %p0, i64 88
  %v9.unpack320 = load i8, ptr %v9.elt319, align 1
  %v9.elt321 = getelementptr i8, ptr %p0, i64 89
  %v9.unpack322 = load i8, ptr %v9.elt321, align 1
  %v9.elt323 = getelementptr i8, ptr %p0, i64 90
  %v9.unpack324 = load i8, ptr %v9.elt323, align 1
  %v9.elt325 = getelementptr i8, ptr %p0, i64 91
  %v9.unpack326 = load i8, ptr %v9.elt325, align 1
  %v9.elt327 = getelementptr i8, ptr %p0, i64 92
  %v9.unpack328 = load i8, ptr %v9.elt327, align 1
  %v9.elt329 = getelementptr i8, ptr %p0, i64 93
  %v9.unpack330 = load i8, ptr %v9.elt329, align 1
  %v9.elt331 = getelementptr i8, ptr %p0, i64 94
  %v9.unpack332 = load i8, ptr %v9.elt331, align 1
  %v9.elt333 = getelementptr i8, ptr %p0, i64 95
  %v9.unpack334 = load i8, ptr %v9.elt333, align 1
  %v9.elt335 = getelementptr i8, ptr %p0, i64 96
  %v9.unpack336 = load i8, ptr %v9.elt335, align 1
  %v9.elt337 = getelementptr i8, ptr %p0, i64 97
  %v9.unpack338 = load i8, ptr %v9.elt337, align 1
  %v9.elt339 = getelementptr i8, ptr %p0, i64 98
  %v9.unpack340 = load i8, ptr %v9.elt339, align 1
  %v9.elt341 = getelementptr i8, ptr %p0, i64 99
  %v9.unpack342 = load i8, ptr %v9.elt341, align 1
  %v9.elt343 = getelementptr i8, ptr %p0, i64 100
  %v9.unpack344 = load i8, ptr %v9.elt343, align 1
  %v9.elt345 = getelementptr i8, ptr %p0, i64 101
  %v9.unpack346 = load i8, ptr %v9.elt345, align 1
  %v9.elt347 = getelementptr i8, ptr %p0, i64 102
  %v9.unpack348 = load i8, ptr %v9.elt347, align 1
  %v9.elt349 = getelementptr i8, ptr %p0, i64 103
  %v9.unpack350 = load i8, ptr %v9.elt349, align 1
  %v9.elt351 = getelementptr i8, ptr %p0, i64 104
  %v9.unpack352 = load i8, ptr %v9.elt351, align 1
  %v9.elt353 = getelementptr i8, ptr %p0, i64 105
  %v9.unpack354 = load i8, ptr %v9.elt353, align 1
  %v9.elt355 = getelementptr i8, ptr %p0, i64 106
  %v9.unpack356 = load i8, ptr %v9.elt355, align 1
  %v9.elt357 = getelementptr i8, ptr %p0, i64 107
  %v9.unpack358 = load i8, ptr %v9.elt357, align 1
  %v9.elt359 = getelementptr i8, ptr %p0, i64 108
  %v9.unpack360 = load i8, ptr %v9.elt359, align 1
  %v9.elt361 = getelementptr i8, ptr %p0, i64 109
  %v9.unpack362 = load i8, ptr %v9.elt361, align 1
  %v9.elt363 = getelementptr i8, ptr %p0, i64 110
  %v9.unpack364 = load i8, ptr %v9.elt363, align 1
  %v9.elt365 = getelementptr i8, ptr %p0, i64 111
  %v9.unpack366 = load i8, ptr %v9.elt365, align 1
  %v9.elt367 = getelementptr i8, ptr %p0, i64 112
  %v9.unpack368 = load i8, ptr %v9.elt367, align 1
  %v9.elt369 = getelementptr i8, ptr %p0, i64 113
  %v9.unpack370 = load i8, ptr %v9.elt369, align 1
  %v9.elt371 = getelementptr i8, ptr %p0, i64 114
  %v9.unpack372 = load i8, ptr %v9.elt371, align 1
  %v9.elt373 = getelementptr i8, ptr %p0, i64 115
  %v9.unpack374 = load i8, ptr %v9.elt373, align 1
  %v9.elt375 = getelementptr i8, ptr %p0, i64 116
  %v9.unpack376 = load i8, ptr %v9.elt375, align 1
  %v9.elt377 = getelementptr i8, ptr %p0, i64 117
  %v9.unpack378 = load i8, ptr %v9.elt377, align 1
  %v9.elt379 = getelementptr i8, ptr %p0, i64 118
  %v9.unpack380 = load i8, ptr %v9.elt379, align 1
  %v9.elt381 = getelementptr i8, ptr %p0, i64 119
  %v9.unpack382 = load i8, ptr %v9.elt381, align 1
  store i8 %v9.unpack, ptr %v9_storage, align 1
  %v9.fca.1.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 1
  store i8 %v9.unpack258, ptr %v9.fca.1.gep, align 1
  %v9.fca.2.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 2
  store i8 %v9.unpack260, ptr %v9.fca.2.gep, align 1
  %v9.fca.3.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 3
  store i8 %v9.unpack262, ptr %v9.fca.3.gep, align 1
  %v9.fca.4.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 4
  store i8 %v9.unpack264, ptr %v9.fca.4.gep, align 1
  %v9.fca.5.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 5
  store i8 %v9.unpack266, ptr %v9.fca.5.gep, align 1
  %v9.fca.6.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 6
  store i8 %v9.unpack268, ptr %v9.fca.6.gep, align 1
  %v9.fca.7.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 7
  store i8 %v9.unpack270, ptr %v9.fca.7.gep, align 1
  %v9.fca.8.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 8
  store i8 %v9.unpack272, ptr %v9.fca.8.gep, align 1
  %v9.fca.9.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 9
  store i8 %v9.unpack274, ptr %v9.fca.9.gep, align 1
  %v9.fca.10.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 10
  store i8 %v9.unpack276, ptr %v9.fca.10.gep, align 1
  %v9.fca.11.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 11
  store i8 %v9.unpack278, ptr %v9.fca.11.gep, align 1
  %v9.fca.12.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 12
  store i8 %v9.unpack280, ptr %v9.fca.12.gep, align 1
  %v9.fca.13.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 13
  store i8 %v9.unpack282, ptr %v9.fca.13.gep, align 1
  %v9.fca.14.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 14
  store i8 %v9.unpack284, ptr %v9.fca.14.gep, align 1
  %v9.fca.15.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 15
  store i8 %v9.unpack286, ptr %v9.fca.15.gep, align 1
  %v9.fca.16.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 16
  store i8 %v9.unpack288, ptr %v9.fca.16.gep, align 1
  %v9.fca.17.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 17
  store i8 %v9.unpack290, ptr %v9.fca.17.gep, align 1
  %v9.fca.18.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 18
  store i8 %v9.unpack292, ptr %v9.fca.18.gep, align 1
  %v9.fca.19.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 19
  store i8 %v9.unpack294, ptr %v9.fca.19.gep, align 1
  %v9.fca.20.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 20
  store i8 %v9.unpack296, ptr %v9.fca.20.gep, align 1
  %v9.fca.21.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 21
  store i8 %v9.unpack298, ptr %v9.fca.21.gep, align 1
  %v9.fca.22.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 22
  store i8 %v9.unpack300, ptr %v9.fca.22.gep, align 1
  %v9.fca.23.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 23
  store i8 %v9.unpack302, ptr %v9.fca.23.gep, align 1
  %v9.fca.24.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 24
  store i8 %v9.unpack304, ptr %v9.fca.24.gep, align 1
  %v9.fca.25.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 25
  store i8 %v9.unpack306, ptr %v9.fca.25.gep, align 1
  %v9.fca.26.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 26
  store i8 %v9.unpack308, ptr %v9.fca.26.gep, align 1
  %v9.fca.27.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 27
  store i8 %v9.unpack310, ptr %v9.fca.27.gep, align 1
  %v9.fca.28.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 28
  store i8 %v9.unpack312, ptr %v9.fca.28.gep, align 1
  %v9.fca.29.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 29
  store i8 %v9.unpack314, ptr %v9.fca.29.gep, align 1
  %v9.fca.30.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 30
  store i8 %v9.unpack316, ptr %v9.fca.30.gep, align 1
  %v9.fca.31.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 31
  store i8 %v9.unpack318, ptr %v9.fca.31.gep, align 1
  %v9.fca.32.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 32
  store i8 %v9.unpack320, ptr %v9.fca.32.gep, align 1
  %v9.fca.33.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 33
  store i8 %v9.unpack322, ptr %v9.fca.33.gep, align 1
  %v9.fca.34.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 34
  store i8 %v9.unpack324, ptr %v9.fca.34.gep, align 1
  %v9.fca.35.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 35
  store i8 %v9.unpack326, ptr %v9.fca.35.gep, align 1
  %v9.fca.36.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 36
  store i8 %v9.unpack328, ptr %v9.fca.36.gep, align 1
  %v9.fca.37.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 37
  store i8 %v9.unpack330, ptr %v9.fca.37.gep, align 1
  %v9.fca.38.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 38
  store i8 %v9.unpack332, ptr %v9.fca.38.gep, align 1
  %v9.fca.39.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 39
  store i8 %v9.unpack334, ptr %v9.fca.39.gep, align 1
  %v9.fca.40.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 40
  store i8 %v9.unpack336, ptr %v9.fca.40.gep, align 1
  %v9.fca.41.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 41
  store i8 %v9.unpack338, ptr %v9.fca.41.gep, align 1
  %v9.fca.42.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 42
  store i8 %v9.unpack340, ptr %v9.fca.42.gep, align 1
  %v9.fca.43.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 43
  store i8 %v9.unpack342, ptr %v9.fca.43.gep, align 1
  %v9.fca.44.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 44
  store i8 %v9.unpack344, ptr %v9.fca.44.gep, align 1
  %v9.fca.45.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 45
  store i8 %v9.unpack346, ptr %v9.fca.45.gep, align 1
  %v9.fca.46.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 46
  store i8 %v9.unpack348, ptr %v9.fca.46.gep, align 1
  %v9.fca.47.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 47
  store i8 %v9.unpack350, ptr %v9.fca.47.gep, align 1
  %v9.fca.48.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 48
  store i8 %v9.unpack352, ptr %v9.fca.48.gep, align 1
  %v9.fca.49.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 49
  store i8 %v9.unpack354, ptr %v9.fca.49.gep, align 1
  %v9.fca.50.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 50
  store i8 %v9.unpack356, ptr %v9.fca.50.gep, align 1
  %v9.fca.51.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 51
  store i8 %v9.unpack358, ptr %v9.fca.51.gep, align 1
  %v9.fca.52.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 52
  store i8 %v9.unpack360, ptr %v9.fca.52.gep, align 1
  %v9.fca.53.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 53
  store i8 %v9.unpack362, ptr %v9.fca.53.gep, align 1
  %v9.fca.54.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 54
  store i8 %v9.unpack364, ptr %v9.fca.54.gep, align 1
  %v9.fca.55.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 55
  store i8 %v9.unpack366, ptr %v9.fca.55.gep, align 1
  %v9.fca.56.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 56
  store i8 %v9.unpack368, ptr %v9.fca.56.gep, align 1
  %v9.fca.57.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 57
  store i8 %v9.unpack370, ptr %v9.fca.57.gep, align 1
  %v9.fca.58.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 58
  store i8 %v9.unpack372, ptr %v9.fca.58.gep, align 1
  %v9.fca.59.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 59
  store i8 %v9.unpack374, ptr %v9.fca.59.gep, align 1
  %v9.fca.60.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 60
  store i8 %v9.unpack376, ptr %v9.fca.60.gep, align 1
  %v9.fca.61.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 61
  store i8 %v9.unpack378, ptr %v9.fca.61.gep, align 1
  %v9.fca.62.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 62
  store i8 %v9.unpack380, ptr %v9.fca.62.gep, align 1
  %v9.fca.63.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 63
  store i8 %v9.unpack382, ptr %v9.fca.63.gep, align 1
  %v10_invalid = icmp ugt i32 %v8_pair, 63
  br i1 %v10_invalid, label %v10_trap, label %v10_ok

v10_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v10_ok:                                           ; preds = %b2
  %v10_offset = zext nneg i32 %v8_pair to i64
  %v10_ptr = getelementptr [64 x i8], ptr %v9_storage, i64 0, i64 %v10_offset
  %v10 = load i8, ptr %v10_ptr, align 1
  %v12 = icmp eq i8 %v10, 1
  br i1 %v12, label %b8_to_b9, label %b3

b3:                                               ; preds = %v10_ok
  store i8 %v9.unpack, ptr %v14_storage, align 1
  %v14.fca.1.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 1
  store i8 %v9.unpack258, ptr %v14.fca.1.gep, align 1
  %v14.fca.2.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 2
  store i8 %v9.unpack260, ptr %v14.fca.2.gep, align 1
  %v14.fca.3.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 3
  store i8 %v9.unpack262, ptr %v14.fca.3.gep, align 1
  %v14.fca.4.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 4
  store i8 %v9.unpack264, ptr %v14.fca.4.gep, align 1
  %v14.fca.5.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 5
  store i8 %v9.unpack266, ptr %v14.fca.5.gep, align 1
  %v14.fca.6.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 6
  store i8 %v9.unpack268, ptr %v14.fca.6.gep, align 1
  %v14.fca.7.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 7
  store i8 %v9.unpack270, ptr %v14.fca.7.gep, align 1
  %v14.fca.8.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 8
  store i8 %v9.unpack272, ptr %v14.fca.8.gep, align 1
  %v14.fca.9.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 9
  store i8 %v9.unpack274, ptr %v14.fca.9.gep, align 1
  %v14.fca.10.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 10
  store i8 %v9.unpack276, ptr %v14.fca.10.gep, align 1
  %v14.fca.11.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 11
  store i8 %v9.unpack278, ptr %v14.fca.11.gep, align 1
  %v14.fca.12.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 12
  store i8 %v9.unpack280, ptr %v14.fca.12.gep, align 1
  %v14.fca.13.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 13
  store i8 %v9.unpack282, ptr %v14.fca.13.gep, align 1
  %v14.fca.14.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 14
  store i8 %v9.unpack284, ptr %v14.fca.14.gep, align 1
  %v14.fca.15.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 15
  store i8 %v9.unpack286, ptr %v14.fca.15.gep, align 1
  %v14.fca.16.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 16
  store i8 %v9.unpack288, ptr %v14.fca.16.gep, align 1
  %v14.fca.17.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 17
  store i8 %v9.unpack290, ptr %v14.fca.17.gep, align 1
  %v14.fca.18.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 18
  store i8 %v9.unpack292, ptr %v14.fca.18.gep, align 1
  %v14.fca.19.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 19
  store i8 %v9.unpack294, ptr %v14.fca.19.gep, align 1
  %v14.fca.20.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 20
  store i8 %v9.unpack296, ptr %v14.fca.20.gep, align 1
  %v14.fca.21.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 21
  store i8 %v9.unpack298, ptr %v14.fca.21.gep, align 1
  %v14.fca.22.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 22
  store i8 %v9.unpack300, ptr %v14.fca.22.gep, align 1
  %v14.fca.23.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 23
  store i8 %v9.unpack302, ptr %v14.fca.23.gep, align 1
  %v14.fca.24.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 24
  store i8 %v9.unpack304, ptr %v14.fca.24.gep, align 1
  %v14.fca.25.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 25
  store i8 %v9.unpack306, ptr %v14.fca.25.gep, align 1
  %v14.fca.26.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 26
  store i8 %v9.unpack308, ptr %v14.fca.26.gep, align 1
  %v14.fca.27.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 27
  store i8 %v9.unpack310, ptr %v14.fca.27.gep, align 1
  %v14.fca.28.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 28
  store i8 %v9.unpack312, ptr %v14.fca.28.gep, align 1
  %v14.fca.29.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 29
  store i8 %v9.unpack314, ptr %v14.fca.29.gep, align 1
  %v14.fca.30.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 30
  store i8 %v9.unpack316, ptr %v14.fca.30.gep, align 1
  %v14.fca.31.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 31
  store i8 %v9.unpack318, ptr %v14.fca.31.gep, align 1
  %v14.fca.32.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 32
  store i8 %v9.unpack320, ptr %v14.fca.32.gep, align 1
  %v14.fca.33.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 33
  store i8 %v9.unpack322, ptr %v14.fca.33.gep, align 1
  %v14.fca.34.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 34
  store i8 %v9.unpack324, ptr %v14.fca.34.gep, align 1
  %v14.fca.35.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 35
  store i8 %v9.unpack326, ptr %v14.fca.35.gep, align 1
  %v14.fca.36.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 36
  store i8 %v9.unpack328, ptr %v14.fca.36.gep, align 1
  %v14.fca.37.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 37
  store i8 %v9.unpack330, ptr %v14.fca.37.gep, align 1
  %v14.fca.38.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 38
  store i8 %v9.unpack332, ptr %v14.fca.38.gep, align 1
  %v14.fca.39.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 39
  store i8 %v9.unpack334, ptr %v14.fca.39.gep, align 1
  %v14.fca.40.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 40
  store i8 %v9.unpack336, ptr %v14.fca.40.gep, align 1
  %v14.fca.41.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 41
  store i8 %v9.unpack338, ptr %v14.fca.41.gep, align 1
  %v14.fca.42.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 42
  store i8 %v9.unpack340, ptr %v14.fca.42.gep, align 1
  %v14.fca.43.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 43
  store i8 %v9.unpack342, ptr %v14.fca.43.gep, align 1
  %v14.fca.44.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 44
  store i8 %v9.unpack344, ptr %v14.fca.44.gep, align 1
  %v14.fca.45.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 45
  store i8 %v9.unpack346, ptr %v14.fca.45.gep, align 1
  %v14.fca.46.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 46
  store i8 %v9.unpack348, ptr %v14.fca.46.gep, align 1
  %v14.fca.47.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 47
  store i8 %v9.unpack350, ptr %v14.fca.47.gep, align 1
  %v14.fca.48.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 48
  store i8 %v9.unpack352, ptr %v14.fca.48.gep, align 1
  %v14.fca.49.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 49
  store i8 %v9.unpack354, ptr %v14.fca.49.gep, align 1
  %v14.fca.50.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 50
  store i8 %v9.unpack356, ptr %v14.fca.50.gep, align 1
  %v14.fca.51.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 51
  store i8 %v9.unpack358, ptr %v14.fca.51.gep, align 1
  %v14.fca.52.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 52
  store i8 %v9.unpack360, ptr %v14.fca.52.gep, align 1
  %v14.fca.53.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 53
  store i8 %v9.unpack362, ptr %v14.fca.53.gep, align 1
  %v14.fca.54.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 54
  store i8 %v9.unpack364, ptr %v14.fca.54.gep, align 1
  %v14.fca.55.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 55
  store i8 %v9.unpack366, ptr %v14.fca.55.gep, align 1
  %v14.fca.56.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 56
  store i8 %v9.unpack368, ptr %v14.fca.56.gep, align 1
  %v14.fca.57.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 57
  store i8 %v9.unpack370, ptr %v14.fca.57.gep, align 1
  %v14.fca.58.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 58
  store i8 %v9.unpack372, ptr %v14.fca.58.gep, align 1
  %v14.fca.59.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 59
  store i8 %v9.unpack374, ptr %v14.fca.59.gep, align 1
  %v14.fca.60.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 60
  store i8 %v9.unpack376, ptr %v14.fca.60.gep, align 1
  %v14.fca.61.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 61
  store i8 %v9.unpack378, ptr %v14.fca.61.gep, align 1
  %v14.fca.62.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 62
  store i8 %v9.unpack380, ptr %v14.fca.62.gep, align 1
  %v14.fca.63.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 63
  store i8 %v9.unpack382, ptr %v14.fca.63.gep, align 1
  %v15_ptr = getelementptr [64 x i8], ptr %v14_storage, i64 0, i64 %v10_offset
  %v15 = load i8, ptr %v15_ptr, align 1
  %v17 = icmp eq i8 %v15, 3
  %spec.select = select i1 %v17, ptr %v22_scratch, ptr %v27_scratch
  %spec.select1351 = select i1 %v17, i8 2, i8 7
  br label %b8_to_b9

b9:                                               ; preds = %b8_to_b9, %b1
  %v29_mem.sroa.0.sink = phi ptr [ %v29_mem.sroa.0, %b8_to_b9 ], [ %p0, %b1 ]
  %v29_mem.sroa.131.sroa.4.sink = phi ptr [ %v29_mem.sroa.131.sroa.4, %b8_to_b9 ], [ %v5_mem.sroa.68.0.p0.sroa_idx, %b1 ]
  %v30_mem.sroa.131.sroa.3.sroa.0.0 = phi i8 [ %16, %b8_to_b9 ], [ %v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0.v5_mem.sroa.67.sroa.0.0., %b1 ]
  %v30_mem.sroa.131.sroa.0.0 = phi i32 [ %v23_mem.sroa.130.sroa.0.0.copyload, %b8_to_b9 ], [ 0, %b1 ]
  %4 = phi <16 x i8> [ %12, %b8_to_b9 ], [ %0, %b1 ]
  %5 = phi <16 x i8> [ %13, %b8_to_b9 ], [ %1, %b1 ]
  %6 = phi <16 x i8> [ %14, %b8_to_b9 ], [ %2, %b1 ]
  %7 = phi <16 x i8> [ %15, %b8_to_b9 ], [ %3, %b1 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %v30_mem.sroa.0, ptr noundef nonnull align 1 dereferenceable(56) %v29_mem.sroa.0.sink, i64 56, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5, ptr noundef nonnull align 1 dereferenceable(59) %v29_mem.sroa.131.sroa.4.sink, i64 59, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %return_storage, ptr noundef nonnull align 8 dereferenceable(56) %v30_mem.sroa.0, i64 56, i1 false)
  %v30_mem.sroa.3.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 56
  store <16 x i8> %4, ptr %v30_mem.sroa.3.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.35.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 72
  store <16 x i8> %5, ptr %v30_mem.sroa.35.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.67.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 88
  store <16 x i8> %6, ptr %v30_mem.sroa.67.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.99.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 104
  store <16 x i8> %7, ptr %v30_mem.sroa.99.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.131.0.return_storage.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 120
  store i32 %v30_mem.sroa.131.sroa.0.0, ptr %v30_mem.sroa.131.0.return_storage.sroa_idx, align 8
  %v30_mem.sroa.131.sroa.3.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  store i8 %v30_mem.sroa.131.sroa.3.sroa.0.0, ptr %v30_mem.sroa.131.sroa.3.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx, align 4
  %v30_mem.sroa.131.sroa.5.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %return_storage, i64 125
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5.0.v30_mem.sroa.131.0.return_storage.sroa_idx.sroa_idx, ptr noundef nonnull align 1 dereferenceable(59) %v30_mem.sroa.131.sroa.5, i64 59, i1 false)
  ret void

b8_to_b9:                                         ; preds = %b3, %v10_ok
  %v22_scratch.sink1350 = phi ptr [ %v22_scratch, %v10_ok ], [ %spec.select, %b3 ]
  %.sink = phi i8 [ 2, %v10_ok ], [ %spec.select1351, %b3 ]
  %8 = load <16 x i8>, ptr %v9_ptr, align 1
  store <16 x i8> %8, ptr %v22_scratch.sink1350, align 1
  %v19.fca.16.gep162 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 16
  %9 = load <16 x i8>, ptr %v9.elt287, align 1
  store <16 x i8> %9, ptr %v19.fca.16.gep162, align 1
  %v19.fca.32.gep194 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 32
  %10 = load <16 x i8>, ptr %v9.elt319, align 1
  store <16 x i8> %10, ptr %v19.fca.32.gep194, align 1
  %v19.fca.48.gep226 = getelementptr inbounds nuw i8, ptr %v22_scratch.sink1350, i64 48
  %11 = load <16 x i8>, ptr %v9.elt351, align 1
  store <16 x i8> %11, ptr %v19.fca.48.gep226, align 1
  %v22_ptr = getelementptr [64 x i8], ptr %v22_scratch.sink1350, i64 0, i64 %v10_offset
  store i8 %.sink, ptr %v22_ptr, align 1
  %12 = load <16 x i8>, ptr %v22_scratch.sink1350, align 1
  %13 = load <16 x i8>, ptr %v19.fca.16.gep162, align 1
  %14 = load <16 x i8>, ptr %v19.fca.32.gep194, align 1
  %15 = load <16 x i8>, ptr %v19.fca.48.gep226, align 1
  %v23_mem.sroa.130.sroa.0.0.copyload = load i32, ptr %v0_ptr, align 1
  %v23_mem.sroa.130.sroa.2.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx = getelementptr i8, ptr %p0, i64 124
  %16 = load i8, ptr %v23_mem.sroa.130.sroa.2.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx, align 1
  %v23_mem.sroa.130.sroa.3.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx = getelementptr i8, ptr %p0, i64 125
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(56) %v29_mem.sroa.0, ptr noundef nonnull align 1 dereferenceable(56) %p0, i64 56, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(59) %v29_mem.sroa.131.sroa.4, ptr noundef nonnull align 1 dereferenceable(59) %v23_mem.sroa.130.sroa.3.0.v23_mem.sroa.130.0.p0.sroa_idx.sroa_idx, i64 59, i1 false)
  br label %b9
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i1 @liza___liza_json_space(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = icmp ult i8 %p0, 33
  %switch.cast = zext nneg i8 %p0 to i33
  %switch.downshift = lshr i33 -4294957568, %switch.cast
  %switch.masked = trunc i33 %switch.downshift to i1
  %v13 = select i1 %0, i1 %switch.masked, i1 false
  ret i1 %v13
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i1 @liza___liza_json_digit(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = add i8 %p0, -48
  %v5 = icmp ult i8 %0, 10
  ret i1 %v5
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define range(i32 0, 17) i32 @liza___liza_json_hex(i8 %p0) local_unnamed_addr #6 {
b0:
  %0 = add i8 %p0, -48
  %v5 = icmp ult i8 %0, 10
  br i1 %v5, label %v6_ok, label %b6

v6_ok:                                            ; preds = %b0
  %v6 = zext nneg i8 %p0 to i32
  %v8_pair = add nsw i32 %v6, -48
  br label %common.ret

common.ret:                                       ; preds = %v24_ok, %v15_ok, %v6_ok, %b12
  %common.ret.op = phi i32 [ %v8_pair, %v6_ok ], [ %v17_pair, %v15_ok ], [ %v26_pair, %v24_ok ], [ 16, %b12 ]
  ret i32 %common.ret.op

b6:                                               ; preds = %b0
  %1 = add i8 %p0, -65
  %v14 = icmp ult i8 %1, 6
  br i1 %v14, label %v15_ok, label %b12

v15_ok:                                           ; preds = %b6
  %v15 = zext nneg i8 %p0 to i32
  %v17_pair = add nsw i32 %v15, -55
  br label %common.ret

b12:                                              ; preds = %b6
  %2 = add i8 %p0, -97
  %v23 = icmp ult i8 %2, 6
  br i1 %v23, label %v24_ok, label %common.ret

v24_ok:                                           ; preds = %b12
  %v24 = zext nneg i8 %p0 to i32
  %v26_pair = add nsw i32 %v24, -87
  br label %common.ret
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define %variant.4 @liza_json.status(ptr readonly captures(none) %p0) local_unnamed_addr #3 {
b0:
  %v0_ptr = getelementptr i8, ptr %p0, i64 168
  %v0 = load i32, ptr %v0_ptr, align 4
  %v2 = icmp eq i32 %v0, 0
  br i1 %v2, label %common.ret, label %b3

common.ret:                                       ; preds = %b0, %b3
  %common.ret.op = phi %variant.4 [ %v42, %b3 ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  ret %variant.4 %common.ret.op

b3:                                               ; preds = %b0
  %v7 = icmp eq i32 %v0, 2
  %v9 = select i1 %v7, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12 = icmp eq i32 %v0, 3
  %v14 = select i1 %v12, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9
  %v17 = icmp eq i32 %v0, 4
  %v19 = select i1 %v17, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14
  %v22 = icmp eq i32 %v0, 5
  %v24 = select i1 %v22, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19
  %v27 = icmp eq i32 %v0, 6
  %v29 = select i1 %v27, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24
  %v32 = icmp eq i32 %v0, 7
  %v34 = select i1 %v32, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29
  %v37 = icmp eq i32 %v0, 8
  %v39 = select i1 %v37, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34
  %v40_ptr = getelementptr i8, ptr %p0, i64 176
  %v40 = load i64, ptr %v40_ptr, align 8
  %v41_field0 = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39, 0
  %v41 = insertvalue %struct.JsonError %v41_field0, i64 %v40, 1
  %v42 = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41, 1
  br label %common.ret
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define %variant.5 @liza_json.finish(ptr readonly captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v33_mem = alloca %struct.JsonState, align 8
  %v0_ptr.i = getelementptr i8, ptr %p0, i64 168
  %v0.i = load i32, ptr %v0_ptr.i, align 4
  %v2.i = icmp eq i32 %v0.i, 0
  br i1 %v2.i, label %liza_json.status.exit, label %b3.i

b3.i:                                             ; preds = %b0
  %v7.i = icmp eq i32 %v0.i, 2
  %v9.i = select i1 %v7.i, %variant.1 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 zeroinitializer
  %v12.i = icmp eq i32 %v0.i, 3
  %v14.i = select i1 %v12.i, %variant.1 { i32 2, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v9.i
  %v17.i = icmp eq i32 %v0.i, 4
  %v19.i = select i1 %v17.i, %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v14.i
  %v22.i = icmp eq i32 %v0.i, 5
  %v24.i = select i1 %v22.i, %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v19.i
  %v27.i = icmp eq i32 %v0.i, 6
  %v29.i = select i1 %v27.i, %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v24.i
  %v32.i = icmp eq i32 %v0.i, 7
  %v34.i = select i1 %v32.i, %variant.1 { i32 6, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v29.i
  %v37.i = icmp eq i32 %v0.i, 8
  %v39.i = select i1 %v37.i, %variant.1 { i32 7, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, %variant.1 %v34.i
  %v40_ptr.i = getelementptr i8, ptr %p0, i64 176
  %v40.i = load i64, ptr %v40_ptr.i, align 8
  %v41_field0.i = insertvalue %struct.JsonError zeroinitializer, %variant.1 %v39.i, 0
  %v41.i = insertvalue %struct.JsonError %v41_field0.i, i64 %v40.i, 1
  %v42.i = insertvalue %variant.4 zeroinitializer, %struct.JsonError %v41.i, 1
  br label %liza_json.status.exit

liza_json.status.exit:                            ; preds = %b0, %b3.i
  %common.ret.op.i = phi %variant.4 [ %v42.i, %b3.i ], [ { i32 1, %struct.JsonError zeroinitializer, [0 x i8] zeroinitializer }, %b0 ]
  %v1 = extractvalue %variant.4 %common.ret.op.i, 0
  %switch = icmp eq i32 %v1, 0
  br i1 %switch, label %b2, label %b4

common.ret:                                       ; preds = %b38, %b36, %b27, %b7, %b2
  %common.ret.op = phi %variant.5 [ %v3, %b2 ], [ %v12, %b7 ], [ %v52, %b27 ], [ %v68, %b36 ], [ %v70, %b38 ]
  ret %variant.5 %common.ret.op

b2:                                               ; preds = %liza_json.status.exit
  %v2 = extractvalue %variant.4 %common.ret.op.i, 1
  %v3 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v2, 2
  br label %common.ret

b4:                                               ; preds = %liza_json.status.exit
  %v4 = load %struct.Utf8StreamState, ptr %p0, align 8
  %v0.i8 = extractvalue %struct.Utf8StreamState %v4, 6
  switch i32 %v0.i8, label %b6.i [
    i32 1, label %b1.i
    i32 2, label %b4.i
  ]

b1.i:                                             ; preds = %b4
  %v4.i = extractvalue %struct.Utf8StreamState %v4, 7
  %v5.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i, 1
  %v6.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v5.i, 2
  br label %liza_utf8_stream.finish.exit

b4.i:                                             ; preds = %b4
  %v11.i = extractvalue %struct.Utf8StreamState %v4, 7
  %v12.i9 = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i, 1
  %v13.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v12.i9, 2
  br label %liza_utf8_stream.finish.exit

b6.i:                                             ; preds = %b4
  %v14.i11 = extractvalue %struct.Utf8StreamState %v4, 3
  %v16.not.i = icmp eq i32 %v14.i11, 0
  br i1 %v16.not.i, label %b9.i, label %b7.i

b7.i:                                             ; preds = %b6.i
  %v18.i = extractvalue %struct.Utf8StreamState %v4, 2
  %v19.i12 = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v18.i, 1
  %v20.i = insertvalue %variant.2 { i32 1, i64 0, %struct.Utf8StreamError zeroinitializer }, %struct.Utf8StreamError %v19.i12, 2
  br label %liza_utf8_stream.finish.exit

b9.i:                                             ; preds = %b6.i
  %v21.i = extractvalue %struct.Utf8StreamState %v4, 1
  %v22.i13 = insertvalue %variant.2 zeroinitializer, i64 %v21.i, 1
  br label %liza_utf8_stream.finish.exit

liza_utf8_stream.finish.exit:                     ; preds = %b1.i, %b4.i, %b7.i, %b9.i
  %common.ret.op.i10 = phi %variant.2 [ %v6.i, %b1.i ], [ %v13.i, %b4.i ], [ %v20.i, %b7.i ], [ %v22.i13, %b9.i ]
  %v6 = extractvalue %variant.2 %common.ret.op.i10, 0
  %switch6 = icmp eq i32 %v6, 0
  br i1 %switch6, label %b6, label %b7

b6:                                               ; preds = %liza_utf8_stream.finish.exit
  %v13_ptr = getelementptr i8, ptr %p0, i64 128
  %v13 = load i32, ptr %v13_ptr, align 4
  switch i32 %v13, label %b19_to_b20 [
    i32 11, label %b18
    i32 12, label %b18
    i32 14, label %b18
    i32 17, label %b18
  ]

b7:                                               ; preds = %liza_utf8_stream.finish.exit
  %v8 = extractvalue %variant.2 %common.ret.op.i10, 2
  %v10 = extractvalue %struct.Utf8StreamError %v8, 1
  %v11 = insertvalue %struct.JsonError { %variant.1 { i32 4, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v10, 1
  %v12 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v11, 2
  br label %common.ret

b18:                                              ; preds = %b6, %b6, %b6, %b6
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(184) %v33_mem, ptr noundef nonnull align 1 dereferenceable(184) %p0, i64 184, i1 false)
  %v33_part = getelementptr inbounds nuw i8, ptr %v33_mem, i64 128
  store i32 0, ptr %v33_part, align 8
  call void @liza___liza_owned___liza_json_done(ptr nonnull sret(%struct.JsonState) %v33_mem, ptr nonnull poison)
  %v35_next.sroa.4.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 48
  %v35_next.sroa.4.0.copyload = load i64, ptr %v35_next.sroa.4.0.v33_mem.sroa_idx, align 8
  %v35_next.sroa.8.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 120
  %v35_next.sroa.8.0.copyload = load i32, ptr %v35_next.sroa.8.0.v33_mem.sroa_idx, align 8
  %v35_next.sroa.10.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 124
  %0 = load i8, ptr %v35_next.sroa.10.0.v33_mem.sroa_idx, align 4
  %v35_next.sroa.14.0.copyload = load i32, ptr %v33_part, align 8
  %v35_next.sroa.18.0.v33_mem.sroa_idx = getelementptr inbounds nuw i8, ptr %v33_mem, i64 160
  %v35_next.sroa.18.0.copyload = load i64, ptr %v35_next.sroa.18.0.v33_mem.sroa_idx, align 8
  %extract.t37 = trunc i8 %0 to i1
  br label %b20

b20:                                              ; preds = %b19_to_b20, %b18
  %.sink.off0 = phi i1 [ %extract.t, %b19_to_b20 ], [ %extract.t37, %b18 ]
  %v35_mem.sroa.726.0 = phi i64 [ %v35_next.sroa.18.0.copyload33, %b19_to_b20 ], [ %v35_next.sroa.18.0.copyload, %b18 ]
  %v35_mem.sroa.622.0 = phi i32 [ %v13, %b19_to_b20 ], [ %v35_next.sroa.14.0.copyload, %b18 ]
  %v35_mem.sroa.417.0 = phi i32 [ %v35_next.sroa.8.0.copyload31, %b19_to_b20 ], [ %v35_next.sroa.8.0.copyload, %b18 ]
  %v35_mem.sroa.2.0 = phi i64 [ %v35_next.sroa.4.0.copyload30, %b19_to_b20 ], [ %v35_next.sroa.4.0.copyload, %b18 ]
  %v35_mem.128.v36.off = add i32 %v35_mem.sroa.622.0, -4
  %switch7 = icmp ult i32 %v35_mem.128.v36.off, 3
  br i1 %switch7, label %b27, label %b29

b27:                                              ; preds = %b20
  %v51 = insertvalue %struct.JsonError { %variant.1 { i32 3, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.726.0, 1
  %v52 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v51, 2
  br label %common.ret

b29:                                              ; preds = %b20
  %v55 = icmp eq i32 %v35_mem.sroa.622.0, 0
  %v59 = icmp eq i32 %v35_mem.sroa.417.0, 0
  %v60.not5 = select i1 %v55, i1 %v59, i1 false
  %v64.not = select i1 %v60.not5, i1 %.sink.off0, i1 false
  br i1 %v64.not, label %b38, label %b36

b36:                                              ; preds = %b29
  %v67 = insertvalue %struct.JsonError { %variant.1 { i32 5, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v35_mem.sroa.2.0, 1
  %v68 = insertvalue %variant.5 { i32 1, i64 0, %struct.JsonError zeroinitializer }, %struct.JsonError %v67, 2
  br label %common.ret

b38:                                              ; preds = %b29
  %v70 = insertvalue %variant.5 zeroinitializer, i64 %v35_mem.sroa.2.0, 1
  br label %common.ret

b19_to_b20:                                       ; preds = %b6
  %v35_next.sroa.4.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 48
  %v35_next.sroa.4.0.copyload30 = load i64, ptr %v35_next.sroa.4.0.p0.sroa_idx, align 1
  %v35_next.sroa.8.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 120
  %v35_next.sroa.8.0.copyload31 = load i32, ptr %v35_next.sroa.8.0.p0.sroa_idx, align 1
  %v35_next.sroa.10.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 124
  %1 = load i8, ptr %v35_next.sroa.10.0.p0.sroa_idx, align 1
  %v35_next.sroa.18.0.p0.sroa_idx = getelementptr inbounds nuw i8, ptr %p0, i64 160
  %v35_next.sroa.18.0.copyload33 = load i64, ptr %v35_next.sroa.18.0.p0.sroa_idx, align 1
  %extract.t = trunc i8 %1 to i1
  br label %b20
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define i32 @liza___liza_json_mut_fail(i32 returned %p0, i64 %p1, ptr writeonly captures(none) initializes((168, 172), (176, 184)) %p2) local_unnamed_addr #8 {
b0:
  %v0 = getelementptr i8, ptr %p2, i64 168
  store i32 %p0, ptr %v0, align 4
  %v2 = getelementptr i8, ptr %p2, i64 176
  store i64 %p1, ptr %v2, align 8
  ret i32 %p0
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i32 @liza___liza_json_mut_done(ptr captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v0 = getelementptr i8, ptr %p0, i64 120
  %v1 = load i32, ptr %v0, align 4
  %v3 = icmp eq i32 %v1, 0
  br i1 %v3, label %b1, label %b2

b1:                                               ; preds = %b0
  %v4 = getelementptr i8, ptr %p0, i64 124
  store i1 true, ptr %v4, align 1
  br label %b9

b2:                                               ; preds = %b0
  %v10_pair = add i32 %v1, -1
  %v12_invalid = icmp ugt i32 %v10_pair, 63
  br i1 %v12_invalid, label %v12_trap, label %v12_ok

v12_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v12_ok:                                           ; preds = %b2
  %v11 = getelementptr i8, ptr %p0, i64 56
  %v12_offset = zext nneg i32 %v10_pair to i64
  %v12 = getelementptr [64 x i8], ptr %v11, i64 0, i64 %v12_offset
  %v13 = load i8, ptr %v12, align 1
  switch i8 %v13, label %v28_ok [
    i8 1, label %v24_ok
    i8 3, label %v24_ok
  ]

v24_ok:                                           ; preds = %v12_ok, %v12_ok
  store i8 2, ptr %v12, align 1
  br label %b9

v28_ok:                                           ; preds = %v12_ok
  store i8 7, ptr %v12, align 1
  br label %b9

b9:                                               ; preds = %v24_ok, %v28_ok, %b1
  %v31 = getelementptr i8, ptr %p0, i64 168
  %v32 = load i32, ptr %v31, align 4
  ret i32 %v32
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i32 @liza___liza_json_mut_step(i8 %p0, ptr %p1) local_unnamed_addr #2 {
b0:
  %v0 = getelementptr i8, ptr %p1, i64 128
  %v1 = load i32, ptr %v0, align 4
  switch i32 %v1, label %b132 [
    i32 1, label %b1
    i32 2, label %b16
    i32 4, label %b46
    i32 5, label %b52
    i32 3, label %b61
    i32 6, label %b61
    i32 20, label %b91
  ]

b1:                                               ; preds = %b0
  %v5 = icmp ult i8 %p0, 32
  br i1 %v5, label %b3, label %b5

common.ret:                                       ; preds = %b312, %b304, %b292, %b289, %b286, %v691_ok, %b279, %b271, %b266, %b264, %v613_ok, %b255, %b251, %b246, %v560_ok, %v542_ok, %b217, %b210, %b201, %b189, %b180, %b165, %b157, %b140, %b131, %liza___liza_json_mut_done.exit, %b126, %b89, %b86, %b80, %b75, %b73, %b63, %b56, %b54, %b50, %b48, %b44, %b42, %b39, %b14, %b10, %v24_ok, %b3
  %common.ret.op = phi i32 [ 1, %b3 ], [ %v28, %v24_ok ], [ %v30, %b10 ], [ %v42, %b14 ], [ %v81, %b39 ], [ %v94, %b42 ], [ 3, %b44 ], [ 4, %b48 ], [ %v117, %b50 ], [ 4, %b54 ], [ %v140, %b56 ], [ 3, %b63 ], [ 4, %b73 ], [ %v201, %b75 ], [ %v220, %b80 ], [ 4, %b86 ], [ %v241, %b89 ], [ 1, %b126 ], [ %v32.i, %liza___liza_json_mut_done.exit ], [ %v337, %b131 ], [ 2, %b140 ], [ %v392, %b157 ], [ %v411, %b165 ], [ %v440, %b180 ], [ %v457, %b189 ], [ 2, %b201 ], [ 2, %b210 ], [ %v514, %b217 ], [ %v545, %v542_ok ], [ %v563, %v560_ok ], [ 1, %b246 ], [ %v597, %b251 ], [ 1, %b255 ], [ %v617, %v613_ok ], [ 1, %b264 ], [ %v639, %b266 ], [ 1, %b271 ], [ 7, %b279 ], [ %v694, %v691_ok ], [ %v704, %b286 ], [ %v711, %b289 ], [ %v722, %b292 ], [ %v753, %b304 ], [ 1, %b312 ]
  ret i32 %common.ret.op

b3:                                               ; preds = %b1
  %v7 = getelementptr i8, ptr %p1, i64 48
  %v8 = load i64, ptr %v7, align 8
  %v0.i = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i, align 4
  %v2.i = getelementptr i8, ptr %p1, i64 176
  store i64 %v8, ptr %v2.i, align 8
  br label %common.ret

b5:                                               ; preds = %b1
  switch i8 %p0, label %b14 [
    i8 34, label %b6
    i8 92, label %b12
  ]

b6:                                               ; preds = %b5
  store i32 0, ptr %v0, align 4
  %v17 = getelementptr i8, ptr %p1, i64 132
  %v18 = load i1, ptr %v17, align 1
  br i1 %v18, label %b8, label %b10

b8:                                               ; preds = %b6
  %v19 = getelementptr i8, ptr %p1, i64 56
  %v20 = getelementptr i8, ptr %p1, i64 120
  %v21 = load i32, ptr %v20, align 4
  %v23_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v21, i32 1)
  %v23 = extractvalue { i32, i1 } %v23_pair, 0
  %v23_overflow = extractvalue { i32, i1 } %v23_pair, 1
  br i1 %v23_overflow, label %v23_trap, label %v23_ok

v23_trap:                                         ; preds = %b8
  tail call void @llvm.trap()
  unreachable

v23_ok:                                           ; preds = %b8
  %v24_invalid = icmp ugt i32 %v23, 63
  br i1 %v24_invalid, label %v24_trap, label %v24_ok

v24_trap:                                         ; preds = %v23_ok
  tail call void @llvm.trap()
  unreachable

v24_ok:                                           ; preds = %v23_ok
  %v24_offset = zext nneg i32 %v23 to i64
  %v24 = getelementptr [64 x i8], ptr %v19, i64 0, i64 %v24_offset
  store i8 5, ptr %v24, align 1
  %v27 = getelementptr i8, ptr %p1, i64 168
  %v28 = load i32, ptr %v27, align 4
  br label %common.ret

b10:                                              ; preds = %b6
  %v30 = tail call i32 @liza___liza_json_mut_done(ptr nonnull %p1)
  br label %common.ret

b12:                                              ; preds = %b5
  store i32 2, ptr %v0, align 4
  %v37 = getelementptr i8, ptr %p1, i64 152
  %v38 = getelementptr i8, ptr %p1, i64 48
  %v39 = load i64, ptr %v38, align 8
  store i64 %v39, ptr %v37, align 8
  br label %b14

b14:                                              ; preds = %b5, %b12
  %v41 = getelementptr i8, ptr %p1, i64 168
  %v42 = load i32, ptr %v41, align 4
  br label %common.ret

b16:                                              ; preds = %b0
  switch i8 %p0, label %b44 [
    i8 114, label %b39
    i8 110, label %b39
    i8 102, label %b39
    i8 98, label %b39
    i8 92, label %b39
    i8 47, label %b39
    i8 34, label %b39
    i8 116, label %b39
    i8 117, label %b42
  ]

b39:                                              ; preds = %b16, %b16, %b16, %b16, %b16, %b16, %b16, %b16
  store i32 1, ptr %v0, align 4
  %v80 = getelementptr i8, ptr %p1, i64 168
  %v81 = load i32, ptr %v80, align 4
  br label %common.ret

b42:                                              ; preds = %b16
  store i32 3, ptr %v0, align 4
  %v87 = getelementptr i8, ptr %p1, i64 144
  store <2 x i32> zeroinitializer, ptr %v87, align 4
  %v93 = getelementptr i8, ptr %p1, i64 168
  %v94 = load i32, ptr %v93, align 4
  br label %common.ret

b44:                                              ; preds = %b16
  %v96 = getelementptr i8, ptr %p1, i64 48
  %v97 = load i64, ptr %v96, align 8
  %v0.i13 = getelementptr i8, ptr %p1, i64 168
  store i32 3, ptr %v0.i13, align 4
  %v2.i14 = getelementptr i8, ptr %p1, i64 176
  store i64 %v97, ptr %v2.i14, align 8
  br label %common.ret

b46:                                              ; preds = %b0
  %v106.not = icmp eq i8 %p0, 92
  br i1 %v106.not, label %b50, label %b48

b48:                                              ; preds = %b46
  %v108 = getelementptr i8, ptr %p1, i64 160
  %v109 = load i64, ptr %v108, align 8
  %v0.i15 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i15, align 4
  %v2.i16 = getelementptr i8, ptr %p1, i64 176
  store i64 %v109, ptr %v2.i16, align 8
  br label %common.ret

b50:                                              ; preds = %b46
  store i32 5, ptr %v0, align 4
  %v116 = getelementptr i8, ptr %p1, i64 168
  %v117 = load i32, ptr %v116, align 4
  br label %common.ret

b52:                                              ; preds = %b0
  %v123.not = icmp eq i8 %p0, 117
  br i1 %v123.not, label %b56, label %b54

b54:                                              ; preds = %b52
  %v125 = getelementptr i8, ptr %p1, i64 160
  %v126 = load i64, ptr %v125, align 8
  %v0.i17 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i17, align 4
  %v2.i18 = getelementptr i8, ptr %p1, i64 176
  store i64 %v126, ptr %v2.i18, align 8
  br label %common.ret

b56:                                              ; preds = %b52
  store i32 6, ptr %v0, align 4
  %v133 = getelementptr i8, ptr %p1, i64 144
  store <2 x i32> zeroinitializer, ptr %v133, align 4
  %v139 = getelementptr i8, ptr %p1, i64 168
  %v140 = load i32, ptr %v139, align 4
  br label %common.ret

b61:                                              ; preds = %b0, %b0
  %0 = add i8 %p0, -48
  %v5.i = icmp ult i8 %0, 10
  br i1 %v5.i, label %b65, label %b6.i

b6.i:                                             ; preds = %b61
  %1 = add i8 %p0, -65
  %v14.i = icmp ult i8 %1, 6
  br i1 %v14.i, label %b65, label %b12.i

b12.i:                                            ; preds = %b6.i
  %2 = add i8 %p0, -97
  %v23.i = icmp ult i8 %2, 6
  br i1 %v23.i, label %b65, label %b63

b63:                                              ; preds = %b12.i
  %v155 = getelementptr i8, ptr %p1, i64 48
  %v156 = load i64, ptr %v155, align 8
  %v0.i19 = getelementptr i8, ptr %p1, i64 168
  store i32 3, ptr %v0.i19, align 4
  %v2.i20 = getelementptr i8, ptr %p1, i64 176
  store i64 %v156, ptr %v2.i20, align 8
  br label %common.ret

b65:                                              ; preds = %b12.i, %b6.i, %b61
  %.sink = phi i32 [ -48, %b61 ], [ -55, %b6.i ], [ -87, %b12.i ]
  %v160 = getelementptr i8, ptr %p1, i64 148
  %v162 = load i32, ptr %v160, align 4
  %v164_overflow = icmp ugt i32 %v162, 268435455
  br i1 %v164_overflow, label %v164_trap, label %v165_ok

v164_trap:                                        ; preds = %b65
  tail call void @llvm.trap()
  unreachable

v165_ok:                                          ; preds = %b65
  %v6.i = zext nneg i8 %p0 to i32
  %v8_pair.i = add nsw i32 %.sink, %v6.i
  %v164 = shl nuw i32 %v162, 4
  %v165_pair70 = add nuw i32 %v164, %v8_pair.i
  store i32 %v165_pair70, ptr %v160, align 4
  %v167 = getelementptr i8, ptr %p1, i64 144
  %v169 = load i32, ptr %v167, align 4
  %v171_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v169, i32 1)
  %v171_overflow = extractvalue { i32, i1 } %v171_pair, 1
  br i1 %v171_overflow, label %v171_trap, label %v171_ok

v171_trap:                                        ; preds = %v165_ok
  tail call void @llvm.trap()
  unreachable

v171_ok:                                          ; preds = %v165_ok
  %v171 = extractvalue { i32, i1 } %v171_pair, 0
  store i32 %v171, ptr %v167, align 4
  %v176 = icmp eq i32 %v171, 4
  br i1 %v176, label %b66, label %b89

b66:                                              ; preds = %v171_ok
  %v180 = icmp eq i32 %v1, 6
  br i1 %v180, label %b68, label %b76

b68:                                              ; preds = %b66
  %3 = add i32 %v165_pair70, -57344
  %or.cond = icmp ult i32 %3, -1024
  br i1 %or.cond, label %b73, label %b75

b73:                                              ; preds = %b68
  %v192 = getelementptr i8, ptr %p1, i64 160
  %v193 = load i64, ptr %v192, align 8
  %v0.i21 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i21, align 4
  %v2.i22 = getelementptr i8, ptr %p1, i64 176
  store i64 %v193, ptr %v2.i22, align 8
  br label %common.ret

b75:                                              ; preds = %b68
  store i32 1, ptr %v0, align 4
  %v200 = getelementptr i8, ptr %p1, i64 168
  %v201 = load i32, ptr %v200, align 4
  br label %common.ret

b76:                                              ; preds = %b66
  %4 = and i32 %v165_pair70, -1024
  switch i32 %4, label %b88 [
    i32 55296, label %b80
    i32 56320, label %b86
  ]

b80:                                              ; preds = %b76
  store i32 4, ptr %v0, align 4
  %v215 = getelementptr i8, ptr %p1, i64 160
  %v216 = getelementptr i8, ptr %p1, i64 152
  %v217 = load i64, ptr %v216, align 8
  store i64 %v217, ptr %v215, align 8
  %v219 = getelementptr i8, ptr %p1, i64 168
  %v220 = load i32, ptr %v219, align 4
  br label %common.ret

b86:                                              ; preds = %b76
  %v232 = getelementptr i8, ptr %p1, i64 152
  %v233 = load i64, ptr %v232, align 8
  %v0.i23 = getelementptr i8, ptr %p1, i64 168
  store i32 4, ptr %v0.i23, align 4
  %v2.i24 = getelementptr i8, ptr %p1, i64 176
  store i64 %v233, ptr %v2.i24, align 8
  br label %common.ret

b88:                                              ; preds = %b76
  store i32 1, ptr %v0, align 4
  br label %b89

b89:                                              ; preds = %v171_ok, %b88
  %v240 = getelementptr i8, ptr %p1, i64 168
  %v241 = load i32, ptr %v240, align 4
  br label %common.ret

b91:                                              ; preds = %b0
  %v248 = getelementptr i8, ptr %p1, i64 136
  %v249 = load i32, ptr %v248, align 4
  switch i32 %v249, label %b125 [
    i32 1, label %b104.thread
    i32 2, label %b105
    i32 3, label %b120
  ]

b104.thread:                                      ; preds = %b91
  %v252 = getelementptr i8, ptr %p1, i64 140
  %v253 = load i32, ptr %v252, align 4
  %v255 = icmp eq i32 %v253, 1
  %. = select i1 %v255, i8 114, i8 0
  %v261 = icmp eq i32 %v253, 2
  %v263 = select i1 %v261, i8 117, i8 %.
  %v267 = icmp eq i32 %v253, 3
  %v269 = select i1 %v267, i8 101, i8 %v263
  br label %b125

b105:                                             ; preds = %b91
  %v276 = getelementptr i8, ptr %p1, i64 140
  %v277 = load i32, ptr %v276, align 4
  %v279 = icmp eq i32 %v277, 1
  %.v270 = select i1 %v279, i8 97, i8 0
  %v285 = icmp eq i32 %v277, 2
  %v287 = select i1 %v285, i8 108, i8 %.v270
  %v291 = icmp eq i32 %v277, 3
  %v293 = select i1 %v291, i8 115, i8 %v287
  %v297 = icmp eq i32 %v277, 4
  %v299 = select i1 %v297, i8 101, i8 %v293
  br label %b125

b120:                                             ; preds = %b91
  %v306 = getelementptr i8, ptr %p1, i64 140
  %v307 = load i32, ptr %v306, align 4
  %v309 = icmp eq i32 %v307, 1
  %.1 = select i1 %v309, i8 117, i8 108
  br label %b125

b125:                                             ; preds = %b91, %b105, %b104.thread, %b120
  %v30161 = phi i32 [ 4, %b120 ], [ 4, %b104.thread ], [ 5, %b105 ], [ 4, %b91 ]
  %v313 = phi i8 [ %.1, %b120 ], [ %v269, %b104.thread ], [ %v299, %b105 ], [ 0, %b91 ]
  %v314.not = icmp eq i8 %p0, %v313
  br i1 %v314.not, label %b128, label %b126

b126:                                             ; preds = %b125
  %v316 = getelementptr i8, ptr %p1, i64 48
  %v317 = load i64, ptr %v316, align 8
  %v0.i25 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i25, align 4
  %v2.i26 = getelementptr i8, ptr %p1, i64 176
  store i64 %v317, ptr %v2.i26, align 8
  br label %common.ret

b128:                                             ; preds = %b125
  %v321 = getelementptr i8, ptr %p1, i64 140
  %v323 = load i32, ptr %v321, align 4
  %v325_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v323, i32 1)
  %v325_overflow = extractvalue { i32, i1 } %v325_pair, 1
  br i1 %v325_overflow, label %v325_trap, label %v325_ok

v325_trap:                                        ; preds = %b128
  tail call void @llvm.trap()
  unreachable

v325_ok:                                          ; preds = %b128
  %v325 = extractvalue { i32, i1 } %v325_pair, 0
  store i32 %v325, ptr %v321, align 4
  %v329 = icmp eq i32 %v325, %v30161
  br i1 %v329, label %b129, label %b131

b129:                                             ; preds = %v325_ok
  store i32 0, ptr %v0, align 4
  %v0.i27 = getelementptr i8, ptr %p1, i64 120
  %v1.i = load i32, ptr %v0.i27, align 4
  %v3.i = icmp eq i32 %v1.i, 0
  br i1 %v3.i, label %b1.i, label %b2.i

b1.i:                                             ; preds = %b129
  %v4.i = getelementptr i8, ptr %p1, i64 124
  store i1 true, ptr %v4.i, align 1
  br label %liza___liza_json_mut_done.exit

b2.i:                                             ; preds = %b129
  %v10_pair.i = add i32 %v1.i, -1
  %v12_invalid.i = icmp ugt i32 %v10_pair.i, 63
  br i1 %v12_invalid.i, label %v12_trap.i, label %v12_ok.i

v12_trap.i:                                       ; preds = %b2.i
  tail call void @llvm.trap()
  unreachable

v12_ok.i:                                         ; preds = %b2.i
  %v11.i = getelementptr i8, ptr %p1, i64 56
  %v12_offset.i = zext nneg i32 %v10_pair.i to i64
  %v12.i = getelementptr [64 x i8], ptr %v11.i, i64 0, i64 %v12_offset.i
  %v13.i = load i8, ptr %v12.i, align 1
  switch i8 %v13.i, label %v28_ok.i [
    i8 1, label %v24_ok.i28
    i8 3, label %v24_ok.i28
  ]

v24_ok.i28:                                       ; preds = %v12_ok.i, %v12_ok.i
  store i8 2, ptr %v12.i, align 1
  br label %liza___liza_json_mut_done.exit

v28_ok.i:                                         ; preds = %v12_ok.i
  store i8 7, ptr %v12.i, align 1
  br label %liza___liza_json_mut_done.exit

liza___liza_json_mut_done.exit:                   ; preds = %b1.i, %v24_ok.i28, %v28_ok.i
  %v31.i = getelementptr i8, ptr %p1, i64 168
  %v32.i = load i32, ptr %v31.i, align 4
  br label %common.ret

b131:                                             ; preds = %v325_ok
  %v336 = getelementptr i8, ptr %p1, i64 168
  %v337 = load i32, ptr %v336, align 4
  br label %common.ret

b132:                                             ; preds = %b0
  %5 = add i32 %v1, -10
  %or.cond10 = icmp ult i32 %5, 8
  br i1 %or.cond10, label %b136, label %b216

b136:                                             ; preds = %b132
  %6 = add i8 %p0, -48
  %v5.i29 = icmp ult i8 %6, 10
  br i1 %v5.i29, label %b138, label %b158

b138:                                             ; preds = %b136
  switch i32 %v1, label %b151 [
    i32 11, label %b140
    i32 10, label %b143
    i32 13, label %b157.sink.split
  ]

b140:                                             ; preds = %b138
  %v354 = getelementptr i8, ptr %p1, i64 48
  %v355 = load i64, ptr %v354, align 8
  %v0.i30 = getelementptr i8, ptr %p1, i64 168
  store i32 2, ptr %v0.i30, align 4
  %v2.i31 = getelementptr i8, ptr %p1, i64 176
  store i64 %v355, ptr %v2.i31, align 8
  br label %common.ret

b143:                                             ; preds = %b138
  %v364 = icmp eq i8 %p0, 48
  %.79 = select i1 %v364, i32 11, i32 12
  br label %b157.sink.split

b151:                                             ; preds = %b138
  %v379.off = add nsw i32 %v1, -15
  %switch12 = icmp ult i32 %v379.off, 2
  br i1 %switch12, label %b157.sink.split, label %b157

b157.sink.split:                                  ; preds = %b151, %b138, %b143
  %.sink75 = phi i32 [ %.79, %b143 ], [ 14, %b138 ], [ 17, %b151 ]
  store i32 %.sink75, ptr %v0, align 4
  br label %b157

b157:                                             ; preds = %b157.sink.split, %b151
  %v391 = getelementptr i8, ptr %p1, i64 168
  %v392 = load i32, ptr %v391, align 4
  br label %common.ret

b158:                                             ; preds = %b136
  %v396 = icmp eq i32 %v1, 11
  br i1 %v396, label %b162, label %b159

b159:                                             ; preds = %b158
  %v401 = icmp eq i32 %v1, 12
  %v405 = icmp eq i8 %p0, 46
  %or.cond6 = select i1 %v401, i1 %v405, i1 false
  br i1 %or.cond6, label %b165, label %b167

b162:                                             ; preds = %b158
  switch i8 %p0, label %b210 [
    i8 46, label %b165
    i8 101, label %b180
    i8 69, label %b180
    i8 32, label %b215
    i8 10, label %b215
    i8 9, label %b215
    i8 13, label %b215
    i8 93, label %b215
    i8 44, label %b215
    i8 125, label %b215
  ]

b165:                                             ; preds = %b162, %b159
  store i32 13, ptr %v0, align 4
  %v410 = getelementptr i8, ptr %p1, i64 168
  %v411 = load i32, ptr %v410, align 4
  br label %common.ret

b167:                                             ; preds = %b159
  switch i32 %v1, label %b203 [
    i32 11, label %b174
    i32 12, label %b174
    i32 14, label %b174
    i32 15, label %b183
    i32 10, label %b201
    i32 13, label %b201
    i32 16, label %b201
  ]

b174:                                             ; preds = %b167, %b167, %b167
  switch i8 %p0, label %b191 [
    i8 101, label %b180
    i8 69, label %b180
  ]

b180:                                             ; preds = %b162, %b162, %b174, %b174
  store i32 15, ptr %v0, align 4
  %v439 = getelementptr i8, ptr %p1, i64 168
  %v440 = load i32, ptr %v439, align 4
  br label %common.ret

b183:                                             ; preds = %b167
  switch i8 %p0, label %b201 [
    i8 45, label %b189
    i8 43, label %b189
  ]

b189:                                             ; preds = %b183, %b183
  store i32 16, ptr %v0, align 4
  %v456 = getelementptr i8, ptr %p1, i64 168
  %v457 = load i32, ptr %v456, align 4
  br label %common.ret

b191:                                             ; preds = %b174
  %cond = icmp eq i32 %v1, 13
  br i1 %cond, label %b201, label %b203

b201:                                             ; preds = %b191, %b167, %b167, %b167, %b183
  %v481 = getelementptr i8, ptr %p1, i64 48
  %v482 = load i64, ptr %v481, align 8
  %v0.i32 = getelementptr i8, ptr %p1, i64 168
  store i32 2, ptr %v0.i32, align 4
  %v2.i33 = getelementptr i8, ptr %p1, i64 176
  store i64 %v482, ptr %v2.i33, align 8
  br label %common.ret

b203:                                             ; preds = %b191, %b167
  switch i8 %p0, label %b210 [
    i8 32, label %b215
    i8 10, label %b215
    i8 9, label %b215
    i8 13, label %b215
    i8 93, label %b215
    i8 44, label %b215
    i8 125, label %b215
  ]

b210:                                             ; preds = %b162, %b203
  %v501 = getelementptr i8, ptr %p1, i64 48
  %v502 = load i64, ptr %v501, align 8
  %v0.i35 = getelementptr i8, ptr %p1, i64 168
  store i32 2, ptr %v0.i35, align 4
  %v2.i36 = getelementptr i8, ptr %p1, i64 176
  store i64 %v502, ptr %v2.i36, align 8
  br label %common.ret

b215:                                             ; preds = %b162, %b162, %b162, %b162, %b162, %b162, %b162, %b203, %b203, %b203, %b203, %b203, %b203, %b203
  store i32 0, ptr %v0, align 4
  %v510 = tail call i32 @liza___liza_json_mut_done(ptr nonnull %p1)
  br label %b216

b216:                                             ; preds = %b132, %b215
  switch i8 %p0, label %b219 [
    i8 32, label %b217
    i8 10, label %b217
    i8 9, label %b217
    i8 13, label %b217
  ]

b217:                                             ; preds = %b216, %b216, %b216, %b216
  %v513 = getelementptr i8, ptr %p1, i64 168
  %v514 = load i32, ptr %v513, align 4
  br label %common.ret

b219:                                             ; preds = %b216
  %v516 = getelementptr i8, ptr %p1, i64 120
  %v517 = load i32, ptr %v516, align 4
  %v519.not = icmp eq i32 %v517, 0
  br i1 %v519.not, label %b222, label %b220

b220:                                             ; preds = %b219
  %v524_pair = add i32 %v517, -1
  %v525_invalid = icmp ugt i32 %v524_pair, 63
  br i1 %v525_invalid, label %v525_trap, label %v525_ok

v525_trap:                                        ; preds = %b220
  tail call void @llvm.trap()
  unreachable

v525_ok:                                          ; preds = %b220
  %v520 = getelementptr i8, ptr %p1, i64 56
  %v525_offset = zext nneg i32 %v524_pair to i64
  %v525 = getelementptr [64 x i8], ptr %v520, i64 0, i64 %v525_offset
  %v526 = load i8, ptr %v525, align 1
  br label %b222

b222:                                             ; preds = %b219, %v525_ok
  %v527 = phi i8 [ %v526, %v525_ok ], [ 0, %b219 ]
  switch i8 %p0, label %b240 [
    i8 93, label %b223
    i8 125, label %b232
  ]

b223:                                             ; preds = %b222
  %v527.off = add i8 %v527, -1
  %switch = icmp ult i8 %v527.off, 2
  br i1 %switch, label %b229, label %b240

b229:                                             ; preds = %b223
  %v542_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v542_overflow = extractvalue { i32, i1 } %v542_pair, 1
  br i1 %v542_overflow, label %v542_trap, label %v542_ok

v542_trap:                                        ; preds = %b229
  tail call void @llvm.trap()
  unreachable

v542_ok:                                          ; preds = %b229
  %v542 = extractvalue { i32, i1 } %v542_pair, 0
  store i32 %v542, ptr %v516, align 4
  %v544 = getelementptr i8, ptr %p1, i64 168
  %v545 = load i32, ptr %v544, align 4
  br label %common.ret

b232:                                             ; preds = %b222
  switch i8 %v527, label %b259 [
    i8 7, label %b238
    i8 4, label %b238
    i8 2, label %b246
    i8 5, label %b255
    i8 8, label %b264
  ]

b238:                                             ; preds = %b232, %b232
  %v560_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v560_overflow = extractvalue { i32, i1 } %v560_pair, 1
  br i1 %v560_overflow, label %v560_trap, label %v560_ok

v560_trap:                                        ; preds = %b238
  tail call void @llvm.trap()
  unreachable

v560_ok:                                          ; preds = %b238
  %v560 = extractvalue { i32, i1 } %v560_pair, 0
  store i32 %v560, ptr %v516, align 4
  %v562 = getelementptr i8, ptr %p1, i64 168
  %v563 = load i32, ptr %v562, align 4
  br label %common.ret

b240:                                             ; preds = %b223, %b222
  switch i8 %v527, label %b259 [
    i8 7, label %b244
    i8 2, label %b244
    i8 5, label %b253
    i8 4, label %b262
    i8 8, label %b262
  ]

b244:                                             ; preds = %b240, %b240
  %v571.not = icmp eq i8 %p0, 44
  br i1 %v571.not, label %b248, label %b246

b246:                                             ; preds = %b232, %b244
  %v573 = getelementptr i8, ptr %p1, i64 48
  %v574 = load i64, ptr %v573, align 8
  %v0.i40 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i40, align 4
  %v2.i41 = getelementptr i8, ptr %p1, i64 176
  store i64 %v574, ptr %v2.i41, align 8
  br label %common.ret

b248:                                             ; preds = %b244
  %v579 = icmp eq i8 %v527, 2
  %v580 = getelementptr i8, ptr %p1, i64 56
  %v584_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v584 = extractvalue { i32, i1 } %v584_pair, 0
  %v584_overflow = extractvalue { i32, i1 } %v584_pair, 1
  br i1 %v579, label %b249, label %b250

b249:                                             ; preds = %b248
  br i1 %v584_overflow, label %v584_trap, label %v584_ok

v584_trap:                                        ; preds = %b249
  tail call void @llvm.trap()
  unreachable

v584_ok:                                          ; preds = %b249
  %v585_invalid = icmp ugt i32 %v584, 63
  br i1 %v585_invalid, label %v585_trap, label %b251

v585_trap:                                        ; preds = %v584_ok
  tail call void @llvm.trap()
  unreachable

b250:                                             ; preds = %b248
  br i1 %v584_overflow, label %v592_trap, label %v592_ok

v592_trap:                                        ; preds = %b250
  tail call void @llvm.trap()
  unreachable

v592_ok:                                          ; preds = %b250
  %v593_invalid = icmp ugt i32 %v584, 63
  br i1 %v593_invalid, label %v593_trap, label %b251

v593_trap:                                        ; preds = %v592_ok
  tail call void @llvm.trap()
  unreachable

b251:                                             ; preds = %v592_ok, %v584_ok
  %.sink76 = phi i8 [ 3, %v584_ok ], [ 8, %v592_ok ]
  %v593_offset = zext nneg i32 %v584 to i64
  %v593 = getelementptr [64 x i8], ptr %v580, i64 0, i64 %v593_offset
  store i8 %.sink76, ptr %v593, align 1
  %v596 = getelementptr i8, ptr %p1, i64 168
  %v597 = load i32, ptr %v596, align 4
  br label %common.ret

b253:                                             ; preds = %b240
  %v601.not = icmp eq i8 %p0, 58
  br i1 %v601.not, label %b257, label %b255

b255:                                             ; preds = %b232, %b253
  %v603 = getelementptr i8, ptr %p1, i64 48
  %v604 = load i64, ptr %v603, align 8
  %v0.i42 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i42, align 4
  %v2.i43 = getelementptr i8, ptr %p1, i64 176
  store i64 %v604, ptr %v2.i43, align 8
  br label %common.ret

b257:                                             ; preds = %b253
  %v608 = getelementptr i8, ptr %p1, i64 56
  %v612_pair = tail call { i32, i1 } @llvm.usub.with.overflow.i32(i32 %v517, i32 1)
  %v612 = extractvalue { i32, i1 } %v612_pair, 0
  %v612_overflow = extractvalue { i32, i1 } %v612_pair, 1
  br i1 %v612_overflow, label %v612_trap, label %v612_ok

v612_trap:                                        ; preds = %b257
  tail call void @llvm.trap()
  unreachable

v612_ok:                                          ; preds = %b257
  %v613_invalid = icmp ugt i32 %v612, 63
  br i1 %v613_invalid, label %v613_trap, label %v613_ok

v613_trap:                                        ; preds = %v612_ok
  tail call void @llvm.trap()
  unreachable

v613_ok:                                          ; preds = %v612_ok
  %v613_offset = zext nneg i32 %v612 to i64
  %v613 = getelementptr [64 x i8], ptr %v608, i64 0, i64 %v613_offset
  store i8 6, ptr %v613, align 1
  %v616 = getelementptr i8, ptr %p1, i64 168
  %v617 = load i32, ptr %v616, align 4
  br label %common.ret

b259:                                             ; preds = %b232, %b240
  br i1 %v519.not, label %b268, label %b273

b262:                                             ; preds = %b240, %b240
  %v625.not = icmp eq i8 %p0, 34
  br i1 %v625.not, label %b266, label %b264

b264:                                             ; preds = %b232, %b262
  %v627 = getelementptr i8, ptr %p1, i64 48
  %v628 = load i64, ptr %v627, align 8
  %v0.i44 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i44, align 4
  %v2.i45 = getelementptr i8, ptr %p1, i64 176
  store i64 %v628, ptr %v2.i45, align 8
  br label %common.ret

b266:                                             ; preds = %b262
  %v632 = getelementptr i8, ptr %p1, i64 132
  store i1 true, ptr %v632, align 1
  store i32 1, ptr %v0, align 4
  %v638 = getelementptr i8, ptr %p1, i64 168
  %v639 = load i32, ptr %v638, align 4
  br label %common.ret

b268:                                             ; preds = %b259
  %v645 = getelementptr i8, ptr %p1, i64 124
  %v646 = load i1, ptr %v645, align 1
  br i1 %v646, label %b271, label %b273

b271:                                             ; preds = %b268
  %v649 = getelementptr i8, ptr %p1, i64 48
  %v650 = load i64, ptr %v649, align 8
  %v0.i46 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i46, align 4
  %v2.i47 = getelementptr i8, ptr %p1, i64 176
  store i64 %v650, ptr %v2.i47, align 8
  br label %common.ret

b273:                                             ; preds = %b268, %b259
  switch i8 %p0, label %b291 [
    i8 123, label %b277
    i8 91, label %b277
    i8 34, label %b286
    i8 45, label %b289
  ]

b277:                                             ; preds = %b273, %b273
  %v663 = icmp eq i32 %v517, 64
  br i1 %v663, label %b279, label %b281

b279:                                             ; preds = %b277
  %v665 = getelementptr i8, ptr %p1, i64 48
  %v666 = load i64, ptr %v665, align 8
  %v0.i48 = getelementptr i8, ptr %p1, i64 168
  store i32 7, ptr %v0.i48, align 4
  %v2.i49 = getelementptr i8, ptr %p1, i64 176
  store i64 %v666, ptr %v2.i49, align 8
  br label %common.ret

b281:                                             ; preds = %b277
  %v671 = tail call i32 @liza___liza_json_mut_done(ptr nonnull %p1)
  %v674 = icmp eq i8 %p0, 91
  %v677 = load i32, ptr %v516, align 4
  %v678_invalid = icmp ugt i32 %v677, 63
  br i1 %v674, label %b282, label %b283

b282:                                             ; preds = %b281
  br i1 %v678_invalid, label %v678_trap, label %b284

v678_trap:                                        ; preds = %b282
  tail call void @llvm.trap()
  unreachable

b283:                                             ; preds = %b281
  br i1 %v678_invalid, label %v684_trap, label %b284

v684_trap:                                        ; preds = %b283
  tail call void @llvm.trap()
  unreachable

b284:                                             ; preds = %b283, %b282
  %.sink77 = phi i8 [ 1, %b282 ], [ 4, %b283 ]
  %v681 = getelementptr i8, ptr %p1, i64 56
  %v684_offset = zext nneg i32 %v677 to i64
  %v684 = getelementptr [64 x i8], ptr %v681, i64 0, i64 %v684_offset
  store i8 %.sink77, ptr %v684, align 1
  %v689 = load i32, ptr %v516, align 4
  %v691_pair = tail call { i32, i1 } @llvm.uadd.with.overflow.i32(i32 %v689, i32 1)
  %v691_overflow = extractvalue { i32, i1 } %v691_pair, 1
  br i1 %v691_overflow, label %v691_trap, label %v691_ok

v691_trap:                                        ; preds = %b284
  tail call void @llvm.trap()
  unreachable

v691_ok:                                          ; preds = %b284
  %v691 = extractvalue { i32, i1 } %v691_pair, 0
  store i32 %v691, ptr %v516, align 4
  %v693 = getelementptr i8, ptr %p1, i64 168
  %v694 = load i32, ptr %v693, align 4
  br label %common.ret

b286:                                             ; preds = %b273
  %v697 = getelementptr i8, ptr %p1, i64 132
  store i1 false, ptr %v697, align 1
  store i32 1, ptr %v0, align 4
  %v703 = getelementptr i8, ptr %p1, i64 168
  %v704 = load i32, ptr %v703, align 4
  br label %common.ret

b289:                                             ; preds = %b273
  store i32 10, ptr %v0, align 4
  %v710 = getelementptr i8, ptr %p1, i64 168
  %v711 = load i32, ptr %v710, align 4
  br label %common.ret

b291:                                             ; preds = %b273
  %7 = add i8 %p0, -48
  %v5.i50 = icmp ult i8 %7, 10
  br i1 %v5.i50, label %b292, label %b297

b292:                                             ; preds = %b291
  %v714 = icmp eq i8 %p0, 48
  %.11 = select i1 %v714, i32 11, i32 12
  store i32 %.11, ptr %v0, align 4
  %v721 = getelementptr i8, ptr %p1, i64 168
  %v722 = load i32, ptr %v721, align 4
  br label %common.ret

b297:                                             ; preds = %b291
  switch i8 %p0, label %b312 [
    i8 116, label %b304
    i8 102, label %b304
    i8 110, label %b304
  ]

b304:                                             ; preds = %b297, %b297, %b297
  store i32 20, ptr %v0, align 4
  %v736 = getelementptr i8, ptr %p1, i64 140
  store i32 1, ptr %v736, align 4
  %v749 = getelementptr i8, ptr %p1, i64 136
  %switch.selectcmp = icmp eq i8 %p0, 102
  %switch.select = select i1 %switch.selectcmp, i32 2, i32 3
  %switch.selectcmp80 = icmp eq i8 %p0, 116
  %switch.select81 = select i1 %switch.selectcmp80, i32 1, i32 %switch.select
  store i32 %switch.select81, ptr %v749, align 4
  %v752 = getelementptr i8, ptr %p1, i64 168
  %v753 = load i32, ptr %v752, align 4
  br label %common.ret

b312:                                             ; preds = %b297
  %v755 = getelementptr i8, ptr %p1, i64 48
  %v756 = load i64, ptr %v755, align 8
  %v0.i51 = getelementptr i8, ptr %p1, i64 168
  store i32 1, ptr %v0.i51, align 4
  %v2.i52 = getelementptr i8, ptr %p1, i64 176
  store i64 %v756, ptr %v2.i52, align 8
  br label %common.ret
}

; Function Attrs: nounwind memory(read, argmem: readwrite, inaccessiblemem: write)
define i32 @liza_json.feed_mut(ptr %p0, { ptr, i32 } %p1) local_unnamed_addr #5 {
b0:
  %v0 = getelementptr i8, ptr %p0, i64 168
  %v1 = load i32, ptr %v0, align 4
  %v3.not = icmp eq i32 %v1, 0
  br i1 %v3.not, label %b4.preheader, label %common.ret

b4.preheader:                                     ; preds = %b0
  %v8 = extractvalue { ptr, i32 } %p1, 1
  %v99.not = icmp eq i32 %v8, 0
  br i1 %v99.not, label %common.ret, label %v10_ok.lr.ph

v10_ok.lr.ph:                                     ; preds = %b4.preheader
  %v10_base = extractvalue { ptr, i32 } %p1, 0
  %v42 = getelementptr i8, ptr %p0, i64 48
  %wide.trip.count = zext i32 %v8 to i64
  br label %v10_ok

common.ret:                                       ; preds = %v46_ok, %b13, %b9, %b4.preheader, %b0
  %common.ret.op = phi i32 [ %v1, %b0 ], [ 0, %b4.preheader ], [ %., %b9 ], [ 0, %v46_ok ], [ %v37, %b13 ]
  ret i32 %common.ret.op

v10_ok:                                           ; preds = %v10_ok.lr.ph, %v46_ok
  %indvars.iv = phi i64 [ 0, %v10_ok.lr.ph ], [ %indvars.iv.next, %v46_ok ]
  %v10_ptr = getelementptr i8, ptr %v10_base, i64 %indvars.iv
  %v10 = load i8, ptr %v10_ptr, align 1
  %v13 = load %struct.Utf8StreamState, ptr %p0, align 8
  %v14 = tail call %struct.Utf8StreamState @liza_utf8_stream.feed_byte(%struct.Utf8StreamState %v13, i8 %v10)
  store %struct.Utf8StreamState %v14, ptr %p0, align 8
  %v0.i = extractvalue %struct.Utf8StreamState %v14, 6
  switch i32 %v0.i, label %liza_utf8_stream.status.exit [
    i32 1, label %b1.i
    i32 2, label %b4.i
  ]

b1.i:                                             ; preds = %v10_ok
  %v4.i = extractvalue %struct.Utf8StreamState %v14, 7
  %v5.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i, 1
  %v6.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5.i, 1
  br label %liza_utf8_stream.status.exit

b4.i:                                             ; preds = %v10_ok
  %v11.i = extractvalue %struct.Utf8StreamState %v14, 7
  %v12.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i, 1
  %v13.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12.i, 1
  br label %liza_utf8_stream.status.exit

liza_utf8_stream.status.exit:                     ; preds = %v10_ok, %b1.i, %b4.i
  %common.ret.op.i = phi %variant.3 [ %v6.i, %b1.i ], [ %v13.i, %b4.i ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %v10_ok ]
  %v19 = extractvalue %variant.3 %common.ret.op.i, 0
  %switch = icmp eq i32 %v19, 1
  br i1 %switch, label %b13, label %b9

b9:                                               ; preds = %liza_utf8_stream.status.exit
  %v20 = extractvalue %variant.3 %common.ret.op.i, 1
  %v21 = extractvalue %struct.Utf8StreamError %v20, 0
  %v22 = extractvalue %variant.0 %v21, 0
  %switch1 = icmp eq i32 %v22, 0
  %. = select i1 %switch1, i32 5, i32 8
  %v29 = extractvalue %struct.Utf8StreamError %v20, 1
  store i32 %., ptr %v0, align 4
  %v2.i4 = getelementptr i8, ptr %p0, i64 176
  store i64 %v29, ptr %v2.i4, align 8
  br label %common.ret

b13:                                              ; preds = %liza_utf8_stream.status.exit
  %v34 = tail call i32 @liza___liza_json_mut_step(i8 %v10, ptr nonnull %p0)
  %v37 = load i32, ptr %v0, align 4
  %v39.not = icmp eq i32 %v37, 0
  br i1 %v39.not, label %b16, label %common.ret

b16:                                              ; preds = %b13
  %v44 = load i64, ptr %v42, align 8
  %v46_pair = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v44, i64 1)
  %v46_overflow = extractvalue { i64, i1 } %v46_pair, 1
  br i1 %v46_overflow, label %v46_trap, label %v46_ok

v46_trap:                                         ; preds = %b16
  tail call void @llvm.trap()
  unreachable

v46_ok:                                           ; preds = %b16
  %v46 = extractvalue { i64, i1 } %v46_pair, 0
  store i64 %v46, ptr %v42, align 8
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %wide.trip.count
  br i1 %exitcond.not, label %common.ret, label %v10_ok
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define void @liza___liza_owned___liza_json_done(ptr sret(%struct.JsonState) %return_storage, ptr readnone captures(none) %p0) local_unnamed_addr #2 {
b0:
  %v22_scratch = alloca [64 x i8], align 16
  %v27_scratch = alloca [64 x i8], align 16
  %v14_storage = alloca [64 x i8], align 1
  %v9_storage = alloca [64 x i8], align 1
  %v0_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 120
  %v0 = load i32, ptr %v0_ptr, align 8
  %v2 = icmp eq i32 %v0, 0
  br i1 %v2, label %b1, label %b2

b1:                                               ; preds = %b0
  %v3_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 124
  store i1 true, ptr %v3_ptr, align 4
  br label %b9

b2:                                               ; preds = %b0
  %v8_pair = add i32 %v0, -1
  %v9_ptr = getelementptr inbounds nuw i8, ptr %return_storage, i64 56
  %v9.unpack = load i8, ptr %v9_ptr, align 8
  %v9.elt257 = getelementptr inbounds nuw i8, ptr %return_storage, i64 57
  %v9.unpack258 = load i8, ptr %v9.elt257, align 1
  %v9.elt259 = getelementptr inbounds nuw i8, ptr %return_storage, i64 58
  %v9.unpack260 = load i8, ptr %v9.elt259, align 2
  %v9.elt261 = getelementptr inbounds nuw i8, ptr %return_storage, i64 59
  %v9.unpack262 = load i8, ptr %v9.elt261, align 1
  %v9.elt263 = getelementptr inbounds nuw i8, ptr %return_storage, i64 60
  %v9.unpack264 = load i8, ptr %v9.elt263, align 4
  %v9.elt265 = getelementptr inbounds nuw i8, ptr %return_storage, i64 61
  %v9.unpack266 = load i8, ptr %v9.elt265, align 1
  %v9.elt267 = getelementptr inbounds nuw i8, ptr %return_storage, i64 62
  %v9.unpack268 = load i8, ptr %v9.elt267, align 2
  %v9.elt269 = getelementptr inbounds nuw i8, ptr %return_storage, i64 63
  %v9.unpack270 = load i8, ptr %v9.elt269, align 1
  %v9.elt271 = getelementptr inbounds nuw i8, ptr %return_storage, i64 64
  %v9.unpack272 = load i8, ptr %v9.elt271, align 8
  %v9.elt273 = getelementptr inbounds nuw i8, ptr %return_storage, i64 65
  %v9.unpack274 = load i8, ptr %v9.elt273, align 1
  %v9.elt275 = getelementptr inbounds nuw i8, ptr %return_storage, i64 66
  %v9.unpack276 = load i8, ptr %v9.elt275, align 2
  %v9.elt277 = getelementptr inbounds nuw i8, ptr %return_storage, i64 67
  %v9.unpack278 = load i8, ptr %v9.elt277, align 1
  %v9.elt279 = getelementptr inbounds nuw i8, ptr %return_storage, i64 68
  %v9.unpack280 = load i8, ptr %v9.elt279, align 4
  %v9.elt281 = getelementptr inbounds nuw i8, ptr %return_storage, i64 69
  %v9.unpack282 = load i8, ptr %v9.elt281, align 1
  %v9.elt283 = getelementptr inbounds nuw i8, ptr %return_storage, i64 70
  %v9.unpack284 = load i8, ptr %v9.elt283, align 2
  %v9.elt285 = getelementptr inbounds nuw i8, ptr %return_storage, i64 71
  %v9.unpack286 = load i8, ptr %v9.elt285, align 1
  %v9.elt287 = getelementptr inbounds nuw i8, ptr %return_storage, i64 72
  %v9.unpack288 = load i8, ptr %v9.elt287, align 8
  %v9.elt289 = getelementptr inbounds nuw i8, ptr %return_storage, i64 73
  %v9.unpack290 = load i8, ptr %v9.elt289, align 1
  %v9.elt291 = getelementptr inbounds nuw i8, ptr %return_storage, i64 74
  %v9.unpack292 = load i8, ptr %v9.elt291, align 2
  %v9.elt293 = getelementptr inbounds nuw i8, ptr %return_storage, i64 75
  %v9.unpack294 = load i8, ptr %v9.elt293, align 1
  %v9.elt295 = getelementptr inbounds nuw i8, ptr %return_storage, i64 76
  %v9.unpack296 = load i8, ptr %v9.elt295, align 4
  %v9.elt297 = getelementptr inbounds nuw i8, ptr %return_storage, i64 77
  %v9.unpack298 = load i8, ptr %v9.elt297, align 1
  %v9.elt299 = getelementptr inbounds nuw i8, ptr %return_storage, i64 78
  %v9.unpack300 = load i8, ptr %v9.elt299, align 2
  %v9.elt301 = getelementptr inbounds nuw i8, ptr %return_storage, i64 79
  %v9.unpack302 = load i8, ptr %v9.elt301, align 1
  %v9.elt303 = getelementptr inbounds nuw i8, ptr %return_storage, i64 80
  %v9.unpack304 = load i8, ptr %v9.elt303, align 8
  %v9.elt305 = getelementptr inbounds nuw i8, ptr %return_storage, i64 81
  %v9.unpack306 = load i8, ptr %v9.elt305, align 1
  %v9.elt307 = getelementptr inbounds nuw i8, ptr %return_storage, i64 82
  %v9.unpack308 = load i8, ptr %v9.elt307, align 2
  %v9.elt309 = getelementptr inbounds nuw i8, ptr %return_storage, i64 83
  %v9.unpack310 = load i8, ptr %v9.elt309, align 1
  %v9.elt311 = getelementptr inbounds nuw i8, ptr %return_storage, i64 84
  %v9.unpack312 = load i8, ptr %v9.elt311, align 4
  %v9.elt313 = getelementptr inbounds nuw i8, ptr %return_storage, i64 85
  %v9.unpack314 = load i8, ptr %v9.elt313, align 1
  %v9.elt315 = getelementptr inbounds nuw i8, ptr %return_storage, i64 86
  %v9.unpack316 = load i8, ptr %v9.elt315, align 2
  %v9.elt317 = getelementptr inbounds nuw i8, ptr %return_storage, i64 87
  %v9.unpack318 = load i8, ptr %v9.elt317, align 1
  %v9.elt319 = getelementptr inbounds nuw i8, ptr %return_storage, i64 88
  %v9.unpack320 = load i8, ptr %v9.elt319, align 8
  %v9.elt321 = getelementptr inbounds nuw i8, ptr %return_storage, i64 89
  %v9.unpack322 = load i8, ptr %v9.elt321, align 1
  %v9.elt323 = getelementptr inbounds nuw i8, ptr %return_storage, i64 90
  %v9.unpack324 = load i8, ptr %v9.elt323, align 2
  %v9.elt325 = getelementptr inbounds nuw i8, ptr %return_storage, i64 91
  %v9.unpack326 = load i8, ptr %v9.elt325, align 1
  %v9.elt327 = getelementptr inbounds nuw i8, ptr %return_storage, i64 92
  %v9.unpack328 = load i8, ptr %v9.elt327, align 4
  %v9.elt329 = getelementptr inbounds nuw i8, ptr %return_storage, i64 93
  %v9.unpack330 = load i8, ptr %v9.elt329, align 1
  %v9.elt331 = getelementptr inbounds nuw i8, ptr %return_storage, i64 94
  %v9.unpack332 = load i8, ptr %v9.elt331, align 2
  %v9.elt333 = getelementptr inbounds nuw i8, ptr %return_storage, i64 95
  %v9.unpack334 = load i8, ptr %v9.elt333, align 1
  %v9.elt335 = getelementptr inbounds nuw i8, ptr %return_storage, i64 96
  %v9.unpack336 = load i8, ptr %v9.elt335, align 8
  %v9.elt337 = getelementptr inbounds nuw i8, ptr %return_storage, i64 97
  %v9.unpack338 = load i8, ptr %v9.elt337, align 1
  %v9.elt339 = getelementptr inbounds nuw i8, ptr %return_storage, i64 98
  %v9.unpack340 = load i8, ptr %v9.elt339, align 2
  %v9.elt341 = getelementptr inbounds nuw i8, ptr %return_storage, i64 99
  %v9.unpack342 = load i8, ptr %v9.elt341, align 1
  %v9.elt343 = getelementptr inbounds nuw i8, ptr %return_storage, i64 100
  %v9.unpack344 = load i8, ptr %v9.elt343, align 4
  %v9.elt345 = getelementptr inbounds nuw i8, ptr %return_storage, i64 101
  %v9.unpack346 = load i8, ptr %v9.elt345, align 1
  %v9.elt347 = getelementptr inbounds nuw i8, ptr %return_storage, i64 102
  %v9.unpack348 = load i8, ptr %v9.elt347, align 2
  %v9.elt349 = getelementptr inbounds nuw i8, ptr %return_storage, i64 103
  %v9.unpack350 = load i8, ptr %v9.elt349, align 1
  %v9.elt351 = getelementptr inbounds nuw i8, ptr %return_storage, i64 104
  %v9.unpack352 = load i8, ptr %v9.elt351, align 8
  %v9.elt353 = getelementptr inbounds nuw i8, ptr %return_storage, i64 105
  %v9.unpack354 = load i8, ptr %v9.elt353, align 1
  %v9.elt355 = getelementptr inbounds nuw i8, ptr %return_storage, i64 106
  %v9.unpack356 = load i8, ptr %v9.elt355, align 2
  %v9.elt357 = getelementptr inbounds nuw i8, ptr %return_storage, i64 107
  %v9.unpack358 = load i8, ptr %v9.elt357, align 1
  %v9.elt359 = getelementptr inbounds nuw i8, ptr %return_storage, i64 108
  %v9.unpack360 = load i8, ptr %v9.elt359, align 4
  %v9.elt361 = getelementptr inbounds nuw i8, ptr %return_storage, i64 109
  %v9.unpack362 = load i8, ptr %v9.elt361, align 1
  %v9.elt363 = getelementptr inbounds nuw i8, ptr %return_storage, i64 110
  %v9.unpack364 = load i8, ptr %v9.elt363, align 2
  %v9.elt365 = getelementptr inbounds nuw i8, ptr %return_storage, i64 111
  %v9.unpack366 = load i8, ptr %v9.elt365, align 1
  %v9.elt367 = getelementptr inbounds nuw i8, ptr %return_storage, i64 112
  %v9.unpack368 = load i8, ptr %v9.elt367, align 8
  %v9.elt369 = getelementptr inbounds nuw i8, ptr %return_storage, i64 113
  %v9.unpack370 = load i8, ptr %v9.elt369, align 1
  %v9.elt371 = getelementptr inbounds nuw i8, ptr %return_storage, i64 114
  %v9.unpack372 = load i8, ptr %v9.elt371, align 2
  %v9.elt373 = getelementptr inbounds nuw i8, ptr %return_storage, i64 115
  %v9.unpack374 = load i8, ptr %v9.elt373, align 1
  %v9.elt375 = getelementptr inbounds nuw i8, ptr %return_storage, i64 116
  %v9.unpack376 = load i8, ptr %v9.elt375, align 4
  %v9.elt377 = getelementptr inbounds nuw i8, ptr %return_storage, i64 117
  %v9.unpack378 = load i8, ptr %v9.elt377, align 1
  %v9.elt379 = getelementptr inbounds nuw i8, ptr %return_storage, i64 118
  %v9.unpack380 = load i8, ptr %v9.elt379, align 2
  %v9.elt381 = getelementptr inbounds nuw i8, ptr %return_storage, i64 119
  %v9.unpack382 = load i8, ptr %v9.elt381, align 1
  store i8 %v9.unpack, ptr %v9_storage, align 1
  %v9.fca.1.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 1
  store i8 %v9.unpack258, ptr %v9.fca.1.gep, align 1
  %v9.fca.2.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 2
  store i8 %v9.unpack260, ptr %v9.fca.2.gep, align 1
  %v9.fca.3.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 3
  store i8 %v9.unpack262, ptr %v9.fca.3.gep, align 1
  %v9.fca.4.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 4
  store i8 %v9.unpack264, ptr %v9.fca.4.gep, align 1
  %v9.fca.5.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 5
  store i8 %v9.unpack266, ptr %v9.fca.5.gep, align 1
  %v9.fca.6.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 6
  store i8 %v9.unpack268, ptr %v9.fca.6.gep, align 1
  %v9.fca.7.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 7
  store i8 %v9.unpack270, ptr %v9.fca.7.gep, align 1
  %v9.fca.8.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 8
  store i8 %v9.unpack272, ptr %v9.fca.8.gep, align 1
  %v9.fca.9.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 9
  store i8 %v9.unpack274, ptr %v9.fca.9.gep, align 1
  %v9.fca.10.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 10
  store i8 %v9.unpack276, ptr %v9.fca.10.gep, align 1
  %v9.fca.11.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 11
  store i8 %v9.unpack278, ptr %v9.fca.11.gep, align 1
  %v9.fca.12.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 12
  store i8 %v9.unpack280, ptr %v9.fca.12.gep, align 1
  %v9.fca.13.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 13
  store i8 %v9.unpack282, ptr %v9.fca.13.gep, align 1
  %v9.fca.14.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 14
  store i8 %v9.unpack284, ptr %v9.fca.14.gep, align 1
  %v9.fca.15.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 15
  store i8 %v9.unpack286, ptr %v9.fca.15.gep, align 1
  %v9.fca.16.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 16
  store i8 %v9.unpack288, ptr %v9.fca.16.gep, align 1
  %v9.fca.17.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 17
  store i8 %v9.unpack290, ptr %v9.fca.17.gep, align 1
  %v9.fca.18.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 18
  store i8 %v9.unpack292, ptr %v9.fca.18.gep, align 1
  %v9.fca.19.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 19
  store i8 %v9.unpack294, ptr %v9.fca.19.gep, align 1
  %v9.fca.20.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 20
  store i8 %v9.unpack296, ptr %v9.fca.20.gep, align 1
  %v9.fca.21.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 21
  store i8 %v9.unpack298, ptr %v9.fca.21.gep, align 1
  %v9.fca.22.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 22
  store i8 %v9.unpack300, ptr %v9.fca.22.gep, align 1
  %v9.fca.23.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 23
  store i8 %v9.unpack302, ptr %v9.fca.23.gep, align 1
  %v9.fca.24.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 24
  store i8 %v9.unpack304, ptr %v9.fca.24.gep, align 1
  %v9.fca.25.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 25
  store i8 %v9.unpack306, ptr %v9.fca.25.gep, align 1
  %v9.fca.26.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 26
  store i8 %v9.unpack308, ptr %v9.fca.26.gep, align 1
  %v9.fca.27.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 27
  store i8 %v9.unpack310, ptr %v9.fca.27.gep, align 1
  %v9.fca.28.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 28
  store i8 %v9.unpack312, ptr %v9.fca.28.gep, align 1
  %v9.fca.29.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 29
  store i8 %v9.unpack314, ptr %v9.fca.29.gep, align 1
  %v9.fca.30.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 30
  store i8 %v9.unpack316, ptr %v9.fca.30.gep, align 1
  %v9.fca.31.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 31
  store i8 %v9.unpack318, ptr %v9.fca.31.gep, align 1
  %v9.fca.32.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 32
  store i8 %v9.unpack320, ptr %v9.fca.32.gep, align 1
  %v9.fca.33.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 33
  store i8 %v9.unpack322, ptr %v9.fca.33.gep, align 1
  %v9.fca.34.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 34
  store i8 %v9.unpack324, ptr %v9.fca.34.gep, align 1
  %v9.fca.35.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 35
  store i8 %v9.unpack326, ptr %v9.fca.35.gep, align 1
  %v9.fca.36.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 36
  store i8 %v9.unpack328, ptr %v9.fca.36.gep, align 1
  %v9.fca.37.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 37
  store i8 %v9.unpack330, ptr %v9.fca.37.gep, align 1
  %v9.fca.38.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 38
  store i8 %v9.unpack332, ptr %v9.fca.38.gep, align 1
  %v9.fca.39.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 39
  store i8 %v9.unpack334, ptr %v9.fca.39.gep, align 1
  %v9.fca.40.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 40
  store i8 %v9.unpack336, ptr %v9.fca.40.gep, align 1
  %v9.fca.41.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 41
  store i8 %v9.unpack338, ptr %v9.fca.41.gep, align 1
  %v9.fca.42.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 42
  store i8 %v9.unpack340, ptr %v9.fca.42.gep, align 1
  %v9.fca.43.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 43
  store i8 %v9.unpack342, ptr %v9.fca.43.gep, align 1
  %v9.fca.44.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 44
  store i8 %v9.unpack344, ptr %v9.fca.44.gep, align 1
  %v9.fca.45.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 45
  store i8 %v9.unpack346, ptr %v9.fca.45.gep, align 1
  %v9.fca.46.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 46
  store i8 %v9.unpack348, ptr %v9.fca.46.gep, align 1
  %v9.fca.47.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 47
  store i8 %v9.unpack350, ptr %v9.fca.47.gep, align 1
  %v9.fca.48.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 48
  store i8 %v9.unpack352, ptr %v9.fca.48.gep, align 1
  %v9.fca.49.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 49
  store i8 %v9.unpack354, ptr %v9.fca.49.gep, align 1
  %v9.fca.50.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 50
  store i8 %v9.unpack356, ptr %v9.fca.50.gep, align 1
  %v9.fca.51.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 51
  store i8 %v9.unpack358, ptr %v9.fca.51.gep, align 1
  %v9.fca.52.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 52
  store i8 %v9.unpack360, ptr %v9.fca.52.gep, align 1
  %v9.fca.53.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 53
  store i8 %v9.unpack362, ptr %v9.fca.53.gep, align 1
  %v9.fca.54.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 54
  store i8 %v9.unpack364, ptr %v9.fca.54.gep, align 1
  %v9.fca.55.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 55
  store i8 %v9.unpack366, ptr %v9.fca.55.gep, align 1
  %v9.fca.56.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 56
  store i8 %v9.unpack368, ptr %v9.fca.56.gep, align 1
  %v9.fca.57.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 57
  store i8 %v9.unpack370, ptr %v9.fca.57.gep, align 1
  %v9.fca.58.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 58
  store i8 %v9.unpack372, ptr %v9.fca.58.gep, align 1
  %v9.fca.59.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 59
  store i8 %v9.unpack374, ptr %v9.fca.59.gep, align 1
  %v9.fca.60.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 60
  store i8 %v9.unpack376, ptr %v9.fca.60.gep, align 1
  %v9.fca.61.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 61
  store i8 %v9.unpack378, ptr %v9.fca.61.gep, align 1
  %v9.fca.62.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 62
  store i8 %v9.unpack380, ptr %v9.fca.62.gep, align 1
  %v9.fca.63.gep = getelementptr inbounds nuw i8, ptr %v9_storage, i64 63
  store i8 %v9.unpack382, ptr %v9.fca.63.gep, align 1
  %v10_invalid = icmp ugt i32 %v8_pair, 63
  br i1 %v10_invalid, label %v10_trap, label %v10_ok

v10_trap:                                         ; preds = %b2
  tail call void @llvm.trap()
  unreachable

v10_ok:                                           ; preds = %b2
  %v10_offset = zext nneg i32 %v8_pair to i64
  %v10_ptr = getelementptr [64 x i8], ptr %v9_storage, i64 0, i64 %v10_offset
  %v10 = load i8, ptr %v10_ptr, align 1
  %v12 = icmp eq i8 %v10, 1
  br i1 %v12, label %v20_ok, label %b3

b3:                                               ; preds = %v10_ok
  store i8 %v9.unpack, ptr %v14_storage, align 1
  %v14.fca.1.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 1
  store i8 %v9.unpack258, ptr %v14.fca.1.gep, align 1
  %v14.fca.2.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 2
  store i8 %v9.unpack260, ptr %v14.fca.2.gep, align 1
  %v14.fca.3.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 3
  store i8 %v9.unpack262, ptr %v14.fca.3.gep, align 1
  %v14.fca.4.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 4
  store i8 %v9.unpack264, ptr %v14.fca.4.gep, align 1
  %v14.fca.5.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 5
  store i8 %v9.unpack266, ptr %v14.fca.5.gep, align 1
  %v14.fca.6.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 6
  store i8 %v9.unpack268, ptr %v14.fca.6.gep, align 1
  %v14.fca.7.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 7
  store i8 %v9.unpack270, ptr %v14.fca.7.gep, align 1
  %v14.fca.8.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 8
  store i8 %v9.unpack272, ptr %v14.fca.8.gep, align 1
  %v14.fca.9.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 9
  store i8 %v9.unpack274, ptr %v14.fca.9.gep, align 1
  %v14.fca.10.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 10
  store i8 %v9.unpack276, ptr %v14.fca.10.gep, align 1
  %v14.fca.11.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 11
  store i8 %v9.unpack278, ptr %v14.fca.11.gep, align 1
  %v14.fca.12.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 12
  store i8 %v9.unpack280, ptr %v14.fca.12.gep, align 1
  %v14.fca.13.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 13
  store i8 %v9.unpack282, ptr %v14.fca.13.gep, align 1
  %v14.fca.14.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 14
  store i8 %v9.unpack284, ptr %v14.fca.14.gep, align 1
  %v14.fca.15.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 15
  store i8 %v9.unpack286, ptr %v14.fca.15.gep, align 1
  %v14.fca.16.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 16
  store i8 %v9.unpack288, ptr %v14.fca.16.gep, align 1
  %v14.fca.17.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 17
  store i8 %v9.unpack290, ptr %v14.fca.17.gep, align 1
  %v14.fca.18.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 18
  store i8 %v9.unpack292, ptr %v14.fca.18.gep, align 1
  %v14.fca.19.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 19
  store i8 %v9.unpack294, ptr %v14.fca.19.gep, align 1
  %v14.fca.20.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 20
  store i8 %v9.unpack296, ptr %v14.fca.20.gep, align 1
  %v14.fca.21.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 21
  store i8 %v9.unpack298, ptr %v14.fca.21.gep, align 1
  %v14.fca.22.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 22
  store i8 %v9.unpack300, ptr %v14.fca.22.gep, align 1
  %v14.fca.23.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 23
  store i8 %v9.unpack302, ptr %v14.fca.23.gep, align 1
  %v14.fca.24.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 24
  store i8 %v9.unpack304, ptr %v14.fca.24.gep, align 1
  %v14.fca.25.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 25
  store i8 %v9.unpack306, ptr %v14.fca.25.gep, align 1
  %v14.fca.26.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 26
  store i8 %v9.unpack308, ptr %v14.fca.26.gep, align 1
  %v14.fca.27.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 27
  store i8 %v9.unpack310, ptr %v14.fca.27.gep, align 1
  %v14.fca.28.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 28
  store i8 %v9.unpack312, ptr %v14.fca.28.gep, align 1
  %v14.fca.29.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 29
  store i8 %v9.unpack314, ptr %v14.fca.29.gep, align 1
  %v14.fca.30.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 30
  store i8 %v9.unpack316, ptr %v14.fca.30.gep, align 1
  %v14.fca.31.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 31
  store i8 %v9.unpack318, ptr %v14.fca.31.gep, align 1
  %v14.fca.32.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 32
  store i8 %v9.unpack320, ptr %v14.fca.32.gep, align 1
  %v14.fca.33.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 33
  store i8 %v9.unpack322, ptr %v14.fca.33.gep, align 1
  %v14.fca.34.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 34
  store i8 %v9.unpack324, ptr %v14.fca.34.gep, align 1
  %v14.fca.35.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 35
  store i8 %v9.unpack326, ptr %v14.fca.35.gep, align 1
  %v14.fca.36.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 36
  store i8 %v9.unpack328, ptr %v14.fca.36.gep, align 1
  %v14.fca.37.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 37
  store i8 %v9.unpack330, ptr %v14.fca.37.gep, align 1
  %v14.fca.38.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 38
  store i8 %v9.unpack332, ptr %v14.fca.38.gep, align 1
  %v14.fca.39.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 39
  store i8 %v9.unpack334, ptr %v14.fca.39.gep, align 1
  %v14.fca.40.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 40
  store i8 %v9.unpack336, ptr %v14.fca.40.gep, align 1
  %v14.fca.41.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 41
  store i8 %v9.unpack338, ptr %v14.fca.41.gep, align 1
  %v14.fca.42.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 42
  store i8 %v9.unpack340, ptr %v14.fca.42.gep, align 1
  %v14.fca.43.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 43
  store i8 %v9.unpack342, ptr %v14.fca.43.gep, align 1
  %v14.fca.44.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 44
  store i8 %v9.unpack344, ptr %v14.fca.44.gep, align 1
  %v14.fca.45.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 45
  store i8 %v9.unpack346, ptr %v14.fca.45.gep, align 1
  %v14.fca.46.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 46
  store i8 %v9.unpack348, ptr %v14.fca.46.gep, align 1
  %v14.fca.47.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 47
  store i8 %v9.unpack350, ptr %v14.fca.47.gep, align 1
  %v14.fca.48.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 48
  store i8 %v9.unpack352, ptr %v14.fca.48.gep, align 1
  %v14.fca.49.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 49
  store i8 %v9.unpack354, ptr %v14.fca.49.gep, align 1
  %v14.fca.50.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 50
  store i8 %v9.unpack356, ptr %v14.fca.50.gep, align 1
  %v14.fca.51.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 51
  store i8 %v9.unpack358, ptr %v14.fca.51.gep, align 1
  %v14.fca.52.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 52
  store i8 %v9.unpack360, ptr %v14.fca.52.gep, align 1
  %v14.fca.53.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 53
  store i8 %v9.unpack362, ptr %v14.fca.53.gep, align 1
  %v14.fca.54.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 54
  store i8 %v9.unpack364, ptr %v14.fca.54.gep, align 1
  %v14.fca.55.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 55
  store i8 %v9.unpack366, ptr %v14.fca.55.gep, align 1
  %v14.fca.56.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 56
  store i8 %v9.unpack368, ptr %v14.fca.56.gep, align 1
  %v14.fca.57.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 57
  store i8 %v9.unpack370, ptr %v14.fca.57.gep, align 1
  %v14.fca.58.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 58
  store i8 %v9.unpack372, ptr %v14.fca.58.gep, align 1
  %v14.fca.59.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 59
  store i8 %v9.unpack374, ptr %v14.fca.59.gep, align 1
  %v14.fca.60.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 60
  store i8 %v9.unpack376, ptr %v14.fca.60.gep, align 1
  %v14.fca.61.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 61
  store i8 %v9.unpack378, ptr %v14.fca.61.gep, align 1
  %v14.fca.62.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 62
  store i8 %v9.unpack380, ptr %v14.fca.62.gep, align 1
  %v14.fca.63.gep = getelementptr inbounds nuw i8, ptr %v14_storage, i64 63
  store i8 %v9.unpack382, ptr %v14.fca.63.gep, align 1
  %v15_ptr = getelementptr [64 x i8], ptr %v14_storage, i64 0, i64 %v10_offset
  %v15 = load i8, ptr %v15_ptr, align 1
  %v17 = icmp eq i8 %v15, 3
  br i1 %v17, label %v20_ok, label %v25_ok

v20_ok:                                           ; preds = %b3, %v10_ok
  %0 = load <16 x i8>, ptr %v9_ptr, align 8
  store <16 x i8> %0, ptr %v22_scratch, align 16
  %v19.fca.16.gep162 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 16
  %1 = load <16 x i8>, ptr %v9.elt287, align 8
  store <16 x i8> %1, ptr %v19.fca.16.gep162, align 16
  %v19.fca.32.gep194 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 32
  %2 = load <16 x i8>, ptr %v9.elt319, align 8
  store <16 x i8> %2, ptr %v19.fca.32.gep194, align 16
  %v19.fca.48.gep226 = getelementptr inbounds nuw i8, ptr %v22_scratch, i64 48
  %3 = load <16 x i8>, ptr %v9.elt351, align 8
  store <16 x i8> %3, ptr %v19.fca.48.gep226, align 16
  %v22_ptr = getelementptr [64 x i8], ptr %v22_scratch, i64 0, i64 %v10_offset
  store i8 2, ptr %v22_ptr, align 1
  %4 = load <16 x i8>, ptr %v22_scratch, align 16
  store <16 x i8> %4, ptr %v9_ptr, align 8
  %5 = load <16 x i8>, ptr %v19.fca.16.gep162, align 16
  store <16 x i8> %5, ptr %v9.elt287, align 8
  %6 = load <16 x i8>, ptr %v19.fca.32.gep194, align 16
  store <16 x i8> %6, ptr %v9.elt319, align 8
  %7 = load <16 x i8>, ptr %v19.fca.48.gep226, align 16
  store <16 x i8> %7, ptr %v9.elt351, align 8
  br label %b9

v25_ok:                                           ; preds = %b3
  %8 = load <16 x i8>, ptr %v9_ptr, align 8
  store <16 x i8> %8, ptr %v27_scratch, align 16
  %v24.fca.16.gep34 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 16
  %9 = load <16 x i8>, ptr %v9.elt287, align 8
  store <16 x i8> %9, ptr %v24.fca.16.gep34, align 16
  %v24.fca.32.gep66 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 32
  %10 = load <16 x i8>, ptr %v9.elt319, align 8
  store <16 x i8> %10, ptr %v24.fca.32.gep66, align 16
  %v24.fca.48.gep98 = getelementptr inbounds nuw i8, ptr %v27_scratch, i64 48
  %11 = load <16 x i8>, ptr %v9.elt351, align 8
  store <16 x i8> %11, ptr %v24.fca.48.gep98, align 16
  %v27_ptr = getelementptr [64 x i8], ptr %v27_scratch, i64 0, i64 %v10_offset
  store i8 7, ptr %v27_ptr, align 1
  %12 = load <16 x i8>, ptr %v27_scratch, align 16
  store <16 x i8> %12, ptr %v9_ptr, align 8
  %13 = load <16 x i8>, ptr %v24.fca.16.gep34, align 16
  store <16 x i8> %13, ptr %v9.elt287, align 8
  %14 = load <16 x i8>, ptr %v24.fca.32.gep66, align 16
  store <16 x i8> %14, ptr %v9.elt319, align 8
  %15 = load <16 x i8>, ptr %v24.fca.48.gep98, align 16
  store <16 x i8> %15, ptr %v9.elt351, align 8
  br label %b9

b9:                                               ; preds = %v25_ok, %v20_ok, %b1
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i32 @example_entry() local_unnamed_addr #6 {
entry:
  ret i32 0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define void @stream_start(ptr writeonly captures(none) initializes((0, 30), (32, 36), (40, 125), (128, 133), (136, 172), (176, 184)) %out) local_unnamed_addr #8 {
  %v16_mem.sroa.75.sroa.0.i = alloca i8, align 4
  %v16_mem.sroa.77.sroa.0.i = alloca i8, align 4
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.start.p0(i64 1, ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  store i1 false, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  store i1 false, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  %v16_mem.sroa.5.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 28
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(28) %out, i8 0, i64 28, i1 false)
  store i8 -128, ptr %v16_mem.sroa.5.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.6.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 29
  store i8 -65, ptr %v16_mem.sroa.6.0.return_storage.sroa_idx.i, align 1
  %v16_mem.sroa.71.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 32
  store i32 0, ptr %v16_mem.sroa.71.0.return_storage.sroa_idx.i, align 8
  %v16_mem.sroa.82.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 40
  %v16_mem.sroa.75.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 124
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(84) %v16_mem.sroa.82.0.return_storage.sroa_idx.i, i8 0, i64 84, i1 false)
  %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i = load i8, ptr %v16_mem.sroa.75.sroa.0.i, align 4
  store i8 %v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.i.0.v16_mem.sroa.75.sroa.0.0.v16_mem.sroa.75.sroa.0.0..i, ptr %v16_mem.sroa.75.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.764.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 128
  store i32 0, ptr %v16_mem.sroa.764.0.return_storage.sroa_idx.i, align 8
  %v16_mem.sroa.77.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 132
  %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i = load i8, ptr %v16_mem.sroa.77.sroa.0.i, align 4
  store i8 %v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.i.0.v16_mem.sroa.77.sroa.0.0.v16_mem.sroa.77.sroa.0.0..i, ptr %v16_mem.sroa.77.0.return_storage.sroa_idx.i, align 4
  %v16_mem.sroa.785.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 136
  %v16_mem.sroa.857.0.return_storage.sroa_idx.i = getelementptr inbounds nuw i8, ptr %out, i64 176
  store i64 0, ptr %v16_mem.sroa.857.0.return_storage.sroa_idx.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36) %v16_mem.sroa.785.0.return_storage.sroa_idx.i, i8 0, i64 36, i1 false)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %v16_mem.sroa.75.sroa.0.i)
  call void @llvm.lifetime.end.p0(i64 1, ptr nonnull %v16_mem.sroa.77.sroa.0.i)
  ret void
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define void @stream_feed(ptr %state, ptr readonly captures(none) %bytes, i32 %length) local_unnamed_addr #2 {
  %v0.i = getelementptr i8, ptr %state, i64 168
  %v1.i = load i32, ptr %v0.i, align 4
  %v3.not.i = icmp ne i32 %v1.i, 0
  %v99.not.i = icmp eq i32 %length, 0
  %or.cond = select i1 %v3.not.i, i1 true, i1 %v99.not.i
  br i1 %or.cond, label %liza_json.feed_mut.exit, label %v10_ok.lr.ph.i

v10_ok.lr.ph.i:                                   ; preds = %0
  %v42.i = getelementptr i8, ptr %state, i64 48
  %wide.trip.count.i = zext i32 %length to i64
  br label %v10_ok.i

v10_ok.i:                                         ; preds = %v46_ok.i, %v10_ok.lr.ph.i
  %indvars.iv.i = phi i64 [ 0, %v10_ok.lr.ph.i ], [ %indvars.iv.next.i, %v46_ok.i ]
  %v10_ptr.i = getelementptr i8, ptr %bytes, i64 %indvars.iv.i
  %v10.i = load i8, ptr %v10_ptr.i, align 1
  %v13.i = load %struct.Utf8StreamState, ptr %state, align 8
  %v14.i = tail call %struct.Utf8StreamState @liza_utf8_stream.feed_byte(%struct.Utf8StreamState %v13.i, i8 %v10.i)
  store %struct.Utf8StreamState %v14.i, ptr %state, align 8
  %v0.i.i = extractvalue %struct.Utf8StreamState %v14.i, 6
  switch i32 %v0.i.i, label %liza_utf8_stream.status.exit.i [
    i32 1, label %b1.i.i
    i32 2, label %b4.i.i
  ]

b1.i.i:                                           ; preds = %v10_ok.i
  %v4.i.i = extractvalue %struct.Utf8StreamState %v14.i, 7
  %v5.i.i = insertvalue %struct.Utf8StreamError zeroinitializer, i64 %v4.i.i, 1
  %v6.i.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v5.i.i, 1
  br label %liza_utf8_stream.status.exit.i

b4.i.i:                                           ; preds = %v10_ok.i
  %v11.i.i = extractvalue %struct.Utf8StreamState %v14.i, 7
  %v12.i.i = insertvalue %struct.Utf8StreamError { %variant.0 { i32 1, [0 x i8] zeroinitializer, [0 x i8] zeroinitializer }, i64 0 }, i64 %v11.i.i, 1
  %v13.i.i = insertvalue %variant.3 zeroinitializer, %struct.Utf8StreamError %v12.i.i, 1
  br label %liza_utf8_stream.status.exit.i

liza_utf8_stream.status.exit.i:                   ; preds = %b4.i.i, %b1.i.i, %v10_ok.i
  %common.ret.op.i.i = phi %variant.3 [ %v6.i.i, %b1.i.i ], [ %v13.i.i, %b4.i.i ], [ { i32 1, %struct.Utf8StreamError zeroinitializer, [0 x i8] zeroinitializer }, %v10_ok.i ]
  %v19.i = extractvalue %variant.3 %common.ret.op.i.i, 0
  %switch.i = icmp eq i32 %v19.i, 1
  br i1 %switch.i, label %b13.i, label %b9.i

b9.i:                                             ; preds = %liza_utf8_stream.status.exit.i
  %v20.i = extractvalue %variant.3 %common.ret.op.i.i, 1
  %v21.i = extractvalue %struct.Utf8StreamError %v20.i, 0
  %v22.i = extractvalue %variant.0 %v21.i, 0
  %switch1.i = icmp eq i32 %v22.i, 0
  %..i = select i1 %switch1.i, i32 5, i32 8
  %v29.i = extractvalue %struct.Utf8StreamError %v20.i, 1
  store i32 %..i, ptr %v0.i, align 4
  %v2.i4.i = getelementptr i8, ptr %state, i64 176
  store i64 %v29.i, ptr %v2.i4.i, align 8
  br label %liza_json.feed_mut.exit

b13.i:                                            ; preds = %liza_utf8_stream.status.exit.i
  %v34.i = tail call i32 @liza___liza_json_mut_step(i8 %v10.i, ptr nonnull %state)
  %v37.i = load i32, ptr %v0.i, align 4
  %v39.not.i = icmp eq i32 %v37.i, 0
  br i1 %v39.not.i, label %b16.i, label %liza_json.feed_mut.exit

b16.i:                                            ; preds = %b13.i
  %v44.i = load i64, ptr %v42.i, align 8
  %v46_pair.i = tail call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 %v44.i, i64 1)
  %v46_overflow.i = extractvalue { i64, i1 } %v46_pair.i, 1
  br i1 %v46_overflow.i, label %v46_trap.i, label %v46_ok.i

v46_trap.i:                                       ; preds = %b16.i
  tail call void @llvm.trap()
  unreachable

v46_ok.i:                                         ; preds = %b16.i
  %v46.i = extractvalue { i64, i1 } %v46_pair.i, 0
  store i64 %v46.i, ptr %v42.i, align 8
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1
  %exitcond.not.i = icmp eq i64 %indvars.iv.next.i, %wide.trip.count.i
  br i1 %exitcond.not.i, label %liza_json.feed_mut.exit, label %v10_ok.i

liza_json.feed_mut.exit:                          ; preds = %b13.i, %v46_ok.i, %0, %b9.i
  ret void
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i32 0, 9) i32 @stream_status(ptr readonly captures(none) %state) local_unnamed_addr #2 {
liza_status.exit:
  %v0.i = tail call %variant.5 @liza_json.finish(ptr readonly %state)
  %v1.i = extractvalue %variant.5 %v0.i, 0
  %switch.i = icmp eq i32 %v1.i, 0
  %v4.i = extractvalue %variant.5 %v0.i, 2
  %v5.i = extractvalue %struct.JsonError %v4.i, 0
  %v6.i = extractvalue %variant.1 %v5.i, 0
  %switch.offset = add nsw i32 %v6.i, 1
  %common.ret.op.i = select i1 %switch.i, i32 0, i32 %switch.offset
  ret i32 %common.ret.op.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define range(i32 0, 2) i32 @stream_pending(ptr readonly captures(none) %state) local_unnamed_addr #3 {
  %v0_ptr.i.i = getelementptr i8, ptr %state, i64 168
  %v0.i.i = load i32, ptr %v0_ptr.i.i, align 4
  %v2.i.not.i = icmp ne i32 %v0.i.i, 0
  %spec.select.i = zext i1 %v2.i.not.i to i32
  ret i32 %spec.select.i
}

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @stream_value(ptr readonly captures(none) %state) local_unnamed_addr #2 {
  %v0.i = tail call %variant.5 @liza_json.finish(ptr readonly %state)
  %v1.i = extractvalue %variant.5 %v0.i, 0
  %switch.i = icmp eq i32 %v1.i, 0
  %v2.i = extractvalue %variant.5 %v0.i, 1
  %v3.i = extractvalue %variant.5 %v0.i, 2
  %v4.i = extractvalue %struct.JsonError %v3.i, 1
  %common.ret.op.i = select i1 %switch.i, i64 %v2.i, i64 %v4.i
  ret i64 %common.ret.op.i
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef i64 @stream_size() local_unnamed_addr #6 {
  ret i64 184
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #10

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #11

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #12

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #12

attributes #0 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nounwind memory(argmem: readwrite, inaccessiblemem: write) }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind memory(read, argmem: readwrite, inaccessiblemem: write) }
attributes #6 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
attributes #7 = { nounwind memory(inaccessiblemem: write) }
attributes #8 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) }
attributes #9 = { nounwind memory(readwrite, inaccessiblemem: write) }
attributes #10 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #11 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
